/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 9889:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "handler": () => (/* binding */ handler)
});

;// CONCATENATED MODULE: ./lambdas/db/products.json
const products_namespaceObject = [];
// EXTERNAL MODULE: ./node_modules/pg/lib/index.js
var lib = __webpack_require__(8955);
;// CONCATENATED MODULE: ./conection.js



const { PG_HOST, PG_PORT, PG_DATABASE, PG_USERNAME, PG_PASSWORD } = process.env;
const dbOptions = {
    host: PG_HOST,
    port: PG_PORT,
    database: PG_DATABASE,
    user: PG_USERNAME,
    password: PG_PASSWORD,
    ssl: {
        rejectUnauthorized: false,
    },
    connectionTimeoutMillis: 5000,
};
class ConnectDB {
    constructor() {
        this.client = new lib.Client(dbOptions);
    }

    async connect() {
        await this.client.connect();
        return this.client;
    }

    async disconnect() {
        await this.client.end();
    }

    async createTable(tableName, config) {
        await this.client.query(`
  create table if not exist ${tableName} (
    ${config}
  )`);
    }


    async getList(tableName) {
        const { rows } = await this.client.query(select * from `${tableName}`);
        return rows;
    }
}
;// CONCATENATED MODULE: ./lambdas/getProductsList.js







const handler = async (event) => {
    console.log(event);
    const db = new ConnectDB();

    try {
        const client = await db.connect();

        const { rows } = await client.query(`select products.*, stock.count from products left join stock on products.id = stock.product_id`);

        return {
            headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Methods': '*',
                    'Access-Control-Allow-Origin': '*',
                  },
                statusCode: 200,
                body: JSON.stringify(rows)
            };
    } catch (error) {
    return {
        headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Origin': '*',
              },
            statusCode: 500,
            body: JSON.stringify(error.message)
        };
    } finally {
        db.disconnect();
    }
};

/***/ }),

/***/ 4378:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

try {
  var util = __webpack_require__(1669);
  /* istanbul ignore next */
  if (typeof util.inherits !== 'function') throw '';
  module.exports = util.inherits;
} catch (e) {
  /* istanbul ignore next */
  module.exports = __webpack_require__(5717);
}


/***/ }),

/***/ 5717:
/***/ ((module) => {

if (typeof Object.create === 'function') {
  // implementation from standard node.js 'util' module
  module.exports = function inherits(ctor, superCtor) {
    if (superCtor) {
      ctor.super_ = superCtor
      ctor.prototype = Object.create(superCtor.prototype, {
        constructor: {
          value: ctor,
          enumerable: false,
          writable: true,
          configurable: true
        }
      })
    }
  };
} else {
  // old school shim for old browsers
  module.exports = function inherits(ctor, superCtor) {
    if (superCtor) {
      ctor.super_ = superCtor
      var TempCtor = function () {}
      TempCtor.prototype = superCtor.prototype
      ctor.prototype = new TempCtor()
      ctor.prototype.constructor = ctor
    }
  }
}


/***/ }),

/***/ 5697:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var url = __webpack_require__(8835)
var fs = __webpack_require__(5747)

//Parse method copied from https://github.com/brianc/node-postgres
//Copyright (c) 2010-2014 Brian Carlson (brian.m.carlson@gmail.com)
//MIT License

//parses a connection string
function parse(str) {
  //unix socket
  if (str.charAt(0) === '/') {
    var config = str.split(' ')
    return { host: config[0], database: config[1] }
  }

  // url parse expects spaces encoded as %20
  var result = url.parse(
    / |%[^a-f0-9]|%[a-f0-9][^a-f0-9]/i.test(str) ? encodeURI(str).replace(/\%25(\d\d)/g, '%$1') : str,
    true
  )
  var config = result.query
  for (var k in config) {
    if (Array.isArray(config[k])) {
      config[k] = config[k][config[k].length - 1]
    }
  }

  var auth = (result.auth || ':').split(':')
  config.user = auth[0]
  config.password = auth.splice(1).join(':')

  config.port = result.port
  if (result.protocol == 'socket:') {
    config.host = decodeURI(result.pathname)
    config.database = result.query.db
    config.client_encoding = result.query.encoding
    return config
  }
  if (!config.host) {
    // Only set the host if there is no equivalent query param.
    config.host = result.hostname
  }

  // If the host is missing it might be a URL-encoded path to a socket.
  var pathname = result.pathname
  if (!config.host && pathname && /^%2f/i.test(pathname)) {
    var pathnameSplit = pathname.split('/')
    config.host = decodeURIComponent(pathnameSplit[0])
    pathname = pathnameSplit.splice(1).join('/')
  }
  // result.pathname is not always guaranteed to have a '/' prefix (e.g. relative urls)
  // only strip the slash if it is present.
  if (pathname && pathname.charAt(0) === '/') {
    pathname = pathname.slice(1) || null
  }
  config.database = pathname && decodeURI(pathname)

  if (config.ssl === 'true' || config.ssl === '1') {
    config.ssl = true
  }

  if (config.ssl === '0') {
    config.ssl = false
  }

  if (config.sslcert || config.sslkey || config.sslrootcert || config.sslmode) {
    config.ssl = {}
  }

  if (config.sslcert) {
    config.ssl.cert = fs.readFileSync(config.sslcert).toString()
  }

  if (config.sslkey) {
    config.ssl.key = fs.readFileSync(config.sslkey).toString()
  }

  if (config.sslrootcert) {
    config.ssl.ca = fs.readFileSync(config.sslrootcert).toString()
  }

  switch (config.sslmode) {
    case 'disable': {
      config.ssl = false
      break
    }
    case 'prefer':
    case 'require':
    case 'verify-ca':
    case 'verify-full': {
      break
    }
    case 'no-verify': {
      config.ssl.rejectUnauthorized = false
      break
    }
  }

  return config
}

module.exports = parse

parse.parse = parse


/***/ }),

/***/ 6064:
/***/ ((module) => {

"use strict";


// selected so (BASE - 1) * 0x100000000 + 0xffffffff is a safe integer
var BASE = 1000000;

function readInt8(buffer) {
	var high = buffer.readInt32BE(0);
	var low = buffer.readUInt32BE(4);
	var sign = '';

	if (high < 0) {
		high = ~high + (low === 0);
		low = (~low + 1) >>> 0;
		sign = '-';
	}

	var result = '';
	var carry;
	var t;
	var digits;
	var pad;
	var l;
	var i;

	{
		carry = high % BASE;
		high = high / BASE >>> 0;

		t = 0x100000000 * carry + low;
		low = t / BASE >>> 0;
		digits = '' + (t - BASE * low);

		if (low === 0 && high === 0) {
			return sign + digits + result;
		}

		pad = '';
		l = 6 - digits.length;

		for (i = 0; i < l; i++) {
			pad += '0';
		}

		result = pad + digits + result;
	}

	{
		carry = high % BASE;
		high = high / BASE >>> 0;

		t = 0x100000000 * carry + low;
		low = t / BASE >>> 0;
		digits = '' + (t - BASE * low);

		if (low === 0 && high === 0) {
			return sign + digits + result;
		}

		pad = '';
		l = 6 - digits.length;

		for (i = 0; i < l; i++) {
			pad += '0';
		}

		result = pad + digits + result;
	}

	{
		carry = high % BASE;
		high = high / BASE >>> 0;

		t = 0x100000000 * carry + low;
		low = t / BASE >>> 0;
		digits = '' + (t - BASE * low);

		if (low === 0 && high === 0) {
			return sign + digits + result;
		}

		pad = '';
		l = 6 - digits.length;

		for (i = 0; i < l; i++) {
			pad += '0';
		}

		result = pad + digits + result;
	}

	{
		carry = high % BASE;
		t = 0x100000000 * carry + low;
		digits = '' + t % BASE;

		return sign + digits + result;
	}
}

module.exports = readInt8;


/***/ }),

/***/ 5546:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

const EventEmitter = __webpack_require__(8614).EventEmitter

const NOOP = function () {}

const removeWhere = (list, predicate) => {
  const i = list.findIndex(predicate)

  return i === -1 ? undefined : list.splice(i, 1)[0]
}

class IdleItem {
  constructor(client, idleListener, timeoutId) {
    this.client = client
    this.idleListener = idleListener
    this.timeoutId = timeoutId
  }
}

class PendingItem {
  constructor(callback) {
    this.callback = callback
  }
}

function throwOnDoubleRelease() {
  throw new Error('Release called on client which has already been released to the pool.')
}

function promisify(Promise, callback) {
  if (callback) {
    return { callback: callback, result: undefined }
  }
  let rej
  let res
  const cb = function (err, client) {
    err ? rej(err) : res(client)
  }
  const result = new Promise(function (resolve, reject) {
    res = resolve
    rej = reject
  })
  return { callback: cb, result: result }
}

function makeIdleListener(pool, client) {
  return function idleListener(err) {
    err.client = client

    client.removeListener('error', idleListener)
    client.on('error', () => {
      pool.log('additional client error after disconnection due to error', err)
    })
    pool._remove(client)
    // TODO - document that once the pool emits an error
    // the client has already been closed & purged and is unusable
    pool.emit('error', err, client)
  }
}

class Pool extends EventEmitter {
  constructor(options, Client) {
    super()
    this.options = Object.assign({}, options)

    if (options != null && 'password' in options) {
      // "hiding" the password so it doesn't show up in stack traces
      // or if the client is console.logged
      Object.defineProperty(this.options, 'password', {
        configurable: true,
        enumerable: false,
        writable: true,
        value: options.password,
      })
    }
    if (options != null && options.ssl && options.ssl.key) {
      // "hiding" the ssl->key so it doesn't show up in stack traces
      // or if the client is console.logged
      Object.defineProperty(this.options.ssl, 'key', {
        enumerable: false,
      })
    }

    this.options.max = this.options.max || this.options.poolSize || 10
    this.options.maxUses = this.options.maxUses || Infinity
    this.options.allowExitOnIdle = this.options.allowExitOnIdle || false
    this.log = this.options.log || function () {}
    this.Client = this.options.Client || Client || __webpack_require__(8955).Client
    this.Promise = this.options.Promise || global.Promise

    if (typeof this.options.idleTimeoutMillis === 'undefined') {
      this.options.idleTimeoutMillis = 10000
    }

    this._clients = []
    this._idle = []
    this._pendingQueue = []
    this._endCallback = undefined
    this.ending = false
    this.ended = false
  }

  _isFull() {
    return this._clients.length >= this.options.max
  }

  _pulseQueue() {
    this.log('pulse queue')
    if (this.ended) {
      this.log('pulse queue ended')
      return
    }
    if (this.ending) {
      this.log('pulse queue on ending')
      if (this._idle.length) {
        this._idle.slice().map((item) => {
          this._remove(item.client)
        })
      }
      if (!this._clients.length) {
        this.ended = true
        this._endCallback()
      }
      return
    }
    // if we don't have any waiting, do nothing
    if (!this._pendingQueue.length) {
      this.log('no queued requests')
      return
    }
    // if we don't have any idle clients and we have no more room do nothing
    if (!this._idle.length && this._isFull()) {
      return
    }
    const pendingItem = this._pendingQueue.shift()
    if (this._idle.length) {
      const idleItem = this._idle.pop()
      clearTimeout(idleItem.timeoutId)
      const client = idleItem.client
      client.ref && client.ref()
      const idleListener = idleItem.idleListener

      return this._acquireClient(client, pendingItem, idleListener, false)
    }
    if (!this._isFull()) {
      return this.newClient(pendingItem)
    }
    throw new Error('unexpected condition')
  }

  _remove(client) {
    const removed = removeWhere(this._idle, (item) => item.client === client)

    if (removed !== undefined) {
      clearTimeout(removed.timeoutId)
    }

    this._clients = this._clients.filter((c) => c !== client)
    client.end()
    this.emit('remove', client)
  }

  connect(cb) {
    if (this.ending) {
      const err = new Error('Cannot use a pool after calling end on the pool')
      return cb ? cb(err) : this.Promise.reject(err)
    }

    const response = promisify(this.Promise, cb)
    const result = response.result

    // if we don't have to connect a new client, don't do so
    if (this._isFull() || this._idle.length) {
      // if we have idle clients schedule a pulse immediately
      if (this._idle.length) {
        process.nextTick(() => this._pulseQueue())
      }

      if (!this.options.connectionTimeoutMillis) {
        this._pendingQueue.push(new PendingItem(response.callback))
        return result
      }

      const queueCallback = (err, res, done) => {
        clearTimeout(tid)
        response.callback(err, res, done)
      }

      const pendingItem = new PendingItem(queueCallback)

      // set connection timeout on checking out an existing client
      const tid = setTimeout(() => {
        // remove the callback from pending waiters because
        // we're going to call it with a timeout error
        removeWhere(this._pendingQueue, (i) => i.callback === queueCallback)
        pendingItem.timedOut = true
        response.callback(new Error('timeout exceeded when trying to connect'))
      }, this.options.connectionTimeoutMillis)

      this._pendingQueue.push(pendingItem)
      return result
    }

    this.newClient(new PendingItem(response.callback))

    return result
  }

  newClient(pendingItem) {
    const client = new this.Client(this.options)
    this._clients.push(client)
    const idleListener = makeIdleListener(this, client)

    this.log('checking client timeout')

    // connection timeout logic
    let tid
    let timeoutHit = false
    if (this.options.connectionTimeoutMillis) {
      tid = setTimeout(() => {
        this.log('ending client due to timeout')
        timeoutHit = true
        // force kill the node driver, and let libpq do its teardown
        client.connection ? client.connection.stream.destroy() : client.end()
      }, this.options.connectionTimeoutMillis)
    }

    this.log('connecting new client')
    client.connect((err) => {
      if (tid) {
        clearTimeout(tid)
      }
      client.on('error', idleListener)
      if (err) {
        this.log('client failed to connect', err)
        // remove the dead client from our list of clients
        this._clients = this._clients.filter((c) => c !== client)
        if (timeoutHit) {
          err.message = 'Connection terminated due to connection timeout'
        }

        // this client won’t be released, so move on immediately
        this._pulseQueue()

        if (!pendingItem.timedOut) {
          pendingItem.callback(err, undefined, NOOP)
        }
      } else {
        this.log('new client connected')

        return this._acquireClient(client, pendingItem, idleListener, true)
      }
    })
  }

  // acquire a client for a pending work item
  _acquireClient(client, pendingItem, idleListener, isNew) {
    if (isNew) {
      this.emit('connect', client)
    }

    this.emit('acquire', client)

    client.release = this._releaseOnce(client, idleListener)

    client.removeListener('error', idleListener)

    if (!pendingItem.timedOut) {
      if (isNew && this.options.verify) {
        this.options.verify(client, (err) => {
          if (err) {
            client.release(err)
            return pendingItem.callback(err, undefined, NOOP)
          }

          pendingItem.callback(undefined, client, client.release)
        })
      } else {
        pendingItem.callback(undefined, client, client.release)
      }
    } else {
      if (isNew && this.options.verify) {
        this.options.verify(client, client.release)
      } else {
        client.release()
      }
    }
  }

  // returns a function that wraps _release and throws if called more than once
  _releaseOnce(client, idleListener) {
    let released = false

    return (err) => {
      if (released) {
        throwOnDoubleRelease()
      }

      released = true
      this._release(client, idleListener, err)
    }
  }

  // release a client back to the poll, include an error
  // to remove it from the pool
  _release(client, idleListener, err) {
    client.on('error', idleListener)

    client._poolUseCount = (client._poolUseCount || 0) + 1

    // TODO(bmc): expose a proper, public interface _queryable and _ending
    if (err || this.ending || !client._queryable || client._ending || client._poolUseCount >= this.options.maxUses) {
      if (client._poolUseCount >= this.options.maxUses) {
        this.log('remove expended client')
      }
      this._remove(client)
      this._pulseQueue()
      return
    }

    // idle timeout
    let tid
    if (this.options.idleTimeoutMillis) {
      tid = setTimeout(() => {
        this.log('remove idle client')
        this._remove(client)
      }, this.options.idleTimeoutMillis)

      if (this.options.allowExitOnIdle) {
        // allow Node to exit if this is all that's left
        tid.unref()
      }
    }

    if (this.options.allowExitOnIdle) {
      client.unref()
    }

    this._idle.push(new IdleItem(client, idleListener, tid))
    this._pulseQueue()
  }

  query(text, values, cb) {
    // guard clause against passing a function as the first parameter
    if (typeof text === 'function') {
      const response = promisify(this.Promise, text)
      setImmediate(function () {
        return response.callback(new Error('Passing a function as the first parameter to pool.query is not supported'))
      })
      return response.result
    }

    // allow plain text query without values
    if (typeof values === 'function') {
      cb = values
      values = undefined
    }
    const response = promisify(this.Promise, cb)
    cb = response.callback

    this.connect((err, client) => {
      if (err) {
        return cb(err)
      }

      let clientReleased = false
      const onError = (err) => {
        if (clientReleased) {
          return
        }
        clientReleased = true
        client.release(err)
        cb(err)
      }

      client.once('error', onError)
      this.log('dispatching query')
      client.query(text, values, (err, res) => {
        this.log('query dispatched')
        client.removeListener('error', onError)
        if (clientReleased) {
          return
        }
        clientReleased = true
        client.release(err)
        if (err) {
          return cb(err)
        } else {
          return cb(undefined, res)
        }
      })
    })
    return response.result
  }

  end(cb) {
    this.log('ending')
    if (this.ending) {
      const err = new Error('Called end on pool more than once')
      return cb ? cb(err) : this.Promise.reject(err)
    }
    this.ending = true
    const promised = promisify(this.Promise, cb)
    this._endCallback = promised.callback
    this._pulseQueue()
    return promised.result
  }

  get waitingCount() {
    return this._pendingQueue.length
  }

  get idleCount() {
    return this._idle.length
  }

  get totalCount() {
    return this._clients.length
  }
}
module.exports = Pool


/***/ }),

/***/ 1144:
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BufferReader = void 0;
const emptyBuffer = Buffer.allocUnsafe(0);
class BufferReader {
    constructor(offset = 0) {
        this.offset = offset;
        this.buffer = emptyBuffer;
        // TODO(bmc): support non-utf8 encoding?
        this.encoding = 'utf-8';
    }
    setBuffer(offset, buffer) {
        this.offset = offset;
        this.buffer = buffer;
    }
    int16() {
        const result = this.buffer.readInt16BE(this.offset);
        this.offset += 2;
        return result;
    }
    byte() {
        const result = this.buffer[this.offset];
        this.offset++;
        return result;
    }
    int32() {
        const result = this.buffer.readInt32BE(this.offset);
        this.offset += 4;
        return result;
    }
    string(length) {
        const result = this.buffer.toString(this.encoding, this.offset, this.offset + length);
        this.offset += length;
        return result;
    }
    cstring() {
        const start = this.offset;
        let end = start;
        while (this.buffer[end++] !== 0) { }
        this.offset = end;
        return this.buffer.toString(this.encoding, start, end - 1);
    }
    bytes(length) {
        const result = this.buffer.slice(this.offset, this.offset + length);
        this.offset += length;
        return result;
    }
}
exports.BufferReader = BufferReader;
//# sourceMappingURL=buffer-reader.js.map

/***/ }),

/***/ 246:
/***/ ((__unused_webpack_module, exports) => {

"use strict";

//binary data writer tuned for encoding binary specific to the postgres binary protocol
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Writer = void 0;
class Writer {
    constructor(size = 256) {
        this.size = size;
        this.offset = 5;
        this.headerPosition = 0;
        this.buffer = Buffer.allocUnsafe(size);
    }
    ensure(size) {
        var remaining = this.buffer.length - this.offset;
        if (remaining < size) {
            var oldBuffer = this.buffer;
            // exponential growth factor of around ~ 1.5
            // https://stackoverflow.com/questions/2269063/buffer-growth-strategy
            var newSize = oldBuffer.length + (oldBuffer.length >> 1) + size;
            this.buffer = Buffer.allocUnsafe(newSize);
            oldBuffer.copy(this.buffer);
        }
    }
    addInt32(num) {
        this.ensure(4);
        this.buffer[this.offset++] = (num >>> 24) & 0xff;
        this.buffer[this.offset++] = (num >>> 16) & 0xff;
        this.buffer[this.offset++] = (num >>> 8) & 0xff;
        this.buffer[this.offset++] = (num >>> 0) & 0xff;
        return this;
    }
    addInt16(num) {
        this.ensure(2);
        this.buffer[this.offset++] = (num >>> 8) & 0xff;
        this.buffer[this.offset++] = (num >>> 0) & 0xff;
        return this;
    }
    addCString(string) {
        if (!string) {
            this.ensure(1);
        }
        else {
            var len = Buffer.byteLength(string);
            this.ensure(len + 1); // +1 for null terminator
            this.buffer.write(string, this.offset, 'utf-8');
            this.offset += len;
        }
        this.buffer[this.offset++] = 0; // null terminator
        return this;
    }
    addString(string = '') {
        var len = Buffer.byteLength(string);
        this.ensure(len);
        this.buffer.write(string, this.offset);
        this.offset += len;
        return this;
    }
    add(otherBuffer) {
        this.ensure(otherBuffer.length);
        otherBuffer.copy(this.buffer, this.offset);
        this.offset += otherBuffer.length;
        return this;
    }
    join(code) {
        if (code) {
            this.buffer[this.headerPosition] = code;
            //length is everything in this packet minus the code
            const length = this.offset - (this.headerPosition + 1);
            this.buffer.writeInt32BE(length, this.headerPosition + 1);
        }
        return this.buffer.slice(code ? 0 : 5, this.offset);
    }
    flush(code) {
        var result = this.join(code);
        this.offset = 5;
        this.headerPosition = 0;
        this.buffer = Buffer.allocUnsafe(this.size);
        return result;
    }
}
exports.Writer = Writer;
//# sourceMappingURL=buffer-writer.js.map

/***/ }),

/***/ 8152:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DatabaseError = exports.serialize = exports.parse = void 0;
const messages_1 = __webpack_require__(2510);
Object.defineProperty(exports, "DatabaseError", ({ enumerable: true, get: function () { return messages_1.DatabaseError; } }));
const serializer_1 = __webpack_require__(9209);
Object.defineProperty(exports, "serialize", ({ enumerable: true, get: function () { return serializer_1.serialize; } }));
const parser_1 = __webpack_require__(946);
function parse(stream, callback) {
    const parser = new parser_1.Parser();
    stream.on('data', (buffer) => parser.parse(buffer, callback));
    return new Promise((resolve) => stream.on('end', () => resolve()));
}
exports.parse = parse;
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 2510:
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.NoticeMessage = exports.DataRowMessage = exports.CommandCompleteMessage = exports.ReadyForQueryMessage = exports.NotificationResponseMessage = exports.BackendKeyDataMessage = exports.AuthenticationMD5Password = exports.ParameterStatusMessage = exports.ParameterDescriptionMessage = exports.RowDescriptionMessage = exports.Field = exports.CopyResponse = exports.CopyDataMessage = exports.DatabaseError = exports.copyDone = exports.emptyQuery = exports.replicationStart = exports.portalSuspended = exports.noData = exports.closeComplete = exports.bindComplete = exports.parseComplete = void 0;
exports.parseComplete = {
    name: 'parseComplete',
    length: 5,
};
exports.bindComplete = {
    name: 'bindComplete',
    length: 5,
};
exports.closeComplete = {
    name: 'closeComplete',
    length: 5,
};
exports.noData = {
    name: 'noData',
    length: 5,
};
exports.portalSuspended = {
    name: 'portalSuspended',
    length: 5,
};
exports.replicationStart = {
    name: 'replicationStart',
    length: 4,
};
exports.emptyQuery = {
    name: 'emptyQuery',
    length: 4,
};
exports.copyDone = {
    name: 'copyDone',
    length: 4,
};
class DatabaseError extends Error {
    constructor(message, length, name) {
        super(message);
        this.length = length;
        this.name = name;
    }
}
exports.DatabaseError = DatabaseError;
class CopyDataMessage {
    constructor(length, chunk) {
        this.length = length;
        this.chunk = chunk;
        this.name = 'copyData';
    }
}
exports.CopyDataMessage = CopyDataMessage;
class CopyResponse {
    constructor(length, name, binary, columnCount) {
        this.length = length;
        this.name = name;
        this.binary = binary;
        this.columnTypes = new Array(columnCount);
    }
}
exports.CopyResponse = CopyResponse;
class Field {
    constructor(name, tableID, columnID, dataTypeID, dataTypeSize, dataTypeModifier, format) {
        this.name = name;
        this.tableID = tableID;
        this.columnID = columnID;
        this.dataTypeID = dataTypeID;
        this.dataTypeSize = dataTypeSize;
        this.dataTypeModifier = dataTypeModifier;
        this.format = format;
    }
}
exports.Field = Field;
class RowDescriptionMessage {
    constructor(length, fieldCount) {
        this.length = length;
        this.fieldCount = fieldCount;
        this.name = 'rowDescription';
        this.fields = new Array(this.fieldCount);
    }
}
exports.RowDescriptionMessage = RowDescriptionMessage;
class ParameterDescriptionMessage {
    constructor(length, parameterCount) {
        this.length = length;
        this.parameterCount = parameterCount;
        this.name = 'parameterDescription';
        this.dataTypeIDs = new Array(this.parameterCount);
    }
}
exports.ParameterDescriptionMessage = ParameterDescriptionMessage;
class ParameterStatusMessage {
    constructor(length, parameterName, parameterValue) {
        this.length = length;
        this.parameterName = parameterName;
        this.parameterValue = parameterValue;
        this.name = 'parameterStatus';
    }
}
exports.ParameterStatusMessage = ParameterStatusMessage;
class AuthenticationMD5Password {
    constructor(length, salt) {
        this.length = length;
        this.salt = salt;
        this.name = 'authenticationMD5Password';
    }
}
exports.AuthenticationMD5Password = AuthenticationMD5Password;
class BackendKeyDataMessage {
    constructor(length, processID, secretKey) {
        this.length = length;
        this.processID = processID;
        this.secretKey = secretKey;
        this.name = 'backendKeyData';
    }
}
exports.BackendKeyDataMessage = BackendKeyDataMessage;
class NotificationResponseMessage {
    constructor(length, processId, channel, payload) {
        this.length = length;
        this.processId = processId;
        this.channel = channel;
        this.payload = payload;
        this.name = 'notification';
    }
}
exports.NotificationResponseMessage = NotificationResponseMessage;
class ReadyForQueryMessage {
    constructor(length, status) {
        this.length = length;
        this.status = status;
        this.name = 'readyForQuery';
    }
}
exports.ReadyForQueryMessage = ReadyForQueryMessage;
class CommandCompleteMessage {
    constructor(length, text) {
        this.length = length;
        this.text = text;
        this.name = 'commandComplete';
    }
}
exports.CommandCompleteMessage = CommandCompleteMessage;
class DataRowMessage {
    constructor(length, fields) {
        this.length = length;
        this.fields = fields;
        this.name = 'dataRow';
        this.fieldCount = fields.length;
    }
}
exports.DataRowMessage = DataRowMessage;
class NoticeMessage {
    constructor(length, message) {
        this.length = length;
        this.message = message;
        this.name = 'notice';
    }
}
exports.NoticeMessage = NoticeMessage;
//# sourceMappingURL=messages.js.map

/***/ }),

/***/ 946:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Parser = void 0;
const messages_1 = __webpack_require__(2510);
const buffer_reader_1 = __webpack_require__(1144);
const assert_1 = __importDefault(__webpack_require__(2357));
// every message is prefixed with a single bye
const CODE_LENGTH = 1;
// every message has an int32 length which includes itself but does
// NOT include the code in the length
const LEN_LENGTH = 4;
const HEADER_LENGTH = CODE_LENGTH + LEN_LENGTH;
const emptyBuffer = Buffer.allocUnsafe(0);
class Parser {
    constructor(opts) {
        this.buffer = emptyBuffer;
        this.bufferLength = 0;
        this.bufferOffset = 0;
        this.reader = new buffer_reader_1.BufferReader();
        if ((opts === null || opts === void 0 ? void 0 : opts.mode) === 'binary') {
            throw new Error('Binary mode not supported yet');
        }
        this.mode = (opts === null || opts === void 0 ? void 0 : opts.mode) || 'text';
    }
    parse(buffer, callback) {
        this.mergeBuffer(buffer);
        const bufferFullLength = this.bufferOffset + this.bufferLength;
        let offset = this.bufferOffset;
        while (offset + HEADER_LENGTH <= bufferFullLength) {
            // code is 1 byte long - it identifies the message type
            const code = this.buffer[offset];
            // length is 1 Uint32BE - it is the length of the message EXCLUDING the code
            const length = this.buffer.readUInt32BE(offset + CODE_LENGTH);
            const fullMessageLength = CODE_LENGTH + length;
            if (fullMessageLength + offset <= bufferFullLength) {
                const message = this.handlePacket(offset + HEADER_LENGTH, code, length, this.buffer);
                callback(message);
                offset += fullMessageLength;
            }
            else {
                break;
            }
        }
        if (offset === bufferFullLength) {
            // No more use for the buffer
            this.buffer = emptyBuffer;
            this.bufferLength = 0;
            this.bufferOffset = 0;
        }
        else {
            // Adjust the cursors of remainingBuffer
            this.bufferLength = bufferFullLength - offset;
            this.bufferOffset = offset;
        }
    }
    mergeBuffer(buffer) {
        if (this.bufferLength > 0) {
            const newLength = this.bufferLength + buffer.byteLength;
            const newFullLength = newLength + this.bufferOffset;
            if (newFullLength > this.buffer.byteLength) {
                // We can't concat the new buffer with the remaining one
                let newBuffer;
                if (newLength <= this.buffer.byteLength && this.bufferOffset >= this.bufferLength) {
                    // We can move the relevant part to the beginning of the buffer instead of allocating a new buffer
                    newBuffer = this.buffer;
                }
                else {
                    // Allocate a new larger buffer
                    let newBufferLength = this.buffer.byteLength * 2;
                    while (newLength >= newBufferLength) {
                        newBufferLength *= 2;
                    }
                    newBuffer = Buffer.allocUnsafe(newBufferLength);
                }
                // Move the remaining buffer to the new one
                this.buffer.copy(newBuffer, 0, this.bufferOffset, this.bufferOffset + this.bufferLength);
                this.buffer = newBuffer;
                this.bufferOffset = 0;
            }
            // Concat the new buffer with the remaining one
            buffer.copy(this.buffer, this.bufferOffset + this.bufferLength);
            this.bufferLength = newLength;
        }
        else {
            this.buffer = buffer;
            this.bufferOffset = 0;
            this.bufferLength = buffer.byteLength;
        }
    }
    handlePacket(offset, code, length, bytes) {
        switch (code) {
            case 50 /* BindComplete */:
                return messages_1.bindComplete;
            case 49 /* ParseComplete */:
                return messages_1.parseComplete;
            case 51 /* CloseComplete */:
                return messages_1.closeComplete;
            case 110 /* NoData */:
                return messages_1.noData;
            case 115 /* PortalSuspended */:
                return messages_1.portalSuspended;
            case 99 /* CopyDone */:
                return messages_1.copyDone;
            case 87 /* ReplicationStart */:
                return messages_1.replicationStart;
            case 73 /* EmptyQuery */:
                return messages_1.emptyQuery;
            case 68 /* DataRow */:
                return this.parseDataRowMessage(offset, length, bytes);
            case 67 /* CommandComplete */:
                return this.parseCommandCompleteMessage(offset, length, bytes);
            case 90 /* ReadyForQuery */:
                return this.parseReadyForQueryMessage(offset, length, bytes);
            case 65 /* NotificationResponse */:
                return this.parseNotificationMessage(offset, length, bytes);
            case 82 /* AuthenticationResponse */:
                return this.parseAuthenticationResponse(offset, length, bytes);
            case 83 /* ParameterStatus */:
                return this.parseParameterStatusMessage(offset, length, bytes);
            case 75 /* BackendKeyData */:
                return this.parseBackendKeyData(offset, length, bytes);
            case 69 /* ErrorMessage */:
                return this.parseErrorMessage(offset, length, bytes, 'error');
            case 78 /* NoticeMessage */:
                return this.parseErrorMessage(offset, length, bytes, 'notice');
            case 84 /* RowDescriptionMessage */:
                return this.parseRowDescriptionMessage(offset, length, bytes);
            case 116 /* ParameterDescriptionMessage */:
                return this.parseParameterDescriptionMessage(offset, length, bytes);
            case 71 /* CopyIn */:
                return this.parseCopyInMessage(offset, length, bytes);
            case 72 /* CopyOut */:
                return this.parseCopyOutMessage(offset, length, bytes);
            case 100 /* CopyData */:
                return this.parseCopyData(offset, length, bytes);
            default:
                assert_1.default.fail(`unknown message code: ${code.toString(16)}`);
        }
    }
    parseReadyForQueryMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const status = this.reader.string(1);
        return new messages_1.ReadyForQueryMessage(length, status);
    }
    parseCommandCompleteMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const text = this.reader.cstring();
        return new messages_1.CommandCompleteMessage(length, text);
    }
    parseCopyData(offset, length, bytes) {
        const chunk = bytes.slice(offset, offset + (length - 4));
        return new messages_1.CopyDataMessage(length, chunk);
    }
    parseCopyInMessage(offset, length, bytes) {
        return this.parseCopyMessage(offset, length, bytes, 'copyInResponse');
    }
    parseCopyOutMessage(offset, length, bytes) {
        return this.parseCopyMessage(offset, length, bytes, 'copyOutResponse');
    }
    parseCopyMessage(offset, length, bytes, messageName) {
        this.reader.setBuffer(offset, bytes);
        const isBinary = this.reader.byte() !== 0;
        const columnCount = this.reader.int16();
        const message = new messages_1.CopyResponse(length, messageName, isBinary, columnCount);
        for (let i = 0; i < columnCount; i++) {
            message.columnTypes[i] = this.reader.int16();
        }
        return message;
    }
    parseNotificationMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const processId = this.reader.int32();
        const channel = this.reader.cstring();
        const payload = this.reader.cstring();
        return new messages_1.NotificationResponseMessage(length, processId, channel, payload);
    }
    parseRowDescriptionMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const fieldCount = this.reader.int16();
        const message = new messages_1.RowDescriptionMessage(length, fieldCount);
        for (let i = 0; i < fieldCount; i++) {
            message.fields[i] = this.parseField();
        }
        return message;
    }
    parseField() {
        const name = this.reader.cstring();
        const tableID = this.reader.int32();
        const columnID = this.reader.int16();
        const dataTypeID = this.reader.int32();
        const dataTypeSize = this.reader.int16();
        const dataTypeModifier = this.reader.int32();
        const mode = this.reader.int16() === 0 ? 'text' : 'binary';
        return new messages_1.Field(name, tableID, columnID, dataTypeID, dataTypeSize, dataTypeModifier, mode);
    }
    parseParameterDescriptionMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const parameterCount = this.reader.int16();
        const message = new messages_1.ParameterDescriptionMessage(length, parameterCount);
        for (let i = 0; i < parameterCount; i++) {
            message.dataTypeIDs[i] = this.reader.int32();
        }
        return message;
    }
    parseDataRowMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const fieldCount = this.reader.int16();
        const fields = new Array(fieldCount);
        for (let i = 0; i < fieldCount; i++) {
            const len = this.reader.int32();
            // a -1 for length means the value of the field is null
            fields[i] = len === -1 ? null : this.reader.string(len);
        }
        return new messages_1.DataRowMessage(length, fields);
    }
    parseParameterStatusMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const name = this.reader.cstring();
        const value = this.reader.cstring();
        return new messages_1.ParameterStatusMessage(length, name, value);
    }
    parseBackendKeyData(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const processID = this.reader.int32();
        const secretKey = this.reader.int32();
        return new messages_1.BackendKeyDataMessage(length, processID, secretKey);
    }
    parseAuthenticationResponse(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const code = this.reader.int32();
        // TODO(bmc): maybe better types here
        const message = {
            name: 'authenticationOk',
            length,
        };
        switch (code) {
            case 0: // AuthenticationOk
                break;
            case 3: // AuthenticationCleartextPassword
                if (message.length === 8) {
                    message.name = 'authenticationCleartextPassword';
                }
                break;
            case 5: // AuthenticationMD5Password
                if (message.length === 12) {
                    message.name = 'authenticationMD5Password';
                    const salt = this.reader.bytes(4);
                    return new messages_1.AuthenticationMD5Password(length, salt);
                }
                break;
            case 10: // AuthenticationSASL
                message.name = 'authenticationSASL';
                message.mechanisms = [];
                let mechanism;
                do {
                    mechanism = this.reader.cstring();
                    if (mechanism) {
                        message.mechanisms.push(mechanism);
                    }
                } while (mechanism);
                break;
            case 11: // AuthenticationSASLContinue
                message.name = 'authenticationSASLContinue';
                message.data = this.reader.string(length - 8);
                break;
            case 12: // AuthenticationSASLFinal
                message.name = 'authenticationSASLFinal';
                message.data = this.reader.string(length - 8);
                break;
            default:
                throw new Error('Unknown authenticationOk message type ' + code);
        }
        return message;
    }
    parseErrorMessage(offset, length, bytes, name) {
        this.reader.setBuffer(offset, bytes);
        const fields = {};
        let fieldType = this.reader.string(1);
        while (fieldType !== '\0') {
            fields[fieldType] = this.reader.cstring();
            fieldType = this.reader.string(1);
        }
        const messageValue = fields.M;
        const message = name === 'notice' ? new messages_1.NoticeMessage(length, messageValue) : new messages_1.DatabaseError(messageValue, length, name);
        message.severity = fields.S;
        message.code = fields.C;
        message.detail = fields.D;
        message.hint = fields.H;
        message.position = fields.P;
        message.internalPosition = fields.p;
        message.internalQuery = fields.q;
        message.where = fields.W;
        message.schema = fields.s;
        message.table = fields.t;
        message.column = fields.c;
        message.dataType = fields.d;
        message.constraint = fields.n;
        message.file = fields.F;
        message.line = fields.L;
        message.routine = fields.R;
        return message;
    }
}
exports.Parser = Parser;
//# sourceMappingURL=parser.js.map

/***/ }),

/***/ 9209:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.serialize = void 0;
const buffer_writer_1 = __webpack_require__(246);
const writer = new buffer_writer_1.Writer();
const startup = (opts) => {
    // protocol version
    writer.addInt16(3).addInt16(0);
    for (const key of Object.keys(opts)) {
        writer.addCString(key).addCString(opts[key]);
    }
    writer.addCString('client_encoding').addCString('UTF8');
    var bodyBuffer = writer.addCString('').flush();
    // this message is sent without a code
    var length = bodyBuffer.length + 4;
    return new buffer_writer_1.Writer().addInt32(length).add(bodyBuffer).flush();
};
const requestSsl = () => {
    const response = Buffer.allocUnsafe(8);
    response.writeInt32BE(8, 0);
    response.writeInt32BE(80877103, 4);
    return response;
};
const password = (password) => {
    return writer.addCString(password).flush(112 /* startup */);
};
const sendSASLInitialResponseMessage = function (mechanism, initialResponse) {
    // 0x70 = 'p'
    writer.addCString(mechanism).addInt32(Buffer.byteLength(initialResponse)).addString(initialResponse);
    return writer.flush(112 /* startup */);
};
const sendSCRAMClientFinalMessage = function (additionalData) {
    return writer.addString(additionalData).flush(112 /* startup */);
};
const query = (text) => {
    return writer.addCString(text).flush(81 /* query */);
};
const emptyArray = [];
const parse = (query) => {
    // expect something like this:
    // { name: 'queryName',
    //   text: 'select * from blah',
    //   types: ['int8', 'bool'] }
    // normalize missing query names to allow for null
    const name = query.name || '';
    if (name.length > 63) {
        /* eslint-disable no-console */
        console.error('Warning! Postgres only supports 63 characters for query names.');
        console.error('You supplied %s (%s)', name, name.length);
        console.error('This can cause conflicts and silent errors executing queries');
        /* eslint-enable no-console */
    }
    const types = query.types || emptyArray;
    var len = types.length;
    var buffer = writer
        .addCString(name) // name of query
        .addCString(query.text) // actual query text
        .addInt16(len);
    for (var i = 0; i < len; i++) {
        buffer.addInt32(types[i]);
    }
    return writer.flush(80 /* parse */);
};
const paramWriter = new buffer_writer_1.Writer();
const writeValues = function (values, valueMapper) {
    for (let i = 0; i < values.length; i++) {
        const mappedVal = valueMapper ? valueMapper(values[i], i) : values[i];
        if (mappedVal == null) {
            // add the param type (string) to the writer
            writer.addInt16(0 /* STRING */);
            // write -1 to the param writer to indicate null
            paramWriter.addInt32(-1);
        }
        else if (mappedVal instanceof Buffer) {
            // add the param type (binary) to the writer
            writer.addInt16(1 /* BINARY */);
            // add the buffer to the param writer
            paramWriter.addInt32(mappedVal.length);
            paramWriter.add(mappedVal);
        }
        else {
            // add the param type (string) to the writer
            writer.addInt16(0 /* STRING */);
            paramWriter.addInt32(Buffer.byteLength(mappedVal));
            paramWriter.addString(mappedVal);
        }
    }
};
const bind = (config = {}) => {
    // normalize config
    const portal = config.portal || '';
    const statement = config.statement || '';
    const binary = config.binary || false;
    const values = config.values || emptyArray;
    const len = values.length;
    writer.addCString(portal).addCString(statement);
    writer.addInt16(len);
    writeValues(values, config.valueMapper);
    writer.addInt16(len);
    writer.add(paramWriter.flush());
    // format code
    writer.addInt16(binary ? 1 /* BINARY */ : 0 /* STRING */);
    return writer.flush(66 /* bind */);
};
const emptyExecute = Buffer.from([69 /* execute */, 0x00, 0x00, 0x00, 0x09, 0x00, 0x00, 0x00, 0x00, 0x00]);
const execute = (config) => {
    // this is the happy path for most queries
    if (!config || (!config.portal && !config.rows)) {
        return emptyExecute;
    }
    const portal = config.portal || '';
    const rows = config.rows || 0;
    const portalLength = Buffer.byteLength(portal);
    const len = 4 + portalLength + 1 + 4;
    // one extra bit for code
    const buff = Buffer.allocUnsafe(1 + len);
    buff[0] = 69 /* execute */;
    buff.writeInt32BE(len, 1);
    buff.write(portal, 5, 'utf-8');
    buff[portalLength + 5] = 0; // null terminate portal cString
    buff.writeUInt32BE(rows, buff.length - 4);
    return buff;
};
const cancel = (processID, secretKey) => {
    const buffer = Buffer.allocUnsafe(16);
    buffer.writeInt32BE(16, 0);
    buffer.writeInt16BE(1234, 4);
    buffer.writeInt16BE(5678, 6);
    buffer.writeInt32BE(processID, 8);
    buffer.writeInt32BE(secretKey, 12);
    return buffer;
};
const cstringMessage = (code, string) => {
    const stringLen = Buffer.byteLength(string);
    const len = 4 + stringLen + 1;
    // one extra bit for code
    const buffer = Buffer.allocUnsafe(1 + len);
    buffer[0] = code;
    buffer.writeInt32BE(len, 1);
    buffer.write(string, 5, 'utf-8');
    buffer[len] = 0; // null terminate cString
    return buffer;
};
const emptyDescribePortal = writer.addCString('P').flush(68 /* describe */);
const emptyDescribeStatement = writer.addCString('S').flush(68 /* describe */);
const describe = (msg) => {
    return msg.name
        ? cstringMessage(68 /* describe */, `${msg.type}${msg.name || ''}`)
        : msg.type === 'P'
            ? emptyDescribePortal
            : emptyDescribeStatement;
};
const close = (msg) => {
    const text = `${msg.type}${msg.name || ''}`;
    return cstringMessage(67 /* close */, text);
};
const copyData = (chunk) => {
    return writer.add(chunk).flush(100 /* copyFromChunk */);
};
const copyFail = (message) => {
    return cstringMessage(102 /* copyFail */, message);
};
const codeOnlyBuffer = (code) => Buffer.from([code, 0x00, 0x00, 0x00, 0x04]);
const flushBuffer = codeOnlyBuffer(72 /* flush */);
const syncBuffer = codeOnlyBuffer(83 /* sync */);
const endBuffer = codeOnlyBuffer(88 /* end */);
const copyDoneBuffer = codeOnlyBuffer(99 /* copyDone */);
const serialize = {
    startup,
    password,
    requestSsl,
    sendSASLInitialResponseMessage,
    sendSCRAMClientFinalMessage,
    query,
    parse,
    bind,
    execute,
    describe,
    close,
    flush: () => flushBuffer,
    sync: () => syncBuffer,
    end: () => endBuffer,
    copyData,
    copyDone: () => copyDoneBuffer,
    copyFail,
    cancel,
};
exports.serialize = serialize;
//# sourceMappingURL=serializer.js.map

/***/ }),

/***/ 3619:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var textParsers = __webpack_require__(2980);
var binaryParsers = __webpack_require__(1931);
var arrayParser = __webpack_require__(6169);
var builtinTypes = __webpack_require__(8078);

exports.getTypeParser = getTypeParser;
exports.setTypeParser = setTypeParser;
exports.arrayParser = arrayParser;
exports.builtins = builtinTypes;

var typeParsers = {
  text: {},
  binary: {}
};

//the empty parse function
function noParse (val) {
  return String(val);
};

//returns a function used to convert a specific type (specified by
//oid) into a result javascript type
//note: the oid can be obtained via the following sql query:
//SELECT oid FROM pg_type WHERE typname = 'TYPE_NAME_HERE';
function getTypeParser (oid, format) {
  format = format || 'text';
  if (!typeParsers[format]) {
    return noParse;
  }
  return typeParsers[format][oid] || noParse;
};

function setTypeParser (oid, format, parseFn) {
  if(typeof format == 'function') {
    parseFn = format;
    format = 'text';
  }
  typeParsers[format][oid] = parseFn;
};

textParsers.init(function(oid, converter) {
  typeParsers.text[oid] = converter;
});

binaryParsers.init(function(oid, converter) {
  typeParsers.binary[oid] = converter;
});


/***/ }),

/***/ 6169:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var array = __webpack_require__(7315);

module.exports = {
  create: function (source, transform) {
    return {
      parse: function() {
        return array.parse(source, transform);
      }
    };
  }
};


/***/ }),

/***/ 1931:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var parseInt64 = __webpack_require__(6064);

var parseBits = function(data, bits, offset, invert, callback) {
  offset = offset || 0;
  invert = invert || false;
  callback = callback || function(lastValue, newValue, bits) { return (lastValue * Math.pow(2, bits)) + newValue; };
  var offsetBytes = offset >> 3;

  var inv = function(value) {
    if (invert) {
      return ~value & 0xff;
    }

    return value;
  };

  // read first (maybe partial) byte
  var mask = 0xff;
  var firstBits = 8 - (offset % 8);
  if (bits < firstBits) {
    mask = (0xff << (8 - bits)) & 0xff;
    firstBits = bits;
  }

  if (offset) {
    mask = mask >> (offset % 8);
  }

  var result = 0;
  if ((offset % 8) + bits >= 8) {
    result = callback(0, inv(data[offsetBytes]) & mask, firstBits);
  }

  // read bytes
  var bytes = (bits + offset) >> 3;
  for (var i = offsetBytes + 1; i < bytes; i++) {
    result = callback(result, inv(data[i]), 8);
  }

  // bits to read, that are not a complete byte
  var lastBits = (bits + offset) % 8;
  if (lastBits > 0) {
    result = callback(result, inv(data[bytes]) >> (8 - lastBits), lastBits);
  }

  return result;
};

var parseFloatFromBits = function(data, precisionBits, exponentBits) {
  var bias = Math.pow(2, exponentBits - 1) - 1;
  var sign = parseBits(data, 1);
  var exponent = parseBits(data, exponentBits, 1);

  if (exponent === 0) {
    return 0;
  }

  // parse mantissa
  var precisionBitsCounter = 1;
  var parsePrecisionBits = function(lastValue, newValue, bits) {
    if (lastValue === 0) {
      lastValue = 1;
    }

    for (var i = 1; i <= bits; i++) {
      precisionBitsCounter /= 2;
      if ((newValue & (0x1 << (bits - i))) > 0) {
        lastValue += precisionBitsCounter;
      }
    }

    return lastValue;
  };

  var mantissa = parseBits(data, precisionBits, exponentBits + 1, false, parsePrecisionBits);

  // special cases
  if (exponent == (Math.pow(2, exponentBits + 1) - 1)) {
    if (mantissa === 0) {
      return (sign === 0) ? Infinity : -Infinity;
    }

    return NaN;
  }

  // normale number
  return ((sign === 0) ? 1 : -1) * Math.pow(2, exponent - bias) * mantissa;
};

var parseInt16 = function(value) {
  if (parseBits(value, 1) == 1) {
    return -1 * (parseBits(value, 15, 1, true) + 1);
  }

  return parseBits(value, 15, 1);
};

var parseInt32 = function(value) {
  if (parseBits(value, 1) == 1) {
    return -1 * (parseBits(value, 31, 1, true) + 1);
  }

  return parseBits(value, 31, 1);
};

var parseFloat32 = function(value) {
  return parseFloatFromBits(value, 23, 8);
};

var parseFloat64 = function(value) {
  return parseFloatFromBits(value, 52, 11);
};

var parseNumeric = function(value) {
  var sign = parseBits(value, 16, 32);
  if (sign == 0xc000) {
    return NaN;
  }

  var weight = Math.pow(10000, parseBits(value, 16, 16));
  var result = 0;

  var digits = [];
  var ndigits = parseBits(value, 16);
  for (var i = 0; i < ndigits; i++) {
    result += parseBits(value, 16, 64 + (16 * i)) * weight;
    weight /= 10000;
  }

  var scale = Math.pow(10, parseBits(value, 16, 48));
  return ((sign === 0) ? 1 : -1) * Math.round(result * scale) / scale;
};

var parseDate = function(isUTC, value) {
  var sign = parseBits(value, 1);
  var rawValue = parseBits(value, 63, 1);

  // discard usecs and shift from 2000 to 1970
  var result = new Date((((sign === 0) ? 1 : -1) * rawValue / 1000) + 946684800000);

  if (!isUTC) {
    result.setTime(result.getTime() + result.getTimezoneOffset() * 60000);
  }

  // add microseconds to the date
  result.usec = rawValue % 1000;
  result.getMicroSeconds = function() {
    return this.usec;
  };
  result.setMicroSeconds = function(value) {
    this.usec = value;
  };
  result.getUTCMicroSeconds = function() {
    return this.usec;
  };

  return result;
};

var parseArray = function(value) {
  var dim = parseBits(value, 32);

  var flags = parseBits(value, 32, 32);
  var elementType = parseBits(value, 32, 64);

  var offset = 96;
  var dims = [];
  for (var i = 0; i < dim; i++) {
    // parse dimension
    dims[i] = parseBits(value, 32, offset);
    offset += 32;

    // ignore lower bounds
    offset += 32;
  }

  var parseElement = function(elementType) {
    // parse content length
    var length = parseBits(value, 32, offset);
    offset += 32;

    // parse null values
    if (length == 0xffffffff) {
      return null;
    }

    var result;
    if ((elementType == 0x17) || (elementType == 0x14)) {
      // int/bigint
      result = parseBits(value, length * 8, offset);
      offset += length * 8;
      return result;
    }
    else if (elementType == 0x19) {
      // string
      result = value.toString(this.encoding, offset >> 3, (offset += (length << 3)) >> 3);
      return result;
    }
    else {
      console.log("ERROR: ElementType not implemented: " + elementType);
    }
  };

  var parse = function(dimension, elementType) {
    var array = [];
    var i;

    if (dimension.length > 1) {
      var count = dimension.shift();
      for (i = 0; i < count; i++) {
        array[i] = parse(dimension, elementType);
      }
      dimension.unshift(count);
    }
    else {
      for (i = 0; i < dimension[0]; i++) {
        array[i] = parseElement(elementType);
      }
    }

    return array;
  };

  return parse(dims, elementType);
};

var parseText = function(value) {
  return value.toString('utf8');
};

var parseBool = function(value) {
  if(value === null) return null;
  return (parseBits(value, 8) > 0);
};

var init = function(register) {
  register(20, parseInt64);
  register(21, parseInt16);
  register(23, parseInt32);
  register(26, parseInt32);
  register(1700, parseNumeric);
  register(700, parseFloat32);
  register(701, parseFloat64);
  register(16, parseBool);
  register(1114, parseDate.bind(null, false));
  register(1184, parseDate.bind(null, true));
  register(1000, parseArray);
  register(1007, parseArray);
  register(1016, parseArray);
  register(1008, parseArray);
  register(1009, parseArray);
  register(25, parseText);
};

module.exports = {
  init: init
};


/***/ }),

/***/ 8078:
/***/ ((module) => {

/**
 * Following query was used to generate this file:

 SELECT json_object_agg(UPPER(PT.typname), PT.oid::int4 ORDER BY pt.oid)
 FROM pg_type PT
 WHERE typnamespace = (SELECT pgn.oid FROM pg_namespace pgn WHERE nspname = 'pg_catalog') -- Take only builting Postgres types with stable OID (extension types are not guaranted to be stable)
 AND typtype = 'b' -- Only basic types
 AND typelem = 0 -- Ignore aliases
 AND typisdefined -- Ignore undefined types
 */

module.exports = {
    BOOL: 16,
    BYTEA: 17,
    CHAR: 18,
    INT8: 20,
    INT2: 21,
    INT4: 23,
    REGPROC: 24,
    TEXT: 25,
    OID: 26,
    TID: 27,
    XID: 28,
    CID: 29,
    JSON: 114,
    XML: 142,
    PG_NODE_TREE: 194,
    SMGR: 210,
    PATH: 602,
    POLYGON: 604,
    CIDR: 650,
    FLOAT4: 700,
    FLOAT8: 701,
    ABSTIME: 702,
    RELTIME: 703,
    TINTERVAL: 704,
    CIRCLE: 718,
    MACADDR8: 774,
    MONEY: 790,
    MACADDR: 829,
    INET: 869,
    ACLITEM: 1033,
    BPCHAR: 1042,
    VARCHAR: 1043,
    DATE: 1082,
    TIME: 1083,
    TIMESTAMP: 1114,
    TIMESTAMPTZ: 1184,
    INTERVAL: 1186,
    TIMETZ: 1266,
    BIT: 1560,
    VARBIT: 1562,
    NUMERIC: 1700,
    REFCURSOR: 1790,
    REGPROCEDURE: 2202,
    REGOPER: 2203,
    REGOPERATOR: 2204,
    REGCLASS: 2205,
    REGTYPE: 2206,
    UUID: 2950,
    TXID_SNAPSHOT: 2970,
    PG_LSN: 3220,
    PG_NDISTINCT: 3361,
    PG_DEPENDENCIES: 3402,
    TSVECTOR: 3614,
    TSQUERY: 3615,
    GTSVECTOR: 3642,
    REGCONFIG: 3734,
    REGDICTIONARY: 3769,
    JSONB: 3802,
    REGNAMESPACE: 4089,
    REGROLE: 4096
};


/***/ }),

/***/ 2980:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var array = __webpack_require__(7315)
var arrayParser = __webpack_require__(6169);
var parseDate = __webpack_require__(3765);
var parseInterval = __webpack_require__(1055);
var parseByteA = __webpack_require__(3712);

function allowNull (fn) {
  return function nullAllowed (value) {
    if (value === null) return value
    return fn(value)
  }
}

function parseBool (value) {
  if (value === null) return value
  return value === 'TRUE' ||
    value === 't' ||
    value === 'true' ||
    value === 'y' ||
    value === 'yes' ||
    value === 'on' ||
    value === '1';
}

function parseBoolArray (value) {
  if (!value) return null
  return array.parse(value, parseBool)
}

function parseBaseTenInt (string) {
  return parseInt(string, 10)
}

function parseIntegerArray (value) {
  if (!value) return null
  return array.parse(value, allowNull(parseBaseTenInt))
}

function parseBigIntegerArray (value) {
  if (!value) return null
  return array.parse(value, allowNull(function (entry) {
    return parseBigInteger(entry).trim()
  }))
}

var parsePointArray = function(value) {
  if(!value) { return null; }
  var p = arrayParser.create(value, function(entry) {
    if(entry !== null) {
      entry = parsePoint(entry);
    }
    return entry;
  });

  return p.parse();
};

var parseFloatArray = function(value) {
  if(!value) { return null; }
  var p = arrayParser.create(value, function(entry) {
    if(entry !== null) {
      entry = parseFloat(entry);
    }
    return entry;
  });

  return p.parse();
};

var parseStringArray = function(value) {
  if(!value) { return null; }

  var p = arrayParser.create(value);
  return p.parse();
};

var parseDateArray = function(value) {
  if (!value) { return null; }

  var p = arrayParser.create(value, function(entry) {
    if (entry !== null) {
      entry = parseDate(entry);
    }
    return entry;
  });

  return p.parse();
};

var parseIntervalArray = function(value) {
  if (!value) { return null; }

  var p = arrayParser.create(value, function(entry) {
    if (entry !== null) {
      entry = parseInterval(entry);
    }
    return entry;
  });

  return p.parse();
};

var parseByteAArray = function(value) {
  if (!value) { return null; }

  return array.parse(value, allowNull(parseByteA));
};

var parseInteger = function(value) {
  return parseInt(value, 10);
};

var parseBigInteger = function(value) {
  var valStr = String(value);
  if (/^\d+$/.test(valStr)) { return valStr; }
  return value;
};

var parseJsonArray = function(value) {
  if (!value) { return null; }

  return array.parse(value, allowNull(JSON.parse));
};

var parsePoint = function(value) {
  if (value[0] !== '(') { return null; }

  value = value.substring( 1, value.length - 1 ).split(',');

  return {
    x: parseFloat(value[0])
  , y: parseFloat(value[1])
  };
};

var parseCircle = function(value) {
  if (value[0] !== '<' && value[1] !== '(') { return null; }

  var point = '(';
  var radius = '';
  var pointParsed = false;
  for (var i = 2; i < value.length - 1; i++){
    if (!pointParsed) {
      point += value[i];
    }

    if (value[i] === ')') {
      pointParsed = true;
      continue;
    } else if (!pointParsed) {
      continue;
    }

    if (value[i] === ','){
      continue;
    }

    radius += value[i];
  }
  var result = parsePoint(point);
  result.radius = parseFloat(radius);

  return result;
};

var init = function(register) {
  register(20, parseBigInteger); // int8
  register(21, parseInteger); // int2
  register(23, parseInteger); // int4
  register(26, parseInteger); // oid
  register(700, parseFloat); // float4/real
  register(701, parseFloat); // float8/double
  register(16, parseBool);
  register(1082, parseDate); // date
  register(1114, parseDate); // timestamp without timezone
  register(1184, parseDate); // timestamp
  register(600, parsePoint); // point
  register(651, parseStringArray); // cidr[]
  register(718, parseCircle); // circle
  register(1000, parseBoolArray);
  register(1001, parseByteAArray);
  register(1005, parseIntegerArray); // _int2
  register(1007, parseIntegerArray); // _int4
  register(1028, parseIntegerArray); // oid[]
  register(1016, parseBigIntegerArray); // _int8
  register(1017, parsePointArray); // point[]
  register(1021, parseFloatArray); // _float4
  register(1022, parseFloatArray); // _float8
  register(1231, parseFloatArray); // _numeric
  register(1014, parseStringArray); //char
  register(1015, parseStringArray); //varchar
  register(1008, parseStringArray);
  register(1009, parseStringArray);
  register(1040, parseStringArray); // macaddr[]
  register(1041, parseStringArray); // inet[]
  register(1115, parseDateArray); // timestamp without time zone[]
  register(1182, parseDateArray); // _date
  register(1185, parseDateArray); // timestamp with time zone[]
  register(1186, parseInterval);
  register(1187, parseIntervalArray);
  register(17, parseByteA);
  register(114, JSON.parse.bind(JSON)); // json
  register(3802, JSON.parse.bind(JSON)); // jsonb
  register(199, parseJsonArray); // json[]
  register(3807, parseJsonArray); // jsonb[]
  register(3907, parseStringArray); // numrange[]
  register(2951, parseStringArray); // uuid[]
  register(791, parseStringArray); // money[]
  register(1183, parseStringArray); // time[]
  register(1270, parseStringArray); // timetz[]
};

module.exports = {
  init: init
};


/***/ }),

/***/ 7442:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var EventEmitter = __webpack_require__(8614).EventEmitter
var util = __webpack_require__(1669)
var utils = __webpack_require__(1262)
var sasl = __webpack_require__(4615)
var pgPass = __webpack_require__(8812)
var TypeOverrides = __webpack_require__(5701)

var ConnectionParameters = __webpack_require__(8048)
var Query = __webpack_require__(1134)
var defaults = __webpack_require__(7433)
var Connection = __webpack_require__(1964)

class Client extends EventEmitter {
  constructor(config) {
    super()

    this.connectionParameters = new ConnectionParameters(config)
    this.user = this.connectionParameters.user
    this.database = this.connectionParameters.database
    this.port = this.connectionParameters.port
    this.host = this.connectionParameters.host

    // "hiding" the password so it doesn't show up in stack traces
    // or if the client is console.logged
    Object.defineProperty(this, 'password', {
      configurable: true,
      enumerable: false,
      writable: true,
      value: this.connectionParameters.password,
    })

    this.replication = this.connectionParameters.replication

    var c = config || {}

    this._Promise = c.Promise || global.Promise
    this._types = new TypeOverrides(c.types)
    this._ending = false
    this._connecting = false
    this._connected = false
    this._connectionError = false
    this._queryable = true

    this.connection =
      c.connection ||
      new Connection({
        stream: c.stream,
        ssl: this.connectionParameters.ssl,
        keepAlive: c.keepAlive || false,
        keepAliveInitialDelayMillis: c.keepAliveInitialDelayMillis || 0,
        encoding: this.connectionParameters.client_encoding || 'utf8',
      })
    this.queryQueue = []
    this.binary = c.binary || defaults.binary
    this.processID = null
    this.secretKey = null
    this.ssl = this.connectionParameters.ssl || false
    // As with Password, make SSL->Key (the private key) non-enumerable.
    // It won't show up in stack traces
    // or if the client is console.logged
    if (this.ssl && this.ssl.key) {
      Object.defineProperty(this.ssl, 'key', {
        enumerable: false,
      })
    }

    this._connectionTimeoutMillis = c.connectionTimeoutMillis || 0
  }

  _errorAllQueries(err) {
    const enqueueError = (query) => {
      process.nextTick(() => {
        query.handleError(err, this.connection)
      })
    }

    if (this.activeQuery) {
      enqueueError(this.activeQuery)
      this.activeQuery = null
    }

    this.queryQueue.forEach(enqueueError)
    this.queryQueue.length = 0
  }

  _connect(callback) {
    var self = this
    var con = this.connection
    this._connectionCallback = callback

    if (this._connecting || this._connected) {
      const err = new Error('Client has already been connected. You cannot reuse a client.')
      process.nextTick(() => {
        callback(err)
      })
      return
    }
    this._connecting = true

    this.connectionTimeoutHandle
    if (this._connectionTimeoutMillis > 0) {
      this.connectionTimeoutHandle = setTimeout(() => {
        con._ending = true
        con.stream.destroy(new Error('timeout expired'))
      }, this._connectionTimeoutMillis)
    }

    if (this.host && this.host.indexOf('/') === 0) {
      con.connect(this.host + '/.s.PGSQL.' + this.port)
    } else {
      con.connect(this.port, this.host)
    }

    // once connection is established send startup message
    con.on('connect', function () {
      if (self.ssl) {
        con.requestSsl()
      } else {
        con.startup(self.getStartupConf())
      }
    })

    con.on('sslconnect', function () {
      con.startup(self.getStartupConf())
    })

    this._attachListeners(con)

    con.once('end', () => {
      const error = this._ending ? new Error('Connection terminated') : new Error('Connection terminated unexpectedly')

      clearTimeout(this.connectionTimeoutHandle)
      this._errorAllQueries(error)

      if (!this._ending) {
        // if the connection is ended without us calling .end()
        // on this client then we have an unexpected disconnection
        // treat this as an error unless we've already emitted an error
        // during connection.
        if (this._connecting && !this._connectionError) {
          if (this._connectionCallback) {
            this._connectionCallback(error)
          } else {
            this._handleErrorEvent(error)
          }
        } else if (!this._connectionError) {
          this._handleErrorEvent(error)
        }
      }

      process.nextTick(() => {
        this.emit('end')
      })
    })
  }

  connect(callback) {
    if (callback) {
      this._connect(callback)
      return
    }

    return new this._Promise((resolve, reject) => {
      this._connect((error) => {
        if (error) {
          reject(error)
        } else {
          resolve()
        }
      })
    })
  }

  _attachListeners(con) {
    // password request handling
    con.on('authenticationCleartextPassword', this._handleAuthCleartextPassword.bind(this))
    // password request handling
    con.on('authenticationMD5Password', this._handleAuthMD5Password.bind(this))
    // password request handling (SASL)
    con.on('authenticationSASL', this._handleAuthSASL.bind(this))
    con.on('authenticationSASLContinue', this._handleAuthSASLContinue.bind(this))
    con.on('authenticationSASLFinal', this._handleAuthSASLFinal.bind(this))
    con.on('backendKeyData', this._handleBackendKeyData.bind(this))
    con.on('error', this._handleErrorEvent.bind(this))
    con.on('errorMessage', this._handleErrorMessage.bind(this))
    con.on('readyForQuery', this._handleReadyForQuery.bind(this))
    con.on('notice', this._handleNotice.bind(this))
    con.on('rowDescription', this._handleRowDescription.bind(this))
    con.on('dataRow', this._handleDataRow.bind(this))
    con.on('portalSuspended', this._handlePortalSuspended.bind(this))
    con.on('emptyQuery', this._handleEmptyQuery.bind(this))
    con.on('commandComplete', this._handleCommandComplete.bind(this))
    con.on('parseComplete', this._handleParseComplete.bind(this))
    con.on('copyInResponse', this._handleCopyInResponse.bind(this))
    con.on('copyData', this._handleCopyData.bind(this))
    con.on('notification', this._handleNotification.bind(this))
  }

  // TODO(bmc): deprecate pgpass "built in" integration since this.password can be a function
  // it can be supplied by the user if required - this is a breaking change!
  _checkPgPass(cb) {
    const con = this.connection
    if (typeof this.password === 'function') {
      this._Promise
        .resolve()
        .then(() => this.password())
        .then((pass) => {
          if (pass !== undefined) {
            if (typeof pass !== 'string') {
              con.emit('error', new TypeError('Password must be a string'))
              return
            }
            this.connectionParameters.password = this.password = pass
          } else {
            this.connectionParameters.password = this.password = null
          }
          cb()
        })
        .catch((err) => {
          con.emit('error', err)
        })
    } else if (this.password !== null) {
      cb()
    } else {
      pgPass(this.connectionParameters, (pass) => {
        if (undefined !== pass) {
          this.connectionParameters.password = this.password = pass
        }
        cb()
      })
    }
  }

  _handleAuthCleartextPassword(msg) {
    this._checkPgPass(() => {
      this.connection.password(this.password)
    })
  }

  _handleAuthMD5Password(msg) {
    this._checkPgPass(() => {
      const hashedPassword = utils.postgresMd5PasswordHash(this.user, this.password, msg.salt)
      this.connection.password(hashedPassword)
    })
  }

  _handleAuthSASL(msg) {
    this._checkPgPass(() => {
      this.saslSession = sasl.startSession(msg.mechanisms)
      this.connection.sendSASLInitialResponseMessage(this.saslSession.mechanism, this.saslSession.response)
    })
  }

  _handleAuthSASLContinue(msg) {
    sasl.continueSession(this.saslSession, this.password, msg.data)
    this.connection.sendSCRAMClientFinalMessage(this.saslSession.response)
  }

  _handleAuthSASLFinal(msg) {
    sasl.finalizeSession(this.saslSession, msg.data)
    this.saslSession = null
  }

  _handleBackendKeyData(msg) {
    this.processID = msg.processID
    this.secretKey = msg.secretKey
  }

  _handleReadyForQuery(msg) {
    if (this._connecting) {
      this._connecting = false
      this._connected = true
      clearTimeout(this.connectionTimeoutHandle)

      // process possible callback argument to Client#connect
      if (this._connectionCallback) {
        this._connectionCallback(null, this)
        // remove callback for proper error handling
        // after the connect event
        this._connectionCallback = null
      }
      this.emit('connect')
    }
    const { activeQuery } = this
    this.activeQuery = null
    this.readyForQuery = true
    if (activeQuery) {
      activeQuery.handleReadyForQuery(this.connection)
    }
    this._pulseQueryQueue()
  }

  // if we receieve an error event or error message
  // during the connection process we handle it here
  _handleErrorWhileConnecting(err) {
    if (this._connectionError) {
      // TODO(bmc): this is swallowing errors - we shouldn't do this
      return
    }
    this._connectionError = true
    clearTimeout(this.connectionTimeoutHandle)
    if (this._connectionCallback) {
      return this._connectionCallback(err)
    }
    this.emit('error', err)
  }

  // if we're connected and we receive an error event from the connection
  // this means the socket is dead - do a hard abort of all queries and emit
  // the socket error on the client as well
  _handleErrorEvent(err) {
    if (this._connecting) {
      return this._handleErrorWhileConnecting(err)
    }
    this._queryable = false
    this._errorAllQueries(err)
    this.emit('error', err)
  }

  // handle error messages from the postgres backend
  _handleErrorMessage(msg) {
    if (this._connecting) {
      return this._handleErrorWhileConnecting(msg)
    }
    const activeQuery = this.activeQuery

    if (!activeQuery) {
      this._handleErrorEvent(msg)
      return
    }

    this.activeQuery = null
    activeQuery.handleError(msg, this.connection)
  }

  _handleRowDescription(msg) {
    // delegate rowDescription to active query
    this.activeQuery.handleRowDescription(msg)
  }

  _handleDataRow(msg) {
    // delegate dataRow to active query
    this.activeQuery.handleDataRow(msg)
  }

  _handlePortalSuspended(msg) {
    // delegate portalSuspended to active query
    this.activeQuery.handlePortalSuspended(this.connection)
  }

  _handleEmptyQuery(msg) {
    // delegate emptyQuery to active query
    this.activeQuery.handleEmptyQuery(this.connection)
  }

  _handleCommandComplete(msg) {
    // delegate commandComplete to active query
    this.activeQuery.handleCommandComplete(msg, this.connection)
  }

  _handleParseComplete(msg) {
    // if a prepared statement has a name and properly parses
    // we track that its already been executed so we don't parse
    // it again on the same client
    if (this.activeQuery.name) {
      this.connection.parsedStatements[this.activeQuery.name] = this.activeQuery.text
    }
  }

  _handleCopyInResponse(msg) {
    this.activeQuery.handleCopyInResponse(this.connection)
  }

  _handleCopyData(msg) {
    this.activeQuery.handleCopyData(msg, this.connection)
  }

  _handleNotification(msg) {
    this.emit('notification', msg)
  }

  _handleNotice(msg) {
    this.emit('notice', msg)
  }

  getStartupConf() {
    var params = this.connectionParameters

    var data = {
      user: params.user,
      database: params.database,
    }

    var appName = params.application_name || params.fallback_application_name
    if (appName) {
      data.application_name = appName
    }
    if (params.replication) {
      data.replication = '' + params.replication
    }
    if (params.statement_timeout) {
      data.statement_timeout = String(parseInt(params.statement_timeout, 10))
    }
    if (params.idle_in_transaction_session_timeout) {
      data.idle_in_transaction_session_timeout = String(parseInt(params.idle_in_transaction_session_timeout, 10))
    }
    if (params.options) {
      data.options = params.options
    }

    return data
  }

  cancel(client, query) {
    if (client.activeQuery === query) {
      var con = this.connection

      if (this.host && this.host.indexOf('/') === 0) {
        con.connect(this.host + '/.s.PGSQL.' + this.port)
      } else {
        con.connect(this.port, this.host)
      }

      // once connection is established send cancel message
      con.on('connect', function () {
        con.cancel(client.processID, client.secretKey)
      })
    } else if (client.queryQueue.indexOf(query) !== -1) {
      client.queryQueue.splice(client.queryQueue.indexOf(query), 1)
    }
  }

  setTypeParser(oid, format, parseFn) {
    return this._types.setTypeParser(oid, format, parseFn)
  }

  getTypeParser(oid, format) {
    return this._types.getTypeParser(oid, format)
  }

  // Ported from PostgreSQL 9.2.4 source code in src/interfaces/libpq/fe-exec.c
  escapeIdentifier(str) {
    return '"' + str.replace(/"/g, '""') + '"'
  }

  // Ported from PostgreSQL 9.2.4 source code in src/interfaces/libpq/fe-exec.c
  escapeLiteral(str) {
    var hasBackslash = false
    var escaped = "'"

    for (var i = 0; i < str.length; i++) {
      var c = str[i]
      if (c === "'") {
        escaped += c + c
      } else if (c === '\\') {
        escaped += c + c
        hasBackslash = true
      } else {
        escaped += c
      }
    }

    escaped += "'"

    if (hasBackslash === true) {
      escaped = ' E' + escaped
    }

    return escaped
  }

  _pulseQueryQueue() {
    if (this.readyForQuery === true) {
      this.activeQuery = this.queryQueue.shift()
      if (this.activeQuery) {
        this.readyForQuery = false
        this.hasExecuted = true

        const queryError = this.activeQuery.submit(this.connection)
        if (queryError) {
          process.nextTick(() => {
            this.activeQuery.handleError(queryError, this.connection)
            this.readyForQuery = true
            this._pulseQueryQueue()
          })
        }
      } else if (this.hasExecuted) {
        this.activeQuery = null
        this.emit('drain')
      }
    }
  }

  query(config, values, callback) {
    // can take in strings, config object or query object
    var query
    var result
    var readTimeout
    var readTimeoutTimer
    var queryCallback

    if (config === null || config === undefined) {
      throw new TypeError('Client was passed a null or undefined query')
    } else if (typeof config.submit === 'function') {
      readTimeout = config.query_timeout || this.connectionParameters.query_timeout
      result = query = config
      if (typeof values === 'function') {
        query.callback = query.callback || values
      }
    } else {
      readTimeout = this.connectionParameters.query_timeout
      query = new Query(config, values, callback)
      if (!query.callback) {
        result = new this._Promise((resolve, reject) => {
          query.callback = (err, res) => (err ? reject(err) : resolve(res))
        })
      }
    }

    if (readTimeout) {
      queryCallback = query.callback

      readTimeoutTimer = setTimeout(() => {
        var error = new Error('Query read timeout')

        process.nextTick(() => {
          query.handleError(error, this.connection)
        })

        queryCallback(error)

        // we already returned an error,
        // just do nothing if query completes
        query.callback = () => {}

        // Remove from queue
        var index = this.queryQueue.indexOf(query)
        if (index > -1) {
          this.queryQueue.splice(index, 1)
        }

        this._pulseQueryQueue()
      }, readTimeout)

      query.callback = (err, res) => {
        clearTimeout(readTimeoutTimer)
        queryCallback(err, res)
      }
    }

    if (this.binary && !query.binary) {
      query.binary = true
    }

    if (query._result && !query._result._types) {
      query._result._types = this._types
    }

    if (!this._queryable) {
      process.nextTick(() => {
        query.handleError(new Error('Client has encountered a connection error and is not queryable'), this.connection)
      })
      return result
    }

    if (this._ending) {
      process.nextTick(() => {
        query.handleError(new Error('Client was closed and is not queryable'), this.connection)
      })
      return result
    }

    this.queryQueue.push(query)
    this._pulseQueryQueue()
    return result
  }

  ref() {
    this.connection.ref()
  }

  unref() {
    this.connection.unref()
  }

  end(cb) {
    this._ending = true

    // if we have never connected, then end is a noop, callback immediately
    if (!this.connection._connecting) {
      if (cb) {
        cb()
      } else {
        return this._Promise.resolve()
      }
    }

    if (this.activeQuery || !this._queryable) {
      // if we have an active query we need to force a disconnect
      // on the socket - otherwise a hung query could block end forever
      this.connection.stream.destroy()
    } else {
      this.connection.end()
    }

    if (cb) {
      this.connection.once('end', cb)
    } else {
      return new this._Promise((resolve) => {
        this.connection.once('end', resolve)
      })
    }
  }
}

// expose a Query constructor
Client.Query = Query

module.exports = Client


/***/ }),

/***/ 8048:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var dns = __webpack_require__(881)

var defaults = __webpack_require__(7433)

var parse = __webpack_require__(5697).parse // parses a connection string

var val = function (key, config, envVar) {
  if (envVar === undefined) {
    envVar = process.env['PG' + key.toUpperCase()]
  } else if (envVar === false) {
    // do nothing ... use false
  } else {
    envVar = process.env[envVar]
  }

  return config[key] || envVar || defaults[key]
}

var readSSLConfigFromEnvironment = function () {
  switch (process.env.PGSSLMODE) {
    case 'disable':
      return false
    case 'prefer':
    case 'require':
    case 'verify-ca':
    case 'verify-full':
      return true
    case 'no-verify':
      return { rejectUnauthorized: false }
  }
  return defaults.ssl
}

// Convert arg to a string, surround in single quotes, and escape single quotes and backslashes
var quoteParamValue = function (value) {
  return "'" + ('' + value).replace(/\\/g, '\\\\').replace(/'/g, "\\'") + "'"
}

var add = function (params, config, paramName) {
  var value = config[paramName]
  if (value !== undefined && value !== null) {
    params.push(paramName + '=' + quoteParamValue(value))
  }
}

class ConnectionParameters {
  constructor(config) {
    // if a string is passed, it is a raw connection string so we parse it into a config
    config = typeof config === 'string' ? parse(config) : config || {}

    // if the config has a connectionString defined, parse IT into the config we use
    // this will override other default values with what is stored in connectionString
    if (config.connectionString) {
      config = Object.assign({}, config, parse(config.connectionString))
    }

    this.user = val('user', config)
    this.database = val('database', config)

    if (this.database === undefined) {
      this.database = this.user
    }

    this.port = parseInt(val('port', config), 10)
    this.host = val('host', config)

    // "hiding" the password so it doesn't show up in stack traces
    // or if the client is console.logged
    Object.defineProperty(this, 'password', {
      configurable: true,
      enumerable: false,
      writable: true,
      value: val('password', config),
    })

    this.binary = val('binary', config)
    this.options = val('options', config)

    this.ssl = typeof config.ssl === 'undefined' ? readSSLConfigFromEnvironment() : config.ssl

    if (typeof this.ssl === 'string') {
      if (this.ssl === 'true') {
        this.ssl = true
      }
    }
    // support passing in ssl=no-verify via connection string
    if (this.ssl === 'no-verify') {
      this.ssl = { rejectUnauthorized: false }
    }
    if (this.ssl && this.ssl.key) {
      Object.defineProperty(this.ssl, 'key', {
        enumerable: false,
      })
    }

    this.client_encoding = val('client_encoding', config)
    this.replication = val('replication', config)
    // a domain socket begins with '/'
    this.isDomainSocket = !(this.host || '').indexOf('/')

    this.application_name = val('application_name', config, 'PGAPPNAME')
    this.fallback_application_name = val('fallback_application_name', config, false)
    this.statement_timeout = val('statement_timeout', config, false)
    this.idle_in_transaction_session_timeout = val('idle_in_transaction_session_timeout', config, false)
    this.query_timeout = val('query_timeout', config, false)

    if (config.connectionTimeoutMillis === undefined) {
      this.connect_timeout = process.env.PGCONNECT_TIMEOUT || 0
    } else {
      this.connect_timeout = Math.floor(config.connectionTimeoutMillis / 1000)
    }

    if (config.keepAlive === false) {
      this.keepalives = 0
    } else if (config.keepAlive === true) {
      this.keepalives = 1
    }

    if (typeof config.keepAliveInitialDelayMillis === 'number') {
      this.keepalives_idle = Math.floor(config.keepAliveInitialDelayMillis / 1000)
    }
  }

  getLibpqConnectionString(cb) {
    var params = []
    add(params, this, 'user')
    add(params, this, 'password')
    add(params, this, 'port')
    add(params, this, 'application_name')
    add(params, this, 'fallback_application_name')
    add(params, this, 'connect_timeout')
    add(params, this, 'options')

    var ssl = typeof this.ssl === 'object' ? this.ssl : this.ssl ? { sslmode: this.ssl } : {}
    add(params, ssl, 'sslmode')
    add(params, ssl, 'sslca')
    add(params, ssl, 'sslkey')
    add(params, ssl, 'sslcert')
    add(params, ssl, 'sslrootcert')

    if (this.database) {
      params.push('dbname=' + quoteParamValue(this.database))
    }
    if (this.replication) {
      params.push('replication=' + quoteParamValue(this.replication))
    }
    if (this.host) {
      params.push('host=' + quoteParamValue(this.host))
    }
    if (this.isDomainSocket) {
      return cb(null, params.join(' '))
    }
    if (this.client_encoding) {
      params.push('client_encoding=' + quoteParamValue(this.client_encoding))
    }
    dns.lookup(this.host, function (err, address) {
      if (err) return cb(err, null)
      params.push('hostaddr=' + quoteParamValue(address))
      return cb(null, params.join(' '))
    })
  }
}

module.exports = ConnectionParameters


/***/ }),

/***/ 1964:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var net = __webpack_require__(1631)
var EventEmitter = __webpack_require__(8614).EventEmitter

const { parse, serialize } = __webpack_require__(8152)

const flushBuffer = serialize.flush()
const syncBuffer = serialize.sync()
const endBuffer = serialize.end()

// TODO(bmc) support binary mode at some point
class Connection extends EventEmitter {
  constructor(config) {
    super()
    config = config || {}
    this.stream = config.stream || new net.Socket()
    this._keepAlive = config.keepAlive
    this._keepAliveInitialDelayMillis = config.keepAliveInitialDelayMillis
    this.lastBuffer = false
    this.parsedStatements = {}
    this.ssl = config.ssl || false
    this._ending = false
    this._emitMessage = false
    var self = this
    this.on('newListener', function (eventName) {
      if (eventName === 'message') {
        self._emitMessage = true
      }
    })
  }

  connect(port, host) {
    var self = this

    this._connecting = true
    this.stream.setNoDelay(true)
    this.stream.connect(port, host)

    this.stream.once('connect', function () {
      if (self._keepAlive) {
        self.stream.setKeepAlive(true, self._keepAliveInitialDelayMillis)
      }
      self.emit('connect')
    })

    const reportStreamError = function (error) {
      // errors about disconnections should be ignored during disconnect
      if (self._ending && (error.code === 'ECONNRESET' || error.code === 'EPIPE')) {
        return
      }
      self.emit('error', error)
    }
    this.stream.on('error', reportStreamError)

    this.stream.on('close', function () {
      self.emit('end')
    })

    if (!this.ssl) {
      return this.attachListeners(this.stream)
    }

    this.stream.once('data', function (buffer) {
      var responseCode = buffer.toString('utf8')
      switch (responseCode) {
        case 'S': // Server supports SSL connections, continue with a secure connection
          break
        case 'N': // Server does not support SSL connections
          self.stream.end()
          return self.emit('error', new Error('The server does not support SSL connections'))
        default:
          // Any other response byte, including 'E' (ErrorResponse) indicating a server error
          self.stream.end()
          return self.emit('error', new Error('There was an error establishing an SSL connection'))
      }
      var tls = __webpack_require__(4016)
      const options = {
        socket: self.stream,
      }

      if (self.ssl !== true) {
        Object.assign(options, self.ssl)

        if ('key' in self.ssl) {
          options.key = self.ssl.key
        }
      }

      if (net.isIP(host) === 0) {
        options.servername = host
      }
      try {
        self.stream = tls.connect(options)
      } catch (err) {
        return self.emit('error', err)
      }
      self.attachListeners(self.stream)
      self.stream.on('error', reportStreamError)

      self.emit('sslconnect')
    })
  }

  attachListeners(stream) {
    stream.on('end', () => {
      this.emit('end')
    })
    parse(stream, (msg) => {
      var eventName = msg.name === 'error' ? 'errorMessage' : msg.name
      if (this._emitMessage) {
        this.emit('message', msg)
      }
      this.emit(eventName, msg)
    })
  }

  requestSsl() {
    this.stream.write(serialize.requestSsl())
  }

  startup(config) {
    this.stream.write(serialize.startup(config))
  }

  cancel(processID, secretKey) {
    this._send(serialize.cancel(processID, secretKey))
  }

  password(password) {
    this._send(serialize.password(password))
  }

  sendSASLInitialResponseMessage(mechanism, initialResponse) {
    this._send(serialize.sendSASLInitialResponseMessage(mechanism, initialResponse))
  }

  sendSCRAMClientFinalMessage(additionalData) {
    this._send(serialize.sendSCRAMClientFinalMessage(additionalData))
  }

  _send(buffer) {
    if (!this.stream.writable) {
      return false
    }
    return this.stream.write(buffer)
  }

  query(text) {
    this._send(serialize.query(text))
  }

  // send parse message
  parse(query) {
    this._send(serialize.parse(query))
  }

  // send bind message
  bind(config) {
    this._send(serialize.bind(config))
  }

  // send execute message
  execute(config) {
    this._send(serialize.execute(config))
  }

  flush() {
    if (this.stream.writable) {
      this.stream.write(flushBuffer)
    }
  }

  sync() {
    this._ending = true
    this._send(flushBuffer)
    this._send(syncBuffer)
  }

  ref() {
    this.stream.ref()
  }

  unref() {
    this.stream.unref()
  }

  end() {
    // 0x58 = 'X'
    this._ending = true
    if (!this._connecting || !this.stream.writable) {
      this.stream.end()
      return
    }
    return this.stream.write(endBuffer, () => {
      this.stream.end()
    })
  }

  close(msg) {
    this._send(serialize.close(msg))
  }

  describe(msg) {
    this._send(serialize.describe(msg))
  }

  sendCopyFromChunk(chunk) {
    this._send(serialize.copyData(chunk))
  }

  endCopyFrom() {
    this._send(serialize.copyDone())
  }

  sendCopyFail(msg) {
    this._send(serialize.copyFail(msg))
  }
}

module.exports = Connection


/***/ }),

/***/ 7433:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


module.exports = {
  // database host. defaults to localhost
  host: 'localhost',

  // database user's name
  user: process.platform === 'win32' ? process.env.USERNAME : process.env.USER,

  // name of database to connect
  database: undefined,

  // database user's password
  password: null,

  // a Postgres connection string to be used instead of setting individual connection items
  // NOTE:  Setting this value will cause it to override any other value (such as database or user) defined
  // in the defaults object.
  connectionString: undefined,

  // database port
  port: 5432,

  // number of rows to return at a time from a prepared statement's
  // portal. 0 will return all rows at once
  rows: 0,

  // binary result mode
  binary: false,

  // Connection pool options - see https://github.com/brianc/node-pg-pool

  // number of connections to use in connection pool
  // 0 will disable connection pooling
  max: 10,

  // max milliseconds a client can go unused before it is removed
  // from the pool and destroyed
  idleTimeoutMillis: 30000,

  client_encoding: '',

  ssl: false,

  application_name: undefined,

  fallback_application_name: undefined,

  options: undefined,

  parseInputDatesAsUTC: false,

  // max milliseconds any query using this connection will execute for before timing out in error.
  // false=unlimited
  statement_timeout: false,

  // Terminate any session with an open transaction that has been idle for longer than the specified duration in milliseconds
  // false=unlimited
  idle_in_transaction_session_timeout: false,

  // max milliseconds to wait for query to complete (client side)
  query_timeout: false,

  connect_timeout: 0,

  keepalives: 1,

  keepalives_idle: 0,
}

var pgTypes = __webpack_require__(3619)
// save default parsers
var parseBigInteger = pgTypes.getTypeParser(20, 'text')
var parseBigIntegerArray = pgTypes.getTypeParser(1016, 'text')

// parse int8 so you can get your count values as actual numbers
module.exports.__defineSetter__('parseInt8', function (val) {
  pgTypes.setTypeParser(20, 'text', val ? pgTypes.getTypeParser(23, 'text') : parseBigInteger)
  pgTypes.setTypeParser(1016, 'text', val ? pgTypes.getTypeParser(1007, 'text') : parseBigIntegerArray)
})


/***/ }),

/***/ 8955:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var Client = __webpack_require__(7442)
var defaults = __webpack_require__(7433)
var Connection = __webpack_require__(1964)
var Pool = __webpack_require__(5546)
const { DatabaseError } = __webpack_require__(8152)

const poolFactory = (Client) => {
  return class BoundPool extends Pool {
    constructor(options) {
      super(options, Client)
    }
  }
}

var PG = function (clientConstructor) {
  this.defaults = defaults
  this.Client = clientConstructor
  this.Query = this.Client.Query
  this.Pool = poolFactory(this.Client)
  this._pools = []
  this.Connection = Connection
  this.types = __webpack_require__(3619)
  this.DatabaseError = DatabaseError
}

if (typeof process.env.NODE_PG_FORCE_NATIVE !== 'undefined') {
  module.exports = new PG(__webpack_require__(6221))
} else {
  module.exports = new PG(Client)

  // lazy require native module...the native module may not have installed
  Object.defineProperty(module.exports, "native", ({
    configurable: true,
    enumerable: false,
    get() {
      var native = null
      try {
        native = new PG(__webpack_require__(6221))
      } catch (err) {
        if (err.code !== 'MODULE_NOT_FOUND') {
          throw err
        }
      }

      // overwrite module.exports.native so that getter is never called again
      Object.defineProperty(module.exports, "native", ({
        value: native,
      }))

      return native
    },
  }))
}


/***/ }),

/***/ 6033:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// eslint-disable-next-line
var Native = __webpack_require__(Object(function webpackMissingModule() { var e = new Error("Cannot find module 'pg-native'"); e.code = 'MODULE_NOT_FOUND'; throw e; }()))
var TypeOverrides = __webpack_require__(5701)
var pkg = __webpack_require__(2466)
var EventEmitter = __webpack_require__(8614).EventEmitter
var util = __webpack_require__(1669)
var ConnectionParameters = __webpack_require__(8048)

var NativeQuery = __webpack_require__(7839)

var Client = (module.exports = function (config) {
  EventEmitter.call(this)
  config = config || {}

  this._Promise = config.Promise || global.Promise
  this._types = new TypeOverrides(config.types)

  this.native = new Native({
    types: this._types,
  })

  this._queryQueue = []
  this._ending = false
  this._connecting = false
  this._connected = false
  this._queryable = true

  // keep these on the object for legacy reasons
  // for the time being. TODO: deprecate all this jazz
  var cp = (this.connectionParameters = new ConnectionParameters(config))
  this.user = cp.user

  // "hiding" the password so it doesn't show up in stack traces
  // or if the client is console.logged
  Object.defineProperty(this, 'password', {
    configurable: true,
    enumerable: false,
    writable: true,
    value: cp.password,
  })
  this.database = cp.database
  this.host = cp.host
  this.port = cp.port

  // a hash to hold named queries
  this.namedQueries = {}
})

Client.Query = NativeQuery

util.inherits(Client, EventEmitter)

Client.prototype._errorAllQueries = function (err) {
  const enqueueError = (query) => {
    process.nextTick(() => {
      query.native = this.native
      query.handleError(err)
    })
  }

  if (this._hasActiveQuery()) {
    enqueueError(this._activeQuery)
    this._activeQuery = null
  }

  this._queryQueue.forEach(enqueueError)
  this._queryQueue.length = 0
}

// connect to the backend
// pass an optional callback to be called once connected
// or with an error if there was a connection error
Client.prototype._connect = function (cb) {
  var self = this

  if (this._connecting) {
    process.nextTick(() => cb(new Error('Client has already been connected. You cannot reuse a client.')))
    return
  }

  this._connecting = true

  this.connectionParameters.getLibpqConnectionString(function (err, conString) {
    if (err) return cb(err)
    self.native.connect(conString, function (err) {
      if (err) {
        self.native.end()
        return cb(err)
      }

      // set internal states to connected
      self._connected = true

      // handle connection errors from the native layer
      self.native.on('error', function (err) {
        self._queryable = false
        self._errorAllQueries(err)
        self.emit('error', err)
      })

      self.native.on('notification', function (msg) {
        self.emit('notification', {
          channel: msg.relname,
          payload: msg.extra,
        })
      })

      // signal we are connected now
      self.emit('connect')
      self._pulseQueryQueue(true)

      cb()
    })
  })
}

Client.prototype.connect = function (callback) {
  if (callback) {
    this._connect(callback)
    return
  }

  return new this._Promise((resolve, reject) => {
    this._connect((error) => {
      if (error) {
        reject(error)
      } else {
        resolve()
      }
    })
  })
}

// send a query to the server
// this method is highly overloaded to take
// 1) string query, optional array of parameters, optional function callback
// 2) object query with {
//    string query
//    optional array values,
//    optional function callback instead of as a separate parameter
//    optional string name to name & cache the query plan
//    optional string rowMode = 'array' for an array of results
//  }
Client.prototype.query = function (config, values, callback) {
  var query
  var result
  var readTimeout
  var readTimeoutTimer
  var queryCallback

  if (config === null || config === undefined) {
    throw new TypeError('Client was passed a null or undefined query')
  } else if (typeof config.submit === 'function') {
    readTimeout = config.query_timeout || this.connectionParameters.query_timeout
    result = query = config
    // accept query(new Query(...), (err, res) => { }) style
    if (typeof values === 'function') {
      config.callback = values
    }
  } else {
    readTimeout = this.connectionParameters.query_timeout
    query = new NativeQuery(config, values, callback)
    if (!query.callback) {
      let resolveOut, rejectOut
      result = new this._Promise((resolve, reject) => {
        resolveOut = resolve
        rejectOut = reject
      })
      query.callback = (err, res) => (err ? rejectOut(err) : resolveOut(res))
    }
  }

  if (readTimeout) {
    queryCallback = query.callback

    readTimeoutTimer = setTimeout(() => {
      var error = new Error('Query read timeout')

      process.nextTick(() => {
        query.handleError(error, this.connection)
      })

      queryCallback(error)

      // we already returned an error,
      // just do nothing if query completes
      query.callback = () => {}

      // Remove from queue
      var index = this._queryQueue.indexOf(query)
      if (index > -1) {
        this._queryQueue.splice(index, 1)
      }

      this._pulseQueryQueue()
    }, readTimeout)

    query.callback = (err, res) => {
      clearTimeout(readTimeoutTimer)
      queryCallback(err, res)
    }
  }

  if (!this._queryable) {
    query.native = this.native
    process.nextTick(() => {
      query.handleError(new Error('Client has encountered a connection error and is not queryable'))
    })
    return result
  }

  if (this._ending) {
    query.native = this.native
    process.nextTick(() => {
      query.handleError(new Error('Client was closed and is not queryable'))
    })
    return result
  }

  this._queryQueue.push(query)
  this._pulseQueryQueue()
  return result
}

// disconnect from the backend server
Client.prototype.end = function (cb) {
  var self = this

  this._ending = true

  if (!this._connected) {
    this.once('connect', this.end.bind(this, cb))
  }
  var result
  if (!cb) {
    result = new this._Promise(function (resolve, reject) {
      cb = (err) => (err ? reject(err) : resolve())
    })
  }
  this.native.end(function () {
    self._errorAllQueries(new Error('Connection terminated'))

    process.nextTick(() => {
      self.emit('end')
      if (cb) cb()
    })
  })
  return result
}

Client.prototype._hasActiveQuery = function () {
  return this._activeQuery && this._activeQuery.state !== 'error' && this._activeQuery.state !== 'end'
}

Client.prototype._pulseQueryQueue = function (initialConnection) {
  if (!this._connected) {
    return
  }
  if (this._hasActiveQuery()) {
    return
  }
  var query = this._queryQueue.shift()
  if (!query) {
    if (!initialConnection) {
      this.emit('drain')
    }
    return
  }
  this._activeQuery = query
  query.submit(this)
  var self = this
  query.once('_done', function () {
    self._pulseQueryQueue()
  })
}

// attempt to cancel an in-progress query
Client.prototype.cancel = function (query) {
  if (this._activeQuery === query) {
    this.native.cancel(function () {})
  } else if (this._queryQueue.indexOf(query) !== -1) {
    this._queryQueue.splice(this._queryQueue.indexOf(query), 1)
  }
}

Client.prototype.ref = function () {}
Client.prototype.unref = function () {}

Client.prototype.setTypeParser = function (oid, format, parseFn) {
  return this._types.setTypeParser(oid, format, parseFn)
}

Client.prototype.getTypeParser = function (oid, format) {
  return this._types.getTypeParser(oid, format)
}


/***/ }),

/***/ 6221:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

module.exports = __webpack_require__(6033)


/***/ }),

/***/ 7839:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var EventEmitter = __webpack_require__(8614).EventEmitter
var util = __webpack_require__(1669)
var utils = __webpack_require__(1262)

var NativeQuery = (module.exports = function (config, values, callback) {
  EventEmitter.call(this)
  config = utils.normalizeQueryConfig(config, values, callback)
  this.text = config.text
  this.values = config.values
  this.name = config.name
  this.callback = config.callback
  this.state = 'new'
  this._arrayMode = config.rowMode === 'array'

  // if the 'row' event is listened for
  // then emit them as they come in
  // without setting singleRowMode to true
  // this has almost no meaning because libpq
  // reads all rows into memory befor returning any
  this._emitRowEvents = false
  this.on(
    'newListener',
    function (event) {
      if (event === 'row') this._emitRowEvents = true
    }.bind(this)
  )
})

util.inherits(NativeQuery, EventEmitter)

var errorFieldMap = {
  /* eslint-disable quote-props */
  sqlState: 'code',
  statementPosition: 'position',
  messagePrimary: 'message',
  context: 'where',
  schemaName: 'schema',
  tableName: 'table',
  columnName: 'column',
  dataTypeName: 'dataType',
  constraintName: 'constraint',
  sourceFile: 'file',
  sourceLine: 'line',
  sourceFunction: 'routine',
}

NativeQuery.prototype.handleError = function (err) {
  // copy pq error fields into the error object
  var fields = this.native.pq.resultErrorFields()
  if (fields) {
    for (var key in fields) {
      var normalizedFieldName = errorFieldMap[key] || key
      err[normalizedFieldName] = fields[key]
    }
  }
  if (this.callback) {
    this.callback(err)
  } else {
    this.emit('error', err)
  }
  this.state = 'error'
}

NativeQuery.prototype.then = function (onSuccess, onFailure) {
  return this._getPromise().then(onSuccess, onFailure)
}

NativeQuery.prototype.catch = function (callback) {
  return this._getPromise().catch(callback)
}

NativeQuery.prototype._getPromise = function () {
  if (this._promise) return this._promise
  this._promise = new Promise(
    function (resolve, reject) {
      this._once('end', resolve)
      this._once('error', reject)
    }.bind(this)
  )
  return this._promise
}

NativeQuery.prototype.submit = function (client) {
  this.state = 'running'
  var self = this
  this.native = client.native
  client.native.arrayMode = this._arrayMode

  var after = function (err, rows, results) {
    client.native.arrayMode = false
    setImmediate(function () {
      self.emit('_done')
    })

    // handle possible query error
    if (err) {
      return self.handleError(err)
    }

    // emit row events for each row in the result
    if (self._emitRowEvents) {
      if (results.length > 1) {
        rows.forEach((rowOfRows, i) => {
          rowOfRows.forEach((row) => {
            self.emit('row', row, results[i])
          })
        })
      } else {
        rows.forEach(function (row) {
          self.emit('row', row, results)
        })
      }
    }

    // handle successful result
    self.state = 'end'
    self.emit('end', results)
    if (self.callback) {
      self.callback(null, results)
    }
  }

  if (process.domain) {
    after = process.domain.bind(after)
  }

  // named query
  if (this.name) {
    if (this.name.length > 63) {
      /* eslint-disable no-console */
      console.error('Warning! Postgres only supports 63 characters for query names.')
      console.error('You supplied %s (%s)', this.name, this.name.length)
      console.error('This can cause conflicts and silent errors executing queries')
      /* eslint-enable no-console */
    }
    var values = (this.values || []).map(utils.prepareValue)

    // check if the client has already executed this named query
    // if so...just execute it again - skip the planning phase
    if (client.namedQueries[this.name]) {
      if (this.text && client.namedQueries[this.name] !== this.text) {
        const err = new Error(`Prepared statements must be unique - '${this.name}' was used for a different statement`)
        return after(err)
      }
      return client.native.execute(this.name, values, after)
    }
    // plan the named query the first time, then execute it
    return client.native.prepare(this.name, this.text, values.length, function (err) {
      if (err) return after(err)
      client.namedQueries[self.name] = self.text
      return self.native.execute(self.name, values, after)
    })
  } else if (this.values) {
    if (!Array.isArray(this.values)) {
      const err = new Error('Query values must be an array')
      return after(err)
    }
    var vals = this.values.map(utils.prepareValue)
    client.native.query(this.text, vals, after)
  } else {
    client.native.query(this.text, after)
  }
}


/***/ }),

/***/ 1134:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


const { EventEmitter } = __webpack_require__(8614)

const Result = __webpack_require__(3758)
const utils = __webpack_require__(1262)

class Query extends EventEmitter {
  constructor(config, values, callback) {
    super()

    config = utils.normalizeQueryConfig(config, values, callback)

    this.text = config.text
    this.values = config.values
    this.rows = config.rows
    this.types = config.types
    this.name = config.name
    this.binary = config.binary
    // use unique portal name each time
    this.portal = config.portal || ''
    this.callback = config.callback
    this._rowMode = config.rowMode
    if (process.domain && config.callback) {
      this.callback = process.domain.bind(config.callback)
    }
    this._result = new Result(this._rowMode, this.types)

    // potential for multiple results
    this._results = this._result
    this.isPreparedStatement = false
    this._canceledDueToError = false
    this._promise = null
  }

  requiresPreparation() {
    // named queries must always be prepared
    if (this.name) {
      return true
    }
    // always prepare if there are max number of rows expected per
    // portal execution
    if (this.rows) {
      return true
    }
    // don't prepare empty text queries
    if (!this.text) {
      return false
    }
    // prepare if there are values
    if (!this.values) {
      return false
    }
    return this.values.length > 0
  }

  _checkForMultirow() {
    // if we already have a result with a command property
    // then we've already executed one query in a multi-statement simple query
    // turn our results into an array of results
    if (this._result.command) {
      if (!Array.isArray(this._results)) {
        this._results = [this._result]
      }
      this._result = new Result(this._rowMode, this.types)
      this._results.push(this._result)
    }
  }

  // associates row metadata from the supplied
  // message with this query object
  // metadata used when parsing row results
  handleRowDescription(msg) {
    this._checkForMultirow()
    this._result.addFields(msg.fields)
    this._accumulateRows = this.callback || !this.listeners('row').length
  }

  handleDataRow(msg) {
    let row

    if (this._canceledDueToError) {
      return
    }

    try {
      row = this._result.parseRow(msg.fields)
    } catch (err) {
      this._canceledDueToError = err
      return
    }

    this.emit('row', row, this._result)
    if (this._accumulateRows) {
      this._result.addRow(row)
    }
  }

  handleCommandComplete(msg, connection) {
    this._checkForMultirow()
    this._result.addCommandComplete(msg)
    // need to sync after each command complete of a prepared statement
    // if we were using a row count which results in multiple calls to _getRows
    if (this.rows) {
      connection.sync()
    }
  }

  // if a named prepared statement is created with empty query text
  // the backend will send an emptyQuery message but *not* a command complete message
  // since we pipeline sync immediately after execute we don't need to do anything here
  // unless we have rows specified, in which case we did not pipeline the intial sync call
  handleEmptyQuery(connection) {
    if (this.rows) {
      connection.sync()
    }
  }

  handleError(err, connection) {
    // need to sync after error during a prepared statement
    if (this._canceledDueToError) {
      err = this._canceledDueToError
      this._canceledDueToError = false
    }
    // if callback supplied do not emit error event as uncaught error
    // events will bubble up to node process
    if (this.callback) {
      return this.callback(err)
    }
    this.emit('error', err)
  }

  handleReadyForQuery(con) {
    if (this._canceledDueToError) {
      return this.handleError(this._canceledDueToError, con)
    }
    if (this.callback) {
      this.callback(null, this._results)
    }
    this.emit('end', this._results)
  }

  submit(connection) {
    if (typeof this.text !== 'string' && typeof this.name !== 'string') {
      return new Error('A query must have either text or a name. Supplying neither is unsupported.')
    }
    const previous = connection.parsedStatements[this.name]
    if (this.text && previous && this.text !== previous) {
      return new Error(`Prepared statements must be unique - '${this.name}' was used for a different statement`)
    }
    if (this.values && !Array.isArray(this.values)) {
      return new Error('Query values must be an array')
    }
    if (this.requiresPreparation()) {
      this.prepare(connection)
    } else {
      connection.query(this.text)
    }
    return null
  }

  hasBeenParsed(connection) {
    return this.name && connection.parsedStatements[this.name]
  }

  handlePortalSuspended(connection) {
    this._getRows(connection, this.rows)
  }

  _getRows(connection, rows) {
    connection.execute({
      portal: this.portal,
      rows: rows,
    })
    // if we're not reading pages of rows send the sync command
    // to indicate the pipeline is finished
    if (!rows) {
      connection.sync()
    } else {
      // otherwise flush the call out to read more rows
      connection.flush()
    }
  }

  // http://developer.postgresql.org/pgdocs/postgres/protocol-flow.html#PROTOCOL-FLOW-EXT-QUERY
  prepare(connection) {
    // prepared statements need sync to be called after each command
    // complete or when an error is encountered
    this.isPreparedStatement = true

    // TODO refactor this poor encapsulation
    if (!this.hasBeenParsed(connection)) {
      connection.parse({
        text: this.text,
        name: this.name,
        types: this.types,
      })
    }

    // because we're mapping user supplied values to
    // postgres wire protocol compatible values it could
    // throw an exception, so try/catch this section
    try {
      connection.bind({
        portal: this.portal,
        statement: this.name,
        values: this.values,
        binary: this.binary,
        valueMapper: utils.prepareValue,
      })
    } catch (err) {
      this.handleError(err, connection)
      return
    }

    connection.describe({
      type: 'P',
      name: this.portal || '',
    })

    this._getRows(connection, this.rows)
  }

  handleCopyInResponse(connection) {
    connection.sendCopyFail('No source stream defined')
  }

  // eslint-disable-next-line no-unused-vars
  handleCopyData(msg, connection) {
    // noop
  }
}

module.exports = Query


/***/ }),

/***/ 3758:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var types = __webpack_require__(3619)

var matchRegexp = /^([A-Za-z]+)(?: (\d+))?(?: (\d+))?/

// result object returned from query
// in the 'end' event and also
// passed as second argument to provided callback
class Result {
  constructor(rowMode, types) {
    this.command = null
    this.rowCount = null
    this.oid = null
    this.rows = []
    this.fields = []
    this._parsers = undefined
    this._types = types
    this.RowCtor = null
    this.rowAsArray = rowMode === 'array'
    if (this.rowAsArray) {
      this.parseRow = this._parseRowAsArray
    }
  }

  // adds a command complete message
  addCommandComplete(msg) {
    var match
    if (msg.text) {
      // pure javascript
      match = matchRegexp.exec(msg.text)
    } else {
      // native bindings
      match = matchRegexp.exec(msg.command)
    }
    if (match) {
      this.command = match[1]
      if (match[3]) {
        // COMMMAND OID ROWS
        this.oid = parseInt(match[2], 10)
        this.rowCount = parseInt(match[3], 10)
      } else if (match[2]) {
        // COMMAND ROWS
        this.rowCount = parseInt(match[2], 10)
      }
    }
  }

  _parseRowAsArray(rowData) {
    var row = new Array(rowData.length)
    for (var i = 0, len = rowData.length; i < len; i++) {
      var rawValue = rowData[i]
      if (rawValue !== null) {
        row[i] = this._parsers[i](rawValue)
      } else {
        row[i] = null
      }
    }
    return row
  }

  parseRow(rowData) {
    var row = {}
    for (var i = 0, len = rowData.length; i < len; i++) {
      var rawValue = rowData[i]
      var field = this.fields[i].name
      if (rawValue !== null) {
        row[field] = this._parsers[i](rawValue)
      } else {
        row[field] = null
      }
    }
    return row
  }

  addRow(row) {
    this.rows.push(row)
  }

  addFields(fieldDescriptions) {
    // clears field definitions
    // multiple query statements in 1 action can result in multiple sets
    // of rowDescriptions...eg: 'select NOW(); select 1::int;'
    // you need to reset the fields
    this.fields = fieldDescriptions
    if (this.fields.length) {
      this._parsers = new Array(fieldDescriptions.length)
    }
    for (var i = 0; i < fieldDescriptions.length; i++) {
      var desc = fieldDescriptions[i]
      if (this._types) {
        this._parsers[i] = this._types.getTypeParser(desc.dataTypeID, desc.format || 'text')
      } else {
        this._parsers[i] = types.getTypeParser(desc.dataTypeID, desc.format || 'text')
      }
    }
  }
}

module.exports = Result


/***/ }),

/***/ 4615:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

const crypto = __webpack_require__(6417)

function startSession(mechanisms) {
  if (mechanisms.indexOf('SCRAM-SHA-256') === -1) {
    throw new Error('SASL: Only mechanism SCRAM-SHA-256 is currently supported')
  }

  const clientNonce = crypto.randomBytes(18).toString('base64')

  return {
    mechanism: 'SCRAM-SHA-256',
    clientNonce,
    response: 'n,,n=*,r=' + clientNonce,
    message: 'SASLInitialResponse',
  }
}

function continueSession(session, password, serverData) {
  if (session.message !== 'SASLInitialResponse') {
    throw new Error('SASL: Last message was not SASLInitialResponse')
  }
  if (typeof password !== 'string') {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: client password must be a string')
  }
  if (typeof serverData !== 'string') {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: serverData must be a string')
  }

  const sv = parseServerFirstMessage(serverData)

  if (!sv.nonce.startsWith(session.clientNonce)) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: server nonce does not start with client nonce')
  } else if (sv.nonce.length === session.clientNonce.length) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: server nonce is too short')
  }

  var saltBytes = Buffer.from(sv.salt, 'base64')

  var saltedPassword = Hi(password, saltBytes, sv.iteration)

  var clientKey = hmacSha256(saltedPassword, 'Client Key')
  var storedKey = sha256(clientKey)

  var clientFirstMessageBare = 'n=*,r=' + session.clientNonce
  var serverFirstMessage = 'r=' + sv.nonce + ',s=' + sv.salt + ',i=' + sv.iteration

  var clientFinalMessageWithoutProof = 'c=biws,r=' + sv.nonce

  var authMessage = clientFirstMessageBare + ',' + serverFirstMessage + ',' + clientFinalMessageWithoutProof

  var clientSignature = hmacSha256(storedKey, authMessage)
  var clientProofBytes = xorBuffers(clientKey, clientSignature)
  var clientProof = clientProofBytes.toString('base64')

  var serverKey = hmacSha256(saltedPassword, 'Server Key')
  var serverSignatureBytes = hmacSha256(serverKey, authMessage)

  session.message = 'SASLResponse'
  session.serverSignature = serverSignatureBytes.toString('base64')
  session.response = clientFinalMessageWithoutProof + ',p=' + clientProof
}

function finalizeSession(session, serverData) {
  if (session.message !== 'SASLResponse') {
    throw new Error('SASL: Last message was not SASLResponse')
  }
  if (typeof serverData !== 'string') {
    throw new Error('SASL: SCRAM-SERVER-FINAL-MESSAGE: serverData must be a string')
  }

  const { serverSignature } = parseServerFinalMessage(serverData)

  if (serverSignature !== session.serverSignature) {
    throw new Error('SASL: SCRAM-SERVER-FINAL-MESSAGE: server signature does not match')
  }
}

/**
 * printable       = %x21-2B / %x2D-7E
 *                   ;; Printable ASCII except ",".
 *                   ;; Note that any "printable" is also
 *                   ;; a valid "value".
 */
function isPrintableChars(text) {
  if (typeof text !== 'string') {
    throw new TypeError('SASL: text must be a string')
  }
  return text
    .split('')
    .map((_, i) => text.charCodeAt(i))
    .every((c) => (c >= 0x21 && c <= 0x2b) || (c >= 0x2d && c <= 0x7e))
}

/**
 * base64-char     = ALPHA / DIGIT / "/" / "+"
 *
 * base64-4        = 4base64-char
 *
 * base64-3        = 3base64-char "="
 *
 * base64-2        = 2base64-char "=="
 *
 * base64          = *base64-4 [base64-3 / base64-2]
 */
function isBase64(text) {
  return /^(?:[a-zA-Z0-9+/]{4})*(?:[a-zA-Z0-9+/]{2}==|[a-zA-Z0-9+/]{3}=)?$/.test(text)
}

function parseAttributePairs(text) {
  if (typeof text !== 'string') {
    throw new TypeError('SASL: attribute pairs text must be a string')
  }

  return new Map(
    text.split(',').map((attrValue) => {
      if (!/^.=/.test(attrValue)) {
        throw new Error('SASL: Invalid attribute pair entry')
      }
      const name = attrValue[0]
      const value = attrValue.substring(2)
      return [name, value]
    })
  )
}

function parseServerFirstMessage(data) {
  const attrPairs = parseAttributePairs(data)

  const nonce = attrPairs.get('r')
  if (!nonce) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: nonce missing')
  } else if (!isPrintableChars(nonce)) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: nonce must only contain printable characters')
  }
  const salt = attrPairs.get('s')
  if (!salt) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: salt missing')
  } else if (!isBase64(salt)) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: salt must be base64')
  }
  const iterationText = attrPairs.get('i')
  if (!iterationText) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: iteration missing')
  } else if (!/^[1-9][0-9]*$/.test(iterationText)) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: invalid iteration count')
  }
  const iteration = parseInt(iterationText, 10)

  return {
    nonce,
    salt,
    iteration,
  }
}

function parseServerFinalMessage(serverData) {
  const attrPairs = parseAttributePairs(serverData)
  const serverSignature = attrPairs.get('v')
  if (!serverSignature) {
    throw new Error('SASL: SCRAM-SERVER-FINAL-MESSAGE: server signature is missing')
  } else if (!isBase64(serverSignature)) {
    throw new Error('SASL: SCRAM-SERVER-FINAL-MESSAGE: server signature must be base64')
  }
  return {
    serverSignature,
  }
}

function xorBuffers(a, b) {
  if (!Buffer.isBuffer(a)) {
    throw new TypeError('first argument must be a Buffer')
  }
  if (!Buffer.isBuffer(b)) {
    throw new TypeError('second argument must be a Buffer')
  }
  if (a.length !== b.length) {
    throw new Error('Buffer lengths must match')
  }
  if (a.length === 0) {
    throw new Error('Buffers cannot be empty')
  }
  return Buffer.from(a.map((_, i) => a[i] ^ b[i]))
}

function sha256(text) {
  return crypto.createHash('sha256').update(text).digest()
}

function hmacSha256(key, msg) {
  return crypto.createHmac('sha256', key).update(msg).digest()
}

function Hi(password, saltBytes, iterations) {
  var ui1 = hmacSha256(password, Buffer.concat([saltBytes, Buffer.from([0, 0, 0, 1])]))
  var ui = ui1
  for (var i = 0; i < iterations - 1; i++) {
    ui1 = hmacSha256(password, ui1)
    ui = xorBuffers(ui, ui1)
  }

  return ui
}

module.exports = {
  startSession,
  continueSession,
  finalizeSession,
}


/***/ }),

/***/ 5701:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var types = __webpack_require__(3619)

function TypeOverrides(userTypes) {
  this._types = userTypes || types
  this.text = {}
  this.binary = {}
}

TypeOverrides.prototype.getOverrides = function (format) {
  switch (format) {
    case 'text':
      return this.text
    case 'binary':
      return this.binary
    default:
      return {}
  }
}

TypeOverrides.prototype.setTypeParser = function (oid, format, parseFn) {
  if (typeof format === 'function') {
    parseFn = format
    format = 'text'
  }
  this.getOverrides(format)[oid] = parseFn
}

TypeOverrides.prototype.getTypeParser = function (oid, format) {
  format = format || 'text'
  return this.getOverrides(format)[oid] || this._types.getTypeParser(oid, format)
}

module.exports = TypeOverrides


/***/ }),

/***/ 1262:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


const crypto = __webpack_require__(6417)

const defaults = __webpack_require__(7433)

function escapeElement(elementRepresentation) {
  var escaped = elementRepresentation.replace(/\\/g, '\\\\').replace(/"/g, '\\"')

  return '"' + escaped + '"'
}

// convert a JS array to a postgres array literal
// uses comma separator so won't work for types like box that use
// a different array separator.
function arrayString(val) {
  var result = '{'
  for (var i = 0; i < val.length; i++) {
    if (i > 0) {
      result = result + ','
    }
    if (val[i] === null || typeof val[i] === 'undefined') {
      result = result + 'NULL'
    } else if (Array.isArray(val[i])) {
      result = result + arrayString(val[i])
    } else if (val[i] instanceof Buffer) {
      result += '\\\\x' + val[i].toString('hex')
    } else {
      result += escapeElement(prepareValue(val[i]))
    }
  }
  result = result + '}'
  return result
}

// converts values from javascript types
// to their 'raw' counterparts for use as a postgres parameter
// note: you can override this function to provide your own conversion mechanism
// for complex types, etc...
var prepareValue = function (val, seen) {
  // null and undefined are both null for postgres
  if (val == null) {
    return null
  }
  if (val instanceof Buffer) {
    return val
  }
  if (ArrayBuffer.isView(val)) {
    var buf = Buffer.from(val.buffer, val.byteOffset, val.byteLength)
    if (buf.length === val.byteLength) {
      return buf
    }
    return buf.slice(val.byteOffset, val.byteOffset + val.byteLength) // Node.js v4 does not support those Buffer.from params
  }
  if (val instanceof Date) {
    if (defaults.parseInputDatesAsUTC) {
      return dateToStringUTC(val)
    } else {
      return dateToString(val)
    }
  }
  if (Array.isArray(val)) {
    return arrayString(val)
  }
  if (typeof val === 'object') {
    return prepareObject(val, seen)
  }
  return val.toString()
}

function prepareObject(val, seen) {
  if (val && typeof val.toPostgres === 'function') {
    seen = seen || []
    if (seen.indexOf(val) !== -1) {
      throw new Error('circular reference detected while preparing "' + val + '" for query')
    }
    seen.push(val)

    return prepareValue(val.toPostgres(prepareValue), seen)
  }
  return JSON.stringify(val)
}

function pad(number, digits) {
  number = '' + number
  while (number.length < digits) {
    number = '0' + number
  }
  return number
}

function dateToString(date) {
  var offset = -date.getTimezoneOffset()

  var year = date.getFullYear()
  var isBCYear = year < 1
  if (isBCYear) year = Math.abs(year) + 1 // negative years are 1 off their BC representation

  var ret =
    pad(year, 4) +
    '-' +
    pad(date.getMonth() + 1, 2) +
    '-' +
    pad(date.getDate(), 2) +
    'T' +
    pad(date.getHours(), 2) +
    ':' +
    pad(date.getMinutes(), 2) +
    ':' +
    pad(date.getSeconds(), 2) +
    '.' +
    pad(date.getMilliseconds(), 3)

  if (offset < 0) {
    ret += '-'
    offset *= -1
  } else {
    ret += '+'
  }

  ret += pad(Math.floor(offset / 60), 2) + ':' + pad(offset % 60, 2)
  if (isBCYear) ret += ' BC'
  return ret
}

function dateToStringUTC(date) {
  var year = date.getUTCFullYear()
  var isBCYear = year < 1
  if (isBCYear) year = Math.abs(year) + 1 // negative years are 1 off their BC representation

  var ret =
    pad(year, 4) +
    '-' +
    pad(date.getUTCMonth() + 1, 2) +
    '-' +
    pad(date.getUTCDate(), 2) +
    'T' +
    pad(date.getUTCHours(), 2) +
    ':' +
    pad(date.getUTCMinutes(), 2) +
    ':' +
    pad(date.getUTCSeconds(), 2) +
    '.' +
    pad(date.getUTCMilliseconds(), 3)

  ret += '+00:00'
  if (isBCYear) ret += ' BC'
  return ret
}

function normalizeQueryConfig(config, values, callback) {
  // can take in strings or config objects
  config = typeof config === 'string' ? { text: config } : config
  if (values) {
    if (typeof values === 'function') {
      config.callback = values
    } else {
      config.values = values
    }
  }
  if (callback) {
    config.callback = callback
  }
  return config
}

const md5 = function (string) {
  return crypto.createHash('md5').update(string, 'utf-8').digest('hex')
}

// See AuthenticationMD5Password at https://www.postgresql.org/docs/current/static/protocol-flow.html
const postgresMd5PasswordHash = function (user, password, salt) {
  var inner = md5(password + user)
  var outer = md5(Buffer.concat([Buffer.from(inner), salt]))
  return 'md5' + outer
}

module.exports = {
  prepareValue: function prepareValueWrapper(value) {
    // this ensures that extra arguments do not get passed into prepareValue
    // by accident, eg: from calling values.map(utils.prepareValue)
    return prepareValue(value)
  },
  normalizeQueryConfig,
  postgresMd5PasswordHash,
  md5,
}


/***/ }),

/***/ 8242:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var path = __webpack_require__(5622)
  , Stream = __webpack_require__(2413).Stream
  , split = __webpack_require__(861)
  , util = __webpack_require__(1669)
  , defaultPort = 5432
  , isWin = (process.platform === 'win32')
  , warnStream = process.stderr
;


var S_IRWXG = 56     //    00070(8)
  , S_IRWXO = 7      //    00007(8)
  , S_IFMT  = 61440  // 00170000(8)
  , S_IFREG = 32768  //  0100000(8)
;
function isRegFile(mode) {
    return ((mode & S_IFMT) == S_IFREG);
}

var fieldNames = [ 'host', 'port', 'database', 'user', 'password' ];
var nrOfFields = fieldNames.length;
var passKey = fieldNames[ nrOfFields -1 ];


function warn() {
    var isWritable = (
        warnStream instanceof Stream &&
          true === warnStream.writable
    );

    if (isWritable) {
        var args = Array.prototype.slice.call(arguments).concat("\n");
        warnStream.write( util.format.apply(util, args) );
    }
}


Object.defineProperty(module.exports, "isWin", ({
    get : function() {
        return isWin;
    } ,
    set : function(val) {
        isWin = val;
    }
}));


module.exports.warnTo = function(stream) {
    var old = warnStream;
    warnStream = stream;
    return old;
};

module.exports.getFileName = function(rawEnv){
    var env = rawEnv || process.env;
    var file = env.PGPASSFILE || (
        isWin ?
          path.join( env.APPDATA || './' , 'postgresql', 'pgpass.conf' ) :
          path.join( env.HOME || './', '.pgpass' )
    );
    return file;
};

module.exports.usePgPass = function(stats, fname) {
    if (Object.prototype.hasOwnProperty.call(process.env, 'PGPASSWORD')) {
        return false;
    }

    if (isWin) {
        return true;
    }

    fname = fname || '<unkn>';

    if (! isRegFile(stats.mode)) {
        warn('WARNING: password file "%s" is not a plain file', fname);
        return false;
    }

    if (stats.mode & (S_IRWXG | S_IRWXO)) {
        /* If password file is insecure, alert the user and ignore it. */
        warn('WARNING: password file "%s" has group or world access; permissions should be u=rw (0600) or less', fname);
        return false;
    }

    return true;
};


var matcher = module.exports.match = function(connInfo, entry) {
    return fieldNames.slice(0, -1).reduce(function(prev, field, idx){
        if (idx == 1) {
            // the port
            if ( Number( connInfo[field] || defaultPort ) === Number( entry[field] ) ) {
                return prev && true;
            }
        }
        return prev && (
            entry[field] === '*' ||
              entry[field] === connInfo[field]
        );
    }, true);
};


module.exports.getPassword = function(connInfo, stream, cb) {
    var pass;
    var lineStream = stream.pipe(split());

    function onLine(line) {
        var entry = parseLine(line);
        if (entry && isValidEntry(entry) && matcher(connInfo, entry)) {
            pass = entry[passKey];
            lineStream.end(); // -> calls onEnd(), but pass is set now
        }
    }

    var onEnd = function() {
        stream.destroy();
        cb(pass);
    };

    var onErr = function(err) {
        stream.destroy();
        warn('WARNING: error on reading file: %s', err);
        cb(undefined);
    };

    stream.on('error', onErr);
    lineStream
        .on('data', onLine)
        .on('end', onEnd)
        .on('error', onErr)
    ;

};


var parseLine = module.exports.parseLine = function(line) {
    if (line.length < 11 || line.match(/^\s+#/)) {
        return null;
    }

    var curChar = '';
    var prevChar = '';
    var fieldIdx = 0;
    var startIdx = 0;
    var endIdx = 0;
    var obj = {};
    var isLastField = false;
    var addToObj = function(idx, i0, i1) {
        var field = line.substring(i0, i1);

        if (! Object.hasOwnProperty.call(process.env, 'PGPASS_NO_DEESCAPE')) {
            field = field.replace(/\\([:\\])/g, '$1');
        }

        obj[ fieldNames[idx] ] = field;
    };

    for (var i = 0 ; i < line.length-1 ; i += 1) {
        curChar = line.charAt(i+1);
        prevChar = line.charAt(i);

        isLastField = (fieldIdx == nrOfFields-1);

        if (isLastField) {
            addToObj(fieldIdx, startIdx);
            break;
        }

        if (i >= 0 && curChar == ':' && prevChar !== '\\') {
            addToObj(fieldIdx, startIdx, i+1);

            startIdx = i+2;
            fieldIdx += 1;
        }
    }

    obj = ( Object.keys(obj).length === nrOfFields ) ? obj : null;

    return obj;
};


var isValidEntry = module.exports.isValidEntry = function(entry){
    var rules = {
        // host
        0 : function(x){
            return x.length > 0;
        } ,
        // port
        1 : function(x){
            if (x === '*') {
                return true;
            }
            x = Number(x);
            return (
                isFinite(x) &&
                  x > 0 &&
                  x < 9007199254740992 &&
                  Math.floor(x) === x
            );
        } ,
        // database
        2 : function(x){
            return x.length > 0;
        } ,
        // username
        3 : function(x){
            return x.length > 0;
        } ,
        // password
        4 : function(x){
            return x.length > 0;
        }
    };

    for (var idx = 0 ; idx < fieldNames.length ; idx += 1) {
        var rule = rules[idx];
        var value = entry[ fieldNames[idx] ] || '';

        var res = rule(value);
        if (!res) {
            return false;
        }
    }

    return true;
};



/***/ }),

/***/ 8812:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var path = __webpack_require__(5622)
  , fs = __webpack_require__(5747)
  , helper = __webpack_require__(8242)
;


module.exports = function(connInfo, cb) {
    var file = helper.getFileName();
    
    fs.stat(file, function(err, stat){
        if (err || !helper.usePgPass(stat, file)) {
            return cb(undefined);
        }

        var st = fs.createReadStream(file);

        helper.getPassword(connInfo, st, cb);
    });
};

module.exports.warnTo = helper.warnTo;


/***/ }),

/***/ 7315:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


exports.parse = function (source, transform) {
  return new ArrayParser(source, transform).parse()
}

class ArrayParser {
  constructor (source, transform) {
    this.source = source
    this.transform = transform || identity
    this.position = 0
    this.entries = []
    this.recorded = []
    this.dimension = 0
  }

  isEof () {
    return this.position >= this.source.length
  }

  nextCharacter () {
    var character = this.source[this.position++]
    if (character === '\\') {
      return {
        value: this.source[this.position++],
        escaped: true
      }
    }
    return {
      value: character,
      escaped: false
    }
  }

  record (character) {
    this.recorded.push(character)
  }

  newEntry (includeEmpty) {
    var entry
    if (this.recorded.length > 0 || includeEmpty) {
      entry = this.recorded.join('')
      if (entry === 'NULL' && !includeEmpty) {
        entry = null
      }
      if (entry !== null) entry = this.transform(entry)
      this.entries.push(entry)
      this.recorded = []
    }
  }

  consumeDimensions () {
    if (this.source[0] === '[') {
      while (!this.isEof()) {
        var char = this.nextCharacter()
        if (char.value === '=') break
      }
    }
  }

  parse (nested) {
    var character, parser, quote
    this.consumeDimensions()
    while (!this.isEof()) {
      character = this.nextCharacter()
      if (character.value === '{' && !quote) {
        this.dimension++
        if (this.dimension > 1) {
          parser = new ArrayParser(this.source.substr(this.position - 1), this.transform)
          this.entries.push(parser.parse(true))
          this.position += parser.position - 2
        }
      } else if (character.value === '}' && !quote) {
        this.dimension--
        if (!this.dimension) {
          this.newEntry()
          if (nested) return this.entries
        }
      } else if (character.value === '"' && !character.escaped) {
        if (quote) this.newEntry(true)
        quote = !quote
      } else if (character.value === ',' && !quote) {
        this.newEntry()
      } else {
        this.record(character.value)
      }
    }
    if (this.dimension !== 0) {
      throw new Error('array dimension not balanced')
    }
    return this.entries
  }
}

function identity (value) {
  return value
}


/***/ }),

/***/ 3712:
/***/ ((module) => {

"use strict";


module.exports = function parseBytea (input) {
  if (/^\\x/.test(input)) {
    // new 'hex' style response (pg >9.0)
    return new Buffer(input.substr(2), 'hex')
  }
  var output = ''
  var i = 0
  while (i < input.length) {
    if (input[i] !== '\\') {
      output += input[i]
      ++i
    } else {
      if (/[0-7]{3}/.test(input.substr(i + 1, 3))) {
        output += String.fromCharCode(parseInt(input.substr(i + 1, 3), 8))
        i += 4
      } else {
        var backslashes = 1
        while (i + backslashes < input.length && input[i + backslashes] === '\\') {
          backslashes++
        }
        for (var k = 0; k < Math.floor(backslashes / 2); ++k) {
          output += '\\'
        }
        i += Math.floor(backslashes / 2) * 2
      }
    }
  }
  return new Buffer(output, 'binary')
}


/***/ }),

/***/ 3765:
/***/ ((module) => {

"use strict";


var DATE_TIME = /(\d{1,})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})(\.\d{1,})?.*?( BC)?$/
var DATE = /^(\d{1,})-(\d{2})-(\d{2})( BC)?$/
var TIME_ZONE = /([Z+-])(\d{2})?:?(\d{2})?:?(\d{2})?/
var INFINITY = /^-?infinity$/

module.exports = function parseDate (isoDate) {
  if (INFINITY.test(isoDate)) {
    // Capitalize to Infinity before passing to Number
    return Number(isoDate.replace('i', 'I'))
  }
  var matches = DATE_TIME.exec(isoDate)

  if (!matches) {
    // Force YYYY-MM-DD dates to be parsed as local time
    return getDate(isoDate) || null
  }

  var isBC = !!matches[8]
  var year = parseInt(matches[1], 10)
  if (isBC) {
    year = bcYearToNegativeYear(year)
  }

  var month = parseInt(matches[2], 10) - 1
  var day = matches[3]
  var hour = parseInt(matches[4], 10)
  var minute = parseInt(matches[5], 10)
  var second = parseInt(matches[6], 10)

  var ms = matches[7]
  ms = ms ? 1000 * parseFloat(ms) : 0

  var date
  var offset = timeZoneOffset(isoDate)
  if (offset != null) {
    date = new Date(Date.UTC(year, month, day, hour, minute, second, ms))

    // Account for years from 0 to 99 being interpreted as 1900-1999
    // by Date.UTC / the multi-argument form of the Date constructor
    if (is0To99(year)) {
      date.setUTCFullYear(year)
    }

    if (offset !== 0) {
      date.setTime(date.getTime() - offset)
    }
  } else {
    date = new Date(year, month, day, hour, minute, second, ms)

    if (is0To99(year)) {
      date.setFullYear(year)
    }
  }

  return date
}

function getDate (isoDate) {
  var matches = DATE.exec(isoDate)
  if (!matches) {
    return
  }

  var year = parseInt(matches[1], 10)
  var isBC = !!matches[4]
  if (isBC) {
    year = bcYearToNegativeYear(year)
  }

  var month = parseInt(matches[2], 10) - 1
  var day = matches[3]
  // YYYY-MM-DD will be parsed as local time
  var date = new Date(year, month, day)

  if (is0To99(year)) {
    date.setFullYear(year)
  }

  return date
}

// match timezones:
// Z (UTC)
// -05
// +06:30
function timeZoneOffset (isoDate) {
  if (isoDate.endsWith('+00')) {
    return 0
  }

  var zone = TIME_ZONE.exec(isoDate.split(' ')[1])
  if (!zone) return
  var type = zone[1]

  if (type === 'Z') {
    return 0
  }
  var sign = type === '-' ? -1 : 1
  var offset = parseInt(zone[2], 10) * 3600 +
    parseInt(zone[3] || 0, 10) * 60 +
    parseInt(zone[4] || 0, 10)

  return offset * sign * 1000
}

function bcYearToNegativeYear (year) {
  // Account for numerical difference between representations of BC years
  // See: https://github.com/bendrucker/postgres-date/issues/5
  return -(year - 1)
}

function is0To99 (num) {
  return num >= 0 && num < 100
}


/***/ }),

/***/ 1055:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var extend = __webpack_require__(9820)

module.exports = PostgresInterval

function PostgresInterval (raw) {
  if (!(this instanceof PostgresInterval)) {
    return new PostgresInterval(raw)
  }
  extend(this, parse(raw))
}
var properties = ['seconds', 'minutes', 'hours', 'days', 'months', 'years']
PostgresInterval.prototype.toPostgres = function () {
  var filtered = properties.filter(this.hasOwnProperty, this)

  // In addition to `properties`, we need to account for fractions of seconds.
  if (this.milliseconds && filtered.indexOf('seconds') < 0) {
    filtered.push('seconds')
  }

  if (filtered.length === 0) return '0'
  return filtered
    .map(function (property) {
      var value = this[property] || 0

      // Account for fractional part of seconds,
      // remove trailing zeroes.
      if (property === 'seconds' && this.milliseconds) {
        value = (value + this.milliseconds / 1000).toFixed(6).replace(/\.?0+$/, '')
      }

      return value + ' ' + property
    }, this)
    .join(' ')
}

var propertiesISOEquivalent = {
  years: 'Y',
  months: 'M',
  days: 'D',
  hours: 'H',
  minutes: 'M',
  seconds: 'S'
}
var dateProperties = ['years', 'months', 'days']
var timeProperties = ['hours', 'minutes', 'seconds']
// according to ISO 8601
PostgresInterval.prototype.toISOString = PostgresInterval.prototype.toISO = function () {
  var datePart = dateProperties
    .map(buildProperty, this)
    .join('')

  var timePart = timeProperties
    .map(buildProperty, this)
    .join('')

  return 'P' + datePart + 'T' + timePart

  function buildProperty (property) {
    var value = this[property] || 0

    // Account for fractional part of seconds,
    // remove trailing zeroes.
    if (property === 'seconds' && this.milliseconds) {
      value = (value + this.milliseconds / 1000).toFixed(6).replace(/0+$/, '')
    }

    return value + propertiesISOEquivalent[property]
  }
}

var NUMBER = '([+-]?\\d+)'
var YEAR = NUMBER + '\\s+years?'
var MONTH = NUMBER + '\\s+mons?'
var DAY = NUMBER + '\\s+days?'
var TIME = '([+-])?([\\d]*):(\\d\\d):(\\d\\d)\\.?(\\d{1,6})?'
var INTERVAL = new RegExp([YEAR, MONTH, DAY, TIME].map(function (regexString) {
  return '(' + regexString + ')?'
})
  .join('\\s*'))

// Positions of values in regex match
var positions = {
  years: 2,
  months: 4,
  days: 6,
  hours: 9,
  minutes: 10,
  seconds: 11,
  milliseconds: 12
}
// We can use negative time
var negatives = ['hours', 'minutes', 'seconds', 'milliseconds']

function parseMilliseconds (fraction) {
  // add omitted zeroes
  var microseconds = fraction + '000000'.slice(fraction.length)
  return parseInt(microseconds, 10) / 1000
}

function parse (interval) {
  if (!interval) return {}
  var matches = INTERVAL.exec(interval)
  var isNegative = matches[8] === '-'
  return Object.keys(positions)
    .reduce(function (parsed, property) {
      var position = positions[property]
      var value = matches[position]
      // no empty string
      if (!value) return parsed
      // milliseconds are actually microseconds (up to 6 digits)
      // with omitted trailing zeroes.
      value = property === 'milliseconds'
        ? parseMilliseconds(value)
        : parseInt(value, 10)
      // no zeros
      if (!value) return parsed
      if (isNegative && ~negatives.indexOf(property)) {
        value *= -1
      }
      parsed[property] = value
      return parsed
    }, {})
}


/***/ }),

/***/ 4012:
/***/ ((module) => {

"use strict";


const codes = {};

function createErrorType(code, message, Base) {
  if (!Base) {
    Base = Error
  }

  function getMessage (arg1, arg2, arg3) {
    if (typeof message === 'string') {
      return message
    } else {
      return message(arg1, arg2, arg3)
    }
  }

  class NodeError extends Base {
    constructor (arg1, arg2, arg3) {
      super(getMessage(arg1, arg2, arg3));
    }
  }

  NodeError.prototype.name = Base.name;
  NodeError.prototype.code = code;

  codes[code] = NodeError;
}

// https://github.com/nodejs/node/blob/v10.8.0/lib/internal/errors.js
function oneOf(expected, thing) {
  if (Array.isArray(expected)) {
    const len = expected.length;
    expected = expected.map((i) => String(i));
    if (len > 2) {
      return `one of ${thing} ${expected.slice(0, len - 1).join(', ')}, or ` +
             expected[len - 1];
    } else if (len === 2) {
      return `one of ${thing} ${expected[0]} or ${expected[1]}`;
    } else {
      return `of ${thing} ${expected[0]}`;
    }
  } else {
    return `of ${thing} ${String(expected)}`;
  }
}

// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/startsWith
function startsWith(str, search, pos) {
	return str.substr(!pos || pos < 0 ? 0 : +pos, search.length) === search;
}

// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/endsWith
function endsWith(str, search, this_len) {
	if (this_len === undefined || this_len > str.length) {
		this_len = str.length;
	}
	return str.substring(this_len - search.length, this_len) === search;
}

// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/includes
function includes(str, search, start) {
  if (typeof start !== 'number') {
    start = 0;
  }

  if (start + search.length > str.length) {
    return false;
  } else {
    return str.indexOf(search, start) !== -1;
  }
}

createErrorType('ERR_INVALID_OPT_VALUE', function (name, value) {
  return 'The value "' + value + '" is invalid for option "' + name + '"'
}, TypeError);
createErrorType('ERR_INVALID_ARG_TYPE', function (name, expected, actual) {
  // determiner: 'must be' or 'must not be'
  let determiner;
  if (typeof expected === 'string' && startsWith(expected, 'not ')) {
    determiner = 'must not be';
    expected = expected.replace(/^not /, '');
  } else {
    determiner = 'must be';
  }

  let msg;
  if (endsWith(name, ' argument')) {
    // For cases like 'first argument'
    msg = `The ${name} ${determiner} ${oneOf(expected, 'type')}`;
  } else {
    const type = includes(name, '.') ? 'property' : 'argument';
    msg = `The "${name}" ${type} ${determiner} ${oneOf(expected, 'type')}`;
  }

  msg += `. Received type ${typeof actual}`;
  return msg;
}, TypeError);
createErrorType('ERR_STREAM_PUSH_AFTER_EOF', 'stream.push() after EOF');
createErrorType('ERR_METHOD_NOT_IMPLEMENTED', function (name) {
  return 'The ' + name + ' method is not implemented'
});
createErrorType('ERR_STREAM_PREMATURE_CLOSE', 'Premature close');
createErrorType('ERR_STREAM_DESTROYED', function (name) {
  return 'Cannot call ' + name + ' after a stream was destroyed';
});
createErrorType('ERR_MULTIPLE_CALLBACK', 'Callback called multiple times');
createErrorType('ERR_STREAM_CANNOT_PIPE', 'Cannot pipe, not readable');
createErrorType('ERR_STREAM_WRITE_AFTER_END', 'write after end');
createErrorType('ERR_STREAM_NULL_VALUES', 'May not write null values to stream', TypeError);
createErrorType('ERR_UNKNOWN_ENCODING', function (arg) {
  return 'Unknown encoding: ' + arg
}, TypeError);
createErrorType('ERR_STREAM_UNSHIFT_AFTER_END_EVENT', 'stream.unshift() after end event');

module.exports.q = codes;


/***/ }),

/***/ 6753:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.
// a duplex stream is just a stream that is both readable and writable.
// Since JS doesn't have multiple prototypal inheritance, this class
// prototypally inherits from Readable, and then parasitically from
// Writable.

/*<replacement>*/

var objectKeys = Object.keys || function (obj) {
  var keys = [];

  for (var key in obj) {
    keys.push(key);
  }

  return keys;
};
/*</replacement>*/


module.exports = Duplex;

var Readable = __webpack_require__(9481);

var Writable = __webpack_require__(4229);

__webpack_require__(4378)(Duplex, Readable);

{
  // Allow the keys array to be GC'ed.
  var keys = objectKeys(Writable.prototype);

  for (var v = 0; v < keys.length; v++) {
    var method = keys[v];
    if (!Duplex.prototype[method]) Duplex.prototype[method] = Writable.prototype[method];
  }
}

function Duplex(options) {
  if (!(this instanceof Duplex)) return new Duplex(options);
  Readable.call(this, options);
  Writable.call(this, options);
  this.allowHalfOpen = true;

  if (options) {
    if (options.readable === false) this.readable = false;
    if (options.writable === false) this.writable = false;

    if (options.allowHalfOpen === false) {
      this.allowHalfOpen = false;
      this.once('end', onend);
    }
  }
}

Object.defineProperty(Duplex.prototype, 'writableHighWaterMark', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._writableState.highWaterMark;
  }
});
Object.defineProperty(Duplex.prototype, 'writableBuffer', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._writableState && this._writableState.getBuffer();
  }
});
Object.defineProperty(Duplex.prototype, 'writableLength', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._writableState.length;
  }
}); // the no-half-open enforcer

function onend() {
  // If the writable side ended, then we're ok.
  if (this._writableState.ended) return; // no more data can be written.
  // But allow more writes to happen in this tick.

  process.nextTick(onEndNT, this);
}

function onEndNT(self) {
  self.end();
}

Object.defineProperty(Duplex.prototype, 'destroyed', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    if (this._readableState === undefined || this._writableState === undefined) {
      return false;
    }

    return this._readableState.destroyed && this._writableState.destroyed;
  },
  set: function set(value) {
    // we ignore the value if the stream
    // has not been initialized yet
    if (this._readableState === undefined || this._writableState === undefined) {
      return;
    } // backward compatibility, the user is explicitly
    // managing destroyed


    this._readableState.destroyed = value;
    this._writableState.destroyed = value;
  }
});

/***/ }),

/***/ 2725:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.
// a passthrough stream.
// basically just the most minimal sort of Transform stream.
// Every written chunk gets output as-is.


module.exports = PassThrough;

var Transform = __webpack_require__(4605);

__webpack_require__(4378)(PassThrough, Transform);

function PassThrough(options) {
  if (!(this instanceof PassThrough)) return new PassThrough(options);
  Transform.call(this, options);
}

PassThrough.prototype._transform = function (chunk, encoding, cb) {
  cb(null, chunk);
};

/***/ }),

/***/ 9481:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.


module.exports = Readable;
/*<replacement>*/

var Duplex;
/*</replacement>*/

Readable.ReadableState = ReadableState;
/*<replacement>*/

var EE = __webpack_require__(8614).EventEmitter;

var EElistenerCount = function EElistenerCount(emitter, type) {
  return emitter.listeners(type).length;
};
/*</replacement>*/

/*<replacement>*/


var Stream = __webpack_require__(9740);
/*</replacement>*/


var Buffer = __webpack_require__(4293).Buffer;

var OurUint8Array = global.Uint8Array || function () {};

function _uint8ArrayToBuffer(chunk) {
  return Buffer.from(chunk);
}

function _isUint8Array(obj) {
  return Buffer.isBuffer(obj) || obj instanceof OurUint8Array;
}
/*<replacement>*/


var debugUtil = __webpack_require__(1669);

var debug;

if (debugUtil && debugUtil.debuglog) {
  debug = debugUtil.debuglog('stream');
} else {
  debug = function debug() {};
}
/*</replacement>*/


var BufferList = __webpack_require__(7327);

var destroyImpl = __webpack_require__(1195);

var _require = __webpack_require__(2457),
    getHighWaterMark = _require.getHighWaterMark;

var _require$codes = __webpack_require__(4012)/* .codes */ .q,
    ERR_INVALID_ARG_TYPE = _require$codes.ERR_INVALID_ARG_TYPE,
    ERR_STREAM_PUSH_AFTER_EOF = _require$codes.ERR_STREAM_PUSH_AFTER_EOF,
    ERR_METHOD_NOT_IMPLEMENTED = _require$codes.ERR_METHOD_NOT_IMPLEMENTED,
    ERR_STREAM_UNSHIFT_AFTER_END_EVENT = _require$codes.ERR_STREAM_UNSHIFT_AFTER_END_EVENT; // Lazy loaded to improve the startup performance.


var StringDecoder;
var createReadableStreamAsyncIterator;
var from;

__webpack_require__(4378)(Readable, Stream);

var errorOrDestroy = destroyImpl.errorOrDestroy;
var kProxyEvents = ['error', 'close', 'destroy', 'pause', 'resume'];

function prependListener(emitter, event, fn) {
  // Sadly this is not cacheable as some libraries bundle their own
  // event emitter implementation with them.
  if (typeof emitter.prependListener === 'function') return emitter.prependListener(event, fn); // This is a hack to make sure that our error handler is attached before any
  // userland ones.  NEVER DO THIS. This is here only because this code needs
  // to continue to work with older versions of Node.js that do not include
  // the prependListener() method. The goal is to eventually remove this hack.

  if (!emitter._events || !emitter._events[event]) emitter.on(event, fn);else if (Array.isArray(emitter._events[event])) emitter._events[event].unshift(fn);else emitter._events[event] = [fn, emitter._events[event]];
}

function ReadableState(options, stream, isDuplex) {
  Duplex = Duplex || __webpack_require__(6753);
  options = options || {}; // Duplex streams are both readable and writable, but share
  // the same options object.
  // However, some cases require setting options to different
  // values for the readable and the writable sides of the duplex stream.
  // These options can be provided separately as readableXXX and writableXXX.

  if (typeof isDuplex !== 'boolean') isDuplex = stream instanceof Duplex; // object stream flag. Used to make read(n) ignore n and to
  // make all the buffer merging and length checks go away

  this.objectMode = !!options.objectMode;
  if (isDuplex) this.objectMode = this.objectMode || !!options.readableObjectMode; // the point at which it stops calling _read() to fill the buffer
  // Note: 0 is a valid value, means "don't call _read preemptively ever"

  this.highWaterMark = getHighWaterMark(this, options, 'readableHighWaterMark', isDuplex); // A linked list is used to store data chunks instead of an array because the
  // linked list can remove elements from the beginning faster than
  // array.shift()

  this.buffer = new BufferList();
  this.length = 0;
  this.pipes = null;
  this.pipesCount = 0;
  this.flowing = null;
  this.ended = false;
  this.endEmitted = false;
  this.reading = false; // a flag to be able to tell if the event 'readable'/'data' is emitted
  // immediately, or on a later tick.  We set this to true at first, because
  // any actions that shouldn't happen until "later" should generally also
  // not happen before the first read call.

  this.sync = true; // whenever we return null, then we set a flag to say
  // that we're awaiting a 'readable' event emission.

  this.needReadable = false;
  this.emittedReadable = false;
  this.readableListening = false;
  this.resumeScheduled = false;
  this.paused = true; // Should close be emitted on destroy. Defaults to true.

  this.emitClose = options.emitClose !== false; // Should .destroy() be called after 'end' (and potentially 'finish')

  this.autoDestroy = !!options.autoDestroy; // has it been destroyed

  this.destroyed = false; // Crypto is kind of old and crusty.  Historically, its default string
  // encoding is 'binary' so we have to make this configurable.
  // Everything else in the universe uses 'utf8', though.

  this.defaultEncoding = options.defaultEncoding || 'utf8'; // the number of writers that are awaiting a drain event in .pipe()s

  this.awaitDrain = 0; // if true, a maybeReadMore has been scheduled

  this.readingMore = false;
  this.decoder = null;
  this.encoding = null;

  if (options.encoding) {
    if (!StringDecoder) StringDecoder = __webpack_require__(2553)/* .StringDecoder */ .s;
    this.decoder = new StringDecoder(options.encoding);
    this.encoding = options.encoding;
  }
}

function Readable(options) {
  Duplex = Duplex || __webpack_require__(6753);
  if (!(this instanceof Readable)) return new Readable(options); // Checking for a Stream.Duplex instance is faster here instead of inside
  // the ReadableState constructor, at least with V8 6.5

  var isDuplex = this instanceof Duplex;
  this._readableState = new ReadableState(options, this, isDuplex); // legacy

  this.readable = true;

  if (options) {
    if (typeof options.read === 'function') this._read = options.read;
    if (typeof options.destroy === 'function') this._destroy = options.destroy;
  }

  Stream.call(this);
}

Object.defineProperty(Readable.prototype, 'destroyed', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    if (this._readableState === undefined) {
      return false;
    }

    return this._readableState.destroyed;
  },
  set: function set(value) {
    // we ignore the value if the stream
    // has not been initialized yet
    if (!this._readableState) {
      return;
    } // backward compatibility, the user is explicitly
    // managing destroyed


    this._readableState.destroyed = value;
  }
});
Readable.prototype.destroy = destroyImpl.destroy;
Readable.prototype._undestroy = destroyImpl.undestroy;

Readable.prototype._destroy = function (err, cb) {
  cb(err);
}; // Manually shove something into the read() buffer.
// This returns true if the highWaterMark has not been hit yet,
// similar to how Writable.write() returns true if you should
// write() some more.


Readable.prototype.push = function (chunk, encoding) {
  var state = this._readableState;
  var skipChunkCheck;

  if (!state.objectMode) {
    if (typeof chunk === 'string') {
      encoding = encoding || state.defaultEncoding;

      if (encoding !== state.encoding) {
        chunk = Buffer.from(chunk, encoding);
        encoding = '';
      }

      skipChunkCheck = true;
    }
  } else {
    skipChunkCheck = true;
  }

  return readableAddChunk(this, chunk, encoding, false, skipChunkCheck);
}; // Unshift should *always* be something directly out of read()


Readable.prototype.unshift = function (chunk) {
  return readableAddChunk(this, chunk, null, true, false);
};

function readableAddChunk(stream, chunk, encoding, addToFront, skipChunkCheck) {
  debug('readableAddChunk', chunk);
  var state = stream._readableState;

  if (chunk === null) {
    state.reading = false;
    onEofChunk(stream, state);
  } else {
    var er;
    if (!skipChunkCheck) er = chunkInvalid(state, chunk);

    if (er) {
      errorOrDestroy(stream, er);
    } else if (state.objectMode || chunk && chunk.length > 0) {
      if (typeof chunk !== 'string' && !state.objectMode && Object.getPrototypeOf(chunk) !== Buffer.prototype) {
        chunk = _uint8ArrayToBuffer(chunk);
      }

      if (addToFront) {
        if (state.endEmitted) errorOrDestroy(stream, new ERR_STREAM_UNSHIFT_AFTER_END_EVENT());else addChunk(stream, state, chunk, true);
      } else if (state.ended) {
        errorOrDestroy(stream, new ERR_STREAM_PUSH_AFTER_EOF());
      } else if (state.destroyed) {
        return false;
      } else {
        state.reading = false;

        if (state.decoder && !encoding) {
          chunk = state.decoder.write(chunk);
          if (state.objectMode || chunk.length !== 0) addChunk(stream, state, chunk, false);else maybeReadMore(stream, state);
        } else {
          addChunk(stream, state, chunk, false);
        }
      }
    } else if (!addToFront) {
      state.reading = false;
      maybeReadMore(stream, state);
    }
  } // We can push more data if we are below the highWaterMark.
  // Also, if we have no data yet, we can stand some more bytes.
  // This is to work around cases where hwm=0, such as the repl.


  return !state.ended && (state.length < state.highWaterMark || state.length === 0);
}

function addChunk(stream, state, chunk, addToFront) {
  if (state.flowing && state.length === 0 && !state.sync) {
    state.awaitDrain = 0;
    stream.emit('data', chunk);
  } else {
    // update the buffer info.
    state.length += state.objectMode ? 1 : chunk.length;
    if (addToFront) state.buffer.unshift(chunk);else state.buffer.push(chunk);
    if (state.needReadable) emitReadable(stream);
  }

  maybeReadMore(stream, state);
}

function chunkInvalid(state, chunk) {
  var er;

  if (!_isUint8Array(chunk) && typeof chunk !== 'string' && chunk !== undefined && !state.objectMode) {
    er = new ERR_INVALID_ARG_TYPE('chunk', ['string', 'Buffer', 'Uint8Array'], chunk);
  }

  return er;
}

Readable.prototype.isPaused = function () {
  return this._readableState.flowing === false;
}; // backwards compatibility.


Readable.prototype.setEncoding = function (enc) {
  if (!StringDecoder) StringDecoder = __webpack_require__(2553)/* .StringDecoder */ .s;
  var decoder = new StringDecoder(enc);
  this._readableState.decoder = decoder; // If setEncoding(null), decoder.encoding equals utf8

  this._readableState.encoding = this._readableState.decoder.encoding; // Iterate over current buffer to convert already stored Buffers:

  var p = this._readableState.buffer.head;
  var content = '';

  while (p !== null) {
    content += decoder.write(p.data);
    p = p.next;
  }

  this._readableState.buffer.clear();

  if (content !== '') this._readableState.buffer.push(content);
  this._readableState.length = content.length;
  return this;
}; // Don't raise the hwm > 1GB


var MAX_HWM = 0x40000000;

function computeNewHighWaterMark(n) {
  if (n >= MAX_HWM) {
    // TODO(ronag): Throw ERR_VALUE_OUT_OF_RANGE.
    n = MAX_HWM;
  } else {
    // Get the next highest power of 2 to prevent increasing hwm excessively in
    // tiny amounts
    n--;
    n |= n >>> 1;
    n |= n >>> 2;
    n |= n >>> 4;
    n |= n >>> 8;
    n |= n >>> 16;
    n++;
  }

  return n;
} // This function is designed to be inlinable, so please take care when making
// changes to the function body.


function howMuchToRead(n, state) {
  if (n <= 0 || state.length === 0 && state.ended) return 0;
  if (state.objectMode) return 1;

  if (n !== n) {
    // Only flow one buffer at a time
    if (state.flowing && state.length) return state.buffer.head.data.length;else return state.length;
  } // If we're asking for more than the current hwm, then raise the hwm.


  if (n > state.highWaterMark) state.highWaterMark = computeNewHighWaterMark(n);
  if (n <= state.length) return n; // Don't have enough

  if (!state.ended) {
    state.needReadable = true;
    return 0;
  }

  return state.length;
} // you can override either this method, or the async _read(n) below.


Readable.prototype.read = function (n) {
  debug('read', n);
  n = parseInt(n, 10);
  var state = this._readableState;
  var nOrig = n;
  if (n !== 0) state.emittedReadable = false; // if we're doing read(0) to trigger a readable event, but we
  // already have a bunch of data in the buffer, then just trigger
  // the 'readable' event and move on.

  if (n === 0 && state.needReadable && ((state.highWaterMark !== 0 ? state.length >= state.highWaterMark : state.length > 0) || state.ended)) {
    debug('read: emitReadable', state.length, state.ended);
    if (state.length === 0 && state.ended) endReadable(this);else emitReadable(this);
    return null;
  }

  n = howMuchToRead(n, state); // if we've ended, and we're now clear, then finish it up.

  if (n === 0 && state.ended) {
    if (state.length === 0) endReadable(this);
    return null;
  } // All the actual chunk generation logic needs to be
  // *below* the call to _read.  The reason is that in certain
  // synthetic stream cases, such as passthrough streams, _read
  // may be a completely synchronous operation which may change
  // the state of the read buffer, providing enough data when
  // before there was *not* enough.
  //
  // So, the steps are:
  // 1. Figure out what the state of things will be after we do
  // a read from the buffer.
  //
  // 2. If that resulting state will trigger a _read, then call _read.
  // Note that this may be asynchronous, or synchronous.  Yes, it is
  // deeply ugly to write APIs this way, but that still doesn't mean
  // that the Readable class should behave improperly, as streams are
  // designed to be sync/async agnostic.
  // Take note if the _read call is sync or async (ie, if the read call
  // has returned yet), so that we know whether or not it's safe to emit
  // 'readable' etc.
  //
  // 3. Actually pull the requested chunks out of the buffer and return.
  // if we need a readable event, then we need to do some reading.


  var doRead = state.needReadable;
  debug('need readable', doRead); // if we currently have less than the highWaterMark, then also read some

  if (state.length === 0 || state.length - n < state.highWaterMark) {
    doRead = true;
    debug('length less than watermark', doRead);
  } // however, if we've ended, then there's no point, and if we're already
  // reading, then it's unnecessary.


  if (state.ended || state.reading) {
    doRead = false;
    debug('reading or ended', doRead);
  } else if (doRead) {
    debug('do read');
    state.reading = true;
    state.sync = true; // if the length is currently zero, then we *need* a readable event.

    if (state.length === 0) state.needReadable = true; // call internal read method

    this._read(state.highWaterMark);

    state.sync = false; // If _read pushed data synchronously, then `reading` will be false,
    // and we need to re-evaluate how much data we can return to the user.

    if (!state.reading) n = howMuchToRead(nOrig, state);
  }

  var ret;
  if (n > 0) ret = fromList(n, state);else ret = null;

  if (ret === null) {
    state.needReadable = state.length <= state.highWaterMark;
    n = 0;
  } else {
    state.length -= n;
    state.awaitDrain = 0;
  }

  if (state.length === 0) {
    // If we have nothing in the buffer, then we want to know
    // as soon as we *do* get something into the buffer.
    if (!state.ended) state.needReadable = true; // If we tried to read() past the EOF, then emit end on the next tick.

    if (nOrig !== n && state.ended) endReadable(this);
  }

  if (ret !== null) this.emit('data', ret);
  return ret;
};

function onEofChunk(stream, state) {
  debug('onEofChunk');
  if (state.ended) return;

  if (state.decoder) {
    var chunk = state.decoder.end();

    if (chunk && chunk.length) {
      state.buffer.push(chunk);
      state.length += state.objectMode ? 1 : chunk.length;
    }
  }

  state.ended = true;

  if (state.sync) {
    // if we are sync, wait until next tick to emit the data.
    // Otherwise we risk emitting data in the flow()
    // the readable code triggers during a read() call
    emitReadable(stream);
  } else {
    // emit 'readable' now to make sure it gets picked up.
    state.needReadable = false;

    if (!state.emittedReadable) {
      state.emittedReadable = true;
      emitReadable_(stream);
    }
  }
} // Don't emit readable right away in sync mode, because this can trigger
// another read() call => stack overflow.  This way, it might trigger
// a nextTick recursion warning, but that's not so bad.


function emitReadable(stream) {
  var state = stream._readableState;
  debug('emitReadable', state.needReadable, state.emittedReadable);
  state.needReadable = false;

  if (!state.emittedReadable) {
    debug('emitReadable', state.flowing);
    state.emittedReadable = true;
    process.nextTick(emitReadable_, stream);
  }
}

function emitReadable_(stream) {
  var state = stream._readableState;
  debug('emitReadable_', state.destroyed, state.length, state.ended);

  if (!state.destroyed && (state.length || state.ended)) {
    stream.emit('readable');
    state.emittedReadable = false;
  } // The stream needs another readable event if
  // 1. It is not flowing, as the flow mechanism will take
  //    care of it.
  // 2. It is not ended.
  // 3. It is below the highWaterMark, so we can schedule
  //    another readable later.


  state.needReadable = !state.flowing && !state.ended && state.length <= state.highWaterMark;
  flow(stream);
} // at this point, the user has presumably seen the 'readable' event,
// and called read() to consume some data.  that may have triggered
// in turn another _read(n) call, in which case reading = true if
// it's in progress.
// However, if we're not ended, or reading, and the length < hwm,
// then go ahead and try to read some more preemptively.


function maybeReadMore(stream, state) {
  if (!state.readingMore) {
    state.readingMore = true;
    process.nextTick(maybeReadMore_, stream, state);
  }
}

function maybeReadMore_(stream, state) {
  // Attempt to read more data if we should.
  //
  // The conditions for reading more data are (one of):
  // - Not enough data buffered (state.length < state.highWaterMark). The loop
  //   is responsible for filling the buffer with enough data if such data
  //   is available. If highWaterMark is 0 and we are not in the flowing mode
  //   we should _not_ attempt to buffer any extra data. We'll get more data
  //   when the stream consumer calls read() instead.
  // - No data in the buffer, and the stream is in flowing mode. In this mode
  //   the loop below is responsible for ensuring read() is called. Failing to
  //   call read here would abort the flow and there's no other mechanism for
  //   continuing the flow if the stream consumer has just subscribed to the
  //   'data' event.
  //
  // In addition to the above conditions to keep reading data, the following
  // conditions prevent the data from being read:
  // - The stream has ended (state.ended).
  // - There is already a pending 'read' operation (state.reading). This is a
  //   case where the the stream has called the implementation defined _read()
  //   method, but they are processing the call asynchronously and have _not_
  //   called push() with new data. In this case we skip performing more
  //   read()s. The execution ends in this method again after the _read() ends
  //   up calling push() with more data.
  while (!state.reading && !state.ended && (state.length < state.highWaterMark || state.flowing && state.length === 0)) {
    var len = state.length;
    debug('maybeReadMore read 0');
    stream.read(0);
    if (len === state.length) // didn't get any data, stop spinning.
      break;
  }

  state.readingMore = false;
} // abstract method.  to be overridden in specific implementation classes.
// call cb(er, data) where data is <= n in length.
// for virtual (non-string, non-buffer) streams, "length" is somewhat
// arbitrary, and perhaps not very meaningful.


Readable.prototype._read = function (n) {
  errorOrDestroy(this, new ERR_METHOD_NOT_IMPLEMENTED('_read()'));
};

Readable.prototype.pipe = function (dest, pipeOpts) {
  var src = this;
  var state = this._readableState;

  switch (state.pipesCount) {
    case 0:
      state.pipes = dest;
      break;

    case 1:
      state.pipes = [state.pipes, dest];
      break;

    default:
      state.pipes.push(dest);
      break;
  }

  state.pipesCount += 1;
  debug('pipe count=%d opts=%j', state.pipesCount, pipeOpts);
  var doEnd = (!pipeOpts || pipeOpts.end !== false) && dest !== process.stdout && dest !== process.stderr;
  var endFn = doEnd ? onend : unpipe;
  if (state.endEmitted) process.nextTick(endFn);else src.once('end', endFn);
  dest.on('unpipe', onunpipe);

  function onunpipe(readable, unpipeInfo) {
    debug('onunpipe');

    if (readable === src) {
      if (unpipeInfo && unpipeInfo.hasUnpiped === false) {
        unpipeInfo.hasUnpiped = true;
        cleanup();
      }
    }
  }

  function onend() {
    debug('onend');
    dest.end();
  } // when the dest drains, it reduces the awaitDrain counter
  // on the source.  This would be more elegant with a .once()
  // handler in flow(), but adding and removing repeatedly is
  // too slow.


  var ondrain = pipeOnDrain(src);
  dest.on('drain', ondrain);
  var cleanedUp = false;

  function cleanup() {
    debug('cleanup'); // cleanup event handlers once the pipe is broken

    dest.removeListener('close', onclose);
    dest.removeListener('finish', onfinish);
    dest.removeListener('drain', ondrain);
    dest.removeListener('error', onerror);
    dest.removeListener('unpipe', onunpipe);
    src.removeListener('end', onend);
    src.removeListener('end', unpipe);
    src.removeListener('data', ondata);
    cleanedUp = true; // if the reader is waiting for a drain event from this
    // specific writer, then it would cause it to never start
    // flowing again.
    // So, if this is awaiting a drain, then we just call it now.
    // If we don't know, then assume that we are waiting for one.

    if (state.awaitDrain && (!dest._writableState || dest._writableState.needDrain)) ondrain();
  }

  src.on('data', ondata);

  function ondata(chunk) {
    debug('ondata');
    var ret = dest.write(chunk);
    debug('dest.write', ret);

    if (ret === false) {
      // If the user unpiped during `dest.write()`, it is possible
      // to get stuck in a permanently paused state if that write
      // also returned false.
      // => Check whether `dest` is still a piping destination.
      if ((state.pipesCount === 1 && state.pipes === dest || state.pipesCount > 1 && indexOf(state.pipes, dest) !== -1) && !cleanedUp) {
        debug('false write response, pause', state.awaitDrain);
        state.awaitDrain++;
      }

      src.pause();
    }
  } // if the dest has an error, then stop piping into it.
  // however, don't suppress the throwing behavior for this.


  function onerror(er) {
    debug('onerror', er);
    unpipe();
    dest.removeListener('error', onerror);
    if (EElistenerCount(dest, 'error') === 0) errorOrDestroy(dest, er);
  } // Make sure our error handler is attached before userland ones.


  prependListener(dest, 'error', onerror); // Both close and finish should trigger unpipe, but only once.

  function onclose() {
    dest.removeListener('finish', onfinish);
    unpipe();
  }

  dest.once('close', onclose);

  function onfinish() {
    debug('onfinish');
    dest.removeListener('close', onclose);
    unpipe();
  }

  dest.once('finish', onfinish);

  function unpipe() {
    debug('unpipe');
    src.unpipe(dest);
  } // tell the dest that it's being piped to


  dest.emit('pipe', src); // start the flow if it hasn't been started already.

  if (!state.flowing) {
    debug('pipe resume');
    src.resume();
  }

  return dest;
};

function pipeOnDrain(src) {
  return function pipeOnDrainFunctionResult() {
    var state = src._readableState;
    debug('pipeOnDrain', state.awaitDrain);
    if (state.awaitDrain) state.awaitDrain--;

    if (state.awaitDrain === 0 && EElistenerCount(src, 'data')) {
      state.flowing = true;
      flow(src);
    }
  };
}

Readable.prototype.unpipe = function (dest) {
  var state = this._readableState;
  var unpipeInfo = {
    hasUnpiped: false
  }; // if we're not piping anywhere, then do nothing.

  if (state.pipesCount === 0) return this; // just one destination.  most common case.

  if (state.pipesCount === 1) {
    // passed in one, but it's not the right one.
    if (dest && dest !== state.pipes) return this;
    if (!dest) dest = state.pipes; // got a match.

    state.pipes = null;
    state.pipesCount = 0;
    state.flowing = false;
    if (dest) dest.emit('unpipe', this, unpipeInfo);
    return this;
  } // slow case. multiple pipe destinations.


  if (!dest) {
    // remove all.
    var dests = state.pipes;
    var len = state.pipesCount;
    state.pipes = null;
    state.pipesCount = 0;
    state.flowing = false;

    for (var i = 0; i < len; i++) {
      dests[i].emit('unpipe', this, {
        hasUnpiped: false
      });
    }

    return this;
  } // try to find the right one.


  var index = indexOf(state.pipes, dest);
  if (index === -1) return this;
  state.pipes.splice(index, 1);
  state.pipesCount -= 1;
  if (state.pipesCount === 1) state.pipes = state.pipes[0];
  dest.emit('unpipe', this, unpipeInfo);
  return this;
}; // set up data events if they are asked for
// Ensure readable listeners eventually get something


Readable.prototype.on = function (ev, fn) {
  var res = Stream.prototype.on.call(this, ev, fn);
  var state = this._readableState;

  if (ev === 'data') {
    // update readableListening so that resume() may be a no-op
    // a few lines down. This is needed to support once('readable').
    state.readableListening = this.listenerCount('readable') > 0; // Try start flowing on next tick if stream isn't explicitly paused

    if (state.flowing !== false) this.resume();
  } else if (ev === 'readable') {
    if (!state.endEmitted && !state.readableListening) {
      state.readableListening = state.needReadable = true;
      state.flowing = false;
      state.emittedReadable = false;
      debug('on readable', state.length, state.reading);

      if (state.length) {
        emitReadable(this);
      } else if (!state.reading) {
        process.nextTick(nReadingNextTick, this);
      }
    }
  }

  return res;
};

Readable.prototype.addListener = Readable.prototype.on;

Readable.prototype.removeListener = function (ev, fn) {
  var res = Stream.prototype.removeListener.call(this, ev, fn);

  if (ev === 'readable') {
    // We need to check if there is someone still listening to
    // readable and reset the state. However this needs to happen
    // after readable has been emitted but before I/O (nextTick) to
    // support once('readable', fn) cycles. This means that calling
    // resume within the same tick will have no
    // effect.
    process.nextTick(updateReadableListening, this);
  }

  return res;
};

Readable.prototype.removeAllListeners = function (ev) {
  var res = Stream.prototype.removeAllListeners.apply(this, arguments);

  if (ev === 'readable' || ev === undefined) {
    // We need to check if there is someone still listening to
    // readable and reset the state. However this needs to happen
    // after readable has been emitted but before I/O (nextTick) to
    // support once('readable', fn) cycles. This means that calling
    // resume within the same tick will have no
    // effect.
    process.nextTick(updateReadableListening, this);
  }

  return res;
};

function updateReadableListening(self) {
  var state = self._readableState;
  state.readableListening = self.listenerCount('readable') > 0;

  if (state.resumeScheduled && !state.paused) {
    // flowing needs to be set to true now, otherwise
    // the upcoming resume will not flow.
    state.flowing = true; // crude way to check if we should resume
  } else if (self.listenerCount('data') > 0) {
    self.resume();
  }
}

function nReadingNextTick(self) {
  debug('readable nexttick read 0');
  self.read(0);
} // pause() and resume() are remnants of the legacy readable stream API
// If the user uses them, then switch into old mode.


Readable.prototype.resume = function () {
  var state = this._readableState;

  if (!state.flowing) {
    debug('resume'); // we flow only if there is no one listening
    // for readable, but we still have to call
    // resume()

    state.flowing = !state.readableListening;
    resume(this, state);
  }

  state.paused = false;
  return this;
};

function resume(stream, state) {
  if (!state.resumeScheduled) {
    state.resumeScheduled = true;
    process.nextTick(resume_, stream, state);
  }
}

function resume_(stream, state) {
  debug('resume', state.reading);

  if (!state.reading) {
    stream.read(0);
  }

  state.resumeScheduled = false;
  stream.emit('resume');
  flow(stream);
  if (state.flowing && !state.reading) stream.read(0);
}

Readable.prototype.pause = function () {
  debug('call pause flowing=%j', this._readableState.flowing);

  if (this._readableState.flowing !== false) {
    debug('pause');
    this._readableState.flowing = false;
    this.emit('pause');
  }

  this._readableState.paused = true;
  return this;
};

function flow(stream) {
  var state = stream._readableState;
  debug('flow', state.flowing);

  while (state.flowing && stream.read() !== null) {
    ;
  }
} // wrap an old-style stream as the async data source.
// This is *not* part of the readable stream interface.
// It is an ugly unfortunate mess of history.


Readable.prototype.wrap = function (stream) {
  var _this = this;

  var state = this._readableState;
  var paused = false;
  stream.on('end', function () {
    debug('wrapped end');

    if (state.decoder && !state.ended) {
      var chunk = state.decoder.end();
      if (chunk && chunk.length) _this.push(chunk);
    }

    _this.push(null);
  });
  stream.on('data', function (chunk) {
    debug('wrapped data');
    if (state.decoder) chunk = state.decoder.write(chunk); // don't skip over falsy values in objectMode

    if (state.objectMode && (chunk === null || chunk === undefined)) return;else if (!state.objectMode && (!chunk || !chunk.length)) return;

    var ret = _this.push(chunk);

    if (!ret) {
      paused = true;
      stream.pause();
    }
  }); // proxy all the other methods.
  // important when wrapping filters and duplexes.

  for (var i in stream) {
    if (this[i] === undefined && typeof stream[i] === 'function') {
      this[i] = function methodWrap(method) {
        return function methodWrapReturnFunction() {
          return stream[method].apply(stream, arguments);
        };
      }(i);
    }
  } // proxy certain important events.


  for (var n = 0; n < kProxyEvents.length; n++) {
    stream.on(kProxyEvents[n], this.emit.bind(this, kProxyEvents[n]));
  } // when we try to consume some more bytes, simply unpause the
  // underlying stream.


  this._read = function (n) {
    debug('wrapped _read', n);

    if (paused) {
      paused = false;
      stream.resume();
    }
  };

  return this;
};

if (typeof Symbol === 'function') {
  Readable.prototype[Symbol.asyncIterator] = function () {
    if (createReadableStreamAsyncIterator === undefined) {
      createReadableStreamAsyncIterator = __webpack_require__(5850);
    }

    return createReadableStreamAsyncIterator(this);
  };
}

Object.defineProperty(Readable.prototype, 'readableHighWaterMark', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._readableState.highWaterMark;
  }
});
Object.defineProperty(Readable.prototype, 'readableBuffer', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._readableState && this._readableState.buffer;
  }
});
Object.defineProperty(Readable.prototype, 'readableFlowing', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._readableState.flowing;
  },
  set: function set(state) {
    if (this._readableState) {
      this._readableState.flowing = state;
    }
  }
}); // exposed for testing purposes only.

Readable._fromList = fromList;
Object.defineProperty(Readable.prototype, 'readableLength', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._readableState.length;
  }
}); // Pluck off n bytes from an array of buffers.
// Length is the combined lengths of all the buffers in the list.
// This function is designed to be inlinable, so please take care when making
// changes to the function body.

function fromList(n, state) {
  // nothing buffered
  if (state.length === 0) return null;
  var ret;
  if (state.objectMode) ret = state.buffer.shift();else if (!n || n >= state.length) {
    // read it all, truncate the list
    if (state.decoder) ret = state.buffer.join('');else if (state.buffer.length === 1) ret = state.buffer.first();else ret = state.buffer.concat(state.length);
    state.buffer.clear();
  } else {
    // read part of list
    ret = state.buffer.consume(n, state.decoder);
  }
  return ret;
}

function endReadable(stream) {
  var state = stream._readableState;
  debug('endReadable', state.endEmitted);

  if (!state.endEmitted) {
    state.ended = true;
    process.nextTick(endReadableNT, state, stream);
  }
}

function endReadableNT(state, stream) {
  debug('endReadableNT', state.endEmitted, state.length); // Check that we didn't get one last unshift.

  if (!state.endEmitted && state.length === 0) {
    state.endEmitted = true;
    stream.readable = false;
    stream.emit('end');

    if (state.autoDestroy) {
      // In case of duplex streams we need a way to detect
      // if the writable side is ready for autoDestroy as well
      var wState = stream._writableState;

      if (!wState || wState.autoDestroy && wState.finished) {
        stream.destroy();
      }
    }
  }
}

if (typeof Symbol === 'function') {
  Readable.from = function (iterable, opts) {
    if (from === undefined) {
      from = __webpack_require__(6307);
    }

    return from(Readable, iterable, opts);
  };
}

function indexOf(xs, x) {
  for (var i = 0, l = xs.length; i < l; i++) {
    if (xs[i] === x) return i;
  }

  return -1;
}

/***/ }),

/***/ 4605:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.
// a transform stream is a readable/writable stream where you do
// something with the data.  Sometimes it's called a "filter",
// but that's not a great name for it, since that implies a thing where
// some bits pass through, and others are simply ignored.  (That would
// be a valid example of a transform, of course.)
//
// While the output is causally related to the input, it's not a
// necessarily symmetric or synchronous transformation.  For example,
// a zlib stream might take multiple plain-text writes(), and then
// emit a single compressed chunk some time in the future.
//
// Here's how this works:
//
// The Transform stream has all the aspects of the readable and writable
// stream classes.  When you write(chunk), that calls _write(chunk,cb)
// internally, and returns false if there's a lot of pending writes
// buffered up.  When you call read(), that calls _read(n) until
// there's enough pending readable data buffered up.
//
// In a transform stream, the written data is placed in a buffer.  When
// _read(n) is called, it transforms the queued up data, calling the
// buffered _write cb's as it consumes chunks.  If consuming a single
// written chunk would result in multiple output chunks, then the first
// outputted bit calls the readcb, and subsequent chunks just go into
// the read buffer, and will cause it to emit 'readable' if necessary.
//
// This way, back-pressure is actually determined by the reading side,
// since _read has to be called to start processing a new chunk.  However,
// a pathological inflate type of transform can cause excessive buffering
// here.  For example, imagine a stream where every byte of input is
// interpreted as an integer from 0-255, and then results in that many
// bytes of output.  Writing the 4 bytes {ff,ff,ff,ff} would result in
// 1kb of data being output.  In this case, you could write a very small
// amount of input, and end up with a very large amount of output.  In
// such a pathological inflating mechanism, there'd be no way to tell
// the system to stop doing the transform.  A single 4MB write could
// cause the system to run out of memory.
//
// However, even in such a pathological case, only a single written chunk
// would be consumed, and then the rest would wait (un-transformed) until
// the results of the previous transformed chunk were consumed.


module.exports = Transform;

var _require$codes = __webpack_require__(4012)/* .codes */ .q,
    ERR_METHOD_NOT_IMPLEMENTED = _require$codes.ERR_METHOD_NOT_IMPLEMENTED,
    ERR_MULTIPLE_CALLBACK = _require$codes.ERR_MULTIPLE_CALLBACK,
    ERR_TRANSFORM_ALREADY_TRANSFORMING = _require$codes.ERR_TRANSFORM_ALREADY_TRANSFORMING,
    ERR_TRANSFORM_WITH_LENGTH_0 = _require$codes.ERR_TRANSFORM_WITH_LENGTH_0;

var Duplex = __webpack_require__(6753);

__webpack_require__(4378)(Transform, Duplex);

function afterTransform(er, data) {
  var ts = this._transformState;
  ts.transforming = false;
  var cb = ts.writecb;

  if (cb === null) {
    return this.emit('error', new ERR_MULTIPLE_CALLBACK());
  }

  ts.writechunk = null;
  ts.writecb = null;
  if (data != null) // single equals check for both `null` and `undefined`
    this.push(data);
  cb(er);
  var rs = this._readableState;
  rs.reading = false;

  if (rs.needReadable || rs.length < rs.highWaterMark) {
    this._read(rs.highWaterMark);
  }
}

function Transform(options) {
  if (!(this instanceof Transform)) return new Transform(options);
  Duplex.call(this, options);
  this._transformState = {
    afterTransform: afterTransform.bind(this),
    needTransform: false,
    transforming: false,
    writecb: null,
    writechunk: null,
    writeencoding: null
  }; // start out asking for a readable event once data is transformed.

  this._readableState.needReadable = true; // we have implemented the _read method, and done the other things
  // that Readable wants before the first _read call, so unset the
  // sync guard flag.

  this._readableState.sync = false;

  if (options) {
    if (typeof options.transform === 'function') this._transform = options.transform;
    if (typeof options.flush === 'function') this._flush = options.flush;
  } // When the writable side finishes, then flush out anything remaining.


  this.on('prefinish', prefinish);
}

function prefinish() {
  var _this = this;

  if (typeof this._flush === 'function' && !this._readableState.destroyed) {
    this._flush(function (er, data) {
      done(_this, er, data);
    });
  } else {
    done(this, null, null);
  }
}

Transform.prototype.push = function (chunk, encoding) {
  this._transformState.needTransform = false;
  return Duplex.prototype.push.call(this, chunk, encoding);
}; // This is the part where you do stuff!
// override this function in implementation classes.
// 'chunk' is an input chunk.
//
// Call `push(newChunk)` to pass along transformed output
// to the readable side.  You may call 'push' zero or more times.
//
// Call `cb(err)` when you are done with this chunk.  If you pass
// an error, then that'll put the hurt on the whole operation.  If you
// never call cb(), then you'll never get another chunk.


Transform.prototype._transform = function (chunk, encoding, cb) {
  cb(new ERR_METHOD_NOT_IMPLEMENTED('_transform()'));
};

Transform.prototype._write = function (chunk, encoding, cb) {
  var ts = this._transformState;
  ts.writecb = cb;
  ts.writechunk = chunk;
  ts.writeencoding = encoding;

  if (!ts.transforming) {
    var rs = this._readableState;
    if (ts.needTransform || rs.needReadable || rs.length < rs.highWaterMark) this._read(rs.highWaterMark);
  }
}; // Doesn't matter what the args are here.
// _transform does all the work.
// That we got here means that the readable side wants more data.


Transform.prototype._read = function (n) {
  var ts = this._transformState;

  if (ts.writechunk !== null && !ts.transforming) {
    ts.transforming = true;

    this._transform(ts.writechunk, ts.writeencoding, ts.afterTransform);
  } else {
    // mark that we need a transform, so that any data that comes in
    // will get processed, now that we've asked for it.
    ts.needTransform = true;
  }
};

Transform.prototype._destroy = function (err, cb) {
  Duplex.prototype._destroy.call(this, err, function (err2) {
    cb(err2);
  });
};

function done(stream, er, data) {
  if (er) return stream.emit('error', er);
  if (data != null) // single equals check for both `null` and `undefined`
    stream.push(data); // TODO(BridgeAR): Write a test for these two error cases
  // if there's nothing in the write buffer, then that means
  // that nothing more will ever be provided

  if (stream._writableState.length) throw new ERR_TRANSFORM_WITH_LENGTH_0();
  if (stream._transformState.transforming) throw new ERR_TRANSFORM_ALREADY_TRANSFORMING();
  return stream.push(null);
}

/***/ }),

/***/ 4229:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.
// A bit simpler than readable streams.
// Implement an async ._write(chunk, encoding, cb), and it'll handle all
// the drain event emission and buffering.


module.exports = Writable;
/* <replacement> */

function WriteReq(chunk, encoding, cb) {
  this.chunk = chunk;
  this.encoding = encoding;
  this.callback = cb;
  this.next = null;
} // It seems a linked list but it is not
// there will be only 2 of these for each stream


function CorkedRequest(state) {
  var _this = this;

  this.next = null;
  this.entry = null;

  this.finish = function () {
    onCorkedFinish(_this, state);
  };
}
/* </replacement> */

/*<replacement>*/


var Duplex;
/*</replacement>*/

Writable.WritableState = WritableState;
/*<replacement>*/

var internalUtil = {
  deprecate: __webpack_require__(1159)
};
/*</replacement>*/

/*<replacement>*/

var Stream = __webpack_require__(9740);
/*</replacement>*/


var Buffer = __webpack_require__(4293).Buffer;

var OurUint8Array = global.Uint8Array || function () {};

function _uint8ArrayToBuffer(chunk) {
  return Buffer.from(chunk);
}

function _isUint8Array(obj) {
  return Buffer.isBuffer(obj) || obj instanceof OurUint8Array;
}

var destroyImpl = __webpack_require__(1195);

var _require = __webpack_require__(2457),
    getHighWaterMark = _require.getHighWaterMark;

var _require$codes = __webpack_require__(4012)/* .codes */ .q,
    ERR_INVALID_ARG_TYPE = _require$codes.ERR_INVALID_ARG_TYPE,
    ERR_METHOD_NOT_IMPLEMENTED = _require$codes.ERR_METHOD_NOT_IMPLEMENTED,
    ERR_MULTIPLE_CALLBACK = _require$codes.ERR_MULTIPLE_CALLBACK,
    ERR_STREAM_CANNOT_PIPE = _require$codes.ERR_STREAM_CANNOT_PIPE,
    ERR_STREAM_DESTROYED = _require$codes.ERR_STREAM_DESTROYED,
    ERR_STREAM_NULL_VALUES = _require$codes.ERR_STREAM_NULL_VALUES,
    ERR_STREAM_WRITE_AFTER_END = _require$codes.ERR_STREAM_WRITE_AFTER_END,
    ERR_UNKNOWN_ENCODING = _require$codes.ERR_UNKNOWN_ENCODING;

var errorOrDestroy = destroyImpl.errorOrDestroy;

__webpack_require__(4378)(Writable, Stream);

function nop() {}

function WritableState(options, stream, isDuplex) {
  Duplex = Duplex || __webpack_require__(6753);
  options = options || {}; // Duplex streams are both readable and writable, but share
  // the same options object.
  // However, some cases require setting options to different
  // values for the readable and the writable sides of the duplex stream,
  // e.g. options.readableObjectMode vs. options.writableObjectMode, etc.

  if (typeof isDuplex !== 'boolean') isDuplex = stream instanceof Duplex; // object stream flag to indicate whether or not this stream
  // contains buffers or objects.

  this.objectMode = !!options.objectMode;
  if (isDuplex) this.objectMode = this.objectMode || !!options.writableObjectMode; // the point at which write() starts returning false
  // Note: 0 is a valid value, means that we always return false if
  // the entire buffer is not flushed immediately on write()

  this.highWaterMark = getHighWaterMark(this, options, 'writableHighWaterMark', isDuplex); // if _final has been called

  this.finalCalled = false; // drain event flag.

  this.needDrain = false; // at the start of calling end()

  this.ending = false; // when end() has been called, and returned

  this.ended = false; // when 'finish' is emitted

  this.finished = false; // has it been destroyed

  this.destroyed = false; // should we decode strings into buffers before passing to _write?
  // this is here so that some node-core streams can optimize string
  // handling at a lower level.

  var noDecode = options.decodeStrings === false;
  this.decodeStrings = !noDecode; // Crypto is kind of old and crusty.  Historically, its default string
  // encoding is 'binary' so we have to make this configurable.
  // Everything else in the universe uses 'utf8', though.

  this.defaultEncoding = options.defaultEncoding || 'utf8'; // not an actual buffer we keep track of, but a measurement
  // of how much we're waiting to get pushed to some underlying
  // socket or file.

  this.length = 0; // a flag to see when we're in the middle of a write.

  this.writing = false; // when true all writes will be buffered until .uncork() call

  this.corked = 0; // a flag to be able to tell if the onwrite cb is called immediately,
  // or on a later tick.  We set this to true at first, because any
  // actions that shouldn't happen until "later" should generally also
  // not happen before the first write call.

  this.sync = true; // a flag to know if we're processing previously buffered items, which
  // may call the _write() callback in the same tick, so that we don't
  // end up in an overlapped onwrite situation.

  this.bufferProcessing = false; // the callback that's passed to _write(chunk,cb)

  this.onwrite = function (er) {
    onwrite(stream, er);
  }; // the callback that the user supplies to write(chunk,encoding,cb)


  this.writecb = null; // the amount that is being written when _write is called.

  this.writelen = 0;
  this.bufferedRequest = null;
  this.lastBufferedRequest = null; // number of pending user-supplied write callbacks
  // this must be 0 before 'finish' can be emitted

  this.pendingcb = 0; // emit prefinish if the only thing we're waiting for is _write cbs
  // This is relevant for synchronous Transform streams

  this.prefinished = false; // True if the error was already emitted and should not be thrown again

  this.errorEmitted = false; // Should close be emitted on destroy. Defaults to true.

  this.emitClose = options.emitClose !== false; // Should .destroy() be called after 'finish' (and potentially 'end')

  this.autoDestroy = !!options.autoDestroy; // count buffered requests

  this.bufferedRequestCount = 0; // allocate the first CorkedRequest, there is always
  // one allocated and free to use, and we maintain at most two

  this.corkedRequestsFree = new CorkedRequest(this);
}

WritableState.prototype.getBuffer = function getBuffer() {
  var current = this.bufferedRequest;
  var out = [];

  while (current) {
    out.push(current);
    current = current.next;
  }

  return out;
};

(function () {
  try {
    Object.defineProperty(WritableState.prototype, 'buffer', {
      get: internalUtil.deprecate(function writableStateBufferGetter() {
        return this.getBuffer();
      }, '_writableState.buffer is deprecated. Use _writableState.getBuffer ' + 'instead.', 'DEP0003')
    });
  } catch (_) {}
})(); // Test _writableState for inheritance to account for Duplex streams,
// whose prototype chain only points to Readable.


var realHasInstance;

if (typeof Symbol === 'function' && Symbol.hasInstance && typeof Function.prototype[Symbol.hasInstance] === 'function') {
  realHasInstance = Function.prototype[Symbol.hasInstance];
  Object.defineProperty(Writable, Symbol.hasInstance, {
    value: function value(object) {
      if (realHasInstance.call(this, object)) return true;
      if (this !== Writable) return false;
      return object && object._writableState instanceof WritableState;
    }
  });
} else {
  realHasInstance = function realHasInstance(object) {
    return object instanceof this;
  };
}

function Writable(options) {
  Duplex = Duplex || __webpack_require__(6753); // Writable ctor is applied to Duplexes, too.
  // `realHasInstance` is necessary because using plain `instanceof`
  // would return false, as no `_writableState` property is attached.
  // Trying to use the custom `instanceof` for Writable here will also break the
  // Node.js LazyTransform implementation, which has a non-trivial getter for
  // `_writableState` that would lead to infinite recursion.
  // Checking for a Stream.Duplex instance is faster here instead of inside
  // the WritableState constructor, at least with V8 6.5

  var isDuplex = this instanceof Duplex;
  if (!isDuplex && !realHasInstance.call(Writable, this)) return new Writable(options);
  this._writableState = new WritableState(options, this, isDuplex); // legacy.

  this.writable = true;

  if (options) {
    if (typeof options.write === 'function') this._write = options.write;
    if (typeof options.writev === 'function') this._writev = options.writev;
    if (typeof options.destroy === 'function') this._destroy = options.destroy;
    if (typeof options.final === 'function') this._final = options.final;
  }

  Stream.call(this);
} // Otherwise people can pipe Writable streams, which is just wrong.


Writable.prototype.pipe = function () {
  errorOrDestroy(this, new ERR_STREAM_CANNOT_PIPE());
};

function writeAfterEnd(stream, cb) {
  var er = new ERR_STREAM_WRITE_AFTER_END(); // TODO: defer error events consistently everywhere, not just the cb

  errorOrDestroy(stream, er);
  process.nextTick(cb, er);
} // Checks that a user-supplied chunk is valid, especially for the particular
// mode the stream is in. Currently this means that `null` is never accepted
// and undefined/non-string values are only allowed in object mode.


function validChunk(stream, state, chunk, cb) {
  var er;

  if (chunk === null) {
    er = new ERR_STREAM_NULL_VALUES();
  } else if (typeof chunk !== 'string' && !state.objectMode) {
    er = new ERR_INVALID_ARG_TYPE('chunk', ['string', 'Buffer'], chunk);
  }

  if (er) {
    errorOrDestroy(stream, er);
    process.nextTick(cb, er);
    return false;
  }

  return true;
}

Writable.prototype.write = function (chunk, encoding, cb) {
  var state = this._writableState;
  var ret = false;

  var isBuf = !state.objectMode && _isUint8Array(chunk);

  if (isBuf && !Buffer.isBuffer(chunk)) {
    chunk = _uint8ArrayToBuffer(chunk);
  }

  if (typeof encoding === 'function') {
    cb = encoding;
    encoding = null;
  }

  if (isBuf) encoding = 'buffer';else if (!encoding) encoding = state.defaultEncoding;
  if (typeof cb !== 'function') cb = nop;
  if (state.ending) writeAfterEnd(this, cb);else if (isBuf || validChunk(this, state, chunk, cb)) {
    state.pendingcb++;
    ret = writeOrBuffer(this, state, isBuf, chunk, encoding, cb);
  }
  return ret;
};

Writable.prototype.cork = function () {
  this._writableState.corked++;
};

Writable.prototype.uncork = function () {
  var state = this._writableState;

  if (state.corked) {
    state.corked--;
    if (!state.writing && !state.corked && !state.bufferProcessing && state.bufferedRequest) clearBuffer(this, state);
  }
};

Writable.prototype.setDefaultEncoding = function setDefaultEncoding(encoding) {
  // node::ParseEncoding() requires lower case.
  if (typeof encoding === 'string') encoding = encoding.toLowerCase();
  if (!(['hex', 'utf8', 'utf-8', 'ascii', 'binary', 'base64', 'ucs2', 'ucs-2', 'utf16le', 'utf-16le', 'raw'].indexOf((encoding + '').toLowerCase()) > -1)) throw new ERR_UNKNOWN_ENCODING(encoding);
  this._writableState.defaultEncoding = encoding;
  return this;
};

Object.defineProperty(Writable.prototype, 'writableBuffer', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._writableState && this._writableState.getBuffer();
  }
});

function decodeChunk(state, chunk, encoding) {
  if (!state.objectMode && state.decodeStrings !== false && typeof chunk === 'string') {
    chunk = Buffer.from(chunk, encoding);
  }

  return chunk;
}

Object.defineProperty(Writable.prototype, 'writableHighWaterMark', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._writableState.highWaterMark;
  }
}); // if we're already writing something, then just put this
// in the queue, and wait our turn.  Otherwise, call _write
// If we return false, then we need a drain event, so set that flag.

function writeOrBuffer(stream, state, isBuf, chunk, encoding, cb) {
  if (!isBuf) {
    var newChunk = decodeChunk(state, chunk, encoding);

    if (chunk !== newChunk) {
      isBuf = true;
      encoding = 'buffer';
      chunk = newChunk;
    }
  }

  var len = state.objectMode ? 1 : chunk.length;
  state.length += len;
  var ret = state.length < state.highWaterMark; // we must ensure that previous needDrain will not be reset to false.

  if (!ret) state.needDrain = true;

  if (state.writing || state.corked) {
    var last = state.lastBufferedRequest;
    state.lastBufferedRequest = {
      chunk: chunk,
      encoding: encoding,
      isBuf: isBuf,
      callback: cb,
      next: null
    };

    if (last) {
      last.next = state.lastBufferedRequest;
    } else {
      state.bufferedRequest = state.lastBufferedRequest;
    }

    state.bufferedRequestCount += 1;
  } else {
    doWrite(stream, state, false, len, chunk, encoding, cb);
  }

  return ret;
}

function doWrite(stream, state, writev, len, chunk, encoding, cb) {
  state.writelen = len;
  state.writecb = cb;
  state.writing = true;
  state.sync = true;
  if (state.destroyed) state.onwrite(new ERR_STREAM_DESTROYED('write'));else if (writev) stream._writev(chunk, state.onwrite);else stream._write(chunk, encoding, state.onwrite);
  state.sync = false;
}

function onwriteError(stream, state, sync, er, cb) {
  --state.pendingcb;

  if (sync) {
    // defer the callback if we are being called synchronously
    // to avoid piling up things on the stack
    process.nextTick(cb, er); // this can emit finish, and it will always happen
    // after error

    process.nextTick(finishMaybe, stream, state);
    stream._writableState.errorEmitted = true;
    errorOrDestroy(stream, er);
  } else {
    // the caller expect this to happen before if
    // it is async
    cb(er);
    stream._writableState.errorEmitted = true;
    errorOrDestroy(stream, er); // this can emit finish, but finish must
    // always follow error

    finishMaybe(stream, state);
  }
}

function onwriteStateUpdate(state) {
  state.writing = false;
  state.writecb = null;
  state.length -= state.writelen;
  state.writelen = 0;
}

function onwrite(stream, er) {
  var state = stream._writableState;
  var sync = state.sync;
  var cb = state.writecb;
  if (typeof cb !== 'function') throw new ERR_MULTIPLE_CALLBACK();
  onwriteStateUpdate(state);
  if (er) onwriteError(stream, state, sync, er, cb);else {
    // Check if we're actually ready to finish, but don't emit yet
    var finished = needFinish(state) || stream.destroyed;

    if (!finished && !state.corked && !state.bufferProcessing && state.bufferedRequest) {
      clearBuffer(stream, state);
    }

    if (sync) {
      process.nextTick(afterWrite, stream, state, finished, cb);
    } else {
      afterWrite(stream, state, finished, cb);
    }
  }
}

function afterWrite(stream, state, finished, cb) {
  if (!finished) onwriteDrain(stream, state);
  state.pendingcb--;
  cb();
  finishMaybe(stream, state);
} // Must force callback to be called on nextTick, so that we don't
// emit 'drain' before the write() consumer gets the 'false' return
// value, and has a chance to attach a 'drain' listener.


function onwriteDrain(stream, state) {
  if (state.length === 0 && state.needDrain) {
    state.needDrain = false;
    stream.emit('drain');
  }
} // if there's something in the buffer waiting, then process it


function clearBuffer(stream, state) {
  state.bufferProcessing = true;
  var entry = state.bufferedRequest;

  if (stream._writev && entry && entry.next) {
    // Fast case, write everything using _writev()
    var l = state.bufferedRequestCount;
    var buffer = new Array(l);
    var holder = state.corkedRequestsFree;
    holder.entry = entry;
    var count = 0;
    var allBuffers = true;

    while (entry) {
      buffer[count] = entry;
      if (!entry.isBuf) allBuffers = false;
      entry = entry.next;
      count += 1;
    }

    buffer.allBuffers = allBuffers;
    doWrite(stream, state, true, state.length, buffer, '', holder.finish); // doWrite is almost always async, defer these to save a bit of time
    // as the hot path ends with doWrite

    state.pendingcb++;
    state.lastBufferedRequest = null;

    if (holder.next) {
      state.corkedRequestsFree = holder.next;
      holder.next = null;
    } else {
      state.corkedRequestsFree = new CorkedRequest(state);
    }

    state.bufferedRequestCount = 0;
  } else {
    // Slow case, write chunks one-by-one
    while (entry) {
      var chunk = entry.chunk;
      var encoding = entry.encoding;
      var cb = entry.callback;
      var len = state.objectMode ? 1 : chunk.length;
      doWrite(stream, state, false, len, chunk, encoding, cb);
      entry = entry.next;
      state.bufferedRequestCount--; // if we didn't call the onwrite immediately, then
      // it means that we need to wait until it does.
      // also, that means that the chunk and cb are currently
      // being processed, so move the buffer counter past them.

      if (state.writing) {
        break;
      }
    }

    if (entry === null) state.lastBufferedRequest = null;
  }

  state.bufferedRequest = entry;
  state.bufferProcessing = false;
}

Writable.prototype._write = function (chunk, encoding, cb) {
  cb(new ERR_METHOD_NOT_IMPLEMENTED('_write()'));
};

Writable.prototype._writev = null;

Writable.prototype.end = function (chunk, encoding, cb) {
  var state = this._writableState;

  if (typeof chunk === 'function') {
    cb = chunk;
    chunk = null;
    encoding = null;
  } else if (typeof encoding === 'function') {
    cb = encoding;
    encoding = null;
  }

  if (chunk !== null && chunk !== undefined) this.write(chunk, encoding); // .end() fully uncorks

  if (state.corked) {
    state.corked = 1;
    this.uncork();
  } // ignore unnecessary end() calls.


  if (!state.ending) endWritable(this, state, cb);
  return this;
};

Object.defineProperty(Writable.prototype, 'writableLength', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._writableState.length;
  }
});

function needFinish(state) {
  return state.ending && state.length === 0 && state.bufferedRequest === null && !state.finished && !state.writing;
}

function callFinal(stream, state) {
  stream._final(function (err) {
    state.pendingcb--;

    if (err) {
      errorOrDestroy(stream, err);
    }

    state.prefinished = true;
    stream.emit('prefinish');
    finishMaybe(stream, state);
  });
}

function prefinish(stream, state) {
  if (!state.prefinished && !state.finalCalled) {
    if (typeof stream._final === 'function' && !state.destroyed) {
      state.pendingcb++;
      state.finalCalled = true;
      process.nextTick(callFinal, stream, state);
    } else {
      state.prefinished = true;
      stream.emit('prefinish');
    }
  }
}

function finishMaybe(stream, state) {
  var need = needFinish(state);

  if (need) {
    prefinish(stream, state);

    if (state.pendingcb === 0) {
      state.finished = true;
      stream.emit('finish');

      if (state.autoDestroy) {
        // In case of duplex streams we need a way to detect
        // if the readable side is ready for autoDestroy as well
        var rState = stream._readableState;

        if (!rState || rState.autoDestroy && rState.endEmitted) {
          stream.destroy();
        }
      }
    }
  }

  return need;
}

function endWritable(stream, state, cb) {
  state.ending = true;
  finishMaybe(stream, state);

  if (cb) {
    if (state.finished) process.nextTick(cb);else stream.once('finish', cb);
  }

  state.ended = true;
  stream.writable = false;
}

function onCorkedFinish(corkReq, state, err) {
  var entry = corkReq.entry;
  corkReq.entry = null;

  while (entry) {
    var cb = entry.callback;
    state.pendingcb--;
    cb(err);
    entry = entry.next;
  } // reuse the free corkReq.


  state.corkedRequestsFree.next = corkReq;
}

Object.defineProperty(Writable.prototype, 'destroyed', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    if (this._writableState === undefined) {
      return false;
    }

    return this._writableState.destroyed;
  },
  set: function set(value) {
    // we ignore the value if the stream
    // has not been initialized yet
    if (!this._writableState) {
      return;
    } // backward compatibility, the user is explicitly
    // managing destroyed


    this._writableState.destroyed = value;
  }
});
Writable.prototype.destroy = destroyImpl.destroy;
Writable.prototype._undestroy = destroyImpl.undestroy;

Writable.prototype._destroy = function (err, cb) {
  cb(err);
};

/***/ }),

/***/ 5850:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var _Object$setPrototypeO;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var finished = __webpack_require__(8610);

var kLastResolve = Symbol('lastResolve');
var kLastReject = Symbol('lastReject');
var kError = Symbol('error');
var kEnded = Symbol('ended');
var kLastPromise = Symbol('lastPromise');
var kHandlePromise = Symbol('handlePromise');
var kStream = Symbol('stream');

function createIterResult(value, done) {
  return {
    value: value,
    done: done
  };
}

function readAndResolve(iter) {
  var resolve = iter[kLastResolve];

  if (resolve !== null) {
    var data = iter[kStream].read(); // we defer if data is null
    // we can be expecting either 'end' or
    // 'error'

    if (data !== null) {
      iter[kLastPromise] = null;
      iter[kLastResolve] = null;
      iter[kLastReject] = null;
      resolve(createIterResult(data, false));
    }
  }
}

function onReadable(iter) {
  // we wait for the next tick, because it might
  // emit an error with process.nextTick
  process.nextTick(readAndResolve, iter);
}

function wrapForNext(lastPromise, iter) {
  return function (resolve, reject) {
    lastPromise.then(function () {
      if (iter[kEnded]) {
        resolve(createIterResult(undefined, true));
        return;
      }

      iter[kHandlePromise](resolve, reject);
    }, reject);
  };
}

var AsyncIteratorPrototype = Object.getPrototypeOf(function () {});
var ReadableStreamAsyncIteratorPrototype = Object.setPrototypeOf((_Object$setPrototypeO = {
  get stream() {
    return this[kStream];
  },

  next: function next() {
    var _this = this;

    // if we have detected an error in the meanwhile
    // reject straight away
    var error = this[kError];

    if (error !== null) {
      return Promise.reject(error);
    }

    if (this[kEnded]) {
      return Promise.resolve(createIterResult(undefined, true));
    }

    if (this[kStream].destroyed) {
      // We need to defer via nextTick because if .destroy(err) is
      // called, the error will be emitted via nextTick, and
      // we cannot guarantee that there is no error lingering around
      // waiting to be emitted.
      return new Promise(function (resolve, reject) {
        process.nextTick(function () {
          if (_this[kError]) {
            reject(_this[kError]);
          } else {
            resolve(createIterResult(undefined, true));
          }
        });
      });
    } // if we have multiple next() calls
    // we will wait for the previous Promise to finish
    // this logic is optimized to support for await loops,
    // where next() is only called once at a time


    var lastPromise = this[kLastPromise];
    var promise;

    if (lastPromise) {
      promise = new Promise(wrapForNext(lastPromise, this));
    } else {
      // fast path needed to support multiple this.push()
      // without triggering the next() queue
      var data = this[kStream].read();

      if (data !== null) {
        return Promise.resolve(createIterResult(data, false));
      }

      promise = new Promise(this[kHandlePromise]);
    }

    this[kLastPromise] = promise;
    return promise;
  }
}, _defineProperty(_Object$setPrototypeO, Symbol.asyncIterator, function () {
  return this;
}), _defineProperty(_Object$setPrototypeO, "return", function _return() {
  var _this2 = this;

  // destroy(err, cb) is a private API
  // we can guarantee we have that here, because we control the
  // Readable class this is attached to
  return new Promise(function (resolve, reject) {
    _this2[kStream].destroy(null, function (err) {
      if (err) {
        reject(err);
        return;
      }

      resolve(createIterResult(undefined, true));
    });
  });
}), _Object$setPrototypeO), AsyncIteratorPrototype);

var createReadableStreamAsyncIterator = function createReadableStreamAsyncIterator(stream) {
  var _Object$create;

  var iterator = Object.create(ReadableStreamAsyncIteratorPrototype, (_Object$create = {}, _defineProperty(_Object$create, kStream, {
    value: stream,
    writable: true
  }), _defineProperty(_Object$create, kLastResolve, {
    value: null,
    writable: true
  }), _defineProperty(_Object$create, kLastReject, {
    value: null,
    writable: true
  }), _defineProperty(_Object$create, kError, {
    value: null,
    writable: true
  }), _defineProperty(_Object$create, kEnded, {
    value: stream._readableState.endEmitted,
    writable: true
  }), _defineProperty(_Object$create, kHandlePromise, {
    value: function value(resolve, reject) {
      var data = iterator[kStream].read();

      if (data) {
        iterator[kLastPromise] = null;
        iterator[kLastResolve] = null;
        iterator[kLastReject] = null;
        resolve(createIterResult(data, false));
      } else {
        iterator[kLastResolve] = resolve;
        iterator[kLastReject] = reject;
      }
    },
    writable: true
  }), _Object$create));
  iterator[kLastPromise] = null;
  finished(stream, function (err) {
    if (err && err.code !== 'ERR_STREAM_PREMATURE_CLOSE') {
      var reject = iterator[kLastReject]; // reject if we are waiting for data in the Promise
      // returned by next() and store the error

      if (reject !== null) {
        iterator[kLastPromise] = null;
        iterator[kLastResolve] = null;
        iterator[kLastReject] = null;
        reject(err);
      }

      iterator[kError] = err;
      return;
    }

    var resolve = iterator[kLastResolve];

    if (resolve !== null) {
      iterator[kLastPromise] = null;
      iterator[kLastResolve] = null;
      iterator[kLastReject] = null;
      resolve(createIterResult(undefined, true));
    }

    iterator[kEnded] = true;
  });
  stream.on('readable', onReadable.bind(null, iterator));
  return iterator;
};

module.exports = createReadableStreamAsyncIterator;

/***/ }),

/***/ 7327:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var _require = __webpack_require__(4293),
    Buffer = _require.Buffer;

var _require2 = __webpack_require__(1669),
    inspect = _require2.inspect;

var custom = inspect && inspect.custom || 'inspect';

function copyBuffer(src, target, offset) {
  Buffer.prototype.copy.call(src, target, offset);
}

module.exports =
/*#__PURE__*/
function () {
  function BufferList() {
    _classCallCheck(this, BufferList);

    this.head = null;
    this.tail = null;
    this.length = 0;
  }

  _createClass(BufferList, [{
    key: "push",
    value: function push(v) {
      var entry = {
        data: v,
        next: null
      };
      if (this.length > 0) this.tail.next = entry;else this.head = entry;
      this.tail = entry;
      ++this.length;
    }
  }, {
    key: "unshift",
    value: function unshift(v) {
      var entry = {
        data: v,
        next: this.head
      };
      if (this.length === 0) this.tail = entry;
      this.head = entry;
      ++this.length;
    }
  }, {
    key: "shift",
    value: function shift() {
      if (this.length === 0) return;
      var ret = this.head.data;
      if (this.length === 1) this.head = this.tail = null;else this.head = this.head.next;
      --this.length;
      return ret;
    }
  }, {
    key: "clear",
    value: function clear() {
      this.head = this.tail = null;
      this.length = 0;
    }
  }, {
    key: "join",
    value: function join(s) {
      if (this.length === 0) return '';
      var p = this.head;
      var ret = '' + p.data;

      while (p = p.next) {
        ret += s + p.data;
      }

      return ret;
    }
  }, {
    key: "concat",
    value: function concat(n) {
      if (this.length === 0) return Buffer.alloc(0);
      var ret = Buffer.allocUnsafe(n >>> 0);
      var p = this.head;
      var i = 0;

      while (p) {
        copyBuffer(p.data, ret, i);
        i += p.data.length;
        p = p.next;
      }

      return ret;
    } // Consumes a specified amount of bytes or characters from the buffered data.

  }, {
    key: "consume",
    value: function consume(n, hasStrings) {
      var ret;

      if (n < this.head.data.length) {
        // `slice` is the same for buffers and strings.
        ret = this.head.data.slice(0, n);
        this.head.data = this.head.data.slice(n);
      } else if (n === this.head.data.length) {
        // First chunk is a perfect match.
        ret = this.shift();
      } else {
        // Result spans more than one buffer.
        ret = hasStrings ? this._getString(n) : this._getBuffer(n);
      }

      return ret;
    }
  }, {
    key: "first",
    value: function first() {
      return this.head.data;
    } // Consumes a specified amount of characters from the buffered data.

  }, {
    key: "_getString",
    value: function _getString(n) {
      var p = this.head;
      var c = 1;
      var ret = p.data;
      n -= ret.length;

      while (p = p.next) {
        var str = p.data;
        var nb = n > str.length ? str.length : n;
        if (nb === str.length) ret += str;else ret += str.slice(0, n);
        n -= nb;

        if (n === 0) {
          if (nb === str.length) {
            ++c;
            if (p.next) this.head = p.next;else this.head = this.tail = null;
          } else {
            this.head = p;
            p.data = str.slice(nb);
          }

          break;
        }

        ++c;
      }

      this.length -= c;
      return ret;
    } // Consumes a specified amount of bytes from the buffered data.

  }, {
    key: "_getBuffer",
    value: function _getBuffer(n) {
      var ret = Buffer.allocUnsafe(n);
      var p = this.head;
      var c = 1;
      p.data.copy(ret);
      n -= p.data.length;

      while (p = p.next) {
        var buf = p.data;
        var nb = n > buf.length ? buf.length : n;
        buf.copy(ret, ret.length - n, 0, nb);
        n -= nb;

        if (n === 0) {
          if (nb === buf.length) {
            ++c;
            if (p.next) this.head = p.next;else this.head = this.tail = null;
          } else {
            this.head = p;
            p.data = buf.slice(nb);
          }

          break;
        }

        ++c;
      }

      this.length -= c;
      return ret;
    } // Make sure the linked list only shows the minimal necessary information.

  }, {
    key: custom,
    value: function value(_, options) {
      return inspect(this, _objectSpread({}, options, {
        // Only inspect one level.
        depth: 0,
        // It should not recurse.
        customInspect: false
      }));
    }
  }]);

  return BufferList;
}();

/***/ }),

/***/ 1195:
/***/ ((module) => {

"use strict";
 // undocumented cb() API, needed for core, not for public API

function destroy(err, cb) {
  var _this = this;

  var readableDestroyed = this._readableState && this._readableState.destroyed;
  var writableDestroyed = this._writableState && this._writableState.destroyed;

  if (readableDestroyed || writableDestroyed) {
    if (cb) {
      cb(err);
    } else if (err) {
      if (!this._writableState) {
        process.nextTick(emitErrorNT, this, err);
      } else if (!this._writableState.errorEmitted) {
        this._writableState.errorEmitted = true;
        process.nextTick(emitErrorNT, this, err);
      }
    }

    return this;
  } // we set destroyed to true before firing error callbacks in order
  // to make it re-entrance safe in case destroy() is called within callbacks


  if (this._readableState) {
    this._readableState.destroyed = true;
  } // if this is a duplex stream mark the writable part as destroyed as well


  if (this._writableState) {
    this._writableState.destroyed = true;
  }

  this._destroy(err || null, function (err) {
    if (!cb && err) {
      if (!_this._writableState) {
        process.nextTick(emitErrorAndCloseNT, _this, err);
      } else if (!_this._writableState.errorEmitted) {
        _this._writableState.errorEmitted = true;
        process.nextTick(emitErrorAndCloseNT, _this, err);
      } else {
        process.nextTick(emitCloseNT, _this);
      }
    } else if (cb) {
      process.nextTick(emitCloseNT, _this);
      cb(err);
    } else {
      process.nextTick(emitCloseNT, _this);
    }
  });

  return this;
}

function emitErrorAndCloseNT(self, err) {
  emitErrorNT(self, err);
  emitCloseNT(self);
}

function emitCloseNT(self) {
  if (self._writableState && !self._writableState.emitClose) return;
  if (self._readableState && !self._readableState.emitClose) return;
  self.emit('close');
}

function undestroy() {
  if (this._readableState) {
    this._readableState.destroyed = false;
    this._readableState.reading = false;
    this._readableState.ended = false;
    this._readableState.endEmitted = false;
  }

  if (this._writableState) {
    this._writableState.destroyed = false;
    this._writableState.ended = false;
    this._writableState.ending = false;
    this._writableState.finalCalled = false;
    this._writableState.prefinished = false;
    this._writableState.finished = false;
    this._writableState.errorEmitted = false;
  }
}

function emitErrorNT(self, err) {
  self.emit('error', err);
}

function errorOrDestroy(stream, err) {
  // We have tests that rely on errors being emitted
  // in the same tick, so changing this is semver major.
  // For now when you opt-in to autoDestroy we allow
  // the error to be emitted nextTick. In a future
  // semver major update we should change the default to this.
  var rState = stream._readableState;
  var wState = stream._writableState;
  if (rState && rState.autoDestroy || wState && wState.autoDestroy) stream.destroy(err);else stream.emit('error', err);
}

module.exports = {
  destroy: destroy,
  undestroy: undestroy,
  errorOrDestroy: errorOrDestroy
};

/***/ }),

/***/ 8610:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Ported from https://github.com/mafintosh/end-of-stream with
// permission from the author, Mathias Buus (@mafintosh).


var ERR_STREAM_PREMATURE_CLOSE = __webpack_require__(4012)/* .codes.ERR_STREAM_PREMATURE_CLOSE */ .q.ERR_STREAM_PREMATURE_CLOSE;

function once(callback) {
  var called = false;
  return function () {
    if (called) return;
    called = true;

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    callback.apply(this, args);
  };
}

function noop() {}

function isRequest(stream) {
  return stream.setHeader && typeof stream.abort === 'function';
}

function eos(stream, opts, callback) {
  if (typeof opts === 'function') return eos(stream, null, opts);
  if (!opts) opts = {};
  callback = once(callback || noop);
  var readable = opts.readable || opts.readable !== false && stream.readable;
  var writable = opts.writable || opts.writable !== false && stream.writable;

  var onlegacyfinish = function onlegacyfinish() {
    if (!stream.writable) onfinish();
  };

  var writableEnded = stream._writableState && stream._writableState.finished;

  var onfinish = function onfinish() {
    writable = false;
    writableEnded = true;
    if (!readable) callback.call(stream);
  };

  var readableEnded = stream._readableState && stream._readableState.endEmitted;

  var onend = function onend() {
    readable = false;
    readableEnded = true;
    if (!writable) callback.call(stream);
  };

  var onerror = function onerror(err) {
    callback.call(stream, err);
  };

  var onclose = function onclose() {
    var err;

    if (readable && !readableEnded) {
      if (!stream._readableState || !stream._readableState.ended) err = new ERR_STREAM_PREMATURE_CLOSE();
      return callback.call(stream, err);
    }

    if (writable && !writableEnded) {
      if (!stream._writableState || !stream._writableState.ended) err = new ERR_STREAM_PREMATURE_CLOSE();
      return callback.call(stream, err);
    }
  };

  var onrequest = function onrequest() {
    stream.req.on('finish', onfinish);
  };

  if (isRequest(stream)) {
    stream.on('complete', onfinish);
    stream.on('abort', onclose);
    if (stream.req) onrequest();else stream.on('request', onrequest);
  } else if (writable && !stream._writableState) {
    // legacy streams
    stream.on('end', onlegacyfinish);
    stream.on('close', onlegacyfinish);
  }

  stream.on('end', onend);
  stream.on('finish', onfinish);
  if (opts.error !== false) stream.on('error', onerror);
  stream.on('close', onclose);
  return function () {
    stream.removeListener('complete', onfinish);
    stream.removeListener('abort', onclose);
    stream.removeListener('request', onrequest);
    if (stream.req) stream.req.removeListener('finish', onfinish);
    stream.removeListener('end', onlegacyfinish);
    stream.removeListener('close', onlegacyfinish);
    stream.removeListener('finish', onfinish);
    stream.removeListener('end', onend);
    stream.removeListener('error', onerror);
    stream.removeListener('close', onclose);
  };
}

module.exports = eos;

/***/ }),

/***/ 6307:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var ERR_INVALID_ARG_TYPE = __webpack_require__(4012)/* .codes.ERR_INVALID_ARG_TYPE */ .q.ERR_INVALID_ARG_TYPE;

function from(Readable, iterable, opts) {
  var iterator;

  if (iterable && typeof iterable.next === 'function') {
    iterator = iterable;
  } else if (iterable && iterable[Symbol.asyncIterator]) iterator = iterable[Symbol.asyncIterator]();else if (iterable && iterable[Symbol.iterator]) iterator = iterable[Symbol.iterator]();else throw new ERR_INVALID_ARG_TYPE('iterable', ['Iterable'], iterable);

  var readable = new Readable(_objectSpread({
    objectMode: true
  }, opts)); // Reading boolean to protect against _read
  // being called before last iteration completion.

  var reading = false;

  readable._read = function () {
    if (!reading) {
      reading = true;
      next();
    }
  };

  function next() {
    return _next2.apply(this, arguments);
  }

  function _next2() {
    _next2 = _asyncToGenerator(function* () {
      try {
        var _ref = yield iterator.next(),
            value = _ref.value,
            done = _ref.done;

        if (done) {
          readable.push(null);
        } else if (readable.push((yield value))) {
          next();
        } else {
          reading = false;
        }
      } catch (err) {
        readable.destroy(err);
      }
    });
    return _next2.apply(this, arguments);
  }

  return readable;
}

module.exports = from;

/***/ }),

/***/ 9946:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Ported from https://github.com/mafintosh/pump with
// permission from the author, Mathias Buus (@mafintosh).


var eos;

function once(callback) {
  var called = false;
  return function () {
    if (called) return;
    called = true;
    callback.apply(void 0, arguments);
  };
}

var _require$codes = __webpack_require__(4012)/* .codes */ .q,
    ERR_MISSING_ARGS = _require$codes.ERR_MISSING_ARGS,
    ERR_STREAM_DESTROYED = _require$codes.ERR_STREAM_DESTROYED;

function noop(err) {
  // Rethrow the error if it exists to avoid swallowing it
  if (err) throw err;
}

function isRequest(stream) {
  return stream.setHeader && typeof stream.abort === 'function';
}

function destroyer(stream, reading, writing, callback) {
  callback = once(callback);
  var closed = false;
  stream.on('close', function () {
    closed = true;
  });
  if (eos === undefined) eos = __webpack_require__(8610);
  eos(stream, {
    readable: reading,
    writable: writing
  }, function (err) {
    if (err) return callback(err);
    closed = true;
    callback();
  });
  var destroyed = false;
  return function (err) {
    if (closed) return;
    if (destroyed) return;
    destroyed = true; // request.destroy just do .end - .abort is what we want

    if (isRequest(stream)) return stream.abort();
    if (typeof stream.destroy === 'function') return stream.destroy();
    callback(err || new ERR_STREAM_DESTROYED('pipe'));
  };
}

function call(fn) {
  fn();
}

function pipe(from, to) {
  return from.pipe(to);
}

function popCallback(streams) {
  if (!streams.length) return noop;
  if (typeof streams[streams.length - 1] !== 'function') return noop;
  return streams.pop();
}

function pipeline() {
  for (var _len = arguments.length, streams = new Array(_len), _key = 0; _key < _len; _key++) {
    streams[_key] = arguments[_key];
  }

  var callback = popCallback(streams);
  if (Array.isArray(streams[0])) streams = streams[0];

  if (streams.length < 2) {
    throw new ERR_MISSING_ARGS('streams');
  }

  var error;
  var destroys = streams.map(function (stream, i) {
    var reading = i < streams.length - 1;
    var writing = i > 0;
    return destroyer(stream, reading, writing, function (err) {
      if (!error) error = err;
      if (err) destroys.forEach(call);
      if (reading) return;
      destroys.forEach(call);
      callback(error);
    });
  });
  return streams.reduce(pipe);
}

module.exports = pipeline;

/***/ }),

/***/ 2457:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var ERR_INVALID_OPT_VALUE = __webpack_require__(4012)/* .codes.ERR_INVALID_OPT_VALUE */ .q.ERR_INVALID_OPT_VALUE;

function highWaterMarkFrom(options, isDuplex, duplexKey) {
  return options.highWaterMark != null ? options.highWaterMark : isDuplex ? options[duplexKey] : null;
}

function getHighWaterMark(state, options, duplexKey, isDuplex) {
  var hwm = highWaterMarkFrom(options, isDuplex, duplexKey);

  if (hwm != null) {
    if (!(isFinite(hwm) && Math.floor(hwm) === hwm) || hwm < 0) {
      var name = isDuplex ? duplexKey : 'highWaterMark';
      throw new ERR_INVALID_OPT_VALUE(name, hwm);
    }

    return Math.floor(hwm);
  } // Default value


  return state.objectMode ? 16 : 16 * 1024;
}

module.exports = {
  getHighWaterMark: getHighWaterMark
};

/***/ }),

/***/ 9740:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(2413);


/***/ }),

/***/ 1451:
/***/ ((module, exports, __webpack_require__) => {

var Stream = __webpack_require__(2413);
if (process.env.READABLE_STREAM === 'disable' && Stream) {
  module.exports = Stream.Readable;
  Object.assign(module.exports, Stream);
  module.exports.Stream = Stream;
} else {
  exports = module.exports = __webpack_require__(9481);
  exports.Stream = Stream || exports;
  exports.Readable = exports;
  exports.Writable = __webpack_require__(4229);
  exports.Duplex = __webpack_require__(6753);
  exports.Transform = __webpack_require__(4605);
  exports.PassThrough = __webpack_require__(2725);
  exports.finished = __webpack_require__(8610);
  exports.pipeline = __webpack_require__(9946);
}


/***/ }),

/***/ 9509:
/***/ ((module, exports, __webpack_require__) => {

/*! safe-buffer. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
/* eslint-disable node/no-deprecated-api */
var buffer = __webpack_require__(4293)
var Buffer = buffer.Buffer

// alternative to using Object.keys for old browsers
function copyProps (src, dst) {
  for (var key in src) {
    dst[key] = src[key]
  }
}
if (Buffer.from && Buffer.alloc && Buffer.allocUnsafe && Buffer.allocUnsafeSlow) {
  module.exports = buffer
} else {
  // Copy properties from require('buffer')
  copyProps(buffer, exports)
  exports.Buffer = SafeBuffer
}

function SafeBuffer (arg, encodingOrOffset, length) {
  return Buffer(arg, encodingOrOffset, length)
}

SafeBuffer.prototype = Object.create(Buffer.prototype)

// Copy static methods from Buffer
copyProps(Buffer, SafeBuffer)

SafeBuffer.from = function (arg, encodingOrOffset, length) {
  if (typeof arg === 'number') {
    throw new TypeError('Argument must not be a number')
  }
  return Buffer(arg, encodingOrOffset, length)
}

SafeBuffer.alloc = function (size, fill, encoding) {
  if (typeof size !== 'number') {
    throw new TypeError('Argument must be a number')
  }
  var buf = Buffer(size)
  if (fill !== undefined) {
    if (typeof encoding === 'string') {
      buf.fill(fill, encoding)
    } else {
      buf.fill(fill)
    }
  } else {
    buf.fill(0)
  }
  return buf
}

SafeBuffer.allocUnsafe = function (size) {
  if (typeof size !== 'number') {
    throw new TypeError('Argument must be a number')
  }
  return Buffer(size)
}

SafeBuffer.allocUnsafeSlow = function (size) {
  if (typeof size !== 'number') {
    throw new TypeError('Argument must be a number')
  }
  return buffer.SlowBuffer(size)
}


/***/ }),

/***/ 861:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
/*
Copyright (c) 2014-2018, Matteo Collina <hello@matteocollina.com>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/



const { Transform } = __webpack_require__(1451)
const { StringDecoder } = __webpack_require__(4304)
const kLast = Symbol('last')
const kDecoder = Symbol('decoder')

function transform (chunk, enc, cb) {
  var list
  if (this.overflow) { // Line buffer is full. Skip to start of next line.
    var buf = this[kDecoder].write(chunk)
    list = buf.split(this.matcher)

    if (list.length === 1) return cb() // Line ending not found. Discard entire chunk.

    // Line ending found. Discard trailing fragment of previous line and reset overflow state.
    list.shift()
    this.overflow = false
  } else {
    this[kLast] += this[kDecoder].write(chunk)
    list = this[kLast].split(this.matcher)
  }

  this[kLast] = list.pop()

  for (var i = 0; i < list.length; i++) {
    try {
      push(this, this.mapper(list[i]))
    } catch (error) {
      return cb(error)
    }
  }

  this.overflow = this[kLast].length > this.maxLength
  if (this.overflow && !this.skipOverflow) return cb(new Error('maximum buffer reached'))

  cb()
}

function flush (cb) {
  // forward any gibberish left in there
  this[kLast] += this[kDecoder].end()

  if (this[kLast]) {
    try {
      push(this, this.mapper(this[kLast]))
    } catch (error) {
      return cb(error)
    }
  }

  cb()
}

function push (self, val) {
  if (val !== undefined) {
    self.push(val)
  }
}

function noop (incoming) {
  return incoming
}

function split (matcher, mapper, options) {
  // Set defaults for any arguments not supplied.
  matcher = matcher || /\r?\n/
  mapper = mapper || noop
  options = options || {}

  // Test arguments explicitly.
  switch (arguments.length) {
    case 1:
      // If mapper is only argument.
      if (typeof matcher === 'function') {
        mapper = matcher
        matcher = /\r?\n/
      // If options is only argument.
      } else if (typeof matcher === 'object' && !(matcher instanceof RegExp)) {
        options = matcher
        matcher = /\r?\n/
      }
      break

    case 2:
      // If mapper and options are arguments.
      if (typeof matcher === 'function') {
        options = mapper
        mapper = matcher
        matcher = /\r?\n/
      // If matcher and options are arguments.
      } else if (typeof mapper === 'object') {
        options = mapper
        mapper = noop
      }
  }

  options = Object.assign({}, options)
  options.transform = transform
  options.flush = flush
  options.readableObjectMode = true

  const stream = new Transform(options)

  stream[kLast] = ''
  stream[kDecoder] = new StringDecoder('utf8')
  stream.matcher = matcher
  stream.mapper = mapper
  stream.maxLength = options.maxLength
  stream.skipOverflow = options.skipOverflow
  stream.overflow = false

  return stream
}

module.exports = split


/***/ }),

/***/ 2553:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.



/*<replacement>*/

var Buffer = __webpack_require__(9509).Buffer;
/*</replacement>*/

var isEncoding = Buffer.isEncoding || function (encoding) {
  encoding = '' + encoding;
  switch (encoding && encoding.toLowerCase()) {
    case 'hex':case 'utf8':case 'utf-8':case 'ascii':case 'binary':case 'base64':case 'ucs2':case 'ucs-2':case 'utf16le':case 'utf-16le':case 'raw':
      return true;
    default:
      return false;
  }
};

function _normalizeEncoding(enc) {
  if (!enc) return 'utf8';
  var retried;
  while (true) {
    switch (enc) {
      case 'utf8':
      case 'utf-8':
        return 'utf8';
      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return 'utf16le';
      case 'latin1':
      case 'binary':
        return 'latin1';
      case 'base64':
      case 'ascii':
      case 'hex':
        return enc;
      default:
        if (retried) return; // undefined
        enc = ('' + enc).toLowerCase();
        retried = true;
    }
  }
};

// Do not cache `Buffer.isEncoding` when checking encoding names as some
// modules monkey-patch it to support additional encodings
function normalizeEncoding(enc) {
  var nenc = _normalizeEncoding(enc);
  if (typeof nenc !== 'string' && (Buffer.isEncoding === isEncoding || !isEncoding(enc))) throw new Error('Unknown encoding: ' + enc);
  return nenc || enc;
}

// StringDecoder provides an interface for efficiently splitting a series of
// buffers into a series of JS strings without breaking apart multi-byte
// characters.
exports.s = StringDecoder;
function StringDecoder(encoding) {
  this.encoding = normalizeEncoding(encoding);
  var nb;
  switch (this.encoding) {
    case 'utf16le':
      this.text = utf16Text;
      this.end = utf16End;
      nb = 4;
      break;
    case 'utf8':
      this.fillLast = utf8FillLast;
      nb = 4;
      break;
    case 'base64':
      this.text = base64Text;
      this.end = base64End;
      nb = 3;
      break;
    default:
      this.write = simpleWrite;
      this.end = simpleEnd;
      return;
  }
  this.lastNeed = 0;
  this.lastTotal = 0;
  this.lastChar = Buffer.allocUnsafe(nb);
}

StringDecoder.prototype.write = function (buf) {
  if (buf.length === 0) return '';
  var r;
  var i;
  if (this.lastNeed) {
    r = this.fillLast(buf);
    if (r === undefined) return '';
    i = this.lastNeed;
    this.lastNeed = 0;
  } else {
    i = 0;
  }
  if (i < buf.length) return r ? r + this.text(buf, i) : this.text(buf, i);
  return r || '';
};

StringDecoder.prototype.end = utf8End;

// Returns only complete characters in a Buffer
StringDecoder.prototype.text = utf8Text;

// Attempts to complete a partial non-UTF-8 character using bytes from a Buffer
StringDecoder.prototype.fillLast = function (buf) {
  if (this.lastNeed <= buf.length) {
    buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, this.lastNeed);
    return this.lastChar.toString(this.encoding, 0, this.lastTotal);
  }
  buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, buf.length);
  this.lastNeed -= buf.length;
};

// Checks the type of a UTF-8 byte, whether it's ASCII, a leading byte, or a
// continuation byte. If an invalid byte is detected, -2 is returned.
function utf8CheckByte(byte) {
  if (byte <= 0x7F) return 0;else if (byte >> 5 === 0x06) return 2;else if (byte >> 4 === 0x0E) return 3;else if (byte >> 3 === 0x1E) return 4;
  return byte >> 6 === 0x02 ? -1 : -2;
}

// Checks at most 3 bytes at the end of a Buffer in order to detect an
// incomplete multi-byte UTF-8 character. The total number of bytes (2, 3, or 4)
// needed to complete the UTF-8 character (if applicable) are returned.
function utf8CheckIncomplete(self, buf, i) {
  var j = buf.length - 1;
  if (j < i) return 0;
  var nb = utf8CheckByte(buf[j]);
  if (nb >= 0) {
    if (nb > 0) self.lastNeed = nb - 1;
    return nb;
  }
  if (--j < i || nb === -2) return 0;
  nb = utf8CheckByte(buf[j]);
  if (nb >= 0) {
    if (nb > 0) self.lastNeed = nb - 2;
    return nb;
  }
  if (--j < i || nb === -2) return 0;
  nb = utf8CheckByte(buf[j]);
  if (nb >= 0) {
    if (nb > 0) {
      if (nb === 2) nb = 0;else self.lastNeed = nb - 3;
    }
    return nb;
  }
  return 0;
}

// Validates as many continuation bytes for a multi-byte UTF-8 character as
// needed or are available. If we see a non-continuation byte where we expect
// one, we "replace" the validated continuation bytes we've seen so far with
// a single UTF-8 replacement character ('\ufffd'), to match v8's UTF-8 decoding
// behavior. The continuation byte check is included three times in the case
// where all of the continuation bytes for a character exist in the same buffer.
// It is also done this way as a slight performance increase instead of using a
// loop.
function utf8CheckExtraBytes(self, buf, p) {
  if ((buf[0] & 0xC0) !== 0x80) {
    self.lastNeed = 0;
    return '\ufffd';
  }
  if (self.lastNeed > 1 && buf.length > 1) {
    if ((buf[1] & 0xC0) !== 0x80) {
      self.lastNeed = 1;
      return '\ufffd';
    }
    if (self.lastNeed > 2 && buf.length > 2) {
      if ((buf[2] & 0xC0) !== 0x80) {
        self.lastNeed = 2;
        return '\ufffd';
      }
    }
  }
}

// Attempts to complete a multi-byte UTF-8 character using bytes from a Buffer.
function utf8FillLast(buf) {
  var p = this.lastTotal - this.lastNeed;
  var r = utf8CheckExtraBytes(this, buf, p);
  if (r !== undefined) return r;
  if (this.lastNeed <= buf.length) {
    buf.copy(this.lastChar, p, 0, this.lastNeed);
    return this.lastChar.toString(this.encoding, 0, this.lastTotal);
  }
  buf.copy(this.lastChar, p, 0, buf.length);
  this.lastNeed -= buf.length;
}

// Returns all complete UTF-8 characters in a Buffer. If the Buffer ended on a
// partial character, the character's bytes are buffered until the required
// number of bytes are available.
function utf8Text(buf, i) {
  var total = utf8CheckIncomplete(this, buf, i);
  if (!this.lastNeed) return buf.toString('utf8', i);
  this.lastTotal = total;
  var end = buf.length - (total - this.lastNeed);
  buf.copy(this.lastChar, 0, end);
  return buf.toString('utf8', i, end);
}

// For UTF-8, a replacement character is added when ending on a partial
// character.
function utf8End(buf) {
  var r = buf && buf.length ? this.write(buf) : '';
  if (this.lastNeed) return r + '\ufffd';
  return r;
}

// UTF-16LE typically needs two bytes per character, but even if we have an even
// number of bytes available, we need to check if we end on a leading/high
// surrogate. In that case, we need to wait for the next two bytes in order to
// decode the last character properly.
function utf16Text(buf, i) {
  if ((buf.length - i) % 2 === 0) {
    var r = buf.toString('utf16le', i);
    if (r) {
      var c = r.charCodeAt(r.length - 1);
      if (c >= 0xD800 && c <= 0xDBFF) {
        this.lastNeed = 2;
        this.lastTotal = 4;
        this.lastChar[0] = buf[buf.length - 2];
        this.lastChar[1] = buf[buf.length - 1];
        return r.slice(0, -1);
      }
    }
    return r;
  }
  this.lastNeed = 1;
  this.lastTotal = 2;
  this.lastChar[0] = buf[buf.length - 1];
  return buf.toString('utf16le', i, buf.length - 1);
}

// For UTF-16LE we do not explicitly append special replacement characters if we
// end on a partial character, we simply let v8 handle that.
function utf16End(buf) {
  var r = buf && buf.length ? this.write(buf) : '';
  if (this.lastNeed) {
    var end = this.lastTotal - this.lastNeed;
    return r + this.lastChar.toString('utf16le', 0, end);
  }
  return r;
}

function base64Text(buf, i) {
  var n = (buf.length - i) % 3;
  if (n === 0) return buf.toString('base64', i);
  this.lastNeed = 3 - n;
  this.lastTotal = 3;
  if (n === 1) {
    this.lastChar[0] = buf[buf.length - 1];
  } else {
    this.lastChar[0] = buf[buf.length - 2];
    this.lastChar[1] = buf[buf.length - 1];
  }
  return buf.toString('base64', i, buf.length - n);
}

function base64End(buf) {
  var r = buf && buf.length ? this.write(buf) : '';
  if (this.lastNeed) return r + this.lastChar.toString('base64', 0, 3 - this.lastNeed);
  return r;
}

// Pass bytes on through for single-byte encodings (e.g. ascii, latin1, hex)
function simpleWrite(buf) {
  return buf.toString(this.encoding);
}

function simpleEnd(buf) {
  return buf && buf.length ? this.write(buf) : '';
}

/***/ }),

/***/ 1159:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


/**
 * For Node.js, simply re-export the core `util.deprecate` function.
 */

module.exports = __webpack_require__(1669).deprecate;


/***/ }),

/***/ 9820:
/***/ ((module) => {

module.exports = extend

var hasOwnProperty = Object.prototype.hasOwnProperty;

function extend(target) {
    for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i]

        for (var key in source) {
            if (hasOwnProperty.call(source, key)) {
                target[key] = source[key]
            }
        }
    }

    return target
}


/***/ }),

/***/ 2357:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 4293:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6417:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 881:
/***/ ((module) => {

"use strict";
module.exports = require("dns");

/***/ }),

/***/ 8614:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 5747:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 1631:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 5622:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 2413:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 4304:
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ 4016:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 8835:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 1669:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 2466:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"name":"pg","version":"8.7.1","description":"PostgreSQL client - pure javascript & libpq with the same API","keywords":["database","libpq","pg","postgre","postgres","postgresql","rdbms"],"homepage":"https://github.com/brianc/node-postgres","repository":{"type":"git","url":"git://github.com/brianc/node-postgres.git","directory":"packages/pg"},"author":"Brian Carlson <brian.m.carlson@gmail.com>","main":"./lib","dependencies":{"buffer-writer":"2.0.0","packet-reader":"1.0.0","pg-connection-string":"^2.5.0","pg-pool":"^3.4.1","pg-protocol":"^1.5.0","pg-types":"^2.1.0","pgpass":"1.x"},"devDependencies":{"async":"0.9.0","bluebird":"3.5.2","co":"4.6.0","pg-copy-streams":"0.3.0"},"peerDependencies":{"pg-native":">=2.0.0"},"peerDependenciesMeta":{"pg-native":{"optional":true}},"scripts":{"test":"make test-all"},"files":["lib","SPONSORS.md"],"license":"MIT","engines":{"node":">= 8.0.0"},"gitHead":"92b4d37926c276d343bfe56447ff6f526af757cf"}');

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module doesn't tell about it's top-level declarations so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(9889);
/******/ 	var __webpack_export_target__ = exports;
/******/ 	for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
/******/ 	if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGFtYmRhcy9nZXRQcm9kdWN0c0xpc3QuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDekNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7OztBQ3RDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDUkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUMxQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ3pHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDbkdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUNwYUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUNqREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ2hGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDZEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDL0pBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDblRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7OztBQzVMQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQzlDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ1ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDaFFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ3hFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUN0TkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUM1bUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUNyS0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDNU5BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQy9FQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDdERBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDeFNBO0FBQ0E7Ozs7Ozs7OztBQ0RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDcEtBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDek9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUNuR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDaE5BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ2xDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDMUxBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ3hPQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUN0QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ2hHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDOUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ25IQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUM1SEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDbkhBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQzFJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDdENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDbm1DQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDeE1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ3hyQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQzlNQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDak5BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUN4R0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUN2R0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDL0RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ2hHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7QUMxQkE7Ozs7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDZkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDaEVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDbklBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7QUN2U0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ0xBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ2hCQTs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7QUN2QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7QUNQQTs7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7QUVOQTtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL2NvbmVjdGlvbi5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9sYW1iZGFzL2dldFByb2R1Y3RzTGlzdC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvaW5oZXJpdHMvaW5oZXJpdHMuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL2luaGVyaXRzL2luaGVyaXRzX2Jyb3dzZXIuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnLWNvbm5lY3Rpb24tc3RyaW5nL2luZGV4LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy1pbnQ4L2luZGV4LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy1wb29sL2luZGV4LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy1wcm90b2NvbC9kaXN0L2J1ZmZlci1yZWFkZXIuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnLXByb3RvY29sL2Rpc3QvYnVmZmVyLXdyaXRlci5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGctcHJvdG9jb2wvZGlzdC9pbmRleC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGctcHJvdG9jb2wvZGlzdC9tZXNzYWdlcy5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGctcHJvdG9jb2wvZGlzdC9wYXJzZXIuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnLXByb3RvY29sL2Rpc3Qvc2VyaWFsaXplci5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGctdHlwZXMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnLXR5cGVzL2xpYi9hcnJheVBhcnNlci5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGctdHlwZXMvbGliL2JpbmFyeVBhcnNlcnMuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnLXR5cGVzL2xpYi9idWlsdGlucy5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGctdHlwZXMvbGliL3RleHRQYXJzZXJzLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy9saWIvY2xpZW50LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy9saWIvY29ubmVjdGlvbi1wYXJhbWV0ZXJzLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy9saWIvY29ubmVjdGlvbi5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGcvbGliL2RlZmF1bHRzLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy9saWIvaW5kZXguanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnL2xpYi9uYXRpdmUvY2xpZW50LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy9saWIvbmF0aXZlL2luZGV4LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy9saWIvbmF0aXZlL3F1ZXJ5LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy9saWIvcXVlcnkuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnL2xpYi9yZXN1bHQuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnL2xpYi9zYXNsLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy9saWIvdHlwZS1vdmVycmlkZXMuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnL2xpYi91dGlscy5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGdwYXNzL2xpYi9oZWxwZXIuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BncGFzcy9saWIvaW5kZXguanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3Bvc3RncmVzLWFycmF5L2luZGV4LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wb3N0Z3Jlcy1ieXRlYS9pbmRleC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcG9zdGdyZXMtZGF0ZS9pbmRleC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcG9zdGdyZXMtaW50ZXJ2YWwvaW5kZXguanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3JlYWRhYmxlLXN0cmVhbS9lcnJvcnMuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3JlYWRhYmxlLXN0cmVhbS9saWIvX3N0cmVhbV9kdXBsZXguanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3JlYWRhYmxlLXN0cmVhbS9saWIvX3N0cmVhbV9wYXNzdGhyb3VnaC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcmVhZGFibGUtc3RyZWFtL2xpYi9fc3RyZWFtX3JlYWRhYmxlLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9yZWFkYWJsZS1zdHJlYW0vbGliL19zdHJlYW1fdHJhbnNmb3JtLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9yZWFkYWJsZS1zdHJlYW0vbGliL19zdHJlYW1fd3JpdGFibGUuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3JlYWRhYmxlLXN0cmVhbS9saWIvaW50ZXJuYWwvc3RyZWFtcy9hc3luY19pdGVyYXRvci5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcmVhZGFibGUtc3RyZWFtL2xpYi9pbnRlcm5hbC9zdHJlYW1zL2J1ZmZlcl9saXN0LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9yZWFkYWJsZS1zdHJlYW0vbGliL2ludGVybmFsL3N0cmVhbXMvZGVzdHJveS5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcmVhZGFibGUtc3RyZWFtL2xpYi9pbnRlcm5hbC9zdHJlYW1zL2VuZC1vZi1zdHJlYW0uanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3JlYWRhYmxlLXN0cmVhbS9saWIvaW50ZXJuYWwvc3RyZWFtcy9mcm9tLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9yZWFkYWJsZS1zdHJlYW0vbGliL2ludGVybmFsL3N0cmVhbXMvcGlwZWxpbmUuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3JlYWRhYmxlLXN0cmVhbS9saWIvaW50ZXJuYWwvc3RyZWFtcy9zdGF0ZS5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcmVhZGFibGUtc3RyZWFtL2xpYi9pbnRlcm5hbC9zdHJlYW1zL3N0cmVhbS5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcmVhZGFibGUtc3RyZWFtL3JlYWRhYmxlLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9zYWZlLWJ1ZmZlci9pbmRleC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvc3BsaXQyL2luZGV4LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9zdHJpbmdfZGVjb2Rlci9saWIvc3RyaW5nX2RlY29kZXIuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3V0aWwtZGVwcmVjYXRlL25vZGUuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3h0ZW5kL211dGFibGUuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL2V4dGVybmFsIFwiYXNzZXJ0XCIiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL2V4dGVybmFsIFwiYnVmZmVyXCIiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL2V4dGVybmFsIFwiY3J5cHRvXCIiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL2V4dGVybmFsIFwiZG5zXCIiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL2V4dGVybmFsIFwiZXZlbnRzXCIiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL2V4dGVybmFsIFwiZnNcIiIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvZXh0ZXJuYWwgXCJuZXRcIiIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvZXh0ZXJuYWwgXCJwYXRoXCIiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL2V4dGVybmFsIFwic3RyZWFtXCIiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL2V4dGVybmFsIFwic3RyaW5nX2RlY29kZXJcIiIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvZXh0ZXJuYWwgXCJ0bHNcIiIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvZXh0ZXJuYWwgXCJ1cmxcIiIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvZXh0ZXJuYWwgXCJ1dGlsXCIiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS93ZWJwYWNrL3J1bnRpbWUvZGVmaW5lIHByb3BlcnR5IGdldHRlcnMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL3dlYnBhY2svcnVudGltZS9oYXNPd25Qcm9wZXJ0eSBzaG9ydGhhbmQiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL3dlYnBhY2svcnVudGltZS9tYWtlIG5hbWVzcGFjZSBvYmplY3QiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL3dlYnBhY2svYmVmb3JlLXN0YXJ0dXAiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL3dlYnBhY2svc3RhcnR1cCIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2Uvd2VicGFjay9hZnRlci1zdGFydHVwIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENsaWVudCB9IGZyb20gJ3BnJztcclxuXHJcblxyXG5jb25zdCB7IFBHX0hPU1QsIFBHX1BPUlQsIFBHX0RBVEFCQVNFLCBQR19VU0VSTkFNRSwgUEdfUEFTU1dPUkQgfSA9IHByb2Nlc3MuZW52O1xyXG5leHBvcnQgY29uc3QgZGJPcHRpb25zID0ge1xyXG4gICAgaG9zdDogUEdfSE9TVCxcclxuICAgIHBvcnQ6IFBHX1BPUlQsXHJcbiAgICBkYXRhYmFzZTogUEdfREFUQUJBU0UsXHJcbiAgICB1c2VyOiBQR19VU0VSTkFNRSxcclxuICAgIHBhc3N3b3JkOiBQR19QQVNTV09SRCxcclxuICAgIHNzbDoge1xyXG4gICAgICAgIHJlamVjdFVuYXV0aG9yaXplZDogZmFsc2UsXHJcbiAgICB9LFxyXG4gICAgY29ubmVjdGlvblRpbWVvdXRNaWxsaXM6IDUwMDAsXHJcbn07XHJcbmV4cG9ydCBjbGFzcyBDb25uZWN0REIge1xyXG4gICAgY29uc3RydWN0b3IoKSB7XHJcbiAgICAgICAgdGhpcy5jbGllbnQgPSBuZXcgQ2xpZW50KGRiT3B0aW9ucyk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgY29ubmVjdCgpIHtcclxuICAgICAgICBhd2FpdCB0aGlzLmNsaWVudC5jb25uZWN0KCk7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuY2xpZW50O1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGRpc2Nvbm5lY3QoKSB7XHJcbiAgICAgICAgYXdhaXQgdGhpcy5jbGllbnQuZW5kKCk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgY3JlYXRlVGFibGUodGFibGVOYW1lLCBjb25maWcpIHtcclxuICAgICAgICBhd2FpdCB0aGlzLmNsaWVudC5xdWVyeShgXHJcbiAgY3JlYXRlIHRhYmxlIGlmIG5vdCBleGlzdCAke3RhYmxlTmFtZX0gKFxyXG4gICAgJHtjb25maWd9XHJcbiAgKWApO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBhc3luYyBnZXRMaXN0KHRhYmxlTmFtZSkge1xyXG4gICAgICAgIGNvbnN0IHsgcm93cyB9ID0gYXdhaXQgdGhpcy5jbGllbnQucXVlcnkoc2VsZWN0ICogZnJvbSBgJHt0YWJsZU5hbWV9YCk7XHJcbiAgICAgICAgcmV0dXJuIHJvd3M7XHJcbiAgICB9XHJcbn0iLCJpbXBvcnQgcHJvZHVjdHMgZnJvbSAnLi9kYi9wcm9kdWN0cy5qc29uJztcclxuaW1wb3J0IHsgQ2xpZW50IH0gZnJvbSAncGcnO1xyXG5pbXBvcnQgeyBDb25uZWN0REIsIGRiT3B0aW9ucyB9IGZyb20gJy4uL2NvbmVjdGlvbidcclxuXHJcblxyXG5cclxuXHJcbmV4cG9ydCBjb25zdCBoYW5kbGVyID0gYXN5bmMgKGV2ZW50KSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZyhldmVudCk7XHJcbiAgICBjb25zdCBkYiA9IG5ldyBDb25uZWN0REIoKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGF3YWl0IGRiLmNvbm5lY3QoKTtcclxuXHJcbiAgICAgICAgY29uc3QgeyByb3dzIH0gPSBhd2FpdCBjbGllbnQucXVlcnkoYHNlbGVjdCBwcm9kdWN0cy4qLCBzdG9jay5jb3VudCBmcm9tIHByb2R1Y3RzIGxlZnQgam9pbiBzdG9jayBvbiBwcm9kdWN0cy5pZCA9IHN0b2NrLnByb2R1Y3RfaWRgKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICAgICAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU1ldGhvZHMnOiAnKicsXHJcbiAgICAgICAgICAgICAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICcqJyxcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcclxuICAgICAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHJvd3MpXHJcbiAgICAgICAgICAgIH07XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU1ldGhvZHMnOiAnKicsXHJcbiAgICAgICAgICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDUwMCxcclxuICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoZXJyb3IubWVzc2FnZSlcclxuICAgICAgICB9O1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBkYi5kaXNjb25uZWN0KCk7XHJcbiAgICB9XHJcbn07IiwidHJ5IHtcbiAgdmFyIHV0aWwgPSByZXF1aXJlKCd1dGlsJyk7XG4gIC8qIGlzdGFuYnVsIGlnbm9yZSBuZXh0ICovXG4gIGlmICh0eXBlb2YgdXRpbC5pbmhlcml0cyAhPT0gJ2Z1bmN0aW9uJykgdGhyb3cgJyc7XG4gIG1vZHVsZS5leHBvcnRzID0gdXRpbC5pbmhlcml0cztcbn0gY2F0Y2ggKGUpIHtcbiAgLyogaXN0YW5idWwgaWdub3JlIG5leHQgKi9cbiAgbW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuL2luaGVyaXRzX2Jyb3dzZXIuanMnKTtcbn1cbiIsImlmICh0eXBlb2YgT2JqZWN0LmNyZWF0ZSA9PT0gJ2Z1bmN0aW9uJykge1xuICAvLyBpbXBsZW1lbnRhdGlvbiBmcm9tIHN0YW5kYXJkIG5vZGUuanMgJ3V0aWwnIG1vZHVsZVxuICBtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGluaGVyaXRzKGN0b3IsIHN1cGVyQ3Rvcikge1xuICAgIGlmIChzdXBlckN0b3IpIHtcbiAgICAgIGN0b3Iuc3VwZXJfID0gc3VwZXJDdG9yXG4gICAgICBjdG9yLnByb3RvdHlwZSA9IE9iamVjdC5jcmVhdGUoc3VwZXJDdG9yLnByb3RvdHlwZSwge1xuICAgICAgICBjb25zdHJ1Y3Rvcjoge1xuICAgICAgICAgIHZhbHVlOiBjdG9yLFxuICAgICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgICAgICB9XG4gICAgICB9KVxuICAgIH1cbiAgfTtcbn0gZWxzZSB7XG4gIC8vIG9sZCBzY2hvb2wgc2hpbSBmb3Igb2xkIGJyb3dzZXJzXG4gIG1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gaW5oZXJpdHMoY3Rvciwgc3VwZXJDdG9yKSB7XG4gICAgaWYgKHN1cGVyQ3Rvcikge1xuICAgICAgY3Rvci5zdXBlcl8gPSBzdXBlckN0b3JcbiAgICAgIHZhciBUZW1wQ3RvciA9IGZ1bmN0aW9uICgpIHt9XG4gICAgICBUZW1wQ3Rvci5wcm90b3R5cGUgPSBzdXBlckN0b3IucHJvdG90eXBlXG4gICAgICBjdG9yLnByb3RvdHlwZSA9IG5ldyBUZW1wQ3RvcigpXG4gICAgICBjdG9yLnByb3RvdHlwZS5jb25zdHJ1Y3RvciA9IGN0b3JcbiAgICB9XG4gIH1cbn1cbiIsIid1c2Ugc3RyaWN0J1xuXG52YXIgdXJsID0gcmVxdWlyZSgndXJsJylcbnZhciBmcyA9IHJlcXVpcmUoJ2ZzJylcblxuLy9QYXJzZSBtZXRob2QgY29waWVkIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL2JyaWFuYy9ub2RlLXBvc3RncmVzXG4vL0NvcHlyaWdodCAoYykgMjAxMC0yMDE0IEJyaWFuIENhcmxzb24gKGJyaWFuLm0uY2FybHNvbkBnbWFpbC5jb20pXG4vL01JVCBMaWNlbnNlXG5cbi8vcGFyc2VzIGEgY29ubmVjdGlvbiBzdHJpbmdcbmZ1bmN0aW9uIHBhcnNlKHN0cikge1xuICAvL3VuaXggc29ja2V0XG4gIGlmIChzdHIuY2hhckF0KDApID09PSAnLycpIHtcbiAgICB2YXIgY29uZmlnID0gc3RyLnNwbGl0KCcgJylcbiAgICByZXR1cm4geyBob3N0OiBjb25maWdbMF0sIGRhdGFiYXNlOiBjb25maWdbMV0gfVxuICB9XG5cbiAgLy8gdXJsIHBhcnNlIGV4cGVjdHMgc3BhY2VzIGVuY29kZWQgYXMgJTIwXG4gIHZhciByZXN1bHQgPSB1cmwucGFyc2UoXG4gICAgLyB8JVteYS1mMC05XXwlW2EtZjAtOV1bXmEtZjAtOV0vaS50ZXN0KHN0cikgPyBlbmNvZGVVUkkoc3RyKS5yZXBsYWNlKC9cXCUyNShcXGRcXGQpL2csICclJDEnKSA6IHN0cixcbiAgICB0cnVlXG4gIClcbiAgdmFyIGNvbmZpZyA9IHJlc3VsdC5xdWVyeVxuICBmb3IgKHZhciBrIGluIGNvbmZpZykge1xuICAgIGlmIChBcnJheS5pc0FycmF5KGNvbmZpZ1trXSkpIHtcbiAgICAgIGNvbmZpZ1trXSA9IGNvbmZpZ1trXVtjb25maWdba10ubGVuZ3RoIC0gMV1cbiAgICB9XG4gIH1cblxuICB2YXIgYXV0aCA9IChyZXN1bHQuYXV0aCB8fCAnOicpLnNwbGl0KCc6JylcbiAgY29uZmlnLnVzZXIgPSBhdXRoWzBdXG4gIGNvbmZpZy5wYXNzd29yZCA9IGF1dGguc3BsaWNlKDEpLmpvaW4oJzonKVxuXG4gIGNvbmZpZy5wb3J0ID0gcmVzdWx0LnBvcnRcbiAgaWYgKHJlc3VsdC5wcm90b2NvbCA9PSAnc29ja2V0OicpIHtcbiAgICBjb25maWcuaG9zdCA9IGRlY29kZVVSSShyZXN1bHQucGF0aG5hbWUpXG4gICAgY29uZmlnLmRhdGFiYXNlID0gcmVzdWx0LnF1ZXJ5LmRiXG4gICAgY29uZmlnLmNsaWVudF9lbmNvZGluZyA9IHJlc3VsdC5xdWVyeS5lbmNvZGluZ1xuICAgIHJldHVybiBjb25maWdcbiAgfVxuICBpZiAoIWNvbmZpZy5ob3N0KSB7XG4gICAgLy8gT25seSBzZXQgdGhlIGhvc3QgaWYgdGhlcmUgaXMgbm8gZXF1aXZhbGVudCBxdWVyeSBwYXJhbS5cbiAgICBjb25maWcuaG9zdCA9IHJlc3VsdC5ob3N0bmFtZVxuICB9XG5cbiAgLy8gSWYgdGhlIGhvc3QgaXMgbWlzc2luZyBpdCBtaWdodCBiZSBhIFVSTC1lbmNvZGVkIHBhdGggdG8gYSBzb2NrZXQuXG4gIHZhciBwYXRobmFtZSA9IHJlc3VsdC5wYXRobmFtZVxuICBpZiAoIWNvbmZpZy5ob3N0ICYmIHBhdGhuYW1lICYmIC9eJTJmL2kudGVzdChwYXRobmFtZSkpIHtcbiAgICB2YXIgcGF0aG5hbWVTcGxpdCA9IHBhdGhuYW1lLnNwbGl0KCcvJylcbiAgICBjb25maWcuaG9zdCA9IGRlY29kZVVSSUNvbXBvbmVudChwYXRobmFtZVNwbGl0WzBdKVxuICAgIHBhdGhuYW1lID0gcGF0aG5hbWVTcGxpdC5zcGxpY2UoMSkuam9pbignLycpXG4gIH1cbiAgLy8gcmVzdWx0LnBhdGhuYW1lIGlzIG5vdCBhbHdheXMgZ3VhcmFudGVlZCB0byBoYXZlIGEgJy8nIHByZWZpeCAoZS5nLiByZWxhdGl2ZSB1cmxzKVxuICAvLyBvbmx5IHN0cmlwIHRoZSBzbGFzaCBpZiBpdCBpcyBwcmVzZW50LlxuICBpZiAocGF0aG5hbWUgJiYgcGF0aG5hbWUuY2hhckF0KDApID09PSAnLycpIHtcbiAgICBwYXRobmFtZSA9IHBhdGhuYW1lLnNsaWNlKDEpIHx8IG51bGxcbiAgfVxuICBjb25maWcuZGF0YWJhc2UgPSBwYXRobmFtZSAmJiBkZWNvZGVVUkkocGF0aG5hbWUpXG5cbiAgaWYgKGNvbmZpZy5zc2wgPT09ICd0cnVlJyB8fCBjb25maWcuc3NsID09PSAnMScpIHtcbiAgICBjb25maWcuc3NsID0gdHJ1ZVxuICB9XG5cbiAgaWYgKGNvbmZpZy5zc2wgPT09ICcwJykge1xuICAgIGNvbmZpZy5zc2wgPSBmYWxzZVxuICB9XG5cbiAgaWYgKGNvbmZpZy5zc2xjZXJ0IHx8IGNvbmZpZy5zc2xrZXkgfHwgY29uZmlnLnNzbHJvb3RjZXJ0IHx8IGNvbmZpZy5zc2xtb2RlKSB7XG4gICAgY29uZmlnLnNzbCA9IHt9XG4gIH1cblxuICBpZiAoY29uZmlnLnNzbGNlcnQpIHtcbiAgICBjb25maWcuc3NsLmNlcnQgPSBmcy5yZWFkRmlsZVN5bmMoY29uZmlnLnNzbGNlcnQpLnRvU3RyaW5nKClcbiAgfVxuXG4gIGlmIChjb25maWcuc3Nsa2V5KSB7XG4gICAgY29uZmlnLnNzbC5rZXkgPSBmcy5yZWFkRmlsZVN5bmMoY29uZmlnLnNzbGtleSkudG9TdHJpbmcoKVxuICB9XG5cbiAgaWYgKGNvbmZpZy5zc2xyb290Y2VydCkge1xuICAgIGNvbmZpZy5zc2wuY2EgPSBmcy5yZWFkRmlsZVN5bmMoY29uZmlnLnNzbHJvb3RjZXJ0KS50b1N0cmluZygpXG4gIH1cblxuICBzd2l0Y2ggKGNvbmZpZy5zc2xtb2RlKSB7XG4gICAgY2FzZSAnZGlzYWJsZSc6IHtcbiAgICAgIGNvbmZpZy5zc2wgPSBmYWxzZVxuICAgICAgYnJlYWtcbiAgICB9XG4gICAgY2FzZSAncHJlZmVyJzpcbiAgICBjYXNlICdyZXF1aXJlJzpcbiAgICBjYXNlICd2ZXJpZnktY2EnOlxuICAgIGNhc2UgJ3ZlcmlmeS1mdWxsJzoge1xuICAgICAgYnJlYWtcbiAgICB9XG4gICAgY2FzZSAnbm8tdmVyaWZ5Jzoge1xuICAgICAgY29uZmlnLnNzbC5yZWplY3RVbmF1dGhvcml6ZWQgPSBmYWxzZVxuICAgICAgYnJlYWtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gY29uZmlnXG59XG5cbm1vZHVsZS5leHBvcnRzID0gcGFyc2VcblxucGFyc2UucGFyc2UgPSBwYXJzZVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG4vLyBzZWxlY3RlZCBzbyAoQkFTRSAtIDEpICogMHgxMDAwMDAwMDAgKyAweGZmZmZmZmZmIGlzIGEgc2FmZSBpbnRlZ2VyXG52YXIgQkFTRSA9IDEwMDAwMDA7XG5cbmZ1bmN0aW9uIHJlYWRJbnQ4KGJ1ZmZlcikge1xuXHR2YXIgaGlnaCA9IGJ1ZmZlci5yZWFkSW50MzJCRSgwKTtcblx0dmFyIGxvdyA9IGJ1ZmZlci5yZWFkVUludDMyQkUoNCk7XG5cdHZhciBzaWduID0gJyc7XG5cblx0aWYgKGhpZ2ggPCAwKSB7XG5cdFx0aGlnaCA9IH5oaWdoICsgKGxvdyA9PT0gMCk7XG5cdFx0bG93ID0gKH5sb3cgKyAxKSA+Pj4gMDtcblx0XHRzaWduID0gJy0nO1xuXHR9XG5cblx0dmFyIHJlc3VsdCA9ICcnO1xuXHR2YXIgY2Fycnk7XG5cdHZhciB0O1xuXHR2YXIgZGlnaXRzO1xuXHR2YXIgcGFkO1xuXHR2YXIgbDtcblx0dmFyIGk7XG5cblx0e1xuXHRcdGNhcnJ5ID0gaGlnaCAlIEJBU0U7XG5cdFx0aGlnaCA9IGhpZ2ggLyBCQVNFID4+PiAwO1xuXG5cdFx0dCA9IDB4MTAwMDAwMDAwICogY2FycnkgKyBsb3c7XG5cdFx0bG93ID0gdCAvIEJBU0UgPj4+IDA7XG5cdFx0ZGlnaXRzID0gJycgKyAodCAtIEJBU0UgKiBsb3cpO1xuXG5cdFx0aWYgKGxvdyA9PT0gMCAmJiBoaWdoID09PSAwKSB7XG5cdFx0XHRyZXR1cm4gc2lnbiArIGRpZ2l0cyArIHJlc3VsdDtcblx0XHR9XG5cblx0XHRwYWQgPSAnJztcblx0XHRsID0gNiAtIGRpZ2l0cy5sZW5ndGg7XG5cblx0XHRmb3IgKGkgPSAwOyBpIDwgbDsgaSsrKSB7XG5cdFx0XHRwYWQgKz0gJzAnO1xuXHRcdH1cblxuXHRcdHJlc3VsdCA9IHBhZCArIGRpZ2l0cyArIHJlc3VsdDtcblx0fVxuXG5cdHtcblx0XHRjYXJyeSA9IGhpZ2ggJSBCQVNFO1xuXHRcdGhpZ2ggPSBoaWdoIC8gQkFTRSA+Pj4gMDtcblxuXHRcdHQgPSAweDEwMDAwMDAwMCAqIGNhcnJ5ICsgbG93O1xuXHRcdGxvdyA9IHQgLyBCQVNFID4+PiAwO1xuXHRcdGRpZ2l0cyA9ICcnICsgKHQgLSBCQVNFICogbG93KTtcblxuXHRcdGlmIChsb3cgPT09IDAgJiYgaGlnaCA9PT0gMCkge1xuXHRcdFx0cmV0dXJuIHNpZ24gKyBkaWdpdHMgKyByZXN1bHQ7XG5cdFx0fVxuXG5cdFx0cGFkID0gJyc7XG5cdFx0bCA9IDYgLSBkaWdpdHMubGVuZ3RoO1xuXG5cdFx0Zm9yIChpID0gMDsgaSA8IGw7IGkrKykge1xuXHRcdFx0cGFkICs9ICcwJztcblx0XHR9XG5cblx0XHRyZXN1bHQgPSBwYWQgKyBkaWdpdHMgKyByZXN1bHQ7XG5cdH1cblxuXHR7XG5cdFx0Y2FycnkgPSBoaWdoICUgQkFTRTtcblx0XHRoaWdoID0gaGlnaCAvIEJBU0UgPj4+IDA7XG5cblx0XHR0ID0gMHgxMDAwMDAwMDAgKiBjYXJyeSArIGxvdztcblx0XHRsb3cgPSB0IC8gQkFTRSA+Pj4gMDtcblx0XHRkaWdpdHMgPSAnJyArICh0IC0gQkFTRSAqIGxvdyk7XG5cblx0XHRpZiAobG93ID09PSAwICYmIGhpZ2ggPT09IDApIHtcblx0XHRcdHJldHVybiBzaWduICsgZGlnaXRzICsgcmVzdWx0O1xuXHRcdH1cblxuXHRcdHBhZCA9ICcnO1xuXHRcdGwgPSA2IC0gZGlnaXRzLmxlbmd0aDtcblxuXHRcdGZvciAoaSA9IDA7IGkgPCBsOyBpKyspIHtcblx0XHRcdHBhZCArPSAnMCc7XG5cdFx0fVxuXG5cdFx0cmVzdWx0ID0gcGFkICsgZGlnaXRzICsgcmVzdWx0O1xuXHR9XG5cblx0e1xuXHRcdGNhcnJ5ID0gaGlnaCAlIEJBU0U7XG5cdFx0dCA9IDB4MTAwMDAwMDAwICogY2FycnkgKyBsb3c7XG5cdFx0ZGlnaXRzID0gJycgKyB0ICUgQkFTRTtcblxuXHRcdHJldHVybiBzaWduICsgZGlnaXRzICsgcmVzdWx0O1xuXHR9XG59XG5cbm1vZHVsZS5leHBvcnRzID0gcmVhZEludDg7XG4iLCIndXNlIHN0cmljdCdcbmNvbnN0IEV2ZW50RW1pdHRlciA9IHJlcXVpcmUoJ2V2ZW50cycpLkV2ZW50RW1pdHRlclxuXG5jb25zdCBOT09QID0gZnVuY3Rpb24gKCkge31cblxuY29uc3QgcmVtb3ZlV2hlcmUgPSAobGlzdCwgcHJlZGljYXRlKSA9PiB7XG4gIGNvbnN0IGkgPSBsaXN0LmZpbmRJbmRleChwcmVkaWNhdGUpXG5cbiAgcmV0dXJuIGkgPT09IC0xID8gdW5kZWZpbmVkIDogbGlzdC5zcGxpY2UoaSwgMSlbMF1cbn1cblxuY2xhc3MgSWRsZUl0ZW0ge1xuICBjb25zdHJ1Y3RvcihjbGllbnQsIGlkbGVMaXN0ZW5lciwgdGltZW91dElkKSB7XG4gICAgdGhpcy5jbGllbnQgPSBjbGllbnRcbiAgICB0aGlzLmlkbGVMaXN0ZW5lciA9IGlkbGVMaXN0ZW5lclxuICAgIHRoaXMudGltZW91dElkID0gdGltZW91dElkXG4gIH1cbn1cblxuY2xhc3MgUGVuZGluZ0l0ZW0ge1xuICBjb25zdHJ1Y3RvcihjYWxsYmFjaykge1xuICAgIHRoaXMuY2FsbGJhY2sgPSBjYWxsYmFja1xuICB9XG59XG5cbmZ1bmN0aW9uIHRocm93T25Eb3VibGVSZWxlYXNlKCkge1xuICB0aHJvdyBuZXcgRXJyb3IoJ1JlbGVhc2UgY2FsbGVkIG9uIGNsaWVudCB3aGljaCBoYXMgYWxyZWFkeSBiZWVuIHJlbGVhc2VkIHRvIHRoZSBwb29sLicpXG59XG5cbmZ1bmN0aW9uIHByb21pc2lmeShQcm9taXNlLCBjYWxsYmFjaykge1xuICBpZiAoY2FsbGJhY2spIHtcbiAgICByZXR1cm4geyBjYWxsYmFjazogY2FsbGJhY2ssIHJlc3VsdDogdW5kZWZpbmVkIH1cbiAgfVxuICBsZXQgcmVqXG4gIGxldCByZXNcbiAgY29uc3QgY2IgPSBmdW5jdGlvbiAoZXJyLCBjbGllbnQpIHtcbiAgICBlcnIgPyByZWooZXJyKSA6IHJlcyhjbGllbnQpXG4gIH1cbiAgY29uc3QgcmVzdWx0ID0gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgIHJlcyA9IHJlc29sdmVcbiAgICByZWogPSByZWplY3RcbiAgfSlcbiAgcmV0dXJuIHsgY2FsbGJhY2s6IGNiLCByZXN1bHQ6IHJlc3VsdCB9XG59XG5cbmZ1bmN0aW9uIG1ha2VJZGxlTGlzdGVuZXIocG9vbCwgY2xpZW50KSB7XG4gIHJldHVybiBmdW5jdGlvbiBpZGxlTGlzdGVuZXIoZXJyKSB7XG4gICAgZXJyLmNsaWVudCA9IGNsaWVudFxuXG4gICAgY2xpZW50LnJlbW92ZUxpc3RlbmVyKCdlcnJvcicsIGlkbGVMaXN0ZW5lcilcbiAgICBjbGllbnQub24oJ2Vycm9yJywgKCkgPT4ge1xuICAgICAgcG9vbC5sb2coJ2FkZGl0aW9uYWwgY2xpZW50IGVycm9yIGFmdGVyIGRpc2Nvbm5lY3Rpb24gZHVlIHRvIGVycm9yJywgZXJyKVxuICAgIH0pXG4gICAgcG9vbC5fcmVtb3ZlKGNsaWVudClcbiAgICAvLyBUT0RPIC0gZG9jdW1lbnQgdGhhdCBvbmNlIHRoZSBwb29sIGVtaXRzIGFuIGVycm9yXG4gICAgLy8gdGhlIGNsaWVudCBoYXMgYWxyZWFkeSBiZWVuIGNsb3NlZCAmIHB1cmdlZCBhbmQgaXMgdW51c2FibGVcbiAgICBwb29sLmVtaXQoJ2Vycm9yJywgZXJyLCBjbGllbnQpXG4gIH1cbn1cblxuY2xhc3MgUG9vbCBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMsIENsaWVudCkge1xuICAgIHN1cGVyKClcbiAgICB0aGlzLm9wdGlvbnMgPSBPYmplY3QuYXNzaWduKHt9LCBvcHRpb25zKVxuXG4gICAgaWYgKG9wdGlvbnMgIT0gbnVsbCAmJiAncGFzc3dvcmQnIGluIG9wdGlvbnMpIHtcbiAgICAgIC8vIFwiaGlkaW5nXCIgdGhlIHBhc3N3b3JkIHNvIGl0IGRvZXNuJ3Qgc2hvdyB1cCBpbiBzdGFjayB0cmFjZXNcbiAgICAgIC8vIG9yIGlmIHRoZSBjbGllbnQgaXMgY29uc29sZS5sb2dnZWRcbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLm9wdGlvbnMsICdwYXNzd29yZCcsIHtcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICAgIHZhbHVlOiBvcHRpb25zLnBhc3N3b3JkLFxuICAgICAgfSlcbiAgICB9XG4gICAgaWYgKG9wdGlvbnMgIT0gbnVsbCAmJiBvcHRpb25zLnNzbCAmJiBvcHRpb25zLnNzbC5rZXkpIHtcbiAgICAgIC8vIFwiaGlkaW5nXCIgdGhlIHNzbC0+a2V5IHNvIGl0IGRvZXNuJ3Qgc2hvdyB1cCBpbiBzdGFjayB0cmFjZXNcbiAgICAgIC8vIG9yIGlmIHRoZSBjbGllbnQgaXMgY29uc29sZS5sb2dnZWRcbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLm9wdGlvbnMuc3NsLCAna2V5Jywge1xuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgIH0pXG4gICAgfVxuXG4gICAgdGhpcy5vcHRpb25zLm1heCA9IHRoaXMub3B0aW9ucy5tYXggfHwgdGhpcy5vcHRpb25zLnBvb2xTaXplIHx8IDEwXG4gICAgdGhpcy5vcHRpb25zLm1heFVzZXMgPSB0aGlzLm9wdGlvbnMubWF4VXNlcyB8fCBJbmZpbml0eVxuICAgIHRoaXMub3B0aW9ucy5hbGxvd0V4aXRPbklkbGUgPSB0aGlzLm9wdGlvbnMuYWxsb3dFeGl0T25JZGxlIHx8IGZhbHNlXG4gICAgdGhpcy5sb2cgPSB0aGlzLm9wdGlvbnMubG9nIHx8IGZ1bmN0aW9uICgpIHt9XG4gICAgdGhpcy5DbGllbnQgPSB0aGlzLm9wdGlvbnMuQ2xpZW50IHx8IENsaWVudCB8fCByZXF1aXJlKCdwZycpLkNsaWVudFxuICAgIHRoaXMuUHJvbWlzZSA9IHRoaXMub3B0aW9ucy5Qcm9taXNlIHx8IGdsb2JhbC5Qcm9taXNlXG5cbiAgICBpZiAodHlwZW9mIHRoaXMub3B0aW9ucy5pZGxlVGltZW91dE1pbGxpcyA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIHRoaXMub3B0aW9ucy5pZGxlVGltZW91dE1pbGxpcyA9IDEwMDAwXG4gICAgfVxuXG4gICAgdGhpcy5fY2xpZW50cyA9IFtdXG4gICAgdGhpcy5faWRsZSA9IFtdXG4gICAgdGhpcy5fcGVuZGluZ1F1ZXVlID0gW11cbiAgICB0aGlzLl9lbmRDYWxsYmFjayA9IHVuZGVmaW5lZFxuICAgIHRoaXMuZW5kaW5nID0gZmFsc2VcbiAgICB0aGlzLmVuZGVkID0gZmFsc2VcbiAgfVxuXG4gIF9pc0Z1bGwoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NsaWVudHMubGVuZ3RoID49IHRoaXMub3B0aW9ucy5tYXhcbiAgfVxuXG4gIF9wdWxzZVF1ZXVlKCkge1xuICAgIHRoaXMubG9nKCdwdWxzZSBxdWV1ZScpXG4gICAgaWYgKHRoaXMuZW5kZWQpIHtcbiAgICAgIHRoaXMubG9nKCdwdWxzZSBxdWV1ZSBlbmRlZCcpXG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgaWYgKHRoaXMuZW5kaW5nKSB7XG4gICAgICB0aGlzLmxvZygncHVsc2UgcXVldWUgb24gZW5kaW5nJylcbiAgICAgIGlmICh0aGlzLl9pZGxlLmxlbmd0aCkge1xuICAgICAgICB0aGlzLl9pZGxlLnNsaWNlKCkubWFwKChpdGVtKSA9PiB7XG4gICAgICAgICAgdGhpcy5fcmVtb3ZlKGl0ZW0uY2xpZW50KVxuICAgICAgICB9KVxuICAgICAgfVxuICAgICAgaWYgKCF0aGlzLl9jbGllbnRzLmxlbmd0aCkge1xuICAgICAgICB0aGlzLmVuZGVkID0gdHJ1ZVxuICAgICAgICB0aGlzLl9lbmRDYWxsYmFjaygpXG4gICAgICB9XG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgLy8gaWYgd2UgZG9uJ3QgaGF2ZSBhbnkgd2FpdGluZywgZG8gbm90aGluZ1xuICAgIGlmICghdGhpcy5fcGVuZGluZ1F1ZXVlLmxlbmd0aCkge1xuICAgICAgdGhpcy5sb2coJ25vIHF1ZXVlZCByZXF1ZXN0cycpXG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgLy8gaWYgd2UgZG9uJ3QgaGF2ZSBhbnkgaWRsZSBjbGllbnRzIGFuZCB3ZSBoYXZlIG5vIG1vcmUgcm9vbSBkbyBub3RoaW5nXG4gICAgaWYgKCF0aGlzLl9pZGxlLmxlbmd0aCAmJiB0aGlzLl9pc0Z1bGwoKSkge1xuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIGNvbnN0IHBlbmRpbmdJdGVtID0gdGhpcy5fcGVuZGluZ1F1ZXVlLnNoaWZ0KClcbiAgICBpZiAodGhpcy5faWRsZS5sZW5ndGgpIHtcbiAgICAgIGNvbnN0IGlkbGVJdGVtID0gdGhpcy5faWRsZS5wb3AoKVxuICAgICAgY2xlYXJUaW1lb3V0KGlkbGVJdGVtLnRpbWVvdXRJZClcbiAgICAgIGNvbnN0IGNsaWVudCA9IGlkbGVJdGVtLmNsaWVudFxuICAgICAgY2xpZW50LnJlZiAmJiBjbGllbnQucmVmKClcbiAgICAgIGNvbnN0IGlkbGVMaXN0ZW5lciA9IGlkbGVJdGVtLmlkbGVMaXN0ZW5lclxuXG4gICAgICByZXR1cm4gdGhpcy5fYWNxdWlyZUNsaWVudChjbGllbnQsIHBlbmRpbmdJdGVtLCBpZGxlTGlzdGVuZXIsIGZhbHNlKVxuICAgIH1cbiAgICBpZiAoIXRoaXMuX2lzRnVsbCgpKSB7XG4gICAgICByZXR1cm4gdGhpcy5uZXdDbGllbnQocGVuZGluZ0l0ZW0pXG4gICAgfVxuICAgIHRocm93IG5ldyBFcnJvcigndW5leHBlY3RlZCBjb25kaXRpb24nKVxuICB9XG5cbiAgX3JlbW92ZShjbGllbnQpIHtcbiAgICBjb25zdCByZW1vdmVkID0gcmVtb3ZlV2hlcmUodGhpcy5faWRsZSwgKGl0ZW0pID0+IGl0ZW0uY2xpZW50ID09PSBjbGllbnQpXG5cbiAgICBpZiAocmVtb3ZlZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBjbGVhclRpbWVvdXQocmVtb3ZlZC50aW1lb3V0SWQpXG4gICAgfVxuXG4gICAgdGhpcy5fY2xpZW50cyA9IHRoaXMuX2NsaWVudHMuZmlsdGVyKChjKSA9PiBjICE9PSBjbGllbnQpXG4gICAgY2xpZW50LmVuZCgpXG4gICAgdGhpcy5lbWl0KCdyZW1vdmUnLCBjbGllbnQpXG4gIH1cblxuICBjb25uZWN0KGNiKSB7XG4gICAgaWYgKHRoaXMuZW5kaW5nKSB7XG4gICAgICBjb25zdCBlcnIgPSBuZXcgRXJyb3IoJ0Nhbm5vdCB1c2UgYSBwb29sIGFmdGVyIGNhbGxpbmcgZW5kIG9uIHRoZSBwb29sJylcbiAgICAgIHJldHVybiBjYiA/IGNiKGVycikgOiB0aGlzLlByb21pc2UucmVqZWN0KGVycilcbiAgICB9XG5cbiAgICBjb25zdCByZXNwb25zZSA9IHByb21pc2lmeSh0aGlzLlByb21pc2UsIGNiKVxuICAgIGNvbnN0IHJlc3VsdCA9IHJlc3BvbnNlLnJlc3VsdFxuXG4gICAgLy8gaWYgd2UgZG9uJ3QgaGF2ZSB0byBjb25uZWN0IGEgbmV3IGNsaWVudCwgZG9uJ3QgZG8gc29cbiAgICBpZiAodGhpcy5faXNGdWxsKCkgfHwgdGhpcy5faWRsZS5sZW5ndGgpIHtcbiAgICAgIC8vIGlmIHdlIGhhdmUgaWRsZSBjbGllbnRzIHNjaGVkdWxlIGEgcHVsc2UgaW1tZWRpYXRlbHlcbiAgICAgIGlmICh0aGlzLl9pZGxlLmxlbmd0aCkge1xuICAgICAgICBwcm9jZXNzLm5leHRUaWNrKCgpID0+IHRoaXMuX3B1bHNlUXVldWUoKSlcbiAgICAgIH1cblxuICAgICAgaWYgKCF0aGlzLm9wdGlvbnMuY29ubmVjdGlvblRpbWVvdXRNaWxsaXMpIHtcbiAgICAgICAgdGhpcy5fcGVuZGluZ1F1ZXVlLnB1c2gobmV3IFBlbmRpbmdJdGVtKHJlc3BvbnNlLmNhbGxiYWNrKSlcbiAgICAgICAgcmV0dXJuIHJlc3VsdFxuICAgICAgfVxuXG4gICAgICBjb25zdCBxdWV1ZUNhbGxiYWNrID0gKGVyciwgcmVzLCBkb25lKSA9PiB7XG4gICAgICAgIGNsZWFyVGltZW91dCh0aWQpXG4gICAgICAgIHJlc3BvbnNlLmNhbGxiYWNrKGVyciwgcmVzLCBkb25lKVxuICAgICAgfVxuXG4gICAgICBjb25zdCBwZW5kaW5nSXRlbSA9IG5ldyBQZW5kaW5nSXRlbShxdWV1ZUNhbGxiYWNrKVxuXG4gICAgICAvLyBzZXQgY29ubmVjdGlvbiB0aW1lb3V0IG9uIGNoZWNraW5nIG91dCBhbiBleGlzdGluZyBjbGllbnRcbiAgICAgIGNvbnN0IHRpZCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAvLyByZW1vdmUgdGhlIGNhbGxiYWNrIGZyb20gcGVuZGluZyB3YWl0ZXJzIGJlY2F1c2VcbiAgICAgICAgLy8gd2UncmUgZ29pbmcgdG8gY2FsbCBpdCB3aXRoIGEgdGltZW91dCBlcnJvclxuICAgICAgICByZW1vdmVXaGVyZSh0aGlzLl9wZW5kaW5nUXVldWUsIChpKSA9PiBpLmNhbGxiYWNrID09PSBxdWV1ZUNhbGxiYWNrKVxuICAgICAgICBwZW5kaW5nSXRlbS50aW1lZE91dCA9IHRydWVcbiAgICAgICAgcmVzcG9uc2UuY2FsbGJhY2sobmV3IEVycm9yKCd0aW1lb3V0IGV4Y2VlZGVkIHdoZW4gdHJ5aW5nIHRvIGNvbm5lY3QnKSlcbiAgICAgIH0sIHRoaXMub3B0aW9ucy5jb25uZWN0aW9uVGltZW91dE1pbGxpcylcblxuICAgICAgdGhpcy5fcGVuZGluZ1F1ZXVlLnB1c2gocGVuZGluZ0l0ZW0pXG4gICAgICByZXR1cm4gcmVzdWx0XG4gICAgfVxuXG4gICAgdGhpcy5uZXdDbGllbnQobmV3IFBlbmRpbmdJdGVtKHJlc3BvbnNlLmNhbGxiYWNrKSlcblxuICAgIHJldHVybiByZXN1bHRcbiAgfVxuXG4gIG5ld0NsaWVudChwZW5kaW5nSXRlbSkge1xuICAgIGNvbnN0IGNsaWVudCA9IG5ldyB0aGlzLkNsaWVudCh0aGlzLm9wdGlvbnMpXG4gICAgdGhpcy5fY2xpZW50cy5wdXNoKGNsaWVudClcbiAgICBjb25zdCBpZGxlTGlzdGVuZXIgPSBtYWtlSWRsZUxpc3RlbmVyKHRoaXMsIGNsaWVudClcblxuICAgIHRoaXMubG9nKCdjaGVja2luZyBjbGllbnQgdGltZW91dCcpXG5cbiAgICAvLyBjb25uZWN0aW9uIHRpbWVvdXQgbG9naWNcbiAgICBsZXQgdGlkXG4gICAgbGV0IHRpbWVvdXRIaXQgPSBmYWxzZVxuICAgIGlmICh0aGlzLm9wdGlvbnMuY29ubmVjdGlvblRpbWVvdXRNaWxsaXMpIHtcbiAgICAgIHRpZCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICB0aGlzLmxvZygnZW5kaW5nIGNsaWVudCBkdWUgdG8gdGltZW91dCcpXG4gICAgICAgIHRpbWVvdXRIaXQgPSB0cnVlXG4gICAgICAgIC8vIGZvcmNlIGtpbGwgdGhlIG5vZGUgZHJpdmVyLCBhbmQgbGV0IGxpYnBxIGRvIGl0cyB0ZWFyZG93blxuICAgICAgICBjbGllbnQuY29ubmVjdGlvbiA/IGNsaWVudC5jb25uZWN0aW9uLnN0cmVhbS5kZXN0cm95KCkgOiBjbGllbnQuZW5kKClcbiAgICAgIH0sIHRoaXMub3B0aW9ucy5jb25uZWN0aW9uVGltZW91dE1pbGxpcylcbiAgICB9XG5cbiAgICB0aGlzLmxvZygnY29ubmVjdGluZyBuZXcgY2xpZW50JylcbiAgICBjbGllbnQuY29ubmVjdCgoZXJyKSA9PiB7XG4gICAgICBpZiAodGlkKSB7XG4gICAgICAgIGNsZWFyVGltZW91dCh0aWQpXG4gICAgICB9XG4gICAgICBjbGllbnQub24oJ2Vycm9yJywgaWRsZUxpc3RlbmVyKVxuICAgICAgaWYgKGVycikge1xuICAgICAgICB0aGlzLmxvZygnY2xpZW50IGZhaWxlZCB0byBjb25uZWN0JywgZXJyKVxuICAgICAgICAvLyByZW1vdmUgdGhlIGRlYWQgY2xpZW50IGZyb20gb3VyIGxpc3Qgb2YgY2xpZW50c1xuICAgICAgICB0aGlzLl9jbGllbnRzID0gdGhpcy5fY2xpZW50cy5maWx0ZXIoKGMpID0+IGMgIT09IGNsaWVudClcbiAgICAgICAgaWYgKHRpbWVvdXRIaXQpIHtcbiAgICAgICAgICBlcnIubWVzc2FnZSA9ICdDb25uZWN0aW9uIHRlcm1pbmF0ZWQgZHVlIHRvIGNvbm5lY3Rpb24gdGltZW91dCdcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHRoaXMgY2xpZW50IHdvbuKAmXQgYmUgcmVsZWFzZWQsIHNvIG1vdmUgb24gaW1tZWRpYXRlbHlcbiAgICAgICAgdGhpcy5fcHVsc2VRdWV1ZSgpXG5cbiAgICAgICAgaWYgKCFwZW5kaW5nSXRlbS50aW1lZE91dCkge1xuICAgICAgICAgIHBlbmRpbmdJdGVtLmNhbGxiYWNrKGVyciwgdW5kZWZpbmVkLCBOT09QKVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLmxvZygnbmV3IGNsaWVudCBjb25uZWN0ZWQnKVxuXG4gICAgICAgIHJldHVybiB0aGlzLl9hY3F1aXJlQ2xpZW50KGNsaWVudCwgcGVuZGluZ0l0ZW0sIGlkbGVMaXN0ZW5lciwgdHJ1ZSlcbiAgICAgIH1cbiAgICB9KVxuICB9XG5cbiAgLy8gYWNxdWlyZSBhIGNsaWVudCBmb3IgYSBwZW5kaW5nIHdvcmsgaXRlbVxuICBfYWNxdWlyZUNsaWVudChjbGllbnQsIHBlbmRpbmdJdGVtLCBpZGxlTGlzdGVuZXIsIGlzTmV3KSB7XG4gICAgaWYgKGlzTmV3KSB7XG4gICAgICB0aGlzLmVtaXQoJ2Nvbm5lY3QnLCBjbGllbnQpXG4gICAgfVxuXG4gICAgdGhpcy5lbWl0KCdhY3F1aXJlJywgY2xpZW50KVxuXG4gICAgY2xpZW50LnJlbGVhc2UgPSB0aGlzLl9yZWxlYXNlT25jZShjbGllbnQsIGlkbGVMaXN0ZW5lcilcblxuICAgIGNsaWVudC5yZW1vdmVMaXN0ZW5lcignZXJyb3InLCBpZGxlTGlzdGVuZXIpXG5cbiAgICBpZiAoIXBlbmRpbmdJdGVtLnRpbWVkT3V0KSB7XG4gICAgICBpZiAoaXNOZXcgJiYgdGhpcy5vcHRpb25zLnZlcmlmeSkge1xuICAgICAgICB0aGlzLm9wdGlvbnMudmVyaWZ5KGNsaWVudCwgKGVycikgPT4ge1xuICAgICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICAgIGNsaWVudC5yZWxlYXNlKGVycilcbiAgICAgICAgICAgIHJldHVybiBwZW5kaW5nSXRlbS5jYWxsYmFjayhlcnIsIHVuZGVmaW5lZCwgTk9PUClcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBwZW5kaW5nSXRlbS5jYWxsYmFjayh1bmRlZmluZWQsIGNsaWVudCwgY2xpZW50LnJlbGVhc2UpXG4gICAgICAgIH0pXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwZW5kaW5nSXRlbS5jYWxsYmFjayh1bmRlZmluZWQsIGNsaWVudCwgY2xpZW50LnJlbGVhc2UpXG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChpc05ldyAmJiB0aGlzLm9wdGlvbnMudmVyaWZ5KSB7XG4gICAgICAgIHRoaXMub3B0aW9ucy52ZXJpZnkoY2xpZW50LCBjbGllbnQucmVsZWFzZSlcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNsaWVudC5yZWxlYXNlKClcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvLyByZXR1cm5zIGEgZnVuY3Rpb24gdGhhdCB3cmFwcyBfcmVsZWFzZSBhbmQgdGhyb3dzIGlmIGNhbGxlZCBtb3JlIHRoYW4gb25jZVxuICBfcmVsZWFzZU9uY2UoY2xpZW50LCBpZGxlTGlzdGVuZXIpIHtcbiAgICBsZXQgcmVsZWFzZWQgPSBmYWxzZVxuXG4gICAgcmV0dXJuIChlcnIpID0+IHtcbiAgICAgIGlmIChyZWxlYXNlZCkge1xuICAgICAgICB0aHJvd09uRG91YmxlUmVsZWFzZSgpXG4gICAgICB9XG5cbiAgICAgIHJlbGVhc2VkID0gdHJ1ZVxuICAgICAgdGhpcy5fcmVsZWFzZShjbGllbnQsIGlkbGVMaXN0ZW5lciwgZXJyKVxuICAgIH1cbiAgfVxuXG4gIC8vIHJlbGVhc2UgYSBjbGllbnQgYmFjayB0byB0aGUgcG9sbCwgaW5jbHVkZSBhbiBlcnJvclxuICAvLyB0byByZW1vdmUgaXQgZnJvbSB0aGUgcG9vbFxuICBfcmVsZWFzZShjbGllbnQsIGlkbGVMaXN0ZW5lciwgZXJyKSB7XG4gICAgY2xpZW50Lm9uKCdlcnJvcicsIGlkbGVMaXN0ZW5lcilcblxuICAgIGNsaWVudC5fcG9vbFVzZUNvdW50ID0gKGNsaWVudC5fcG9vbFVzZUNvdW50IHx8IDApICsgMVxuXG4gICAgLy8gVE9ETyhibWMpOiBleHBvc2UgYSBwcm9wZXIsIHB1YmxpYyBpbnRlcmZhY2UgX3F1ZXJ5YWJsZSBhbmQgX2VuZGluZ1xuICAgIGlmIChlcnIgfHwgdGhpcy5lbmRpbmcgfHwgIWNsaWVudC5fcXVlcnlhYmxlIHx8IGNsaWVudC5fZW5kaW5nIHx8IGNsaWVudC5fcG9vbFVzZUNvdW50ID49IHRoaXMub3B0aW9ucy5tYXhVc2VzKSB7XG4gICAgICBpZiAoY2xpZW50Ll9wb29sVXNlQ291bnQgPj0gdGhpcy5vcHRpb25zLm1heFVzZXMpIHtcbiAgICAgICAgdGhpcy5sb2coJ3JlbW92ZSBleHBlbmRlZCBjbGllbnQnKVxuICAgICAgfVxuICAgICAgdGhpcy5fcmVtb3ZlKGNsaWVudClcbiAgICAgIHRoaXMuX3B1bHNlUXVldWUoKVxuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgLy8gaWRsZSB0aW1lb3V0XG4gICAgbGV0IHRpZFxuICAgIGlmICh0aGlzLm9wdGlvbnMuaWRsZVRpbWVvdXRNaWxsaXMpIHtcbiAgICAgIHRpZCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICB0aGlzLmxvZygncmVtb3ZlIGlkbGUgY2xpZW50JylcbiAgICAgICAgdGhpcy5fcmVtb3ZlKGNsaWVudClcbiAgICAgIH0sIHRoaXMub3B0aW9ucy5pZGxlVGltZW91dE1pbGxpcylcblxuICAgICAgaWYgKHRoaXMub3B0aW9ucy5hbGxvd0V4aXRPbklkbGUpIHtcbiAgICAgICAgLy8gYWxsb3cgTm9kZSB0byBleGl0IGlmIHRoaXMgaXMgYWxsIHRoYXQncyBsZWZ0XG4gICAgICAgIHRpZC51bnJlZigpXG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5hbGxvd0V4aXRPbklkbGUpIHtcbiAgICAgIGNsaWVudC51bnJlZigpXG4gICAgfVxuXG4gICAgdGhpcy5faWRsZS5wdXNoKG5ldyBJZGxlSXRlbShjbGllbnQsIGlkbGVMaXN0ZW5lciwgdGlkKSlcbiAgICB0aGlzLl9wdWxzZVF1ZXVlKClcbiAgfVxuXG4gIHF1ZXJ5KHRleHQsIHZhbHVlcywgY2IpIHtcbiAgICAvLyBndWFyZCBjbGF1c2UgYWdhaW5zdCBwYXNzaW5nIGEgZnVuY3Rpb24gYXMgdGhlIGZpcnN0IHBhcmFtZXRlclxuICAgIGlmICh0eXBlb2YgdGV4dCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBwcm9taXNpZnkodGhpcy5Qcm9taXNlLCB0ZXh0KVxuICAgICAgc2V0SW1tZWRpYXRlKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmNhbGxiYWNrKG5ldyBFcnJvcignUGFzc2luZyBhIGZ1bmN0aW9uIGFzIHRoZSBmaXJzdCBwYXJhbWV0ZXIgdG8gcG9vbC5xdWVyeSBpcyBub3Qgc3VwcG9ydGVkJykpXG4gICAgICB9KVxuICAgICAgcmV0dXJuIHJlc3BvbnNlLnJlc3VsdFxuICAgIH1cblxuICAgIC8vIGFsbG93IHBsYWluIHRleHQgcXVlcnkgd2l0aG91dCB2YWx1ZXNcbiAgICBpZiAodHlwZW9mIHZhbHVlcyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgY2IgPSB2YWx1ZXNcbiAgICAgIHZhbHVlcyA9IHVuZGVmaW5lZFxuICAgIH1cbiAgICBjb25zdCByZXNwb25zZSA9IHByb21pc2lmeSh0aGlzLlByb21pc2UsIGNiKVxuICAgIGNiID0gcmVzcG9uc2UuY2FsbGJhY2tcblxuICAgIHRoaXMuY29ubmVjdCgoZXJyLCBjbGllbnQpID0+IHtcbiAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgcmV0dXJuIGNiKGVycilcbiAgICAgIH1cblxuICAgICAgbGV0IGNsaWVudFJlbGVhc2VkID0gZmFsc2VcbiAgICAgIGNvbnN0IG9uRXJyb3IgPSAoZXJyKSA9PiB7XG4gICAgICAgIGlmIChjbGllbnRSZWxlYXNlZCkge1xuICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG4gICAgICAgIGNsaWVudFJlbGVhc2VkID0gdHJ1ZVxuICAgICAgICBjbGllbnQucmVsZWFzZShlcnIpXG4gICAgICAgIGNiKGVycilcbiAgICAgIH1cblxuICAgICAgY2xpZW50Lm9uY2UoJ2Vycm9yJywgb25FcnJvcilcbiAgICAgIHRoaXMubG9nKCdkaXNwYXRjaGluZyBxdWVyeScpXG4gICAgICBjbGllbnQucXVlcnkodGV4dCwgdmFsdWVzLCAoZXJyLCByZXMpID0+IHtcbiAgICAgICAgdGhpcy5sb2coJ3F1ZXJ5IGRpc3BhdGNoZWQnKVxuICAgICAgICBjbGllbnQucmVtb3ZlTGlzdGVuZXIoJ2Vycm9yJywgb25FcnJvcilcbiAgICAgICAgaWYgKGNsaWVudFJlbGVhc2VkKSB7XG4gICAgICAgICAgcmV0dXJuXG4gICAgICAgIH1cbiAgICAgICAgY2xpZW50UmVsZWFzZWQgPSB0cnVlXG4gICAgICAgIGNsaWVudC5yZWxlYXNlKGVycilcbiAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgIHJldHVybiBjYihlcnIpXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIGNiKHVuZGVmaW5lZCwgcmVzKVxuICAgICAgICB9XG4gICAgICB9KVxuICAgIH0pXG4gICAgcmV0dXJuIHJlc3BvbnNlLnJlc3VsdFxuICB9XG5cbiAgZW5kKGNiKSB7XG4gICAgdGhpcy5sb2coJ2VuZGluZycpXG4gICAgaWYgKHRoaXMuZW5kaW5nKSB7XG4gICAgICBjb25zdCBlcnIgPSBuZXcgRXJyb3IoJ0NhbGxlZCBlbmQgb24gcG9vbCBtb3JlIHRoYW4gb25jZScpXG4gICAgICByZXR1cm4gY2IgPyBjYihlcnIpIDogdGhpcy5Qcm9taXNlLnJlamVjdChlcnIpXG4gICAgfVxuICAgIHRoaXMuZW5kaW5nID0gdHJ1ZVxuICAgIGNvbnN0IHByb21pc2VkID0gcHJvbWlzaWZ5KHRoaXMuUHJvbWlzZSwgY2IpXG4gICAgdGhpcy5fZW5kQ2FsbGJhY2sgPSBwcm9taXNlZC5jYWxsYmFja1xuICAgIHRoaXMuX3B1bHNlUXVldWUoKVxuICAgIHJldHVybiBwcm9taXNlZC5yZXN1bHRcbiAgfVxuXG4gIGdldCB3YWl0aW5nQ291bnQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3BlbmRpbmdRdWV1ZS5sZW5ndGhcbiAgfVxuXG4gIGdldCBpZGxlQ291bnQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2lkbGUubGVuZ3RoXG4gIH1cblxuICBnZXQgdG90YWxDb3VudCgpIHtcbiAgICByZXR1cm4gdGhpcy5fY2xpZW50cy5sZW5ndGhcbiAgfVxufVxubW9kdWxlLmV4cG9ydHMgPSBQb29sXG4iLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuQnVmZmVyUmVhZGVyID0gdm9pZCAwO1xuY29uc3QgZW1wdHlCdWZmZXIgPSBCdWZmZXIuYWxsb2NVbnNhZmUoMCk7XG5jbGFzcyBCdWZmZXJSZWFkZXIge1xuICAgIGNvbnN0cnVjdG9yKG9mZnNldCA9IDApIHtcbiAgICAgICAgdGhpcy5vZmZzZXQgPSBvZmZzZXQ7XG4gICAgICAgIHRoaXMuYnVmZmVyID0gZW1wdHlCdWZmZXI7XG4gICAgICAgIC8vIFRPRE8oYm1jKTogc3VwcG9ydCBub24tdXRmOCBlbmNvZGluZz9cbiAgICAgICAgdGhpcy5lbmNvZGluZyA9ICd1dGYtOCc7XG4gICAgfVxuICAgIHNldEJ1ZmZlcihvZmZzZXQsIGJ1ZmZlcikge1xuICAgICAgICB0aGlzLm9mZnNldCA9IG9mZnNldDtcbiAgICAgICAgdGhpcy5idWZmZXIgPSBidWZmZXI7XG4gICAgfVxuICAgIGludDE2KCkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSB0aGlzLmJ1ZmZlci5yZWFkSW50MTZCRSh0aGlzLm9mZnNldCk7XG4gICAgICAgIHRoaXMub2Zmc2V0ICs9IDI7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIGJ5dGUoKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMuYnVmZmVyW3RoaXMub2Zmc2V0XTtcbiAgICAgICAgdGhpcy5vZmZzZXQrKztcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgaW50MzIoKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMuYnVmZmVyLnJlYWRJbnQzMkJFKHRoaXMub2Zmc2V0KTtcbiAgICAgICAgdGhpcy5vZmZzZXQgKz0gNDtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgc3RyaW5nKGxlbmd0aCkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSB0aGlzLmJ1ZmZlci50b1N0cmluZyh0aGlzLmVuY29kaW5nLCB0aGlzLm9mZnNldCwgdGhpcy5vZmZzZXQgKyBsZW5ndGgpO1xuICAgICAgICB0aGlzLm9mZnNldCArPSBsZW5ndGg7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIGNzdHJpbmcoKSB7XG4gICAgICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5vZmZzZXQ7XG4gICAgICAgIGxldCBlbmQgPSBzdGFydDtcbiAgICAgICAgd2hpbGUgKHRoaXMuYnVmZmVyW2VuZCsrXSAhPT0gMCkgeyB9XG4gICAgICAgIHRoaXMub2Zmc2V0ID0gZW5kO1xuICAgICAgICByZXR1cm4gdGhpcy5idWZmZXIudG9TdHJpbmcodGhpcy5lbmNvZGluZywgc3RhcnQsIGVuZCAtIDEpO1xuICAgIH1cbiAgICBieXRlcyhsZW5ndGgpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gdGhpcy5idWZmZXIuc2xpY2UodGhpcy5vZmZzZXQsIHRoaXMub2Zmc2V0ICsgbGVuZ3RoKTtcbiAgICAgICAgdGhpcy5vZmZzZXQgKz0gbGVuZ3RoO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbn1cbmV4cG9ydHMuQnVmZmVyUmVhZGVyID0gQnVmZmVyUmVhZGVyO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YnVmZmVyLXJlYWRlci5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbi8vYmluYXJ5IGRhdGEgd3JpdGVyIHR1bmVkIGZvciBlbmNvZGluZyBiaW5hcnkgc3BlY2lmaWMgdG8gdGhlIHBvc3RncmVzIGJpbmFyeSBwcm90b2NvbFxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5Xcml0ZXIgPSB2b2lkIDA7XG5jbGFzcyBXcml0ZXIge1xuICAgIGNvbnN0cnVjdG9yKHNpemUgPSAyNTYpIHtcbiAgICAgICAgdGhpcy5zaXplID0gc2l6ZTtcbiAgICAgICAgdGhpcy5vZmZzZXQgPSA1O1xuICAgICAgICB0aGlzLmhlYWRlclBvc2l0aW9uID0gMDtcbiAgICAgICAgdGhpcy5idWZmZXIgPSBCdWZmZXIuYWxsb2NVbnNhZmUoc2l6ZSk7XG4gICAgfVxuICAgIGVuc3VyZShzaXplKSB7XG4gICAgICAgIHZhciByZW1haW5pbmcgPSB0aGlzLmJ1ZmZlci5sZW5ndGggLSB0aGlzLm9mZnNldDtcbiAgICAgICAgaWYgKHJlbWFpbmluZyA8IHNpemUpIHtcbiAgICAgICAgICAgIHZhciBvbGRCdWZmZXIgPSB0aGlzLmJ1ZmZlcjtcbiAgICAgICAgICAgIC8vIGV4cG9uZW50aWFsIGdyb3d0aCBmYWN0b3Igb2YgYXJvdW5kIH4gMS41XG4gICAgICAgICAgICAvLyBodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL3F1ZXN0aW9ucy8yMjY5MDYzL2J1ZmZlci1ncm93dGgtc3RyYXRlZ3lcbiAgICAgICAgICAgIHZhciBuZXdTaXplID0gb2xkQnVmZmVyLmxlbmd0aCArIChvbGRCdWZmZXIubGVuZ3RoID4+IDEpICsgc2l6ZTtcbiAgICAgICAgICAgIHRoaXMuYnVmZmVyID0gQnVmZmVyLmFsbG9jVW5zYWZlKG5ld1NpemUpO1xuICAgICAgICAgICAgb2xkQnVmZmVyLmNvcHkodGhpcy5idWZmZXIpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGFkZEludDMyKG51bSkge1xuICAgICAgICB0aGlzLmVuc3VyZSg0KTtcbiAgICAgICAgdGhpcy5idWZmZXJbdGhpcy5vZmZzZXQrK10gPSAobnVtID4+PiAyNCkgJiAweGZmO1xuICAgICAgICB0aGlzLmJ1ZmZlclt0aGlzLm9mZnNldCsrXSA9IChudW0gPj4+IDE2KSAmIDB4ZmY7XG4gICAgICAgIHRoaXMuYnVmZmVyW3RoaXMub2Zmc2V0KytdID0gKG51bSA+Pj4gOCkgJiAweGZmO1xuICAgICAgICB0aGlzLmJ1ZmZlclt0aGlzLm9mZnNldCsrXSA9IChudW0gPj4+IDApICYgMHhmZjtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGFkZEludDE2KG51bSkge1xuICAgICAgICB0aGlzLmVuc3VyZSgyKTtcbiAgICAgICAgdGhpcy5idWZmZXJbdGhpcy5vZmZzZXQrK10gPSAobnVtID4+PiA4KSAmIDB4ZmY7XG4gICAgICAgIHRoaXMuYnVmZmVyW3RoaXMub2Zmc2V0KytdID0gKG51bSA+Pj4gMCkgJiAweGZmO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgYWRkQ1N0cmluZyhzdHJpbmcpIHtcbiAgICAgICAgaWYgKCFzdHJpbmcpIHtcbiAgICAgICAgICAgIHRoaXMuZW5zdXJlKDEpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdmFyIGxlbiA9IEJ1ZmZlci5ieXRlTGVuZ3RoKHN0cmluZyk7XG4gICAgICAgICAgICB0aGlzLmVuc3VyZShsZW4gKyAxKTsgLy8gKzEgZm9yIG51bGwgdGVybWluYXRvclxuICAgICAgICAgICAgdGhpcy5idWZmZXIud3JpdGUoc3RyaW5nLCB0aGlzLm9mZnNldCwgJ3V0Zi04Jyk7XG4gICAgICAgICAgICB0aGlzLm9mZnNldCArPSBsZW47XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5idWZmZXJbdGhpcy5vZmZzZXQrK10gPSAwOyAvLyBudWxsIHRlcm1pbmF0b3JcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGFkZFN0cmluZyhzdHJpbmcgPSAnJykge1xuICAgICAgICB2YXIgbGVuID0gQnVmZmVyLmJ5dGVMZW5ndGgoc3RyaW5nKTtcbiAgICAgICAgdGhpcy5lbnN1cmUobGVuKTtcbiAgICAgICAgdGhpcy5idWZmZXIud3JpdGUoc3RyaW5nLCB0aGlzLm9mZnNldCk7XG4gICAgICAgIHRoaXMub2Zmc2V0ICs9IGxlbjtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGFkZChvdGhlckJ1ZmZlcikge1xuICAgICAgICB0aGlzLmVuc3VyZShvdGhlckJ1ZmZlci5sZW5ndGgpO1xuICAgICAgICBvdGhlckJ1ZmZlci5jb3B5KHRoaXMuYnVmZmVyLCB0aGlzLm9mZnNldCk7XG4gICAgICAgIHRoaXMub2Zmc2V0ICs9IG90aGVyQnVmZmVyLmxlbmd0aDtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGpvaW4oY29kZSkge1xuICAgICAgICBpZiAoY29kZSkge1xuICAgICAgICAgICAgdGhpcy5idWZmZXJbdGhpcy5oZWFkZXJQb3NpdGlvbl0gPSBjb2RlO1xuICAgICAgICAgICAgLy9sZW5ndGggaXMgZXZlcnl0aGluZyBpbiB0aGlzIHBhY2tldCBtaW51cyB0aGUgY29kZVxuICAgICAgICAgICAgY29uc3QgbGVuZ3RoID0gdGhpcy5vZmZzZXQgLSAodGhpcy5oZWFkZXJQb3NpdGlvbiArIDEpO1xuICAgICAgICAgICAgdGhpcy5idWZmZXIud3JpdGVJbnQzMkJFKGxlbmd0aCwgdGhpcy5oZWFkZXJQb3NpdGlvbiArIDEpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLmJ1ZmZlci5zbGljZShjb2RlID8gMCA6IDUsIHRoaXMub2Zmc2V0KTtcbiAgICB9XG4gICAgZmx1c2goY29kZSkge1xuICAgICAgICB2YXIgcmVzdWx0ID0gdGhpcy5qb2luKGNvZGUpO1xuICAgICAgICB0aGlzLm9mZnNldCA9IDU7XG4gICAgICAgIHRoaXMuaGVhZGVyUG9zaXRpb24gPSAwO1xuICAgICAgICB0aGlzLmJ1ZmZlciA9IEJ1ZmZlci5hbGxvY1Vuc2FmZSh0aGlzLnNpemUpO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbn1cbmV4cG9ydHMuV3JpdGVyID0gV3JpdGVyO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YnVmZmVyLXdyaXRlci5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuRGF0YWJhc2VFcnJvciA9IGV4cG9ydHMuc2VyaWFsaXplID0gZXhwb3J0cy5wYXJzZSA9IHZvaWQgMDtcbmNvbnN0IG1lc3NhZ2VzXzEgPSByZXF1aXJlKFwiLi9tZXNzYWdlc1wiKTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIkRhdGFiYXNlRXJyb3JcIiwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIG1lc3NhZ2VzXzEuRGF0YWJhc2VFcnJvcjsgfSB9KTtcbmNvbnN0IHNlcmlhbGl6ZXJfMSA9IHJlcXVpcmUoXCIuL3NlcmlhbGl6ZXJcIik7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJzZXJpYWxpemVcIiwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHNlcmlhbGl6ZXJfMS5zZXJpYWxpemU7IH0gfSk7XG5jb25zdCBwYXJzZXJfMSA9IHJlcXVpcmUoXCIuL3BhcnNlclwiKTtcbmZ1bmN0aW9uIHBhcnNlKHN0cmVhbSwgY2FsbGJhY2spIHtcbiAgICBjb25zdCBwYXJzZXIgPSBuZXcgcGFyc2VyXzEuUGFyc2VyKCk7XG4gICAgc3RyZWFtLm9uKCdkYXRhJywgKGJ1ZmZlcikgPT4gcGFyc2VyLnBhcnNlKGJ1ZmZlciwgY2FsbGJhY2spKTtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHN0cmVhbS5vbignZW5kJywgKCkgPT4gcmVzb2x2ZSgpKSk7XG59XG5leHBvcnRzLnBhcnNlID0gcGFyc2U7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuTm90aWNlTWVzc2FnZSA9IGV4cG9ydHMuRGF0YVJvd01lc3NhZ2UgPSBleHBvcnRzLkNvbW1hbmRDb21wbGV0ZU1lc3NhZ2UgPSBleHBvcnRzLlJlYWR5Rm9yUXVlcnlNZXNzYWdlID0gZXhwb3J0cy5Ob3RpZmljYXRpb25SZXNwb25zZU1lc3NhZ2UgPSBleHBvcnRzLkJhY2tlbmRLZXlEYXRhTWVzc2FnZSA9IGV4cG9ydHMuQXV0aGVudGljYXRpb25NRDVQYXNzd29yZCA9IGV4cG9ydHMuUGFyYW1ldGVyU3RhdHVzTWVzc2FnZSA9IGV4cG9ydHMuUGFyYW1ldGVyRGVzY3JpcHRpb25NZXNzYWdlID0gZXhwb3J0cy5Sb3dEZXNjcmlwdGlvbk1lc3NhZ2UgPSBleHBvcnRzLkZpZWxkID0gZXhwb3J0cy5Db3B5UmVzcG9uc2UgPSBleHBvcnRzLkNvcHlEYXRhTWVzc2FnZSA9IGV4cG9ydHMuRGF0YWJhc2VFcnJvciA9IGV4cG9ydHMuY29weURvbmUgPSBleHBvcnRzLmVtcHR5UXVlcnkgPSBleHBvcnRzLnJlcGxpY2F0aW9uU3RhcnQgPSBleHBvcnRzLnBvcnRhbFN1c3BlbmRlZCA9IGV4cG9ydHMubm9EYXRhID0gZXhwb3J0cy5jbG9zZUNvbXBsZXRlID0gZXhwb3J0cy5iaW5kQ29tcGxldGUgPSBleHBvcnRzLnBhcnNlQ29tcGxldGUgPSB2b2lkIDA7XG5leHBvcnRzLnBhcnNlQ29tcGxldGUgPSB7XG4gICAgbmFtZTogJ3BhcnNlQ29tcGxldGUnLFxuICAgIGxlbmd0aDogNSxcbn07XG5leHBvcnRzLmJpbmRDb21wbGV0ZSA9IHtcbiAgICBuYW1lOiAnYmluZENvbXBsZXRlJyxcbiAgICBsZW5ndGg6IDUsXG59O1xuZXhwb3J0cy5jbG9zZUNvbXBsZXRlID0ge1xuICAgIG5hbWU6ICdjbG9zZUNvbXBsZXRlJyxcbiAgICBsZW5ndGg6IDUsXG59O1xuZXhwb3J0cy5ub0RhdGEgPSB7XG4gICAgbmFtZTogJ25vRGF0YScsXG4gICAgbGVuZ3RoOiA1LFxufTtcbmV4cG9ydHMucG9ydGFsU3VzcGVuZGVkID0ge1xuICAgIG5hbWU6ICdwb3J0YWxTdXNwZW5kZWQnLFxuICAgIGxlbmd0aDogNSxcbn07XG5leHBvcnRzLnJlcGxpY2F0aW9uU3RhcnQgPSB7XG4gICAgbmFtZTogJ3JlcGxpY2F0aW9uU3RhcnQnLFxuICAgIGxlbmd0aDogNCxcbn07XG5leHBvcnRzLmVtcHR5UXVlcnkgPSB7XG4gICAgbmFtZTogJ2VtcHR5UXVlcnknLFxuICAgIGxlbmd0aDogNCxcbn07XG5leHBvcnRzLmNvcHlEb25lID0ge1xuICAgIG5hbWU6ICdjb3B5RG9uZScsXG4gICAgbGVuZ3RoOiA0LFxufTtcbmNsYXNzIERhdGFiYXNlRXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gICAgY29uc3RydWN0b3IobWVzc2FnZSwgbGVuZ3RoLCBuYW1lKSB7XG4gICAgICAgIHN1cGVyKG1lc3NhZ2UpO1xuICAgICAgICB0aGlzLmxlbmd0aCA9IGxlbmd0aDtcbiAgICAgICAgdGhpcy5uYW1lID0gbmFtZTtcbiAgICB9XG59XG5leHBvcnRzLkRhdGFiYXNlRXJyb3IgPSBEYXRhYmFzZUVycm9yO1xuY2xhc3MgQ29weURhdGFNZXNzYWdlIHtcbiAgICBjb25zdHJ1Y3RvcihsZW5ndGgsIGNodW5rKSB7XG4gICAgICAgIHRoaXMubGVuZ3RoID0gbGVuZ3RoO1xuICAgICAgICB0aGlzLmNodW5rID0gY2h1bms7XG4gICAgICAgIHRoaXMubmFtZSA9ICdjb3B5RGF0YSc7XG4gICAgfVxufVxuZXhwb3J0cy5Db3B5RGF0YU1lc3NhZ2UgPSBDb3B5RGF0YU1lc3NhZ2U7XG5jbGFzcyBDb3B5UmVzcG9uc2Uge1xuICAgIGNvbnN0cnVjdG9yKGxlbmd0aCwgbmFtZSwgYmluYXJ5LCBjb2x1bW5Db3VudCkge1xuICAgICAgICB0aGlzLmxlbmd0aCA9IGxlbmd0aDtcbiAgICAgICAgdGhpcy5uYW1lID0gbmFtZTtcbiAgICAgICAgdGhpcy5iaW5hcnkgPSBiaW5hcnk7XG4gICAgICAgIHRoaXMuY29sdW1uVHlwZXMgPSBuZXcgQXJyYXkoY29sdW1uQ291bnQpO1xuICAgIH1cbn1cbmV4cG9ydHMuQ29weVJlc3BvbnNlID0gQ29weVJlc3BvbnNlO1xuY2xhc3MgRmllbGQge1xuICAgIGNvbnN0cnVjdG9yKG5hbWUsIHRhYmxlSUQsIGNvbHVtbklELCBkYXRhVHlwZUlELCBkYXRhVHlwZVNpemUsIGRhdGFUeXBlTW9kaWZpZXIsIGZvcm1hdCkge1xuICAgICAgICB0aGlzLm5hbWUgPSBuYW1lO1xuICAgICAgICB0aGlzLnRhYmxlSUQgPSB0YWJsZUlEO1xuICAgICAgICB0aGlzLmNvbHVtbklEID0gY29sdW1uSUQ7XG4gICAgICAgIHRoaXMuZGF0YVR5cGVJRCA9IGRhdGFUeXBlSUQ7XG4gICAgICAgIHRoaXMuZGF0YVR5cGVTaXplID0gZGF0YVR5cGVTaXplO1xuICAgICAgICB0aGlzLmRhdGFUeXBlTW9kaWZpZXIgPSBkYXRhVHlwZU1vZGlmaWVyO1xuICAgICAgICB0aGlzLmZvcm1hdCA9IGZvcm1hdDtcbiAgICB9XG59XG5leHBvcnRzLkZpZWxkID0gRmllbGQ7XG5jbGFzcyBSb3dEZXNjcmlwdGlvbk1lc3NhZ2Uge1xuICAgIGNvbnN0cnVjdG9yKGxlbmd0aCwgZmllbGRDb3VudCkge1xuICAgICAgICB0aGlzLmxlbmd0aCA9IGxlbmd0aDtcbiAgICAgICAgdGhpcy5maWVsZENvdW50ID0gZmllbGRDb3VudDtcbiAgICAgICAgdGhpcy5uYW1lID0gJ3Jvd0Rlc2NyaXB0aW9uJztcbiAgICAgICAgdGhpcy5maWVsZHMgPSBuZXcgQXJyYXkodGhpcy5maWVsZENvdW50KTtcbiAgICB9XG59XG5leHBvcnRzLlJvd0Rlc2NyaXB0aW9uTWVzc2FnZSA9IFJvd0Rlc2NyaXB0aW9uTWVzc2FnZTtcbmNsYXNzIFBhcmFtZXRlckRlc2NyaXB0aW9uTWVzc2FnZSB7XG4gICAgY29uc3RydWN0b3IobGVuZ3RoLCBwYXJhbWV0ZXJDb3VudCkge1xuICAgICAgICB0aGlzLmxlbmd0aCA9IGxlbmd0aDtcbiAgICAgICAgdGhpcy5wYXJhbWV0ZXJDb3VudCA9IHBhcmFtZXRlckNvdW50O1xuICAgICAgICB0aGlzLm5hbWUgPSAncGFyYW1ldGVyRGVzY3JpcHRpb24nO1xuICAgICAgICB0aGlzLmRhdGFUeXBlSURzID0gbmV3IEFycmF5KHRoaXMucGFyYW1ldGVyQ291bnQpO1xuICAgIH1cbn1cbmV4cG9ydHMuUGFyYW1ldGVyRGVzY3JpcHRpb25NZXNzYWdlID0gUGFyYW1ldGVyRGVzY3JpcHRpb25NZXNzYWdlO1xuY2xhc3MgUGFyYW1ldGVyU3RhdHVzTWVzc2FnZSB7XG4gICAgY29uc3RydWN0b3IobGVuZ3RoLCBwYXJhbWV0ZXJOYW1lLCBwYXJhbWV0ZXJWYWx1ZSkge1xuICAgICAgICB0aGlzLmxlbmd0aCA9IGxlbmd0aDtcbiAgICAgICAgdGhpcy5wYXJhbWV0ZXJOYW1lID0gcGFyYW1ldGVyTmFtZTtcbiAgICAgICAgdGhpcy5wYXJhbWV0ZXJWYWx1ZSA9IHBhcmFtZXRlclZhbHVlO1xuICAgICAgICB0aGlzLm5hbWUgPSAncGFyYW1ldGVyU3RhdHVzJztcbiAgICB9XG59XG5leHBvcnRzLlBhcmFtZXRlclN0YXR1c01lc3NhZ2UgPSBQYXJhbWV0ZXJTdGF0dXNNZXNzYWdlO1xuY2xhc3MgQXV0aGVudGljYXRpb25NRDVQYXNzd29yZCB7XG4gICAgY29uc3RydWN0b3IobGVuZ3RoLCBzYWx0KSB7XG4gICAgICAgIHRoaXMubGVuZ3RoID0gbGVuZ3RoO1xuICAgICAgICB0aGlzLnNhbHQgPSBzYWx0O1xuICAgICAgICB0aGlzLm5hbWUgPSAnYXV0aGVudGljYXRpb25NRDVQYXNzd29yZCc7XG4gICAgfVxufVxuZXhwb3J0cy5BdXRoZW50aWNhdGlvbk1ENVBhc3N3b3JkID0gQXV0aGVudGljYXRpb25NRDVQYXNzd29yZDtcbmNsYXNzIEJhY2tlbmRLZXlEYXRhTWVzc2FnZSB7XG4gICAgY29uc3RydWN0b3IobGVuZ3RoLCBwcm9jZXNzSUQsIHNlY3JldEtleSkge1xuICAgICAgICB0aGlzLmxlbmd0aCA9IGxlbmd0aDtcbiAgICAgICAgdGhpcy5wcm9jZXNzSUQgPSBwcm9jZXNzSUQ7XG4gICAgICAgIHRoaXMuc2VjcmV0S2V5ID0gc2VjcmV0S2V5O1xuICAgICAgICB0aGlzLm5hbWUgPSAnYmFja2VuZEtleURhdGEnO1xuICAgIH1cbn1cbmV4cG9ydHMuQmFja2VuZEtleURhdGFNZXNzYWdlID0gQmFja2VuZEtleURhdGFNZXNzYWdlO1xuY2xhc3MgTm90aWZpY2F0aW9uUmVzcG9uc2VNZXNzYWdlIHtcbiAgICBjb25zdHJ1Y3RvcihsZW5ndGgsIHByb2Nlc3NJZCwgY2hhbm5lbCwgcGF5bG9hZCkge1xuICAgICAgICB0aGlzLmxlbmd0aCA9IGxlbmd0aDtcbiAgICAgICAgdGhpcy5wcm9jZXNzSWQgPSBwcm9jZXNzSWQ7XG4gICAgICAgIHRoaXMuY2hhbm5lbCA9IGNoYW5uZWw7XG4gICAgICAgIHRoaXMucGF5bG9hZCA9IHBheWxvYWQ7XG4gICAgICAgIHRoaXMubmFtZSA9ICdub3RpZmljYXRpb24nO1xuICAgIH1cbn1cbmV4cG9ydHMuTm90aWZpY2F0aW9uUmVzcG9uc2VNZXNzYWdlID0gTm90aWZpY2F0aW9uUmVzcG9uc2VNZXNzYWdlO1xuY2xhc3MgUmVhZHlGb3JRdWVyeU1lc3NhZ2Uge1xuICAgIGNvbnN0cnVjdG9yKGxlbmd0aCwgc3RhdHVzKSB7XG4gICAgICAgIHRoaXMubGVuZ3RoID0gbGVuZ3RoO1xuICAgICAgICB0aGlzLnN0YXR1cyA9IHN0YXR1cztcbiAgICAgICAgdGhpcy5uYW1lID0gJ3JlYWR5Rm9yUXVlcnknO1xuICAgIH1cbn1cbmV4cG9ydHMuUmVhZHlGb3JRdWVyeU1lc3NhZ2UgPSBSZWFkeUZvclF1ZXJ5TWVzc2FnZTtcbmNsYXNzIENvbW1hbmRDb21wbGV0ZU1lc3NhZ2Uge1xuICAgIGNvbnN0cnVjdG9yKGxlbmd0aCwgdGV4dCkge1xuICAgICAgICB0aGlzLmxlbmd0aCA9IGxlbmd0aDtcbiAgICAgICAgdGhpcy50ZXh0ID0gdGV4dDtcbiAgICAgICAgdGhpcy5uYW1lID0gJ2NvbW1hbmRDb21wbGV0ZSc7XG4gICAgfVxufVxuZXhwb3J0cy5Db21tYW5kQ29tcGxldGVNZXNzYWdlID0gQ29tbWFuZENvbXBsZXRlTWVzc2FnZTtcbmNsYXNzIERhdGFSb3dNZXNzYWdlIHtcbiAgICBjb25zdHJ1Y3RvcihsZW5ndGgsIGZpZWxkcykge1xuICAgICAgICB0aGlzLmxlbmd0aCA9IGxlbmd0aDtcbiAgICAgICAgdGhpcy5maWVsZHMgPSBmaWVsZHM7XG4gICAgICAgIHRoaXMubmFtZSA9ICdkYXRhUm93JztcbiAgICAgICAgdGhpcy5maWVsZENvdW50ID0gZmllbGRzLmxlbmd0aDtcbiAgICB9XG59XG5leHBvcnRzLkRhdGFSb3dNZXNzYWdlID0gRGF0YVJvd01lc3NhZ2U7XG5jbGFzcyBOb3RpY2VNZXNzYWdlIHtcbiAgICBjb25zdHJ1Y3RvcihsZW5ndGgsIG1lc3NhZ2UpIHtcbiAgICAgICAgdGhpcy5sZW5ndGggPSBsZW5ndGg7XG4gICAgICAgIHRoaXMubWVzc2FnZSA9IG1lc3NhZ2U7XG4gICAgICAgIHRoaXMubmFtZSA9ICdub3RpY2UnO1xuICAgIH1cbn1cbmV4cG9ydHMuTm90aWNlTWVzc2FnZSA9IE5vdGljZU1lc3NhZ2U7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1tZXNzYWdlcy5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbnZhciBfX2ltcG9ydERlZmF1bHQgPSAodGhpcyAmJiB0aGlzLl9faW1wb3J0RGVmYXVsdCkgfHwgZnVuY3Rpb24gKG1vZCkge1xuICAgIHJldHVybiAobW9kICYmIG1vZC5fX2VzTW9kdWxlKSA/IG1vZCA6IHsgXCJkZWZhdWx0XCI6IG1vZCB9O1xufTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuUGFyc2VyID0gdm9pZCAwO1xuY29uc3QgbWVzc2FnZXNfMSA9IHJlcXVpcmUoXCIuL21lc3NhZ2VzXCIpO1xuY29uc3QgYnVmZmVyX3JlYWRlcl8xID0gcmVxdWlyZShcIi4vYnVmZmVyLXJlYWRlclwiKTtcbmNvbnN0IGFzc2VydF8xID0gX19pbXBvcnREZWZhdWx0KHJlcXVpcmUoXCJhc3NlcnRcIikpO1xuLy8gZXZlcnkgbWVzc2FnZSBpcyBwcmVmaXhlZCB3aXRoIGEgc2luZ2xlIGJ5ZVxuY29uc3QgQ09ERV9MRU5HVEggPSAxO1xuLy8gZXZlcnkgbWVzc2FnZSBoYXMgYW4gaW50MzIgbGVuZ3RoIHdoaWNoIGluY2x1ZGVzIGl0c2VsZiBidXQgZG9lc1xuLy8gTk9UIGluY2x1ZGUgdGhlIGNvZGUgaW4gdGhlIGxlbmd0aFxuY29uc3QgTEVOX0xFTkdUSCA9IDQ7XG5jb25zdCBIRUFERVJfTEVOR1RIID0gQ09ERV9MRU5HVEggKyBMRU5fTEVOR1RIO1xuY29uc3QgZW1wdHlCdWZmZXIgPSBCdWZmZXIuYWxsb2NVbnNhZmUoMCk7XG5jbGFzcyBQYXJzZXIge1xuICAgIGNvbnN0cnVjdG9yKG9wdHMpIHtcbiAgICAgICAgdGhpcy5idWZmZXIgPSBlbXB0eUJ1ZmZlcjtcbiAgICAgICAgdGhpcy5idWZmZXJMZW5ndGggPSAwO1xuICAgICAgICB0aGlzLmJ1ZmZlck9mZnNldCA9IDA7XG4gICAgICAgIHRoaXMucmVhZGVyID0gbmV3IGJ1ZmZlcl9yZWFkZXJfMS5CdWZmZXJSZWFkZXIoKTtcbiAgICAgICAgaWYgKChvcHRzID09PSBudWxsIHx8IG9wdHMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG9wdHMubW9kZSkgPT09ICdiaW5hcnknKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0JpbmFyeSBtb2RlIG5vdCBzdXBwb3J0ZWQgeWV0Jyk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5tb2RlID0gKG9wdHMgPT09IG51bGwgfHwgb3B0cyA9PT0gdm9pZCAwID8gdm9pZCAwIDogb3B0cy5tb2RlKSB8fCAndGV4dCc7XG4gICAgfVxuICAgIHBhcnNlKGJ1ZmZlciwgY2FsbGJhY2spIHtcbiAgICAgICAgdGhpcy5tZXJnZUJ1ZmZlcihidWZmZXIpO1xuICAgICAgICBjb25zdCBidWZmZXJGdWxsTGVuZ3RoID0gdGhpcy5idWZmZXJPZmZzZXQgKyB0aGlzLmJ1ZmZlckxlbmd0aDtcbiAgICAgICAgbGV0IG9mZnNldCA9IHRoaXMuYnVmZmVyT2Zmc2V0O1xuICAgICAgICB3aGlsZSAob2Zmc2V0ICsgSEVBREVSX0xFTkdUSCA8PSBidWZmZXJGdWxsTGVuZ3RoKSB7XG4gICAgICAgICAgICAvLyBjb2RlIGlzIDEgYnl0ZSBsb25nIC0gaXQgaWRlbnRpZmllcyB0aGUgbWVzc2FnZSB0eXBlXG4gICAgICAgICAgICBjb25zdCBjb2RlID0gdGhpcy5idWZmZXJbb2Zmc2V0XTtcbiAgICAgICAgICAgIC8vIGxlbmd0aCBpcyAxIFVpbnQzMkJFIC0gaXQgaXMgdGhlIGxlbmd0aCBvZiB0aGUgbWVzc2FnZSBFWENMVURJTkcgdGhlIGNvZGVcbiAgICAgICAgICAgIGNvbnN0IGxlbmd0aCA9IHRoaXMuYnVmZmVyLnJlYWRVSW50MzJCRShvZmZzZXQgKyBDT0RFX0xFTkdUSCk7XG4gICAgICAgICAgICBjb25zdCBmdWxsTWVzc2FnZUxlbmd0aCA9IENPREVfTEVOR1RIICsgbGVuZ3RoO1xuICAgICAgICAgICAgaWYgKGZ1bGxNZXNzYWdlTGVuZ3RoICsgb2Zmc2V0IDw9IGJ1ZmZlckZ1bGxMZW5ndGgpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBtZXNzYWdlID0gdGhpcy5oYW5kbGVQYWNrZXQob2Zmc2V0ICsgSEVBREVSX0xFTkdUSCwgY29kZSwgbGVuZ3RoLCB0aGlzLmJ1ZmZlcik7XG4gICAgICAgICAgICAgICAgY2FsbGJhY2sobWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgb2Zmc2V0ICs9IGZ1bGxNZXNzYWdlTGVuZ3RoO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG9mZnNldCA9PT0gYnVmZmVyRnVsbExlbmd0aCkge1xuICAgICAgICAgICAgLy8gTm8gbW9yZSB1c2UgZm9yIHRoZSBidWZmZXJcbiAgICAgICAgICAgIHRoaXMuYnVmZmVyID0gZW1wdHlCdWZmZXI7XG4gICAgICAgICAgICB0aGlzLmJ1ZmZlckxlbmd0aCA9IDA7XG4gICAgICAgICAgICB0aGlzLmJ1ZmZlck9mZnNldCA9IDA7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAvLyBBZGp1c3QgdGhlIGN1cnNvcnMgb2YgcmVtYWluaW5nQnVmZmVyXG4gICAgICAgICAgICB0aGlzLmJ1ZmZlckxlbmd0aCA9IGJ1ZmZlckZ1bGxMZW5ndGggLSBvZmZzZXQ7XG4gICAgICAgICAgICB0aGlzLmJ1ZmZlck9mZnNldCA9IG9mZnNldDtcbiAgICAgICAgfVxuICAgIH1cbiAgICBtZXJnZUJ1ZmZlcihidWZmZXIpIHtcbiAgICAgICAgaWYgKHRoaXMuYnVmZmVyTGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgY29uc3QgbmV3TGVuZ3RoID0gdGhpcy5idWZmZXJMZW5ndGggKyBidWZmZXIuYnl0ZUxlbmd0aDtcbiAgICAgICAgICAgIGNvbnN0IG5ld0Z1bGxMZW5ndGggPSBuZXdMZW5ndGggKyB0aGlzLmJ1ZmZlck9mZnNldDtcbiAgICAgICAgICAgIGlmIChuZXdGdWxsTGVuZ3RoID4gdGhpcy5idWZmZXIuYnl0ZUxlbmd0aCkge1xuICAgICAgICAgICAgICAgIC8vIFdlIGNhbid0IGNvbmNhdCB0aGUgbmV3IGJ1ZmZlciB3aXRoIHRoZSByZW1haW5pbmcgb25lXG4gICAgICAgICAgICAgICAgbGV0IG5ld0J1ZmZlcjtcbiAgICAgICAgICAgICAgICBpZiAobmV3TGVuZ3RoIDw9IHRoaXMuYnVmZmVyLmJ5dGVMZW5ndGggJiYgdGhpcy5idWZmZXJPZmZzZXQgPj0gdGhpcy5idWZmZXJMZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gV2UgY2FuIG1vdmUgdGhlIHJlbGV2YW50IHBhcnQgdG8gdGhlIGJlZ2lubmluZyBvZiB0aGUgYnVmZmVyIGluc3RlYWQgb2YgYWxsb2NhdGluZyBhIG5ldyBidWZmZXJcbiAgICAgICAgICAgICAgICAgICAgbmV3QnVmZmVyID0gdGhpcy5idWZmZXI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAvLyBBbGxvY2F0ZSBhIG5ldyBsYXJnZXIgYnVmZmVyXG4gICAgICAgICAgICAgICAgICAgIGxldCBuZXdCdWZmZXJMZW5ndGggPSB0aGlzLmJ1ZmZlci5ieXRlTGVuZ3RoICogMjtcbiAgICAgICAgICAgICAgICAgICAgd2hpbGUgKG5ld0xlbmd0aCA+PSBuZXdCdWZmZXJMZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5ld0J1ZmZlckxlbmd0aCAqPSAyO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIG5ld0J1ZmZlciA9IEJ1ZmZlci5hbGxvY1Vuc2FmZShuZXdCdWZmZXJMZW5ndGgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyBNb3ZlIHRoZSByZW1haW5pbmcgYnVmZmVyIHRvIHRoZSBuZXcgb25lXG4gICAgICAgICAgICAgICAgdGhpcy5idWZmZXIuY29weShuZXdCdWZmZXIsIDAsIHRoaXMuYnVmZmVyT2Zmc2V0LCB0aGlzLmJ1ZmZlck9mZnNldCArIHRoaXMuYnVmZmVyTGVuZ3RoKTtcbiAgICAgICAgICAgICAgICB0aGlzLmJ1ZmZlciA9IG5ld0J1ZmZlcjtcbiAgICAgICAgICAgICAgICB0aGlzLmJ1ZmZlck9mZnNldCA9IDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBDb25jYXQgdGhlIG5ldyBidWZmZXIgd2l0aCB0aGUgcmVtYWluaW5nIG9uZVxuICAgICAgICAgICAgYnVmZmVyLmNvcHkodGhpcy5idWZmZXIsIHRoaXMuYnVmZmVyT2Zmc2V0ICsgdGhpcy5idWZmZXJMZW5ndGgpO1xuICAgICAgICAgICAgdGhpcy5idWZmZXJMZW5ndGggPSBuZXdMZW5ndGg7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmJ1ZmZlciA9IGJ1ZmZlcjtcbiAgICAgICAgICAgIHRoaXMuYnVmZmVyT2Zmc2V0ID0gMDtcbiAgICAgICAgICAgIHRoaXMuYnVmZmVyTGVuZ3RoID0gYnVmZmVyLmJ5dGVMZW5ndGg7XG4gICAgICAgIH1cbiAgICB9XG4gICAgaGFuZGxlUGFja2V0KG9mZnNldCwgY29kZSwgbGVuZ3RoLCBieXRlcykge1xuICAgICAgICBzd2l0Y2ggKGNvZGUpIHtcbiAgICAgICAgICAgIGNhc2UgNTAgLyogQmluZENvbXBsZXRlICovOlxuICAgICAgICAgICAgICAgIHJldHVybiBtZXNzYWdlc18xLmJpbmRDb21wbGV0ZTtcbiAgICAgICAgICAgIGNhc2UgNDkgLyogUGFyc2VDb21wbGV0ZSAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gbWVzc2FnZXNfMS5wYXJzZUNvbXBsZXRlO1xuICAgICAgICAgICAgY2FzZSA1MSAvKiBDbG9zZUNvbXBsZXRlICovOlxuICAgICAgICAgICAgICAgIHJldHVybiBtZXNzYWdlc18xLmNsb3NlQ29tcGxldGU7XG4gICAgICAgICAgICBjYXNlIDExMCAvKiBOb0RhdGEgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2VzXzEubm9EYXRhO1xuICAgICAgICAgICAgY2FzZSAxMTUgLyogUG9ydGFsU3VzcGVuZGVkICovOlxuICAgICAgICAgICAgICAgIHJldHVybiBtZXNzYWdlc18xLnBvcnRhbFN1c3BlbmRlZDtcbiAgICAgICAgICAgIGNhc2UgOTkgLyogQ29weURvbmUgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2VzXzEuY29weURvbmU7XG4gICAgICAgICAgICBjYXNlIDg3IC8qIFJlcGxpY2F0aW9uU3RhcnQgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2VzXzEucmVwbGljYXRpb25TdGFydDtcbiAgICAgICAgICAgIGNhc2UgNzMgLyogRW1wdHlRdWVyeSAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gbWVzc2FnZXNfMS5lbXB0eVF1ZXJ5O1xuICAgICAgICAgICAgY2FzZSA2OCAvKiBEYXRhUm93ICovOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlRGF0YVJvd01lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKTtcbiAgICAgICAgICAgIGNhc2UgNjcgLyogQ29tbWFuZENvbXBsZXRlICovOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlQ29tbWFuZENvbXBsZXRlTWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpO1xuICAgICAgICAgICAgY2FzZSA5MCAvKiBSZWFkeUZvclF1ZXJ5ICovOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlUmVhZHlGb3JRdWVyeU1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKTtcbiAgICAgICAgICAgIGNhc2UgNjUgLyogTm90aWZpY2F0aW9uUmVzcG9uc2UgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VOb3RpZmljYXRpb25NZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcyk7XG4gICAgICAgICAgICBjYXNlIDgyIC8qIEF1dGhlbnRpY2F0aW9uUmVzcG9uc2UgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VBdXRoZW50aWNhdGlvblJlc3BvbnNlKG9mZnNldCwgbGVuZ3RoLCBieXRlcyk7XG4gICAgICAgICAgICBjYXNlIDgzIC8qIFBhcmFtZXRlclN0YXR1cyAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZVBhcmFtZXRlclN0YXR1c01lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKTtcbiAgICAgICAgICAgIGNhc2UgNzUgLyogQmFja2VuZEtleURhdGEgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VCYWNrZW5kS2V5RGF0YShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpO1xuICAgICAgICAgICAgY2FzZSA2OSAvKiBFcnJvck1lc3NhZ2UgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VFcnJvck1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzLCAnZXJyb3InKTtcbiAgICAgICAgICAgIGNhc2UgNzggLyogTm90aWNlTWVzc2FnZSAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZUVycm9yTWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMsICdub3RpY2UnKTtcbiAgICAgICAgICAgIGNhc2UgODQgLyogUm93RGVzY3JpcHRpb25NZXNzYWdlICovOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlUm93RGVzY3JpcHRpb25NZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcyk7XG4gICAgICAgICAgICBjYXNlIDExNiAvKiBQYXJhbWV0ZXJEZXNjcmlwdGlvbk1lc3NhZ2UgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VQYXJhbWV0ZXJEZXNjcmlwdGlvbk1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKTtcbiAgICAgICAgICAgIGNhc2UgNzEgLyogQ29weUluICovOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlQ29weUluTWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpO1xuICAgICAgICAgICAgY2FzZSA3MiAvKiBDb3B5T3V0ICovOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlQ29weU91dE1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKTtcbiAgICAgICAgICAgIGNhc2UgMTAwIC8qIENvcHlEYXRhICovOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlQ29weURhdGEob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKTtcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgYXNzZXJ0XzEuZGVmYXVsdC5mYWlsKGB1bmtub3duIG1lc3NhZ2UgY29kZTogJHtjb2RlLnRvU3RyaW5nKDE2KX1gKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBwYXJzZVJlYWR5Rm9yUXVlcnlNZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcykge1xuICAgICAgICB0aGlzLnJlYWRlci5zZXRCdWZmZXIob2Zmc2V0LCBieXRlcyk7XG4gICAgICAgIGNvbnN0IHN0YXR1cyA9IHRoaXMucmVhZGVyLnN0cmluZygxKTtcbiAgICAgICAgcmV0dXJuIG5ldyBtZXNzYWdlc18xLlJlYWR5Rm9yUXVlcnlNZXNzYWdlKGxlbmd0aCwgc3RhdHVzKTtcbiAgICB9XG4gICAgcGFyc2VDb21tYW5kQ29tcGxldGVNZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcykge1xuICAgICAgICB0aGlzLnJlYWRlci5zZXRCdWZmZXIob2Zmc2V0LCBieXRlcyk7XG4gICAgICAgIGNvbnN0IHRleHQgPSB0aGlzLnJlYWRlci5jc3RyaW5nKCk7XG4gICAgICAgIHJldHVybiBuZXcgbWVzc2FnZXNfMS5Db21tYW5kQ29tcGxldGVNZXNzYWdlKGxlbmd0aCwgdGV4dCk7XG4gICAgfVxuICAgIHBhcnNlQ29weURhdGEob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKSB7XG4gICAgICAgIGNvbnN0IGNodW5rID0gYnl0ZXMuc2xpY2Uob2Zmc2V0LCBvZmZzZXQgKyAobGVuZ3RoIC0gNCkpO1xuICAgICAgICByZXR1cm4gbmV3IG1lc3NhZ2VzXzEuQ29weURhdGFNZXNzYWdlKGxlbmd0aCwgY2h1bmspO1xuICAgIH1cbiAgICBwYXJzZUNvcHlJbk1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnBhcnNlQ29weU1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzLCAnY29weUluUmVzcG9uc2UnKTtcbiAgICB9XG4gICAgcGFyc2VDb3B5T3V0TWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VDb3B5TWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMsICdjb3B5T3V0UmVzcG9uc2UnKTtcbiAgICB9XG4gICAgcGFyc2VDb3B5TWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMsIG1lc3NhZ2VOYW1lKSB7XG4gICAgICAgIHRoaXMucmVhZGVyLnNldEJ1ZmZlcihvZmZzZXQsIGJ5dGVzKTtcbiAgICAgICAgY29uc3QgaXNCaW5hcnkgPSB0aGlzLnJlYWRlci5ieXRlKCkgIT09IDA7XG4gICAgICAgIGNvbnN0IGNvbHVtbkNvdW50ID0gdGhpcy5yZWFkZXIuaW50MTYoKTtcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IG5ldyBtZXNzYWdlc18xLkNvcHlSZXNwb25zZShsZW5ndGgsIG1lc3NhZ2VOYW1lLCBpc0JpbmFyeSwgY29sdW1uQ291bnQpO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNvbHVtbkNvdW50OyBpKyspIHtcbiAgICAgICAgICAgIG1lc3NhZ2UuY29sdW1uVHlwZXNbaV0gPSB0aGlzLnJlYWRlci5pbnQxNigpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgIH1cbiAgICBwYXJzZU5vdGlmaWNhdGlvbk1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKSB7XG4gICAgICAgIHRoaXMucmVhZGVyLnNldEJ1ZmZlcihvZmZzZXQsIGJ5dGVzKTtcbiAgICAgICAgY29uc3QgcHJvY2Vzc0lkID0gdGhpcy5yZWFkZXIuaW50MzIoKTtcbiAgICAgICAgY29uc3QgY2hhbm5lbCA9IHRoaXMucmVhZGVyLmNzdHJpbmcoKTtcbiAgICAgICAgY29uc3QgcGF5bG9hZCA9IHRoaXMucmVhZGVyLmNzdHJpbmcoKTtcbiAgICAgICAgcmV0dXJuIG5ldyBtZXNzYWdlc18xLk5vdGlmaWNhdGlvblJlc3BvbnNlTWVzc2FnZShsZW5ndGgsIHByb2Nlc3NJZCwgY2hhbm5lbCwgcGF5bG9hZCk7XG4gICAgfVxuICAgIHBhcnNlUm93RGVzY3JpcHRpb25NZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcykge1xuICAgICAgICB0aGlzLnJlYWRlci5zZXRCdWZmZXIob2Zmc2V0LCBieXRlcyk7XG4gICAgICAgIGNvbnN0IGZpZWxkQ291bnQgPSB0aGlzLnJlYWRlci5pbnQxNigpO1xuICAgICAgICBjb25zdCBtZXNzYWdlID0gbmV3IG1lc3NhZ2VzXzEuUm93RGVzY3JpcHRpb25NZXNzYWdlKGxlbmd0aCwgZmllbGRDb3VudCk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZmllbGRDb3VudDsgaSsrKSB7XG4gICAgICAgICAgICBtZXNzYWdlLmZpZWxkc1tpXSA9IHRoaXMucGFyc2VGaWVsZCgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgIH1cbiAgICBwYXJzZUZpZWxkKCkge1xuICAgICAgICBjb25zdCBuYW1lID0gdGhpcy5yZWFkZXIuY3N0cmluZygpO1xuICAgICAgICBjb25zdCB0YWJsZUlEID0gdGhpcy5yZWFkZXIuaW50MzIoKTtcbiAgICAgICAgY29uc3QgY29sdW1uSUQgPSB0aGlzLnJlYWRlci5pbnQxNigpO1xuICAgICAgICBjb25zdCBkYXRhVHlwZUlEID0gdGhpcy5yZWFkZXIuaW50MzIoKTtcbiAgICAgICAgY29uc3QgZGF0YVR5cGVTaXplID0gdGhpcy5yZWFkZXIuaW50MTYoKTtcbiAgICAgICAgY29uc3QgZGF0YVR5cGVNb2RpZmllciA9IHRoaXMucmVhZGVyLmludDMyKCk7XG4gICAgICAgIGNvbnN0IG1vZGUgPSB0aGlzLnJlYWRlci5pbnQxNigpID09PSAwID8gJ3RleHQnIDogJ2JpbmFyeSc7XG4gICAgICAgIHJldHVybiBuZXcgbWVzc2FnZXNfMS5GaWVsZChuYW1lLCB0YWJsZUlELCBjb2x1bW5JRCwgZGF0YVR5cGVJRCwgZGF0YVR5cGVTaXplLCBkYXRhVHlwZU1vZGlmaWVyLCBtb2RlKTtcbiAgICB9XG4gICAgcGFyc2VQYXJhbWV0ZXJEZXNjcmlwdGlvbk1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKSB7XG4gICAgICAgIHRoaXMucmVhZGVyLnNldEJ1ZmZlcihvZmZzZXQsIGJ5dGVzKTtcbiAgICAgICAgY29uc3QgcGFyYW1ldGVyQ291bnQgPSB0aGlzLnJlYWRlci5pbnQxNigpO1xuICAgICAgICBjb25zdCBtZXNzYWdlID0gbmV3IG1lc3NhZ2VzXzEuUGFyYW1ldGVyRGVzY3JpcHRpb25NZXNzYWdlKGxlbmd0aCwgcGFyYW1ldGVyQ291bnQpO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHBhcmFtZXRlckNvdW50OyBpKyspIHtcbiAgICAgICAgICAgIG1lc3NhZ2UuZGF0YVR5cGVJRHNbaV0gPSB0aGlzLnJlYWRlci5pbnQzMigpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgIH1cbiAgICBwYXJzZURhdGFSb3dNZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcykge1xuICAgICAgICB0aGlzLnJlYWRlci5zZXRCdWZmZXIob2Zmc2V0LCBieXRlcyk7XG4gICAgICAgIGNvbnN0IGZpZWxkQ291bnQgPSB0aGlzLnJlYWRlci5pbnQxNigpO1xuICAgICAgICBjb25zdCBmaWVsZHMgPSBuZXcgQXJyYXkoZmllbGRDb3VudCk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZmllbGRDb3VudDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBsZW4gPSB0aGlzLnJlYWRlci5pbnQzMigpO1xuICAgICAgICAgICAgLy8gYSAtMSBmb3IgbGVuZ3RoIG1lYW5zIHRoZSB2YWx1ZSBvZiB0aGUgZmllbGQgaXMgbnVsbFxuICAgICAgICAgICAgZmllbGRzW2ldID0gbGVuID09PSAtMSA/IG51bGwgOiB0aGlzLnJlYWRlci5zdHJpbmcobGVuKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbmV3IG1lc3NhZ2VzXzEuRGF0YVJvd01lc3NhZ2UobGVuZ3RoLCBmaWVsZHMpO1xuICAgIH1cbiAgICBwYXJzZVBhcmFtZXRlclN0YXR1c01lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKSB7XG4gICAgICAgIHRoaXMucmVhZGVyLnNldEJ1ZmZlcihvZmZzZXQsIGJ5dGVzKTtcbiAgICAgICAgY29uc3QgbmFtZSA9IHRoaXMucmVhZGVyLmNzdHJpbmcoKTtcbiAgICAgICAgY29uc3QgdmFsdWUgPSB0aGlzLnJlYWRlci5jc3RyaW5nKCk7XG4gICAgICAgIHJldHVybiBuZXcgbWVzc2FnZXNfMS5QYXJhbWV0ZXJTdGF0dXNNZXNzYWdlKGxlbmd0aCwgbmFtZSwgdmFsdWUpO1xuICAgIH1cbiAgICBwYXJzZUJhY2tlbmRLZXlEYXRhKG9mZnNldCwgbGVuZ3RoLCBieXRlcykge1xuICAgICAgICB0aGlzLnJlYWRlci5zZXRCdWZmZXIob2Zmc2V0LCBieXRlcyk7XG4gICAgICAgIGNvbnN0IHByb2Nlc3NJRCA9IHRoaXMucmVhZGVyLmludDMyKCk7XG4gICAgICAgIGNvbnN0IHNlY3JldEtleSA9IHRoaXMucmVhZGVyLmludDMyKCk7XG4gICAgICAgIHJldHVybiBuZXcgbWVzc2FnZXNfMS5CYWNrZW5kS2V5RGF0YU1lc3NhZ2UobGVuZ3RoLCBwcm9jZXNzSUQsIHNlY3JldEtleSk7XG4gICAgfVxuICAgIHBhcnNlQXV0aGVudGljYXRpb25SZXNwb25zZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpIHtcbiAgICAgICAgdGhpcy5yZWFkZXIuc2V0QnVmZmVyKG9mZnNldCwgYnl0ZXMpO1xuICAgICAgICBjb25zdCBjb2RlID0gdGhpcy5yZWFkZXIuaW50MzIoKTtcbiAgICAgICAgLy8gVE9ETyhibWMpOiBtYXliZSBiZXR0ZXIgdHlwZXMgaGVyZVxuICAgICAgICBjb25zdCBtZXNzYWdlID0ge1xuICAgICAgICAgICAgbmFtZTogJ2F1dGhlbnRpY2F0aW9uT2snLFxuICAgICAgICAgICAgbGVuZ3RoLFxuICAgICAgICB9O1xuICAgICAgICBzd2l0Y2ggKGNvZGUpIHtcbiAgICAgICAgICAgIGNhc2UgMDogLy8gQXV0aGVudGljYXRpb25Pa1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAzOiAvLyBBdXRoZW50aWNhdGlvbkNsZWFydGV4dFBhc3N3b3JkXG4gICAgICAgICAgICAgICAgaWYgKG1lc3NhZ2UubGVuZ3RoID09PSA4KSB7XG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UubmFtZSA9ICdhdXRoZW50aWNhdGlvbkNsZWFydGV4dFBhc3N3b3JkJztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIDU6IC8vIEF1dGhlbnRpY2F0aW9uTUQ1UGFzc3dvcmRcbiAgICAgICAgICAgICAgICBpZiAobWVzc2FnZS5sZW5ndGggPT09IDEyKSB7XG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UubmFtZSA9ICdhdXRoZW50aWNhdGlvbk1ENVBhc3N3b3JkJztcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgc2FsdCA9IHRoaXMucmVhZGVyLmJ5dGVzKDQpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbmV3IG1lc3NhZ2VzXzEuQXV0aGVudGljYXRpb25NRDVQYXNzd29yZChsZW5ndGgsIHNhbHQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgMTA6IC8vIEF1dGhlbnRpY2F0aW9uU0FTTFxuICAgICAgICAgICAgICAgIG1lc3NhZ2UubmFtZSA9ICdhdXRoZW50aWNhdGlvblNBU0wnO1xuICAgICAgICAgICAgICAgIG1lc3NhZ2UubWVjaGFuaXNtcyA9IFtdO1xuICAgICAgICAgICAgICAgIGxldCBtZWNoYW5pc207XG4gICAgICAgICAgICAgICAgZG8ge1xuICAgICAgICAgICAgICAgICAgICBtZWNoYW5pc20gPSB0aGlzLnJlYWRlci5jc3RyaW5nKCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZWNoYW5pc20pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UubWVjaGFuaXNtcy5wdXNoKG1lY2hhbmlzbSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9IHdoaWxlIChtZWNoYW5pc20pO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAxMTogLy8gQXV0aGVudGljYXRpb25TQVNMQ29udGludWVcbiAgICAgICAgICAgICAgICBtZXNzYWdlLm5hbWUgPSAnYXV0aGVudGljYXRpb25TQVNMQ29udGludWUnO1xuICAgICAgICAgICAgICAgIG1lc3NhZ2UuZGF0YSA9IHRoaXMucmVhZGVyLnN0cmluZyhsZW5ndGggLSA4KTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgMTI6IC8vIEF1dGhlbnRpY2F0aW9uU0FTTEZpbmFsXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5uYW1lID0gJ2F1dGhlbnRpY2F0aW9uU0FTTEZpbmFsJztcbiAgICAgICAgICAgICAgICBtZXNzYWdlLmRhdGEgPSB0aGlzLnJlYWRlci5zdHJpbmcobGVuZ3RoIC0gOCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVW5rbm93biBhdXRoZW50aWNhdGlvbk9rIG1lc3NhZ2UgdHlwZSAnICsgY29kZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgfVxuICAgIHBhcnNlRXJyb3JNZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcywgbmFtZSkge1xuICAgICAgICB0aGlzLnJlYWRlci5zZXRCdWZmZXIob2Zmc2V0LCBieXRlcyk7XG4gICAgICAgIGNvbnN0IGZpZWxkcyA9IHt9O1xuICAgICAgICBsZXQgZmllbGRUeXBlID0gdGhpcy5yZWFkZXIuc3RyaW5nKDEpO1xuICAgICAgICB3aGlsZSAoZmllbGRUeXBlICE9PSAnXFwwJykge1xuICAgICAgICAgICAgZmllbGRzW2ZpZWxkVHlwZV0gPSB0aGlzLnJlYWRlci5jc3RyaW5nKCk7XG4gICAgICAgICAgICBmaWVsZFR5cGUgPSB0aGlzLnJlYWRlci5zdHJpbmcoMSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgbWVzc2FnZVZhbHVlID0gZmllbGRzLk07XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBuYW1lID09PSAnbm90aWNlJyA/IG5ldyBtZXNzYWdlc18xLk5vdGljZU1lc3NhZ2UobGVuZ3RoLCBtZXNzYWdlVmFsdWUpIDogbmV3IG1lc3NhZ2VzXzEuRGF0YWJhc2VFcnJvcihtZXNzYWdlVmFsdWUsIGxlbmd0aCwgbmFtZSk7XG4gICAgICAgIG1lc3NhZ2Uuc2V2ZXJpdHkgPSBmaWVsZHMuUztcbiAgICAgICAgbWVzc2FnZS5jb2RlID0gZmllbGRzLkM7XG4gICAgICAgIG1lc3NhZ2UuZGV0YWlsID0gZmllbGRzLkQ7XG4gICAgICAgIG1lc3NhZ2UuaGludCA9IGZpZWxkcy5IO1xuICAgICAgICBtZXNzYWdlLnBvc2l0aW9uID0gZmllbGRzLlA7XG4gICAgICAgIG1lc3NhZ2UuaW50ZXJuYWxQb3NpdGlvbiA9IGZpZWxkcy5wO1xuICAgICAgICBtZXNzYWdlLmludGVybmFsUXVlcnkgPSBmaWVsZHMucTtcbiAgICAgICAgbWVzc2FnZS53aGVyZSA9IGZpZWxkcy5XO1xuICAgICAgICBtZXNzYWdlLnNjaGVtYSA9IGZpZWxkcy5zO1xuICAgICAgICBtZXNzYWdlLnRhYmxlID0gZmllbGRzLnQ7XG4gICAgICAgIG1lc3NhZ2UuY29sdW1uID0gZmllbGRzLmM7XG4gICAgICAgIG1lc3NhZ2UuZGF0YVR5cGUgPSBmaWVsZHMuZDtcbiAgICAgICAgbWVzc2FnZS5jb25zdHJhaW50ID0gZmllbGRzLm47XG4gICAgICAgIG1lc3NhZ2UuZmlsZSA9IGZpZWxkcy5GO1xuICAgICAgICBtZXNzYWdlLmxpbmUgPSBmaWVsZHMuTDtcbiAgICAgICAgbWVzc2FnZS5yb3V0aW5lID0gZmllbGRzLlI7XG4gICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgIH1cbn1cbmV4cG9ydHMuUGFyc2VyID0gUGFyc2VyO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cGFyc2VyLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5zZXJpYWxpemUgPSB2b2lkIDA7XG5jb25zdCBidWZmZXJfd3JpdGVyXzEgPSByZXF1aXJlKFwiLi9idWZmZXItd3JpdGVyXCIpO1xuY29uc3Qgd3JpdGVyID0gbmV3IGJ1ZmZlcl93cml0ZXJfMS5Xcml0ZXIoKTtcbmNvbnN0IHN0YXJ0dXAgPSAob3B0cykgPT4ge1xuICAgIC8vIHByb3RvY29sIHZlcnNpb25cbiAgICB3cml0ZXIuYWRkSW50MTYoMykuYWRkSW50MTYoMCk7XG4gICAgZm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMob3B0cykpIHtcbiAgICAgICAgd3JpdGVyLmFkZENTdHJpbmcoa2V5KS5hZGRDU3RyaW5nKG9wdHNba2V5XSk7XG4gICAgfVxuICAgIHdyaXRlci5hZGRDU3RyaW5nKCdjbGllbnRfZW5jb2RpbmcnKS5hZGRDU3RyaW5nKCdVVEY4Jyk7XG4gICAgdmFyIGJvZHlCdWZmZXIgPSB3cml0ZXIuYWRkQ1N0cmluZygnJykuZmx1c2goKTtcbiAgICAvLyB0aGlzIG1lc3NhZ2UgaXMgc2VudCB3aXRob3V0IGEgY29kZVxuICAgIHZhciBsZW5ndGggPSBib2R5QnVmZmVyLmxlbmd0aCArIDQ7XG4gICAgcmV0dXJuIG5ldyBidWZmZXJfd3JpdGVyXzEuV3JpdGVyKCkuYWRkSW50MzIobGVuZ3RoKS5hZGQoYm9keUJ1ZmZlcikuZmx1c2goKTtcbn07XG5jb25zdCByZXF1ZXN0U3NsID0gKCkgPT4ge1xuICAgIGNvbnN0IHJlc3BvbnNlID0gQnVmZmVyLmFsbG9jVW5zYWZlKDgpO1xuICAgIHJlc3BvbnNlLndyaXRlSW50MzJCRSg4LCAwKTtcbiAgICByZXNwb25zZS53cml0ZUludDMyQkUoODA4NzcxMDMsIDQpO1xuICAgIHJldHVybiByZXNwb25zZTtcbn07XG5jb25zdCBwYXNzd29yZCA9IChwYXNzd29yZCkgPT4ge1xuICAgIHJldHVybiB3cml0ZXIuYWRkQ1N0cmluZyhwYXNzd29yZCkuZmx1c2goMTEyIC8qIHN0YXJ0dXAgKi8pO1xufTtcbmNvbnN0IHNlbmRTQVNMSW5pdGlhbFJlc3BvbnNlTWVzc2FnZSA9IGZ1bmN0aW9uIChtZWNoYW5pc20sIGluaXRpYWxSZXNwb25zZSkge1xuICAgIC8vIDB4NzAgPSAncCdcbiAgICB3cml0ZXIuYWRkQ1N0cmluZyhtZWNoYW5pc20pLmFkZEludDMyKEJ1ZmZlci5ieXRlTGVuZ3RoKGluaXRpYWxSZXNwb25zZSkpLmFkZFN0cmluZyhpbml0aWFsUmVzcG9uc2UpO1xuICAgIHJldHVybiB3cml0ZXIuZmx1c2goMTEyIC8qIHN0YXJ0dXAgKi8pO1xufTtcbmNvbnN0IHNlbmRTQ1JBTUNsaWVudEZpbmFsTWVzc2FnZSA9IGZ1bmN0aW9uIChhZGRpdGlvbmFsRGF0YSkge1xuICAgIHJldHVybiB3cml0ZXIuYWRkU3RyaW5nKGFkZGl0aW9uYWxEYXRhKS5mbHVzaCgxMTIgLyogc3RhcnR1cCAqLyk7XG59O1xuY29uc3QgcXVlcnkgPSAodGV4dCkgPT4ge1xuICAgIHJldHVybiB3cml0ZXIuYWRkQ1N0cmluZyh0ZXh0KS5mbHVzaCg4MSAvKiBxdWVyeSAqLyk7XG59O1xuY29uc3QgZW1wdHlBcnJheSA9IFtdO1xuY29uc3QgcGFyc2UgPSAocXVlcnkpID0+IHtcbiAgICAvLyBleHBlY3Qgc29tZXRoaW5nIGxpa2UgdGhpczpcbiAgICAvLyB7IG5hbWU6ICdxdWVyeU5hbWUnLFxuICAgIC8vICAgdGV4dDogJ3NlbGVjdCAqIGZyb20gYmxhaCcsXG4gICAgLy8gICB0eXBlczogWydpbnQ4JywgJ2Jvb2wnXSB9XG4gICAgLy8gbm9ybWFsaXplIG1pc3NpbmcgcXVlcnkgbmFtZXMgdG8gYWxsb3cgZm9yIG51bGxcbiAgICBjb25zdCBuYW1lID0gcXVlcnkubmFtZSB8fCAnJztcbiAgICBpZiAobmFtZS5sZW5ndGggPiA2Mykge1xuICAgICAgICAvKiBlc2xpbnQtZGlzYWJsZSBuby1jb25zb2xlICovXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ1dhcm5pbmchIFBvc3RncmVzIG9ubHkgc3VwcG9ydHMgNjMgY2hhcmFjdGVycyBmb3IgcXVlcnkgbmFtZXMuJyk7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ1lvdSBzdXBwbGllZCAlcyAoJXMpJywgbmFtZSwgbmFtZS5sZW5ndGgpO1xuICAgICAgICBjb25zb2xlLmVycm9yKCdUaGlzIGNhbiBjYXVzZSBjb25mbGljdHMgYW5kIHNpbGVudCBlcnJvcnMgZXhlY3V0aW5nIHF1ZXJpZXMnKTtcbiAgICAgICAgLyogZXNsaW50LWVuYWJsZSBuby1jb25zb2xlICovXG4gICAgfVxuICAgIGNvbnN0IHR5cGVzID0gcXVlcnkudHlwZXMgfHwgZW1wdHlBcnJheTtcbiAgICB2YXIgbGVuID0gdHlwZXMubGVuZ3RoO1xuICAgIHZhciBidWZmZXIgPSB3cml0ZXJcbiAgICAgICAgLmFkZENTdHJpbmcobmFtZSkgLy8gbmFtZSBvZiBxdWVyeVxuICAgICAgICAuYWRkQ1N0cmluZyhxdWVyeS50ZXh0KSAvLyBhY3R1YWwgcXVlcnkgdGV4dFxuICAgICAgICAuYWRkSW50MTYobGVuKTtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgIGJ1ZmZlci5hZGRJbnQzMih0eXBlc1tpXSk7XG4gICAgfVxuICAgIHJldHVybiB3cml0ZXIuZmx1c2goODAgLyogcGFyc2UgKi8pO1xufTtcbmNvbnN0IHBhcmFtV3JpdGVyID0gbmV3IGJ1ZmZlcl93cml0ZXJfMS5Xcml0ZXIoKTtcbmNvbnN0IHdyaXRlVmFsdWVzID0gZnVuY3Rpb24gKHZhbHVlcywgdmFsdWVNYXBwZXIpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHZhbHVlcy5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCBtYXBwZWRWYWwgPSB2YWx1ZU1hcHBlciA/IHZhbHVlTWFwcGVyKHZhbHVlc1tpXSwgaSkgOiB2YWx1ZXNbaV07XG4gICAgICAgIGlmIChtYXBwZWRWYWwgPT0gbnVsbCkge1xuICAgICAgICAgICAgLy8gYWRkIHRoZSBwYXJhbSB0eXBlIChzdHJpbmcpIHRvIHRoZSB3cml0ZXJcbiAgICAgICAgICAgIHdyaXRlci5hZGRJbnQxNigwIC8qIFNUUklORyAqLyk7XG4gICAgICAgICAgICAvLyB3cml0ZSAtMSB0byB0aGUgcGFyYW0gd3JpdGVyIHRvIGluZGljYXRlIG51bGxcbiAgICAgICAgICAgIHBhcmFtV3JpdGVyLmFkZEludDMyKC0xKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtYXBwZWRWYWwgaW5zdGFuY2VvZiBCdWZmZXIpIHtcbiAgICAgICAgICAgIC8vIGFkZCB0aGUgcGFyYW0gdHlwZSAoYmluYXJ5KSB0byB0aGUgd3JpdGVyXG4gICAgICAgICAgICB3cml0ZXIuYWRkSW50MTYoMSAvKiBCSU5BUlkgKi8pO1xuICAgICAgICAgICAgLy8gYWRkIHRoZSBidWZmZXIgdG8gdGhlIHBhcmFtIHdyaXRlclxuICAgICAgICAgICAgcGFyYW1Xcml0ZXIuYWRkSW50MzIobWFwcGVkVmFsLmxlbmd0aCk7XG4gICAgICAgICAgICBwYXJhbVdyaXRlci5hZGQobWFwcGVkVmFsKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIC8vIGFkZCB0aGUgcGFyYW0gdHlwZSAoc3RyaW5nKSB0byB0aGUgd3JpdGVyXG4gICAgICAgICAgICB3cml0ZXIuYWRkSW50MTYoMCAvKiBTVFJJTkcgKi8pO1xuICAgICAgICAgICAgcGFyYW1Xcml0ZXIuYWRkSW50MzIoQnVmZmVyLmJ5dGVMZW5ndGgobWFwcGVkVmFsKSk7XG4gICAgICAgICAgICBwYXJhbVdyaXRlci5hZGRTdHJpbmcobWFwcGVkVmFsKTtcbiAgICAgICAgfVxuICAgIH1cbn07XG5jb25zdCBiaW5kID0gKGNvbmZpZyA9IHt9KSA9PiB7XG4gICAgLy8gbm9ybWFsaXplIGNvbmZpZ1xuICAgIGNvbnN0IHBvcnRhbCA9IGNvbmZpZy5wb3J0YWwgfHwgJyc7XG4gICAgY29uc3Qgc3RhdGVtZW50ID0gY29uZmlnLnN0YXRlbWVudCB8fCAnJztcbiAgICBjb25zdCBiaW5hcnkgPSBjb25maWcuYmluYXJ5IHx8IGZhbHNlO1xuICAgIGNvbnN0IHZhbHVlcyA9IGNvbmZpZy52YWx1ZXMgfHwgZW1wdHlBcnJheTtcbiAgICBjb25zdCBsZW4gPSB2YWx1ZXMubGVuZ3RoO1xuICAgIHdyaXRlci5hZGRDU3RyaW5nKHBvcnRhbCkuYWRkQ1N0cmluZyhzdGF0ZW1lbnQpO1xuICAgIHdyaXRlci5hZGRJbnQxNihsZW4pO1xuICAgIHdyaXRlVmFsdWVzKHZhbHVlcywgY29uZmlnLnZhbHVlTWFwcGVyKTtcbiAgICB3cml0ZXIuYWRkSW50MTYobGVuKTtcbiAgICB3cml0ZXIuYWRkKHBhcmFtV3JpdGVyLmZsdXNoKCkpO1xuICAgIC8vIGZvcm1hdCBjb2RlXG4gICAgd3JpdGVyLmFkZEludDE2KGJpbmFyeSA/IDEgLyogQklOQVJZICovIDogMCAvKiBTVFJJTkcgKi8pO1xuICAgIHJldHVybiB3cml0ZXIuZmx1c2goNjYgLyogYmluZCAqLyk7XG59O1xuY29uc3QgZW1wdHlFeGVjdXRlID0gQnVmZmVyLmZyb20oWzY5IC8qIGV4ZWN1dGUgKi8sIDB4MDAsIDB4MDAsIDB4MDAsIDB4MDksIDB4MDAsIDB4MDAsIDB4MDAsIDB4MDAsIDB4MDBdKTtcbmNvbnN0IGV4ZWN1dGUgPSAoY29uZmlnKSA9PiB7XG4gICAgLy8gdGhpcyBpcyB0aGUgaGFwcHkgcGF0aCBmb3IgbW9zdCBxdWVyaWVzXG4gICAgaWYgKCFjb25maWcgfHwgKCFjb25maWcucG9ydGFsICYmICFjb25maWcucm93cykpIHtcbiAgICAgICAgcmV0dXJuIGVtcHR5RXhlY3V0ZTtcbiAgICB9XG4gICAgY29uc3QgcG9ydGFsID0gY29uZmlnLnBvcnRhbCB8fCAnJztcbiAgICBjb25zdCByb3dzID0gY29uZmlnLnJvd3MgfHwgMDtcbiAgICBjb25zdCBwb3J0YWxMZW5ndGggPSBCdWZmZXIuYnl0ZUxlbmd0aChwb3J0YWwpO1xuICAgIGNvbnN0IGxlbiA9IDQgKyBwb3J0YWxMZW5ndGggKyAxICsgNDtcbiAgICAvLyBvbmUgZXh0cmEgYml0IGZvciBjb2RlXG4gICAgY29uc3QgYnVmZiA9IEJ1ZmZlci5hbGxvY1Vuc2FmZSgxICsgbGVuKTtcbiAgICBidWZmWzBdID0gNjkgLyogZXhlY3V0ZSAqLztcbiAgICBidWZmLndyaXRlSW50MzJCRShsZW4sIDEpO1xuICAgIGJ1ZmYud3JpdGUocG9ydGFsLCA1LCAndXRmLTgnKTtcbiAgICBidWZmW3BvcnRhbExlbmd0aCArIDVdID0gMDsgLy8gbnVsbCB0ZXJtaW5hdGUgcG9ydGFsIGNTdHJpbmdcbiAgICBidWZmLndyaXRlVUludDMyQkUocm93cywgYnVmZi5sZW5ndGggLSA0KTtcbiAgICByZXR1cm4gYnVmZjtcbn07XG5jb25zdCBjYW5jZWwgPSAocHJvY2Vzc0lELCBzZWNyZXRLZXkpID0+IHtcbiAgICBjb25zdCBidWZmZXIgPSBCdWZmZXIuYWxsb2NVbnNhZmUoMTYpO1xuICAgIGJ1ZmZlci53cml0ZUludDMyQkUoMTYsIDApO1xuICAgIGJ1ZmZlci53cml0ZUludDE2QkUoMTIzNCwgNCk7XG4gICAgYnVmZmVyLndyaXRlSW50MTZCRSg1Njc4LCA2KTtcbiAgICBidWZmZXIud3JpdGVJbnQzMkJFKHByb2Nlc3NJRCwgOCk7XG4gICAgYnVmZmVyLndyaXRlSW50MzJCRShzZWNyZXRLZXksIDEyKTtcbiAgICByZXR1cm4gYnVmZmVyO1xufTtcbmNvbnN0IGNzdHJpbmdNZXNzYWdlID0gKGNvZGUsIHN0cmluZykgPT4ge1xuICAgIGNvbnN0IHN0cmluZ0xlbiA9IEJ1ZmZlci5ieXRlTGVuZ3RoKHN0cmluZyk7XG4gICAgY29uc3QgbGVuID0gNCArIHN0cmluZ0xlbiArIDE7XG4gICAgLy8gb25lIGV4dHJhIGJpdCBmb3IgY29kZVxuICAgIGNvbnN0IGJ1ZmZlciA9IEJ1ZmZlci5hbGxvY1Vuc2FmZSgxICsgbGVuKTtcbiAgICBidWZmZXJbMF0gPSBjb2RlO1xuICAgIGJ1ZmZlci53cml0ZUludDMyQkUobGVuLCAxKTtcbiAgICBidWZmZXIud3JpdGUoc3RyaW5nLCA1LCAndXRmLTgnKTtcbiAgICBidWZmZXJbbGVuXSA9IDA7IC8vIG51bGwgdGVybWluYXRlIGNTdHJpbmdcbiAgICByZXR1cm4gYnVmZmVyO1xufTtcbmNvbnN0IGVtcHR5RGVzY3JpYmVQb3J0YWwgPSB3cml0ZXIuYWRkQ1N0cmluZygnUCcpLmZsdXNoKDY4IC8qIGRlc2NyaWJlICovKTtcbmNvbnN0IGVtcHR5RGVzY3JpYmVTdGF0ZW1lbnQgPSB3cml0ZXIuYWRkQ1N0cmluZygnUycpLmZsdXNoKDY4IC8qIGRlc2NyaWJlICovKTtcbmNvbnN0IGRlc2NyaWJlID0gKG1zZykgPT4ge1xuICAgIHJldHVybiBtc2cubmFtZVxuICAgICAgICA/IGNzdHJpbmdNZXNzYWdlKDY4IC8qIGRlc2NyaWJlICovLCBgJHttc2cudHlwZX0ke21zZy5uYW1lIHx8ICcnfWApXG4gICAgICAgIDogbXNnLnR5cGUgPT09ICdQJ1xuICAgICAgICAgICAgPyBlbXB0eURlc2NyaWJlUG9ydGFsXG4gICAgICAgICAgICA6IGVtcHR5RGVzY3JpYmVTdGF0ZW1lbnQ7XG59O1xuY29uc3QgY2xvc2UgPSAobXNnKSA9PiB7XG4gICAgY29uc3QgdGV4dCA9IGAke21zZy50eXBlfSR7bXNnLm5hbWUgfHwgJyd9YDtcbiAgICByZXR1cm4gY3N0cmluZ01lc3NhZ2UoNjcgLyogY2xvc2UgKi8sIHRleHQpO1xufTtcbmNvbnN0IGNvcHlEYXRhID0gKGNodW5rKSA9PiB7XG4gICAgcmV0dXJuIHdyaXRlci5hZGQoY2h1bmspLmZsdXNoKDEwMCAvKiBjb3B5RnJvbUNodW5rICovKTtcbn07XG5jb25zdCBjb3B5RmFpbCA9IChtZXNzYWdlKSA9PiB7XG4gICAgcmV0dXJuIGNzdHJpbmdNZXNzYWdlKDEwMiAvKiBjb3B5RmFpbCAqLywgbWVzc2FnZSk7XG59O1xuY29uc3QgY29kZU9ubHlCdWZmZXIgPSAoY29kZSkgPT4gQnVmZmVyLmZyb20oW2NvZGUsIDB4MDAsIDB4MDAsIDB4MDAsIDB4MDRdKTtcbmNvbnN0IGZsdXNoQnVmZmVyID0gY29kZU9ubHlCdWZmZXIoNzIgLyogZmx1c2ggKi8pO1xuY29uc3Qgc3luY0J1ZmZlciA9IGNvZGVPbmx5QnVmZmVyKDgzIC8qIHN5bmMgKi8pO1xuY29uc3QgZW5kQnVmZmVyID0gY29kZU9ubHlCdWZmZXIoODggLyogZW5kICovKTtcbmNvbnN0IGNvcHlEb25lQnVmZmVyID0gY29kZU9ubHlCdWZmZXIoOTkgLyogY29weURvbmUgKi8pO1xuY29uc3Qgc2VyaWFsaXplID0ge1xuICAgIHN0YXJ0dXAsXG4gICAgcGFzc3dvcmQsXG4gICAgcmVxdWVzdFNzbCxcbiAgICBzZW5kU0FTTEluaXRpYWxSZXNwb25zZU1lc3NhZ2UsXG4gICAgc2VuZFNDUkFNQ2xpZW50RmluYWxNZXNzYWdlLFxuICAgIHF1ZXJ5LFxuICAgIHBhcnNlLFxuICAgIGJpbmQsXG4gICAgZXhlY3V0ZSxcbiAgICBkZXNjcmliZSxcbiAgICBjbG9zZSxcbiAgICBmbHVzaDogKCkgPT4gZmx1c2hCdWZmZXIsXG4gICAgc3luYzogKCkgPT4gc3luY0J1ZmZlcixcbiAgICBlbmQ6ICgpID0+IGVuZEJ1ZmZlcixcbiAgICBjb3B5RGF0YSxcbiAgICBjb3B5RG9uZTogKCkgPT4gY29weURvbmVCdWZmZXIsXG4gICAgY29weUZhaWwsXG4gICAgY2FuY2VsLFxufTtcbmV4cG9ydHMuc2VyaWFsaXplID0gc2VyaWFsaXplO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c2VyaWFsaXplci5qcy5tYXAiLCJ2YXIgdGV4dFBhcnNlcnMgPSByZXF1aXJlKCcuL2xpYi90ZXh0UGFyc2VycycpO1xudmFyIGJpbmFyeVBhcnNlcnMgPSByZXF1aXJlKCcuL2xpYi9iaW5hcnlQYXJzZXJzJyk7XG52YXIgYXJyYXlQYXJzZXIgPSByZXF1aXJlKCcuL2xpYi9hcnJheVBhcnNlcicpO1xudmFyIGJ1aWx0aW5UeXBlcyA9IHJlcXVpcmUoJy4vbGliL2J1aWx0aW5zJyk7XG5cbmV4cG9ydHMuZ2V0VHlwZVBhcnNlciA9IGdldFR5cGVQYXJzZXI7XG5leHBvcnRzLnNldFR5cGVQYXJzZXIgPSBzZXRUeXBlUGFyc2VyO1xuZXhwb3J0cy5hcnJheVBhcnNlciA9IGFycmF5UGFyc2VyO1xuZXhwb3J0cy5idWlsdGlucyA9IGJ1aWx0aW5UeXBlcztcblxudmFyIHR5cGVQYXJzZXJzID0ge1xuICB0ZXh0OiB7fSxcbiAgYmluYXJ5OiB7fVxufTtcblxuLy90aGUgZW1wdHkgcGFyc2UgZnVuY3Rpb25cbmZ1bmN0aW9uIG5vUGFyc2UgKHZhbCkge1xuICByZXR1cm4gU3RyaW5nKHZhbCk7XG59O1xuXG4vL3JldHVybnMgYSBmdW5jdGlvbiB1c2VkIHRvIGNvbnZlcnQgYSBzcGVjaWZpYyB0eXBlIChzcGVjaWZpZWQgYnlcbi8vb2lkKSBpbnRvIGEgcmVzdWx0IGphdmFzY3JpcHQgdHlwZVxuLy9ub3RlOiB0aGUgb2lkIGNhbiBiZSBvYnRhaW5lZCB2aWEgdGhlIGZvbGxvd2luZyBzcWwgcXVlcnk6XG4vL1NFTEVDVCBvaWQgRlJPTSBwZ190eXBlIFdIRVJFIHR5cG5hbWUgPSAnVFlQRV9OQU1FX0hFUkUnO1xuZnVuY3Rpb24gZ2V0VHlwZVBhcnNlciAob2lkLCBmb3JtYXQpIHtcbiAgZm9ybWF0ID0gZm9ybWF0IHx8ICd0ZXh0JztcbiAgaWYgKCF0eXBlUGFyc2Vyc1tmb3JtYXRdKSB7XG4gICAgcmV0dXJuIG5vUGFyc2U7XG4gIH1cbiAgcmV0dXJuIHR5cGVQYXJzZXJzW2Zvcm1hdF1bb2lkXSB8fCBub1BhcnNlO1xufTtcblxuZnVuY3Rpb24gc2V0VHlwZVBhcnNlciAob2lkLCBmb3JtYXQsIHBhcnNlRm4pIHtcbiAgaWYodHlwZW9mIGZvcm1hdCA9PSAnZnVuY3Rpb24nKSB7XG4gICAgcGFyc2VGbiA9IGZvcm1hdDtcbiAgICBmb3JtYXQgPSAndGV4dCc7XG4gIH1cbiAgdHlwZVBhcnNlcnNbZm9ybWF0XVtvaWRdID0gcGFyc2VGbjtcbn07XG5cbnRleHRQYXJzZXJzLmluaXQoZnVuY3Rpb24ob2lkLCBjb252ZXJ0ZXIpIHtcbiAgdHlwZVBhcnNlcnMudGV4dFtvaWRdID0gY29udmVydGVyO1xufSk7XG5cbmJpbmFyeVBhcnNlcnMuaW5pdChmdW5jdGlvbihvaWQsIGNvbnZlcnRlcikge1xuICB0eXBlUGFyc2Vycy5iaW5hcnlbb2lkXSA9IGNvbnZlcnRlcjtcbn0pO1xuIiwidmFyIGFycmF5ID0gcmVxdWlyZSgncG9zdGdyZXMtYXJyYXknKTtcblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gIGNyZWF0ZTogZnVuY3Rpb24gKHNvdXJjZSwgdHJhbnNmb3JtKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHBhcnNlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIGFycmF5LnBhcnNlKHNvdXJjZSwgdHJhbnNmb3JtKTtcbiAgICAgIH1cbiAgICB9O1xuICB9XG59O1xuIiwidmFyIHBhcnNlSW50NjQgPSByZXF1aXJlKCdwZy1pbnQ4Jyk7XG5cbnZhciBwYXJzZUJpdHMgPSBmdW5jdGlvbihkYXRhLCBiaXRzLCBvZmZzZXQsIGludmVydCwgY2FsbGJhY2spIHtcbiAgb2Zmc2V0ID0gb2Zmc2V0IHx8IDA7XG4gIGludmVydCA9IGludmVydCB8fCBmYWxzZTtcbiAgY2FsbGJhY2sgPSBjYWxsYmFjayB8fCBmdW5jdGlvbihsYXN0VmFsdWUsIG5ld1ZhbHVlLCBiaXRzKSB7IHJldHVybiAobGFzdFZhbHVlICogTWF0aC5wb3coMiwgYml0cykpICsgbmV3VmFsdWU7IH07XG4gIHZhciBvZmZzZXRCeXRlcyA9IG9mZnNldCA+PiAzO1xuXG4gIHZhciBpbnYgPSBmdW5jdGlvbih2YWx1ZSkge1xuICAgIGlmIChpbnZlcnQpIHtcbiAgICAgIHJldHVybiB+dmFsdWUgJiAweGZmO1xuICAgIH1cblxuICAgIHJldHVybiB2YWx1ZTtcbiAgfTtcblxuICAvLyByZWFkIGZpcnN0IChtYXliZSBwYXJ0aWFsKSBieXRlXG4gIHZhciBtYXNrID0gMHhmZjtcbiAgdmFyIGZpcnN0Qml0cyA9IDggLSAob2Zmc2V0ICUgOCk7XG4gIGlmIChiaXRzIDwgZmlyc3RCaXRzKSB7XG4gICAgbWFzayA9ICgweGZmIDw8ICg4IC0gYml0cykpICYgMHhmZjtcbiAgICBmaXJzdEJpdHMgPSBiaXRzO1xuICB9XG5cbiAgaWYgKG9mZnNldCkge1xuICAgIG1hc2sgPSBtYXNrID4+IChvZmZzZXQgJSA4KTtcbiAgfVxuXG4gIHZhciByZXN1bHQgPSAwO1xuICBpZiAoKG9mZnNldCAlIDgpICsgYml0cyA+PSA4KSB7XG4gICAgcmVzdWx0ID0gY2FsbGJhY2soMCwgaW52KGRhdGFbb2Zmc2V0Qnl0ZXNdKSAmIG1hc2ssIGZpcnN0Qml0cyk7XG4gIH1cblxuICAvLyByZWFkIGJ5dGVzXG4gIHZhciBieXRlcyA9IChiaXRzICsgb2Zmc2V0KSA+PiAzO1xuICBmb3IgKHZhciBpID0gb2Zmc2V0Qnl0ZXMgKyAxOyBpIDwgYnl0ZXM7IGkrKykge1xuICAgIHJlc3VsdCA9IGNhbGxiYWNrKHJlc3VsdCwgaW52KGRhdGFbaV0pLCA4KTtcbiAgfVxuXG4gIC8vIGJpdHMgdG8gcmVhZCwgdGhhdCBhcmUgbm90IGEgY29tcGxldGUgYnl0ZVxuICB2YXIgbGFzdEJpdHMgPSAoYml0cyArIG9mZnNldCkgJSA4O1xuICBpZiAobGFzdEJpdHMgPiAwKSB7XG4gICAgcmVzdWx0ID0gY2FsbGJhY2socmVzdWx0LCBpbnYoZGF0YVtieXRlc10pID4+ICg4IC0gbGFzdEJpdHMpLCBsYXN0Qml0cyk7XG4gIH1cblxuICByZXR1cm4gcmVzdWx0O1xufTtcblxudmFyIHBhcnNlRmxvYXRGcm9tQml0cyA9IGZ1bmN0aW9uKGRhdGEsIHByZWNpc2lvbkJpdHMsIGV4cG9uZW50Qml0cykge1xuICB2YXIgYmlhcyA9IE1hdGgucG93KDIsIGV4cG9uZW50Qml0cyAtIDEpIC0gMTtcbiAgdmFyIHNpZ24gPSBwYXJzZUJpdHMoZGF0YSwgMSk7XG4gIHZhciBleHBvbmVudCA9IHBhcnNlQml0cyhkYXRhLCBleHBvbmVudEJpdHMsIDEpO1xuXG4gIGlmIChleHBvbmVudCA9PT0gMCkge1xuICAgIHJldHVybiAwO1xuICB9XG5cbiAgLy8gcGFyc2UgbWFudGlzc2FcbiAgdmFyIHByZWNpc2lvbkJpdHNDb3VudGVyID0gMTtcbiAgdmFyIHBhcnNlUHJlY2lzaW9uQml0cyA9IGZ1bmN0aW9uKGxhc3RWYWx1ZSwgbmV3VmFsdWUsIGJpdHMpIHtcbiAgICBpZiAobGFzdFZhbHVlID09PSAwKSB7XG4gICAgICBsYXN0VmFsdWUgPSAxO1xuICAgIH1cblxuICAgIGZvciAodmFyIGkgPSAxOyBpIDw9IGJpdHM7IGkrKykge1xuICAgICAgcHJlY2lzaW9uQml0c0NvdW50ZXIgLz0gMjtcbiAgICAgIGlmICgobmV3VmFsdWUgJiAoMHgxIDw8IChiaXRzIC0gaSkpKSA+IDApIHtcbiAgICAgICAgbGFzdFZhbHVlICs9IHByZWNpc2lvbkJpdHNDb3VudGVyO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBsYXN0VmFsdWU7XG4gIH07XG5cbiAgdmFyIG1hbnRpc3NhID0gcGFyc2VCaXRzKGRhdGEsIHByZWNpc2lvbkJpdHMsIGV4cG9uZW50Qml0cyArIDEsIGZhbHNlLCBwYXJzZVByZWNpc2lvbkJpdHMpO1xuXG4gIC8vIHNwZWNpYWwgY2FzZXNcbiAgaWYgKGV4cG9uZW50ID09IChNYXRoLnBvdygyLCBleHBvbmVudEJpdHMgKyAxKSAtIDEpKSB7XG4gICAgaWYgKG1hbnRpc3NhID09PSAwKSB7XG4gICAgICByZXR1cm4gKHNpZ24gPT09IDApID8gSW5maW5pdHkgOiAtSW5maW5pdHk7XG4gICAgfVxuXG4gICAgcmV0dXJuIE5hTjtcbiAgfVxuXG4gIC8vIG5vcm1hbGUgbnVtYmVyXG4gIHJldHVybiAoKHNpZ24gPT09IDApID8gMSA6IC0xKSAqIE1hdGgucG93KDIsIGV4cG9uZW50IC0gYmlhcykgKiBtYW50aXNzYTtcbn07XG5cbnZhciBwYXJzZUludDE2ID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgaWYgKHBhcnNlQml0cyh2YWx1ZSwgMSkgPT0gMSkge1xuICAgIHJldHVybiAtMSAqIChwYXJzZUJpdHModmFsdWUsIDE1LCAxLCB0cnVlKSArIDEpO1xuICB9XG5cbiAgcmV0dXJuIHBhcnNlQml0cyh2YWx1ZSwgMTUsIDEpO1xufTtcblxudmFyIHBhcnNlSW50MzIgPSBmdW5jdGlvbih2YWx1ZSkge1xuICBpZiAocGFyc2VCaXRzKHZhbHVlLCAxKSA9PSAxKSB7XG4gICAgcmV0dXJuIC0xICogKHBhcnNlQml0cyh2YWx1ZSwgMzEsIDEsIHRydWUpICsgMSk7XG4gIH1cblxuICByZXR1cm4gcGFyc2VCaXRzKHZhbHVlLCAzMSwgMSk7XG59O1xuXG52YXIgcGFyc2VGbG9hdDMyID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgcmV0dXJuIHBhcnNlRmxvYXRGcm9tQml0cyh2YWx1ZSwgMjMsIDgpO1xufTtcblxudmFyIHBhcnNlRmxvYXQ2NCA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIHJldHVybiBwYXJzZUZsb2F0RnJvbUJpdHModmFsdWUsIDUyLCAxMSk7XG59O1xuXG52YXIgcGFyc2VOdW1lcmljID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgdmFyIHNpZ24gPSBwYXJzZUJpdHModmFsdWUsIDE2LCAzMik7XG4gIGlmIChzaWduID09IDB4YzAwMCkge1xuICAgIHJldHVybiBOYU47XG4gIH1cblxuICB2YXIgd2VpZ2h0ID0gTWF0aC5wb3coMTAwMDAsIHBhcnNlQml0cyh2YWx1ZSwgMTYsIDE2KSk7XG4gIHZhciByZXN1bHQgPSAwO1xuXG4gIHZhciBkaWdpdHMgPSBbXTtcbiAgdmFyIG5kaWdpdHMgPSBwYXJzZUJpdHModmFsdWUsIDE2KTtcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBuZGlnaXRzOyBpKyspIHtcbiAgICByZXN1bHQgKz0gcGFyc2VCaXRzKHZhbHVlLCAxNiwgNjQgKyAoMTYgKiBpKSkgKiB3ZWlnaHQ7XG4gICAgd2VpZ2h0IC89IDEwMDAwO1xuICB9XG5cbiAgdmFyIHNjYWxlID0gTWF0aC5wb3coMTAsIHBhcnNlQml0cyh2YWx1ZSwgMTYsIDQ4KSk7XG4gIHJldHVybiAoKHNpZ24gPT09IDApID8gMSA6IC0xKSAqIE1hdGgucm91bmQocmVzdWx0ICogc2NhbGUpIC8gc2NhbGU7XG59O1xuXG52YXIgcGFyc2VEYXRlID0gZnVuY3Rpb24oaXNVVEMsIHZhbHVlKSB7XG4gIHZhciBzaWduID0gcGFyc2VCaXRzKHZhbHVlLCAxKTtcbiAgdmFyIHJhd1ZhbHVlID0gcGFyc2VCaXRzKHZhbHVlLCA2MywgMSk7XG5cbiAgLy8gZGlzY2FyZCB1c2VjcyBhbmQgc2hpZnQgZnJvbSAyMDAwIHRvIDE5NzBcbiAgdmFyIHJlc3VsdCA9IG5ldyBEYXRlKCgoKHNpZ24gPT09IDApID8gMSA6IC0xKSAqIHJhd1ZhbHVlIC8gMTAwMCkgKyA5NDY2ODQ4MDAwMDApO1xuXG4gIGlmICghaXNVVEMpIHtcbiAgICByZXN1bHQuc2V0VGltZShyZXN1bHQuZ2V0VGltZSgpICsgcmVzdWx0LmdldFRpbWV6b25lT2Zmc2V0KCkgKiA2MDAwMCk7XG4gIH1cblxuICAvLyBhZGQgbWljcm9zZWNvbmRzIHRvIHRoZSBkYXRlXG4gIHJlc3VsdC51c2VjID0gcmF3VmFsdWUgJSAxMDAwO1xuICByZXN1bHQuZ2V0TWljcm9TZWNvbmRzID0gZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMudXNlYztcbiAgfTtcbiAgcmVzdWx0LnNldE1pY3JvU2Vjb25kcyA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gICAgdGhpcy51c2VjID0gdmFsdWU7XG4gIH07XG4gIHJlc3VsdC5nZXRVVENNaWNyb1NlY29uZHMgPSBmdW5jdGlvbigpIHtcbiAgICByZXR1cm4gdGhpcy51c2VjO1xuICB9O1xuXG4gIHJldHVybiByZXN1bHQ7XG59O1xuXG52YXIgcGFyc2VBcnJheSA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIHZhciBkaW0gPSBwYXJzZUJpdHModmFsdWUsIDMyKTtcblxuICB2YXIgZmxhZ3MgPSBwYXJzZUJpdHModmFsdWUsIDMyLCAzMik7XG4gIHZhciBlbGVtZW50VHlwZSA9IHBhcnNlQml0cyh2YWx1ZSwgMzIsIDY0KTtcblxuICB2YXIgb2Zmc2V0ID0gOTY7XG4gIHZhciBkaW1zID0gW107XG4gIGZvciAodmFyIGkgPSAwOyBpIDwgZGltOyBpKyspIHtcbiAgICAvLyBwYXJzZSBkaW1lbnNpb25cbiAgICBkaW1zW2ldID0gcGFyc2VCaXRzKHZhbHVlLCAzMiwgb2Zmc2V0KTtcbiAgICBvZmZzZXQgKz0gMzI7XG5cbiAgICAvLyBpZ25vcmUgbG93ZXIgYm91bmRzXG4gICAgb2Zmc2V0ICs9IDMyO1xuICB9XG5cbiAgdmFyIHBhcnNlRWxlbWVudCA9IGZ1bmN0aW9uKGVsZW1lbnRUeXBlKSB7XG4gICAgLy8gcGFyc2UgY29udGVudCBsZW5ndGhcbiAgICB2YXIgbGVuZ3RoID0gcGFyc2VCaXRzKHZhbHVlLCAzMiwgb2Zmc2V0KTtcbiAgICBvZmZzZXQgKz0gMzI7XG5cbiAgICAvLyBwYXJzZSBudWxsIHZhbHVlc1xuICAgIGlmIChsZW5ndGggPT0gMHhmZmZmZmZmZikge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuXG4gICAgdmFyIHJlc3VsdDtcbiAgICBpZiAoKGVsZW1lbnRUeXBlID09IDB4MTcpIHx8IChlbGVtZW50VHlwZSA9PSAweDE0KSkge1xuICAgICAgLy8gaW50L2JpZ2ludFxuICAgICAgcmVzdWx0ID0gcGFyc2VCaXRzKHZhbHVlLCBsZW5ndGggKiA4LCBvZmZzZXQpO1xuICAgICAgb2Zmc2V0ICs9IGxlbmd0aCAqIDg7XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBlbHNlIGlmIChlbGVtZW50VHlwZSA9PSAweDE5KSB7XG4gICAgICAvLyBzdHJpbmdcbiAgICAgIHJlc3VsdCA9IHZhbHVlLnRvU3RyaW5nKHRoaXMuZW5jb2RpbmcsIG9mZnNldCA+PiAzLCAob2Zmc2V0ICs9IChsZW5ndGggPDwgMykpID4+IDMpO1xuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICBjb25zb2xlLmxvZyhcIkVSUk9SOiBFbGVtZW50VHlwZSBub3QgaW1wbGVtZW50ZWQ6IFwiICsgZWxlbWVudFR5cGUpO1xuICAgIH1cbiAgfTtcblxuICB2YXIgcGFyc2UgPSBmdW5jdGlvbihkaW1lbnNpb24sIGVsZW1lbnRUeXBlKSB7XG4gICAgdmFyIGFycmF5ID0gW107XG4gICAgdmFyIGk7XG5cbiAgICBpZiAoZGltZW5zaW9uLmxlbmd0aCA+IDEpIHtcbiAgICAgIHZhciBjb3VudCA9IGRpbWVuc2lvbi5zaGlmdCgpO1xuICAgICAgZm9yIChpID0gMDsgaSA8IGNvdW50OyBpKyspIHtcbiAgICAgICAgYXJyYXlbaV0gPSBwYXJzZShkaW1lbnNpb24sIGVsZW1lbnRUeXBlKTtcbiAgICAgIH1cbiAgICAgIGRpbWVuc2lvbi51bnNoaWZ0KGNvdW50KTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICBmb3IgKGkgPSAwOyBpIDwgZGltZW5zaW9uWzBdOyBpKyspIHtcbiAgICAgICAgYXJyYXlbaV0gPSBwYXJzZUVsZW1lbnQoZWxlbWVudFR5cGUpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBhcnJheTtcbiAgfTtcblxuICByZXR1cm4gcGFyc2UoZGltcywgZWxlbWVudFR5cGUpO1xufTtcblxudmFyIHBhcnNlVGV4dCA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIHJldHVybiB2YWx1ZS50b1N0cmluZygndXRmOCcpO1xufTtcblxudmFyIHBhcnNlQm9vbCA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIGlmKHZhbHVlID09PSBudWxsKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIChwYXJzZUJpdHModmFsdWUsIDgpID4gMCk7XG59O1xuXG52YXIgaW5pdCA9IGZ1bmN0aW9uKHJlZ2lzdGVyKSB7XG4gIHJlZ2lzdGVyKDIwLCBwYXJzZUludDY0KTtcbiAgcmVnaXN0ZXIoMjEsIHBhcnNlSW50MTYpO1xuICByZWdpc3RlcigyMywgcGFyc2VJbnQzMik7XG4gIHJlZ2lzdGVyKDI2LCBwYXJzZUludDMyKTtcbiAgcmVnaXN0ZXIoMTcwMCwgcGFyc2VOdW1lcmljKTtcbiAgcmVnaXN0ZXIoNzAwLCBwYXJzZUZsb2F0MzIpO1xuICByZWdpc3Rlcig3MDEsIHBhcnNlRmxvYXQ2NCk7XG4gIHJlZ2lzdGVyKDE2LCBwYXJzZUJvb2wpO1xuICByZWdpc3RlcigxMTE0LCBwYXJzZURhdGUuYmluZChudWxsLCBmYWxzZSkpO1xuICByZWdpc3RlcigxMTg0LCBwYXJzZURhdGUuYmluZChudWxsLCB0cnVlKSk7XG4gIHJlZ2lzdGVyKDEwMDAsIHBhcnNlQXJyYXkpO1xuICByZWdpc3RlcigxMDA3LCBwYXJzZUFycmF5KTtcbiAgcmVnaXN0ZXIoMTAxNiwgcGFyc2VBcnJheSk7XG4gIHJlZ2lzdGVyKDEwMDgsIHBhcnNlQXJyYXkpO1xuICByZWdpc3RlcigxMDA5LCBwYXJzZUFycmF5KTtcbiAgcmVnaXN0ZXIoMjUsIHBhcnNlVGV4dCk7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgaW5pdDogaW5pdFxufTtcbiIsIi8qKlxuICogRm9sbG93aW5nIHF1ZXJ5IHdhcyB1c2VkIHRvIGdlbmVyYXRlIHRoaXMgZmlsZTpcblxuIFNFTEVDVCBqc29uX29iamVjdF9hZ2coVVBQRVIoUFQudHlwbmFtZSksIFBULm9pZDo6aW50NCBPUkRFUiBCWSBwdC5vaWQpXG4gRlJPTSBwZ190eXBlIFBUXG4gV0hFUkUgdHlwbmFtZXNwYWNlID0gKFNFTEVDVCBwZ24ub2lkIEZST00gcGdfbmFtZXNwYWNlIHBnbiBXSEVSRSBuc3BuYW1lID0gJ3BnX2NhdGFsb2cnKSAtLSBUYWtlIG9ubHkgYnVpbHRpbmcgUG9zdGdyZXMgdHlwZXMgd2l0aCBzdGFibGUgT0lEIChleHRlbnNpb24gdHlwZXMgYXJlIG5vdCBndWFyYW50ZWQgdG8gYmUgc3RhYmxlKVxuIEFORCB0eXB0eXBlID0gJ2InIC0tIE9ubHkgYmFzaWMgdHlwZXNcbiBBTkQgdHlwZWxlbSA9IDAgLS0gSWdub3JlIGFsaWFzZXNcbiBBTkQgdHlwaXNkZWZpbmVkIC0tIElnbm9yZSB1bmRlZmluZWQgdHlwZXNcbiAqL1xuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgICBCT09MOiAxNixcbiAgICBCWVRFQTogMTcsXG4gICAgQ0hBUjogMTgsXG4gICAgSU5UODogMjAsXG4gICAgSU5UMjogMjEsXG4gICAgSU5UNDogMjMsXG4gICAgUkVHUFJPQzogMjQsXG4gICAgVEVYVDogMjUsXG4gICAgT0lEOiAyNixcbiAgICBUSUQ6IDI3LFxuICAgIFhJRDogMjgsXG4gICAgQ0lEOiAyOSxcbiAgICBKU09OOiAxMTQsXG4gICAgWE1MOiAxNDIsXG4gICAgUEdfTk9ERV9UUkVFOiAxOTQsXG4gICAgU01HUjogMjEwLFxuICAgIFBBVEg6IDYwMixcbiAgICBQT0xZR09OOiA2MDQsXG4gICAgQ0lEUjogNjUwLFxuICAgIEZMT0FUNDogNzAwLFxuICAgIEZMT0FUODogNzAxLFxuICAgIEFCU1RJTUU6IDcwMixcbiAgICBSRUxUSU1FOiA3MDMsXG4gICAgVElOVEVSVkFMOiA3MDQsXG4gICAgQ0lSQ0xFOiA3MTgsXG4gICAgTUFDQUREUjg6IDc3NCxcbiAgICBNT05FWTogNzkwLFxuICAgIE1BQ0FERFI6IDgyOSxcbiAgICBJTkVUOiA4NjksXG4gICAgQUNMSVRFTTogMTAzMyxcbiAgICBCUENIQVI6IDEwNDIsXG4gICAgVkFSQ0hBUjogMTA0MyxcbiAgICBEQVRFOiAxMDgyLFxuICAgIFRJTUU6IDEwODMsXG4gICAgVElNRVNUQU1QOiAxMTE0LFxuICAgIFRJTUVTVEFNUFRaOiAxMTg0LFxuICAgIElOVEVSVkFMOiAxMTg2LFxuICAgIFRJTUVUWjogMTI2NixcbiAgICBCSVQ6IDE1NjAsXG4gICAgVkFSQklUOiAxNTYyLFxuICAgIE5VTUVSSUM6IDE3MDAsXG4gICAgUkVGQ1VSU09SOiAxNzkwLFxuICAgIFJFR1BST0NFRFVSRTogMjIwMixcbiAgICBSRUdPUEVSOiAyMjAzLFxuICAgIFJFR09QRVJBVE9SOiAyMjA0LFxuICAgIFJFR0NMQVNTOiAyMjA1LFxuICAgIFJFR1RZUEU6IDIyMDYsXG4gICAgVVVJRDogMjk1MCxcbiAgICBUWElEX1NOQVBTSE9UOiAyOTcwLFxuICAgIFBHX0xTTjogMzIyMCxcbiAgICBQR19ORElTVElOQ1Q6IDMzNjEsXG4gICAgUEdfREVQRU5ERU5DSUVTOiAzNDAyLFxuICAgIFRTVkVDVE9SOiAzNjE0LFxuICAgIFRTUVVFUlk6IDM2MTUsXG4gICAgR1RTVkVDVE9SOiAzNjQyLFxuICAgIFJFR0NPTkZJRzogMzczNCxcbiAgICBSRUdESUNUSU9OQVJZOiAzNzY5LFxuICAgIEpTT05COiAzODAyLFxuICAgIFJFR05BTUVTUEFDRTogNDA4OSxcbiAgICBSRUdST0xFOiA0MDk2XG59O1xuIiwidmFyIGFycmF5ID0gcmVxdWlyZSgncG9zdGdyZXMtYXJyYXknKVxudmFyIGFycmF5UGFyc2VyID0gcmVxdWlyZSgnLi9hcnJheVBhcnNlcicpO1xudmFyIHBhcnNlRGF0ZSA9IHJlcXVpcmUoJ3Bvc3RncmVzLWRhdGUnKTtcbnZhciBwYXJzZUludGVydmFsID0gcmVxdWlyZSgncG9zdGdyZXMtaW50ZXJ2YWwnKTtcbnZhciBwYXJzZUJ5dGVBID0gcmVxdWlyZSgncG9zdGdyZXMtYnl0ZWEnKTtcblxuZnVuY3Rpb24gYWxsb3dOdWxsIChmbikge1xuICByZXR1cm4gZnVuY3Rpb24gbnVsbEFsbG93ZWQgKHZhbHVlKSB7XG4gICAgaWYgKHZhbHVlID09PSBudWxsKSByZXR1cm4gdmFsdWVcbiAgICByZXR1cm4gZm4odmFsdWUpXG4gIH1cbn1cblxuZnVuY3Rpb24gcGFyc2VCb29sICh2YWx1ZSkge1xuICBpZiAodmFsdWUgPT09IG51bGwpIHJldHVybiB2YWx1ZVxuICByZXR1cm4gdmFsdWUgPT09ICdUUlVFJyB8fFxuICAgIHZhbHVlID09PSAndCcgfHxcbiAgICB2YWx1ZSA9PT0gJ3RydWUnIHx8XG4gICAgdmFsdWUgPT09ICd5JyB8fFxuICAgIHZhbHVlID09PSAneWVzJyB8fFxuICAgIHZhbHVlID09PSAnb24nIHx8XG4gICAgdmFsdWUgPT09ICcxJztcbn1cblxuZnVuY3Rpb24gcGFyc2VCb29sQXJyYXkgKHZhbHVlKSB7XG4gIGlmICghdmFsdWUpIHJldHVybiBudWxsXG4gIHJldHVybiBhcnJheS5wYXJzZSh2YWx1ZSwgcGFyc2VCb29sKVxufVxuXG5mdW5jdGlvbiBwYXJzZUJhc2VUZW5JbnQgKHN0cmluZykge1xuICByZXR1cm4gcGFyc2VJbnQoc3RyaW5nLCAxMClcbn1cblxuZnVuY3Rpb24gcGFyc2VJbnRlZ2VyQXJyYXkgKHZhbHVlKSB7XG4gIGlmICghdmFsdWUpIHJldHVybiBudWxsXG4gIHJldHVybiBhcnJheS5wYXJzZSh2YWx1ZSwgYWxsb3dOdWxsKHBhcnNlQmFzZVRlbkludCkpXG59XG5cbmZ1bmN0aW9uIHBhcnNlQmlnSW50ZWdlckFycmF5ICh2YWx1ZSkge1xuICBpZiAoIXZhbHVlKSByZXR1cm4gbnVsbFxuICByZXR1cm4gYXJyYXkucGFyc2UodmFsdWUsIGFsbG93TnVsbChmdW5jdGlvbiAoZW50cnkpIHtcbiAgICByZXR1cm4gcGFyc2VCaWdJbnRlZ2VyKGVudHJ5KS50cmltKClcbiAgfSkpXG59XG5cbnZhciBwYXJzZVBvaW50QXJyYXkgPSBmdW5jdGlvbih2YWx1ZSkge1xuICBpZighdmFsdWUpIHsgcmV0dXJuIG51bGw7IH1cbiAgdmFyIHAgPSBhcnJheVBhcnNlci5jcmVhdGUodmFsdWUsIGZ1bmN0aW9uKGVudHJ5KSB7XG4gICAgaWYoZW50cnkgIT09IG51bGwpIHtcbiAgICAgIGVudHJ5ID0gcGFyc2VQb2ludChlbnRyeSk7XG4gICAgfVxuICAgIHJldHVybiBlbnRyeTtcbiAgfSk7XG5cbiAgcmV0dXJuIHAucGFyc2UoKTtcbn07XG5cbnZhciBwYXJzZUZsb2F0QXJyYXkgPSBmdW5jdGlvbih2YWx1ZSkge1xuICBpZighdmFsdWUpIHsgcmV0dXJuIG51bGw7IH1cbiAgdmFyIHAgPSBhcnJheVBhcnNlci5jcmVhdGUodmFsdWUsIGZ1bmN0aW9uKGVudHJ5KSB7XG4gICAgaWYoZW50cnkgIT09IG51bGwpIHtcbiAgICAgIGVudHJ5ID0gcGFyc2VGbG9hdChlbnRyeSk7XG4gICAgfVxuICAgIHJldHVybiBlbnRyeTtcbiAgfSk7XG5cbiAgcmV0dXJuIHAucGFyc2UoKTtcbn07XG5cbnZhciBwYXJzZVN0cmluZ0FycmF5ID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgaWYoIXZhbHVlKSB7IHJldHVybiBudWxsOyB9XG5cbiAgdmFyIHAgPSBhcnJheVBhcnNlci5jcmVhdGUodmFsdWUpO1xuICByZXR1cm4gcC5wYXJzZSgpO1xufTtcblxudmFyIHBhcnNlRGF0ZUFycmF5ID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgaWYgKCF2YWx1ZSkgeyByZXR1cm4gbnVsbDsgfVxuXG4gIHZhciBwID0gYXJyYXlQYXJzZXIuY3JlYXRlKHZhbHVlLCBmdW5jdGlvbihlbnRyeSkge1xuICAgIGlmIChlbnRyeSAhPT0gbnVsbCkge1xuICAgICAgZW50cnkgPSBwYXJzZURhdGUoZW50cnkpO1xuICAgIH1cbiAgICByZXR1cm4gZW50cnk7XG4gIH0pO1xuXG4gIHJldHVybiBwLnBhcnNlKCk7XG59O1xuXG52YXIgcGFyc2VJbnRlcnZhbEFycmF5ID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgaWYgKCF2YWx1ZSkgeyByZXR1cm4gbnVsbDsgfVxuXG4gIHZhciBwID0gYXJyYXlQYXJzZXIuY3JlYXRlKHZhbHVlLCBmdW5jdGlvbihlbnRyeSkge1xuICAgIGlmIChlbnRyeSAhPT0gbnVsbCkge1xuICAgICAgZW50cnkgPSBwYXJzZUludGVydmFsKGVudHJ5KTtcbiAgICB9XG4gICAgcmV0dXJuIGVudHJ5O1xuICB9KTtcblxuICByZXR1cm4gcC5wYXJzZSgpO1xufTtcblxudmFyIHBhcnNlQnl0ZUFBcnJheSA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIGlmICghdmFsdWUpIHsgcmV0dXJuIG51bGw7IH1cblxuICByZXR1cm4gYXJyYXkucGFyc2UodmFsdWUsIGFsbG93TnVsbChwYXJzZUJ5dGVBKSk7XG59O1xuXG52YXIgcGFyc2VJbnRlZ2VyID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgcmV0dXJuIHBhcnNlSW50KHZhbHVlLCAxMCk7XG59O1xuXG52YXIgcGFyc2VCaWdJbnRlZ2VyID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgdmFyIHZhbFN0ciA9IFN0cmluZyh2YWx1ZSk7XG4gIGlmICgvXlxcZCskLy50ZXN0KHZhbFN0cikpIHsgcmV0dXJuIHZhbFN0cjsgfVxuICByZXR1cm4gdmFsdWU7XG59O1xuXG52YXIgcGFyc2VKc29uQXJyYXkgPSBmdW5jdGlvbih2YWx1ZSkge1xuICBpZiAoIXZhbHVlKSB7IHJldHVybiBudWxsOyB9XG5cbiAgcmV0dXJuIGFycmF5LnBhcnNlKHZhbHVlLCBhbGxvd051bGwoSlNPTi5wYXJzZSkpO1xufTtcblxudmFyIHBhcnNlUG9pbnQgPSBmdW5jdGlvbih2YWx1ZSkge1xuICBpZiAodmFsdWVbMF0gIT09ICcoJykgeyByZXR1cm4gbnVsbDsgfVxuXG4gIHZhbHVlID0gdmFsdWUuc3Vic3RyaW5nKCAxLCB2YWx1ZS5sZW5ndGggLSAxICkuc3BsaXQoJywnKTtcblxuICByZXR1cm4ge1xuICAgIHg6IHBhcnNlRmxvYXQodmFsdWVbMF0pXG4gICwgeTogcGFyc2VGbG9hdCh2YWx1ZVsxXSlcbiAgfTtcbn07XG5cbnZhciBwYXJzZUNpcmNsZSA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIGlmICh2YWx1ZVswXSAhPT0gJzwnICYmIHZhbHVlWzFdICE9PSAnKCcpIHsgcmV0dXJuIG51bGw7IH1cblxuICB2YXIgcG9pbnQgPSAnKCc7XG4gIHZhciByYWRpdXMgPSAnJztcbiAgdmFyIHBvaW50UGFyc2VkID0gZmFsc2U7XG4gIGZvciAodmFyIGkgPSAyOyBpIDwgdmFsdWUubGVuZ3RoIC0gMTsgaSsrKXtcbiAgICBpZiAoIXBvaW50UGFyc2VkKSB7XG4gICAgICBwb2ludCArPSB2YWx1ZVtpXTtcbiAgICB9XG5cbiAgICBpZiAodmFsdWVbaV0gPT09ICcpJykge1xuICAgICAgcG9pbnRQYXJzZWQgPSB0cnVlO1xuICAgICAgY29udGludWU7XG4gICAgfSBlbHNlIGlmICghcG9pbnRQYXJzZWQpIHtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGlmICh2YWx1ZVtpXSA9PT0gJywnKXtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIHJhZGl1cyArPSB2YWx1ZVtpXTtcbiAgfVxuICB2YXIgcmVzdWx0ID0gcGFyc2VQb2ludChwb2ludCk7XG4gIHJlc3VsdC5yYWRpdXMgPSBwYXJzZUZsb2F0KHJhZGl1cyk7XG5cbiAgcmV0dXJuIHJlc3VsdDtcbn07XG5cbnZhciBpbml0ID0gZnVuY3Rpb24ocmVnaXN0ZXIpIHtcbiAgcmVnaXN0ZXIoMjAsIHBhcnNlQmlnSW50ZWdlcik7IC8vIGludDhcbiAgcmVnaXN0ZXIoMjEsIHBhcnNlSW50ZWdlcik7IC8vIGludDJcbiAgcmVnaXN0ZXIoMjMsIHBhcnNlSW50ZWdlcik7IC8vIGludDRcbiAgcmVnaXN0ZXIoMjYsIHBhcnNlSW50ZWdlcik7IC8vIG9pZFxuICByZWdpc3Rlcig3MDAsIHBhcnNlRmxvYXQpOyAvLyBmbG9hdDQvcmVhbFxuICByZWdpc3Rlcig3MDEsIHBhcnNlRmxvYXQpOyAvLyBmbG9hdDgvZG91YmxlXG4gIHJlZ2lzdGVyKDE2LCBwYXJzZUJvb2wpO1xuICByZWdpc3RlcigxMDgyLCBwYXJzZURhdGUpOyAvLyBkYXRlXG4gIHJlZ2lzdGVyKDExMTQsIHBhcnNlRGF0ZSk7IC8vIHRpbWVzdGFtcCB3aXRob3V0IHRpbWV6b25lXG4gIHJlZ2lzdGVyKDExODQsIHBhcnNlRGF0ZSk7IC8vIHRpbWVzdGFtcFxuICByZWdpc3Rlcig2MDAsIHBhcnNlUG9pbnQpOyAvLyBwb2ludFxuICByZWdpc3Rlcig2NTEsIHBhcnNlU3RyaW5nQXJyYXkpOyAvLyBjaWRyW11cbiAgcmVnaXN0ZXIoNzE4LCBwYXJzZUNpcmNsZSk7IC8vIGNpcmNsZVxuICByZWdpc3RlcigxMDAwLCBwYXJzZUJvb2xBcnJheSk7XG4gIHJlZ2lzdGVyKDEwMDEsIHBhcnNlQnl0ZUFBcnJheSk7XG4gIHJlZ2lzdGVyKDEwMDUsIHBhcnNlSW50ZWdlckFycmF5KTsgLy8gX2ludDJcbiAgcmVnaXN0ZXIoMTAwNywgcGFyc2VJbnRlZ2VyQXJyYXkpOyAvLyBfaW50NFxuICByZWdpc3RlcigxMDI4LCBwYXJzZUludGVnZXJBcnJheSk7IC8vIG9pZFtdXG4gIHJlZ2lzdGVyKDEwMTYsIHBhcnNlQmlnSW50ZWdlckFycmF5KTsgLy8gX2ludDhcbiAgcmVnaXN0ZXIoMTAxNywgcGFyc2VQb2ludEFycmF5KTsgLy8gcG9pbnRbXVxuICByZWdpc3RlcigxMDIxLCBwYXJzZUZsb2F0QXJyYXkpOyAvLyBfZmxvYXQ0XG4gIHJlZ2lzdGVyKDEwMjIsIHBhcnNlRmxvYXRBcnJheSk7IC8vIF9mbG9hdDhcbiAgcmVnaXN0ZXIoMTIzMSwgcGFyc2VGbG9hdEFycmF5KTsgLy8gX251bWVyaWNcbiAgcmVnaXN0ZXIoMTAxNCwgcGFyc2VTdHJpbmdBcnJheSk7IC8vY2hhclxuICByZWdpc3RlcigxMDE1LCBwYXJzZVN0cmluZ0FycmF5KTsgLy92YXJjaGFyXG4gIHJlZ2lzdGVyKDEwMDgsIHBhcnNlU3RyaW5nQXJyYXkpO1xuICByZWdpc3RlcigxMDA5LCBwYXJzZVN0cmluZ0FycmF5KTtcbiAgcmVnaXN0ZXIoMTA0MCwgcGFyc2VTdHJpbmdBcnJheSk7IC8vIG1hY2FkZHJbXVxuICByZWdpc3RlcigxMDQxLCBwYXJzZVN0cmluZ0FycmF5KTsgLy8gaW5ldFtdXG4gIHJlZ2lzdGVyKDExMTUsIHBhcnNlRGF0ZUFycmF5KTsgLy8gdGltZXN0YW1wIHdpdGhvdXQgdGltZSB6b25lW11cbiAgcmVnaXN0ZXIoMTE4MiwgcGFyc2VEYXRlQXJyYXkpOyAvLyBfZGF0ZVxuICByZWdpc3RlcigxMTg1LCBwYXJzZURhdGVBcnJheSk7IC8vIHRpbWVzdGFtcCB3aXRoIHRpbWUgem9uZVtdXG4gIHJlZ2lzdGVyKDExODYsIHBhcnNlSW50ZXJ2YWwpO1xuICByZWdpc3RlcigxMTg3LCBwYXJzZUludGVydmFsQXJyYXkpO1xuICByZWdpc3RlcigxNywgcGFyc2VCeXRlQSk7XG4gIHJlZ2lzdGVyKDExNCwgSlNPTi5wYXJzZS5iaW5kKEpTT04pKTsgLy8ganNvblxuICByZWdpc3RlcigzODAyLCBKU09OLnBhcnNlLmJpbmQoSlNPTikpOyAvLyBqc29uYlxuICByZWdpc3RlcigxOTksIHBhcnNlSnNvbkFycmF5KTsgLy8ganNvbltdXG4gIHJlZ2lzdGVyKDM4MDcsIHBhcnNlSnNvbkFycmF5KTsgLy8ganNvbmJbXVxuICByZWdpc3RlcigzOTA3LCBwYXJzZVN0cmluZ0FycmF5KTsgLy8gbnVtcmFuZ2VbXVxuICByZWdpc3RlcigyOTUxLCBwYXJzZVN0cmluZ0FycmF5KTsgLy8gdXVpZFtdXG4gIHJlZ2lzdGVyKDc5MSwgcGFyc2VTdHJpbmdBcnJheSk7IC8vIG1vbmV5W11cbiAgcmVnaXN0ZXIoMTE4MywgcGFyc2VTdHJpbmdBcnJheSk7IC8vIHRpbWVbXVxuICByZWdpc3RlcigxMjcwLCBwYXJzZVN0cmluZ0FycmF5KTsgLy8gdGltZXR6W11cbn07XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICBpbml0OiBpbml0XG59O1xuIiwiJ3VzZSBzdHJpY3QnXG5cbnZhciBFdmVudEVtaXR0ZXIgPSByZXF1aXJlKCdldmVudHMnKS5FdmVudEVtaXR0ZXJcbnZhciB1dGlsID0gcmVxdWlyZSgndXRpbCcpXG52YXIgdXRpbHMgPSByZXF1aXJlKCcuL3V0aWxzJylcbnZhciBzYXNsID0gcmVxdWlyZSgnLi9zYXNsJylcbnZhciBwZ1Bhc3MgPSByZXF1aXJlKCdwZ3Bhc3MnKVxudmFyIFR5cGVPdmVycmlkZXMgPSByZXF1aXJlKCcuL3R5cGUtb3ZlcnJpZGVzJylcblxudmFyIENvbm5lY3Rpb25QYXJhbWV0ZXJzID0gcmVxdWlyZSgnLi9jb25uZWN0aW9uLXBhcmFtZXRlcnMnKVxudmFyIFF1ZXJ5ID0gcmVxdWlyZSgnLi9xdWVyeScpXG52YXIgZGVmYXVsdHMgPSByZXF1aXJlKCcuL2RlZmF1bHRzJylcbnZhciBDb25uZWN0aW9uID0gcmVxdWlyZSgnLi9jb25uZWN0aW9uJylcblxuY2xhc3MgQ2xpZW50IGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgY29uc3RydWN0b3IoY29uZmlnKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycyA9IG5ldyBDb25uZWN0aW9uUGFyYW1ldGVycyhjb25maWcpXG4gICAgdGhpcy51c2VyID0gdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy51c2VyXG4gICAgdGhpcy5kYXRhYmFzZSA9IHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMuZGF0YWJhc2VcbiAgICB0aGlzLnBvcnQgPSB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLnBvcnRcbiAgICB0aGlzLmhvc3QgPSB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLmhvc3RcblxuICAgIC8vIFwiaGlkaW5nXCIgdGhlIHBhc3N3b3JkIHNvIGl0IGRvZXNuJ3Qgc2hvdyB1cCBpbiBzdGFjayB0cmFjZXNcbiAgICAvLyBvciBpZiB0aGUgY2xpZW50IGlzIGNvbnNvbGUubG9nZ2VkXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsICdwYXNzd29yZCcsIHtcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICB2YWx1ZTogdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy5wYXNzd29yZCxcbiAgICB9KVxuXG4gICAgdGhpcy5yZXBsaWNhdGlvbiA9IHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMucmVwbGljYXRpb25cblxuICAgIHZhciBjID0gY29uZmlnIHx8IHt9XG5cbiAgICB0aGlzLl9Qcm9taXNlID0gYy5Qcm9taXNlIHx8IGdsb2JhbC5Qcm9taXNlXG4gICAgdGhpcy5fdHlwZXMgPSBuZXcgVHlwZU92ZXJyaWRlcyhjLnR5cGVzKVxuICAgIHRoaXMuX2VuZGluZyA9IGZhbHNlXG4gICAgdGhpcy5fY29ubmVjdGluZyA9IGZhbHNlXG4gICAgdGhpcy5fY29ubmVjdGVkID0gZmFsc2VcbiAgICB0aGlzLl9jb25uZWN0aW9uRXJyb3IgPSBmYWxzZVxuICAgIHRoaXMuX3F1ZXJ5YWJsZSA9IHRydWVcblxuICAgIHRoaXMuY29ubmVjdGlvbiA9XG4gICAgICBjLmNvbm5lY3Rpb24gfHxcbiAgICAgIG5ldyBDb25uZWN0aW9uKHtcbiAgICAgICAgc3RyZWFtOiBjLnN0cmVhbSxcbiAgICAgICAgc3NsOiB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLnNzbCxcbiAgICAgICAga2VlcEFsaXZlOiBjLmtlZXBBbGl2ZSB8fCBmYWxzZSxcbiAgICAgICAga2VlcEFsaXZlSW5pdGlhbERlbGF5TWlsbGlzOiBjLmtlZXBBbGl2ZUluaXRpYWxEZWxheU1pbGxpcyB8fCAwLFxuICAgICAgICBlbmNvZGluZzogdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy5jbGllbnRfZW5jb2RpbmcgfHwgJ3V0ZjgnLFxuICAgICAgfSlcbiAgICB0aGlzLnF1ZXJ5UXVldWUgPSBbXVxuICAgIHRoaXMuYmluYXJ5ID0gYy5iaW5hcnkgfHwgZGVmYXVsdHMuYmluYXJ5XG4gICAgdGhpcy5wcm9jZXNzSUQgPSBudWxsXG4gICAgdGhpcy5zZWNyZXRLZXkgPSBudWxsXG4gICAgdGhpcy5zc2wgPSB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLnNzbCB8fCBmYWxzZVxuICAgIC8vIEFzIHdpdGggUGFzc3dvcmQsIG1ha2UgU1NMLT5LZXkgKHRoZSBwcml2YXRlIGtleSkgbm9uLWVudW1lcmFibGUuXG4gICAgLy8gSXQgd29uJ3Qgc2hvdyB1cCBpbiBzdGFjayB0cmFjZXNcbiAgICAvLyBvciBpZiB0aGUgY2xpZW50IGlzIGNvbnNvbGUubG9nZ2VkXG4gICAgaWYgKHRoaXMuc3NsICYmIHRoaXMuc3NsLmtleSkge1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMuc3NsLCAna2V5Jywge1xuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgIH0pXG4gICAgfVxuXG4gICAgdGhpcy5fY29ubmVjdGlvblRpbWVvdXRNaWxsaXMgPSBjLmNvbm5lY3Rpb25UaW1lb3V0TWlsbGlzIHx8IDBcbiAgfVxuXG4gIF9lcnJvckFsbFF1ZXJpZXMoZXJyKSB7XG4gICAgY29uc3QgZW5xdWV1ZUVycm9yID0gKHF1ZXJ5KSA9PiB7XG4gICAgICBwcm9jZXNzLm5leHRUaWNrKCgpID0+IHtcbiAgICAgICAgcXVlcnkuaGFuZGxlRXJyb3IoZXJyLCB0aGlzLmNvbm5lY3Rpb24pXG4gICAgICB9KVxuICAgIH1cblxuICAgIGlmICh0aGlzLmFjdGl2ZVF1ZXJ5KSB7XG4gICAgICBlbnF1ZXVlRXJyb3IodGhpcy5hY3RpdmVRdWVyeSlcbiAgICAgIHRoaXMuYWN0aXZlUXVlcnkgPSBudWxsXG4gICAgfVxuXG4gICAgdGhpcy5xdWVyeVF1ZXVlLmZvckVhY2goZW5xdWV1ZUVycm9yKVxuICAgIHRoaXMucXVlcnlRdWV1ZS5sZW5ndGggPSAwXG4gIH1cblxuICBfY29ubmVjdChjYWxsYmFjaykge1xuICAgIHZhciBzZWxmID0gdGhpc1xuICAgIHZhciBjb24gPSB0aGlzLmNvbm5lY3Rpb25cbiAgICB0aGlzLl9jb25uZWN0aW9uQ2FsbGJhY2sgPSBjYWxsYmFja1xuXG4gICAgaWYgKHRoaXMuX2Nvbm5lY3RpbmcgfHwgdGhpcy5fY29ubmVjdGVkKSB7XG4gICAgICBjb25zdCBlcnIgPSBuZXcgRXJyb3IoJ0NsaWVudCBoYXMgYWxyZWFkeSBiZWVuIGNvbm5lY3RlZC4gWW91IGNhbm5vdCByZXVzZSBhIGNsaWVudC4nKVxuICAgICAgcHJvY2Vzcy5uZXh0VGljaygoKSA9PiB7XG4gICAgICAgIGNhbGxiYWNrKGVycilcbiAgICAgIH0pXG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgdGhpcy5fY29ubmVjdGluZyA9IHRydWVcblxuICAgIHRoaXMuY29ubmVjdGlvblRpbWVvdXRIYW5kbGVcbiAgICBpZiAodGhpcy5fY29ubmVjdGlvblRpbWVvdXRNaWxsaXMgPiAwKSB7XG4gICAgICB0aGlzLmNvbm5lY3Rpb25UaW1lb3V0SGFuZGxlID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGNvbi5fZW5kaW5nID0gdHJ1ZVxuICAgICAgICBjb24uc3RyZWFtLmRlc3Ryb3kobmV3IEVycm9yKCd0aW1lb3V0IGV4cGlyZWQnKSlcbiAgICAgIH0sIHRoaXMuX2Nvbm5lY3Rpb25UaW1lb3V0TWlsbGlzKVxuICAgIH1cblxuICAgIGlmICh0aGlzLmhvc3QgJiYgdGhpcy5ob3N0LmluZGV4T2YoJy8nKSA9PT0gMCkge1xuICAgICAgY29uLmNvbm5lY3QodGhpcy5ob3N0ICsgJy8ucy5QR1NRTC4nICsgdGhpcy5wb3J0KVxuICAgIH0gZWxzZSB7XG4gICAgICBjb24uY29ubmVjdCh0aGlzLnBvcnQsIHRoaXMuaG9zdClcbiAgICB9XG5cbiAgICAvLyBvbmNlIGNvbm5lY3Rpb24gaXMgZXN0YWJsaXNoZWQgc2VuZCBzdGFydHVwIG1lc3NhZ2VcbiAgICBjb24ub24oJ2Nvbm5lY3QnLCBmdW5jdGlvbiAoKSB7XG4gICAgICBpZiAoc2VsZi5zc2wpIHtcbiAgICAgICAgY29uLnJlcXVlc3RTc2woKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uLnN0YXJ0dXAoc2VsZi5nZXRTdGFydHVwQ29uZigpKVxuICAgICAgfVxuICAgIH0pXG5cbiAgICBjb24ub24oJ3NzbGNvbm5lY3QnLCBmdW5jdGlvbiAoKSB7XG4gICAgICBjb24uc3RhcnR1cChzZWxmLmdldFN0YXJ0dXBDb25mKCkpXG4gICAgfSlcblxuICAgIHRoaXMuX2F0dGFjaExpc3RlbmVycyhjb24pXG5cbiAgICBjb24ub25jZSgnZW5kJywgKCkgPT4ge1xuICAgICAgY29uc3QgZXJyb3IgPSB0aGlzLl9lbmRpbmcgPyBuZXcgRXJyb3IoJ0Nvbm5lY3Rpb24gdGVybWluYXRlZCcpIDogbmV3IEVycm9yKCdDb25uZWN0aW9uIHRlcm1pbmF0ZWQgdW5leHBlY3RlZGx5JylcblxuICAgICAgY2xlYXJUaW1lb3V0KHRoaXMuY29ubmVjdGlvblRpbWVvdXRIYW5kbGUpXG4gICAgICB0aGlzLl9lcnJvckFsbFF1ZXJpZXMoZXJyb3IpXG5cbiAgICAgIGlmICghdGhpcy5fZW5kaW5nKSB7XG4gICAgICAgIC8vIGlmIHRoZSBjb25uZWN0aW9uIGlzIGVuZGVkIHdpdGhvdXQgdXMgY2FsbGluZyAuZW5kKClcbiAgICAgICAgLy8gb24gdGhpcyBjbGllbnQgdGhlbiB3ZSBoYXZlIGFuIHVuZXhwZWN0ZWQgZGlzY29ubmVjdGlvblxuICAgICAgICAvLyB0cmVhdCB0aGlzIGFzIGFuIGVycm9yIHVubGVzcyB3ZSd2ZSBhbHJlYWR5IGVtaXR0ZWQgYW4gZXJyb3JcbiAgICAgICAgLy8gZHVyaW5nIGNvbm5lY3Rpb24uXG4gICAgICAgIGlmICh0aGlzLl9jb25uZWN0aW5nICYmICF0aGlzLl9jb25uZWN0aW9uRXJyb3IpIHtcbiAgICAgICAgICBpZiAodGhpcy5fY29ubmVjdGlvbkNhbGxiYWNrKSB7XG4gICAgICAgICAgICB0aGlzLl9jb25uZWN0aW9uQ2FsbGJhY2soZXJyb3IpXG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuX2hhbmRsZUVycm9yRXZlbnQoZXJyb3IpXG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKCF0aGlzLl9jb25uZWN0aW9uRXJyb3IpIHtcbiAgICAgICAgICB0aGlzLl9oYW5kbGVFcnJvckV2ZW50KGVycm9yKVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHByb2Nlc3MubmV4dFRpY2soKCkgPT4ge1xuICAgICAgICB0aGlzLmVtaXQoJ2VuZCcpXG4gICAgICB9KVxuICAgIH0pXG4gIH1cblxuICBjb25uZWN0KGNhbGxiYWNrKSB7XG4gICAgaWYgKGNhbGxiYWNrKSB7XG4gICAgICB0aGlzLl9jb25uZWN0KGNhbGxiYWNrKVxuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyB0aGlzLl9Qcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIHRoaXMuX2Nvbm5lY3QoKGVycm9yKSA9PiB7XG4gICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgIHJlamVjdChlcnJvcilcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXNvbHZlKClcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9KVxuICB9XG5cbiAgX2F0dGFjaExpc3RlbmVycyhjb24pIHtcbiAgICAvLyBwYXNzd29yZCByZXF1ZXN0IGhhbmRsaW5nXG4gICAgY29uLm9uKCdhdXRoZW50aWNhdGlvbkNsZWFydGV4dFBhc3N3b3JkJywgdGhpcy5faGFuZGxlQXV0aENsZWFydGV4dFBhc3N3b3JkLmJpbmQodGhpcykpXG4gICAgLy8gcGFzc3dvcmQgcmVxdWVzdCBoYW5kbGluZ1xuICAgIGNvbi5vbignYXV0aGVudGljYXRpb25NRDVQYXNzd29yZCcsIHRoaXMuX2hhbmRsZUF1dGhNRDVQYXNzd29yZC5iaW5kKHRoaXMpKVxuICAgIC8vIHBhc3N3b3JkIHJlcXVlc3QgaGFuZGxpbmcgKFNBU0wpXG4gICAgY29uLm9uKCdhdXRoZW50aWNhdGlvblNBU0wnLCB0aGlzLl9oYW5kbGVBdXRoU0FTTC5iaW5kKHRoaXMpKVxuICAgIGNvbi5vbignYXV0aGVudGljYXRpb25TQVNMQ29udGludWUnLCB0aGlzLl9oYW5kbGVBdXRoU0FTTENvbnRpbnVlLmJpbmQodGhpcykpXG4gICAgY29uLm9uKCdhdXRoZW50aWNhdGlvblNBU0xGaW5hbCcsIHRoaXMuX2hhbmRsZUF1dGhTQVNMRmluYWwuYmluZCh0aGlzKSlcbiAgICBjb24ub24oJ2JhY2tlbmRLZXlEYXRhJywgdGhpcy5faGFuZGxlQmFja2VuZEtleURhdGEuYmluZCh0aGlzKSlcbiAgICBjb24ub24oJ2Vycm9yJywgdGhpcy5faGFuZGxlRXJyb3JFdmVudC5iaW5kKHRoaXMpKVxuICAgIGNvbi5vbignZXJyb3JNZXNzYWdlJywgdGhpcy5faGFuZGxlRXJyb3JNZXNzYWdlLmJpbmQodGhpcykpXG4gICAgY29uLm9uKCdyZWFkeUZvclF1ZXJ5JywgdGhpcy5faGFuZGxlUmVhZHlGb3JRdWVyeS5iaW5kKHRoaXMpKVxuICAgIGNvbi5vbignbm90aWNlJywgdGhpcy5faGFuZGxlTm90aWNlLmJpbmQodGhpcykpXG4gICAgY29uLm9uKCdyb3dEZXNjcmlwdGlvbicsIHRoaXMuX2hhbmRsZVJvd0Rlc2NyaXB0aW9uLmJpbmQodGhpcykpXG4gICAgY29uLm9uKCdkYXRhUm93JywgdGhpcy5faGFuZGxlRGF0YVJvdy5iaW5kKHRoaXMpKVxuICAgIGNvbi5vbigncG9ydGFsU3VzcGVuZGVkJywgdGhpcy5faGFuZGxlUG9ydGFsU3VzcGVuZGVkLmJpbmQodGhpcykpXG4gICAgY29uLm9uKCdlbXB0eVF1ZXJ5JywgdGhpcy5faGFuZGxlRW1wdHlRdWVyeS5iaW5kKHRoaXMpKVxuICAgIGNvbi5vbignY29tbWFuZENvbXBsZXRlJywgdGhpcy5faGFuZGxlQ29tbWFuZENvbXBsZXRlLmJpbmQodGhpcykpXG4gICAgY29uLm9uKCdwYXJzZUNvbXBsZXRlJywgdGhpcy5faGFuZGxlUGFyc2VDb21wbGV0ZS5iaW5kKHRoaXMpKVxuICAgIGNvbi5vbignY29weUluUmVzcG9uc2UnLCB0aGlzLl9oYW5kbGVDb3B5SW5SZXNwb25zZS5iaW5kKHRoaXMpKVxuICAgIGNvbi5vbignY29weURhdGEnLCB0aGlzLl9oYW5kbGVDb3B5RGF0YS5iaW5kKHRoaXMpKVxuICAgIGNvbi5vbignbm90aWZpY2F0aW9uJywgdGhpcy5faGFuZGxlTm90aWZpY2F0aW9uLmJpbmQodGhpcykpXG4gIH1cblxuICAvLyBUT0RPKGJtYyk6IGRlcHJlY2F0ZSBwZ3Bhc3MgXCJidWlsdCBpblwiIGludGVncmF0aW9uIHNpbmNlIHRoaXMucGFzc3dvcmQgY2FuIGJlIGEgZnVuY3Rpb25cbiAgLy8gaXQgY2FuIGJlIHN1cHBsaWVkIGJ5IHRoZSB1c2VyIGlmIHJlcXVpcmVkIC0gdGhpcyBpcyBhIGJyZWFraW5nIGNoYW5nZSFcbiAgX2NoZWNrUGdQYXNzKGNiKSB7XG4gICAgY29uc3QgY29uID0gdGhpcy5jb25uZWN0aW9uXG4gICAgaWYgKHR5cGVvZiB0aGlzLnBhc3N3b3JkID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICB0aGlzLl9Qcm9taXNlXG4gICAgICAgIC5yZXNvbHZlKClcbiAgICAgICAgLnRoZW4oKCkgPT4gdGhpcy5wYXNzd29yZCgpKVxuICAgICAgICAudGhlbigocGFzcykgPT4ge1xuICAgICAgICAgIGlmIChwYXNzICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgcGFzcyAhPT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgICAgY29uLmVtaXQoJ2Vycm9yJywgbmV3IFR5cGVFcnJvcignUGFzc3dvcmQgbXVzdCBiZSBhIHN0cmluZycpKVxuICAgICAgICAgICAgICByZXR1cm5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMucGFzc3dvcmQgPSB0aGlzLnBhc3N3b3JkID0gcGFzc1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLnBhc3N3b3JkID0gdGhpcy5wYXNzd29yZCA9IG51bGxcbiAgICAgICAgICB9XG4gICAgICAgICAgY2IoKVxuICAgICAgICB9KVxuICAgICAgICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICAgIGNvbi5lbWl0KCdlcnJvcicsIGVycilcbiAgICAgICAgfSlcbiAgICB9IGVsc2UgaWYgKHRoaXMucGFzc3dvcmQgIT09IG51bGwpIHtcbiAgICAgIGNiKClcbiAgICB9IGVsc2Uge1xuICAgICAgcGdQYXNzKHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMsIChwYXNzKSA9PiB7XG4gICAgICAgIGlmICh1bmRlZmluZWQgIT09IHBhc3MpIHtcbiAgICAgICAgICB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLnBhc3N3b3JkID0gdGhpcy5wYXNzd29yZCA9IHBhc3NcbiAgICAgICAgfVxuICAgICAgICBjYigpXG4gICAgICB9KVxuICAgIH1cbiAgfVxuXG4gIF9oYW5kbGVBdXRoQ2xlYXJ0ZXh0UGFzc3dvcmQobXNnKSB7XG4gICAgdGhpcy5fY2hlY2tQZ1Bhc3MoKCkgPT4ge1xuICAgICAgdGhpcy5jb25uZWN0aW9uLnBhc3N3b3JkKHRoaXMucGFzc3dvcmQpXG4gICAgfSlcbiAgfVxuXG4gIF9oYW5kbGVBdXRoTUQ1UGFzc3dvcmQobXNnKSB7XG4gICAgdGhpcy5fY2hlY2tQZ1Bhc3MoKCkgPT4ge1xuICAgICAgY29uc3QgaGFzaGVkUGFzc3dvcmQgPSB1dGlscy5wb3N0Z3Jlc01kNVBhc3N3b3JkSGFzaCh0aGlzLnVzZXIsIHRoaXMucGFzc3dvcmQsIG1zZy5zYWx0KVxuICAgICAgdGhpcy5jb25uZWN0aW9uLnBhc3N3b3JkKGhhc2hlZFBhc3N3b3JkKVxuICAgIH0pXG4gIH1cblxuICBfaGFuZGxlQXV0aFNBU0wobXNnKSB7XG4gICAgdGhpcy5fY2hlY2tQZ1Bhc3MoKCkgPT4ge1xuICAgICAgdGhpcy5zYXNsU2Vzc2lvbiA9IHNhc2wuc3RhcnRTZXNzaW9uKG1zZy5tZWNoYW5pc21zKVxuICAgICAgdGhpcy5jb25uZWN0aW9uLnNlbmRTQVNMSW5pdGlhbFJlc3BvbnNlTWVzc2FnZSh0aGlzLnNhc2xTZXNzaW9uLm1lY2hhbmlzbSwgdGhpcy5zYXNsU2Vzc2lvbi5yZXNwb25zZSlcbiAgICB9KVxuICB9XG5cbiAgX2hhbmRsZUF1dGhTQVNMQ29udGludWUobXNnKSB7XG4gICAgc2FzbC5jb250aW51ZVNlc3Npb24odGhpcy5zYXNsU2Vzc2lvbiwgdGhpcy5wYXNzd29yZCwgbXNnLmRhdGEpXG4gICAgdGhpcy5jb25uZWN0aW9uLnNlbmRTQ1JBTUNsaWVudEZpbmFsTWVzc2FnZSh0aGlzLnNhc2xTZXNzaW9uLnJlc3BvbnNlKVxuICB9XG5cbiAgX2hhbmRsZUF1dGhTQVNMRmluYWwobXNnKSB7XG4gICAgc2FzbC5maW5hbGl6ZVNlc3Npb24odGhpcy5zYXNsU2Vzc2lvbiwgbXNnLmRhdGEpXG4gICAgdGhpcy5zYXNsU2Vzc2lvbiA9IG51bGxcbiAgfVxuXG4gIF9oYW5kbGVCYWNrZW5kS2V5RGF0YShtc2cpIHtcbiAgICB0aGlzLnByb2Nlc3NJRCA9IG1zZy5wcm9jZXNzSURcbiAgICB0aGlzLnNlY3JldEtleSA9IG1zZy5zZWNyZXRLZXlcbiAgfVxuXG4gIF9oYW5kbGVSZWFkeUZvclF1ZXJ5KG1zZykge1xuICAgIGlmICh0aGlzLl9jb25uZWN0aW5nKSB7XG4gICAgICB0aGlzLl9jb25uZWN0aW5nID0gZmFsc2VcbiAgICAgIHRoaXMuX2Nvbm5lY3RlZCA9IHRydWVcbiAgICAgIGNsZWFyVGltZW91dCh0aGlzLmNvbm5lY3Rpb25UaW1lb3V0SGFuZGxlKVxuXG4gICAgICAvLyBwcm9jZXNzIHBvc3NpYmxlIGNhbGxiYWNrIGFyZ3VtZW50IHRvIENsaWVudCNjb25uZWN0XG4gICAgICBpZiAodGhpcy5fY29ubmVjdGlvbkNhbGxiYWNrKSB7XG4gICAgICAgIHRoaXMuX2Nvbm5lY3Rpb25DYWxsYmFjayhudWxsLCB0aGlzKVxuICAgICAgICAvLyByZW1vdmUgY2FsbGJhY2sgZm9yIHByb3BlciBlcnJvciBoYW5kbGluZ1xuICAgICAgICAvLyBhZnRlciB0aGUgY29ubmVjdCBldmVudFxuICAgICAgICB0aGlzLl9jb25uZWN0aW9uQ2FsbGJhY2sgPSBudWxsXG4gICAgICB9XG4gICAgICB0aGlzLmVtaXQoJ2Nvbm5lY3QnKVxuICAgIH1cbiAgICBjb25zdCB7IGFjdGl2ZVF1ZXJ5IH0gPSB0aGlzXG4gICAgdGhpcy5hY3RpdmVRdWVyeSA9IG51bGxcbiAgICB0aGlzLnJlYWR5Rm9yUXVlcnkgPSB0cnVlXG4gICAgaWYgKGFjdGl2ZVF1ZXJ5KSB7XG4gICAgICBhY3RpdmVRdWVyeS5oYW5kbGVSZWFkeUZvclF1ZXJ5KHRoaXMuY29ubmVjdGlvbilcbiAgICB9XG4gICAgdGhpcy5fcHVsc2VRdWVyeVF1ZXVlKClcbiAgfVxuXG4gIC8vIGlmIHdlIHJlY2VpZXZlIGFuIGVycm9yIGV2ZW50IG9yIGVycm9yIG1lc3NhZ2VcbiAgLy8gZHVyaW5nIHRoZSBjb25uZWN0aW9uIHByb2Nlc3Mgd2UgaGFuZGxlIGl0IGhlcmVcbiAgX2hhbmRsZUVycm9yV2hpbGVDb25uZWN0aW5nKGVycikge1xuICAgIGlmICh0aGlzLl9jb25uZWN0aW9uRXJyb3IpIHtcbiAgICAgIC8vIFRPRE8oYm1jKTogdGhpcyBpcyBzd2FsbG93aW5nIGVycm9ycyAtIHdlIHNob3VsZG4ndCBkbyB0aGlzXG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgdGhpcy5fY29ubmVjdGlvbkVycm9yID0gdHJ1ZVxuICAgIGNsZWFyVGltZW91dCh0aGlzLmNvbm5lY3Rpb25UaW1lb3V0SGFuZGxlKVxuICAgIGlmICh0aGlzLl9jb25uZWN0aW9uQ2FsbGJhY2spIHtcbiAgICAgIHJldHVybiB0aGlzLl9jb25uZWN0aW9uQ2FsbGJhY2soZXJyKVxuICAgIH1cbiAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKVxuICB9XG5cbiAgLy8gaWYgd2UncmUgY29ubmVjdGVkIGFuZCB3ZSByZWNlaXZlIGFuIGVycm9yIGV2ZW50IGZyb20gdGhlIGNvbm5lY3Rpb25cbiAgLy8gdGhpcyBtZWFucyB0aGUgc29ja2V0IGlzIGRlYWQgLSBkbyBhIGhhcmQgYWJvcnQgb2YgYWxsIHF1ZXJpZXMgYW5kIGVtaXRcbiAgLy8gdGhlIHNvY2tldCBlcnJvciBvbiB0aGUgY2xpZW50IGFzIHdlbGxcbiAgX2hhbmRsZUVycm9yRXZlbnQoZXJyKSB7XG4gICAgaWYgKHRoaXMuX2Nvbm5lY3RpbmcpIHtcbiAgICAgIHJldHVybiB0aGlzLl9oYW5kbGVFcnJvcldoaWxlQ29ubmVjdGluZyhlcnIpXG4gICAgfVxuICAgIHRoaXMuX3F1ZXJ5YWJsZSA9IGZhbHNlXG4gICAgdGhpcy5fZXJyb3JBbGxRdWVyaWVzKGVycilcbiAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKVxuICB9XG5cbiAgLy8gaGFuZGxlIGVycm9yIG1lc3NhZ2VzIGZyb20gdGhlIHBvc3RncmVzIGJhY2tlbmRcbiAgX2hhbmRsZUVycm9yTWVzc2FnZShtc2cpIHtcbiAgICBpZiAodGhpcy5fY29ubmVjdGluZykge1xuICAgICAgcmV0dXJuIHRoaXMuX2hhbmRsZUVycm9yV2hpbGVDb25uZWN0aW5nKG1zZylcbiAgICB9XG4gICAgY29uc3QgYWN0aXZlUXVlcnkgPSB0aGlzLmFjdGl2ZVF1ZXJ5XG5cbiAgICBpZiAoIWFjdGl2ZVF1ZXJ5KSB7XG4gICAgICB0aGlzLl9oYW5kbGVFcnJvckV2ZW50KG1zZylcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIHRoaXMuYWN0aXZlUXVlcnkgPSBudWxsXG4gICAgYWN0aXZlUXVlcnkuaGFuZGxlRXJyb3IobXNnLCB0aGlzLmNvbm5lY3Rpb24pXG4gIH1cblxuICBfaGFuZGxlUm93RGVzY3JpcHRpb24obXNnKSB7XG4gICAgLy8gZGVsZWdhdGUgcm93RGVzY3JpcHRpb24gdG8gYWN0aXZlIHF1ZXJ5XG4gICAgdGhpcy5hY3RpdmVRdWVyeS5oYW5kbGVSb3dEZXNjcmlwdGlvbihtc2cpXG4gIH1cblxuICBfaGFuZGxlRGF0YVJvdyhtc2cpIHtcbiAgICAvLyBkZWxlZ2F0ZSBkYXRhUm93IHRvIGFjdGl2ZSBxdWVyeVxuICAgIHRoaXMuYWN0aXZlUXVlcnkuaGFuZGxlRGF0YVJvdyhtc2cpXG4gIH1cblxuICBfaGFuZGxlUG9ydGFsU3VzcGVuZGVkKG1zZykge1xuICAgIC8vIGRlbGVnYXRlIHBvcnRhbFN1c3BlbmRlZCB0byBhY3RpdmUgcXVlcnlcbiAgICB0aGlzLmFjdGl2ZVF1ZXJ5LmhhbmRsZVBvcnRhbFN1c3BlbmRlZCh0aGlzLmNvbm5lY3Rpb24pXG4gIH1cblxuICBfaGFuZGxlRW1wdHlRdWVyeShtc2cpIHtcbiAgICAvLyBkZWxlZ2F0ZSBlbXB0eVF1ZXJ5IHRvIGFjdGl2ZSBxdWVyeVxuICAgIHRoaXMuYWN0aXZlUXVlcnkuaGFuZGxlRW1wdHlRdWVyeSh0aGlzLmNvbm5lY3Rpb24pXG4gIH1cblxuICBfaGFuZGxlQ29tbWFuZENvbXBsZXRlKG1zZykge1xuICAgIC8vIGRlbGVnYXRlIGNvbW1hbmRDb21wbGV0ZSB0byBhY3RpdmUgcXVlcnlcbiAgICB0aGlzLmFjdGl2ZVF1ZXJ5LmhhbmRsZUNvbW1hbmRDb21wbGV0ZShtc2csIHRoaXMuY29ubmVjdGlvbilcbiAgfVxuXG4gIF9oYW5kbGVQYXJzZUNvbXBsZXRlKG1zZykge1xuICAgIC8vIGlmIGEgcHJlcGFyZWQgc3RhdGVtZW50IGhhcyBhIG5hbWUgYW5kIHByb3Blcmx5IHBhcnNlc1xuICAgIC8vIHdlIHRyYWNrIHRoYXQgaXRzIGFscmVhZHkgYmVlbiBleGVjdXRlZCBzbyB3ZSBkb24ndCBwYXJzZVxuICAgIC8vIGl0IGFnYWluIG9uIHRoZSBzYW1lIGNsaWVudFxuICAgIGlmICh0aGlzLmFjdGl2ZVF1ZXJ5Lm5hbWUpIHtcbiAgICAgIHRoaXMuY29ubmVjdGlvbi5wYXJzZWRTdGF0ZW1lbnRzW3RoaXMuYWN0aXZlUXVlcnkubmFtZV0gPSB0aGlzLmFjdGl2ZVF1ZXJ5LnRleHRcbiAgICB9XG4gIH1cblxuICBfaGFuZGxlQ29weUluUmVzcG9uc2UobXNnKSB7XG4gICAgdGhpcy5hY3RpdmVRdWVyeS5oYW5kbGVDb3B5SW5SZXNwb25zZSh0aGlzLmNvbm5lY3Rpb24pXG4gIH1cblxuICBfaGFuZGxlQ29weURhdGEobXNnKSB7XG4gICAgdGhpcy5hY3RpdmVRdWVyeS5oYW5kbGVDb3B5RGF0YShtc2csIHRoaXMuY29ubmVjdGlvbilcbiAgfVxuXG4gIF9oYW5kbGVOb3RpZmljYXRpb24obXNnKSB7XG4gICAgdGhpcy5lbWl0KCdub3RpZmljYXRpb24nLCBtc2cpXG4gIH1cblxuICBfaGFuZGxlTm90aWNlKG1zZykge1xuICAgIHRoaXMuZW1pdCgnbm90aWNlJywgbXNnKVxuICB9XG5cbiAgZ2V0U3RhcnR1cENvbmYoKSB7XG4gICAgdmFyIHBhcmFtcyA9IHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnNcblxuICAgIHZhciBkYXRhID0ge1xuICAgICAgdXNlcjogcGFyYW1zLnVzZXIsXG4gICAgICBkYXRhYmFzZTogcGFyYW1zLmRhdGFiYXNlLFxuICAgIH1cblxuICAgIHZhciBhcHBOYW1lID0gcGFyYW1zLmFwcGxpY2F0aW9uX25hbWUgfHwgcGFyYW1zLmZhbGxiYWNrX2FwcGxpY2F0aW9uX25hbWVcbiAgICBpZiAoYXBwTmFtZSkge1xuICAgICAgZGF0YS5hcHBsaWNhdGlvbl9uYW1lID0gYXBwTmFtZVxuICAgIH1cbiAgICBpZiAocGFyYW1zLnJlcGxpY2F0aW9uKSB7XG4gICAgICBkYXRhLnJlcGxpY2F0aW9uID0gJycgKyBwYXJhbXMucmVwbGljYXRpb25cbiAgICB9XG4gICAgaWYgKHBhcmFtcy5zdGF0ZW1lbnRfdGltZW91dCkge1xuICAgICAgZGF0YS5zdGF0ZW1lbnRfdGltZW91dCA9IFN0cmluZyhwYXJzZUludChwYXJhbXMuc3RhdGVtZW50X3RpbWVvdXQsIDEwKSlcbiAgICB9XG4gICAgaWYgKHBhcmFtcy5pZGxlX2luX3RyYW5zYWN0aW9uX3Nlc3Npb25fdGltZW91dCkge1xuICAgICAgZGF0YS5pZGxlX2luX3RyYW5zYWN0aW9uX3Nlc3Npb25fdGltZW91dCA9IFN0cmluZyhwYXJzZUludChwYXJhbXMuaWRsZV9pbl90cmFuc2FjdGlvbl9zZXNzaW9uX3RpbWVvdXQsIDEwKSlcbiAgICB9XG4gICAgaWYgKHBhcmFtcy5vcHRpb25zKSB7XG4gICAgICBkYXRhLm9wdGlvbnMgPSBwYXJhbXMub3B0aW9uc1xuICAgIH1cblxuICAgIHJldHVybiBkYXRhXG4gIH1cblxuICBjYW5jZWwoY2xpZW50LCBxdWVyeSkge1xuICAgIGlmIChjbGllbnQuYWN0aXZlUXVlcnkgPT09IHF1ZXJ5KSB7XG4gICAgICB2YXIgY29uID0gdGhpcy5jb25uZWN0aW9uXG5cbiAgICAgIGlmICh0aGlzLmhvc3QgJiYgdGhpcy5ob3N0LmluZGV4T2YoJy8nKSA9PT0gMCkge1xuICAgICAgICBjb24uY29ubmVjdCh0aGlzLmhvc3QgKyAnLy5zLlBHU1FMLicgKyB0aGlzLnBvcnQpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb24uY29ubmVjdCh0aGlzLnBvcnQsIHRoaXMuaG9zdClcbiAgICAgIH1cblxuICAgICAgLy8gb25jZSBjb25uZWN0aW9uIGlzIGVzdGFibGlzaGVkIHNlbmQgY2FuY2VsIG1lc3NhZ2VcbiAgICAgIGNvbi5vbignY29ubmVjdCcsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgY29uLmNhbmNlbChjbGllbnQucHJvY2Vzc0lELCBjbGllbnQuc2VjcmV0S2V5KVxuICAgICAgfSlcbiAgICB9IGVsc2UgaWYgKGNsaWVudC5xdWVyeVF1ZXVlLmluZGV4T2YocXVlcnkpICE9PSAtMSkge1xuICAgICAgY2xpZW50LnF1ZXJ5UXVldWUuc3BsaWNlKGNsaWVudC5xdWVyeVF1ZXVlLmluZGV4T2YocXVlcnkpLCAxKVxuICAgIH1cbiAgfVxuXG4gIHNldFR5cGVQYXJzZXIob2lkLCBmb3JtYXQsIHBhcnNlRm4pIHtcbiAgICByZXR1cm4gdGhpcy5fdHlwZXMuc2V0VHlwZVBhcnNlcihvaWQsIGZvcm1hdCwgcGFyc2VGbilcbiAgfVxuXG4gIGdldFR5cGVQYXJzZXIob2lkLCBmb3JtYXQpIHtcbiAgICByZXR1cm4gdGhpcy5fdHlwZXMuZ2V0VHlwZVBhcnNlcihvaWQsIGZvcm1hdClcbiAgfVxuXG4gIC8vIFBvcnRlZCBmcm9tIFBvc3RncmVTUUwgOS4yLjQgc291cmNlIGNvZGUgaW4gc3JjL2ludGVyZmFjZXMvbGlicHEvZmUtZXhlYy5jXG4gIGVzY2FwZUlkZW50aWZpZXIoc3RyKSB7XG4gICAgcmV0dXJuICdcIicgKyBzdHIucmVwbGFjZSgvXCIvZywgJ1wiXCInKSArICdcIidcbiAgfVxuXG4gIC8vIFBvcnRlZCBmcm9tIFBvc3RncmVTUUwgOS4yLjQgc291cmNlIGNvZGUgaW4gc3JjL2ludGVyZmFjZXMvbGlicHEvZmUtZXhlYy5jXG4gIGVzY2FwZUxpdGVyYWwoc3RyKSB7XG4gICAgdmFyIGhhc0JhY2tzbGFzaCA9IGZhbHNlXG4gICAgdmFyIGVzY2FwZWQgPSBcIidcIlxuXG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBzdHIubGVuZ3RoOyBpKyspIHtcbiAgICAgIHZhciBjID0gc3RyW2ldXG4gICAgICBpZiAoYyA9PT0gXCInXCIpIHtcbiAgICAgICAgZXNjYXBlZCArPSBjICsgY1xuICAgICAgfSBlbHNlIGlmIChjID09PSAnXFxcXCcpIHtcbiAgICAgICAgZXNjYXBlZCArPSBjICsgY1xuICAgICAgICBoYXNCYWNrc2xhc2ggPSB0cnVlXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBlc2NhcGVkICs9IGNcbiAgICAgIH1cbiAgICB9XG5cbiAgICBlc2NhcGVkICs9IFwiJ1wiXG5cbiAgICBpZiAoaGFzQmFja3NsYXNoID09PSB0cnVlKSB7XG4gICAgICBlc2NhcGVkID0gJyBFJyArIGVzY2FwZWRcbiAgICB9XG5cbiAgICByZXR1cm4gZXNjYXBlZFxuICB9XG5cbiAgX3B1bHNlUXVlcnlRdWV1ZSgpIHtcbiAgICBpZiAodGhpcy5yZWFkeUZvclF1ZXJ5ID09PSB0cnVlKSB7XG4gICAgICB0aGlzLmFjdGl2ZVF1ZXJ5ID0gdGhpcy5xdWVyeVF1ZXVlLnNoaWZ0KClcbiAgICAgIGlmICh0aGlzLmFjdGl2ZVF1ZXJ5KSB7XG4gICAgICAgIHRoaXMucmVhZHlGb3JRdWVyeSA9IGZhbHNlXG4gICAgICAgIHRoaXMuaGFzRXhlY3V0ZWQgPSB0cnVlXG5cbiAgICAgICAgY29uc3QgcXVlcnlFcnJvciA9IHRoaXMuYWN0aXZlUXVlcnkuc3VibWl0KHRoaXMuY29ubmVjdGlvbilcbiAgICAgICAgaWYgKHF1ZXJ5RXJyb3IpIHtcbiAgICAgICAgICBwcm9jZXNzLm5leHRUaWNrKCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuYWN0aXZlUXVlcnkuaGFuZGxlRXJyb3IocXVlcnlFcnJvciwgdGhpcy5jb25uZWN0aW9uKVxuICAgICAgICAgICAgdGhpcy5yZWFkeUZvclF1ZXJ5ID0gdHJ1ZVxuICAgICAgICAgICAgdGhpcy5fcHVsc2VRdWVyeVF1ZXVlKClcbiAgICAgICAgICB9KVxuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKHRoaXMuaGFzRXhlY3V0ZWQpIHtcbiAgICAgICAgdGhpcy5hY3RpdmVRdWVyeSA9IG51bGxcbiAgICAgICAgdGhpcy5lbWl0KCdkcmFpbicpXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcXVlcnkoY29uZmlnLCB2YWx1ZXMsIGNhbGxiYWNrKSB7XG4gICAgLy8gY2FuIHRha2UgaW4gc3RyaW5ncywgY29uZmlnIG9iamVjdCBvciBxdWVyeSBvYmplY3RcbiAgICB2YXIgcXVlcnlcbiAgICB2YXIgcmVzdWx0XG4gICAgdmFyIHJlYWRUaW1lb3V0XG4gICAgdmFyIHJlYWRUaW1lb3V0VGltZXJcbiAgICB2YXIgcXVlcnlDYWxsYmFja1xuXG4gICAgaWYgKGNvbmZpZyA9PT0gbnVsbCB8fCBjb25maWcgPT09IHVuZGVmaW5lZCkge1xuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignQ2xpZW50IHdhcyBwYXNzZWQgYSBudWxsIG9yIHVuZGVmaW5lZCBxdWVyeScpXG4gICAgfSBlbHNlIGlmICh0eXBlb2YgY29uZmlnLnN1Ym1pdCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgcmVhZFRpbWVvdXQgPSBjb25maWcucXVlcnlfdGltZW91dCB8fCB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLnF1ZXJ5X3RpbWVvdXRcbiAgICAgIHJlc3VsdCA9IHF1ZXJ5ID0gY29uZmlnXG4gICAgICBpZiAodHlwZW9mIHZhbHVlcyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBxdWVyeS5jYWxsYmFjayA9IHF1ZXJ5LmNhbGxiYWNrIHx8IHZhbHVlc1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICByZWFkVGltZW91dCA9IHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMucXVlcnlfdGltZW91dFxuICAgICAgcXVlcnkgPSBuZXcgUXVlcnkoY29uZmlnLCB2YWx1ZXMsIGNhbGxiYWNrKVxuICAgICAgaWYgKCFxdWVyeS5jYWxsYmFjaykge1xuICAgICAgICByZXN1bHQgPSBuZXcgdGhpcy5fUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgcXVlcnkuY2FsbGJhY2sgPSAoZXJyLCByZXMpID0+IChlcnIgPyByZWplY3QoZXJyKSA6IHJlc29sdmUocmVzKSlcbiAgICAgICAgfSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAocmVhZFRpbWVvdXQpIHtcbiAgICAgIHF1ZXJ5Q2FsbGJhY2sgPSBxdWVyeS5jYWxsYmFja1xuXG4gICAgICByZWFkVGltZW91dFRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHZhciBlcnJvciA9IG5ldyBFcnJvcignUXVlcnkgcmVhZCB0aW1lb3V0JylcblxuICAgICAgICBwcm9jZXNzLm5leHRUaWNrKCgpID0+IHtcbiAgICAgICAgICBxdWVyeS5oYW5kbGVFcnJvcihlcnJvciwgdGhpcy5jb25uZWN0aW9uKVxuICAgICAgICB9KVxuXG4gICAgICAgIHF1ZXJ5Q2FsbGJhY2soZXJyb3IpXG5cbiAgICAgICAgLy8gd2UgYWxyZWFkeSByZXR1cm5lZCBhbiBlcnJvcixcbiAgICAgICAgLy8ganVzdCBkbyBub3RoaW5nIGlmIHF1ZXJ5IGNvbXBsZXRlc1xuICAgICAgICBxdWVyeS5jYWxsYmFjayA9ICgpID0+IHt9XG5cbiAgICAgICAgLy8gUmVtb3ZlIGZyb20gcXVldWVcbiAgICAgICAgdmFyIGluZGV4ID0gdGhpcy5xdWVyeVF1ZXVlLmluZGV4T2YocXVlcnkpXG4gICAgICAgIGlmIChpbmRleCA+IC0xKSB7XG4gICAgICAgICAgdGhpcy5xdWVyeVF1ZXVlLnNwbGljZShpbmRleCwgMSlcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuX3B1bHNlUXVlcnlRdWV1ZSgpXG4gICAgICB9LCByZWFkVGltZW91dClcblxuICAgICAgcXVlcnkuY2FsbGJhY2sgPSAoZXJyLCByZXMpID0+IHtcbiAgICAgICAgY2xlYXJUaW1lb3V0KHJlYWRUaW1lb3V0VGltZXIpXG4gICAgICAgIHF1ZXJ5Q2FsbGJhY2soZXJyLCByZXMpXG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuYmluYXJ5ICYmICFxdWVyeS5iaW5hcnkpIHtcbiAgICAgIHF1ZXJ5LmJpbmFyeSA9IHRydWVcbiAgICB9XG5cbiAgICBpZiAocXVlcnkuX3Jlc3VsdCAmJiAhcXVlcnkuX3Jlc3VsdC5fdHlwZXMpIHtcbiAgICAgIHF1ZXJ5Ll9yZXN1bHQuX3R5cGVzID0gdGhpcy5fdHlwZXNcbiAgICB9XG5cbiAgICBpZiAoIXRoaXMuX3F1ZXJ5YWJsZSkge1xuICAgICAgcHJvY2Vzcy5uZXh0VGljaygoKSA9PiB7XG4gICAgICAgIHF1ZXJ5LmhhbmRsZUVycm9yKG5ldyBFcnJvcignQ2xpZW50IGhhcyBlbmNvdW50ZXJlZCBhIGNvbm5lY3Rpb24gZXJyb3IgYW5kIGlzIG5vdCBxdWVyeWFibGUnKSwgdGhpcy5jb25uZWN0aW9uKVxuICAgICAgfSlcbiAgICAgIHJldHVybiByZXN1bHRcbiAgICB9XG5cbiAgICBpZiAodGhpcy5fZW5kaW5nKSB7XG4gICAgICBwcm9jZXNzLm5leHRUaWNrKCgpID0+IHtcbiAgICAgICAgcXVlcnkuaGFuZGxlRXJyb3IobmV3IEVycm9yKCdDbGllbnQgd2FzIGNsb3NlZCBhbmQgaXMgbm90IHF1ZXJ5YWJsZScpLCB0aGlzLmNvbm5lY3Rpb24pXG4gICAgICB9KVxuICAgICAgcmV0dXJuIHJlc3VsdFxuICAgIH1cblxuICAgIHRoaXMucXVlcnlRdWV1ZS5wdXNoKHF1ZXJ5KVxuICAgIHRoaXMuX3B1bHNlUXVlcnlRdWV1ZSgpXG4gICAgcmV0dXJuIHJlc3VsdFxuICB9XG5cbiAgcmVmKCkge1xuICAgIHRoaXMuY29ubmVjdGlvbi5yZWYoKVxuICB9XG5cbiAgdW5yZWYoKSB7XG4gICAgdGhpcy5jb25uZWN0aW9uLnVucmVmKClcbiAgfVxuXG4gIGVuZChjYikge1xuICAgIHRoaXMuX2VuZGluZyA9IHRydWVcblxuICAgIC8vIGlmIHdlIGhhdmUgbmV2ZXIgY29ubmVjdGVkLCB0aGVuIGVuZCBpcyBhIG5vb3AsIGNhbGxiYWNrIGltbWVkaWF0ZWx5XG4gICAgaWYgKCF0aGlzLmNvbm5lY3Rpb24uX2Nvbm5lY3RpbmcpIHtcbiAgICAgIGlmIChjYikge1xuICAgICAgICBjYigpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gdGhpcy5fUHJvbWlzZS5yZXNvbHZlKClcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAodGhpcy5hY3RpdmVRdWVyeSB8fCAhdGhpcy5fcXVlcnlhYmxlKSB7XG4gICAgICAvLyBpZiB3ZSBoYXZlIGFuIGFjdGl2ZSBxdWVyeSB3ZSBuZWVkIHRvIGZvcmNlIGEgZGlzY29ubmVjdFxuICAgICAgLy8gb24gdGhlIHNvY2tldCAtIG90aGVyd2lzZSBhIGh1bmcgcXVlcnkgY291bGQgYmxvY2sgZW5kIGZvcmV2ZXJcbiAgICAgIHRoaXMuY29ubmVjdGlvbi5zdHJlYW0uZGVzdHJveSgpXG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuY29ubmVjdGlvbi5lbmQoKVxuICAgIH1cblxuICAgIGlmIChjYikge1xuICAgICAgdGhpcy5jb25uZWN0aW9uLm9uY2UoJ2VuZCcsIGNiKVxuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gbmV3IHRoaXMuX1Byb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgdGhpcy5jb25uZWN0aW9uLm9uY2UoJ2VuZCcsIHJlc29sdmUpXG4gICAgICB9KVxuICAgIH1cbiAgfVxufVxuXG4vLyBleHBvc2UgYSBRdWVyeSBjb25zdHJ1Y3RvclxuQ2xpZW50LlF1ZXJ5ID0gUXVlcnlcblxubW9kdWxlLmV4cG9ydHMgPSBDbGllbnRcbiIsIid1c2Ugc3RyaWN0J1xuXG52YXIgZG5zID0gcmVxdWlyZSgnZG5zJylcblxudmFyIGRlZmF1bHRzID0gcmVxdWlyZSgnLi9kZWZhdWx0cycpXG5cbnZhciBwYXJzZSA9IHJlcXVpcmUoJ3BnLWNvbm5lY3Rpb24tc3RyaW5nJykucGFyc2UgLy8gcGFyc2VzIGEgY29ubmVjdGlvbiBzdHJpbmdcblxudmFyIHZhbCA9IGZ1bmN0aW9uIChrZXksIGNvbmZpZywgZW52VmFyKSB7XG4gIGlmIChlbnZWYXIgPT09IHVuZGVmaW5lZCkge1xuICAgIGVudlZhciA9IHByb2Nlc3MuZW52WydQRycgKyBrZXkudG9VcHBlckNhc2UoKV1cbiAgfSBlbHNlIGlmIChlbnZWYXIgPT09IGZhbHNlKSB7XG4gICAgLy8gZG8gbm90aGluZyAuLi4gdXNlIGZhbHNlXG4gIH0gZWxzZSB7XG4gICAgZW52VmFyID0gcHJvY2Vzcy5lbnZbZW52VmFyXVxuICB9XG5cbiAgcmV0dXJuIGNvbmZpZ1trZXldIHx8IGVudlZhciB8fCBkZWZhdWx0c1trZXldXG59XG5cbnZhciByZWFkU1NMQ29uZmlnRnJvbUVudmlyb25tZW50ID0gZnVuY3Rpb24gKCkge1xuICBzd2l0Y2ggKHByb2Nlc3MuZW52LlBHU1NMTU9ERSkge1xuICAgIGNhc2UgJ2Rpc2FibGUnOlxuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgY2FzZSAncHJlZmVyJzpcbiAgICBjYXNlICdyZXF1aXJlJzpcbiAgICBjYXNlICd2ZXJpZnktY2EnOlxuICAgIGNhc2UgJ3ZlcmlmeS1mdWxsJzpcbiAgICAgIHJldHVybiB0cnVlXG4gICAgY2FzZSAnbm8tdmVyaWZ5JzpcbiAgICAgIHJldHVybiB7IHJlamVjdFVuYXV0aG9yaXplZDogZmFsc2UgfVxuICB9XG4gIHJldHVybiBkZWZhdWx0cy5zc2xcbn1cblxuLy8gQ29udmVydCBhcmcgdG8gYSBzdHJpbmcsIHN1cnJvdW5kIGluIHNpbmdsZSBxdW90ZXMsIGFuZCBlc2NhcGUgc2luZ2xlIHF1b3RlcyBhbmQgYmFja3NsYXNoZXNcbnZhciBxdW90ZVBhcmFtVmFsdWUgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgcmV0dXJuIFwiJ1wiICsgKCcnICsgdmFsdWUpLnJlcGxhY2UoL1xcXFwvZywgJ1xcXFxcXFxcJykucmVwbGFjZSgvJy9nLCBcIlxcXFwnXCIpICsgXCInXCJcbn1cblxudmFyIGFkZCA9IGZ1bmN0aW9uIChwYXJhbXMsIGNvbmZpZywgcGFyYW1OYW1lKSB7XG4gIHZhciB2YWx1ZSA9IGNvbmZpZ1twYXJhbU5hbWVdXG4gIGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkICYmIHZhbHVlICE9PSBudWxsKSB7XG4gICAgcGFyYW1zLnB1c2gocGFyYW1OYW1lICsgJz0nICsgcXVvdGVQYXJhbVZhbHVlKHZhbHVlKSlcbiAgfVxufVxuXG5jbGFzcyBDb25uZWN0aW9uUGFyYW1ldGVycyB7XG4gIGNvbnN0cnVjdG9yKGNvbmZpZykge1xuICAgIC8vIGlmIGEgc3RyaW5nIGlzIHBhc3NlZCwgaXQgaXMgYSByYXcgY29ubmVjdGlvbiBzdHJpbmcgc28gd2UgcGFyc2UgaXQgaW50byBhIGNvbmZpZ1xuICAgIGNvbmZpZyA9IHR5cGVvZiBjb25maWcgPT09ICdzdHJpbmcnID8gcGFyc2UoY29uZmlnKSA6IGNvbmZpZyB8fCB7fVxuXG4gICAgLy8gaWYgdGhlIGNvbmZpZyBoYXMgYSBjb25uZWN0aW9uU3RyaW5nIGRlZmluZWQsIHBhcnNlIElUIGludG8gdGhlIGNvbmZpZyB3ZSB1c2VcbiAgICAvLyB0aGlzIHdpbGwgb3ZlcnJpZGUgb3RoZXIgZGVmYXVsdCB2YWx1ZXMgd2l0aCB3aGF0IGlzIHN0b3JlZCBpbiBjb25uZWN0aW9uU3RyaW5nXG4gICAgaWYgKGNvbmZpZy5jb25uZWN0aW9uU3RyaW5nKSB7XG4gICAgICBjb25maWcgPSBPYmplY3QuYXNzaWduKHt9LCBjb25maWcsIHBhcnNlKGNvbmZpZy5jb25uZWN0aW9uU3RyaW5nKSlcbiAgICB9XG5cbiAgICB0aGlzLnVzZXIgPSB2YWwoJ3VzZXInLCBjb25maWcpXG4gICAgdGhpcy5kYXRhYmFzZSA9IHZhbCgnZGF0YWJhc2UnLCBjb25maWcpXG5cbiAgICBpZiAodGhpcy5kYXRhYmFzZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aGlzLmRhdGFiYXNlID0gdGhpcy51c2VyXG4gICAgfVxuXG4gICAgdGhpcy5wb3J0ID0gcGFyc2VJbnQodmFsKCdwb3J0JywgY29uZmlnKSwgMTApXG4gICAgdGhpcy5ob3N0ID0gdmFsKCdob3N0JywgY29uZmlnKVxuXG4gICAgLy8gXCJoaWRpbmdcIiB0aGUgcGFzc3dvcmQgc28gaXQgZG9lc24ndCBzaG93IHVwIGluIHN0YWNrIHRyYWNlc1xuICAgIC8vIG9yIGlmIHRoZSBjbGllbnQgaXMgY29uc29sZS5sb2dnZWRcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgJ3Bhc3N3b3JkJywge1xuICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIHZhbHVlOiB2YWwoJ3Bhc3N3b3JkJywgY29uZmlnKSxcbiAgICB9KVxuXG4gICAgdGhpcy5iaW5hcnkgPSB2YWwoJ2JpbmFyeScsIGNvbmZpZylcbiAgICB0aGlzLm9wdGlvbnMgPSB2YWwoJ29wdGlvbnMnLCBjb25maWcpXG5cbiAgICB0aGlzLnNzbCA9IHR5cGVvZiBjb25maWcuc3NsID09PSAndW5kZWZpbmVkJyA/IHJlYWRTU0xDb25maWdGcm9tRW52aXJvbm1lbnQoKSA6IGNvbmZpZy5zc2xcblxuICAgIGlmICh0eXBlb2YgdGhpcy5zc2wgPT09ICdzdHJpbmcnKSB7XG4gICAgICBpZiAodGhpcy5zc2wgPT09ICd0cnVlJykge1xuICAgICAgICB0aGlzLnNzbCA9IHRydWVcbiAgICAgIH1cbiAgICB9XG4gICAgLy8gc3VwcG9ydCBwYXNzaW5nIGluIHNzbD1uby12ZXJpZnkgdmlhIGNvbm5lY3Rpb24gc3RyaW5nXG4gICAgaWYgKHRoaXMuc3NsID09PSAnbm8tdmVyaWZ5Jykge1xuICAgICAgdGhpcy5zc2wgPSB7IHJlamVjdFVuYXV0aG9yaXplZDogZmFsc2UgfVxuICAgIH1cbiAgICBpZiAodGhpcy5zc2wgJiYgdGhpcy5zc2wua2V5KSB7XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcy5zc2wsICdrZXknLCB7XG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgfSlcbiAgICB9XG5cbiAgICB0aGlzLmNsaWVudF9lbmNvZGluZyA9IHZhbCgnY2xpZW50X2VuY29kaW5nJywgY29uZmlnKVxuICAgIHRoaXMucmVwbGljYXRpb24gPSB2YWwoJ3JlcGxpY2F0aW9uJywgY29uZmlnKVxuICAgIC8vIGEgZG9tYWluIHNvY2tldCBiZWdpbnMgd2l0aCAnLydcbiAgICB0aGlzLmlzRG9tYWluU29ja2V0ID0gISh0aGlzLmhvc3QgfHwgJycpLmluZGV4T2YoJy8nKVxuXG4gICAgdGhpcy5hcHBsaWNhdGlvbl9uYW1lID0gdmFsKCdhcHBsaWNhdGlvbl9uYW1lJywgY29uZmlnLCAnUEdBUFBOQU1FJylcbiAgICB0aGlzLmZhbGxiYWNrX2FwcGxpY2F0aW9uX25hbWUgPSB2YWwoJ2ZhbGxiYWNrX2FwcGxpY2F0aW9uX25hbWUnLCBjb25maWcsIGZhbHNlKVxuICAgIHRoaXMuc3RhdGVtZW50X3RpbWVvdXQgPSB2YWwoJ3N0YXRlbWVudF90aW1lb3V0JywgY29uZmlnLCBmYWxzZSlcbiAgICB0aGlzLmlkbGVfaW5fdHJhbnNhY3Rpb25fc2Vzc2lvbl90aW1lb3V0ID0gdmFsKCdpZGxlX2luX3RyYW5zYWN0aW9uX3Nlc3Npb25fdGltZW91dCcsIGNvbmZpZywgZmFsc2UpXG4gICAgdGhpcy5xdWVyeV90aW1lb3V0ID0gdmFsKCdxdWVyeV90aW1lb3V0JywgY29uZmlnLCBmYWxzZSlcblxuICAgIGlmIChjb25maWcuY29ubmVjdGlvblRpbWVvdXRNaWxsaXMgPT09IHVuZGVmaW5lZCkge1xuICAgICAgdGhpcy5jb25uZWN0X3RpbWVvdXQgPSBwcm9jZXNzLmVudi5QR0NPTk5FQ1RfVElNRU9VVCB8fCAwXG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuY29ubmVjdF90aW1lb3V0ID0gTWF0aC5mbG9vcihjb25maWcuY29ubmVjdGlvblRpbWVvdXRNaWxsaXMgLyAxMDAwKVxuICAgIH1cblxuICAgIGlmIChjb25maWcua2VlcEFsaXZlID09PSBmYWxzZSkge1xuICAgICAgdGhpcy5rZWVwYWxpdmVzID0gMFxuICAgIH0gZWxzZSBpZiAoY29uZmlnLmtlZXBBbGl2ZSA9PT0gdHJ1ZSkge1xuICAgICAgdGhpcy5rZWVwYWxpdmVzID0gMVxuICAgIH1cblxuICAgIGlmICh0eXBlb2YgY29uZmlnLmtlZXBBbGl2ZUluaXRpYWxEZWxheU1pbGxpcyA9PT0gJ251bWJlcicpIHtcbiAgICAgIHRoaXMua2VlcGFsaXZlc19pZGxlID0gTWF0aC5mbG9vcihjb25maWcua2VlcEFsaXZlSW5pdGlhbERlbGF5TWlsbGlzIC8gMTAwMClcbiAgICB9XG4gIH1cblxuICBnZXRMaWJwcUNvbm5lY3Rpb25TdHJpbmcoY2IpIHtcbiAgICB2YXIgcGFyYW1zID0gW11cbiAgICBhZGQocGFyYW1zLCB0aGlzLCAndXNlcicpXG4gICAgYWRkKHBhcmFtcywgdGhpcywgJ3Bhc3N3b3JkJylcbiAgICBhZGQocGFyYW1zLCB0aGlzLCAncG9ydCcpXG4gICAgYWRkKHBhcmFtcywgdGhpcywgJ2FwcGxpY2F0aW9uX25hbWUnKVxuICAgIGFkZChwYXJhbXMsIHRoaXMsICdmYWxsYmFja19hcHBsaWNhdGlvbl9uYW1lJylcbiAgICBhZGQocGFyYW1zLCB0aGlzLCAnY29ubmVjdF90aW1lb3V0JylcbiAgICBhZGQocGFyYW1zLCB0aGlzLCAnb3B0aW9ucycpXG5cbiAgICB2YXIgc3NsID0gdHlwZW9mIHRoaXMuc3NsID09PSAnb2JqZWN0JyA/IHRoaXMuc3NsIDogdGhpcy5zc2wgPyB7IHNzbG1vZGU6IHRoaXMuc3NsIH0gOiB7fVxuICAgIGFkZChwYXJhbXMsIHNzbCwgJ3NzbG1vZGUnKVxuICAgIGFkZChwYXJhbXMsIHNzbCwgJ3NzbGNhJylcbiAgICBhZGQocGFyYW1zLCBzc2wsICdzc2xrZXknKVxuICAgIGFkZChwYXJhbXMsIHNzbCwgJ3NzbGNlcnQnKVxuICAgIGFkZChwYXJhbXMsIHNzbCwgJ3NzbHJvb3RjZXJ0JylcblxuICAgIGlmICh0aGlzLmRhdGFiYXNlKSB7XG4gICAgICBwYXJhbXMucHVzaCgnZGJuYW1lPScgKyBxdW90ZVBhcmFtVmFsdWUodGhpcy5kYXRhYmFzZSkpXG4gICAgfVxuICAgIGlmICh0aGlzLnJlcGxpY2F0aW9uKSB7XG4gICAgICBwYXJhbXMucHVzaCgncmVwbGljYXRpb249JyArIHF1b3RlUGFyYW1WYWx1ZSh0aGlzLnJlcGxpY2F0aW9uKSlcbiAgICB9XG4gICAgaWYgKHRoaXMuaG9zdCkge1xuICAgICAgcGFyYW1zLnB1c2goJ2hvc3Q9JyArIHF1b3RlUGFyYW1WYWx1ZSh0aGlzLmhvc3QpKVxuICAgIH1cbiAgICBpZiAodGhpcy5pc0RvbWFpblNvY2tldCkge1xuICAgICAgcmV0dXJuIGNiKG51bGwsIHBhcmFtcy5qb2luKCcgJykpXG4gICAgfVxuICAgIGlmICh0aGlzLmNsaWVudF9lbmNvZGluZykge1xuICAgICAgcGFyYW1zLnB1c2goJ2NsaWVudF9lbmNvZGluZz0nICsgcXVvdGVQYXJhbVZhbHVlKHRoaXMuY2xpZW50X2VuY29kaW5nKSlcbiAgICB9XG4gICAgZG5zLmxvb2t1cCh0aGlzLmhvc3QsIGZ1bmN0aW9uIChlcnIsIGFkZHJlc3MpIHtcbiAgICAgIGlmIChlcnIpIHJldHVybiBjYihlcnIsIG51bGwpXG4gICAgICBwYXJhbXMucHVzaCgnaG9zdGFkZHI9JyArIHF1b3RlUGFyYW1WYWx1ZShhZGRyZXNzKSlcbiAgICAgIHJldHVybiBjYihudWxsLCBwYXJhbXMuam9pbignICcpKVxuICAgIH0pXG4gIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSBDb25uZWN0aW9uUGFyYW1ldGVyc1xuIiwiJ3VzZSBzdHJpY3QnXG5cbnZhciBuZXQgPSByZXF1aXJlKCduZXQnKVxudmFyIEV2ZW50RW1pdHRlciA9IHJlcXVpcmUoJ2V2ZW50cycpLkV2ZW50RW1pdHRlclxuXG5jb25zdCB7IHBhcnNlLCBzZXJpYWxpemUgfSA9IHJlcXVpcmUoJ3BnLXByb3RvY29sJylcblxuY29uc3QgZmx1c2hCdWZmZXIgPSBzZXJpYWxpemUuZmx1c2goKVxuY29uc3Qgc3luY0J1ZmZlciA9IHNlcmlhbGl6ZS5zeW5jKClcbmNvbnN0IGVuZEJ1ZmZlciA9IHNlcmlhbGl6ZS5lbmQoKVxuXG4vLyBUT0RPKGJtYykgc3VwcG9ydCBiaW5hcnkgbW9kZSBhdCBzb21lIHBvaW50XG5jbGFzcyBDb25uZWN0aW9uIGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgY29uc3RydWN0b3IoY29uZmlnKSB7XG4gICAgc3VwZXIoKVxuICAgIGNvbmZpZyA9IGNvbmZpZyB8fCB7fVxuICAgIHRoaXMuc3RyZWFtID0gY29uZmlnLnN0cmVhbSB8fCBuZXcgbmV0LlNvY2tldCgpXG4gICAgdGhpcy5fa2VlcEFsaXZlID0gY29uZmlnLmtlZXBBbGl2ZVxuICAgIHRoaXMuX2tlZXBBbGl2ZUluaXRpYWxEZWxheU1pbGxpcyA9IGNvbmZpZy5rZWVwQWxpdmVJbml0aWFsRGVsYXlNaWxsaXNcbiAgICB0aGlzLmxhc3RCdWZmZXIgPSBmYWxzZVxuICAgIHRoaXMucGFyc2VkU3RhdGVtZW50cyA9IHt9XG4gICAgdGhpcy5zc2wgPSBjb25maWcuc3NsIHx8IGZhbHNlXG4gICAgdGhpcy5fZW5kaW5nID0gZmFsc2VcbiAgICB0aGlzLl9lbWl0TWVzc2FnZSA9IGZhbHNlXG4gICAgdmFyIHNlbGYgPSB0aGlzXG4gICAgdGhpcy5vbignbmV3TGlzdGVuZXInLCBmdW5jdGlvbiAoZXZlbnROYW1lKSB7XG4gICAgICBpZiAoZXZlbnROYW1lID09PSAnbWVzc2FnZScpIHtcbiAgICAgICAgc2VsZi5fZW1pdE1lc3NhZ2UgPSB0cnVlXG4gICAgICB9XG4gICAgfSlcbiAgfVxuXG4gIGNvbm5lY3QocG9ydCwgaG9zdCkge1xuICAgIHZhciBzZWxmID0gdGhpc1xuXG4gICAgdGhpcy5fY29ubmVjdGluZyA9IHRydWVcbiAgICB0aGlzLnN0cmVhbS5zZXROb0RlbGF5KHRydWUpXG4gICAgdGhpcy5zdHJlYW0uY29ubmVjdChwb3J0LCBob3N0KVxuXG4gICAgdGhpcy5zdHJlYW0ub25jZSgnY29ubmVjdCcsIGZ1bmN0aW9uICgpIHtcbiAgICAgIGlmIChzZWxmLl9rZWVwQWxpdmUpIHtcbiAgICAgICAgc2VsZi5zdHJlYW0uc2V0S2VlcEFsaXZlKHRydWUsIHNlbGYuX2tlZXBBbGl2ZUluaXRpYWxEZWxheU1pbGxpcylcbiAgICAgIH1cbiAgICAgIHNlbGYuZW1pdCgnY29ubmVjdCcpXG4gICAgfSlcblxuICAgIGNvbnN0IHJlcG9ydFN0cmVhbUVycm9yID0gZnVuY3Rpb24gKGVycm9yKSB7XG4gICAgICAvLyBlcnJvcnMgYWJvdXQgZGlzY29ubmVjdGlvbnMgc2hvdWxkIGJlIGlnbm9yZWQgZHVyaW5nIGRpc2Nvbm5lY3RcbiAgICAgIGlmIChzZWxmLl9lbmRpbmcgJiYgKGVycm9yLmNvZGUgPT09ICdFQ09OTlJFU0VUJyB8fCBlcnJvci5jb2RlID09PSAnRVBJUEUnKSkge1xuICAgICAgICByZXR1cm5cbiAgICAgIH1cbiAgICAgIHNlbGYuZW1pdCgnZXJyb3InLCBlcnJvcilcbiAgICB9XG4gICAgdGhpcy5zdHJlYW0ub24oJ2Vycm9yJywgcmVwb3J0U3RyZWFtRXJyb3IpXG5cbiAgICB0aGlzLnN0cmVhbS5vbignY2xvc2UnLCBmdW5jdGlvbiAoKSB7XG4gICAgICBzZWxmLmVtaXQoJ2VuZCcpXG4gICAgfSlcblxuICAgIGlmICghdGhpcy5zc2wpIHtcbiAgICAgIHJldHVybiB0aGlzLmF0dGFjaExpc3RlbmVycyh0aGlzLnN0cmVhbSlcbiAgICB9XG5cbiAgICB0aGlzLnN0cmVhbS5vbmNlKCdkYXRhJywgZnVuY3Rpb24gKGJ1ZmZlcikge1xuICAgICAgdmFyIHJlc3BvbnNlQ29kZSA9IGJ1ZmZlci50b1N0cmluZygndXRmOCcpXG4gICAgICBzd2l0Y2ggKHJlc3BvbnNlQ29kZSkge1xuICAgICAgICBjYXNlICdTJzogLy8gU2VydmVyIHN1cHBvcnRzIFNTTCBjb25uZWN0aW9ucywgY29udGludWUgd2l0aCBhIHNlY3VyZSBjb25uZWN0aW9uXG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgY2FzZSAnTic6IC8vIFNlcnZlciBkb2VzIG5vdCBzdXBwb3J0IFNTTCBjb25uZWN0aW9uc1xuICAgICAgICAgIHNlbGYuc3RyZWFtLmVuZCgpXG4gICAgICAgICAgcmV0dXJuIHNlbGYuZW1pdCgnZXJyb3InLCBuZXcgRXJyb3IoJ1RoZSBzZXJ2ZXIgZG9lcyBub3Qgc3VwcG9ydCBTU0wgY29ubmVjdGlvbnMnKSlcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAvLyBBbnkgb3RoZXIgcmVzcG9uc2UgYnl0ZSwgaW5jbHVkaW5nICdFJyAoRXJyb3JSZXNwb25zZSkgaW5kaWNhdGluZyBhIHNlcnZlciBlcnJvclxuICAgICAgICAgIHNlbGYuc3RyZWFtLmVuZCgpXG4gICAgICAgICAgcmV0dXJuIHNlbGYuZW1pdCgnZXJyb3InLCBuZXcgRXJyb3IoJ1RoZXJlIHdhcyBhbiBlcnJvciBlc3RhYmxpc2hpbmcgYW4gU1NMIGNvbm5lY3Rpb24nKSlcbiAgICAgIH1cbiAgICAgIHZhciB0bHMgPSByZXF1aXJlKCd0bHMnKVxuICAgICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgICAgc29ja2V0OiBzZWxmLnN0cmVhbSxcbiAgICAgIH1cblxuICAgICAgaWYgKHNlbGYuc3NsICE9PSB0cnVlKSB7XG4gICAgICAgIE9iamVjdC5hc3NpZ24ob3B0aW9ucywgc2VsZi5zc2wpXG5cbiAgICAgICAgaWYgKCdrZXknIGluIHNlbGYuc3NsKSB7XG4gICAgICAgICAgb3B0aW9ucy5rZXkgPSBzZWxmLnNzbC5rZXlcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAobmV0LmlzSVAoaG9zdCkgPT09IDApIHtcbiAgICAgICAgb3B0aW9ucy5zZXJ2ZXJuYW1lID0gaG9zdFxuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgc2VsZi5zdHJlYW0gPSB0bHMuY29ubmVjdChvcHRpb25zKVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIHJldHVybiBzZWxmLmVtaXQoJ2Vycm9yJywgZXJyKVxuICAgICAgfVxuICAgICAgc2VsZi5hdHRhY2hMaXN0ZW5lcnMoc2VsZi5zdHJlYW0pXG4gICAgICBzZWxmLnN0cmVhbS5vbignZXJyb3InLCByZXBvcnRTdHJlYW1FcnJvcilcblxuICAgICAgc2VsZi5lbWl0KCdzc2xjb25uZWN0JylcbiAgICB9KVxuICB9XG5cbiAgYXR0YWNoTGlzdGVuZXJzKHN0cmVhbSkge1xuICAgIHN0cmVhbS5vbignZW5kJywgKCkgPT4ge1xuICAgICAgdGhpcy5lbWl0KCdlbmQnKVxuICAgIH0pXG4gICAgcGFyc2Uoc3RyZWFtLCAobXNnKSA9PiB7XG4gICAgICB2YXIgZXZlbnROYW1lID0gbXNnLm5hbWUgPT09ICdlcnJvcicgPyAnZXJyb3JNZXNzYWdlJyA6IG1zZy5uYW1lXG4gICAgICBpZiAodGhpcy5fZW1pdE1lc3NhZ2UpIHtcbiAgICAgICAgdGhpcy5lbWl0KCdtZXNzYWdlJywgbXNnKVxuICAgICAgfVxuICAgICAgdGhpcy5lbWl0KGV2ZW50TmFtZSwgbXNnKVxuICAgIH0pXG4gIH1cblxuICByZXF1ZXN0U3NsKCkge1xuICAgIHRoaXMuc3RyZWFtLndyaXRlKHNlcmlhbGl6ZS5yZXF1ZXN0U3NsKCkpXG4gIH1cblxuICBzdGFydHVwKGNvbmZpZykge1xuICAgIHRoaXMuc3RyZWFtLndyaXRlKHNlcmlhbGl6ZS5zdGFydHVwKGNvbmZpZykpXG4gIH1cblxuICBjYW5jZWwocHJvY2Vzc0lELCBzZWNyZXRLZXkpIHtcbiAgICB0aGlzLl9zZW5kKHNlcmlhbGl6ZS5jYW5jZWwocHJvY2Vzc0lELCBzZWNyZXRLZXkpKVxuICB9XG5cbiAgcGFzc3dvcmQocGFzc3dvcmQpIHtcbiAgICB0aGlzLl9zZW5kKHNlcmlhbGl6ZS5wYXNzd29yZChwYXNzd29yZCkpXG4gIH1cblxuICBzZW5kU0FTTEluaXRpYWxSZXNwb25zZU1lc3NhZ2UobWVjaGFuaXNtLCBpbml0aWFsUmVzcG9uc2UpIHtcbiAgICB0aGlzLl9zZW5kKHNlcmlhbGl6ZS5zZW5kU0FTTEluaXRpYWxSZXNwb25zZU1lc3NhZ2UobWVjaGFuaXNtLCBpbml0aWFsUmVzcG9uc2UpKVxuICB9XG5cbiAgc2VuZFNDUkFNQ2xpZW50RmluYWxNZXNzYWdlKGFkZGl0aW9uYWxEYXRhKSB7XG4gICAgdGhpcy5fc2VuZChzZXJpYWxpemUuc2VuZFNDUkFNQ2xpZW50RmluYWxNZXNzYWdlKGFkZGl0aW9uYWxEYXRhKSlcbiAgfVxuXG4gIF9zZW5kKGJ1ZmZlcikge1xuICAgIGlmICghdGhpcy5zdHJlYW0ud3JpdGFibGUpIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgICByZXR1cm4gdGhpcy5zdHJlYW0ud3JpdGUoYnVmZmVyKVxuICB9XG5cbiAgcXVlcnkodGV4dCkge1xuICAgIHRoaXMuX3NlbmQoc2VyaWFsaXplLnF1ZXJ5KHRleHQpKVxuICB9XG5cbiAgLy8gc2VuZCBwYXJzZSBtZXNzYWdlXG4gIHBhcnNlKHF1ZXJ5KSB7XG4gICAgdGhpcy5fc2VuZChzZXJpYWxpemUucGFyc2UocXVlcnkpKVxuICB9XG5cbiAgLy8gc2VuZCBiaW5kIG1lc3NhZ2VcbiAgYmluZChjb25maWcpIHtcbiAgICB0aGlzLl9zZW5kKHNlcmlhbGl6ZS5iaW5kKGNvbmZpZykpXG4gIH1cblxuICAvLyBzZW5kIGV4ZWN1dGUgbWVzc2FnZVxuICBleGVjdXRlKGNvbmZpZykge1xuICAgIHRoaXMuX3NlbmQoc2VyaWFsaXplLmV4ZWN1dGUoY29uZmlnKSlcbiAgfVxuXG4gIGZsdXNoKCkge1xuICAgIGlmICh0aGlzLnN0cmVhbS53cml0YWJsZSkge1xuICAgICAgdGhpcy5zdHJlYW0ud3JpdGUoZmx1c2hCdWZmZXIpXG4gICAgfVxuICB9XG5cbiAgc3luYygpIHtcbiAgICB0aGlzLl9lbmRpbmcgPSB0cnVlXG4gICAgdGhpcy5fc2VuZChmbHVzaEJ1ZmZlcilcbiAgICB0aGlzLl9zZW5kKHN5bmNCdWZmZXIpXG4gIH1cblxuICByZWYoKSB7XG4gICAgdGhpcy5zdHJlYW0ucmVmKClcbiAgfVxuXG4gIHVucmVmKCkge1xuICAgIHRoaXMuc3RyZWFtLnVucmVmKClcbiAgfVxuXG4gIGVuZCgpIHtcbiAgICAvLyAweDU4ID0gJ1gnXG4gICAgdGhpcy5fZW5kaW5nID0gdHJ1ZVxuICAgIGlmICghdGhpcy5fY29ubmVjdGluZyB8fCAhdGhpcy5zdHJlYW0ud3JpdGFibGUpIHtcbiAgICAgIHRoaXMuc3RyZWFtLmVuZCgpXG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuc3RyZWFtLndyaXRlKGVuZEJ1ZmZlciwgKCkgPT4ge1xuICAgICAgdGhpcy5zdHJlYW0uZW5kKClcbiAgICB9KVxuICB9XG5cbiAgY2xvc2UobXNnKSB7XG4gICAgdGhpcy5fc2VuZChzZXJpYWxpemUuY2xvc2UobXNnKSlcbiAgfVxuXG4gIGRlc2NyaWJlKG1zZykge1xuICAgIHRoaXMuX3NlbmQoc2VyaWFsaXplLmRlc2NyaWJlKG1zZykpXG4gIH1cblxuICBzZW5kQ29weUZyb21DaHVuayhjaHVuaykge1xuICAgIHRoaXMuX3NlbmQoc2VyaWFsaXplLmNvcHlEYXRhKGNodW5rKSlcbiAgfVxuXG4gIGVuZENvcHlGcm9tKCkge1xuICAgIHRoaXMuX3NlbmQoc2VyaWFsaXplLmNvcHlEb25lKCkpXG4gIH1cblxuICBzZW5kQ29weUZhaWwobXNnKSB7XG4gICAgdGhpcy5fc2VuZChzZXJpYWxpemUuY29weUZhaWwobXNnKSlcbiAgfVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IENvbm5lY3Rpb25cbiIsIid1c2Ugc3RyaWN0J1xuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgLy8gZGF0YWJhc2UgaG9zdC4gZGVmYXVsdHMgdG8gbG9jYWxob3N0XG4gIGhvc3Q6ICdsb2NhbGhvc3QnLFxuXG4gIC8vIGRhdGFiYXNlIHVzZXIncyBuYW1lXG4gIHVzZXI6IHByb2Nlc3MucGxhdGZvcm0gPT09ICd3aW4zMicgPyBwcm9jZXNzLmVudi5VU0VSTkFNRSA6IHByb2Nlc3MuZW52LlVTRVIsXG5cbiAgLy8gbmFtZSBvZiBkYXRhYmFzZSB0byBjb25uZWN0XG4gIGRhdGFiYXNlOiB1bmRlZmluZWQsXG5cbiAgLy8gZGF0YWJhc2UgdXNlcidzIHBhc3N3b3JkXG4gIHBhc3N3b3JkOiBudWxsLFxuXG4gIC8vIGEgUG9zdGdyZXMgY29ubmVjdGlvbiBzdHJpbmcgdG8gYmUgdXNlZCBpbnN0ZWFkIG9mIHNldHRpbmcgaW5kaXZpZHVhbCBjb25uZWN0aW9uIGl0ZW1zXG4gIC8vIE5PVEU6ICBTZXR0aW5nIHRoaXMgdmFsdWUgd2lsbCBjYXVzZSBpdCB0byBvdmVycmlkZSBhbnkgb3RoZXIgdmFsdWUgKHN1Y2ggYXMgZGF0YWJhc2Ugb3IgdXNlcikgZGVmaW5lZFxuICAvLyBpbiB0aGUgZGVmYXVsdHMgb2JqZWN0LlxuICBjb25uZWN0aW9uU3RyaW5nOiB1bmRlZmluZWQsXG5cbiAgLy8gZGF0YWJhc2UgcG9ydFxuICBwb3J0OiA1NDMyLFxuXG4gIC8vIG51bWJlciBvZiByb3dzIHRvIHJldHVybiBhdCBhIHRpbWUgZnJvbSBhIHByZXBhcmVkIHN0YXRlbWVudCdzXG4gIC8vIHBvcnRhbC4gMCB3aWxsIHJldHVybiBhbGwgcm93cyBhdCBvbmNlXG4gIHJvd3M6IDAsXG5cbiAgLy8gYmluYXJ5IHJlc3VsdCBtb2RlXG4gIGJpbmFyeTogZmFsc2UsXG5cbiAgLy8gQ29ubmVjdGlvbiBwb29sIG9wdGlvbnMgLSBzZWUgaHR0cHM6Ly9naXRodWIuY29tL2JyaWFuYy9ub2RlLXBnLXBvb2xcblxuICAvLyBudW1iZXIgb2YgY29ubmVjdGlvbnMgdG8gdXNlIGluIGNvbm5lY3Rpb24gcG9vbFxuICAvLyAwIHdpbGwgZGlzYWJsZSBjb25uZWN0aW9uIHBvb2xpbmdcbiAgbWF4OiAxMCxcblxuICAvLyBtYXggbWlsbGlzZWNvbmRzIGEgY2xpZW50IGNhbiBnbyB1bnVzZWQgYmVmb3JlIGl0IGlzIHJlbW92ZWRcbiAgLy8gZnJvbSB0aGUgcG9vbCBhbmQgZGVzdHJveWVkXG4gIGlkbGVUaW1lb3V0TWlsbGlzOiAzMDAwMCxcblxuICBjbGllbnRfZW5jb2Rpbmc6ICcnLFxuXG4gIHNzbDogZmFsc2UsXG5cbiAgYXBwbGljYXRpb25fbmFtZTogdW5kZWZpbmVkLFxuXG4gIGZhbGxiYWNrX2FwcGxpY2F0aW9uX25hbWU6IHVuZGVmaW5lZCxcblxuICBvcHRpb25zOiB1bmRlZmluZWQsXG5cbiAgcGFyc2VJbnB1dERhdGVzQXNVVEM6IGZhbHNlLFxuXG4gIC8vIG1heCBtaWxsaXNlY29uZHMgYW55IHF1ZXJ5IHVzaW5nIHRoaXMgY29ubmVjdGlvbiB3aWxsIGV4ZWN1dGUgZm9yIGJlZm9yZSB0aW1pbmcgb3V0IGluIGVycm9yLlxuICAvLyBmYWxzZT11bmxpbWl0ZWRcbiAgc3RhdGVtZW50X3RpbWVvdXQ6IGZhbHNlLFxuXG4gIC8vIFRlcm1pbmF0ZSBhbnkgc2Vzc2lvbiB3aXRoIGFuIG9wZW4gdHJhbnNhY3Rpb24gdGhhdCBoYXMgYmVlbiBpZGxlIGZvciBsb25nZXIgdGhhbiB0aGUgc3BlY2lmaWVkIGR1cmF0aW9uIGluIG1pbGxpc2Vjb25kc1xuICAvLyBmYWxzZT11bmxpbWl0ZWRcbiAgaWRsZV9pbl90cmFuc2FjdGlvbl9zZXNzaW9uX3RpbWVvdXQ6IGZhbHNlLFxuXG4gIC8vIG1heCBtaWxsaXNlY29uZHMgdG8gd2FpdCBmb3IgcXVlcnkgdG8gY29tcGxldGUgKGNsaWVudCBzaWRlKVxuICBxdWVyeV90aW1lb3V0OiBmYWxzZSxcblxuICBjb25uZWN0X3RpbWVvdXQ6IDAsXG5cbiAga2VlcGFsaXZlczogMSxcblxuICBrZWVwYWxpdmVzX2lkbGU6IDAsXG59XG5cbnZhciBwZ1R5cGVzID0gcmVxdWlyZSgncGctdHlwZXMnKVxuLy8gc2F2ZSBkZWZhdWx0IHBhcnNlcnNcbnZhciBwYXJzZUJpZ0ludGVnZXIgPSBwZ1R5cGVzLmdldFR5cGVQYXJzZXIoMjAsICd0ZXh0JylcbnZhciBwYXJzZUJpZ0ludGVnZXJBcnJheSA9IHBnVHlwZXMuZ2V0VHlwZVBhcnNlcigxMDE2LCAndGV4dCcpXG5cbi8vIHBhcnNlIGludDggc28geW91IGNhbiBnZXQgeW91ciBjb3VudCB2YWx1ZXMgYXMgYWN0dWFsIG51bWJlcnNcbm1vZHVsZS5leHBvcnRzLl9fZGVmaW5lU2V0dGVyX18oJ3BhcnNlSW50OCcsIGZ1bmN0aW9uICh2YWwpIHtcbiAgcGdUeXBlcy5zZXRUeXBlUGFyc2VyKDIwLCAndGV4dCcsIHZhbCA/IHBnVHlwZXMuZ2V0VHlwZVBhcnNlcigyMywgJ3RleHQnKSA6IHBhcnNlQmlnSW50ZWdlcilcbiAgcGdUeXBlcy5zZXRUeXBlUGFyc2VyKDEwMTYsICd0ZXh0JywgdmFsID8gcGdUeXBlcy5nZXRUeXBlUGFyc2VyKDEwMDcsICd0ZXh0JykgOiBwYXJzZUJpZ0ludGVnZXJBcnJheSlcbn0pXG4iLCIndXNlIHN0cmljdCdcblxudmFyIENsaWVudCA9IHJlcXVpcmUoJy4vY2xpZW50JylcbnZhciBkZWZhdWx0cyA9IHJlcXVpcmUoJy4vZGVmYXVsdHMnKVxudmFyIENvbm5lY3Rpb24gPSByZXF1aXJlKCcuL2Nvbm5lY3Rpb24nKVxudmFyIFBvb2wgPSByZXF1aXJlKCdwZy1wb29sJylcbmNvbnN0IHsgRGF0YWJhc2VFcnJvciB9ID0gcmVxdWlyZSgncGctcHJvdG9jb2wnKVxuXG5jb25zdCBwb29sRmFjdG9yeSA9IChDbGllbnQpID0+IHtcbiAgcmV0dXJuIGNsYXNzIEJvdW5kUG9vbCBleHRlbmRzIFBvb2wge1xuICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICAgIHN1cGVyKG9wdGlvbnMsIENsaWVudClcbiAgICB9XG4gIH1cbn1cblxudmFyIFBHID0gZnVuY3Rpb24gKGNsaWVudENvbnN0cnVjdG9yKSB7XG4gIHRoaXMuZGVmYXVsdHMgPSBkZWZhdWx0c1xuICB0aGlzLkNsaWVudCA9IGNsaWVudENvbnN0cnVjdG9yXG4gIHRoaXMuUXVlcnkgPSB0aGlzLkNsaWVudC5RdWVyeVxuICB0aGlzLlBvb2wgPSBwb29sRmFjdG9yeSh0aGlzLkNsaWVudClcbiAgdGhpcy5fcG9vbHMgPSBbXVxuICB0aGlzLkNvbm5lY3Rpb24gPSBDb25uZWN0aW9uXG4gIHRoaXMudHlwZXMgPSByZXF1aXJlKCdwZy10eXBlcycpXG4gIHRoaXMuRGF0YWJhc2VFcnJvciA9IERhdGFiYXNlRXJyb3Jcbn1cblxuaWYgKHR5cGVvZiBwcm9jZXNzLmVudi5OT0RFX1BHX0ZPUkNFX05BVElWRSAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgbW9kdWxlLmV4cG9ydHMgPSBuZXcgUEcocmVxdWlyZSgnLi9uYXRpdmUnKSlcbn0gZWxzZSB7XG4gIG1vZHVsZS5leHBvcnRzID0gbmV3IFBHKENsaWVudClcblxuICAvLyBsYXp5IHJlcXVpcmUgbmF0aXZlIG1vZHVsZS4uLnRoZSBuYXRpdmUgbW9kdWxlIG1heSBub3QgaGF2ZSBpbnN0YWxsZWRcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG1vZHVsZS5leHBvcnRzLCAnbmF0aXZlJywge1xuICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICBnZXQoKSB7XG4gICAgICB2YXIgbmF0aXZlID0gbnVsbFxuICAgICAgdHJ5IHtcbiAgICAgICAgbmF0aXZlID0gbmV3IFBHKHJlcXVpcmUoJy4vbmF0aXZlJykpXG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgaWYgKGVyci5jb2RlICE9PSAnTU9EVUxFX05PVF9GT1VORCcpIHtcbiAgICAgICAgICB0aHJvdyBlcnJcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBvdmVyd3JpdGUgbW9kdWxlLmV4cG9ydHMubmF0aXZlIHNvIHRoYXQgZ2V0dGVyIGlzIG5ldmVyIGNhbGxlZCBhZ2FpblxuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG1vZHVsZS5leHBvcnRzLCAnbmF0aXZlJywge1xuICAgICAgICB2YWx1ZTogbmF0aXZlLFxuICAgICAgfSlcblxuICAgICAgcmV0dXJuIG5hdGl2ZVxuICAgIH0sXG4gIH0pXG59XG4iLCIndXNlIHN0cmljdCdcblxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lXG52YXIgTmF0aXZlID0gcmVxdWlyZSgncGctbmF0aXZlJylcbnZhciBUeXBlT3ZlcnJpZGVzID0gcmVxdWlyZSgnLi4vdHlwZS1vdmVycmlkZXMnKVxudmFyIHBrZyA9IHJlcXVpcmUoJy4uLy4uL3BhY2thZ2UuanNvbicpXG52YXIgRXZlbnRFbWl0dGVyID0gcmVxdWlyZSgnZXZlbnRzJykuRXZlbnRFbWl0dGVyXG52YXIgdXRpbCA9IHJlcXVpcmUoJ3V0aWwnKVxudmFyIENvbm5lY3Rpb25QYXJhbWV0ZXJzID0gcmVxdWlyZSgnLi4vY29ubmVjdGlvbi1wYXJhbWV0ZXJzJylcblxudmFyIE5hdGl2ZVF1ZXJ5ID0gcmVxdWlyZSgnLi9xdWVyeScpXG5cbnZhciBDbGllbnQgPSAobW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoY29uZmlnKSB7XG4gIEV2ZW50RW1pdHRlci5jYWxsKHRoaXMpXG4gIGNvbmZpZyA9IGNvbmZpZyB8fCB7fVxuXG4gIHRoaXMuX1Byb21pc2UgPSBjb25maWcuUHJvbWlzZSB8fCBnbG9iYWwuUHJvbWlzZVxuICB0aGlzLl90eXBlcyA9IG5ldyBUeXBlT3ZlcnJpZGVzKGNvbmZpZy50eXBlcylcblxuICB0aGlzLm5hdGl2ZSA9IG5ldyBOYXRpdmUoe1xuICAgIHR5cGVzOiB0aGlzLl90eXBlcyxcbiAgfSlcblxuICB0aGlzLl9xdWVyeVF1ZXVlID0gW11cbiAgdGhpcy5fZW5kaW5nID0gZmFsc2VcbiAgdGhpcy5fY29ubmVjdGluZyA9IGZhbHNlXG4gIHRoaXMuX2Nvbm5lY3RlZCA9IGZhbHNlXG4gIHRoaXMuX3F1ZXJ5YWJsZSA9IHRydWVcblxuICAvLyBrZWVwIHRoZXNlIG9uIHRoZSBvYmplY3QgZm9yIGxlZ2FjeSByZWFzb25zXG4gIC8vIGZvciB0aGUgdGltZSBiZWluZy4gVE9ETzogZGVwcmVjYXRlIGFsbCB0aGlzIGphenpcbiAgdmFyIGNwID0gKHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMgPSBuZXcgQ29ubmVjdGlvblBhcmFtZXRlcnMoY29uZmlnKSlcbiAgdGhpcy51c2VyID0gY3AudXNlclxuXG4gIC8vIFwiaGlkaW5nXCIgdGhlIHBhc3N3b3JkIHNvIGl0IGRvZXNuJ3Qgc2hvdyB1cCBpbiBzdGFjayB0cmFjZXNcbiAgLy8gb3IgaWYgdGhlIGNsaWVudCBpcyBjb25zb2xlLmxvZ2dlZFxuICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgJ3Bhc3N3b3JkJywge1xuICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICB2YWx1ZTogY3AucGFzc3dvcmQsXG4gIH0pXG4gIHRoaXMuZGF0YWJhc2UgPSBjcC5kYXRhYmFzZVxuICB0aGlzLmhvc3QgPSBjcC5ob3N0XG4gIHRoaXMucG9ydCA9IGNwLnBvcnRcblxuICAvLyBhIGhhc2ggdG8gaG9sZCBuYW1lZCBxdWVyaWVzXG4gIHRoaXMubmFtZWRRdWVyaWVzID0ge31cbn0pXG5cbkNsaWVudC5RdWVyeSA9IE5hdGl2ZVF1ZXJ5XG5cbnV0aWwuaW5oZXJpdHMoQ2xpZW50LCBFdmVudEVtaXR0ZXIpXG5cbkNsaWVudC5wcm90b3R5cGUuX2Vycm9yQWxsUXVlcmllcyA9IGZ1bmN0aW9uIChlcnIpIHtcbiAgY29uc3QgZW5xdWV1ZUVycm9yID0gKHF1ZXJ5KSA9PiB7XG4gICAgcHJvY2Vzcy5uZXh0VGljaygoKSA9PiB7XG4gICAgICBxdWVyeS5uYXRpdmUgPSB0aGlzLm5hdGl2ZVxuICAgICAgcXVlcnkuaGFuZGxlRXJyb3IoZXJyKVxuICAgIH0pXG4gIH1cblxuICBpZiAodGhpcy5faGFzQWN0aXZlUXVlcnkoKSkge1xuICAgIGVucXVldWVFcnJvcih0aGlzLl9hY3RpdmVRdWVyeSlcbiAgICB0aGlzLl9hY3RpdmVRdWVyeSA9IG51bGxcbiAgfVxuXG4gIHRoaXMuX3F1ZXJ5UXVldWUuZm9yRWFjaChlbnF1ZXVlRXJyb3IpXG4gIHRoaXMuX3F1ZXJ5UXVldWUubGVuZ3RoID0gMFxufVxuXG4vLyBjb25uZWN0IHRvIHRoZSBiYWNrZW5kXG4vLyBwYXNzIGFuIG9wdGlvbmFsIGNhbGxiYWNrIHRvIGJlIGNhbGxlZCBvbmNlIGNvbm5lY3RlZFxuLy8gb3Igd2l0aCBhbiBlcnJvciBpZiB0aGVyZSB3YXMgYSBjb25uZWN0aW9uIGVycm9yXG5DbGllbnQucHJvdG90eXBlLl9jb25uZWN0ID0gZnVuY3Rpb24gKGNiKSB7XG4gIHZhciBzZWxmID0gdGhpc1xuXG4gIGlmICh0aGlzLl9jb25uZWN0aW5nKSB7XG4gICAgcHJvY2Vzcy5uZXh0VGljaygoKSA9PiBjYihuZXcgRXJyb3IoJ0NsaWVudCBoYXMgYWxyZWFkeSBiZWVuIGNvbm5lY3RlZC4gWW91IGNhbm5vdCByZXVzZSBhIGNsaWVudC4nKSkpXG4gICAgcmV0dXJuXG4gIH1cblxuICB0aGlzLl9jb25uZWN0aW5nID0gdHJ1ZVxuXG4gIHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMuZ2V0TGlicHFDb25uZWN0aW9uU3RyaW5nKGZ1bmN0aW9uIChlcnIsIGNvblN0cmluZykge1xuICAgIGlmIChlcnIpIHJldHVybiBjYihlcnIpXG4gICAgc2VsZi5uYXRpdmUuY29ubmVjdChjb25TdHJpbmcsIGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgc2VsZi5uYXRpdmUuZW5kKClcbiAgICAgICAgcmV0dXJuIGNiKGVycilcbiAgICAgIH1cblxuICAgICAgLy8gc2V0IGludGVybmFsIHN0YXRlcyB0byBjb25uZWN0ZWRcbiAgICAgIHNlbGYuX2Nvbm5lY3RlZCA9IHRydWVcblxuICAgICAgLy8gaGFuZGxlIGNvbm5lY3Rpb24gZXJyb3JzIGZyb20gdGhlIG5hdGl2ZSBsYXllclxuICAgICAgc2VsZi5uYXRpdmUub24oJ2Vycm9yJywgZnVuY3Rpb24gKGVycikge1xuICAgICAgICBzZWxmLl9xdWVyeWFibGUgPSBmYWxzZVxuICAgICAgICBzZWxmLl9lcnJvckFsbFF1ZXJpZXMoZXJyKVxuICAgICAgICBzZWxmLmVtaXQoJ2Vycm9yJywgZXJyKVxuICAgICAgfSlcblxuICAgICAgc2VsZi5uYXRpdmUub24oJ25vdGlmaWNhdGlvbicsIGZ1bmN0aW9uIChtc2cpIHtcbiAgICAgICAgc2VsZi5lbWl0KCdub3RpZmljYXRpb24nLCB7XG4gICAgICAgICAgY2hhbm5lbDogbXNnLnJlbG5hbWUsXG4gICAgICAgICAgcGF5bG9hZDogbXNnLmV4dHJhLFxuICAgICAgICB9KVxuICAgICAgfSlcblxuICAgICAgLy8gc2lnbmFsIHdlIGFyZSBjb25uZWN0ZWQgbm93XG4gICAgICBzZWxmLmVtaXQoJ2Nvbm5lY3QnKVxuICAgICAgc2VsZi5fcHVsc2VRdWVyeVF1ZXVlKHRydWUpXG5cbiAgICAgIGNiKClcbiAgICB9KVxuICB9KVxufVxuXG5DbGllbnQucHJvdG90eXBlLmNvbm5lY3QgPSBmdW5jdGlvbiAoY2FsbGJhY2spIHtcbiAgaWYgKGNhbGxiYWNrKSB7XG4gICAgdGhpcy5fY29ubmVjdChjYWxsYmFjaylcbiAgICByZXR1cm5cbiAgfVxuXG4gIHJldHVybiBuZXcgdGhpcy5fUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgdGhpcy5fY29ubmVjdCgoZXJyb3IpID0+IHtcbiAgICAgIGlmIChlcnJvcikge1xuICAgICAgICByZWplY3QoZXJyb3IpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXNvbHZlKClcbiAgICAgIH1cbiAgICB9KVxuICB9KVxufVxuXG4vLyBzZW5kIGEgcXVlcnkgdG8gdGhlIHNlcnZlclxuLy8gdGhpcyBtZXRob2QgaXMgaGlnaGx5IG92ZXJsb2FkZWQgdG8gdGFrZVxuLy8gMSkgc3RyaW5nIHF1ZXJ5LCBvcHRpb25hbCBhcnJheSBvZiBwYXJhbWV0ZXJzLCBvcHRpb25hbCBmdW5jdGlvbiBjYWxsYmFja1xuLy8gMikgb2JqZWN0IHF1ZXJ5IHdpdGgge1xuLy8gICAgc3RyaW5nIHF1ZXJ5XG4vLyAgICBvcHRpb25hbCBhcnJheSB2YWx1ZXMsXG4vLyAgICBvcHRpb25hbCBmdW5jdGlvbiBjYWxsYmFjayBpbnN0ZWFkIG9mIGFzIGEgc2VwYXJhdGUgcGFyYW1ldGVyXG4vLyAgICBvcHRpb25hbCBzdHJpbmcgbmFtZSB0byBuYW1lICYgY2FjaGUgdGhlIHF1ZXJ5IHBsYW5cbi8vICAgIG9wdGlvbmFsIHN0cmluZyByb3dNb2RlID0gJ2FycmF5JyBmb3IgYW4gYXJyYXkgb2YgcmVzdWx0c1xuLy8gIH1cbkNsaWVudC5wcm90b3R5cGUucXVlcnkgPSBmdW5jdGlvbiAoY29uZmlnLCB2YWx1ZXMsIGNhbGxiYWNrKSB7XG4gIHZhciBxdWVyeVxuICB2YXIgcmVzdWx0XG4gIHZhciByZWFkVGltZW91dFxuICB2YXIgcmVhZFRpbWVvdXRUaW1lclxuICB2YXIgcXVlcnlDYWxsYmFja1xuXG4gIGlmIChjb25maWcgPT09IG51bGwgfHwgY29uZmlnID09PSB1bmRlZmluZWQpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdDbGllbnQgd2FzIHBhc3NlZCBhIG51bGwgb3IgdW5kZWZpbmVkIHF1ZXJ5JylcbiAgfSBlbHNlIGlmICh0eXBlb2YgY29uZmlnLnN1Ym1pdCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIHJlYWRUaW1lb3V0ID0gY29uZmlnLnF1ZXJ5X3RpbWVvdXQgfHwgdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy5xdWVyeV90aW1lb3V0XG4gICAgcmVzdWx0ID0gcXVlcnkgPSBjb25maWdcbiAgICAvLyBhY2NlcHQgcXVlcnkobmV3IFF1ZXJ5KC4uLiksIChlcnIsIHJlcykgPT4geyB9KSBzdHlsZVxuICAgIGlmICh0eXBlb2YgdmFsdWVzID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICBjb25maWcuY2FsbGJhY2sgPSB2YWx1ZXNcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgcmVhZFRpbWVvdXQgPSB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLnF1ZXJ5X3RpbWVvdXRcbiAgICBxdWVyeSA9IG5ldyBOYXRpdmVRdWVyeShjb25maWcsIHZhbHVlcywgY2FsbGJhY2spXG4gICAgaWYgKCFxdWVyeS5jYWxsYmFjaykge1xuICAgICAgbGV0IHJlc29sdmVPdXQsIHJlamVjdE91dFxuICAgICAgcmVzdWx0ID0gbmV3IHRoaXMuX1Byb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICByZXNvbHZlT3V0ID0gcmVzb2x2ZVxuICAgICAgICByZWplY3RPdXQgPSByZWplY3RcbiAgICAgIH0pXG4gICAgICBxdWVyeS5jYWxsYmFjayA9IChlcnIsIHJlcykgPT4gKGVyciA/IHJlamVjdE91dChlcnIpIDogcmVzb2x2ZU91dChyZXMpKVxuICAgIH1cbiAgfVxuXG4gIGlmIChyZWFkVGltZW91dCkge1xuICAgIHF1ZXJ5Q2FsbGJhY2sgPSBxdWVyeS5jYWxsYmFja1xuXG4gICAgcmVhZFRpbWVvdXRUaW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdmFyIGVycm9yID0gbmV3IEVycm9yKCdRdWVyeSByZWFkIHRpbWVvdXQnKVxuXG4gICAgICBwcm9jZXNzLm5leHRUaWNrKCgpID0+IHtcbiAgICAgICAgcXVlcnkuaGFuZGxlRXJyb3IoZXJyb3IsIHRoaXMuY29ubmVjdGlvbilcbiAgICAgIH0pXG5cbiAgICAgIHF1ZXJ5Q2FsbGJhY2soZXJyb3IpXG5cbiAgICAgIC8vIHdlIGFscmVhZHkgcmV0dXJuZWQgYW4gZXJyb3IsXG4gICAgICAvLyBqdXN0IGRvIG5vdGhpbmcgaWYgcXVlcnkgY29tcGxldGVzXG4gICAgICBxdWVyeS5jYWxsYmFjayA9ICgpID0+IHt9XG5cbiAgICAgIC8vIFJlbW92ZSBmcm9tIHF1ZXVlXG4gICAgICB2YXIgaW5kZXggPSB0aGlzLl9xdWVyeVF1ZXVlLmluZGV4T2YocXVlcnkpXG4gICAgICBpZiAoaW5kZXggPiAtMSkge1xuICAgICAgICB0aGlzLl9xdWVyeVF1ZXVlLnNwbGljZShpbmRleCwgMSlcbiAgICAgIH1cblxuICAgICAgdGhpcy5fcHVsc2VRdWVyeVF1ZXVlKClcbiAgICB9LCByZWFkVGltZW91dClcblxuICAgIHF1ZXJ5LmNhbGxiYWNrID0gKGVyciwgcmVzKSA9PiB7XG4gICAgICBjbGVhclRpbWVvdXQocmVhZFRpbWVvdXRUaW1lcilcbiAgICAgIHF1ZXJ5Q2FsbGJhY2soZXJyLCByZXMpXG4gICAgfVxuICB9XG5cbiAgaWYgKCF0aGlzLl9xdWVyeWFibGUpIHtcbiAgICBxdWVyeS5uYXRpdmUgPSB0aGlzLm5hdGl2ZVxuICAgIHByb2Nlc3MubmV4dFRpY2soKCkgPT4ge1xuICAgICAgcXVlcnkuaGFuZGxlRXJyb3IobmV3IEVycm9yKCdDbGllbnQgaGFzIGVuY291bnRlcmVkIGEgY29ubmVjdGlvbiBlcnJvciBhbmQgaXMgbm90IHF1ZXJ5YWJsZScpKVxuICAgIH0pXG4gICAgcmV0dXJuIHJlc3VsdFxuICB9XG5cbiAgaWYgKHRoaXMuX2VuZGluZykge1xuICAgIHF1ZXJ5Lm5hdGl2ZSA9IHRoaXMubmF0aXZlXG4gICAgcHJvY2Vzcy5uZXh0VGljaygoKSA9PiB7XG4gICAgICBxdWVyeS5oYW5kbGVFcnJvcihuZXcgRXJyb3IoJ0NsaWVudCB3YXMgY2xvc2VkIGFuZCBpcyBub3QgcXVlcnlhYmxlJykpXG4gICAgfSlcbiAgICByZXR1cm4gcmVzdWx0XG4gIH1cblxuICB0aGlzLl9xdWVyeVF1ZXVlLnB1c2gocXVlcnkpXG4gIHRoaXMuX3B1bHNlUXVlcnlRdWV1ZSgpXG4gIHJldHVybiByZXN1bHRcbn1cblxuLy8gZGlzY29ubmVjdCBmcm9tIHRoZSBiYWNrZW5kIHNlcnZlclxuQ2xpZW50LnByb3RvdHlwZS5lbmQgPSBmdW5jdGlvbiAoY2IpIHtcbiAgdmFyIHNlbGYgPSB0aGlzXG5cbiAgdGhpcy5fZW5kaW5nID0gdHJ1ZVxuXG4gIGlmICghdGhpcy5fY29ubmVjdGVkKSB7XG4gICAgdGhpcy5vbmNlKCdjb25uZWN0JywgdGhpcy5lbmQuYmluZCh0aGlzLCBjYikpXG4gIH1cbiAgdmFyIHJlc3VsdFxuICBpZiAoIWNiKSB7XG4gICAgcmVzdWx0ID0gbmV3IHRoaXMuX1Byb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgY2IgPSAoZXJyKSA9PiAoZXJyID8gcmVqZWN0KGVycikgOiByZXNvbHZlKCkpXG4gICAgfSlcbiAgfVxuICB0aGlzLm5hdGl2ZS5lbmQoZnVuY3Rpb24gKCkge1xuICAgIHNlbGYuX2Vycm9yQWxsUXVlcmllcyhuZXcgRXJyb3IoJ0Nvbm5lY3Rpb24gdGVybWluYXRlZCcpKVxuXG4gICAgcHJvY2Vzcy5uZXh0VGljaygoKSA9PiB7XG4gICAgICBzZWxmLmVtaXQoJ2VuZCcpXG4gICAgICBpZiAoY2IpIGNiKClcbiAgICB9KVxuICB9KVxuICByZXR1cm4gcmVzdWx0XG59XG5cbkNsaWVudC5wcm90b3R5cGUuX2hhc0FjdGl2ZVF1ZXJ5ID0gZnVuY3Rpb24gKCkge1xuICByZXR1cm4gdGhpcy5fYWN0aXZlUXVlcnkgJiYgdGhpcy5fYWN0aXZlUXVlcnkuc3RhdGUgIT09ICdlcnJvcicgJiYgdGhpcy5fYWN0aXZlUXVlcnkuc3RhdGUgIT09ICdlbmQnXG59XG5cbkNsaWVudC5wcm90b3R5cGUuX3B1bHNlUXVlcnlRdWV1ZSA9IGZ1bmN0aW9uIChpbml0aWFsQ29ubmVjdGlvbikge1xuICBpZiAoIXRoaXMuX2Nvbm5lY3RlZCkge1xuICAgIHJldHVyblxuICB9XG4gIGlmICh0aGlzLl9oYXNBY3RpdmVRdWVyeSgpKSB7XG4gICAgcmV0dXJuXG4gIH1cbiAgdmFyIHF1ZXJ5ID0gdGhpcy5fcXVlcnlRdWV1ZS5zaGlmdCgpXG4gIGlmICghcXVlcnkpIHtcbiAgICBpZiAoIWluaXRpYWxDb25uZWN0aW9uKSB7XG4gICAgICB0aGlzLmVtaXQoJ2RyYWluJylcbiAgICB9XG4gICAgcmV0dXJuXG4gIH1cbiAgdGhpcy5fYWN0aXZlUXVlcnkgPSBxdWVyeVxuICBxdWVyeS5zdWJtaXQodGhpcylcbiAgdmFyIHNlbGYgPSB0aGlzXG4gIHF1ZXJ5Lm9uY2UoJ19kb25lJywgZnVuY3Rpb24gKCkge1xuICAgIHNlbGYuX3B1bHNlUXVlcnlRdWV1ZSgpXG4gIH0pXG59XG5cbi8vIGF0dGVtcHQgdG8gY2FuY2VsIGFuIGluLXByb2dyZXNzIHF1ZXJ5XG5DbGllbnQucHJvdG90eXBlLmNhbmNlbCA9IGZ1bmN0aW9uIChxdWVyeSkge1xuICBpZiAodGhpcy5fYWN0aXZlUXVlcnkgPT09IHF1ZXJ5KSB7XG4gICAgdGhpcy5uYXRpdmUuY2FuY2VsKGZ1bmN0aW9uICgpIHt9KVxuICB9IGVsc2UgaWYgKHRoaXMuX3F1ZXJ5UXVldWUuaW5kZXhPZihxdWVyeSkgIT09IC0xKSB7XG4gICAgdGhpcy5fcXVlcnlRdWV1ZS5zcGxpY2UodGhpcy5fcXVlcnlRdWV1ZS5pbmRleE9mKHF1ZXJ5KSwgMSlcbiAgfVxufVxuXG5DbGllbnQucHJvdG90eXBlLnJlZiA9IGZ1bmN0aW9uICgpIHt9XG5DbGllbnQucHJvdG90eXBlLnVucmVmID0gZnVuY3Rpb24gKCkge31cblxuQ2xpZW50LnByb3RvdHlwZS5zZXRUeXBlUGFyc2VyID0gZnVuY3Rpb24gKG9pZCwgZm9ybWF0LCBwYXJzZUZuKSB7XG4gIHJldHVybiB0aGlzLl90eXBlcy5zZXRUeXBlUGFyc2VyKG9pZCwgZm9ybWF0LCBwYXJzZUZuKVxufVxuXG5DbGllbnQucHJvdG90eXBlLmdldFR5cGVQYXJzZXIgPSBmdW5jdGlvbiAob2lkLCBmb3JtYXQpIHtcbiAgcmV0dXJuIHRoaXMuX3R5cGVzLmdldFR5cGVQYXJzZXIob2lkLCBmb3JtYXQpXG59XG4iLCIndXNlIHN0cmljdCdcbm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9jbGllbnQnKVxuIiwiJ3VzZSBzdHJpY3QnXG5cbnZhciBFdmVudEVtaXR0ZXIgPSByZXF1aXJlKCdldmVudHMnKS5FdmVudEVtaXR0ZXJcbnZhciB1dGlsID0gcmVxdWlyZSgndXRpbCcpXG52YXIgdXRpbHMgPSByZXF1aXJlKCcuLi91dGlscycpXG5cbnZhciBOYXRpdmVRdWVyeSA9IChtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChjb25maWcsIHZhbHVlcywgY2FsbGJhY2spIHtcbiAgRXZlbnRFbWl0dGVyLmNhbGwodGhpcylcbiAgY29uZmlnID0gdXRpbHMubm9ybWFsaXplUXVlcnlDb25maWcoY29uZmlnLCB2YWx1ZXMsIGNhbGxiYWNrKVxuICB0aGlzLnRleHQgPSBjb25maWcudGV4dFxuICB0aGlzLnZhbHVlcyA9IGNvbmZpZy52YWx1ZXNcbiAgdGhpcy5uYW1lID0gY29uZmlnLm5hbWVcbiAgdGhpcy5jYWxsYmFjayA9IGNvbmZpZy5jYWxsYmFja1xuICB0aGlzLnN0YXRlID0gJ25ldydcbiAgdGhpcy5fYXJyYXlNb2RlID0gY29uZmlnLnJvd01vZGUgPT09ICdhcnJheSdcblxuICAvLyBpZiB0aGUgJ3JvdycgZXZlbnQgaXMgbGlzdGVuZWQgZm9yXG4gIC8vIHRoZW4gZW1pdCB0aGVtIGFzIHRoZXkgY29tZSBpblxuICAvLyB3aXRob3V0IHNldHRpbmcgc2luZ2xlUm93TW9kZSB0byB0cnVlXG4gIC8vIHRoaXMgaGFzIGFsbW9zdCBubyBtZWFuaW5nIGJlY2F1c2UgbGlicHFcbiAgLy8gcmVhZHMgYWxsIHJvd3MgaW50byBtZW1vcnkgYmVmb3IgcmV0dXJuaW5nIGFueVxuICB0aGlzLl9lbWl0Um93RXZlbnRzID0gZmFsc2VcbiAgdGhpcy5vbihcbiAgICAnbmV3TGlzdGVuZXInLFxuICAgIGZ1bmN0aW9uIChldmVudCkge1xuICAgICAgaWYgKGV2ZW50ID09PSAncm93JykgdGhpcy5fZW1pdFJvd0V2ZW50cyA9IHRydWVcbiAgICB9LmJpbmQodGhpcylcbiAgKVxufSlcblxudXRpbC5pbmhlcml0cyhOYXRpdmVRdWVyeSwgRXZlbnRFbWl0dGVyKVxuXG52YXIgZXJyb3JGaWVsZE1hcCA9IHtcbiAgLyogZXNsaW50LWRpc2FibGUgcXVvdGUtcHJvcHMgKi9cbiAgc3FsU3RhdGU6ICdjb2RlJyxcbiAgc3RhdGVtZW50UG9zaXRpb246ICdwb3NpdGlvbicsXG4gIG1lc3NhZ2VQcmltYXJ5OiAnbWVzc2FnZScsXG4gIGNvbnRleHQ6ICd3aGVyZScsXG4gIHNjaGVtYU5hbWU6ICdzY2hlbWEnLFxuICB0YWJsZU5hbWU6ICd0YWJsZScsXG4gIGNvbHVtbk5hbWU6ICdjb2x1bW4nLFxuICBkYXRhVHlwZU5hbWU6ICdkYXRhVHlwZScsXG4gIGNvbnN0cmFpbnROYW1lOiAnY29uc3RyYWludCcsXG4gIHNvdXJjZUZpbGU6ICdmaWxlJyxcbiAgc291cmNlTGluZTogJ2xpbmUnLFxuICBzb3VyY2VGdW5jdGlvbjogJ3JvdXRpbmUnLFxufVxuXG5OYXRpdmVRdWVyeS5wcm90b3R5cGUuaGFuZGxlRXJyb3IgPSBmdW5jdGlvbiAoZXJyKSB7XG4gIC8vIGNvcHkgcHEgZXJyb3IgZmllbGRzIGludG8gdGhlIGVycm9yIG9iamVjdFxuICB2YXIgZmllbGRzID0gdGhpcy5uYXRpdmUucHEucmVzdWx0RXJyb3JGaWVsZHMoKVxuICBpZiAoZmllbGRzKSB7XG4gICAgZm9yICh2YXIga2V5IGluIGZpZWxkcykge1xuICAgICAgdmFyIG5vcm1hbGl6ZWRGaWVsZE5hbWUgPSBlcnJvckZpZWxkTWFwW2tleV0gfHwga2V5XG4gICAgICBlcnJbbm9ybWFsaXplZEZpZWxkTmFtZV0gPSBmaWVsZHNba2V5XVxuICAgIH1cbiAgfVxuICBpZiAodGhpcy5jYWxsYmFjaykge1xuICAgIHRoaXMuY2FsbGJhY2soZXJyKVxuICB9IGVsc2Uge1xuICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpXG4gIH1cbiAgdGhpcy5zdGF0ZSA9ICdlcnJvcidcbn1cblxuTmF0aXZlUXVlcnkucHJvdG90eXBlLnRoZW4gPSBmdW5jdGlvbiAob25TdWNjZXNzLCBvbkZhaWx1cmUpIHtcbiAgcmV0dXJuIHRoaXMuX2dldFByb21pc2UoKS50aGVuKG9uU3VjY2Vzcywgb25GYWlsdXJlKVxufVxuXG5OYXRpdmVRdWVyeS5wcm90b3R5cGUuY2F0Y2ggPSBmdW5jdGlvbiAoY2FsbGJhY2spIHtcbiAgcmV0dXJuIHRoaXMuX2dldFByb21pc2UoKS5jYXRjaChjYWxsYmFjaylcbn1cblxuTmF0aXZlUXVlcnkucHJvdG90eXBlLl9nZXRQcm9taXNlID0gZnVuY3Rpb24gKCkge1xuICBpZiAodGhpcy5fcHJvbWlzZSkgcmV0dXJuIHRoaXMuX3Byb21pc2VcbiAgdGhpcy5fcHJvbWlzZSA9IG5ldyBQcm9taXNlKFxuICAgIGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgIHRoaXMuX29uY2UoJ2VuZCcsIHJlc29sdmUpXG4gICAgICB0aGlzLl9vbmNlKCdlcnJvcicsIHJlamVjdClcbiAgICB9LmJpbmQodGhpcylcbiAgKVxuICByZXR1cm4gdGhpcy5fcHJvbWlzZVxufVxuXG5OYXRpdmVRdWVyeS5wcm90b3R5cGUuc3VibWl0ID0gZnVuY3Rpb24gKGNsaWVudCkge1xuICB0aGlzLnN0YXRlID0gJ3J1bm5pbmcnXG4gIHZhciBzZWxmID0gdGhpc1xuICB0aGlzLm5hdGl2ZSA9IGNsaWVudC5uYXRpdmVcbiAgY2xpZW50Lm5hdGl2ZS5hcnJheU1vZGUgPSB0aGlzLl9hcnJheU1vZGVcblxuICB2YXIgYWZ0ZXIgPSBmdW5jdGlvbiAoZXJyLCByb3dzLCByZXN1bHRzKSB7XG4gICAgY2xpZW50Lm5hdGl2ZS5hcnJheU1vZGUgPSBmYWxzZVxuICAgIHNldEltbWVkaWF0ZShmdW5jdGlvbiAoKSB7XG4gICAgICBzZWxmLmVtaXQoJ19kb25lJylcbiAgICB9KVxuXG4gICAgLy8gaGFuZGxlIHBvc3NpYmxlIHF1ZXJ5IGVycm9yXG4gICAgaWYgKGVycikge1xuICAgICAgcmV0dXJuIHNlbGYuaGFuZGxlRXJyb3IoZXJyKVxuICAgIH1cblxuICAgIC8vIGVtaXQgcm93IGV2ZW50cyBmb3IgZWFjaCByb3cgaW4gdGhlIHJlc3VsdFxuICAgIGlmIChzZWxmLl9lbWl0Um93RXZlbnRzKSB7XG4gICAgICBpZiAocmVzdWx0cy5sZW5ndGggPiAxKSB7XG4gICAgICAgIHJvd3MuZm9yRWFjaCgocm93T2ZSb3dzLCBpKSA9PiB7XG4gICAgICAgICAgcm93T2ZSb3dzLmZvckVhY2goKHJvdykgPT4ge1xuICAgICAgICAgICAgc2VsZi5lbWl0KCdyb3cnLCByb3csIHJlc3VsdHNbaV0pXG4gICAgICAgICAgfSlcbiAgICAgICAgfSlcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJvd3MuZm9yRWFjaChmdW5jdGlvbiAocm93KSB7XG4gICAgICAgICAgc2VsZi5lbWl0KCdyb3cnLCByb3csIHJlc3VsdHMpXG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gaGFuZGxlIHN1Y2Nlc3NmdWwgcmVzdWx0XG4gICAgc2VsZi5zdGF0ZSA9ICdlbmQnXG4gICAgc2VsZi5lbWl0KCdlbmQnLCByZXN1bHRzKVxuICAgIGlmIChzZWxmLmNhbGxiYWNrKSB7XG4gICAgICBzZWxmLmNhbGxiYWNrKG51bGwsIHJlc3VsdHMpXG4gICAgfVxuICB9XG5cbiAgaWYgKHByb2Nlc3MuZG9tYWluKSB7XG4gICAgYWZ0ZXIgPSBwcm9jZXNzLmRvbWFpbi5iaW5kKGFmdGVyKVxuICB9XG5cbiAgLy8gbmFtZWQgcXVlcnlcbiAgaWYgKHRoaXMubmFtZSkge1xuICAgIGlmICh0aGlzLm5hbWUubGVuZ3RoID4gNjMpIHtcbiAgICAgIC8qIGVzbGludC1kaXNhYmxlIG5vLWNvbnNvbGUgKi9cbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1dhcm5pbmchIFBvc3RncmVzIG9ubHkgc3VwcG9ydHMgNjMgY2hhcmFjdGVycyBmb3IgcXVlcnkgbmFtZXMuJylcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1lvdSBzdXBwbGllZCAlcyAoJXMpJywgdGhpcy5uYW1lLCB0aGlzLm5hbWUubGVuZ3RoKVxuICAgICAgY29uc29sZS5lcnJvcignVGhpcyBjYW4gY2F1c2UgY29uZmxpY3RzIGFuZCBzaWxlbnQgZXJyb3JzIGV4ZWN1dGluZyBxdWVyaWVzJylcbiAgICAgIC8qIGVzbGludC1lbmFibGUgbm8tY29uc29sZSAqL1xuICAgIH1cbiAgICB2YXIgdmFsdWVzID0gKHRoaXMudmFsdWVzIHx8IFtdKS5tYXAodXRpbHMucHJlcGFyZVZhbHVlKVxuXG4gICAgLy8gY2hlY2sgaWYgdGhlIGNsaWVudCBoYXMgYWxyZWFkeSBleGVjdXRlZCB0aGlzIG5hbWVkIHF1ZXJ5XG4gICAgLy8gaWYgc28uLi5qdXN0IGV4ZWN1dGUgaXQgYWdhaW4gLSBza2lwIHRoZSBwbGFubmluZyBwaGFzZVxuICAgIGlmIChjbGllbnQubmFtZWRRdWVyaWVzW3RoaXMubmFtZV0pIHtcbiAgICAgIGlmICh0aGlzLnRleHQgJiYgY2xpZW50Lm5hbWVkUXVlcmllc1t0aGlzLm5hbWVdICE9PSB0aGlzLnRleHQpIHtcbiAgICAgICAgY29uc3QgZXJyID0gbmV3IEVycm9yKGBQcmVwYXJlZCBzdGF0ZW1lbnRzIG11c3QgYmUgdW5pcXVlIC0gJyR7dGhpcy5uYW1lfScgd2FzIHVzZWQgZm9yIGEgZGlmZmVyZW50IHN0YXRlbWVudGApXG4gICAgICAgIHJldHVybiBhZnRlcihlcnIpXG4gICAgICB9XG4gICAgICByZXR1cm4gY2xpZW50Lm5hdGl2ZS5leGVjdXRlKHRoaXMubmFtZSwgdmFsdWVzLCBhZnRlcilcbiAgICB9XG4gICAgLy8gcGxhbiB0aGUgbmFtZWQgcXVlcnkgdGhlIGZpcnN0IHRpbWUsIHRoZW4gZXhlY3V0ZSBpdFxuICAgIHJldHVybiBjbGllbnQubmF0aXZlLnByZXBhcmUodGhpcy5uYW1lLCB0aGlzLnRleHQsIHZhbHVlcy5sZW5ndGgsIGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgIGlmIChlcnIpIHJldHVybiBhZnRlcihlcnIpXG4gICAgICBjbGllbnQubmFtZWRRdWVyaWVzW3NlbGYubmFtZV0gPSBzZWxmLnRleHRcbiAgICAgIHJldHVybiBzZWxmLm5hdGl2ZS5leGVjdXRlKHNlbGYubmFtZSwgdmFsdWVzLCBhZnRlcilcbiAgICB9KVxuICB9IGVsc2UgaWYgKHRoaXMudmFsdWVzKSB7XG4gICAgaWYgKCFBcnJheS5pc0FycmF5KHRoaXMudmFsdWVzKSkge1xuICAgICAgY29uc3QgZXJyID0gbmV3IEVycm9yKCdRdWVyeSB2YWx1ZXMgbXVzdCBiZSBhbiBhcnJheScpXG4gICAgICByZXR1cm4gYWZ0ZXIoZXJyKVxuICAgIH1cbiAgICB2YXIgdmFscyA9IHRoaXMudmFsdWVzLm1hcCh1dGlscy5wcmVwYXJlVmFsdWUpXG4gICAgY2xpZW50Lm5hdGl2ZS5xdWVyeSh0aGlzLnRleHQsIHZhbHMsIGFmdGVyKVxuICB9IGVsc2Uge1xuICAgIGNsaWVudC5uYXRpdmUucXVlcnkodGhpcy50ZXh0LCBhZnRlcilcbiAgfVxufVxuIiwiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IHsgRXZlbnRFbWl0dGVyIH0gPSByZXF1aXJlKCdldmVudHMnKVxuXG5jb25zdCBSZXN1bHQgPSByZXF1aXJlKCcuL3Jlc3VsdCcpXG5jb25zdCB1dGlscyA9IHJlcXVpcmUoJy4vdXRpbHMnKVxuXG5jbGFzcyBRdWVyeSBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIGNvbnN0cnVjdG9yKGNvbmZpZywgdmFsdWVzLCBjYWxsYmFjaykge1xuICAgIHN1cGVyKClcblxuICAgIGNvbmZpZyA9IHV0aWxzLm5vcm1hbGl6ZVF1ZXJ5Q29uZmlnKGNvbmZpZywgdmFsdWVzLCBjYWxsYmFjaylcblxuICAgIHRoaXMudGV4dCA9IGNvbmZpZy50ZXh0XG4gICAgdGhpcy52YWx1ZXMgPSBjb25maWcudmFsdWVzXG4gICAgdGhpcy5yb3dzID0gY29uZmlnLnJvd3NcbiAgICB0aGlzLnR5cGVzID0gY29uZmlnLnR5cGVzXG4gICAgdGhpcy5uYW1lID0gY29uZmlnLm5hbWVcbiAgICB0aGlzLmJpbmFyeSA9IGNvbmZpZy5iaW5hcnlcbiAgICAvLyB1c2UgdW5pcXVlIHBvcnRhbCBuYW1lIGVhY2ggdGltZVxuICAgIHRoaXMucG9ydGFsID0gY29uZmlnLnBvcnRhbCB8fCAnJ1xuICAgIHRoaXMuY2FsbGJhY2sgPSBjb25maWcuY2FsbGJhY2tcbiAgICB0aGlzLl9yb3dNb2RlID0gY29uZmlnLnJvd01vZGVcbiAgICBpZiAocHJvY2Vzcy5kb21haW4gJiYgY29uZmlnLmNhbGxiYWNrKSB7XG4gICAgICB0aGlzLmNhbGxiYWNrID0gcHJvY2Vzcy5kb21haW4uYmluZChjb25maWcuY2FsbGJhY2spXG4gICAgfVxuICAgIHRoaXMuX3Jlc3VsdCA9IG5ldyBSZXN1bHQodGhpcy5fcm93TW9kZSwgdGhpcy50eXBlcylcblxuICAgIC8vIHBvdGVudGlhbCBmb3IgbXVsdGlwbGUgcmVzdWx0c1xuICAgIHRoaXMuX3Jlc3VsdHMgPSB0aGlzLl9yZXN1bHRcbiAgICB0aGlzLmlzUHJlcGFyZWRTdGF0ZW1lbnQgPSBmYWxzZVxuICAgIHRoaXMuX2NhbmNlbGVkRHVlVG9FcnJvciA9IGZhbHNlXG4gICAgdGhpcy5fcHJvbWlzZSA9IG51bGxcbiAgfVxuXG4gIHJlcXVpcmVzUHJlcGFyYXRpb24oKSB7XG4gICAgLy8gbmFtZWQgcXVlcmllcyBtdXN0IGFsd2F5cyBiZSBwcmVwYXJlZFxuICAgIGlmICh0aGlzLm5hbWUpIHtcbiAgICAgIHJldHVybiB0cnVlXG4gICAgfVxuICAgIC8vIGFsd2F5cyBwcmVwYXJlIGlmIHRoZXJlIGFyZSBtYXggbnVtYmVyIG9mIHJvd3MgZXhwZWN0ZWQgcGVyXG4gICAgLy8gcG9ydGFsIGV4ZWN1dGlvblxuICAgIGlmICh0aGlzLnJvd3MpIHtcbiAgICAgIHJldHVybiB0cnVlXG4gICAgfVxuICAgIC8vIGRvbid0IHByZXBhcmUgZW1wdHkgdGV4dCBxdWVyaWVzXG4gICAgaWYgKCF0aGlzLnRleHQpIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgICAvLyBwcmVwYXJlIGlmIHRoZXJlIGFyZSB2YWx1ZXNcbiAgICBpZiAoIXRoaXMudmFsdWVzKSB7XG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMudmFsdWVzLmxlbmd0aCA+IDBcbiAgfVxuXG4gIF9jaGVja0Zvck11bHRpcm93KCkge1xuICAgIC8vIGlmIHdlIGFscmVhZHkgaGF2ZSBhIHJlc3VsdCB3aXRoIGEgY29tbWFuZCBwcm9wZXJ0eVxuICAgIC8vIHRoZW4gd2UndmUgYWxyZWFkeSBleGVjdXRlZCBvbmUgcXVlcnkgaW4gYSBtdWx0aS1zdGF0ZW1lbnQgc2ltcGxlIHF1ZXJ5XG4gICAgLy8gdHVybiBvdXIgcmVzdWx0cyBpbnRvIGFuIGFycmF5IG9mIHJlc3VsdHNcbiAgICBpZiAodGhpcy5fcmVzdWx0LmNvbW1hbmQpIHtcbiAgICAgIGlmICghQXJyYXkuaXNBcnJheSh0aGlzLl9yZXN1bHRzKSkge1xuICAgICAgICB0aGlzLl9yZXN1bHRzID0gW3RoaXMuX3Jlc3VsdF1cbiAgICAgIH1cbiAgICAgIHRoaXMuX3Jlc3VsdCA9IG5ldyBSZXN1bHQodGhpcy5fcm93TW9kZSwgdGhpcy50eXBlcylcbiAgICAgIHRoaXMuX3Jlc3VsdHMucHVzaCh0aGlzLl9yZXN1bHQpXG4gICAgfVxuICB9XG5cbiAgLy8gYXNzb2NpYXRlcyByb3cgbWV0YWRhdGEgZnJvbSB0aGUgc3VwcGxpZWRcbiAgLy8gbWVzc2FnZSB3aXRoIHRoaXMgcXVlcnkgb2JqZWN0XG4gIC8vIG1ldGFkYXRhIHVzZWQgd2hlbiBwYXJzaW5nIHJvdyByZXN1bHRzXG4gIGhhbmRsZVJvd0Rlc2NyaXB0aW9uKG1zZykge1xuICAgIHRoaXMuX2NoZWNrRm9yTXVsdGlyb3coKVxuICAgIHRoaXMuX3Jlc3VsdC5hZGRGaWVsZHMobXNnLmZpZWxkcylcbiAgICB0aGlzLl9hY2N1bXVsYXRlUm93cyA9IHRoaXMuY2FsbGJhY2sgfHwgIXRoaXMubGlzdGVuZXJzKCdyb3cnKS5sZW5ndGhcbiAgfVxuXG4gIGhhbmRsZURhdGFSb3cobXNnKSB7XG4gICAgbGV0IHJvd1xuXG4gICAgaWYgKHRoaXMuX2NhbmNlbGVkRHVlVG9FcnJvcikge1xuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgIHJvdyA9IHRoaXMuX3Jlc3VsdC5wYXJzZVJvdyhtc2cuZmllbGRzKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgdGhpcy5fY2FuY2VsZWREdWVUb0Vycm9yID0gZXJyXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICB0aGlzLmVtaXQoJ3JvdycsIHJvdywgdGhpcy5fcmVzdWx0KVxuICAgIGlmICh0aGlzLl9hY2N1bXVsYXRlUm93cykge1xuICAgICAgdGhpcy5fcmVzdWx0LmFkZFJvdyhyb3cpXG4gICAgfVxuICB9XG5cbiAgaGFuZGxlQ29tbWFuZENvbXBsZXRlKG1zZywgY29ubmVjdGlvbikge1xuICAgIHRoaXMuX2NoZWNrRm9yTXVsdGlyb3coKVxuICAgIHRoaXMuX3Jlc3VsdC5hZGRDb21tYW5kQ29tcGxldGUobXNnKVxuICAgIC8vIG5lZWQgdG8gc3luYyBhZnRlciBlYWNoIGNvbW1hbmQgY29tcGxldGUgb2YgYSBwcmVwYXJlZCBzdGF0ZW1lbnRcbiAgICAvLyBpZiB3ZSB3ZXJlIHVzaW5nIGEgcm93IGNvdW50IHdoaWNoIHJlc3VsdHMgaW4gbXVsdGlwbGUgY2FsbHMgdG8gX2dldFJvd3NcbiAgICBpZiAodGhpcy5yb3dzKSB7XG4gICAgICBjb25uZWN0aW9uLnN5bmMoKVxuICAgIH1cbiAgfVxuXG4gIC8vIGlmIGEgbmFtZWQgcHJlcGFyZWQgc3RhdGVtZW50IGlzIGNyZWF0ZWQgd2l0aCBlbXB0eSBxdWVyeSB0ZXh0XG4gIC8vIHRoZSBiYWNrZW5kIHdpbGwgc2VuZCBhbiBlbXB0eVF1ZXJ5IG1lc3NhZ2UgYnV0ICpub3QqIGEgY29tbWFuZCBjb21wbGV0ZSBtZXNzYWdlXG4gIC8vIHNpbmNlIHdlIHBpcGVsaW5lIHN5bmMgaW1tZWRpYXRlbHkgYWZ0ZXIgZXhlY3V0ZSB3ZSBkb24ndCBuZWVkIHRvIGRvIGFueXRoaW5nIGhlcmVcbiAgLy8gdW5sZXNzIHdlIGhhdmUgcm93cyBzcGVjaWZpZWQsIGluIHdoaWNoIGNhc2Ugd2UgZGlkIG5vdCBwaXBlbGluZSB0aGUgaW50aWFsIHN5bmMgY2FsbFxuICBoYW5kbGVFbXB0eVF1ZXJ5KGNvbm5lY3Rpb24pIHtcbiAgICBpZiAodGhpcy5yb3dzKSB7XG4gICAgICBjb25uZWN0aW9uLnN5bmMoKVxuICAgIH1cbiAgfVxuXG4gIGhhbmRsZUVycm9yKGVyciwgY29ubmVjdGlvbikge1xuICAgIC8vIG5lZWQgdG8gc3luYyBhZnRlciBlcnJvciBkdXJpbmcgYSBwcmVwYXJlZCBzdGF0ZW1lbnRcbiAgICBpZiAodGhpcy5fY2FuY2VsZWREdWVUb0Vycm9yKSB7XG4gICAgICBlcnIgPSB0aGlzLl9jYW5jZWxlZER1ZVRvRXJyb3JcbiAgICAgIHRoaXMuX2NhbmNlbGVkRHVlVG9FcnJvciA9IGZhbHNlXG4gICAgfVxuICAgIC8vIGlmIGNhbGxiYWNrIHN1cHBsaWVkIGRvIG5vdCBlbWl0IGVycm9yIGV2ZW50IGFzIHVuY2F1Z2h0IGVycm9yXG4gICAgLy8gZXZlbnRzIHdpbGwgYnViYmxlIHVwIHRvIG5vZGUgcHJvY2Vzc1xuICAgIGlmICh0aGlzLmNhbGxiYWNrKSB7XG4gICAgICByZXR1cm4gdGhpcy5jYWxsYmFjayhlcnIpXG4gICAgfVxuICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpXG4gIH1cblxuICBoYW5kbGVSZWFkeUZvclF1ZXJ5KGNvbikge1xuICAgIGlmICh0aGlzLl9jYW5jZWxlZER1ZVRvRXJyb3IpIHtcbiAgICAgIHJldHVybiB0aGlzLmhhbmRsZUVycm9yKHRoaXMuX2NhbmNlbGVkRHVlVG9FcnJvciwgY29uKVxuICAgIH1cbiAgICBpZiAodGhpcy5jYWxsYmFjaykge1xuICAgICAgdGhpcy5jYWxsYmFjayhudWxsLCB0aGlzLl9yZXN1bHRzKVxuICAgIH1cbiAgICB0aGlzLmVtaXQoJ2VuZCcsIHRoaXMuX3Jlc3VsdHMpXG4gIH1cblxuICBzdWJtaXQoY29ubmVjdGlvbikge1xuICAgIGlmICh0eXBlb2YgdGhpcy50ZXh0ICE9PSAnc3RyaW5nJyAmJiB0eXBlb2YgdGhpcy5uYW1lICE9PSAnc3RyaW5nJykge1xuICAgICAgcmV0dXJuIG5ldyBFcnJvcignQSBxdWVyeSBtdXN0IGhhdmUgZWl0aGVyIHRleHQgb3IgYSBuYW1lLiBTdXBwbHlpbmcgbmVpdGhlciBpcyB1bnN1cHBvcnRlZC4nKVxuICAgIH1cbiAgICBjb25zdCBwcmV2aW91cyA9IGNvbm5lY3Rpb24ucGFyc2VkU3RhdGVtZW50c1t0aGlzLm5hbWVdXG4gICAgaWYgKHRoaXMudGV4dCAmJiBwcmV2aW91cyAmJiB0aGlzLnRleHQgIT09IHByZXZpb3VzKSB7XG4gICAgICByZXR1cm4gbmV3IEVycm9yKGBQcmVwYXJlZCBzdGF0ZW1lbnRzIG11c3QgYmUgdW5pcXVlIC0gJyR7dGhpcy5uYW1lfScgd2FzIHVzZWQgZm9yIGEgZGlmZmVyZW50IHN0YXRlbWVudGApXG4gICAgfVxuICAgIGlmICh0aGlzLnZhbHVlcyAmJiAhQXJyYXkuaXNBcnJheSh0aGlzLnZhbHVlcykpIHtcbiAgICAgIHJldHVybiBuZXcgRXJyb3IoJ1F1ZXJ5IHZhbHVlcyBtdXN0IGJlIGFuIGFycmF5JylcbiAgICB9XG4gICAgaWYgKHRoaXMucmVxdWlyZXNQcmVwYXJhdGlvbigpKSB7XG4gICAgICB0aGlzLnByZXBhcmUoY29ubmVjdGlvbilcbiAgICB9IGVsc2Uge1xuICAgICAgY29ubmVjdGlvbi5xdWVyeSh0aGlzLnRleHQpXG4gICAgfVxuICAgIHJldHVybiBudWxsXG4gIH1cblxuICBoYXNCZWVuUGFyc2VkKGNvbm5lY3Rpb24pIHtcbiAgICByZXR1cm4gdGhpcy5uYW1lICYmIGNvbm5lY3Rpb24ucGFyc2VkU3RhdGVtZW50c1t0aGlzLm5hbWVdXG4gIH1cblxuICBoYW5kbGVQb3J0YWxTdXNwZW5kZWQoY29ubmVjdGlvbikge1xuICAgIHRoaXMuX2dldFJvd3MoY29ubmVjdGlvbiwgdGhpcy5yb3dzKVxuICB9XG5cbiAgX2dldFJvd3MoY29ubmVjdGlvbiwgcm93cykge1xuICAgIGNvbm5lY3Rpb24uZXhlY3V0ZSh7XG4gICAgICBwb3J0YWw6IHRoaXMucG9ydGFsLFxuICAgICAgcm93czogcm93cyxcbiAgICB9KVxuICAgIC8vIGlmIHdlJ3JlIG5vdCByZWFkaW5nIHBhZ2VzIG9mIHJvd3Mgc2VuZCB0aGUgc3luYyBjb21tYW5kXG4gICAgLy8gdG8gaW5kaWNhdGUgdGhlIHBpcGVsaW5lIGlzIGZpbmlzaGVkXG4gICAgaWYgKCFyb3dzKSB7XG4gICAgICBjb25uZWN0aW9uLnN5bmMoKVxuICAgIH0gZWxzZSB7XG4gICAgICAvLyBvdGhlcndpc2UgZmx1c2ggdGhlIGNhbGwgb3V0IHRvIHJlYWQgbW9yZSByb3dzXG4gICAgICBjb25uZWN0aW9uLmZsdXNoKClcbiAgICB9XG4gIH1cblxuICAvLyBodHRwOi8vZGV2ZWxvcGVyLnBvc3RncmVzcWwub3JnL3BnZG9jcy9wb3N0Z3Jlcy9wcm90b2NvbC1mbG93Lmh0bWwjUFJPVE9DT0wtRkxPVy1FWFQtUVVFUllcbiAgcHJlcGFyZShjb25uZWN0aW9uKSB7XG4gICAgLy8gcHJlcGFyZWQgc3RhdGVtZW50cyBuZWVkIHN5bmMgdG8gYmUgY2FsbGVkIGFmdGVyIGVhY2ggY29tbWFuZFxuICAgIC8vIGNvbXBsZXRlIG9yIHdoZW4gYW4gZXJyb3IgaXMgZW5jb3VudGVyZWRcbiAgICB0aGlzLmlzUHJlcGFyZWRTdGF0ZW1lbnQgPSB0cnVlXG5cbiAgICAvLyBUT0RPIHJlZmFjdG9yIHRoaXMgcG9vciBlbmNhcHN1bGF0aW9uXG4gICAgaWYgKCF0aGlzLmhhc0JlZW5QYXJzZWQoY29ubmVjdGlvbikpIHtcbiAgICAgIGNvbm5lY3Rpb24ucGFyc2Uoe1xuICAgICAgICB0ZXh0OiB0aGlzLnRleHQsXG4gICAgICAgIG5hbWU6IHRoaXMubmFtZSxcbiAgICAgICAgdHlwZXM6IHRoaXMudHlwZXMsXG4gICAgICB9KVxuICAgIH1cblxuICAgIC8vIGJlY2F1c2Ugd2UncmUgbWFwcGluZyB1c2VyIHN1cHBsaWVkIHZhbHVlcyB0b1xuICAgIC8vIHBvc3RncmVzIHdpcmUgcHJvdG9jb2wgY29tcGF0aWJsZSB2YWx1ZXMgaXQgY291bGRcbiAgICAvLyB0aHJvdyBhbiBleGNlcHRpb24sIHNvIHRyeS9jYXRjaCB0aGlzIHNlY3Rpb25cbiAgICB0cnkge1xuICAgICAgY29ubmVjdGlvbi5iaW5kKHtcbiAgICAgICAgcG9ydGFsOiB0aGlzLnBvcnRhbCxcbiAgICAgICAgc3RhdGVtZW50OiB0aGlzLm5hbWUsXG4gICAgICAgIHZhbHVlczogdGhpcy52YWx1ZXMsXG4gICAgICAgIGJpbmFyeTogdGhpcy5iaW5hcnksXG4gICAgICAgIHZhbHVlTWFwcGVyOiB1dGlscy5wcmVwYXJlVmFsdWUsXG4gICAgICB9KVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgdGhpcy5oYW5kbGVFcnJvcihlcnIsIGNvbm5lY3Rpb24pXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBjb25uZWN0aW9uLmRlc2NyaWJlKHtcbiAgICAgIHR5cGU6ICdQJyxcbiAgICAgIG5hbWU6IHRoaXMucG9ydGFsIHx8ICcnLFxuICAgIH0pXG5cbiAgICB0aGlzLl9nZXRSb3dzKGNvbm5lY3Rpb24sIHRoaXMucm93cylcbiAgfVxuXG4gIGhhbmRsZUNvcHlJblJlc3BvbnNlKGNvbm5lY3Rpb24pIHtcbiAgICBjb25uZWN0aW9uLnNlbmRDb3B5RmFpbCgnTm8gc291cmNlIHN0cmVhbSBkZWZpbmVkJylcbiAgfVxuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby11bnVzZWQtdmFyc1xuICBoYW5kbGVDb3B5RGF0YShtc2csIGNvbm5lY3Rpb24pIHtcbiAgICAvLyBub29wXG4gIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSBRdWVyeVxuIiwiJ3VzZSBzdHJpY3QnXG5cbnZhciB0eXBlcyA9IHJlcXVpcmUoJ3BnLXR5cGVzJylcblxudmFyIG1hdGNoUmVnZXhwID0gL14oW0EtWmEtel0rKSg/OiAoXFxkKykpPyg/OiAoXFxkKykpPy9cblxuLy8gcmVzdWx0IG9iamVjdCByZXR1cm5lZCBmcm9tIHF1ZXJ5XG4vLyBpbiB0aGUgJ2VuZCcgZXZlbnQgYW5kIGFsc29cbi8vIHBhc3NlZCBhcyBzZWNvbmQgYXJndW1lbnQgdG8gcHJvdmlkZWQgY2FsbGJhY2tcbmNsYXNzIFJlc3VsdCB7XG4gIGNvbnN0cnVjdG9yKHJvd01vZGUsIHR5cGVzKSB7XG4gICAgdGhpcy5jb21tYW5kID0gbnVsbFxuICAgIHRoaXMucm93Q291bnQgPSBudWxsXG4gICAgdGhpcy5vaWQgPSBudWxsXG4gICAgdGhpcy5yb3dzID0gW11cbiAgICB0aGlzLmZpZWxkcyA9IFtdXG4gICAgdGhpcy5fcGFyc2VycyA9IHVuZGVmaW5lZFxuICAgIHRoaXMuX3R5cGVzID0gdHlwZXNcbiAgICB0aGlzLlJvd0N0b3IgPSBudWxsXG4gICAgdGhpcy5yb3dBc0FycmF5ID0gcm93TW9kZSA9PT0gJ2FycmF5J1xuICAgIGlmICh0aGlzLnJvd0FzQXJyYXkpIHtcbiAgICAgIHRoaXMucGFyc2VSb3cgPSB0aGlzLl9wYXJzZVJvd0FzQXJyYXlcbiAgICB9XG4gIH1cblxuICAvLyBhZGRzIGEgY29tbWFuZCBjb21wbGV0ZSBtZXNzYWdlXG4gIGFkZENvbW1hbmRDb21wbGV0ZShtc2cpIHtcbiAgICB2YXIgbWF0Y2hcbiAgICBpZiAobXNnLnRleHQpIHtcbiAgICAgIC8vIHB1cmUgamF2YXNjcmlwdFxuICAgICAgbWF0Y2ggPSBtYXRjaFJlZ2V4cC5leGVjKG1zZy50ZXh0KVxuICAgIH0gZWxzZSB7XG4gICAgICAvLyBuYXRpdmUgYmluZGluZ3NcbiAgICAgIG1hdGNoID0gbWF0Y2hSZWdleHAuZXhlYyhtc2cuY29tbWFuZClcbiAgICB9XG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICB0aGlzLmNvbW1hbmQgPSBtYXRjaFsxXVxuICAgICAgaWYgKG1hdGNoWzNdKSB7XG4gICAgICAgIC8vIENPTU1NQU5EIE9JRCBST1dTXG4gICAgICAgIHRoaXMub2lkID0gcGFyc2VJbnQobWF0Y2hbMl0sIDEwKVxuICAgICAgICB0aGlzLnJvd0NvdW50ID0gcGFyc2VJbnQobWF0Y2hbM10sIDEwKVxuICAgICAgfSBlbHNlIGlmIChtYXRjaFsyXSkge1xuICAgICAgICAvLyBDT01NQU5EIFJPV1NcbiAgICAgICAgdGhpcy5yb3dDb3VudCA9IHBhcnNlSW50KG1hdGNoWzJdLCAxMClcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBfcGFyc2VSb3dBc0FycmF5KHJvd0RhdGEpIHtcbiAgICB2YXIgcm93ID0gbmV3IEFycmF5KHJvd0RhdGEubGVuZ3RoKVxuICAgIGZvciAodmFyIGkgPSAwLCBsZW4gPSByb3dEYXRhLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICB2YXIgcmF3VmFsdWUgPSByb3dEYXRhW2ldXG4gICAgICBpZiAocmF3VmFsdWUgIT09IG51bGwpIHtcbiAgICAgICAgcm93W2ldID0gdGhpcy5fcGFyc2Vyc1tpXShyYXdWYWx1ZSlcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJvd1tpXSA9IG51bGxcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHJvd1xuICB9XG5cbiAgcGFyc2VSb3cocm93RGF0YSkge1xuICAgIHZhciByb3cgPSB7fVxuICAgIGZvciAodmFyIGkgPSAwLCBsZW4gPSByb3dEYXRhLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICB2YXIgcmF3VmFsdWUgPSByb3dEYXRhW2ldXG4gICAgICB2YXIgZmllbGQgPSB0aGlzLmZpZWxkc1tpXS5uYW1lXG4gICAgICBpZiAocmF3VmFsdWUgIT09IG51bGwpIHtcbiAgICAgICAgcm93W2ZpZWxkXSA9IHRoaXMuX3BhcnNlcnNbaV0ocmF3VmFsdWUpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICByb3dbZmllbGRdID0gbnVsbFxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcm93XG4gIH1cblxuICBhZGRSb3cocm93KSB7XG4gICAgdGhpcy5yb3dzLnB1c2gocm93KVxuICB9XG5cbiAgYWRkRmllbGRzKGZpZWxkRGVzY3JpcHRpb25zKSB7XG4gICAgLy8gY2xlYXJzIGZpZWxkIGRlZmluaXRpb25zXG4gICAgLy8gbXVsdGlwbGUgcXVlcnkgc3RhdGVtZW50cyBpbiAxIGFjdGlvbiBjYW4gcmVzdWx0IGluIG11bHRpcGxlIHNldHNcbiAgICAvLyBvZiByb3dEZXNjcmlwdGlvbnMuLi5lZzogJ3NlbGVjdCBOT1coKTsgc2VsZWN0IDE6OmludDsnXG4gICAgLy8geW91IG5lZWQgdG8gcmVzZXQgdGhlIGZpZWxkc1xuICAgIHRoaXMuZmllbGRzID0gZmllbGREZXNjcmlwdGlvbnNcbiAgICBpZiAodGhpcy5maWVsZHMubGVuZ3RoKSB7XG4gICAgICB0aGlzLl9wYXJzZXJzID0gbmV3IEFycmF5KGZpZWxkRGVzY3JpcHRpb25zLmxlbmd0aClcbiAgICB9XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBmaWVsZERlc2NyaXB0aW9ucy5sZW5ndGg7IGkrKykge1xuICAgICAgdmFyIGRlc2MgPSBmaWVsZERlc2NyaXB0aW9uc1tpXVxuICAgICAgaWYgKHRoaXMuX3R5cGVzKSB7XG4gICAgICAgIHRoaXMuX3BhcnNlcnNbaV0gPSB0aGlzLl90eXBlcy5nZXRUeXBlUGFyc2VyKGRlc2MuZGF0YVR5cGVJRCwgZGVzYy5mb3JtYXQgfHwgJ3RleHQnKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5fcGFyc2Vyc1tpXSA9IHR5cGVzLmdldFR5cGVQYXJzZXIoZGVzYy5kYXRhVHlwZUlELCBkZXNjLmZvcm1hdCB8fCAndGV4dCcpXG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbm1vZHVsZS5leHBvcnRzID0gUmVzdWx0XG4iLCIndXNlIHN0cmljdCdcbmNvbnN0IGNyeXB0byA9IHJlcXVpcmUoJ2NyeXB0bycpXG5cbmZ1bmN0aW9uIHN0YXJ0U2Vzc2lvbihtZWNoYW5pc21zKSB7XG4gIGlmIChtZWNoYW5pc21zLmluZGV4T2YoJ1NDUkFNLVNIQS0yNTYnKSA9PT0gLTEpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1NBU0w6IE9ubHkgbWVjaGFuaXNtIFNDUkFNLVNIQS0yNTYgaXMgY3VycmVudGx5IHN1cHBvcnRlZCcpXG4gIH1cblxuICBjb25zdCBjbGllbnROb25jZSA9IGNyeXB0by5yYW5kb21CeXRlcygxOCkudG9TdHJpbmcoJ2Jhc2U2NCcpXG5cbiAgcmV0dXJuIHtcbiAgICBtZWNoYW5pc206ICdTQ1JBTS1TSEEtMjU2JyxcbiAgICBjbGllbnROb25jZSxcbiAgICByZXNwb25zZTogJ24sLG49KixyPScgKyBjbGllbnROb25jZSxcbiAgICBtZXNzYWdlOiAnU0FTTEluaXRpYWxSZXNwb25zZScsXG4gIH1cbn1cblxuZnVuY3Rpb24gY29udGludWVTZXNzaW9uKHNlc3Npb24sIHBhc3N3b3JkLCBzZXJ2ZXJEYXRhKSB7XG4gIGlmIChzZXNzaW9uLm1lc3NhZ2UgIT09ICdTQVNMSW5pdGlhbFJlc3BvbnNlJykge1xuICAgIHRocm93IG5ldyBFcnJvcignU0FTTDogTGFzdCBtZXNzYWdlIHdhcyBub3QgU0FTTEluaXRpYWxSZXNwb25zZScpXG4gIH1cbiAgaWYgKHR5cGVvZiBwYXNzd29yZCAhPT0gJ3N0cmluZycpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1NBU0w6IFNDUkFNLVNFUlZFUi1GSVJTVC1NRVNTQUdFOiBjbGllbnQgcGFzc3dvcmQgbXVzdCBiZSBhIHN0cmluZycpXG4gIH1cbiAgaWYgKHR5cGVvZiBzZXJ2ZXJEYXRhICE9PSAnc3RyaW5nJykge1xuICAgIHRocm93IG5ldyBFcnJvcignU0FTTDogU0NSQU0tU0VSVkVSLUZJUlNULU1FU1NBR0U6IHNlcnZlckRhdGEgbXVzdCBiZSBhIHN0cmluZycpXG4gIH1cblxuICBjb25zdCBzdiA9IHBhcnNlU2VydmVyRmlyc3RNZXNzYWdlKHNlcnZlckRhdGEpXG5cbiAgaWYgKCFzdi5ub25jZS5zdGFydHNXaXRoKHNlc3Npb24uY2xpZW50Tm9uY2UpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdTQVNMOiBTQ1JBTS1TRVJWRVItRklSU1QtTUVTU0FHRTogc2VydmVyIG5vbmNlIGRvZXMgbm90IHN0YXJ0IHdpdGggY2xpZW50IG5vbmNlJylcbiAgfSBlbHNlIGlmIChzdi5ub25jZS5sZW5ndGggPT09IHNlc3Npb24uY2xpZW50Tm9uY2UubGVuZ3RoKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdTQVNMOiBTQ1JBTS1TRVJWRVItRklSU1QtTUVTU0FHRTogc2VydmVyIG5vbmNlIGlzIHRvbyBzaG9ydCcpXG4gIH1cblxuICB2YXIgc2FsdEJ5dGVzID0gQnVmZmVyLmZyb20oc3Yuc2FsdCwgJ2Jhc2U2NCcpXG5cbiAgdmFyIHNhbHRlZFBhc3N3b3JkID0gSGkocGFzc3dvcmQsIHNhbHRCeXRlcywgc3YuaXRlcmF0aW9uKVxuXG4gIHZhciBjbGllbnRLZXkgPSBobWFjU2hhMjU2KHNhbHRlZFBhc3N3b3JkLCAnQ2xpZW50IEtleScpXG4gIHZhciBzdG9yZWRLZXkgPSBzaGEyNTYoY2xpZW50S2V5KVxuXG4gIHZhciBjbGllbnRGaXJzdE1lc3NhZ2VCYXJlID0gJ249KixyPScgKyBzZXNzaW9uLmNsaWVudE5vbmNlXG4gIHZhciBzZXJ2ZXJGaXJzdE1lc3NhZ2UgPSAncj0nICsgc3Yubm9uY2UgKyAnLHM9JyArIHN2LnNhbHQgKyAnLGk9JyArIHN2Lml0ZXJhdGlvblxuXG4gIHZhciBjbGllbnRGaW5hbE1lc3NhZ2VXaXRob3V0UHJvb2YgPSAnYz1iaXdzLHI9JyArIHN2Lm5vbmNlXG5cbiAgdmFyIGF1dGhNZXNzYWdlID0gY2xpZW50Rmlyc3RNZXNzYWdlQmFyZSArICcsJyArIHNlcnZlckZpcnN0TWVzc2FnZSArICcsJyArIGNsaWVudEZpbmFsTWVzc2FnZVdpdGhvdXRQcm9vZlxuXG4gIHZhciBjbGllbnRTaWduYXR1cmUgPSBobWFjU2hhMjU2KHN0b3JlZEtleSwgYXV0aE1lc3NhZ2UpXG4gIHZhciBjbGllbnRQcm9vZkJ5dGVzID0geG9yQnVmZmVycyhjbGllbnRLZXksIGNsaWVudFNpZ25hdHVyZSlcbiAgdmFyIGNsaWVudFByb29mID0gY2xpZW50UHJvb2ZCeXRlcy50b1N0cmluZygnYmFzZTY0JylcblxuICB2YXIgc2VydmVyS2V5ID0gaG1hY1NoYTI1NihzYWx0ZWRQYXNzd29yZCwgJ1NlcnZlciBLZXknKVxuICB2YXIgc2VydmVyU2lnbmF0dXJlQnl0ZXMgPSBobWFjU2hhMjU2KHNlcnZlcktleSwgYXV0aE1lc3NhZ2UpXG5cbiAgc2Vzc2lvbi5tZXNzYWdlID0gJ1NBU0xSZXNwb25zZSdcbiAgc2Vzc2lvbi5zZXJ2ZXJTaWduYXR1cmUgPSBzZXJ2ZXJTaWduYXR1cmVCeXRlcy50b1N0cmluZygnYmFzZTY0JylcbiAgc2Vzc2lvbi5yZXNwb25zZSA9IGNsaWVudEZpbmFsTWVzc2FnZVdpdGhvdXRQcm9vZiArICcscD0nICsgY2xpZW50UHJvb2Zcbn1cblxuZnVuY3Rpb24gZmluYWxpemVTZXNzaW9uKHNlc3Npb24sIHNlcnZlckRhdGEpIHtcbiAgaWYgKHNlc3Npb24ubWVzc2FnZSAhPT0gJ1NBU0xSZXNwb25zZScpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1NBU0w6IExhc3QgbWVzc2FnZSB3YXMgbm90IFNBU0xSZXNwb25zZScpXG4gIH1cbiAgaWYgKHR5cGVvZiBzZXJ2ZXJEYXRhICE9PSAnc3RyaW5nJykge1xuICAgIHRocm93IG5ldyBFcnJvcignU0FTTDogU0NSQU0tU0VSVkVSLUZJTkFMLU1FU1NBR0U6IHNlcnZlckRhdGEgbXVzdCBiZSBhIHN0cmluZycpXG4gIH1cblxuICBjb25zdCB7IHNlcnZlclNpZ25hdHVyZSB9ID0gcGFyc2VTZXJ2ZXJGaW5hbE1lc3NhZ2Uoc2VydmVyRGF0YSlcblxuICBpZiAoc2VydmVyU2lnbmF0dXJlICE9PSBzZXNzaW9uLnNlcnZlclNpZ25hdHVyZSkge1xuICAgIHRocm93IG5ldyBFcnJvcignU0FTTDogU0NSQU0tU0VSVkVSLUZJTkFMLU1FU1NBR0U6IHNlcnZlciBzaWduYXR1cmUgZG9lcyBub3QgbWF0Y2gnKVxuICB9XG59XG5cbi8qKlxuICogcHJpbnRhYmxlICAgICAgID0gJXgyMS0yQiAvICV4MkQtN0VcbiAqICAgICAgICAgICAgICAgICAgIDs7IFByaW50YWJsZSBBU0NJSSBleGNlcHQgXCIsXCIuXG4gKiAgICAgICAgICAgICAgICAgICA7OyBOb3RlIHRoYXQgYW55IFwicHJpbnRhYmxlXCIgaXMgYWxzb1xuICogICAgICAgICAgICAgICAgICAgOzsgYSB2YWxpZCBcInZhbHVlXCIuXG4gKi9cbmZ1bmN0aW9uIGlzUHJpbnRhYmxlQ2hhcnModGV4dCkge1xuICBpZiAodHlwZW9mIHRleHQgIT09ICdzdHJpbmcnKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignU0FTTDogdGV4dCBtdXN0IGJlIGEgc3RyaW5nJylcbiAgfVxuICByZXR1cm4gdGV4dFxuICAgIC5zcGxpdCgnJylcbiAgICAubWFwKChfLCBpKSA9PiB0ZXh0LmNoYXJDb2RlQXQoaSkpXG4gICAgLmV2ZXJ5KChjKSA9PiAoYyA+PSAweDIxICYmIGMgPD0gMHgyYikgfHwgKGMgPj0gMHgyZCAmJiBjIDw9IDB4N2UpKVxufVxuXG4vKipcbiAqIGJhc2U2NC1jaGFyICAgICA9IEFMUEhBIC8gRElHSVQgLyBcIi9cIiAvIFwiK1wiXG4gKlxuICogYmFzZTY0LTQgICAgICAgID0gNGJhc2U2NC1jaGFyXG4gKlxuICogYmFzZTY0LTMgICAgICAgID0gM2Jhc2U2NC1jaGFyIFwiPVwiXG4gKlxuICogYmFzZTY0LTIgICAgICAgID0gMmJhc2U2NC1jaGFyIFwiPT1cIlxuICpcbiAqIGJhc2U2NCAgICAgICAgICA9ICpiYXNlNjQtNCBbYmFzZTY0LTMgLyBiYXNlNjQtMl1cbiAqL1xuZnVuY3Rpb24gaXNCYXNlNjQodGV4dCkge1xuICByZXR1cm4gL14oPzpbYS16QS1aMC05Ky9dezR9KSooPzpbYS16QS1aMC05Ky9dezJ9PT18W2EtekEtWjAtOSsvXXszfT0pPyQvLnRlc3QodGV4dClcbn1cblxuZnVuY3Rpb24gcGFyc2VBdHRyaWJ1dGVQYWlycyh0ZXh0KSB7XG4gIGlmICh0eXBlb2YgdGV4dCAhPT0gJ3N0cmluZycpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdTQVNMOiBhdHRyaWJ1dGUgcGFpcnMgdGV4dCBtdXN0IGJlIGEgc3RyaW5nJylcbiAgfVxuXG4gIHJldHVybiBuZXcgTWFwKFxuICAgIHRleHQuc3BsaXQoJywnKS5tYXAoKGF0dHJWYWx1ZSkgPT4ge1xuICAgICAgaWYgKCEvXi49Ly50ZXN0KGF0dHJWYWx1ZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdTQVNMOiBJbnZhbGlkIGF0dHJpYnV0ZSBwYWlyIGVudHJ5JylcbiAgICAgIH1cbiAgICAgIGNvbnN0IG5hbWUgPSBhdHRyVmFsdWVbMF1cbiAgICAgIGNvbnN0IHZhbHVlID0gYXR0clZhbHVlLnN1YnN0cmluZygyKVxuICAgICAgcmV0dXJuIFtuYW1lLCB2YWx1ZV1cbiAgICB9KVxuICApXG59XG5cbmZ1bmN0aW9uIHBhcnNlU2VydmVyRmlyc3RNZXNzYWdlKGRhdGEpIHtcbiAgY29uc3QgYXR0clBhaXJzID0gcGFyc2VBdHRyaWJ1dGVQYWlycyhkYXRhKVxuXG4gIGNvbnN0IG5vbmNlID0gYXR0clBhaXJzLmdldCgncicpXG4gIGlmICghbm9uY2UpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1NBU0w6IFNDUkFNLVNFUlZFUi1GSVJTVC1NRVNTQUdFOiBub25jZSBtaXNzaW5nJylcbiAgfSBlbHNlIGlmICghaXNQcmludGFibGVDaGFycyhub25jZSkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1NBU0w6IFNDUkFNLVNFUlZFUi1GSVJTVC1NRVNTQUdFOiBub25jZSBtdXN0IG9ubHkgY29udGFpbiBwcmludGFibGUgY2hhcmFjdGVycycpXG4gIH1cbiAgY29uc3Qgc2FsdCA9IGF0dHJQYWlycy5nZXQoJ3MnKVxuICBpZiAoIXNhbHQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1NBU0w6IFNDUkFNLVNFUlZFUi1GSVJTVC1NRVNTQUdFOiBzYWx0IG1pc3NpbmcnKVxuICB9IGVsc2UgaWYgKCFpc0Jhc2U2NChzYWx0KSkge1xuICAgIHRocm93IG5ldyBFcnJvcignU0FTTDogU0NSQU0tU0VSVkVSLUZJUlNULU1FU1NBR0U6IHNhbHQgbXVzdCBiZSBiYXNlNjQnKVxuICB9XG4gIGNvbnN0IGl0ZXJhdGlvblRleHQgPSBhdHRyUGFpcnMuZ2V0KCdpJylcbiAgaWYgKCFpdGVyYXRpb25UZXh0KSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdTQVNMOiBTQ1JBTS1TRVJWRVItRklSU1QtTUVTU0FHRTogaXRlcmF0aW9uIG1pc3NpbmcnKVxuICB9IGVsc2UgaWYgKCEvXlsxLTldWzAtOV0qJC8udGVzdChpdGVyYXRpb25UZXh0KSkge1xuICAgIHRocm93IG5ldyBFcnJvcignU0FTTDogU0NSQU0tU0VSVkVSLUZJUlNULU1FU1NBR0U6IGludmFsaWQgaXRlcmF0aW9uIGNvdW50JylcbiAgfVxuICBjb25zdCBpdGVyYXRpb24gPSBwYXJzZUludChpdGVyYXRpb25UZXh0LCAxMClcblxuICByZXR1cm4ge1xuICAgIG5vbmNlLFxuICAgIHNhbHQsXG4gICAgaXRlcmF0aW9uLFxuICB9XG59XG5cbmZ1bmN0aW9uIHBhcnNlU2VydmVyRmluYWxNZXNzYWdlKHNlcnZlckRhdGEpIHtcbiAgY29uc3QgYXR0clBhaXJzID0gcGFyc2VBdHRyaWJ1dGVQYWlycyhzZXJ2ZXJEYXRhKVxuICBjb25zdCBzZXJ2ZXJTaWduYXR1cmUgPSBhdHRyUGFpcnMuZ2V0KCd2JylcbiAgaWYgKCFzZXJ2ZXJTaWduYXR1cmUpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1NBU0w6IFNDUkFNLVNFUlZFUi1GSU5BTC1NRVNTQUdFOiBzZXJ2ZXIgc2lnbmF0dXJlIGlzIG1pc3NpbmcnKVxuICB9IGVsc2UgaWYgKCFpc0Jhc2U2NChzZXJ2ZXJTaWduYXR1cmUpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdTQVNMOiBTQ1JBTS1TRVJWRVItRklOQUwtTUVTU0FHRTogc2VydmVyIHNpZ25hdHVyZSBtdXN0IGJlIGJhc2U2NCcpXG4gIH1cbiAgcmV0dXJuIHtcbiAgICBzZXJ2ZXJTaWduYXR1cmUsXG4gIH1cbn1cblxuZnVuY3Rpb24geG9yQnVmZmVycyhhLCBiKSB7XG4gIGlmICghQnVmZmVyLmlzQnVmZmVyKGEpKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignZmlyc3QgYXJndW1lbnQgbXVzdCBiZSBhIEJ1ZmZlcicpXG4gIH1cbiAgaWYgKCFCdWZmZXIuaXNCdWZmZXIoYikpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdzZWNvbmQgYXJndW1lbnQgbXVzdCBiZSBhIEJ1ZmZlcicpXG4gIH1cbiAgaWYgKGEubGVuZ3RoICE9PSBiLmxlbmd0aCkge1xuICAgIHRocm93IG5ldyBFcnJvcignQnVmZmVyIGxlbmd0aHMgbXVzdCBtYXRjaCcpXG4gIH1cbiAgaWYgKGEubGVuZ3RoID09PSAwKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdCdWZmZXJzIGNhbm5vdCBiZSBlbXB0eScpXG4gIH1cbiAgcmV0dXJuIEJ1ZmZlci5mcm9tKGEubWFwKChfLCBpKSA9PiBhW2ldIF4gYltpXSkpXG59XG5cbmZ1bmN0aW9uIHNoYTI1Nih0ZXh0KSB7XG4gIHJldHVybiBjcnlwdG8uY3JlYXRlSGFzaCgnc2hhMjU2JykudXBkYXRlKHRleHQpLmRpZ2VzdCgpXG59XG5cbmZ1bmN0aW9uIGhtYWNTaGEyNTYoa2V5LCBtc2cpIHtcbiAgcmV0dXJuIGNyeXB0by5jcmVhdGVIbWFjKCdzaGEyNTYnLCBrZXkpLnVwZGF0ZShtc2cpLmRpZ2VzdCgpXG59XG5cbmZ1bmN0aW9uIEhpKHBhc3N3b3JkLCBzYWx0Qnl0ZXMsIGl0ZXJhdGlvbnMpIHtcbiAgdmFyIHVpMSA9IGhtYWNTaGEyNTYocGFzc3dvcmQsIEJ1ZmZlci5jb25jYXQoW3NhbHRCeXRlcywgQnVmZmVyLmZyb20oWzAsIDAsIDAsIDFdKV0pKVxuICB2YXIgdWkgPSB1aTFcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBpdGVyYXRpb25zIC0gMTsgaSsrKSB7XG4gICAgdWkxID0gaG1hY1NoYTI1NihwYXNzd29yZCwgdWkxKVxuICAgIHVpID0geG9yQnVmZmVycyh1aSwgdWkxKVxuICB9XG5cbiAgcmV0dXJuIHVpXG59XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICBzdGFydFNlc3Npb24sXG4gIGNvbnRpbnVlU2Vzc2lvbixcbiAgZmluYWxpemVTZXNzaW9uLFxufVxuIiwiJ3VzZSBzdHJpY3QnXG5cbnZhciB0eXBlcyA9IHJlcXVpcmUoJ3BnLXR5cGVzJylcblxuZnVuY3Rpb24gVHlwZU92ZXJyaWRlcyh1c2VyVHlwZXMpIHtcbiAgdGhpcy5fdHlwZXMgPSB1c2VyVHlwZXMgfHwgdHlwZXNcbiAgdGhpcy50ZXh0ID0ge31cbiAgdGhpcy5iaW5hcnkgPSB7fVxufVxuXG5UeXBlT3ZlcnJpZGVzLnByb3RvdHlwZS5nZXRPdmVycmlkZXMgPSBmdW5jdGlvbiAoZm9ybWF0KSB7XG4gIHN3aXRjaCAoZm9ybWF0KSB7XG4gICAgY2FzZSAndGV4dCc6XG4gICAgICByZXR1cm4gdGhpcy50ZXh0XG4gICAgY2FzZSAnYmluYXJ5JzpcbiAgICAgIHJldHVybiB0aGlzLmJpbmFyeVxuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4ge31cbiAgfVxufVxuXG5UeXBlT3ZlcnJpZGVzLnByb3RvdHlwZS5zZXRUeXBlUGFyc2VyID0gZnVuY3Rpb24gKG9pZCwgZm9ybWF0LCBwYXJzZUZuKSB7XG4gIGlmICh0eXBlb2YgZm9ybWF0ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgcGFyc2VGbiA9IGZvcm1hdFxuICAgIGZvcm1hdCA9ICd0ZXh0J1xuICB9XG4gIHRoaXMuZ2V0T3ZlcnJpZGVzKGZvcm1hdClbb2lkXSA9IHBhcnNlRm5cbn1cblxuVHlwZU92ZXJyaWRlcy5wcm90b3R5cGUuZ2V0VHlwZVBhcnNlciA9IGZ1bmN0aW9uIChvaWQsIGZvcm1hdCkge1xuICBmb3JtYXQgPSBmb3JtYXQgfHwgJ3RleHQnXG4gIHJldHVybiB0aGlzLmdldE92ZXJyaWRlcyhmb3JtYXQpW29pZF0gfHwgdGhpcy5fdHlwZXMuZ2V0VHlwZVBhcnNlcihvaWQsIGZvcm1hdClcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBUeXBlT3ZlcnJpZGVzXG4iLCIndXNlIHN0cmljdCdcblxuY29uc3QgY3J5cHRvID0gcmVxdWlyZSgnY3J5cHRvJylcblxuY29uc3QgZGVmYXVsdHMgPSByZXF1aXJlKCcuL2RlZmF1bHRzJylcblxuZnVuY3Rpb24gZXNjYXBlRWxlbWVudChlbGVtZW50UmVwcmVzZW50YXRpb24pIHtcbiAgdmFyIGVzY2FwZWQgPSBlbGVtZW50UmVwcmVzZW50YXRpb24ucmVwbGFjZSgvXFxcXC9nLCAnXFxcXFxcXFwnKS5yZXBsYWNlKC9cIi9nLCAnXFxcXFwiJylcblxuICByZXR1cm4gJ1wiJyArIGVzY2FwZWQgKyAnXCInXG59XG5cbi8vIGNvbnZlcnQgYSBKUyBhcnJheSB0byBhIHBvc3RncmVzIGFycmF5IGxpdGVyYWxcbi8vIHVzZXMgY29tbWEgc2VwYXJhdG9yIHNvIHdvbid0IHdvcmsgZm9yIHR5cGVzIGxpa2UgYm94IHRoYXQgdXNlXG4vLyBhIGRpZmZlcmVudCBhcnJheSBzZXBhcmF0b3IuXG5mdW5jdGlvbiBhcnJheVN0cmluZyh2YWwpIHtcbiAgdmFyIHJlc3VsdCA9ICd7J1xuICBmb3IgKHZhciBpID0gMDsgaSA8IHZhbC5sZW5ndGg7IGkrKykge1xuICAgIGlmIChpID4gMCkge1xuICAgICAgcmVzdWx0ID0gcmVzdWx0ICsgJywnXG4gICAgfVxuICAgIGlmICh2YWxbaV0gPT09IG51bGwgfHwgdHlwZW9mIHZhbFtpXSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIHJlc3VsdCA9IHJlc3VsdCArICdOVUxMJ1xuICAgIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheSh2YWxbaV0pKSB7XG4gICAgICByZXN1bHQgPSByZXN1bHQgKyBhcnJheVN0cmluZyh2YWxbaV0pXG4gICAgfSBlbHNlIGlmICh2YWxbaV0gaW5zdGFuY2VvZiBCdWZmZXIpIHtcbiAgICAgIHJlc3VsdCArPSAnXFxcXFxcXFx4JyArIHZhbFtpXS50b1N0cmluZygnaGV4JylcbiAgICB9IGVsc2Uge1xuICAgICAgcmVzdWx0ICs9IGVzY2FwZUVsZW1lbnQocHJlcGFyZVZhbHVlKHZhbFtpXSkpXG4gICAgfVxuICB9XG4gIHJlc3VsdCA9IHJlc3VsdCArICd9J1xuICByZXR1cm4gcmVzdWx0XG59XG5cbi8vIGNvbnZlcnRzIHZhbHVlcyBmcm9tIGphdmFzY3JpcHQgdHlwZXNcbi8vIHRvIHRoZWlyICdyYXcnIGNvdW50ZXJwYXJ0cyBmb3IgdXNlIGFzIGEgcG9zdGdyZXMgcGFyYW1ldGVyXG4vLyBub3RlOiB5b3UgY2FuIG92ZXJyaWRlIHRoaXMgZnVuY3Rpb24gdG8gcHJvdmlkZSB5b3VyIG93biBjb252ZXJzaW9uIG1lY2hhbmlzbVxuLy8gZm9yIGNvbXBsZXggdHlwZXMsIGV0Yy4uLlxudmFyIHByZXBhcmVWYWx1ZSA9IGZ1bmN0aW9uICh2YWwsIHNlZW4pIHtcbiAgLy8gbnVsbCBhbmQgdW5kZWZpbmVkIGFyZSBib3RoIG51bGwgZm9yIHBvc3RncmVzXG4gIGlmICh2YWwgPT0gbnVsbCkge1xuICAgIHJldHVybiBudWxsXG4gIH1cbiAgaWYgKHZhbCBpbnN0YW5jZW9mIEJ1ZmZlcikge1xuICAgIHJldHVybiB2YWxcbiAgfVxuICBpZiAoQXJyYXlCdWZmZXIuaXNWaWV3KHZhbCkpIHtcbiAgICB2YXIgYnVmID0gQnVmZmVyLmZyb20odmFsLmJ1ZmZlciwgdmFsLmJ5dGVPZmZzZXQsIHZhbC5ieXRlTGVuZ3RoKVxuICAgIGlmIChidWYubGVuZ3RoID09PSB2YWwuYnl0ZUxlbmd0aCkge1xuICAgICAgcmV0dXJuIGJ1ZlxuICAgIH1cbiAgICByZXR1cm4gYnVmLnNsaWNlKHZhbC5ieXRlT2Zmc2V0LCB2YWwuYnl0ZU9mZnNldCArIHZhbC5ieXRlTGVuZ3RoKSAvLyBOb2RlLmpzIHY0IGRvZXMgbm90IHN1cHBvcnQgdGhvc2UgQnVmZmVyLmZyb20gcGFyYW1zXG4gIH1cbiAgaWYgKHZhbCBpbnN0YW5jZW9mIERhdGUpIHtcbiAgICBpZiAoZGVmYXVsdHMucGFyc2VJbnB1dERhdGVzQXNVVEMpIHtcbiAgICAgIHJldHVybiBkYXRlVG9TdHJpbmdVVEModmFsKVxuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gZGF0ZVRvU3RyaW5nKHZhbClcbiAgICB9XG4gIH1cbiAgaWYgKEFycmF5LmlzQXJyYXkodmFsKSkge1xuICAgIHJldHVybiBhcnJheVN0cmluZyh2YWwpXG4gIH1cbiAgaWYgKHR5cGVvZiB2YWwgPT09ICdvYmplY3QnKSB7XG4gICAgcmV0dXJuIHByZXBhcmVPYmplY3QodmFsLCBzZWVuKVxuICB9XG4gIHJldHVybiB2YWwudG9TdHJpbmcoKVxufVxuXG5mdW5jdGlvbiBwcmVwYXJlT2JqZWN0KHZhbCwgc2Vlbikge1xuICBpZiAodmFsICYmIHR5cGVvZiB2YWwudG9Qb3N0Z3JlcyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIHNlZW4gPSBzZWVuIHx8IFtdXG4gICAgaWYgKHNlZW4uaW5kZXhPZih2YWwpICE9PSAtMSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdjaXJjdWxhciByZWZlcmVuY2UgZGV0ZWN0ZWQgd2hpbGUgcHJlcGFyaW5nIFwiJyArIHZhbCArICdcIiBmb3IgcXVlcnknKVxuICAgIH1cbiAgICBzZWVuLnB1c2godmFsKVxuXG4gICAgcmV0dXJuIHByZXBhcmVWYWx1ZSh2YWwudG9Qb3N0Z3JlcyhwcmVwYXJlVmFsdWUpLCBzZWVuKVxuICB9XG4gIHJldHVybiBKU09OLnN0cmluZ2lmeSh2YWwpXG59XG5cbmZ1bmN0aW9uIHBhZChudW1iZXIsIGRpZ2l0cykge1xuICBudW1iZXIgPSAnJyArIG51bWJlclxuICB3aGlsZSAobnVtYmVyLmxlbmd0aCA8IGRpZ2l0cykge1xuICAgIG51bWJlciA9ICcwJyArIG51bWJlclxuICB9XG4gIHJldHVybiBudW1iZXJcbn1cblxuZnVuY3Rpb24gZGF0ZVRvU3RyaW5nKGRhdGUpIHtcbiAgdmFyIG9mZnNldCA9IC1kYXRlLmdldFRpbWV6b25lT2Zmc2V0KClcblxuICB2YXIgeWVhciA9IGRhdGUuZ2V0RnVsbFllYXIoKVxuICB2YXIgaXNCQ1llYXIgPSB5ZWFyIDwgMVxuICBpZiAoaXNCQ1llYXIpIHllYXIgPSBNYXRoLmFicyh5ZWFyKSArIDEgLy8gbmVnYXRpdmUgeWVhcnMgYXJlIDEgb2ZmIHRoZWlyIEJDIHJlcHJlc2VudGF0aW9uXG5cbiAgdmFyIHJldCA9XG4gICAgcGFkKHllYXIsIDQpICtcbiAgICAnLScgK1xuICAgIHBhZChkYXRlLmdldE1vbnRoKCkgKyAxLCAyKSArXG4gICAgJy0nICtcbiAgICBwYWQoZGF0ZS5nZXREYXRlKCksIDIpICtcbiAgICAnVCcgK1xuICAgIHBhZChkYXRlLmdldEhvdXJzKCksIDIpICtcbiAgICAnOicgK1xuICAgIHBhZChkYXRlLmdldE1pbnV0ZXMoKSwgMikgK1xuICAgICc6JyArXG4gICAgcGFkKGRhdGUuZ2V0U2Vjb25kcygpLCAyKSArXG4gICAgJy4nICtcbiAgICBwYWQoZGF0ZS5nZXRNaWxsaXNlY29uZHMoKSwgMylcblxuICBpZiAob2Zmc2V0IDwgMCkge1xuICAgIHJldCArPSAnLSdcbiAgICBvZmZzZXQgKj0gLTFcbiAgfSBlbHNlIHtcbiAgICByZXQgKz0gJysnXG4gIH1cblxuICByZXQgKz0gcGFkKE1hdGguZmxvb3Iob2Zmc2V0IC8gNjApLCAyKSArICc6JyArIHBhZChvZmZzZXQgJSA2MCwgMilcbiAgaWYgKGlzQkNZZWFyKSByZXQgKz0gJyBCQydcbiAgcmV0dXJuIHJldFxufVxuXG5mdW5jdGlvbiBkYXRlVG9TdHJpbmdVVEMoZGF0ZSkge1xuICB2YXIgeWVhciA9IGRhdGUuZ2V0VVRDRnVsbFllYXIoKVxuICB2YXIgaXNCQ1llYXIgPSB5ZWFyIDwgMVxuICBpZiAoaXNCQ1llYXIpIHllYXIgPSBNYXRoLmFicyh5ZWFyKSArIDEgLy8gbmVnYXRpdmUgeWVhcnMgYXJlIDEgb2ZmIHRoZWlyIEJDIHJlcHJlc2VudGF0aW9uXG5cbiAgdmFyIHJldCA9XG4gICAgcGFkKHllYXIsIDQpICtcbiAgICAnLScgK1xuICAgIHBhZChkYXRlLmdldFVUQ01vbnRoKCkgKyAxLCAyKSArXG4gICAgJy0nICtcbiAgICBwYWQoZGF0ZS5nZXRVVENEYXRlKCksIDIpICtcbiAgICAnVCcgK1xuICAgIHBhZChkYXRlLmdldFVUQ0hvdXJzKCksIDIpICtcbiAgICAnOicgK1xuICAgIHBhZChkYXRlLmdldFVUQ01pbnV0ZXMoKSwgMikgK1xuICAgICc6JyArXG4gICAgcGFkKGRhdGUuZ2V0VVRDU2Vjb25kcygpLCAyKSArXG4gICAgJy4nICtcbiAgICBwYWQoZGF0ZS5nZXRVVENNaWxsaXNlY29uZHMoKSwgMylcblxuICByZXQgKz0gJyswMDowMCdcbiAgaWYgKGlzQkNZZWFyKSByZXQgKz0gJyBCQydcbiAgcmV0dXJuIHJldFxufVxuXG5mdW5jdGlvbiBub3JtYWxpemVRdWVyeUNvbmZpZyhjb25maWcsIHZhbHVlcywgY2FsbGJhY2spIHtcbiAgLy8gY2FuIHRha2UgaW4gc3RyaW5ncyBvciBjb25maWcgb2JqZWN0c1xuICBjb25maWcgPSB0eXBlb2YgY29uZmlnID09PSAnc3RyaW5nJyA/IHsgdGV4dDogY29uZmlnIH0gOiBjb25maWdcbiAgaWYgKHZhbHVlcykge1xuICAgIGlmICh0eXBlb2YgdmFsdWVzID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICBjb25maWcuY2FsbGJhY2sgPSB2YWx1ZXNcbiAgICB9IGVsc2Uge1xuICAgICAgY29uZmlnLnZhbHVlcyA9IHZhbHVlc1xuICAgIH1cbiAgfVxuICBpZiAoY2FsbGJhY2spIHtcbiAgICBjb25maWcuY2FsbGJhY2sgPSBjYWxsYmFja1xuICB9XG4gIHJldHVybiBjb25maWdcbn1cblxuY29uc3QgbWQ1ID0gZnVuY3Rpb24gKHN0cmluZykge1xuICByZXR1cm4gY3J5cHRvLmNyZWF0ZUhhc2goJ21kNScpLnVwZGF0ZShzdHJpbmcsICd1dGYtOCcpLmRpZ2VzdCgnaGV4Jylcbn1cblxuLy8gU2VlIEF1dGhlbnRpY2F0aW9uTUQ1UGFzc3dvcmQgYXQgaHR0cHM6Ly93d3cucG9zdGdyZXNxbC5vcmcvZG9jcy9jdXJyZW50L3N0YXRpYy9wcm90b2NvbC1mbG93Lmh0bWxcbmNvbnN0IHBvc3RncmVzTWQ1UGFzc3dvcmRIYXNoID0gZnVuY3Rpb24gKHVzZXIsIHBhc3N3b3JkLCBzYWx0KSB7XG4gIHZhciBpbm5lciA9IG1kNShwYXNzd29yZCArIHVzZXIpXG4gIHZhciBvdXRlciA9IG1kNShCdWZmZXIuY29uY2F0KFtCdWZmZXIuZnJvbShpbm5lciksIHNhbHRdKSlcbiAgcmV0dXJuICdtZDUnICsgb3V0ZXJcbn1cblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gIHByZXBhcmVWYWx1ZTogZnVuY3Rpb24gcHJlcGFyZVZhbHVlV3JhcHBlcih2YWx1ZSkge1xuICAgIC8vIHRoaXMgZW5zdXJlcyB0aGF0IGV4dHJhIGFyZ3VtZW50cyBkbyBub3QgZ2V0IHBhc3NlZCBpbnRvIHByZXBhcmVWYWx1ZVxuICAgIC8vIGJ5IGFjY2lkZW50LCBlZzogZnJvbSBjYWxsaW5nIHZhbHVlcy5tYXAodXRpbHMucHJlcGFyZVZhbHVlKVxuICAgIHJldHVybiBwcmVwYXJlVmFsdWUodmFsdWUpXG4gIH0sXG4gIG5vcm1hbGl6ZVF1ZXJ5Q29uZmlnLFxuICBwb3N0Z3Jlc01kNVBhc3N3b3JkSGFzaCxcbiAgbWQ1LFxufVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG52YXIgcGF0aCA9IHJlcXVpcmUoJ3BhdGgnKVxuICAsIFN0cmVhbSA9IHJlcXVpcmUoJ3N0cmVhbScpLlN0cmVhbVxuICAsIHNwbGl0ID0gcmVxdWlyZSgnc3BsaXQyJylcbiAgLCB1dGlsID0gcmVxdWlyZSgndXRpbCcpXG4gICwgZGVmYXVsdFBvcnQgPSA1NDMyXG4gICwgaXNXaW4gPSAocHJvY2Vzcy5wbGF0Zm9ybSA9PT0gJ3dpbjMyJylcbiAgLCB3YXJuU3RyZWFtID0gcHJvY2Vzcy5zdGRlcnJcbjtcblxuXG52YXIgU19JUldYRyA9IDU2ICAgICAvLyAgICAwMDA3MCg4KVxuICAsIFNfSVJXWE8gPSA3ICAgICAgLy8gICAgMDAwMDcoOClcbiAgLCBTX0lGTVQgID0gNjE0NDAgIC8vIDAwMTcwMDAwKDgpXG4gICwgU19JRlJFRyA9IDMyNzY4ICAvLyAgMDEwMDAwMCg4KVxuO1xuZnVuY3Rpb24gaXNSZWdGaWxlKG1vZGUpIHtcbiAgICByZXR1cm4gKChtb2RlICYgU19JRk1UKSA9PSBTX0lGUkVHKTtcbn1cblxudmFyIGZpZWxkTmFtZXMgPSBbICdob3N0JywgJ3BvcnQnLCAnZGF0YWJhc2UnLCAndXNlcicsICdwYXNzd29yZCcgXTtcbnZhciBuck9mRmllbGRzID0gZmllbGROYW1lcy5sZW5ndGg7XG52YXIgcGFzc0tleSA9IGZpZWxkTmFtZXNbIG5yT2ZGaWVsZHMgLTEgXTtcblxuXG5mdW5jdGlvbiB3YXJuKCkge1xuICAgIHZhciBpc1dyaXRhYmxlID0gKFxuICAgICAgICB3YXJuU3RyZWFtIGluc3RhbmNlb2YgU3RyZWFtICYmXG4gICAgICAgICAgdHJ1ZSA9PT0gd2FyblN0cmVhbS53cml0YWJsZVxuICAgICk7XG5cbiAgICBpZiAoaXNXcml0YWJsZSkge1xuICAgICAgICB2YXIgYXJncyA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGFyZ3VtZW50cykuY29uY2F0KFwiXFxuXCIpO1xuICAgICAgICB3YXJuU3RyZWFtLndyaXRlKCB1dGlsLmZvcm1hdC5hcHBseSh1dGlsLCBhcmdzKSApO1xuICAgIH1cbn1cblxuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkobW9kdWxlLmV4cG9ydHMsICdpc1dpbicsIHtcbiAgICBnZXQgOiBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIGlzV2luO1xuICAgIH0gLFxuICAgIHNldCA6IGZ1bmN0aW9uKHZhbCkge1xuICAgICAgICBpc1dpbiA9IHZhbDtcbiAgICB9XG59KTtcblxuXG5tb2R1bGUuZXhwb3J0cy53YXJuVG8gPSBmdW5jdGlvbihzdHJlYW0pIHtcbiAgICB2YXIgb2xkID0gd2FyblN0cmVhbTtcbiAgICB3YXJuU3RyZWFtID0gc3RyZWFtO1xuICAgIHJldHVybiBvbGQ7XG59O1xuXG5tb2R1bGUuZXhwb3J0cy5nZXRGaWxlTmFtZSA9IGZ1bmN0aW9uKHJhd0Vudil7XG4gICAgdmFyIGVudiA9IHJhd0VudiB8fCBwcm9jZXNzLmVudjtcbiAgICB2YXIgZmlsZSA9IGVudi5QR1BBU1NGSUxFIHx8IChcbiAgICAgICAgaXNXaW4gP1xuICAgICAgICAgIHBhdGguam9pbiggZW52LkFQUERBVEEgfHwgJy4vJyAsICdwb3N0Z3Jlc3FsJywgJ3BncGFzcy5jb25mJyApIDpcbiAgICAgICAgICBwYXRoLmpvaW4oIGVudi5IT01FIHx8ICcuLycsICcucGdwYXNzJyApXG4gICAgKTtcbiAgICByZXR1cm4gZmlsZTtcbn07XG5cbm1vZHVsZS5leHBvcnRzLnVzZVBnUGFzcyA9IGZ1bmN0aW9uKHN0YXRzLCBmbmFtZSkge1xuICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwocHJvY2Vzcy5lbnYsICdQR1BBU1NXT1JEJykpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIGlmIChpc1dpbikge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG5cbiAgICBmbmFtZSA9IGZuYW1lIHx8ICc8dW5rbj4nO1xuXG4gICAgaWYgKCEgaXNSZWdGaWxlKHN0YXRzLm1vZGUpKSB7XG4gICAgICAgIHdhcm4oJ1dBUk5JTkc6IHBhc3N3b3JkIGZpbGUgXCIlc1wiIGlzIG5vdCBhIHBsYWluIGZpbGUnLCBmbmFtZSk7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICBpZiAoc3RhdHMubW9kZSAmIChTX0lSV1hHIHwgU19JUldYTykpIHtcbiAgICAgICAgLyogSWYgcGFzc3dvcmQgZmlsZSBpcyBpbnNlY3VyZSwgYWxlcnQgdGhlIHVzZXIgYW5kIGlnbm9yZSBpdC4gKi9cbiAgICAgICAgd2FybignV0FSTklORzogcGFzc3dvcmQgZmlsZSBcIiVzXCIgaGFzIGdyb3VwIG9yIHdvcmxkIGFjY2VzczsgcGVybWlzc2lvbnMgc2hvdWxkIGJlIHU9cncgKDA2MDApIG9yIGxlc3MnLCBmbmFtZSk7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICByZXR1cm4gdHJ1ZTtcbn07XG5cblxudmFyIG1hdGNoZXIgPSBtb2R1bGUuZXhwb3J0cy5tYXRjaCA9IGZ1bmN0aW9uKGNvbm5JbmZvLCBlbnRyeSkge1xuICAgIHJldHVybiBmaWVsZE5hbWVzLnNsaWNlKDAsIC0xKS5yZWR1Y2UoZnVuY3Rpb24ocHJldiwgZmllbGQsIGlkeCl7XG4gICAgICAgIGlmIChpZHggPT0gMSkge1xuICAgICAgICAgICAgLy8gdGhlIHBvcnRcbiAgICAgICAgICAgIGlmICggTnVtYmVyKCBjb25uSW5mb1tmaWVsZF0gfHwgZGVmYXVsdFBvcnQgKSA9PT0gTnVtYmVyKCBlbnRyeVtmaWVsZF0gKSApIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gcHJldiAmJiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBwcmV2ICYmIChcbiAgICAgICAgICAgIGVudHJ5W2ZpZWxkXSA9PT0gJyonIHx8XG4gICAgICAgICAgICAgIGVudHJ5W2ZpZWxkXSA9PT0gY29ubkluZm9bZmllbGRdXG4gICAgICAgICk7XG4gICAgfSwgdHJ1ZSk7XG59O1xuXG5cbm1vZHVsZS5leHBvcnRzLmdldFBhc3N3b3JkID0gZnVuY3Rpb24oY29ubkluZm8sIHN0cmVhbSwgY2IpIHtcbiAgICB2YXIgcGFzcztcbiAgICB2YXIgbGluZVN0cmVhbSA9IHN0cmVhbS5waXBlKHNwbGl0KCkpO1xuXG4gICAgZnVuY3Rpb24gb25MaW5lKGxpbmUpIHtcbiAgICAgICAgdmFyIGVudHJ5ID0gcGFyc2VMaW5lKGxpbmUpO1xuICAgICAgICBpZiAoZW50cnkgJiYgaXNWYWxpZEVudHJ5KGVudHJ5KSAmJiBtYXRjaGVyKGNvbm5JbmZvLCBlbnRyeSkpIHtcbiAgICAgICAgICAgIHBhc3MgPSBlbnRyeVtwYXNzS2V5XTtcbiAgICAgICAgICAgIGxpbmVTdHJlYW0uZW5kKCk7IC8vIC0+IGNhbGxzIG9uRW5kKCksIGJ1dCBwYXNzIGlzIHNldCBub3dcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHZhciBvbkVuZCA9IGZ1bmN0aW9uKCkge1xuICAgICAgICBzdHJlYW0uZGVzdHJveSgpO1xuICAgICAgICBjYihwYXNzKTtcbiAgICB9O1xuXG4gICAgdmFyIG9uRXJyID0gZnVuY3Rpb24oZXJyKSB7XG4gICAgICAgIHN0cmVhbS5kZXN0cm95KCk7XG4gICAgICAgIHdhcm4oJ1dBUk5JTkc6IGVycm9yIG9uIHJlYWRpbmcgZmlsZTogJXMnLCBlcnIpO1xuICAgICAgICBjYih1bmRlZmluZWQpO1xuICAgIH07XG5cbiAgICBzdHJlYW0ub24oJ2Vycm9yJywgb25FcnIpO1xuICAgIGxpbmVTdHJlYW1cbiAgICAgICAgLm9uKCdkYXRhJywgb25MaW5lKVxuICAgICAgICAub24oJ2VuZCcsIG9uRW5kKVxuICAgICAgICAub24oJ2Vycm9yJywgb25FcnIpXG4gICAgO1xuXG59O1xuXG5cbnZhciBwYXJzZUxpbmUgPSBtb2R1bGUuZXhwb3J0cy5wYXJzZUxpbmUgPSBmdW5jdGlvbihsaW5lKSB7XG4gICAgaWYgKGxpbmUubGVuZ3RoIDwgMTEgfHwgbGluZS5tYXRjaCgvXlxccysjLykpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuXG4gICAgdmFyIGN1ckNoYXIgPSAnJztcbiAgICB2YXIgcHJldkNoYXIgPSAnJztcbiAgICB2YXIgZmllbGRJZHggPSAwO1xuICAgIHZhciBzdGFydElkeCA9IDA7XG4gICAgdmFyIGVuZElkeCA9IDA7XG4gICAgdmFyIG9iaiA9IHt9O1xuICAgIHZhciBpc0xhc3RGaWVsZCA9IGZhbHNlO1xuICAgIHZhciBhZGRUb09iaiA9IGZ1bmN0aW9uKGlkeCwgaTAsIGkxKSB7XG4gICAgICAgIHZhciBmaWVsZCA9IGxpbmUuc3Vic3RyaW5nKGkwLCBpMSk7XG5cbiAgICAgICAgaWYgKCEgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwocHJvY2Vzcy5lbnYsICdQR1BBU1NfTk9fREVFU0NBUEUnKSkge1xuICAgICAgICAgICAgZmllbGQgPSBmaWVsZC5yZXBsYWNlKC9cXFxcKFs6XFxcXF0pL2csICckMScpO1xuICAgICAgICB9XG5cbiAgICAgICAgb2JqWyBmaWVsZE5hbWVzW2lkeF0gXSA9IGZpZWxkO1xuICAgIH07XG5cbiAgICBmb3IgKHZhciBpID0gMCA7IGkgPCBsaW5lLmxlbmd0aC0xIDsgaSArPSAxKSB7XG4gICAgICAgIGN1ckNoYXIgPSBsaW5lLmNoYXJBdChpKzEpO1xuICAgICAgICBwcmV2Q2hhciA9IGxpbmUuY2hhckF0KGkpO1xuXG4gICAgICAgIGlzTGFzdEZpZWxkID0gKGZpZWxkSWR4ID09IG5yT2ZGaWVsZHMtMSk7XG5cbiAgICAgICAgaWYgKGlzTGFzdEZpZWxkKSB7XG4gICAgICAgICAgICBhZGRUb09iaihmaWVsZElkeCwgc3RhcnRJZHgpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoaSA+PSAwICYmIGN1ckNoYXIgPT0gJzonICYmIHByZXZDaGFyICE9PSAnXFxcXCcpIHtcbiAgICAgICAgICAgIGFkZFRvT2JqKGZpZWxkSWR4LCBzdGFydElkeCwgaSsxKTtcblxuICAgICAgICAgICAgc3RhcnRJZHggPSBpKzI7XG4gICAgICAgICAgICBmaWVsZElkeCArPSAxO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgb2JqID0gKCBPYmplY3Qua2V5cyhvYmopLmxlbmd0aCA9PT0gbnJPZkZpZWxkcyApID8gb2JqIDogbnVsbDtcblxuICAgIHJldHVybiBvYmo7XG59O1xuXG5cbnZhciBpc1ZhbGlkRW50cnkgPSBtb2R1bGUuZXhwb3J0cy5pc1ZhbGlkRW50cnkgPSBmdW5jdGlvbihlbnRyeSl7XG4gICAgdmFyIHJ1bGVzID0ge1xuICAgICAgICAvLyBob3N0XG4gICAgICAgIDAgOiBmdW5jdGlvbih4KXtcbiAgICAgICAgICAgIHJldHVybiB4Lmxlbmd0aCA+IDA7XG4gICAgICAgIH0gLFxuICAgICAgICAvLyBwb3J0XG4gICAgICAgIDEgOiBmdW5jdGlvbih4KXtcbiAgICAgICAgICAgIGlmICh4ID09PSAnKicpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHggPSBOdW1iZXIoeCk7XG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIGlzRmluaXRlKHgpICYmXG4gICAgICAgICAgICAgICAgICB4ID4gMCAmJlxuICAgICAgICAgICAgICAgICAgeCA8IDkwMDcxOTkyNTQ3NDA5OTIgJiZcbiAgICAgICAgICAgICAgICAgIE1hdGguZmxvb3IoeCkgPT09IHhcbiAgICAgICAgICAgICk7XG4gICAgICAgIH0gLFxuICAgICAgICAvLyBkYXRhYmFzZVxuICAgICAgICAyIDogZnVuY3Rpb24oeCl7XG4gICAgICAgICAgICByZXR1cm4geC5sZW5ndGggPiAwO1xuICAgICAgICB9ICxcbiAgICAgICAgLy8gdXNlcm5hbWVcbiAgICAgICAgMyA6IGZ1bmN0aW9uKHgpe1xuICAgICAgICAgICAgcmV0dXJuIHgubGVuZ3RoID4gMDtcbiAgICAgICAgfSAsXG4gICAgICAgIC8vIHBhc3N3b3JkXG4gICAgICAgIDQgOiBmdW5jdGlvbih4KXtcbiAgICAgICAgICAgIHJldHVybiB4Lmxlbmd0aCA+IDA7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgZm9yICh2YXIgaWR4ID0gMCA7IGlkeCA8IGZpZWxkTmFtZXMubGVuZ3RoIDsgaWR4ICs9IDEpIHtcbiAgICAgICAgdmFyIHJ1bGUgPSBydWxlc1tpZHhdO1xuICAgICAgICB2YXIgdmFsdWUgPSBlbnRyeVsgZmllbGROYW1lc1tpZHhdIF0gfHwgJyc7XG5cbiAgICAgICAgdmFyIHJlcyA9IHJ1bGUodmFsdWUpO1xuICAgICAgICBpZiAoIXJlcykge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHRydWU7XG59O1xuXG4iLCIndXNlIHN0cmljdCc7XG5cbnZhciBwYXRoID0gcmVxdWlyZSgncGF0aCcpXG4gICwgZnMgPSByZXF1aXJlKCdmcycpXG4gICwgaGVscGVyID0gcmVxdWlyZSgnLi9oZWxwZXIuanMnKVxuO1xuXG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24oY29ubkluZm8sIGNiKSB7XG4gICAgdmFyIGZpbGUgPSBoZWxwZXIuZ2V0RmlsZU5hbWUoKTtcbiAgICBcbiAgICBmcy5zdGF0KGZpbGUsIGZ1bmN0aW9uKGVyciwgc3RhdCl7XG4gICAgICAgIGlmIChlcnIgfHwgIWhlbHBlci51c2VQZ1Bhc3Moc3RhdCwgZmlsZSkpIHtcbiAgICAgICAgICAgIHJldHVybiBjYih1bmRlZmluZWQpO1xuICAgICAgICB9XG5cbiAgICAgICAgdmFyIHN0ID0gZnMuY3JlYXRlUmVhZFN0cmVhbShmaWxlKTtcblxuICAgICAgICBoZWxwZXIuZ2V0UGFzc3dvcmQoY29ubkluZm8sIHN0LCBjYik7XG4gICAgfSk7XG59O1xuXG5tb2R1bGUuZXhwb3J0cy53YXJuVG8gPSBoZWxwZXIud2FyblRvO1xuIiwiJ3VzZSBzdHJpY3QnXG5cbmV4cG9ydHMucGFyc2UgPSBmdW5jdGlvbiAoc291cmNlLCB0cmFuc2Zvcm0pIHtcbiAgcmV0dXJuIG5ldyBBcnJheVBhcnNlcihzb3VyY2UsIHRyYW5zZm9ybSkucGFyc2UoKVxufVxuXG5jbGFzcyBBcnJheVBhcnNlciB7XG4gIGNvbnN0cnVjdG9yIChzb3VyY2UsIHRyYW5zZm9ybSkge1xuICAgIHRoaXMuc291cmNlID0gc291cmNlXG4gICAgdGhpcy50cmFuc2Zvcm0gPSB0cmFuc2Zvcm0gfHwgaWRlbnRpdHlcbiAgICB0aGlzLnBvc2l0aW9uID0gMFxuICAgIHRoaXMuZW50cmllcyA9IFtdXG4gICAgdGhpcy5yZWNvcmRlZCA9IFtdXG4gICAgdGhpcy5kaW1lbnNpb24gPSAwXG4gIH1cblxuICBpc0VvZiAoKSB7XG4gICAgcmV0dXJuIHRoaXMucG9zaXRpb24gPj0gdGhpcy5zb3VyY2UubGVuZ3RoXG4gIH1cblxuICBuZXh0Q2hhcmFjdGVyICgpIHtcbiAgICB2YXIgY2hhcmFjdGVyID0gdGhpcy5zb3VyY2VbdGhpcy5wb3NpdGlvbisrXVxuICAgIGlmIChjaGFyYWN0ZXIgPT09ICdcXFxcJykge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdmFsdWU6IHRoaXMuc291cmNlW3RoaXMucG9zaXRpb24rK10sXG4gICAgICAgIGVzY2FwZWQ6IHRydWVcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIHZhbHVlOiBjaGFyYWN0ZXIsXG4gICAgICBlc2NhcGVkOiBmYWxzZVxuICAgIH1cbiAgfVxuXG4gIHJlY29yZCAoY2hhcmFjdGVyKSB7XG4gICAgdGhpcy5yZWNvcmRlZC5wdXNoKGNoYXJhY3RlcilcbiAgfVxuXG4gIG5ld0VudHJ5IChpbmNsdWRlRW1wdHkpIHtcbiAgICB2YXIgZW50cnlcbiAgICBpZiAodGhpcy5yZWNvcmRlZC5sZW5ndGggPiAwIHx8IGluY2x1ZGVFbXB0eSkge1xuICAgICAgZW50cnkgPSB0aGlzLnJlY29yZGVkLmpvaW4oJycpXG4gICAgICBpZiAoZW50cnkgPT09ICdOVUxMJyAmJiAhaW5jbHVkZUVtcHR5KSB7XG4gICAgICAgIGVudHJ5ID0gbnVsbFxuICAgICAgfVxuICAgICAgaWYgKGVudHJ5ICE9PSBudWxsKSBlbnRyeSA9IHRoaXMudHJhbnNmb3JtKGVudHJ5KVxuICAgICAgdGhpcy5lbnRyaWVzLnB1c2goZW50cnkpXG4gICAgICB0aGlzLnJlY29yZGVkID0gW11cbiAgICB9XG4gIH1cblxuICBjb25zdW1lRGltZW5zaW9ucyAoKSB7XG4gICAgaWYgKHRoaXMuc291cmNlWzBdID09PSAnWycpIHtcbiAgICAgIHdoaWxlICghdGhpcy5pc0VvZigpKSB7XG4gICAgICAgIHZhciBjaGFyID0gdGhpcy5uZXh0Q2hhcmFjdGVyKClcbiAgICAgICAgaWYgKGNoYXIudmFsdWUgPT09ICc9JykgYnJlYWtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBwYXJzZSAobmVzdGVkKSB7XG4gICAgdmFyIGNoYXJhY3RlciwgcGFyc2VyLCBxdW90ZVxuICAgIHRoaXMuY29uc3VtZURpbWVuc2lvbnMoKVxuICAgIHdoaWxlICghdGhpcy5pc0VvZigpKSB7XG4gICAgICBjaGFyYWN0ZXIgPSB0aGlzLm5leHRDaGFyYWN0ZXIoKVxuICAgICAgaWYgKGNoYXJhY3Rlci52YWx1ZSA9PT0gJ3snICYmICFxdW90ZSkge1xuICAgICAgICB0aGlzLmRpbWVuc2lvbisrXG4gICAgICAgIGlmICh0aGlzLmRpbWVuc2lvbiA+IDEpIHtcbiAgICAgICAgICBwYXJzZXIgPSBuZXcgQXJyYXlQYXJzZXIodGhpcy5zb3VyY2Uuc3Vic3RyKHRoaXMucG9zaXRpb24gLSAxKSwgdGhpcy50cmFuc2Zvcm0pXG4gICAgICAgICAgdGhpcy5lbnRyaWVzLnB1c2gocGFyc2VyLnBhcnNlKHRydWUpKVxuICAgICAgICAgIHRoaXMucG9zaXRpb24gKz0gcGFyc2VyLnBvc2l0aW9uIC0gMlxuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKGNoYXJhY3Rlci52YWx1ZSA9PT0gJ30nICYmICFxdW90ZSkge1xuICAgICAgICB0aGlzLmRpbWVuc2lvbi0tXG4gICAgICAgIGlmICghdGhpcy5kaW1lbnNpb24pIHtcbiAgICAgICAgICB0aGlzLm5ld0VudHJ5KClcbiAgICAgICAgICBpZiAobmVzdGVkKSByZXR1cm4gdGhpcy5lbnRyaWVzXG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoY2hhcmFjdGVyLnZhbHVlID09PSAnXCInICYmICFjaGFyYWN0ZXIuZXNjYXBlZCkge1xuICAgICAgICBpZiAocXVvdGUpIHRoaXMubmV3RW50cnkodHJ1ZSlcbiAgICAgICAgcXVvdGUgPSAhcXVvdGVcbiAgICAgIH0gZWxzZSBpZiAoY2hhcmFjdGVyLnZhbHVlID09PSAnLCcgJiYgIXF1b3RlKSB7XG4gICAgICAgIHRoaXMubmV3RW50cnkoKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5yZWNvcmQoY2hhcmFjdGVyLnZhbHVlKVxuICAgICAgfVxuICAgIH1cbiAgICBpZiAodGhpcy5kaW1lbnNpb24gIT09IDApIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignYXJyYXkgZGltZW5zaW9uIG5vdCBiYWxhbmNlZCcpXG4gICAgfVxuICAgIHJldHVybiB0aGlzLmVudHJpZXNcbiAgfVxufVxuXG5mdW5jdGlvbiBpZGVudGl0eSAodmFsdWUpIHtcbiAgcmV0dXJuIHZhbHVlXG59XG4iLCIndXNlIHN0cmljdCdcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBwYXJzZUJ5dGVhIChpbnB1dCkge1xuICBpZiAoL15cXFxceC8udGVzdChpbnB1dCkpIHtcbiAgICAvLyBuZXcgJ2hleCcgc3R5bGUgcmVzcG9uc2UgKHBnID45LjApXG4gICAgcmV0dXJuIG5ldyBCdWZmZXIoaW5wdXQuc3Vic3RyKDIpLCAnaGV4JylcbiAgfVxuICB2YXIgb3V0cHV0ID0gJydcbiAgdmFyIGkgPSAwXG4gIHdoaWxlIChpIDwgaW5wdXQubGVuZ3RoKSB7XG4gICAgaWYgKGlucHV0W2ldICE9PSAnXFxcXCcpIHtcbiAgICAgIG91dHB1dCArPSBpbnB1dFtpXVxuICAgICAgKytpXG4gICAgfSBlbHNlIHtcbiAgICAgIGlmICgvWzAtN117M30vLnRlc3QoaW5wdXQuc3Vic3RyKGkgKyAxLCAzKSkpIHtcbiAgICAgICAgb3V0cHV0ICs9IFN0cmluZy5mcm9tQ2hhckNvZGUocGFyc2VJbnQoaW5wdXQuc3Vic3RyKGkgKyAxLCAzKSwgOCkpXG4gICAgICAgIGkgKz0gNFxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdmFyIGJhY2tzbGFzaGVzID0gMVxuICAgICAgICB3aGlsZSAoaSArIGJhY2tzbGFzaGVzIDwgaW5wdXQubGVuZ3RoICYmIGlucHV0W2kgKyBiYWNrc2xhc2hlc10gPT09ICdcXFxcJykge1xuICAgICAgICAgIGJhY2tzbGFzaGVzKytcbiAgICAgICAgfVxuICAgICAgICBmb3IgKHZhciBrID0gMDsgayA8IE1hdGguZmxvb3IoYmFja3NsYXNoZXMgLyAyKTsgKytrKSB7XG4gICAgICAgICAgb3V0cHV0ICs9ICdcXFxcJ1xuICAgICAgICB9XG4gICAgICAgIGkgKz0gTWF0aC5mbG9vcihiYWNrc2xhc2hlcyAvIDIpICogMlxuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gbmV3IEJ1ZmZlcihvdXRwdXQsICdiaW5hcnknKVxufVxuIiwiJ3VzZSBzdHJpY3QnXG5cbnZhciBEQVRFX1RJTUUgPSAvKFxcZHsxLH0pLShcXGR7Mn0pLShcXGR7Mn0pIChcXGR7Mn0pOihcXGR7Mn0pOihcXGR7Mn0pKFxcLlxcZHsxLH0pPy4qPyggQkMpPyQvXG52YXIgREFURSA9IC9eKFxcZHsxLH0pLShcXGR7Mn0pLShcXGR7Mn0pKCBCQyk/JC9cbnZhciBUSU1FX1pPTkUgPSAvKFtaKy1dKShcXGR7Mn0pPzo/KFxcZHsyfSk/Oj8oXFxkezJ9KT8vXG52YXIgSU5GSU5JVFkgPSAvXi0/aW5maW5pdHkkL1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIHBhcnNlRGF0ZSAoaXNvRGF0ZSkge1xuICBpZiAoSU5GSU5JVFkudGVzdChpc29EYXRlKSkge1xuICAgIC8vIENhcGl0YWxpemUgdG8gSW5maW5pdHkgYmVmb3JlIHBhc3NpbmcgdG8gTnVtYmVyXG4gICAgcmV0dXJuIE51bWJlcihpc29EYXRlLnJlcGxhY2UoJ2knLCAnSScpKVxuICB9XG4gIHZhciBtYXRjaGVzID0gREFURV9USU1FLmV4ZWMoaXNvRGF0ZSlcblxuICBpZiAoIW1hdGNoZXMpIHtcbiAgICAvLyBGb3JjZSBZWVlZLU1NLUREIGRhdGVzIHRvIGJlIHBhcnNlZCBhcyBsb2NhbCB0aW1lXG4gICAgcmV0dXJuIGdldERhdGUoaXNvRGF0ZSkgfHwgbnVsbFxuICB9XG5cbiAgdmFyIGlzQkMgPSAhIW1hdGNoZXNbOF1cbiAgdmFyIHllYXIgPSBwYXJzZUludChtYXRjaGVzWzFdLCAxMClcbiAgaWYgKGlzQkMpIHtcbiAgICB5ZWFyID0gYmNZZWFyVG9OZWdhdGl2ZVllYXIoeWVhcilcbiAgfVxuXG4gIHZhciBtb250aCA9IHBhcnNlSW50KG1hdGNoZXNbMl0sIDEwKSAtIDFcbiAgdmFyIGRheSA9IG1hdGNoZXNbM11cbiAgdmFyIGhvdXIgPSBwYXJzZUludChtYXRjaGVzWzRdLCAxMClcbiAgdmFyIG1pbnV0ZSA9IHBhcnNlSW50KG1hdGNoZXNbNV0sIDEwKVxuICB2YXIgc2Vjb25kID0gcGFyc2VJbnQobWF0Y2hlc1s2XSwgMTApXG5cbiAgdmFyIG1zID0gbWF0Y2hlc1s3XVxuICBtcyA9IG1zID8gMTAwMCAqIHBhcnNlRmxvYXQobXMpIDogMFxuXG4gIHZhciBkYXRlXG4gIHZhciBvZmZzZXQgPSB0aW1lWm9uZU9mZnNldChpc29EYXRlKVxuICBpZiAob2Zmc2V0ICE9IG51bGwpIHtcbiAgICBkYXRlID0gbmV3IERhdGUoRGF0ZS5VVEMoeWVhciwgbW9udGgsIGRheSwgaG91ciwgbWludXRlLCBzZWNvbmQsIG1zKSlcblxuICAgIC8vIEFjY291bnQgZm9yIHllYXJzIGZyb20gMCB0byA5OSBiZWluZyBpbnRlcnByZXRlZCBhcyAxOTAwLTE5OTlcbiAgICAvLyBieSBEYXRlLlVUQyAvIHRoZSBtdWx0aS1hcmd1bWVudCBmb3JtIG9mIHRoZSBEYXRlIGNvbnN0cnVjdG9yXG4gICAgaWYgKGlzMFRvOTkoeWVhcikpIHtcbiAgICAgIGRhdGUuc2V0VVRDRnVsbFllYXIoeWVhcilcbiAgICB9XG5cbiAgICBpZiAob2Zmc2V0ICE9PSAwKSB7XG4gICAgICBkYXRlLnNldFRpbWUoZGF0ZS5nZXRUaW1lKCkgLSBvZmZzZXQpXG4gICAgfVxuICB9IGVsc2Uge1xuICAgIGRhdGUgPSBuZXcgRGF0ZSh5ZWFyLCBtb250aCwgZGF5LCBob3VyLCBtaW51dGUsIHNlY29uZCwgbXMpXG5cbiAgICBpZiAoaXMwVG85OSh5ZWFyKSkge1xuICAgICAgZGF0ZS5zZXRGdWxsWWVhcih5ZWFyKVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiBkYXRlXG59XG5cbmZ1bmN0aW9uIGdldERhdGUgKGlzb0RhdGUpIHtcbiAgdmFyIG1hdGNoZXMgPSBEQVRFLmV4ZWMoaXNvRGF0ZSlcbiAgaWYgKCFtYXRjaGVzKSB7XG4gICAgcmV0dXJuXG4gIH1cblxuICB2YXIgeWVhciA9IHBhcnNlSW50KG1hdGNoZXNbMV0sIDEwKVxuICB2YXIgaXNCQyA9ICEhbWF0Y2hlc1s0XVxuICBpZiAoaXNCQykge1xuICAgIHllYXIgPSBiY1llYXJUb05lZ2F0aXZlWWVhcih5ZWFyKVxuICB9XG5cbiAgdmFyIG1vbnRoID0gcGFyc2VJbnQobWF0Y2hlc1syXSwgMTApIC0gMVxuICB2YXIgZGF5ID0gbWF0Y2hlc1szXVxuICAvLyBZWVlZLU1NLUREIHdpbGwgYmUgcGFyc2VkIGFzIGxvY2FsIHRpbWVcbiAgdmFyIGRhdGUgPSBuZXcgRGF0ZSh5ZWFyLCBtb250aCwgZGF5KVxuXG4gIGlmIChpczBUbzk5KHllYXIpKSB7XG4gICAgZGF0ZS5zZXRGdWxsWWVhcih5ZWFyKVxuICB9XG5cbiAgcmV0dXJuIGRhdGVcbn1cblxuLy8gbWF0Y2ggdGltZXpvbmVzOlxuLy8gWiAoVVRDKVxuLy8gLTA1XG4vLyArMDY6MzBcbmZ1bmN0aW9uIHRpbWVab25lT2Zmc2V0IChpc29EYXRlKSB7XG4gIGlmIChpc29EYXRlLmVuZHNXaXRoKCcrMDAnKSkge1xuICAgIHJldHVybiAwXG4gIH1cblxuICB2YXIgem9uZSA9IFRJTUVfWk9ORS5leGVjKGlzb0RhdGUuc3BsaXQoJyAnKVsxXSlcbiAgaWYgKCF6b25lKSByZXR1cm5cbiAgdmFyIHR5cGUgPSB6b25lWzFdXG5cbiAgaWYgKHR5cGUgPT09ICdaJykge1xuICAgIHJldHVybiAwXG4gIH1cbiAgdmFyIHNpZ24gPSB0eXBlID09PSAnLScgPyAtMSA6IDFcbiAgdmFyIG9mZnNldCA9IHBhcnNlSW50KHpvbmVbMl0sIDEwKSAqIDM2MDAgK1xuICAgIHBhcnNlSW50KHpvbmVbM10gfHwgMCwgMTApICogNjAgK1xuICAgIHBhcnNlSW50KHpvbmVbNF0gfHwgMCwgMTApXG5cbiAgcmV0dXJuIG9mZnNldCAqIHNpZ24gKiAxMDAwXG59XG5cbmZ1bmN0aW9uIGJjWWVhclRvTmVnYXRpdmVZZWFyICh5ZWFyKSB7XG4gIC8vIEFjY291bnQgZm9yIG51bWVyaWNhbCBkaWZmZXJlbmNlIGJldHdlZW4gcmVwcmVzZW50YXRpb25zIG9mIEJDIHllYXJzXG4gIC8vIFNlZTogaHR0cHM6Ly9naXRodWIuY29tL2JlbmRydWNrZXIvcG9zdGdyZXMtZGF0ZS9pc3N1ZXMvNVxuICByZXR1cm4gLSh5ZWFyIC0gMSlcbn1cblxuZnVuY3Rpb24gaXMwVG85OSAobnVtKSB7XG4gIHJldHVybiBudW0gPj0gMCAmJiBudW0gPCAxMDBcbn1cbiIsIid1c2Ugc3RyaWN0J1xuXG52YXIgZXh0ZW5kID0gcmVxdWlyZSgneHRlbmQvbXV0YWJsZScpXG5cbm1vZHVsZS5leHBvcnRzID0gUG9zdGdyZXNJbnRlcnZhbFxuXG5mdW5jdGlvbiBQb3N0Z3Jlc0ludGVydmFsIChyYXcpIHtcbiAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIFBvc3RncmVzSW50ZXJ2YWwpKSB7XG4gICAgcmV0dXJuIG5ldyBQb3N0Z3Jlc0ludGVydmFsKHJhdylcbiAgfVxuICBleHRlbmQodGhpcywgcGFyc2UocmF3KSlcbn1cbnZhciBwcm9wZXJ0aWVzID0gWydzZWNvbmRzJywgJ21pbnV0ZXMnLCAnaG91cnMnLCAnZGF5cycsICdtb250aHMnLCAneWVhcnMnXVxuUG9zdGdyZXNJbnRlcnZhbC5wcm90b3R5cGUudG9Qb3N0Z3JlcyA9IGZ1bmN0aW9uICgpIHtcbiAgdmFyIGZpbHRlcmVkID0gcHJvcGVydGllcy5maWx0ZXIodGhpcy5oYXNPd25Qcm9wZXJ0eSwgdGhpcylcblxuICAvLyBJbiBhZGRpdGlvbiB0byBgcHJvcGVydGllc2AsIHdlIG5lZWQgdG8gYWNjb3VudCBmb3IgZnJhY3Rpb25zIG9mIHNlY29uZHMuXG4gIGlmICh0aGlzLm1pbGxpc2Vjb25kcyAmJiBmaWx0ZXJlZC5pbmRleE9mKCdzZWNvbmRzJykgPCAwKSB7XG4gICAgZmlsdGVyZWQucHVzaCgnc2Vjb25kcycpXG4gIH1cblxuICBpZiAoZmlsdGVyZWQubGVuZ3RoID09PSAwKSByZXR1cm4gJzAnXG4gIHJldHVybiBmaWx0ZXJlZFxuICAgIC5tYXAoZnVuY3Rpb24gKHByb3BlcnR5KSB7XG4gICAgICB2YXIgdmFsdWUgPSB0aGlzW3Byb3BlcnR5XSB8fCAwXG5cbiAgICAgIC8vIEFjY291bnQgZm9yIGZyYWN0aW9uYWwgcGFydCBvZiBzZWNvbmRzLFxuICAgICAgLy8gcmVtb3ZlIHRyYWlsaW5nIHplcm9lcy5cbiAgICAgIGlmIChwcm9wZXJ0eSA9PT0gJ3NlY29uZHMnICYmIHRoaXMubWlsbGlzZWNvbmRzKSB7XG4gICAgICAgIHZhbHVlID0gKHZhbHVlICsgdGhpcy5taWxsaXNlY29uZHMgLyAxMDAwKS50b0ZpeGVkKDYpLnJlcGxhY2UoL1xcLj8wKyQvLCAnJylcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHZhbHVlICsgJyAnICsgcHJvcGVydHlcbiAgICB9LCB0aGlzKVxuICAgIC5qb2luKCcgJylcbn1cblxudmFyIHByb3BlcnRpZXNJU09FcXVpdmFsZW50ID0ge1xuICB5ZWFyczogJ1knLFxuICBtb250aHM6ICdNJyxcbiAgZGF5czogJ0QnLFxuICBob3VyczogJ0gnLFxuICBtaW51dGVzOiAnTScsXG4gIHNlY29uZHM6ICdTJ1xufVxudmFyIGRhdGVQcm9wZXJ0aWVzID0gWyd5ZWFycycsICdtb250aHMnLCAnZGF5cyddXG52YXIgdGltZVByb3BlcnRpZXMgPSBbJ2hvdXJzJywgJ21pbnV0ZXMnLCAnc2Vjb25kcyddXG4vLyBhY2NvcmRpbmcgdG8gSVNPIDg2MDFcblBvc3RncmVzSW50ZXJ2YWwucHJvdG90eXBlLnRvSVNPU3RyaW5nID0gUG9zdGdyZXNJbnRlcnZhbC5wcm90b3R5cGUudG9JU08gPSBmdW5jdGlvbiAoKSB7XG4gIHZhciBkYXRlUGFydCA9IGRhdGVQcm9wZXJ0aWVzXG4gICAgLm1hcChidWlsZFByb3BlcnR5LCB0aGlzKVxuICAgIC5qb2luKCcnKVxuXG4gIHZhciB0aW1lUGFydCA9IHRpbWVQcm9wZXJ0aWVzXG4gICAgLm1hcChidWlsZFByb3BlcnR5LCB0aGlzKVxuICAgIC5qb2luKCcnKVxuXG4gIHJldHVybiAnUCcgKyBkYXRlUGFydCArICdUJyArIHRpbWVQYXJ0XG5cbiAgZnVuY3Rpb24gYnVpbGRQcm9wZXJ0eSAocHJvcGVydHkpIHtcbiAgICB2YXIgdmFsdWUgPSB0aGlzW3Byb3BlcnR5XSB8fCAwXG5cbiAgICAvLyBBY2NvdW50IGZvciBmcmFjdGlvbmFsIHBhcnQgb2Ygc2Vjb25kcyxcbiAgICAvLyByZW1vdmUgdHJhaWxpbmcgemVyb2VzLlxuICAgIGlmIChwcm9wZXJ0eSA9PT0gJ3NlY29uZHMnICYmIHRoaXMubWlsbGlzZWNvbmRzKSB7XG4gICAgICB2YWx1ZSA9ICh2YWx1ZSArIHRoaXMubWlsbGlzZWNvbmRzIC8gMTAwMCkudG9GaXhlZCg2KS5yZXBsYWNlKC8wKyQvLCAnJylcbiAgICB9XG5cbiAgICByZXR1cm4gdmFsdWUgKyBwcm9wZXJ0aWVzSVNPRXF1aXZhbGVudFtwcm9wZXJ0eV1cbiAgfVxufVxuXG52YXIgTlVNQkVSID0gJyhbKy1dP1xcXFxkKyknXG52YXIgWUVBUiA9IE5VTUJFUiArICdcXFxccyt5ZWFycz8nXG52YXIgTU9OVEggPSBOVU1CRVIgKyAnXFxcXHMrbW9ucz8nXG52YXIgREFZID0gTlVNQkVSICsgJ1xcXFxzK2RheXM/J1xudmFyIFRJTUUgPSAnKFsrLV0pPyhbXFxcXGRdKik6KFxcXFxkXFxcXGQpOihcXFxcZFxcXFxkKVxcXFwuPyhcXFxcZHsxLDZ9KT8nXG52YXIgSU5URVJWQUwgPSBuZXcgUmVnRXhwKFtZRUFSLCBNT05USCwgREFZLCBUSU1FXS5tYXAoZnVuY3Rpb24gKHJlZ2V4U3RyaW5nKSB7XG4gIHJldHVybiAnKCcgKyByZWdleFN0cmluZyArICcpPydcbn0pXG4gIC5qb2luKCdcXFxccyonKSlcblxuLy8gUG9zaXRpb25zIG9mIHZhbHVlcyBpbiByZWdleCBtYXRjaFxudmFyIHBvc2l0aW9ucyA9IHtcbiAgeWVhcnM6IDIsXG4gIG1vbnRoczogNCxcbiAgZGF5czogNixcbiAgaG91cnM6IDksXG4gIG1pbnV0ZXM6IDEwLFxuICBzZWNvbmRzOiAxMSxcbiAgbWlsbGlzZWNvbmRzOiAxMlxufVxuLy8gV2UgY2FuIHVzZSBuZWdhdGl2ZSB0aW1lXG52YXIgbmVnYXRpdmVzID0gWydob3VycycsICdtaW51dGVzJywgJ3NlY29uZHMnLCAnbWlsbGlzZWNvbmRzJ11cblxuZnVuY3Rpb24gcGFyc2VNaWxsaXNlY29uZHMgKGZyYWN0aW9uKSB7XG4gIC8vIGFkZCBvbWl0dGVkIHplcm9lc1xuICB2YXIgbWljcm9zZWNvbmRzID0gZnJhY3Rpb24gKyAnMDAwMDAwJy5zbGljZShmcmFjdGlvbi5sZW5ndGgpXG4gIHJldHVybiBwYXJzZUludChtaWNyb3NlY29uZHMsIDEwKSAvIDEwMDBcbn1cblxuZnVuY3Rpb24gcGFyc2UgKGludGVydmFsKSB7XG4gIGlmICghaW50ZXJ2YWwpIHJldHVybiB7fVxuICB2YXIgbWF0Y2hlcyA9IElOVEVSVkFMLmV4ZWMoaW50ZXJ2YWwpXG4gIHZhciBpc05lZ2F0aXZlID0gbWF0Y2hlc1s4XSA9PT0gJy0nXG4gIHJldHVybiBPYmplY3Qua2V5cyhwb3NpdGlvbnMpXG4gICAgLnJlZHVjZShmdW5jdGlvbiAocGFyc2VkLCBwcm9wZXJ0eSkge1xuICAgICAgdmFyIHBvc2l0aW9uID0gcG9zaXRpb25zW3Byb3BlcnR5XVxuICAgICAgdmFyIHZhbHVlID0gbWF0Y2hlc1twb3NpdGlvbl1cbiAgICAgIC8vIG5vIGVtcHR5IHN0cmluZ1xuICAgICAgaWYgKCF2YWx1ZSkgcmV0dXJuIHBhcnNlZFxuICAgICAgLy8gbWlsbGlzZWNvbmRzIGFyZSBhY3R1YWxseSBtaWNyb3NlY29uZHMgKHVwIHRvIDYgZGlnaXRzKVxuICAgICAgLy8gd2l0aCBvbWl0dGVkIHRyYWlsaW5nIHplcm9lcy5cbiAgICAgIHZhbHVlID0gcHJvcGVydHkgPT09ICdtaWxsaXNlY29uZHMnXG4gICAgICAgID8gcGFyc2VNaWxsaXNlY29uZHModmFsdWUpXG4gICAgICAgIDogcGFyc2VJbnQodmFsdWUsIDEwKVxuICAgICAgLy8gbm8gemVyb3NcbiAgICAgIGlmICghdmFsdWUpIHJldHVybiBwYXJzZWRcbiAgICAgIGlmIChpc05lZ2F0aXZlICYmIH5uZWdhdGl2ZXMuaW5kZXhPZihwcm9wZXJ0eSkpIHtcbiAgICAgICAgdmFsdWUgKj0gLTFcbiAgICAgIH1cbiAgICAgIHBhcnNlZFtwcm9wZXJ0eV0gPSB2YWx1ZVxuICAgICAgcmV0dXJuIHBhcnNlZFxuICAgIH0sIHt9KVxufVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG5jb25zdCBjb2RlcyA9IHt9O1xuXG5mdW5jdGlvbiBjcmVhdGVFcnJvclR5cGUoY29kZSwgbWVzc2FnZSwgQmFzZSkge1xuICBpZiAoIUJhc2UpIHtcbiAgICBCYXNlID0gRXJyb3JcbiAgfVxuXG4gIGZ1bmN0aW9uIGdldE1lc3NhZ2UgKGFyZzEsIGFyZzIsIGFyZzMpIHtcbiAgICBpZiAodHlwZW9mIG1lc3NhZ2UgPT09ICdzdHJpbmcnKSB7XG4gICAgICByZXR1cm4gbWVzc2FnZVxuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gbWVzc2FnZShhcmcxLCBhcmcyLCBhcmczKVxuICAgIH1cbiAgfVxuXG4gIGNsYXNzIE5vZGVFcnJvciBleHRlbmRzIEJhc2Uge1xuICAgIGNvbnN0cnVjdG9yIChhcmcxLCBhcmcyLCBhcmczKSB7XG4gICAgICBzdXBlcihnZXRNZXNzYWdlKGFyZzEsIGFyZzIsIGFyZzMpKTtcbiAgICB9XG4gIH1cblxuICBOb2RlRXJyb3IucHJvdG90eXBlLm5hbWUgPSBCYXNlLm5hbWU7XG4gIE5vZGVFcnJvci5wcm90b3R5cGUuY29kZSA9IGNvZGU7XG5cbiAgY29kZXNbY29kZV0gPSBOb2RlRXJyb3I7XG59XG5cbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS9ub2RlanMvbm9kZS9ibG9iL3YxMC44LjAvbGliL2ludGVybmFsL2Vycm9ycy5qc1xuZnVuY3Rpb24gb25lT2YoZXhwZWN0ZWQsIHRoaW5nKSB7XG4gIGlmIChBcnJheS5pc0FycmF5KGV4cGVjdGVkKSkge1xuICAgIGNvbnN0IGxlbiA9IGV4cGVjdGVkLmxlbmd0aDtcbiAgICBleHBlY3RlZCA9IGV4cGVjdGVkLm1hcCgoaSkgPT4gU3RyaW5nKGkpKTtcbiAgICBpZiAobGVuID4gMikge1xuICAgICAgcmV0dXJuIGBvbmUgb2YgJHt0aGluZ30gJHtleHBlY3RlZC5zbGljZSgwLCBsZW4gLSAxKS5qb2luKCcsICcpfSwgb3IgYCArXG4gICAgICAgICAgICAgZXhwZWN0ZWRbbGVuIC0gMV07XG4gICAgfSBlbHNlIGlmIChsZW4gPT09IDIpIHtcbiAgICAgIHJldHVybiBgb25lIG9mICR7dGhpbmd9ICR7ZXhwZWN0ZWRbMF19IG9yICR7ZXhwZWN0ZWRbMV19YDtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIGBvZiAke3RoaW5nfSAke2V4cGVjdGVkWzBdfWA7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHJldHVybiBgb2YgJHt0aGluZ30gJHtTdHJpbmcoZXhwZWN0ZWQpfWA7XG4gIH1cbn1cblxuLy8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvSmF2YVNjcmlwdC9SZWZlcmVuY2UvR2xvYmFsX09iamVjdHMvU3RyaW5nL3N0YXJ0c1dpdGhcbmZ1bmN0aW9uIHN0YXJ0c1dpdGgoc3RyLCBzZWFyY2gsIHBvcykge1xuXHRyZXR1cm4gc3RyLnN1YnN0cighcG9zIHx8IHBvcyA8IDAgPyAwIDogK3Bvcywgc2VhcmNoLmxlbmd0aCkgPT09IHNlYXJjaDtcbn1cblxuLy8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvSmF2YVNjcmlwdC9SZWZlcmVuY2UvR2xvYmFsX09iamVjdHMvU3RyaW5nL2VuZHNXaXRoXG5mdW5jdGlvbiBlbmRzV2l0aChzdHIsIHNlYXJjaCwgdGhpc19sZW4pIHtcblx0aWYgKHRoaXNfbGVuID09PSB1bmRlZmluZWQgfHwgdGhpc19sZW4gPiBzdHIubGVuZ3RoKSB7XG5cdFx0dGhpc19sZW4gPSBzdHIubGVuZ3RoO1xuXHR9XG5cdHJldHVybiBzdHIuc3Vic3RyaW5nKHRoaXNfbGVuIC0gc2VhcmNoLmxlbmd0aCwgdGhpc19sZW4pID09PSBzZWFyY2g7XG59XG5cbi8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0phdmFTY3JpcHQvUmVmZXJlbmNlL0dsb2JhbF9PYmplY3RzL1N0cmluZy9pbmNsdWRlc1xuZnVuY3Rpb24gaW5jbHVkZXMoc3RyLCBzZWFyY2gsIHN0YXJ0KSB7XG4gIGlmICh0eXBlb2Ygc3RhcnQgIT09ICdudW1iZXInKSB7XG4gICAgc3RhcnQgPSAwO1xuICB9XG5cbiAgaWYgKHN0YXJ0ICsgc2VhcmNoLmxlbmd0aCA+IHN0ci5sZW5ndGgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIHN0ci5pbmRleE9mKHNlYXJjaCwgc3RhcnQpICE9PSAtMTtcbiAgfVxufVxuXG5jcmVhdGVFcnJvclR5cGUoJ0VSUl9JTlZBTElEX09QVF9WQUxVRScsIGZ1bmN0aW9uIChuYW1lLCB2YWx1ZSkge1xuICByZXR1cm4gJ1RoZSB2YWx1ZSBcIicgKyB2YWx1ZSArICdcIiBpcyBpbnZhbGlkIGZvciBvcHRpb24gXCInICsgbmFtZSArICdcIidcbn0sIFR5cGVFcnJvcik7XG5jcmVhdGVFcnJvclR5cGUoJ0VSUl9JTlZBTElEX0FSR19UWVBFJywgZnVuY3Rpb24gKG5hbWUsIGV4cGVjdGVkLCBhY3R1YWwpIHtcbiAgLy8gZGV0ZXJtaW5lcjogJ211c3QgYmUnIG9yICdtdXN0IG5vdCBiZSdcbiAgbGV0IGRldGVybWluZXI7XG4gIGlmICh0eXBlb2YgZXhwZWN0ZWQgPT09ICdzdHJpbmcnICYmIHN0YXJ0c1dpdGgoZXhwZWN0ZWQsICdub3QgJykpIHtcbiAgICBkZXRlcm1pbmVyID0gJ211c3Qgbm90IGJlJztcbiAgICBleHBlY3RlZCA9IGV4cGVjdGVkLnJlcGxhY2UoL15ub3QgLywgJycpO1xuICB9IGVsc2Uge1xuICAgIGRldGVybWluZXIgPSAnbXVzdCBiZSc7XG4gIH1cblxuICBsZXQgbXNnO1xuICBpZiAoZW5kc1dpdGgobmFtZSwgJyBhcmd1bWVudCcpKSB7XG4gICAgLy8gRm9yIGNhc2VzIGxpa2UgJ2ZpcnN0IGFyZ3VtZW50J1xuICAgIG1zZyA9IGBUaGUgJHtuYW1lfSAke2RldGVybWluZXJ9ICR7b25lT2YoZXhwZWN0ZWQsICd0eXBlJyl9YDtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCB0eXBlID0gaW5jbHVkZXMobmFtZSwgJy4nKSA/ICdwcm9wZXJ0eScgOiAnYXJndW1lbnQnO1xuICAgIG1zZyA9IGBUaGUgXCIke25hbWV9XCIgJHt0eXBlfSAke2RldGVybWluZXJ9ICR7b25lT2YoZXhwZWN0ZWQsICd0eXBlJyl9YDtcbiAgfVxuXG4gIG1zZyArPSBgLiBSZWNlaXZlZCB0eXBlICR7dHlwZW9mIGFjdHVhbH1gO1xuICByZXR1cm4gbXNnO1xufSwgVHlwZUVycm9yKTtcbmNyZWF0ZUVycm9yVHlwZSgnRVJSX1NUUkVBTV9QVVNIX0FGVEVSX0VPRicsICdzdHJlYW0ucHVzaCgpIGFmdGVyIEVPRicpO1xuY3JlYXRlRXJyb3JUeXBlKCdFUlJfTUVUSE9EX05PVF9JTVBMRU1FTlRFRCcsIGZ1bmN0aW9uIChuYW1lKSB7XG4gIHJldHVybiAnVGhlICcgKyBuYW1lICsgJyBtZXRob2QgaXMgbm90IGltcGxlbWVudGVkJ1xufSk7XG5jcmVhdGVFcnJvclR5cGUoJ0VSUl9TVFJFQU1fUFJFTUFUVVJFX0NMT1NFJywgJ1ByZW1hdHVyZSBjbG9zZScpO1xuY3JlYXRlRXJyb3JUeXBlKCdFUlJfU1RSRUFNX0RFU1RST1lFRCcsIGZ1bmN0aW9uIChuYW1lKSB7XG4gIHJldHVybiAnQ2Fubm90IGNhbGwgJyArIG5hbWUgKyAnIGFmdGVyIGEgc3RyZWFtIHdhcyBkZXN0cm95ZWQnO1xufSk7XG5jcmVhdGVFcnJvclR5cGUoJ0VSUl9NVUxUSVBMRV9DQUxMQkFDSycsICdDYWxsYmFjayBjYWxsZWQgbXVsdGlwbGUgdGltZXMnKTtcbmNyZWF0ZUVycm9yVHlwZSgnRVJSX1NUUkVBTV9DQU5OT1RfUElQRScsICdDYW5ub3QgcGlwZSwgbm90IHJlYWRhYmxlJyk7XG5jcmVhdGVFcnJvclR5cGUoJ0VSUl9TVFJFQU1fV1JJVEVfQUZURVJfRU5EJywgJ3dyaXRlIGFmdGVyIGVuZCcpO1xuY3JlYXRlRXJyb3JUeXBlKCdFUlJfU1RSRUFNX05VTExfVkFMVUVTJywgJ01heSBub3Qgd3JpdGUgbnVsbCB2YWx1ZXMgdG8gc3RyZWFtJywgVHlwZUVycm9yKTtcbmNyZWF0ZUVycm9yVHlwZSgnRVJSX1VOS05PV05fRU5DT0RJTkcnLCBmdW5jdGlvbiAoYXJnKSB7XG4gIHJldHVybiAnVW5rbm93biBlbmNvZGluZzogJyArIGFyZ1xufSwgVHlwZUVycm9yKTtcbmNyZWF0ZUVycm9yVHlwZSgnRVJSX1NUUkVBTV9VTlNISUZUX0FGVEVSX0VORF9FVkVOVCcsICdzdHJlYW0udW5zaGlmdCgpIGFmdGVyIGVuZCBldmVudCcpO1xuXG5tb2R1bGUuZXhwb3J0cy5jb2RlcyA9IGNvZGVzO1xuIiwiLy8gQ29weXJpZ2h0IEpveWVudCwgSW5jLiBhbmQgb3RoZXIgTm9kZSBjb250cmlidXRvcnMuXG4vL1xuLy8gUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb24gb2J0YWluaW5nIGFcbi8vIGNvcHkgb2YgdGhpcyBzb2Z0d2FyZSBhbmQgYXNzb2NpYXRlZCBkb2N1bWVudGF0aW9uIGZpbGVzICh0aGVcbi8vIFwiU29mdHdhcmVcIiksIHRvIGRlYWwgaW4gdGhlIFNvZnR3YXJlIHdpdGhvdXQgcmVzdHJpY3Rpb24sIGluY2x1ZGluZ1xuLy8gd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMgdG8gdXNlLCBjb3B5LCBtb2RpZnksIG1lcmdlLCBwdWJsaXNoLFxuLy8gZGlzdHJpYnV0ZSwgc3VibGljZW5zZSwgYW5kL29yIHNlbGwgY29waWVzIG9mIHRoZSBTb2Z0d2FyZSwgYW5kIHRvIHBlcm1pdFxuLy8gcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpcyBmdXJuaXNoZWQgdG8gZG8gc28sIHN1YmplY3QgdG8gdGhlXG4vLyBmb2xsb3dpbmcgY29uZGl0aW9uczpcbi8vXG4vLyBUaGUgYWJvdmUgY29weXJpZ2h0IG5vdGljZSBhbmQgdGhpcyBwZXJtaXNzaW9uIG5vdGljZSBzaGFsbCBiZSBpbmNsdWRlZFxuLy8gaW4gYWxsIGNvcGllcyBvciBzdWJzdGFudGlhbCBwb3J0aW9ucyBvZiB0aGUgU29mdHdhcmUuXG4vL1xuLy8gVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiwgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCwgRVhQUkVTU1xuLy8gT1IgSU1QTElFRCwgSU5DTFVESU5HIEJVVCBOT1QgTElNSVRFRCBUTyBUSEUgV0FSUkFOVElFUyBPRlxuLy8gTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTlxuLy8gTk8gRVZFTlQgU0hBTEwgVEhFIEFVVEhPUlMgT1IgQ09QWVJJR0hUIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTlkgQ0xBSU0sXG4vLyBEQU1BR0VTIE9SIE9USEVSIExJQUJJTElUWSwgV0hFVEhFUiBJTiBBTiBBQ1RJT04gT0YgQ09OVFJBQ1QsIFRPUlQgT1Jcbi8vIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRSBTT0ZUV0FSRSBPUiBUSEVcbi8vIFVTRSBPUiBPVEhFUiBERUFMSU5HUyBJTiBUSEUgU09GVFdBUkUuXG4vLyBhIGR1cGxleCBzdHJlYW0gaXMganVzdCBhIHN0cmVhbSB0aGF0IGlzIGJvdGggcmVhZGFibGUgYW5kIHdyaXRhYmxlLlxuLy8gU2luY2UgSlMgZG9lc24ndCBoYXZlIG11bHRpcGxlIHByb3RvdHlwYWwgaW5oZXJpdGFuY2UsIHRoaXMgY2xhc3Ncbi8vIHByb3RvdHlwYWxseSBpbmhlcml0cyBmcm9tIFJlYWRhYmxlLCBhbmQgdGhlbiBwYXJhc2l0aWNhbGx5IGZyb21cbi8vIFdyaXRhYmxlLlxuJ3VzZSBzdHJpY3QnO1xuLyo8cmVwbGFjZW1lbnQ+Ki9cblxudmFyIG9iamVjdEtleXMgPSBPYmplY3Qua2V5cyB8fCBmdW5jdGlvbiAob2JqKSB7XG4gIHZhciBrZXlzID0gW107XG5cbiAgZm9yICh2YXIga2V5IGluIG9iaikge1xuICAgIGtleXMucHVzaChrZXkpO1xuICB9XG5cbiAgcmV0dXJuIGtleXM7XG59O1xuLyo8L3JlcGxhY2VtZW50PiovXG5cblxubW9kdWxlLmV4cG9ydHMgPSBEdXBsZXg7XG5cbnZhciBSZWFkYWJsZSA9IHJlcXVpcmUoJy4vX3N0cmVhbV9yZWFkYWJsZScpO1xuXG52YXIgV3JpdGFibGUgPSByZXF1aXJlKCcuL19zdHJlYW1fd3JpdGFibGUnKTtcblxucmVxdWlyZSgnaW5oZXJpdHMnKShEdXBsZXgsIFJlYWRhYmxlKTtcblxue1xuICAvLyBBbGxvdyB0aGUga2V5cyBhcnJheSB0byBiZSBHQydlZC5cbiAgdmFyIGtleXMgPSBvYmplY3RLZXlzKFdyaXRhYmxlLnByb3RvdHlwZSk7XG5cbiAgZm9yICh2YXIgdiA9IDA7IHYgPCBrZXlzLmxlbmd0aDsgdisrKSB7XG4gICAgdmFyIG1ldGhvZCA9IGtleXNbdl07XG4gICAgaWYgKCFEdXBsZXgucHJvdG90eXBlW21ldGhvZF0pIER1cGxleC5wcm90b3R5cGVbbWV0aG9kXSA9IFdyaXRhYmxlLnByb3RvdHlwZVttZXRob2RdO1xuICB9XG59XG5cbmZ1bmN0aW9uIER1cGxleChvcHRpb25zKSB7XG4gIGlmICghKHRoaXMgaW5zdGFuY2VvZiBEdXBsZXgpKSByZXR1cm4gbmV3IER1cGxleChvcHRpb25zKTtcbiAgUmVhZGFibGUuY2FsbCh0aGlzLCBvcHRpb25zKTtcbiAgV3JpdGFibGUuY2FsbCh0aGlzLCBvcHRpb25zKTtcbiAgdGhpcy5hbGxvd0hhbGZPcGVuID0gdHJ1ZTtcblxuICBpZiAob3B0aW9ucykge1xuICAgIGlmIChvcHRpb25zLnJlYWRhYmxlID09PSBmYWxzZSkgdGhpcy5yZWFkYWJsZSA9IGZhbHNlO1xuICAgIGlmIChvcHRpb25zLndyaXRhYmxlID09PSBmYWxzZSkgdGhpcy53cml0YWJsZSA9IGZhbHNlO1xuXG4gICAgaWYgKG9wdGlvbnMuYWxsb3dIYWxmT3BlbiA9PT0gZmFsc2UpIHtcbiAgICAgIHRoaXMuYWxsb3dIYWxmT3BlbiA9IGZhbHNlO1xuICAgICAgdGhpcy5vbmNlKCdlbmQnLCBvbmVuZCk7XG4gICAgfVxuICB9XG59XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShEdXBsZXgucHJvdG90eXBlLCAnd3JpdGFibGVIaWdoV2F0ZXJNYXJrJywge1xuICAvLyBtYWtpbmcgaXQgZXhwbGljaXQgdGhpcyBwcm9wZXJ0eSBpcyBub3QgZW51bWVyYWJsZVxuICAvLyBiZWNhdXNlIG90aGVyd2lzZSBzb21lIHByb3RvdHlwZSBtYW5pcHVsYXRpb24gaW5cbiAgLy8gdXNlcmxhbmQgd2lsbCBmYWlsXG4gIGVudW1lcmFibGU6IGZhbHNlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICByZXR1cm4gdGhpcy5fd3JpdGFibGVTdGF0ZS5oaWdoV2F0ZXJNYXJrO1xuICB9XG59KTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShEdXBsZXgucHJvdG90eXBlLCAnd3JpdGFibGVCdWZmZXInLCB7XG4gIC8vIG1ha2luZyBpdCBleHBsaWNpdCB0aGlzIHByb3BlcnR5IGlzIG5vdCBlbnVtZXJhYmxlXG4gIC8vIGJlY2F1c2Ugb3RoZXJ3aXNlIHNvbWUgcHJvdG90eXBlIG1hbmlwdWxhdGlvbiBpblxuICAvLyB1c2VybGFuZCB3aWxsIGZhaWxcbiAgZW51bWVyYWJsZTogZmFsc2UsXG4gIGdldDogZnVuY3Rpb24gZ2V0KCkge1xuICAgIHJldHVybiB0aGlzLl93cml0YWJsZVN0YXRlICYmIHRoaXMuX3dyaXRhYmxlU3RhdGUuZ2V0QnVmZmVyKCk7XG4gIH1cbn0pO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KER1cGxleC5wcm90b3R5cGUsICd3cml0YWJsZUxlbmd0aCcsIHtcbiAgLy8gbWFraW5nIGl0IGV4cGxpY2l0IHRoaXMgcHJvcGVydHkgaXMgbm90IGVudW1lcmFibGVcbiAgLy8gYmVjYXVzZSBvdGhlcndpc2Ugc29tZSBwcm90b3R5cGUgbWFuaXB1bGF0aW9uIGluXG4gIC8vIHVzZXJsYW5kIHdpbGwgZmFpbFxuICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgZ2V0OiBmdW5jdGlvbiBnZXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3dyaXRhYmxlU3RhdGUubGVuZ3RoO1xuICB9XG59KTsgLy8gdGhlIG5vLWhhbGYtb3BlbiBlbmZvcmNlclxuXG5mdW5jdGlvbiBvbmVuZCgpIHtcbiAgLy8gSWYgdGhlIHdyaXRhYmxlIHNpZGUgZW5kZWQsIHRoZW4gd2UncmUgb2suXG4gIGlmICh0aGlzLl93cml0YWJsZVN0YXRlLmVuZGVkKSByZXR1cm47IC8vIG5vIG1vcmUgZGF0YSBjYW4gYmUgd3JpdHRlbi5cbiAgLy8gQnV0IGFsbG93IG1vcmUgd3JpdGVzIHRvIGhhcHBlbiBpbiB0aGlzIHRpY2suXG5cbiAgcHJvY2Vzcy5uZXh0VGljayhvbkVuZE5ULCB0aGlzKTtcbn1cblxuZnVuY3Rpb24gb25FbmROVChzZWxmKSB7XG4gIHNlbGYuZW5kKCk7XG59XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShEdXBsZXgucHJvdG90eXBlLCAnZGVzdHJveWVkJywge1xuICAvLyBtYWtpbmcgaXQgZXhwbGljaXQgdGhpcyBwcm9wZXJ0eSBpcyBub3QgZW51bWVyYWJsZVxuICAvLyBiZWNhdXNlIG90aGVyd2lzZSBzb21lIHByb3RvdHlwZSBtYW5pcHVsYXRpb24gaW5cbiAgLy8gdXNlcmxhbmQgd2lsbCBmYWlsXG4gIGVudW1lcmFibGU6IGZhbHNlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICBpZiAodGhpcy5fcmVhZGFibGVTdGF0ZSA9PT0gdW5kZWZpbmVkIHx8IHRoaXMuX3dyaXRhYmxlU3RhdGUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIHJldHVybiB0aGlzLl9yZWFkYWJsZVN0YXRlLmRlc3Ryb3llZCAmJiB0aGlzLl93cml0YWJsZVN0YXRlLmRlc3Ryb3llZDtcbiAgfSxcbiAgc2V0OiBmdW5jdGlvbiBzZXQodmFsdWUpIHtcbiAgICAvLyB3ZSBpZ25vcmUgdGhlIHZhbHVlIGlmIHRoZSBzdHJlYW1cbiAgICAvLyBoYXMgbm90IGJlZW4gaW5pdGlhbGl6ZWQgeWV0XG4gICAgaWYgKHRoaXMuX3JlYWRhYmxlU3RhdGUgPT09IHVuZGVmaW5lZCB8fCB0aGlzLl93cml0YWJsZVN0YXRlID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9IC8vIGJhY2t3YXJkIGNvbXBhdGliaWxpdHksIHRoZSB1c2VyIGlzIGV4cGxpY2l0bHlcbiAgICAvLyBtYW5hZ2luZyBkZXN0cm95ZWRcblxuXG4gICAgdGhpcy5fcmVhZGFibGVTdGF0ZS5kZXN0cm95ZWQgPSB2YWx1ZTtcbiAgICB0aGlzLl93cml0YWJsZVN0YXRlLmRlc3Ryb3llZCA9IHZhbHVlO1xuICB9XG59KTsiLCIvLyBDb3B5cmlnaHQgSm95ZW50LCBJbmMuIGFuZCBvdGhlciBOb2RlIGNvbnRyaWJ1dG9ycy5cbi8vXG4vLyBQZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYVxuLy8gY29weSBvZiB0aGlzIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZVxuLy8gXCJTb2Z0d2FyZVwiKSwgdG8gZGVhbCBpbiB0aGUgU29mdHdhcmUgd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nXG4vLyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsXG4vLyBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0XG4vLyBwZXJzb25zIHRvIHdob20gdGhlIFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0byB0aGVcbi8vIGZvbGxvd2luZyBjb25kaXRpb25zOlxuLy9cbi8vIFRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIHNoYWxsIGJlIGluY2x1ZGVkXG4vLyBpbiBhbGwgY29waWVzIG9yIHN1YnN0YW50aWFsIHBvcnRpb25zIG9mIHRoZSBTb2Z0d2FyZS5cbi8vXG4vLyBUSEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTXG4vLyBPUiBJTVBMSUVELCBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GXG4vLyBNRVJDSEFOVEFCSUxJVFksIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuIElOXG4vLyBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFQgSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSxcbi8vIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSIElOIEFOIEFDVElPTiBPRiBDT05UUkFDVCwgVE9SVCBPUlxuLy8gT1RIRVJXSVNFLCBBUklTSU5HIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFIFNPRlRXQVJFIE9SIFRIRVxuLy8gVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cbi8vIGEgcGFzc3Rocm91Z2ggc3RyZWFtLlxuLy8gYmFzaWNhbGx5IGp1c3QgdGhlIG1vc3QgbWluaW1hbCBzb3J0IG9mIFRyYW5zZm9ybSBzdHJlYW0uXG4vLyBFdmVyeSB3cml0dGVuIGNodW5rIGdldHMgb3V0cHV0IGFzLWlzLlxuJ3VzZSBzdHJpY3QnO1xuXG5tb2R1bGUuZXhwb3J0cyA9IFBhc3NUaHJvdWdoO1xuXG52YXIgVHJhbnNmb3JtID0gcmVxdWlyZSgnLi9fc3RyZWFtX3RyYW5zZm9ybScpO1xuXG5yZXF1aXJlKCdpbmhlcml0cycpKFBhc3NUaHJvdWdoLCBUcmFuc2Zvcm0pO1xuXG5mdW5jdGlvbiBQYXNzVGhyb3VnaChvcHRpb25zKSB7XG4gIGlmICghKHRoaXMgaW5zdGFuY2VvZiBQYXNzVGhyb3VnaCkpIHJldHVybiBuZXcgUGFzc1Rocm91Z2gob3B0aW9ucyk7XG4gIFRyYW5zZm9ybS5jYWxsKHRoaXMsIG9wdGlvbnMpO1xufVxuXG5QYXNzVGhyb3VnaC5wcm90b3R5cGUuX3RyYW5zZm9ybSA9IGZ1bmN0aW9uIChjaHVuaywgZW5jb2RpbmcsIGNiKSB7XG4gIGNiKG51bGwsIGNodW5rKTtcbn07IiwiLy8gQ29weXJpZ2h0IEpveWVudCwgSW5jLiBhbmQgb3RoZXIgTm9kZSBjb250cmlidXRvcnMuXG4vL1xuLy8gUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb24gb2J0YWluaW5nIGFcbi8vIGNvcHkgb2YgdGhpcyBzb2Z0d2FyZSBhbmQgYXNzb2NpYXRlZCBkb2N1bWVudGF0aW9uIGZpbGVzICh0aGVcbi8vIFwiU29mdHdhcmVcIiksIHRvIGRlYWwgaW4gdGhlIFNvZnR3YXJlIHdpdGhvdXQgcmVzdHJpY3Rpb24sIGluY2x1ZGluZ1xuLy8gd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMgdG8gdXNlLCBjb3B5LCBtb2RpZnksIG1lcmdlLCBwdWJsaXNoLFxuLy8gZGlzdHJpYnV0ZSwgc3VibGljZW5zZSwgYW5kL29yIHNlbGwgY29waWVzIG9mIHRoZSBTb2Z0d2FyZSwgYW5kIHRvIHBlcm1pdFxuLy8gcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpcyBmdXJuaXNoZWQgdG8gZG8gc28sIHN1YmplY3QgdG8gdGhlXG4vLyBmb2xsb3dpbmcgY29uZGl0aW9uczpcbi8vXG4vLyBUaGUgYWJvdmUgY29weXJpZ2h0IG5vdGljZSBhbmQgdGhpcyBwZXJtaXNzaW9uIG5vdGljZSBzaGFsbCBiZSBpbmNsdWRlZFxuLy8gaW4gYWxsIGNvcGllcyBvciBzdWJzdGFudGlhbCBwb3J0aW9ucyBvZiB0aGUgU29mdHdhcmUuXG4vL1xuLy8gVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiwgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCwgRVhQUkVTU1xuLy8gT1IgSU1QTElFRCwgSU5DTFVESU5HIEJVVCBOT1QgTElNSVRFRCBUTyBUSEUgV0FSUkFOVElFUyBPRlxuLy8gTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTlxuLy8gTk8gRVZFTlQgU0hBTEwgVEhFIEFVVEhPUlMgT1IgQ09QWVJJR0hUIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTlkgQ0xBSU0sXG4vLyBEQU1BR0VTIE9SIE9USEVSIExJQUJJTElUWSwgV0hFVEhFUiBJTiBBTiBBQ1RJT04gT0YgQ09OVFJBQ1QsIFRPUlQgT1Jcbi8vIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRSBTT0ZUV0FSRSBPUiBUSEVcbi8vIFVTRSBPUiBPVEhFUiBERUFMSU5HUyBJTiBUSEUgU09GVFdBUkUuXG4ndXNlIHN0cmljdCc7XG5cbm1vZHVsZS5leHBvcnRzID0gUmVhZGFibGU7XG4vKjxyZXBsYWNlbWVudD4qL1xuXG52YXIgRHVwbGV4O1xuLyo8L3JlcGxhY2VtZW50PiovXG5cblJlYWRhYmxlLlJlYWRhYmxlU3RhdGUgPSBSZWFkYWJsZVN0YXRlO1xuLyo8cmVwbGFjZW1lbnQ+Ki9cblxudmFyIEVFID0gcmVxdWlyZSgnZXZlbnRzJykuRXZlbnRFbWl0dGVyO1xuXG52YXIgRUVsaXN0ZW5lckNvdW50ID0gZnVuY3Rpb24gRUVsaXN0ZW5lckNvdW50KGVtaXR0ZXIsIHR5cGUpIHtcbiAgcmV0dXJuIGVtaXR0ZXIubGlzdGVuZXJzKHR5cGUpLmxlbmd0aDtcbn07XG4vKjwvcmVwbGFjZW1lbnQ+Ki9cblxuLyo8cmVwbGFjZW1lbnQ+Ki9cblxuXG52YXIgU3RyZWFtID0gcmVxdWlyZSgnLi9pbnRlcm5hbC9zdHJlYW1zL3N0cmVhbScpO1xuLyo8L3JlcGxhY2VtZW50PiovXG5cblxudmFyIEJ1ZmZlciA9IHJlcXVpcmUoJ2J1ZmZlcicpLkJ1ZmZlcjtcblxudmFyIE91clVpbnQ4QXJyYXkgPSBnbG9iYWwuVWludDhBcnJheSB8fCBmdW5jdGlvbiAoKSB7fTtcblxuZnVuY3Rpb24gX3VpbnQ4QXJyYXlUb0J1ZmZlcihjaHVuaykge1xuICByZXR1cm4gQnVmZmVyLmZyb20oY2h1bmspO1xufVxuXG5mdW5jdGlvbiBfaXNVaW50OEFycmF5KG9iaikge1xuICByZXR1cm4gQnVmZmVyLmlzQnVmZmVyKG9iaikgfHwgb2JqIGluc3RhbmNlb2YgT3VyVWludDhBcnJheTtcbn1cbi8qPHJlcGxhY2VtZW50PiovXG5cblxudmFyIGRlYnVnVXRpbCA9IHJlcXVpcmUoJ3V0aWwnKTtcblxudmFyIGRlYnVnO1xuXG5pZiAoZGVidWdVdGlsICYmIGRlYnVnVXRpbC5kZWJ1Z2xvZykge1xuICBkZWJ1ZyA9IGRlYnVnVXRpbC5kZWJ1Z2xvZygnc3RyZWFtJyk7XG59IGVsc2Uge1xuICBkZWJ1ZyA9IGZ1bmN0aW9uIGRlYnVnKCkge307XG59XG4vKjwvcmVwbGFjZW1lbnQ+Ki9cblxuXG52YXIgQnVmZmVyTGlzdCA9IHJlcXVpcmUoJy4vaW50ZXJuYWwvc3RyZWFtcy9idWZmZXJfbGlzdCcpO1xuXG52YXIgZGVzdHJveUltcGwgPSByZXF1aXJlKCcuL2ludGVybmFsL3N0cmVhbXMvZGVzdHJveScpO1xuXG52YXIgX3JlcXVpcmUgPSByZXF1aXJlKCcuL2ludGVybmFsL3N0cmVhbXMvc3RhdGUnKSxcbiAgICBnZXRIaWdoV2F0ZXJNYXJrID0gX3JlcXVpcmUuZ2V0SGlnaFdhdGVyTWFyaztcblxudmFyIF9yZXF1aXJlJGNvZGVzID0gcmVxdWlyZSgnLi4vZXJyb3JzJykuY29kZXMsXG4gICAgRVJSX0lOVkFMSURfQVJHX1RZUEUgPSBfcmVxdWlyZSRjb2Rlcy5FUlJfSU5WQUxJRF9BUkdfVFlQRSxcbiAgICBFUlJfU1RSRUFNX1BVU0hfQUZURVJfRU9GID0gX3JlcXVpcmUkY29kZXMuRVJSX1NUUkVBTV9QVVNIX0FGVEVSX0VPRixcbiAgICBFUlJfTUVUSE9EX05PVF9JTVBMRU1FTlRFRCA9IF9yZXF1aXJlJGNvZGVzLkVSUl9NRVRIT0RfTk9UX0lNUExFTUVOVEVELFxuICAgIEVSUl9TVFJFQU1fVU5TSElGVF9BRlRFUl9FTkRfRVZFTlQgPSBfcmVxdWlyZSRjb2Rlcy5FUlJfU1RSRUFNX1VOU0hJRlRfQUZURVJfRU5EX0VWRU5UOyAvLyBMYXp5IGxvYWRlZCB0byBpbXByb3ZlIHRoZSBzdGFydHVwIHBlcmZvcm1hbmNlLlxuXG5cbnZhciBTdHJpbmdEZWNvZGVyO1xudmFyIGNyZWF0ZVJlYWRhYmxlU3RyZWFtQXN5bmNJdGVyYXRvcjtcbnZhciBmcm9tO1xuXG5yZXF1aXJlKCdpbmhlcml0cycpKFJlYWRhYmxlLCBTdHJlYW0pO1xuXG52YXIgZXJyb3JPckRlc3Ryb3kgPSBkZXN0cm95SW1wbC5lcnJvck9yRGVzdHJveTtcbnZhciBrUHJveHlFdmVudHMgPSBbJ2Vycm9yJywgJ2Nsb3NlJywgJ2Rlc3Ryb3knLCAncGF1c2UnLCAncmVzdW1lJ107XG5cbmZ1bmN0aW9uIHByZXBlbmRMaXN0ZW5lcihlbWl0dGVyLCBldmVudCwgZm4pIHtcbiAgLy8gU2FkbHkgdGhpcyBpcyBub3QgY2FjaGVhYmxlIGFzIHNvbWUgbGlicmFyaWVzIGJ1bmRsZSB0aGVpciBvd25cbiAgLy8gZXZlbnQgZW1pdHRlciBpbXBsZW1lbnRhdGlvbiB3aXRoIHRoZW0uXG4gIGlmICh0eXBlb2YgZW1pdHRlci5wcmVwZW5kTGlzdGVuZXIgPT09ICdmdW5jdGlvbicpIHJldHVybiBlbWl0dGVyLnByZXBlbmRMaXN0ZW5lcihldmVudCwgZm4pOyAvLyBUaGlzIGlzIGEgaGFjayB0byBtYWtlIHN1cmUgdGhhdCBvdXIgZXJyb3IgaGFuZGxlciBpcyBhdHRhY2hlZCBiZWZvcmUgYW55XG4gIC8vIHVzZXJsYW5kIG9uZXMuICBORVZFUiBETyBUSElTLiBUaGlzIGlzIGhlcmUgb25seSBiZWNhdXNlIHRoaXMgY29kZSBuZWVkc1xuICAvLyB0byBjb250aW51ZSB0byB3b3JrIHdpdGggb2xkZXIgdmVyc2lvbnMgb2YgTm9kZS5qcyB0aGF0IGRvIG5vdCBpbmNsdWRlXG4gIC8vIHRoZSBwcmVwZW5kTGlzdGVuZXIoKSBtZXRob2QuIFRoZSBnb2FsIGlzIHRvIGV2ZW50dWFsbHkgcmVtb3ZlIHRoaXMgaGFjay5cblxuICBpZiAoIWVtaXR0ZXIuX2V2ZW50cyB8fCAhZW1pdHRlci5fZXZlbnRzW2V2ZW50XSkgZW1pdHRlci5vbihldmVudCwgZm4pO2Vsc2UgaWYgKEFycmF5LmlzQXJyYXkoZW1pdHRlci5fZXZlbnRzW2V2ZW50XSkpIGVtaXR0ZXIuX2V2ZW50c1tldmVudF0udW5zaGlmdChmbik7ZWxzZSBlbWl0dGVyLl9ldmVudHNbZXZlbnRdID0gW2ZuLCBlbWl0dGVyLl9ldmVudHNbZXZlbnRdXTtcbn1cblxuZnVuY3Rpb24gUmVhZGFibGVTdGF0ZShvcHRpb25zLCBzdHJlYW0sIGlzRHVwbGV4KSB7XG4gIER1cGxleCA9IER1cGxleCB8fCByZXF1aXJlKCcuL19zdHJlYW1fZHVwbGV4Jyk7XG4gIG9wdGlvbnMgPSBvcHRpb25zIHx8IHt9OyAvLyBEdXBsZXggc3RyZWFtcyBhcmUgYm90aCByZWFkYWJsZSBhbmQgd3JpdGFibGUsIGJ1dCBzaGFyZVxuICAvLyB0aGUgc2FtZSBvcHRpb25zIG9iamVjdC5cbiAgLy8gSG93ZXZlciwgc29tZSBjYXNlcyByZXF1aXJlIHNldHRpbmcgb3B0aW9ucyB0byBkaWZmZXJlbnRcbiAgLy8gdmFsdWVzIGZvciB0aGUgcmVhZGFibGUgYW5kIHRoZSB3cml0YWJsZSBzaWRlcyBvZiB0aGUgZHVwbGV4IHN0cmVhbS5cbiAgLy8gVGhlc2Ugb3B0aW9ucyBjYW4gYmUgcHJvdmlkZWQgc2VwYXJhdGVseSBhcyByZWFkYWJsZVhYWCBhbmQgd3JpdGFibGVYWFguXG5cbiAgaWYgKHR5cGVvZiBpc0R1cGxleCAhPT0gJ2Jvb2xlYW4nKSBpc0R1cGxleCA9IHN0cmVhbSBpbnN0YW5jZW9mIER1cGxleDsgLy8gb2JqZWN0IHN0cmVhbSBmbGFnLiBVc2VkIHRvIG1ha2UgcmVhZChuKSBpZ25vcmUgbiBhbmQgdG9cbiAgLy8gbWFrZSBhbGwgdGhlIGJ1ZmZlciBtZXJnaW5nIGFuZCBsZW5ndGggY2hlY2tzIGdvIGF3YXlcblxuICB0aGlzLm9iamVjdE1vZGUgPSAhIW9wdGlvbnMub2JqZWN0TW9kZTtcbiAgaWYgKGlzRHVwbGV4KSB0aGlzLm9iamVjdE1vZGUgPSB0aGlzLm9iamVjdE1vZGUgfHwgISFvcHRpb25zLnJlYWRhYmxlT2JqZWN0TW9kZTsgLy8gdGhlIHBvaW50IGF0IHdoaWNoIGl0IHN0b3BzIGNhbGxpbmcgX3JlYWQoKSB0byBmaWxsIHRoZSBidWZmZXJcbiAgLy8gTm90ZTogMCBpcyBhIHZhbGlkIHZhbHVlLCBtZWFucyBcImRvbid0IGNhbGwgX3JlYWQgcHJlZW1wdGl2ZWx5IGV2ZXJcIlxuXG4gIHRoaXMuaGlnaFdhdGVyTWFyayA9IGdldEhpZ2hXYXRlck1hcmsodGhpcywgb3B0aW9ucywgJ3JlYWRhYmxlSGlnaFdhdGVyTWFyaycsIGlzRHVwbGV4KTsgLy8gQSBsaW5rZWQgbGlzdCBpcyB1c2VkIHRvIHN0b3JlIGRhdGEgY2h1bmtzIGluc3RlYWQgb2YgYW4gYXJyYXkgYmVjYXVzZSB0aGVcbiAgLy8gbGlua2VkIGxpc3QgY2FuIHJlbW92ZSBlbGVtZW50cyBmcm9tIHRoZSBiZWdpbm5pbmcgZmFzdGVyIHRoYW5cbiAgLy8gYXJyYXkuc2hpZnQoKVxuXG4gIHRoaXMuYnVmZmVyID0gbmV3IEJ1ZmZlckxpc3QoKTtcbiAgdGhpcy5sZW5ndGggPSAwO1xuICB0aGlzLnBpcGVzID0gbnVsbDtcbiAgdGhpcy5waXBlc0NvdW50ID0gMDtcbiAgdGhpcy5mbG93aW5nID0gbnVsbDtcbiAgdGhpcy5lbmRlZCA9IGZhbHNlO1xuICB0aGlzLmVuZEVtaXR0ZWQgPSBmYWxzZTtcbiAgdGhpcy5yZWFkaW5nID0gZmFsc2U7IC8vIGEgZmxhZyB0byBiZSBhYmxlIHRvIHRlbGwgaWYgdGhlIGV2ZW50ICdyZWFkYWJsZScvJ2RhdGEnIGlzIGVtaXR0ZWRcbiAgLy8gaW1tZWRpYXRlbHksIG9yIG9uIGEgbGF0ZXIgdGljay4gIFdlIHNldCB0aGlzIHRvIHRydWUgYXQgZmlyc3QsIGJlY2F1c2VcbiAgLy8gYW55IGFjdGlvbnMgdGhhdCBzaG91bGRuJ3QgaGFwcGVuIHVudGlsIFwibGF0ZXJcIiBzaG91bGQgZ2VuZXJhbGx5IGFsc29cbiAgLy8gbm90IGhhcHBlbiBiZWZvcmUgdGhlIGZpcnN0IHJlYWQgY2FsbC5cblxuICB0aGlzLnN5bmMgPSB0cnVlOyAvLyB3aGVuZXZlciB3ZSByZXR1cm4gbnVsbCwgdGhlbiB3ZSBzZXQgYSBmbGFnIHRvIHNheVxuICAvLyB0aGF0IHdlJ3JlIGF3YWl0aW5nIGEgJ3JlYWRhYmxlJyBldmVudCBlbWlzc2lvbi5cblxuICB0aGlzLm5lZWRSZWFkYWJsZSA9IGZhbHNlO1xuICB0aGlzLmVtaXR0ZWRSZWFkYWJsZSA9IGZhbHNlO1xuICB0aGlzLnJlYWRhYmxlTGlzdGVuaW5nID0gZmFsc2U7XG4gIHRoaXMucmVzdW1lU2NoZWR1bGVkID0gZmFsc2U7XG4gIHRoaXMucGF1c2VkID0gdHJ1ZTsgLy8gU2hvdWxkIGNsb3NlIGJlIGVtaXR0ZWQgb24gZGVzdHJveS4gRGVmYXVsdHMgdG8gdHJ1ZS5cblxuICB0aGlzLmVtaXRDbG9zZSA9IG9wdGlvbnMuZW1pdENsb3NlICE9PSBmYWxzZTsgLy8gU2hvdWxkIC5kZXN0cm95KCkgYmUgY2FsbGVkIGFmdGVyICdlbmQnIChhbmQgcG90ZW50aWFsbHkgJ2ZpbmlzaCcpXG5cbiAgdGhpcy5hdXRvRGVzdHJveSA9ICEhb3B0aW9ucy5hdXRvRGVzdHJveTsgLy8gaGFzIGl0IGJlZW4gZGVzdHJveWVkXG5cbiAgdGhpcy5kZXN0cm95ZWQgPSBmYWxzZTsgLy8gQ3J5cHRvIGlzIGtpbmQgb2Ygb2xkIGFuZCBjcnVzdHkuICBIaXN0b3JpY2FsbHksIGl0cyBkZWZhdWx0IHN0cmluZ1xuICAvLyBlbmNvZGluZyBpcyAnYmluYXJ5JyBzbyB3ZSBoYXZlIHRvIG1ha2UgdGhpcyBjb25maWd1cmFibGUuXG4gIC8vIEV2ZXJ5dGhpbmcgZWxzZSBpbiB0aGUgdW5pdmVyc2UgdXNlcyAndXRmOCcsIHRob3VnaC5cblxuICB0aGlzLmRlZmF1bHRFbmNvZGluZyA9IG9wdGlvbnMuZGVmYXVsdEVuY29kaW5nIHx8ICd1dGY4JzsgLy8gdGhlIG51bWJlciBvZiB3cml0ZXJzIHRoYXQgYXJlIGF3YWl0aW5nIGEgZHJhaW4gZXZlbnQgaW4gLnBpcGUoKXNcblxuICB0aGlzLmF3YWl0RHJhaW4gPSAwOyAvLyBpZiB0cnVlLCBhIG1heWJlUmVhZE1vcmUgaGFzIGJlZW4gc2NoZWR1bGVkXG5cbiAgdGhpcy5yZWFkaW5nTW9yZSA9IGZhbHNlO1xuICB0aGlzLmRlY29kZXIgPSBudWxsO1xuICB0aGlzLmVuY29kaW5nID0gbnVsbDtcblxuICBpZiAob3B0aW9ucy5lbmNvZGluZykge1xuICAgIGlmICghU3RyaW5nRGVjb2RlcikgU3RyaW5nRGVjb2RlciA9IHJlcXVpcmUoJ3N0cmluZ19kZWNvZGVyLycpLlN0cmluZ0RlY29kZXI7XG4gICAgdGhpcy5kZWNvZGVyID0gbmV3IFN0cmluZ0RlY29kZXIob3B0aW9ucy5lbmNvZGluZyk7XG4gICAgdGhpcy5lbmNvZGluZyA9IG9wdGlvbnMuZW5jb2Rpbmc7XG4gIH1cbn1cblxuZnVuY3Rpb24gUmVhZGFibGUob3B0aW9ucykge1xuICBEdXBsZXggPSBEdXBsZXggfHwgcmVxdWlyZSgnLi9fc3RyZWFtX2R1cGxleCcpO1xuICBpZiAoISh0aGlzIGluc3RhbmNlb2YgUmVhZGFibGUpKSByZXR1cm4gbmV3IFJlYWRhYmxlKG9wdGlvbnMpOyAvLyBDaGVja2luZyBmb3IgYSBTdHJlYW0uRHVwbGV4IGluc3RhbmNlIGlzIGZhc3RlciBoZXJlIGluc3RlYWQgb2YgaW5zaWRlXG4gIC8vIHRoZSBSZWFkYWJsZVN0YXRlIGNvbnN0cnVjdG9yLCBhdCBsZWFzdCB3aXRoIFY4IDYuNVxuXG4gIHZhciBpc0R1cGxleCA9IHRoaXMgaW5zdGFuY2VvZiBEdXBsZXg7XG4gIHRoaXMuX3JlYWRhYmxlU3RhdGUgPSBuZXcgUmVhZGFibGVTdGF0ZShvcHRpb25zLCB0aGlzLCBpc0R1cGxleCk7IC8vIGxlZ2FjeVxuXG4gIHRoaXMucmVhZGFibGUgPSB0cnVlO1xuXG4gIGlmIChvcHRpb25zKSB7XG4gICAgaWYgKHR5cGVvZiBvcHRpb25zLnJlYWQgPT09ICdmdW5jdGlvbicpIHRoaXMuX3JlYWQgPSBvcHRpb25zLnJlYWQ7XG4gICAgaWYgKHR5cGVvZiBvcHRpb25zLmRlc3Ryb3kgPT09ICdmdW5jdGlvbicpIHRoaXMuX2Rlc3Ryb3kgPSBvcHRpb25zLmRlc3Ryb3k7XG4gIH1cblxuICBTdHJlYW0uY2FsbCh0aGlzKTtcbn1cblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KFJlYWRhYmxlLnByb3RvdHlwZSwgJ2Rlc3Ryb3llZCcsIHtcbiAgLy8gbWFraW5nIGl0IGV4cGxpY2l0IHRoaXMgcHJvcGVydHkgaXMgbm90IGVudW1lcmFibGVcbiAgLy8gYmVjYXVzZSBvdGhlcndpc2Ugc29tZSBwcm90b3R5cGUgbWFuaXB1bGF0aW9uIGluXG4gIC8vIHVzZXJsYW5kIHdpbGwgZmFpbFxuICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgZ2V0OiBmdW5jdGlvbiBnZXQoKSB7XG4gICAgaWYgKHRoaXMuX3JlYWRhYmxlU3RhdGUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIHJldHVybiB0aGlzLl9yZWFkYWJsZVN0YXRlLmRlc3Ryb3llZDtcbiAgfSxcbiAgc2V0OiBmdW5jdGlvbiBzZXQodmFsdWUpIHtcbiAgICAvLyB3ZSBpZ25vcmUgdGhlIHZhbHVlIGlmIHRoZSBzdHJlYW1cbiAgICAvLyBoYXMgbm90IGJlZW4gaW5pdGlhbGl6ZWQgeWV0XG4gICAgaWYgKCF0aGlzLl9yZWFkYWJsZVN0YXRlKSB7XG4gICAgICByZXR1cm47XG4gICAgfSAvLyBiYWNrd2FyZCBjb21wYXRpYmlsaXR5LCB0aGUgdXNlciBpcyBleHBsaWNpdGx5XG4gICAgLy8gbWFuYWdpbmcgZGVzdHJveWVkXG5cblxuICAgIHRoaXMuX3JlYWRhYmxlU3RhdGUuZGVzdHJveWVkID0gdmFsdWU7XG4gIH1cbn0pO1xuUmVhZGFibGUucHJvdG90eXBlLmRlc3Ryb3kgPSBkZXN0cm95SW1wbC5kZXN0cm95O1xuUmVhZGFibGUucHJvdG90eXBlLl91bmRlc3Ryb3kgPSBkZXN0cm95SW1wbC51bmRlc3Ryb3k7XG5cblJlYWRhYmxlLnByb3RvdHlwZS5fZGVzdHJveSA9IGZ1bmN0aW9uIChlcnIsIGNiKSB7XG4gIGNiKGVycik7XG59OyAvLyBNYW51YWxseSBzaG92ZSBzb21ldGhpbmcgaW50byB0aGUgcmVhZCgpIGJ1ZmZlci5cbi8vIFRoaXMgcmV0dXJucyB0cnVlIGlmIHRoZSBoaWdoV2F0ZXJNYXJrIGhhcyBub3QgYmVlbiBoaXQgeWV0LFxuLy8gc2ltaWxhciB0byBob3cgV3JpdGFibGUud3JpdGUoKSByZXR1cm5zIHRydWUgaWYgeW91IHNob3VsZFxuLy8gd3JpdGUoKSBzb21lIG1vcmUuXG5cblxuUmVhZGFibGUucHJvdG90eXBlLnB1c2ggPSBmdW5jdGlvbiAoY2h1bmssIGVuY29kaW5nKSB7XG4gIHZhciBzdGF0ZSA9IHRoaXMuX3JlYWRhYmxlU3RhdGU7XG4gIHZhciBza2lwQ2h1bmtDaGVjaztcblxuICBpZiAoIXN0YXRlLm9iamVjdE1vZGUpIHtcbiAgICBpZiAodHlwZW9mIGNodW5rID09PSAnc3RyaW5nJykge1xuICAgICAgZW5jb2RpbmcgPSBlbmNvZGluZyB8fCBzdGF0ZS5kZWZhdWx0RW5jb2Rpbmc7XG5cbiAgICAgIGlmIChlbmNvZGluZyAhPT0gc3RhdGUuZW5jb2RpbmcpIHtcbiAgICAgICAgY2h1bmsgPSBCdWZmZXIuZnJvbShjaHVuaywgZW5jb2RpbmcpO1xuICAgICAgICBlbmNvZGluZyA9ICcnO1xuICAgICAgfVxuXG4gICAgICBza2lwQ2h1bmtDaGVjayA9IHRydWU7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHNraXBDaHVua0NoZWNrID0gdHJ1ZTtcbiAgfVxuXG4gIHJldHVybiByZWFkYWJsZUFkZENodW5rKHRoaXMsIGNodW5rLCBlbmNvZGluZywgZmFsc2UsIHNraXBDaHVua0NoZWNrKTtcbn07IC8vIFVuc2hpZnQgc2hvdWxkICphbHdheXMqIGJlIHNvbWV0aGluZyBkaXJlY3RseSBvdXQgb2YgcmVhZCgpXG5cblxuUmVhZGFibGUucHJvdG90eXBlLnVuc2hpZnQgPSBmdW5jdGlvbiAoY2h1bmspIHtcbiAgcmV0dXJuIHJlYWRhYmxlQWRkQ2h1bmsodGhpcywgY2h1bmssIG51bGwsIHRydWUsIGZhbHNlKTtcbn07XG5cbmZ1bmN0aW9uIHJlYWRhYmxlQWRkQ2h1bmsoc3RyZWFtLCBjaHVuaywgZW5jb2RpbmcsIGFkZFRvRnJvbnQsIHNraXBDaHVua0NoZWNrKSB7XG4gIGRlYnVnKCdyZWFkYWJsZUFkZENodW5rJywgY2h1bmspO1xuICB2YXIgc3RhdGUgPSBzdHJlYW0uX3JlYWRhYmxlU3RhdGU7XG5cbiAgaWYgKGNodW5rID09PSBudWxsKSB7XG4gICAgc3RhdGUucmVhZGluZyA9IGZhbHNlO1xuICAgIG9uRW9mQ2h1bmsoc3RyZWFtLCBzdGF0ZSk7XG4gIH0gZWxzZSB7XG4gICAgdmFyIGVyO1xuICAgIGlmICghc2tpcENodW5rQ2hlY2spIGVyID0gY2h1bmtJbnZhbGlkKHN0YXRlLCBjaHVuayk7XG5cbiAgICBpZiAoZXIpIHtcbiAgICAgIGVycm9yT3JEZXN0cm95KHN0cmVhbSwgZXIpO1xuICAgIH0gZWxzZSBpZiAoc3RhdGUub2JqZWN0TW9kZSB8fCBjaHVuayAmJiBjaHVuay5sZW5ndGggPiAwKSB7XG4gICAgICBpZiAodHlwZW9mIGNodW5rICE9PSAnc3RyaW5nJyAmJiAhc3RhdGUub2JqZWN0TW9kZSAmJiBPYmplY3QuZ2V0UHJvdG90eXBlT2YoY2h1bmspICE9PSBCdWZmZXIucHJvdG90eXBlKSB7XG4gICAgICAgIGNodW5rID0gX3VpbnQ4QXJyYXlUb0J1ZmZlcihjaHVuayk7XG4gICAgICB9XG5cbiAgICAgIGlmIChhZGRUb0Zyb250KSB7XG4gICAgICAgIGlmIChzdGF0ZS5lbmRFbWl0dGVkKSBlcnJvck9yRGVzdHJveShzdHJlYW0sIG5ldyBFUlJfU1RSRUFNX1VOU0hJRlRfQUZURVJfRU5EX0VWRU5UKCkpO2Vsc2UgYWRkQ2h1bmsoc3RyZWFtLCBzdGF0ZSwgY2h1bmssIHRydWUpO1xuICAgICAgfSBlbHNlIGlmIChzdGF0ZS5lbmRlZCkge1xuICAgICAgICBlcnJvck9yRGVzdHJveShzdHJlYW0sIG5ldyBFUlJfU1RSRUFNX1BVU0hfQUZURVJfRU9GKCkpO1xuICAgICAgfSBlbHNlIGlmIChzdGF0ZS5kZXN0cm95ZWQpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc3RhdGUucmVhZGluZyA9IGZhbHNlO1xuXG4gICAgICAgIGlmIChzdGF0ZS5kZWNvZGVyICYmICFlbmNvZGluZykge1xuICAgICAgICAgIGNodW5rID0gc3RhdGUuZGVjb2Rlci53cml0ZShjaHVuayk7XG4gICAgICAgICAgaWYgKHN0YXRlLm9iamVjdE1vZGUgfHwgY2h1bmsubGVuZ3RoICE9PSAwKSBhZGRDaHVuayhzdHJlYW0sIHN0YXRlLCBjaHVuaywgZmFsc2UpO2Vsc2UgbWF5YmVSZWFkTW9yZShzdHJlYW0sIHN0YXRlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBhZGRDaHVuayhzdHJlYW0sIHN0YXRlLCBjaHVuaywgZmFsc2UpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBlbHNlIGlmICghYWRkVG9Gcm9udCkge1xuICAgICAgc3RhdGUucmVhZGluZyA9IGZhbHNlO1xuICAgICAgbWF5YmVSZWFkTW9yZShzdHJlYW0sIHN0YXRlKTtcbiAgICB9XG4gIH0gLy8gV2UgY2FuIHB1c2ggbW9yZSBkYXRhIGlmIHdlIGFyZSBiZWxvdyB0aGUgaGlnaFdhdGVyTWFyay5cbiAgLy8gQWxzbywgaWYgd2UgaGF2ZSBubyBkYXRhIHlldCwgd2UgY2FuIHN0YW5kIHNvbWUgbW9yZSBieXRlcy5cbiAgLy8gVGhpcyBpcyB0byB3b3JrIGFyb3VuZCBjYXNlcyB3aGVyZSBod209MCwgc3VjaCBhcyB0aGUgcmVwbC5cblxuXG4gIHJldHVybiAhc3RhdGUuZW5kZWQgJiYgKHN0YXRlLmxlbmd0aCA8IHN0YXRlLmhpZ2hXYXRlck1hcmsgfHwgc3RhdGUubGVuZ3RoID09PSAwKTtcbn1cblxuZnVuY3Rpb24gYWRkQ2h1bmsoc3RyZWFtLCBzdGF0ZSwgY2h1bmssIGFkZFRvRnJvbnQpIHtcbiAgaWYgKHN0YXRlLmZsb3dpbmcgJiYgc3RhdGUubGVuZ3RoID09PSAwICYmICFzdGF0ZS5zeW5jKSB7XG4gICAgc3RhdGUuYXdhaXREcmFpbiA9IDA7XG4gICAgc3RyZWFtLmVtaXQoJ2RhdGEnLCBjaHVuayk7XG4gIH0gZWxzZSB7XG4gICAgLy8gdXBkYXRlIHRoZSBidWZmZXIgaW5mby5cbiAgICBzdGF0ZS5sZW5ndGggKz0gc3RhdGUub2JqZWN0TW9kZSA/IDEgOiBjaHVuay5sZW5ndGg7XG4gICAgaWYgKGFkZFRvRnJvbnQpIHN0YXRlLmJ1ZmZlci51bnNoaWZ0KGNodW5rKTtlbHNlIHN0YXRlLmJ1ZmZlci5wdXNoKGNodW5rKTtcbiAgICBpZiAoc3RhdGUubmVlZFJlYWRhYmxlKSBlbWl0UmVhZGFibGUoc3RyZWFtKTtcbiAgfVxuXG4gIG1heWJlUmVhZE1vcmUoc3RyZWFtLCBzdGF0ZSk7XG59XG5cbmZ1bmN0aW9uIGNodW5rSW52YWxpZChzdGF0ZSwgY2h1bmspIHtcbiAgdmFyIGVyO1xuXG4gIGlmICghX2lzVWludDhBcnJheShjaHVuaykgJiYgdHlwZW9mIGNodW5rICE9PSAnc3RyaW5nJyAmJiBjaHVuayAhPT0gdW5kZWZpbmVkICYmICFzdGF0ZS5vYmplY3RNb2RlKSB7XG4gICAgZXIgPSBuZXcgRVJSX0lOVkFMSURfQVJHX1RZUEUoJ2NodW5rJywgWydzdHJpbmcnLCAnQnVmZmVyJywgJ1VpbnQ4QXJyYXknXSwgY2h1bmspO1xuICB9XG5cbiAgcmV0dXJuIGVyO1xufVxuXG5SZWFkYWJsZS5wcm90b3R5cGUuaXNQYXVzZWQgPSBmdW5jdGlvbiAoKSB7XG4gIHJldHVybiB0aGlzLl9yZWFkYWJsZVN0YXRlLmZsb3dpbmcgPT09IGZhbHNlO1xufTsgLy8gYmFja3dhcmRzIGNvbXBhdGliaWxpdHkuXG5cblxuUmVhZGFibGUucHJvdG90eXBlLnNldEVuY29kaW5nID0gZnVuY3Rpb24gKGVuYykge1xuICBpZiAoIVN0cmluZ0RlY29kZXIpIFN0cmluZ0RlY29kZXIgPSByZXF1aXJlKCdzdHJpbmdfZGVjb2Rlci8nKS5TdHJpbmdEZWNvZGVyO1xuICB2YXIgZGVjb2RlciA9IG5ldyBTdHJpbmdEZWNvZGVyKGVuYyk7XG4gIHRoaXMuX3JlYWRhYmxlU3RhdGUuZGVjb2RlciA9IGRlY29kZXI7IC8vIElmIHNldEVuY29kaW5nKG51bGwpLCBkZWNvZGVyLmVuY29kaW5nIGVxdWFscyB1dGY4XG5cbiAgdGhpcy5fcmVhZGFibGVTdGF0ZS5lbmNvZGluZyA9IHRoaXMuX3JlYWRhYmxlU3RhdGUuZGVjb2Rlci5lbmNvZGluZzsgLy8gSXRlcmF0ZSBvdmVyIGN1cnJlbnQgYnVmZmVyIHRvIGNvbnZlcnQgYWxyZWFkeSBzdG9yZWQgQnVmZmVyczpcblxuICB2YXIgcCA9IHRoaXMuX3JlYWRhYmxlU3RhdGUuYnVmZmVyLmhlYWQ7XG4gIHZhciBjb250ZW50ID0gJyc7XG5cbiAgd2hpbGUgKHAgIT09IG51bGwpIHtcbiAgICBjb250ZW50ICs9IGRlY29kZXIud3JpdGUocC5kYXRhKTtcbiAgICBwID0gcC5uZXh0O1xuICB9XG5cbiAgdGhpcy5fcmVhZGFibGVTdGF0ZS5idWZmZXIuY2xlYXIoKTtcblxuICBpZiAoY29udGVudCAhPT0gJycpIHRoaXMuX3JlYWRhYmxlU3RhdGUuYnVmZmVyLnB1c2goY29udGVudCk7XG4gIHRoaXMuX3JlYWRhYmxlU3RhdGUubGVuZ3RoID0gY29udGVudC5sZW5ndGg7XG4gIHJldHVybiB0aGlzO1xufTsgLy8gRG9uJ3QgcmFpc2UgdGhlIGh3bSA+IDFHQlxuXG5cbnZhciBNQVhfSFdNID0gMHg0MDAwMDAwMDtcblxuZnVuY3Rpb24gY29tcHV0ZU5ld0hpZ2hXYXRlck1hcmsobikge1xuICBpZiAobiA+PSBNQVhfSFdNKSB7XG4gICAgLy8gVE9ETyhyb25hZyk6IFRocm93IEVSUl9WQUxVRV9PVVRfT0ZfUkFOR0UuXG4gICAgbiA9IE1BWF9IV007XG4gIH0gZWxzZSB7XG4gICAgLy8gR2V0IHRoZSBuZXh0IGhpZ2hlc3QgcG93ZXIgb2YgMiB0byBwcmV2ZW50IGluY3JlYXNpbmcgaHdtIGV4Y2Vzc2l2ZWx5IGluXG4gICAgLy8gdGlueSBhbW91bnRzXG4gICAgbi0tO1xuICAgIG4gfD0gbiA+Pj4gMTtcbiAgICBuIHw9IG4gPj4+IDI7XG4gICAgbiB8PSBuID4+PiA0O1xuICAgIG4gfD0gbiA+Pj4gODtcbiAgICBuIHw9IG4gPj4+IDE2O1xuICAgIG4rKztcbiAgfVxuXG4gIHJldHVybiBuO1xufSAvLyBUaGlzIGZ1bmN0aW9uIGlzIGRlc2lnbmVkIHRvIGJlIGlubGluYWJsZSwgc28gcGxlYXNlIHRha2UgY2FyZSB3aGVuIG1ha2luZ1xuLy8gY2hhbmdlcyB0byB0aGUgZnVuY3Rpb24gYm9keS5cblxuXG5mdW5jdGlvbiBob3dNdWNoVG9SZWFkKG4sIHN0YXRlKSB7XG4gIGlmIChuIDw9IDAgfHwgc3RhdGUubGVuZ3RoID09PSAwICYmIHN0YXRlLmVuZGVkKSByZXR1cm4gMDtcbiAgaWYgKHN0YXRlLm9iamVjdE1vZGUpIHJldHVybiAxO1xuXG4gIGlmIChuICE9PSBuKSB7XG4gICAgLy8gT25seSBmbG93IG9uZSBidWZmZXIgYXQgYSB0aW1lXG4gICAgaWYgKHN0YXRlLmZsb3dpbmcgJiYgc3RhdGUubGVuZ3RoKSByZXR1cm4gc3RhdGUuYnVmZmVyLmhlYWQuZGF0YS5sZW5ndGg7ZWxzZSByZXR1cm4gc3RhdGUubGVuZ3RoO1xuICB9IC8vIElmIHdlJ3JlIGFza2luZyBmb3IgbW9yZSB0aGFuIHRoZSBjdXJyZW50IGh3bSwgdGhlbiByYWlzZSB0aGUgaHdtLlxuXG5cbiAgaWYgKG4gPiBzdGF0ZS5oaWdoV2F0ZXJNYXJrKSBzdGF0ZS5oaWdoV2F0ZXJNYXJrID0gY29tcHV0ZU5ld0hpZ2hXYXRlck1hcmsobik7XG4gIGlmIChuIDw9IHN0YXRlLmxlbmd0aCkgcmV0dXJuIG47IC8vIERvbid0IGhhdmUgZW5vdWdoXG5cbiAgaWYgKCFzdGF0ZS5lbmRlZCkge1xuICAgIHN0YXRlLm5lZWRSZWFkYWJsZSA9IHRydWU7XG4gICAgcmV0dXJuIDA7XG4gIH1cblxuICByZXR1cm4gc3RhdGUubGVuZ3RoO1xufSAvLyB5b3UgY2FuIG92ZXJyaWRlIGVpdGhlciB0aGlzIG1ldGhvZCwgb3IgdGhlIGFzeW5jIF9yZWFkKG4pIGJlbG93LlxuXG5cblJlYWRhYmxlLnByb3RvdHlwZS5yZWFkID0gZnVuY3Rpb24gKG4pIHtcbiAgZGVidWcoJ3JlYWQnLCBuKTtcbiAgbiA9IHBhcnNlSW50KG4sIDEwKTtcbiAgdmFyIHN0YXRlID0gdGhpcy5fcmVhZGFibGVTdGF0ZTtcbiAgdmFyIG5PcmlnID0gbjtcbiAgaWYgKG4gIT09IDApIHN0YXRlLmVtaXR0ZWRSZWFkYWJsZSA9IGZhbHNlOyAvLyBpZiB3ZSdyZSBkb2luZyByZWFkKDApIHRvIHRyaWdnZXIgYSByZWFkYWJsZSBldmVudCwgYnV0IHdlXG4gIC8vIGFscmVhZHkgaGF2ZSBhIGJ1bmNoIG9mIGRhdGEgaW4gdGhlIGJ1ZmZlciwgdGhlbiBqdXN0IHRyaWdnZXJcbiAgLy8gdGhlICdyZWFkYWJsZScgZXZlbnQgYW5kIG1vdmUgb24uXG5cbiAgaWYgKG4gPT09IDAgJiYgc3RhdGUubmVlZFJlYWRhYmxlICYmICgoc3RhdGUuaGlnaFdhdGVyTWFyayAhPT0gMCA/IHN0YXRlLmxlbmd0aCA+PSBzdGF0ZS5oaWdoV2F0ZXJNYXJrIDogc3RhdGUubGVuZ3RoID4gMCkgfHwgc3RhdGUuZW5kZWQpKSB7XG4gICAgZGVidWcoJ3JlYWQ6IGVtaXRSZWFkYWJsZScsIHN0YXRlLmxlbmd0aCwgc3RhdGUuZW5kZWQpO1xuICAgIGlmIChzdGF0ZS5sZW5ndGggPT09IDAgJiYgc3RhdGUuZW5kZWQpIGVuZFJlYWRhYmxlKHRoaXMpO2Vsc2UgZW1pdFJlYWRhYmxlKHRoaXMpO1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgbiA9IGhvd011Y2hUb1JlYWQobiwgc3RhdGUpOyAvLyBpZiB3ZSd2ZSBlbmRlZCwgYW5kIHdlJ3JlIG5vdyBjbGVhciwgdGhlbiBmaW5pc2ggaXQgdXAuXG5cbiAgaWYgKG4gPT09IDAgJiYgc3RhdGUuZW5kZWQpIHtcbiAgICBpZiAoc3RhdGUubGVuZ3RoID09PSAwKSBlbmRSZWFkYWJsZSh0aGlzKTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfSAvLyBBbGwgdGhlIGFjdHVhbCBjaHVuayBnZW5lcmF0aW9uIGxvZ2ljIG5lZWRzIHRvIGJlXG4gIC8vICpiZWxvdyogdGhlIGNhbGwgdG8gX3JlYWQuICBUaGUgcmVhc29uIGlzIHRoYXQgaW4gY2VydGFpblxuICAvLyBzeW50aGV0aWMgc3RyZWFtIGNhc2VzLCBzdWNoIGFzIHBhc3N0aHJvdWdoIHN0cmVhbXMsIF9yZWFkXG4gIC8vIG1heSBiZSBhIGNvbXBsZXRlbHkgc3luY2hyb25vdXMgb3BlcmF0aW9uIHdoaWNoIG1heSBjaGFuZ2VcbiAgLy8gdGhlIHN0YXRlIG9mIHRoZSByZWFkIGJ1ZmZlciwgcHJvdmlkaW5nIGVub3VnaCBkYXRhIHdoZW5cbiAgLy8gYmVmb3JlIHRoZXJlIHdhcyAqbm90KiBlbm91Z2guXG4gIC8vXG4gIC8vIFNvLCB0aGUgc3RlcHMgYXJlOlxuICAvLyAxLiBGaWd1cmUgb3V0IHdoYXQgdGhlIHN0YXRlIG9mIHRoaW5ncyB3aWxsIGJlIGFmdGVyIHdlIGRvXG4gIC8vIGEgcmVhZCBmcm9tIHRoZSBidWZmZXIuXG4gIC8vXG4gIC8vIDIuIElmIHRoYXQgcmVzdWx0aW5nIHN0YXRlIHdpbGwgdHJpZ2dlciBhIF9yZWFkLCB0aGVuIGNhbGwgX3JlYWQuXG4gIC8vIE5vdGUgdGhhdCB0aGlzIG1heSBiZSBhc3luY2hyb25vdXMsIG9yIHN5bmNocm9ub3VzLiAgWWVzLCBpdCBpc1xuICAvLyBkZWVwbHkgdWdseSB0byB3cml0ZSBBUElzIHRoaXMgd2F5LCBidXQgdGhhdCBzdGlsbCBkb2Vzbid0IG1lYW5cbiAgLy8gdGhhdCB0aGUgUmVhZGFibGUgY2xhc3Mgc2hvdWxkIGJlaGF2ZSBpbXByb3Blcmx5LCBhcyBzdHJlYW1zIGFyZVxuICAvLyBkZXNpZ25lZCB0byBiZSBzeW5jL2FzeW5jIGFnbm9zdGljLlxuICAvLyBUYWtlIG5vdGUgaWYgdGhlIF9yZWFkIGNhbGwgaXMgc3luYyBvciBhc3luYyAoaWUsIGlmIHRoZSByZWFkIGNhbGxcbiAgLy8gaGFzIHJldHVybmVkIHlldCksIHNvIHRoYXQgd2Uga25vdyB3aGV0aGVyIG9yIG5vdCBpdCdzIHNhZmUgdG8gZW1pdFxuICAvLyAncmVhZGFibGUnIGV0Yy5cbiAgLy9cbiAgLy8gMy4gQWN0dWFsbHkgcHVsbCB0aGUgcmVxdWVzdGVkIGNodW5rcyBvdXQgb2YgdGhlIGJ1ZmZlciBhbmQgcmV0dXJuLlxuICAvLyBpZiB3ZSBuZWVkIGEgcmVhZGFibGUgZXZlbnQsIHRoZW4gd2UgbmVlZCB0byBkbyBzb21lIHJlYWRpbmcuXG5cblxuICB2YXIgZG9SZWFkID0gc3RhdGUubmVlZFJlYWRhYmxlO1xuICBkZWJ1ZygnbmVlZCByZWFkYWJsZScsIGRvUmVhZCk7IC8vIGlmIHdlIGN1cnJlbnRseSBoYXZlIGxlc3MgdGhhbiB0aGUgaGlnaFdhdGVyTWFyaywgdGhlbiBhbHNvIHJlYWQgc29tZVxuXG4gIGlmIChzdGF0ZS5sZW5ndGggPT09IDAgfHwgc3RhdGUubGVuZ3RoIC0gbiA8IHN0YXRlLmhpZ2hXYXRlck1hcmspIHtcbiAgICBkb1JlYWQgPSB0cnVlO1xuICAgIGRlYnVnKCdsZW5ndGggbGVzcyB0aGFuIHdhdGVybWFyaycsIGRvUmVhZCk7XG4gIH0gLy8gaG93ZXZlciwgaWYgd2UndmUgZW5kZWQsIHRoZW4gdGhlcmUncyBubyBwb2ludCwgYW5kIGlmIHdlJ3JlIGFscmVhZHlcbiAgLy8gcmVhZGluZywgdGhlbiBpdCdzIHVubmVjZXNzYXJ5LlxuXG5cbiAgaWYgKHN0YXRlLmVuZGVkIHx8IHN0YXRlLnJlYWRpbmcpIHtcbiAgICBkb1JlYWQgPSBmYWxzZTtcbiAgICBkZWJ1ZygncmVhZGluZyBvciBlbmRlZCcsIGRvUmVhZCk7XG4gIH0gZWxzZSBpZiAoZG9SZWFkKSB7XG4gICAgZGVidWcoJ2RvIHJlYWQnKTtcbiAgICBzdGF0ZS5yZWFkaW5nID0gdHJ1ZTtcbiAgICBzdGF0ZS5zeW5jID0gdHJ1ZTsgLy8gaWYgdGhlIGxlbmd0aCBpcyBjdXJyZW50bHkgemVybywgdGhlbiB3ZSAqbmVlZCogYSByZWFkYWJsZSBldmVudC5cblxuICAgIGlmIChzdGF0ZS5sZW5ndGggPT09IDApIHN0YXRlLm5lZWRSZWFkYWJsZSA9IHRydWU7IC8vIGNhbGwgaW50ZXJuYWwgcmVhZCBtZXRob2RcblxuICAgIHRoaXMuX3JlYWQoc3RhdGUuaGlnaFdhdGVyTWFyayk7XG5cbiAgICBzdGF0ZS5zeW5jID0gZmFsc2U7IC8vIElmIF9yZWFkIHB1c2hlZCBkYXRhIHN5bmNocm9ub3VzbHksIHRoZW4gYHJlYWRpbmdgIHdpbGwgYmUgZmFsc2UsXG4gICAgLy8gYW5kIHdlIG5lZWQgdG8gcmUtZXZhbHVhdGUgaG93IG11Y2ggZGF0YSB3ZSBjYW4gcmV0dXJuIHRvIHRoZSB1c2VyLlxuXG4gICAgaWYgKCFzdGF0ZS5yZWFkaW5nKSBuID0gaG93TXVjaFRvUmVhZChuT3JpZywgc3RhdGUpO1xuICB9XG5cbiAgdmFyIHJldDtcbiAgaWYgKG4gPiAwKSByZXQgPSBmcm9tTGlzdChuLCBzdGF0ZSk7ZWxzZSByZXQgPSBudWxsO1xuXG4gIGlmIChyZXQgPT09IG51bGwpIHtcbiAgICBzdGF0ZS5uZWVkUmVhZGFibGUgPSBzdGF0ZS5sZW5ndGggPD0gc3RhdGUuaGlnaFdhdGVyTWFyaztcbiAgICBuID0gMDtcbiAgfSBlbHNlIHtcbiAgICBzdGF0ZS5sZW5ndGggLT0gbjtcbiAgICBzdGF0ZS5hd2FpdERyYWluID0gMDtcbiAgfVxuXG4gIGlmIChzdGF0ZS5sZW5ndGggPT09IDApIHtcbiAgICAvLyBJZiB3ZSBoYXZlIG5vdGhpbmcgaW4gdGhlIGJ1ZmZlciwgdGhlbiB3ZSB3YW50IHRvIGtub3dcbiAgICAvLyBhcyBzb29uIGFzIHdlICpkbyogZ2V0IHNvbWV0aGluZyBpbnRvIHRoZSBidWZmZXIuXG4gICAgaWYgKCFzdGF0ZS5lbmRlZCkgc3RhdGUubmVlZFJlYWRhYmxlID0gdHJ1ZTsgLy8gSWYgd2UgdHJpZWQgdG8gcmVhZCgpIHBhc3QgdGhlIEVPRiwgdGhlbiBlbWl0IGVuZCBvbiB0aGUgbmV4dCB0aWNrLlxuXG4gICAgaWYgKG5PcmlnICE9PSBuICYmIHN0YXRlLmVuZGVkKSBlbmRSZWFkYWJsZSh0aGlzKTtcbiAgfVxuXG4gIGlmIChyZXQgIT09IG51bGwpIHRoaXMuZW1pdCgnZGF0YScsIHJldCk7XG4gIHJldHVybiByZXQ7XG59O1xuXG5mdW5jdGlvbiBvbkVvZkNodW5rKHN0cmVhbSwgc3RhdGUpIHtcbiAgZGVidWcoJ29uRW9mQ2h1bmsnKTtcbiAgaWYgKHN0YXRlLmVuZGVkKSByZXR1cm47XG5cbiAgaWYgKHN0YXRlLmRlY29kZXIpIHtcbiAgICB2YXIgY2h1bmsgPSBzdGF0ZS5kZWNvZGVyLmVuZCgpO1xuXG4gICAgaWYgKGNodW5rICYmIGNodW5rLmxlbmd0aCkge1xuICAgICAgc3RhdGUuYnVmZmVyLnB1c2goY2h1bmspO1xuICAgICAgc3RhdGUubGVuZ3RoICs9IHN0YXRlLm9iamVjdE1vZGUgPyAxIDogY2h1bmsubGVuZ3RoO1xuICAgIH1cbiAgfVxuXG4gIHN0YXRlLmVuZGVkID0gdHJ1ZTtcblxuICBpZiAoc3RhdGUuc3luYykge1xuICAgIC8vIGlmIHdlIGFyZSBzeW5jLCB3YWl0IHVudGlsIG5leHQgdGljayB0byBlbWl0IHRoZSBkYXRhLlxuICAgIC8vIE90aGVyd2lzZSB3ZSByaXNrIGVtaXR0aW5nIGRhdGEgaW4gdGhlIGZsb3coKVxuICAgIC8vIHRoZSByZWFkYWJsZSBjb2RlIHRyaWdnZXJzIGR1cmluZyBhIHJlYWQoKSBjYWxsXG4gICAgZW1pdFJlYWRhYmxlKHN0cmVhbSk7XG4gIH0gZWxzZSB7XG4gICAgLy8gZW1pdCAncmVhZGFibGUnIG5vdyB0byBtYWtlIHN1cmUgaXQgZ2V0cyBwaWNrZWQgdXAuXG4gICAgc3RhdGUubmVlZFJlYWRhYmxlID0gZmFsc2U7XG5cbiAgICBpZiAoIXN0YXRlLmVtaXR0ZWRSZWFkYWJsZSkge1xuICAgICAgc3RhdGUuZW1pdHRlZFJlYWRhYmxlID0gdHJ1ZTtcbiAgICAgIGVtaXRSZWFkYWJsZV8oc3RyZWFtKTtcbiAgICB9XG4gIH1cbn0gLy8gRG9uJ3QgZW1pdCByZWFkYWJsZSByaWdodCBhd2F5IGluIHN5bmMgbW9kZSwgYmVjYXVzZSB0aGlzIGNhbiB0cmlnZ2VyXG4vLyBhbm90aGVyIHJlYWQoKSBjYWxsID0+IHN0YWNrIG92ZXJmbG93LiAgVGhpcyB3YXksIGl0IG1pZ2h0IHRyaWdnZXJcbi8vIGEgbmV4dFRpY2sgcmVjdXJzaW9uIHdhcm5pbmcsIGJ1dCB0aGF0J3Mgbm90IHNvIGJhZC5cblxuXG5mdW5jdGlvbiBlbWl0UmVhZGFibGUoc3RyZWFtKSB7XG4gIHZhciBzdGF0ZSA9IHN0cmVhbS5fcmVhZGFibGVTdGF0ZTtcbiAgZGVidWcoJ2VtaXRSZWFkYWJsZScsIHN0YXRlLm5lZWRSZWFkYWJsZSwgc3RhdGUuZW1pdHRlZFJlYWRhYmxlKTtcbiAgc3RhdGUubmVlZFJlYWRhYmxlID0gZmFsc2U7XG5cbiAgaWYgKCFzdGF0ZS5lbWl0dGVkUmVhZGFibGUpIHtcbiAgICBkZWJ1ZygnZW1pdFJlYWRhYmxlJywgc3RhdGUuZmxvd2luZyk7XG4gICAgc3RhdGUuZW1pdHRlZFJlYWRhYmxlID0gdHJ1ZTtcbiAgICBwcm9jZXNzLm5leHRUaWNrKGVtaXRSZWFkYWJsZV8sIHN0cmVhbSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gZW1pdFJlYWRhYmxlXyhzdHJlYW0pIHtcbiAgdmFyIHN0YXRlID0gc3RyZWFtLl9yZWFkYWJsZVN0YXRlO1xuICBkZWJ1ZygnZW1pdFJlYWRhYmxlXycsIHN0YXRlLmRlc3Ryb3llZCwgc3RhdGUubGVuZ3RoLCBzdGF0ZS5lbmRlZCk7XG5cbiAgaWYgKCFzdGF0ZS5kZXN0cm95ZWQgJiYgKHN0YXRlLmxlbmd0aCB8fCBzdGF0ZS5lbmRlZCkpIHtcbiAgICBzdHJlYW0uZW1pdCgncmVhZGFibGUnKTtcbiAgICBzdGF0ZS5lbWl0dGVkUmVhZGFibGUgPSBmYWxzZTtcbiAgfSAvLyBUaGUgc3RyZWFtIG5lZWRzIGFub3RoZXIgcmVhZGFibGUgZXZlbnQgaWZcbiAgLy8gMS4gSXQgaXMgbm90IGZsb3dpbmcsIGFzIHRoZSBmbG93IG1lY2hhbmlzbSB3aWxsIHRha2VcbiAgLy8gICAgY2FyZSBvZiBpdC5cbiAgLy8gMi4gSXQgaXMgbm90IGVuZGVkLlxuICAvLyAzLiBJdCBpcyBiZWxvdyB0aGUgaGlnaFdhdGVyTWFyaywgc28gd2UgY2FuIHNjaGVkdWxlXG4gIC8vICAgIGFub3RoZXIgcmVhZGFibGUgbGF0ZXIuXG5cblxuICBzdGF0ZS5uZWVkUmVhZGFibGUgPSAhc3RhdGUuZmxvd2luZyAmJiAhc3RhdGUuZW5kZWQgJiYgc3RhdGUubGVuZ3RoIDw9IHN0YXRlLmhpZ2hXYXRlck1hcms7XG4gIGZsb3coc3RyZWFtKTtcbn0gLy8gYXQgdGhpcyBwb2ludCwgdGhlIHVzZXIgaGFzIHByZXN1bWFibHkgc2VlbiB0aGUgJ3JlYWRhYmxlJyBldmVudCxcbi8vIGFuZCBjYWxsZWQgcmVhZCgpIHRvIGNvbnN1bWUgc29tZSBkYXRhLiAgdGhhdCBtYXkgaGF2ZSB0cmlnZ2VyZWRcbi8vIGluIHR1cm4gYW5vdGhlciBfcmVhZChuKSBjYWxsLCBpbiB3aGljaCBjYXNlIHJlYWRpbmcgPSB0cnVlIGlmXG4vLyBpdCdzIGluIHByb2dyZXNzLlxuLy8gSG93ZXZlciwgaWYgd2UncmUgbm90IGVuZGVkLCBvciByZWFkaW5nLCBhbmQgdGhlIGxlbmd0aCA8IGh3bSxcbi8vIHRoZW4gZ28gYWhlYWQgYW5kIHRyeSB0byByZWFkIHNvbWUgbW9yZSBwcmVlbXB0aXZlbHkuXG5cblxuZnVuY3Rpb24gbWF5YmVSZWFkTW9yZShzdHJlYW0sIHN0YXRlKSB7XG4gIGlmICghc3RhdGUucmVhZGluZ01vcmUpIHtcbiAgICBzdGF0ZS5yZWFkaW5nTW9yZSA9IHRydWU7XG4gICAgcHJvY2Vzcy5uZXh0VGljayhtYXliZVJlYWRNb3JlXywgc3RyZWFtLCBzdGF0ZSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gbWF5YmVSZWFkTW9yZV8oc3RyZWFtLCBzdGF0ZSkge1xuICAvLyBBdHRlbXB0IHRvIHJlYWQgbW9yZSBkYXRhIGlmIHdlIHNob3VsZC5cbiAgLy9cbiAgLy8gVGhlIGNvbmRpdGlvbnMgZm9yIHJlYWRpbmcgbW9yZSBkYXRhIGFyZSAob25lIG9mKTpcbiAgLy8gLSBOb3QgZW5vdWdoIGRhdGEgYnVmZmVyZWQgKHN0YXRlLmxlbmd0aCA8IHN0YXRlLmhpZ2hXYXRlck1hcmspLiBUaGUgbG9vcFxuICAvLyAgIGlzIHJlc3BvbnNpYmxlIGZvciBmaWxsaW5nIHRoZSBidWZmZXIgd2l0aCBlbm91Z2ggZGF0YSBpZiBzdWNoIGRhdGFcbiAgLy8gICBpcyBhdmFpbGFibGUuIElmIGhpZ2hXYXRlck1hcmsgaXMgMCBhbmQgd2UgYXJlIG5vdCBpbiB0aGUgZmxvd2luZyBtb2RlXG4gIC8vICAgd2Ugc2hvdWxkIF9ub3RfIGF0dGVtcHQgdG8gYnVmZmVyIGFueSBleHRyYSBkYXRhLiBXZSdsbCBnZXQgbW9yZSBkYXRhXG4gIC8vICAgd2hlbiB0aGUgc3RyZWFtIGNvbnN1bWVyIGNhbGxzIHJlYWQoKSBpbnN0ZWFkLlxuICAvLyAtIE5vIGRhdGEgaW4gdGhlIGJ1ZmZlciwgYW5kIHRoZSBzdHJlYW0gaXMgaW4gZmxvd2luZyBtb2RlLiBJbiB0aGlzIG1vZGVcbiAgLy8gICB0aGUgbG9vcCBiZWxvdyBpcyByZXNwb25zaWJsZSBmb3IgZW5zdXJpbmcgcmVhZCgpIGlzIGNhbGxlZC4gRmFpbGluZyB0b1xuICAvLyAgIGNhbGwgcmVhZCBoZXJlIHdvdWxkIGFib3J0IHRoZSBmbG93IGFuZCB0aGVyZSdzIG5vIG90aGVyIG1lY2hhbmlzbSBmb3JcbiAgLy8gICBjb250aW51aW5nIHRoZSBmbG93IGlmIHRoZSBzdHJlYW0gY29uc3VtZXIgaGFzIGp1c3Qgc3Vic2NyaWJlZCB0byB0aGVcbiAgLy8gICAnZGF0YScgZXZlbnQuXG4gIC8vXG4gIC8vIEluIGFkZGl0aW9uIHRvIHRoZSBhYm92ZSBjb25kaXRpb25zIHRvIGtlZXAgcmVhZGluZyBkYXRhLCB0aGUgZm9sbG93aW5nXG4gIC8vIGNvbmRpdGlvbnMgcHJldmVudCB0aGUgZGF0YSBmcm9tIGJlaW5nIHJlYWQ6XG4gIC8vIC0gVGhlIHN0cmVhbSBoYXMgZW5kZWQgKHN0YXRlLmVuZGVkKS5cbiAgLy8gLSBUaGVyZSBpcyBhbHJlYWR5IGEgcGVuZGluZyAncmVhZCcgb3BlcmF0aW9uIChzdGF0ZS5yZWFkaW5nKS4gVGhpcyBpcyBhXG4gIC8vICAgY2FzZSB3aGVyZSB0aGUgdGhlIHN0cmVhbSBoYXMgY2FsbGVkIHRoZSBpbXBsZW1lbnRhdGlvbiBkZWZpbmVkIF9yZWFkKClcbiAgLy8gICBtZXRob2QsIGJ1dCB0aGV5IGFyZSBwcm9jZXNzaW5nIHRoZSBjYWxsIGFzeW5jaHJvbm91c2x5IGFuZCBoYXZlIF9ub3RfXG4gIC8vICAgY2FsbGVkIHB1c2goKSB3aXRoIG5ldyBkYXRhLiBJbiB0aGlzIGNhc2Ugd2Ugc2tpcCBwZXJmb3JtaW5nIG1vcmVcbiAgLy8gICByZWFkKClzLiBUaGUgZXhlY3V0aW9uIGVuZHMgaW4gdGhpcyBtZXRob2QgYWdhaW4gYWZ0ZXIgdGhlIF9yZWFkKCkgZW5kc1xuICAvLyAgIHVwIGNhbGxpbmcgcHVzaCgpIHdpdGggbW9yZSBkYXRhLlxuICB3aGlsZSAoIXN0YXRlLnJlYWRpbmcgJiYgIXN0YXRlLmVuZGVkICYmIChzdGF0ZS5sZW5ndGggPCBzdGF0ZS5oaWdoV2F0ZXJNYXJrIHx8IHN0YXRlLmZsb3dpbmcgJiYgc3RhdGUubGVuZ3RoID09PSAwKSkge1xuICAgIHZhciBsZW4gPSBzdGF0ZS5sZW5ndGg7XG4gICAgZGVidWcoJ21heWJlUmVhZE1vcmUgcmVhZCAwJyk7XG4gICAgc3RyZWFtLnJlYWQoMCk7XG4gICAgaWYgKGxlbiA9PT0gc3RhdGUubGVuZ3RoKSAvLyBkaWRuJ3QgZ2V0IGFueSBkYXRhLCBzdG9wIHNwaW5uaW5nLlxuICAgICAgYnJlYWs7XG4gIH1cblxuICBzdGF0ZS5yZWFkaW5nTW9yZSA9IGZhbHNlO1xufSAvLyBhYnN0cmFjdCBtZXRob2QuICB0byBiZSBvdmVycmlkZGVuIGluIHNwZWNpZmljIGltcGxlbWVudGF0aW9uIGNsYXNzZXMuXG4vLyBjYWxsIGNiKGVyLCBkYXRhKSB3aGVyZSBkYXRhIGlzIDw9IG4gaW4gbGVuZ3RoLlxuLy8gZm9yIHZpcnR1YWwgKG5vbi1zdHJpbmcsIG5vbi1idWZmZXIpIHN0cmVhbXMsIFwibGVuZ3RoXCIgaXMgc29tZXdoYXRcbi8vIGFyYml0cmFyeSwgYW5kIHBlcmhhcHMgbm90IHZlcnkgbWVhbmluZ2Z1bC5cblxuXG5SZWFkYWJsZS5wcm90b3R5cGUuX3JlYWQgPSBmdW5jdGlvbiAobikge1xuICBlcnJvck9yRGVzdHJveSh0aGlzLCBuZXcgRVJSX01FVEhPRF9OT1RfSU1QTEVNRU5URUQoJ19yZWFkKCknKSk7XG59O1xuXG5SZWFkYWJsZS5wcm90b3R5cGUucGlwZSA9IGZ1bmN0aW9uIChkZXN0LCBwaXBlT3B0cykge1xuICB2YXIgc3JjID0gdGhpcztcbiAgdmFyIHN0YXRlID0gdGhpcy5fcmVhZGFibGVTdGF0ZTtcblxuICBzd2l0Y2ggKHN0YXRlLnBpcGVzQ291bnQpIHtcbiAgICBjYXNlIDA6XG4gICAgICBzdGF0ZS5waXBlcyA9IGRlc3Q7XG4gICAgICBicmVhaztcblxuICAgIGNhc2UgMTpcbiAgICAgIHN0YXRlLnBpcGVzID0gW3N0YXRlLnBpcGVzLCBkZXN0XTtcbiAgICAgIGJyZWFrO1xuXG4gICAgZGVmYXVsdDpcbiAgICAgIHN0YXRlLnBpcGVzLnB1c2goZGVzdCk7XG4gICAgICBicmVhaztcbiAgfVxuXG4gIHN0YXRlLnBpcGVzQ291bnQgKz0gMTtcbiAgZGVidWcoJ3BpcGUgY291bnQ9JWQgb3B0cz0laicsIHN0YXRlLnBpcGVzQ291bnQsIHBpcGVPcHRzKTtcbiAgdmFyIGRvRW5kID0gKCFwaXBlT3B0cyB8fCBwaXBlT3B0cy5lbmQgIT09IGZhbHNlKSAmJiBkZXN0ICE9PSBwcm9jZXNzLnN0ZG91dCAmJiBkZXN0ICE9PSBwcm9jZXNzLnN0ZGVycjtcbiAgdmFyIGVuZEZuID0gZG9FbmQgPyBvbmVuZCA6IHVucGlwZTtcbiAgaWYgKHN0YXRlLmVuZEVtaXR0ZWQpIHByb2Nlc3MubmV4dFRpY2soZW5kRm4pO2Vsc2Ugc3JjLm9uY2UoJ2VuZCcsIGVuZEZuKTtcbiAgZGVzdC5vbigndW5waXBlJywgb251bnBpcGUpO1xuXG4gIGZ1bmN0aW9uIG9udW5waXBlKHJlYWRhYmxlLCB1bnBpcGVJbmZvKSB7XG4gICAgZGVidWcoJ29udW5waXBlJyk7XG5cbiAgICBpZiAocmVhZGFibGUgPT09IHNyYykge1xuICAgICAgaWYgKHVucGlwZUluZm8gJiYgdW5waXBlSW5mby5oYXNVbnBpcGVkID09PSBmYWxzZSkge1xuICAgICAgICB1bnBpcGVJbmZvLmhhc1VucGlwZWQgPSB0cnVlO1xuICAgICAgICBjbGVhbnVwKCk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gb25lbmQoKSB7XG4gICAgZGVidWcoJ29uZW5kJyk7XG4gICAgZGVzdC5lbmQoKTtcbiAgfSAvLyB3aGVuIHRoZSBkZXN0IGRyYWlucywgaXQgcmVkdWNlcyB0aGUgYXdhaXREcmFpbiBjb3VudGVyXG4gIC8vIG9uIHRoZSBzb3VyY2UuICBUaGlzIHdvdWxkIGJlIG1vcmUgZWxlZ2FudCB3aXRoIGEgLm9uY2UoKVxuICAvLyBoYW5kbGVyIGluIGZsb3coKSwgYnV0IGFkZGluZyBhbmQgcmVtb3ZpbmcgcmVwZWF0ZWRseSBpc1xuICAvLyB0b28gc2xvdy5cblxuXG4gIHZhciBvbmRyYWluID0gcGlwZU9uRHJhaW4oc3JjKTtcbiAgZGVzdC5vbignZHJhaW4nLCBvbmRyYWluKTtcbiAgdmFyIGNsZWFuZWRVcCA9IGZhbHNlO1xuXG4gIGZ1bmN0aW9uIGNsZWFudXAoKSB7XG4gICAgZGVidWcoJ2NsZWFudXAnKTsgLy8gY2xlYW51cCBldmVudCBoYW5kbGVycyBvbmNlIHRoZSBwaXBlIGlzIGJyb2tlblxuXG4gICAgZGVzdC5yZW1vdmVMaXN0ZW5lcignY2xvc2UnLCBvbmNsb3NlKTtcbiAgICBkZXN0LnJlbW92ZUxpc3RlbmVyKCdmaW5pc2gnLCBvbmZpbmlzaCk7XG4gICAgZGVzdC5yZW1vdmVMaXN0ZW5lcignZHJhaW4nLCBvbmRyYWluKTtcbiAgICBkZXN0LnJlbW92ZUxpc3RlbmVyKCdlcnJvcicsIG9uZXJyb3IpO1xuICAgIGRlc3QucmVtb3ZlTGlzdGVuZXIoJ3VucGlwZScsIG9udW5waXBlKTtcbiAgICBzcmMucmVtb3ZlTGlzdGVuZXIoJ2VuZCcsIG9uZW5kKTtcbiAgICBzcmMucmVtb3ZlTGlzdGVuZXIoJ2VuZCcsIHVucGlwZSk7XG4gICAgc3JjLnJlbW92ZUxpc3RlbmVyKCdkYXRhJywgb25kYXRhKTtcbiAgICBjbGVhbmVkVXAgPSB0cnVlOyAvLyBpZiB0aGUgcmVhZGVyIGlzIHdhaXRpbmcgZm9yIGEgZHJhaW4gZXZlbnQgZnJvbSB0aGlzXG4gICAgLy8gc3BlY2lmaWMgd3JpdGVyLCB0aGVuIGl0IHdvdWxkIGNhdXNlIGl0IHRvIG5ldmVyIHN0YXJ0XG4gICAgLy8gZmxvd2luZyBhZ2Fpbi5cbiAgICAvLyBTbywgaWYgdGhpcyBpcyBhd2FpdGluZyBhIGRyYWluLCB0aGVuIHdlIGp1c3QgY2FsbCBpdCBub3cuXG4gICAgLy8gSWYgd2UgZG9uJ3Qga25vdywgdGhlbiBhc3N1bWUgdGhhdCB3ZSBhcmUgd2FpdGluZyBmb3Igb25lLlxuXG4gICAgaWYgKHN0YXRlLmF3YWl0RHJhaW4gJiYgKCFkZXN0Ll93cml0YWJsZVN0YXRlIHx8IGRlc3QuX3dyaXRhYmxlU3RhdGUubmVlZERyYWluKSkgb25kcmFpbigpO1xuICB9XG5cbiAgc3JjLm9uKCdkYXRhJywgb25kYXRhKTtcblxuICBmdW5jdGlvbiBvbmRhdGEoY2h1bmspIHtcbiAgICBkZWJ1Zygnb25kYXRhJyk7XG4gICAgdmFyIHJldCA9IGRlc3Qud3JpdGUoY2h1bmspO1xuICAgIGRlYnVnKCdkZXN0LndyaXRlJywgcmV0KTtcblxuICAgIGlmIChyZXQgPT09IGZhbHNlKSB7XG4gICAgICAvLyBJZiB0aGUgdXNlciB1bnBpcGVkIGR1cmluZyBgZGVzdC53cml0ZSgpYCwgaXQgaXMgcG9zc2libGVcbiAgICAgIC8vIHRvIGdldCBzdHVjayBpbiBhIHBlcm1hbmVudGx5IHBhdXNlZCBzdGF0ZSBpZiB0aGF0IHdyaXRlXG4gICAgICAvLyBhbHNvIHJldHVybmVkIGZhbHNlLlxuICAgICAgLy8gPT4gQ2hlY2sgd2hldGhlciBgZGVzdGAgaXMgc3RpbGwgYSBwaXBpbmcgZGVzdGluYXRpb24uXG4gICAgICBpZiAoKHN0YXRlLnBpcGVzQ291bnQgPT09IDEgJiYgc3RhdGUucGlwZXMgPT09IGRlc3QgfHwgc3RhdGUucGlwZXNDb3VudCA+IDEgJiYgaW5kZXhPZihzdGF0ZS5waXBlcywgZGVzdCkgIT09IC0xKSAmJiAhY2xlYW5lZFVwKSB7XG4gICAgICAgIGRlYnVnKCdmYWxzZSB3cml0ZSByZXNwb25zZSwgcGF1c2UnLCBzdGF0ZS5hd2FpdERyYWluKTtcbiAgICAgICAgc3RhdGUuYXdhaXREcmFpbisrO1xuICAgICAgfVxuXG4gICAgICBzcmMucGF1c2UoKTtcbiAgICB9XG4gIH0gLy8gaWYgdGhlIGRlc3QgaGFzIGFuIGVycm9yLCB0aGVuIHN0b3AgcGlwaW5nIGludG8gaXQuXG4gIC8vIGhvd2V2ZXIsIGRvbid0IHN1cHByZXNzIHRoZSB0aHJvd2luZyBiZWhhdmlvciBmb3IgdGhpcy5cblxuXG4gIGZ1bmN0aW9uIG9uZXJyb3IoZXIpIHtcbiAgICBkZWJ1Zygnb25lcnJvcicsIGVyKTtcbiAgICB1bnBpcGUoKTtcbiAgICBkZXN0LnJlbW92ZUxpc3RlbmVyKCdlcnJvcicsIG9uZXJyb3IpO1xuICAgIGlmIChFRWxpc3RlbmVyQ291bnQoZGVzdCwgJ2Vycm9yJykgPT09IDApIGVycm9yT3JEZXN0cm95KGRlc3QsIGVyKTtcbiAgfSAvLyBNYWtlIHN1cmUgb3VyIGVycm9yIGhhbmRsZXIgaXMgYXR0YWNoZWQgYmVmb3JlIHVzZXJsYW5kIG9uZXMuXG5cblxuICBwcmVwZW5kTGlzdGVuZXIoZGVzdCwgJ2Vycm9yJywgb25lcnJvcik7IC8vIEJvdGggY2xvc2UgYW5kIGZpbmlzaCBzaG91bGQgdHJpZ2dlciB1bnBpcGUsIGJ1dCBvbmx5IG9uY2UuXG5cbiAgZnVuY3Rpb24gb25jbG9zZSgpIHtcbiAgICBkZXN0LnJlbW92ZUxpc3RlbmVyKCdmaW5pc2gnLCBvbmZpbmlzaCk7XG4gICAgdW5waXBlKCk7XG4gIH1cblxuICBkZXN0Lm9uY2UoJ2Nsb3NlJywgb25jbG9zZSk7XG5cbiAgZnVuY3Rpb24gb25maW5pc2goKSB7XG4gICAgZGVidWcoJ29uZmluaXNoJyk7XG4gICAgZGVzdC5yZW1vdmVMaXN0ZW5lcignY2xvc2UnLCBvbmNsb3NlKTtcbiAgICB1bnBpcGUoKTtcbiAgfVxuXG4gIGRlc3Qub25jZSgnZmluaXNoJywgb25maW5pc2gpO1xuXG4gIGZ1bmN0aW9uIHVucGlwZSgpIHtcbiAgICBkZWJ1ZygndW5waXBlJyk7XG4gICAgc3JjLnVucGlwZShkZXN0KTtcbiAgfSAvLyB0ZWxsIHRoZSBkZXN0IHRoYXQgaXQncyBiZWluZyBwaXBlZCB0b1xuXG5cbiAgZGVzdC5lbWl0KCdwaXBlJywgc3JjKTsgLy8gc3RhcnQgdGhlIGZsb3cgaWYgaXQgaGFzbid0IGJlZW4gc3RhcnRlZCBhbHJlYWR5LlxuXG4gIGlmICghc3RhdGUuZmxvd2luZykge1xuICAgIGRlYnVnKCdwaXBlIHJlc3VtZScpO1xuICAgIHNyYy5yZXN1bWUoKTtcbiAgfVxuXG4gIHJldHVybiBkZXN0O1xufTtcblxuZnVuY3Rpb24gcGlwZU9uRHJhaW4oc3JjKSB7XG4gIHJldHVybiBmdW5jdGlvbiBwaXBlT25EcmFpbkZ1bmN0aW9uUmVzdWx0KCkge1xuICAgIHZhciBzdGF0ZSA9IHNyYy5fcmVhZGFibGVTdGF0ZTtcbiAgICBkZWJ1ZygncGlwZU9uRHJhaW4nLCBzdGF0ZS5hd2FpdERyYWluKTtcbiAgICBpZiAoc3RhdGUuYXdhaXREcmFpbikgc3RhdGUuYXdhaXREcmFpbi0tO1xuXG4gICAgaWYgKHN0YXRlLmF3YWl0RHJhaW4gPT09IDAgJiYgRUVsaXN0ZW5lckNvdW50KHNyYywgJ2RhdGEnKSkge1xuICAgICAgc3RhdGUuZmxvd2luZyA9IHRydWU7XG4gICAgICBmbG93KHNyYyk7XG4gICAgfVxuICB9O1xufVxuXG5SZWFkYWJsZS5wcm90b3R5cGUudW5waXBlID0gZnVuY3Rpb24gKGRlc3QpIHtcbiAgdmFyIHN0YXRlID0gdGhpcy5fcmVhZGFibGVTdGF0ZTtcbiAgdmFyIHVucGlwZUluZm8gPSB7XG4gICAgaGFzVW5waXBlZDogZmFsc2VcbiAgfTsgLy8gaWYgd2UncmUgbm90IHBpcGluZyBhbnl3aGVyZSwgdGhlbiBkbyBub3RoaW5nLlxuXG4gIGlmIChzdGF0ZS5waXBlc0NvdW50ID09PSAwKSByZXR1cm4gdGhpczsgLy8ganVzdCBvbmUgZGVzdGluYXRpb24uICBtb3N0IGNvbW1vbiBjYXNlLlxuXG4gIGlmIChzdGF0ZS5waXBlc0NvdW50ID09PSAxKSB7XG4gICAgLy8gcGFzc2VkIGluIG9uZSwgYnV0IGl0J3Mgbm90IHRoZSByaWdodCBvbmUuXG4gICAgaWYgKGRlc3QgJiYgZGVzdCAhPT0gc3RhdGUucGlwZXMpIHJldHVybiB0aGlzO1xuICAgIGlmICghZGVzdCkgZGVzdCA9IHN0YXRlLnBpcGVzOyAvLyBnb3QgYSBtYXRjaC5cblxuICAgIHN0YXRlLnBpcGVzID0gbnVsbDtcbiAgICBzdGF0ZS5waXBlc0NvdW50ID0gMDtcbiAgICBzdGF0ZS5mbG93aW5nID0gZmFsc2U7XG4gICAgaWYgKGRlc3QpIGRlc3QuZW1pdCgndW5waXBlJywgdGhpcywgdW5waXBlSW5mbyk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH0gLy8gc2xvdyBjYXNlLiBtdWx0aXBsZSBwaXBlIGRlc3RpbmF0aW9ucy5cblxuXG4gIGlmICghZGVzdCkge1xuICAgIC8vIHJlbW92ZSBhbGwuXG4gICAgdmFyIGRlc3RzID0gc3RhdGUucGlwZXM7XG4gICAgdmFyIGxlbiA9IHN0YXRlLnBpcGVzQ291bnQ7XG4gICAgc3RhdGUucGlwZXMgPSBudWxsO1xuICAgIHN0YXRlLnBpcGVzQ291bnQgPSAwO1xuICAgIHN0YXRlLmZsb3dpbmcgPSBmYWxzZTtcblxuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgIGRlc3RzW2ldLmVtaXQoJ3VucGlwZScsIHRoaXMsIHtcbiAgICAgICAgaGFzVW5waXBlZDogZmFsc2VcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHJldHVybiB0aGlzO1xuICB9IC8vIHRyeSB0byBmaW5kIHRoZSByaWdodCBvbmUuXG5cblxuICB2YXIgaW5kZXggPSBpbmRleE9mKHN0YXRlLnBpcGVzLCBkZXN0KTtcbiAgaWYgKGluZGV4ID09PSAtMSkgcmV0dXJuIHRoaXM7XG4gIHN0YXRlLnBpcGVzLnNwbGljZShpbmRleCwgMSk7XG4gIHN0YXRlLnBpcGVzQ291bnQgLT0gMTtcbiAgaWYgKHN0YXRlLnBpcGVzQ291bnQgPT09IDEpIHN0YXRlLnBpcGVzID0gc3RhdGUucGlwZXNbMF07XG4gIGRlc3QuZW1pdCgndW5waXBlJywgdGhpcywgdW5waXBlSW5mbyk7XG4gIHJldHVybiB0aGlzO1xufTsgLy8gc2V0IHVwIGRhdGEgZXZlbnRzIGlmIHRoZXkgYXJlIGFza2VkIGZvclxuLy8gRW5zdXJlIHJlYWRhYmxlIGxpc3RlbmVycyBldmVudHVhbGx5IGdldCBzb21ldGhpbmdcblxuXG5SZWFkYWJsZS5wcm90b3R5cGUub24gPSBmdW5jdGlvbiAoZXYsIGZuKSB7XG4gIHZhciByZXMgPSBTdHJlYW0ucHJvdG90eXBlLm9uLmNhbGwodGhpcywgZXYsIGZuKTtcbiAgdmFyIHN0YXRlID0gdGhpcy5fcmVhZGFibGVTdGF0ZTtcblxuICBpZiAoZXYgPT09ICdkYXRhJykge1xuICAgIC8vIHVwZGF0ZSByZWFkYWJsZUxpc3RlbmluZyBzbyB0aGF0IHJlc3VtZSgpIG1heSBiZSBhIG5vLW9wXG4gICAgLy8gYSBmZXcgbGluZXMgZG93bi4gVGhpcyBpcyBuZWVkZWQgdG8gc3VwcG9ydCBvbmNlKCdyZWFkYWJsZScpLlxuICAgIHN0YXRlLnJlYWRhYmxlTGlzdGVuaW5nID0gdGhpcy5saXN0ZW5lckNvdW50KCdyZWFkYWJsZScpID4gMDsgLy8gVHJ5IHN0YXJ0IGZsb3dpbmcgb24gbmV4dCB0aWNrIGlmIHN0cmVhbSBpc24ndCBleHBsaWNpdGx5IHBhdXNlZFxuXG4gICAgaWYgKHN0YXRlLmZsb3dpbmcgIT09IGZhbHNlKSB0aGlzLnJlc3VtZSgpO1xuICB9IGVsc2UgaWYgKGV2ID09PSAncmVhZGFibGUnKSB7XG4gICAgaWYgKCFzdGF0ZS5lbmRFbWl0dGVkICYmICFzdGF0ZS5yZWFkYWJsZUxpc3RlbmluZykge1xuICAgICAgc3RhdGUucmVhZGFibGVMaXN0ZW5pbmcgPSBzdGF0ZS5uZWVkUmVhZGFibGUgPSB0cnVlO1xuICAgICAgc3RhdGUuZmxvd2luZyA9IGZhbHNlO1xuICAgICAgc3RhdGUuZW1pdHRlZFJlYWRhYmxlID0gZmFsc2U7XG4gICAgICBkZWJ1Zygnb24gcmVhZGFibGUnLCBzdGF0ZS5sZW5ndGgsIHN0YXRlLnJlYWRpbmcpO1xuXG4gICAgICBpZiAoc3RhdGUubGVuZ3RoKSB7XG4gICAgICAgIGVtaXRSZWFkYWJsZSh0aGlzKTtcbiAgICAgIH0gZWxzZSBpZiAoIXN0YXRlLnJlYWRpbmcpIHtcbiAgICAgICAgcHJvY2Vzcy5uZXh0VGljayhuUmVhZGluZ05leHRUaWNrLCB0aGlzKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICByZXR1cm4gcmVzO1xufTtcblxuUmVhZGFibGUucHJvdG90eXBlLmFkZExpc3RlbmVyID0gUmVhZGFibGUucHJvdG90eXBlLm9uO1xuXG5SZWFkYWJsZS5wcm90b3R5cGUucmVtb3ZlTGlzdGVuZXIgPSBmdW5jdGlvbiAoZXYsIGZuKSB7XG4gIHZhciByZXMgPSBTdHJlYW0ucHJvdG90eXBlLnJlbW92ZUxpc3RlbmVyLmNhbGwodGhpcywgZXYsIGZuKTtcblxuICBpZiAoZXYgPT09ICdyZWFkYWJsZScpIHtcbiAgICAvLyBXZSBuZWVkIHRvIGNoZWNrIGlmIHRoZXJlIGlzIHNvbWVvbmUgc3RpbGwgbGlzdGVuaW5nIHRvXG4gICAgLy8gcmVhZGFibGUgYW5kIHJlc2V0IHRoZSBzdGF0ZS4gSG93ZXZlciB0aGlzIG5lZWRzIHRvIGhhcHBlblxuICAgIC8vIGFmdGVyIHJlYWRhYmxlIGhhcyBiZWVuIGVtaXR0ZWQgYnV0IGJlZm9yZSBJL08gKG5leHRUaWNrKSB0b1xuICAgIC8vIHN1cHBvcnQgb25jZSgncmVhZGFibGUnLCBmbikgY3ljbGVzLiBUaGlzIG1lYW5zIHRoYXQgY2FsbGluZ1xuICAgIC8vIHJlc3VtZSB3aXRoaW4gdGhlIHNhbWUgdGljayB3aWxsIGhhdmUgbm9cbiAgICAvLyBlZmZlY3QuXG4gICAgcHJvY2Vzcy5uZXh0VGljayh1cGRhdGVSZWFkYWJsZUxpc3RlbmluZywgdGhpcyk7XG4gIH1cblxuICByZXR1cm4gcmVzO1xufTtcblxuUmVhZGFibGUucHJvdG90eXBlLnJlbW92ZUFsbExpc3RlbmVycyA9IGZ1bmN0aW9uIChldikge1xuICB2YXIgcmVzID0gU3RyZWFtLnByb3RvdHlwZS5yZW1vdmVBbGxMaXN0ZW5lcnMuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcblxuICBpZiAoZXYgPT09ICdyZWFkYWJsZScgfHwgZXYgPT09IHVuZGVmaW5lZCkge1xuICAgIC8vIFdlIG5lZWQgdG8gY2hlY2sgaWYgdGhlcmUgaXMgc29tZW9uZSBzdGlsbCBsaXN0ZW5pbmcgdG9cbiAgICAvLyByZWFkYWJsZSBhbmQgcmVzZXQgdGhlIHN0YXRlLiBIb3dldmVyIHRoaXMgbmVlZHMgdG8gaGFwcGVuXG4gICAgLy8gYWZ0ZXIgcmVhZGFibGUgaGFzIGJlZW4gZW1pdHRlZCBidXQgYmVmb3JlIEkvTyAobmV4dFRpY2spIHRvXG4gICAgLy8gc3VwcG9ydCBvbmNlKCdyZWFkYWJsZScsIGZuKSBjeWNsZXMuIFRoaXMgbWVhbnMgdGhhdCBjYWxsaW5nXG4gICAgLy8gcmVzdW1lIHdpdGhpbiB0aGUgc2FtZSB0aWNrIHdpbGwgaGF2ZSBub1xuICAgIC8vIGVmZmVjdC5cbiAgICBwcm9jZXNzLm5leHRUaWNrKHVwZGF0ZVJlYWRhYmxlTGlzdGVuaW5nLCB0aGlzKTtcbiAgfVxuXG4gIHJldHVybiByZXM7XG59O1xuXG5mdW5jdGlvbiB1cGRhdGVSZWFkYWJsZUxpc3RlbmluZyhzZWxmKSB7XG4gIHZhciBzdGF0ZSA9IHNlbGYuX3JlYWRhYmxlU3RhdGU7XG4gIHN0YXRlLnJlYWRhYmxlTGlzdGVuaW5nID0gc2VsZi5saXN0ZW5lckNvdW50KCdyZWFkYWJsZScpID4gMDtcblxuICBpZiAoc3RhdGUucmVzdW1lU2NoZWR1bGVkICYmICFzdGF0ZS5wYXVzZWQpIHtcbiAgICAvLyBmbG93aW5nIG5lZWRzIHRvIGJlIHNldCB0byB0cnVlIG5vdywgb3RoZXJ3aXNlXG4gICAgLy8gdGhlIHVwY29taW5nIHJlc3VtZSB3aWxsIG5vdCBmbG93LlxuICAgIHN0YXRlLmZsb3dpbmcgPSB0cnVlOyAvLyBjcnVkZSB3YXkgdG8gY2hlY2sgaWYgd2Ugc2hvdWxkIHJlc3VtZVxuICB9IGVsc2UgaWYgKHNlbGYubGlzdGVuZXJDb3VudCgnZGF0YScpID4gMCkge1xuICAgIHNlbGYucmVzdW1lKCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gblJlYWRpbmdOZXh0VGljayhzZWxmKSB7XG4gIGRlYnVnKCdyZWFkYWJsZSBuZXh0dGljayByZWFkIDAnKTtcbiAgc2VsZi5yZWFkKDApO1xufSAvLyBwYXVzZSgpIGFuZCByZXN1bWUoKSBhcmUgcmVtbmFudHMgb2YgdGhlIGxlZ2FjeSByZWFkYWJsZSBzdHJlYW0gQVBJXG4vLyBJZiB0aGUgdXNlciB1c2VzIHRoZW0sIHRoZW4gc3dpdGNoIGludG8gb2xkIG1vZGUuXG5cblxuUmVhZGFibGUucHJvdG90eXBlLnJlc3VtZSA9IGZ1bmN0aW9uICgpIHtcbiAgdmFyIHN0YXRlID0gdGhpcy5fcmVhZGFibGVTdGF0ZTtcblxuICBpZiAoIXN0YXRlLmZsb3dpbmcpIHtcbiAgICBkZWJ1ZygncmVzdW1lJyk7IC8vIHdlIGZsb3cgb25seSBpZiB0aGVyZSBpcyBubyBvbmUgbGlzdGVuaW5nXG4gICAgLy8gZm9yIHJlYWRhYmxlLCBidXQgd2Ugc3RpbGwgaGF2ZSB0byBjYWxsXG4gICAgLy8gcmVzdW1lKClcblxuICAgIHN0YXRlLmZsb3dpbmcgPSAhc3RhdGUucmVhZGFibGVMaXN0ZW5pbmc7XG4gICAgcmVzdW1lKHRoaXMsIHN0YXRlKTtcbiAgfVxuXG4gIHN0YXRlLnBhdXNlZCA9IGZhbHNlO1xuICByZXR1cm4gdGhpcztcbn07XG5cbmZ1bmN0aW9uIHJlc3VtZShzdHJlYW0sIHN0YXRlKSB7XG4gIGlmICghc3RhdGUucmVzdW1lU2NoZWR1bGVkKSB7XG4gICAgc3RhdGUucmVzdW1lU2NoZWR1bGVkID0gdHJ1ZTtcbiAgICBwcm9jZXNzLm5leHRUaWNrKHJlc3VtZV8sIHN0cmVhbSwgc3RhdGUpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHJlc3VtZV8oc3RyZWFtLCBzdGF0ZSkge1xuICBkZWJ1ZygncmVzdW1lJywgc3RhdGUucmVhZGluZyk7XG5cbiAgaWYgKCFzdGF0ZS5yZWFkaW5nKSB7XG4gICAgc3RyZWFtLnJlYWQoMCk7XG4gIH1cblxuICBzdGF0ZS5yZXN1bWVTY2hlZHVsZWQgPSBmYWxzZTtcbiAgc3RyZWFtLmVtaXQoJ3Jlc3VtZScpO1xuICBmbG93KHN0cmVhbSk7XG4gIGlmIChzdGF0ZS5mbG93aW5nICYmICFzdGF0ZS5yZWFkaW5nKSBzdHJlYW0ucmVhZCgwKTtcbn1cblxuUmVhZGFibGUucHJvdG90eXBlLnBhdXNlID0gZnVuY3Rpb24gKCkge1xuICBkZWJ1ZygnY2FsbCBwYXVzZSBmbG93aW5nPSVqJywgdGhpcy5fcmVhZGFibGVTdGF0ZS5mbG93aW5nKTtcblxuICBpZiAodGhpcy5fcmVhZGFibGVTdGF0ZS5mbG93aW5nICE9PSBmYWxzZSkge1xuICAgIGRlYnVnKCdwYXVzZScpO1xuICAgIHRoaXMuX3JlYWRhYmxlU3RhdGUuZmxvd2luZyA9IGZhbHNlO1xuICAgIHRoaXMuZW1pdCgncGF1c2UnKTtcbiAgfVxuXG4gIHRoaXMuX3JlYWRhYmxlU3RhdGUucGF1c2VkID0gdHJ1ZTtcbiAgcmV0dXJuIHRoaXM7XG59O1xuXG5mdW5jdGlvbiBmbG93KHN0cmVhbSkge1xuICB2YXIgc3RhdGUgPSBzdHJlYW0uX3JlYWRhYmxlU3RhdGU7XG4gIGRlYnVnKCdmbG93Jywgc3RhdGUuZmxvd2luZyk7XG5cbiAgd2hpbGUgKHN0YXRlLmZsb3dpbmcgJiYgc3RyZWFtLnJlYWQoKSAhPT0gbnVsbCkge1xuICAgIDtcbiAgfVxufSAvLyB3cmFwIGFuIG9sZC1zdHlsZSBzdHJlYW0gYXMgdGhlIGFzeW5jIGRhdGEgc291cmNlLlxuLy8gVGhpcyBpcyAqbm90KiBwYXJ0IG9mIHRoZSByZWFkYWJsZSBzdHJlYW0gaW50ZXJmYWNlLlxuLy8gSXQgaXMgYW4gdWdseSB1bmZvcnR1bmF0ZSBtZXNzIG9mIGhpc3RvcnkuXG5cblxuUmVhZGFibGUucHJvdG90eXBlLndyYXAgPSBmdW5jdGlvbiAoc3RyZWFtKSB7XG4gIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgdmFyIHN0YXRlID0gdGhpcy5fcmVhZGFibGVTdGF0ZTtcbiAgdmFyIHBhdXNlZCA9IGZhbHNlO1xuICBzdHJlYW0ub24oJ2VuZCcsIGZ1bmN0aW9uICgpIHtcbiAgICBkZWJ1Zygnd3JhcHBlZCBlbmQnKTtcblxuICAgIGlmIChzdGF0ZS5kZWNvZGVyICYmICFzdGF0ZS5lbmRlZCkge1xuICAgICAgdmFyIGNodW5rID0gc3RhdGUuZGVjb2Rlci5lbmQoKTtcbiAgICAgIGlmIChjaHVuayAmJiBjaHVuay5sZW5ndGgpIF90aGlzLnB1c2goY2h1bmspO1xuICAgIH1cblxuICAgIF90aGlzLnB1c2gobnVsbCk7XG4gIH0pO1xuICBzdHJlYW0ub24oJ2RhdGEnLCBmdW5jdGlvbiAoY2h1bmspIHtcbiAgICBkZWJ1Zygnd3JhcHBlZCBkYXRhJyk7XG4gICAgaWYgKHN0YXRlLmRlY29kZXIpIGNodW5rID0gc3RhdGUuZGVjb2Rlci53cml0ZShjaHVuayk7IC8vIGRvbid0IHNraXAgb3ZlciBmYWxzeSB2YWx1ZXMgaW4gb2JqZWN0TW9kZVxuXG4gICAgaWYgKHN0YXRlLm9iamVjdE1vZGUgJiYgKGNodW5rID09PSBudWxsIHx8IGNodW5rID09PSB1bmRlZmluZWQpKSByZXR1cm47ZWxzZSBpZiAoIXN0YXRlLm9iamVjdE1vZGUgJiYgKCFjaHVuayB8fCAhY2h1bmsubGVuZ3RoKSkgcmV0dXJuO1xuXG4gICAgdmFyIHJldCA9IF90aGlzLnB1c2goY2h1bmspO1xuXG4gICAgaWYgKCFyZXQpIHtcbiAgICAgIHBhdXNlZCA9IHRydWU7XG4gICAgICBzdHJlYW0ucGF1c2UoKTtcbiAgICB9XG4gIH0pOyAvLyBwcm94eSBhbGwgdGhlIG90aGVyIG1ldGhvZHMuXG4gIC8vIGltcG9ydGFudCB3aGVuIHdyYXBwaW5nIGZpbHRlcnMgYW5kIGR1cGxleGVzLlxuXG4gIGZvciAodmFyIGkgaW4gc3RyZWFtKSB7XG4gICAgaWYgKHRoaXNbaV0gPT09IHVuZGVmaW5lZCAmJiB0eXBlb2Ygc3RyZWFtW2ldID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICB0aGlzW2ldID0gZnVuY3Rpb24gbWV0aG9kV3JhcChtZXRob2QpIHtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIG1ldGhvZFdyYXBSZXR1cm5GdW5jdGlvbigpIHtcbiAgICAgICAgICByZXR1cm4gc3RyZWFtW21ldGhvZF0uYXBwbHkoc3RyZWFtLCBhcmd1bWVudHMpO1xuICAgICAgICB9O1xuICAgICAgfShpKTtcbiAgICB9XG4gIH0gLy8gcHJveHkgY2VydGFpbiBpbXBvcnRhbnQgZXZlbnRzLlxuXG5cbiAgZm9yICh2YXIgbiA9IDA7IG4gPCBrUHJveHlFdmVudHMubGVuZ3RoOyBuKyspIHtcbiAgICBzdHJlYW0ub24oa1Byb3h5RXZlbnRzW25dLCB0aGlzLmVtaXQuYmluZCh0aGlzLCBrUHJveHlFdmVudHNbbl0pKTtcbiAgfSAvLyB3aGVuIHdlIHRyeSB0byBjb25zdW1lIHNvbWUgbW9yZSBieXRlcywgc2ltcGx5IHVucGF1c2UgdGhlXG4gIC8vIHVuZGVybHlpbmcgc3RyZWFtLlxuXG5cbiAgdGhpcy5fcmVhZCA9IGZ1bmN0aW9uIChuKSB7XG4gICAgZGVidWcoJ3dyYXBwZWQgX3JlYWQnLCBuKTtcblxuICAgIGlmIChwYXVzZWQpIHtcbiAgICAgIHBhdXNlZCA9IGZhbHNlO1xuICAgICAgc3RyZWFtLnJlc3VtZSgpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gdGhpcztcbn07XG5cbmlmICh0eXBlb2YgU3ltYm9sID09PSAnZnVuY3Rpb24nKSB7XG4gIFJlYWRhYmxlLnByb3RvdHlwZVtTeW1ib2wuYXN5bmNJdGVyYXRvcl0gPSBmdW5jdGlvbiAoKSB7XG4gICAgaWYgKGNyZWF0ZVJlYWRhYmxlU3RyZWFtQXN5bmNJdGVyYXRvciA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICBjcmVhdGVSZWFkYWJsZVN0cmVhbUFzeW5jSXRlcmF0b3IgPSByZXF1aXJlKCcuL2ludGVybmFsL3N0cmVhbXMvYXN5bmNfaXRlcmF0b3InKTtcbiAgICB9XG5cbiAgICByZXR1cm4gY3JlYXRlUmVhZGFibGVTdHJlYW1Bc3luY0l0ZXJhdG9yKHRoaXMpO1xuICB9O1xufVxuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoUmVhZGFibGUucHJvdG90eXBlLCAncmVhZGFibGVIaWdoV2F0ZXJNYXJrJywge1xuICAvLyBtYWtpbmcgaXQgZXhwbGljaXQgdGhpcyBwcm9wZXJ0eSBpcyBub3QgZW51bWVyYWJsZVxuICAvLyBiZWNhdXNlIG90aGVyd2lzZSBzb21lIHByb3RvdHlwZSBtYW5pcHVsYXRpb24gaW5cbiAgLy8gdXNlcmxhbmQgd2lsbCBmYWlsXG4gIGVudW1lcmFibGU6IGZhbHNlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcmVhZGFibGVTdGF0ZS5oaWdoV2F0ZXJNYXJrO1xuICB9XG59KTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShSZWFkYWJsZS5wcm90b3R5cGUsICdyZWFkYWJsZUJ1ZmZlcicsIHtcbiAgLy8gbWFraW5nIGl0IGV4cGxpY2l0IHRoaXMgcHJvcGVydHkgaXMgbm90IGVudW1lcmFibGVcbiAgLy8gYmVjYXVzZSBvdGhlcndpc2Ugc29tZSBwcm90b3R5cGUgbWFuaXB1bGF0aW9uIGluXG4gIC8vIHVzZXJsYW5kIHdpbGwgZmFpbFxuICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgZ2V0OiBmdW5jdGlvbiBnZXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3JlYWRhYmxlU3RhdGUgJiYgdGhpcy5fcmVhZGFibGVTdGF0ZS5idWZmZXI7XG4gIH1cbn0pO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KFJlYWRhYmxlLnByb3RvdHlwZSwgJ3JlYWRhYmxlRmxvd2luZycsIHtcbiAgLy8gbWFraW5nIGl0IGV4cGxpY2l0IHRoaXMgcHJvcGVydHkgaXMgbm90IGVudW1lcmFibGVcbiAgLy8gYmVjYXVzZSBvdGhlcndpc2Ugc29tZSBwcm90b3R5cGUgbWFuaXB1bGF0aW9uIGluXG4gIC8vIHVzZXJsYW5kIHdpbGwgZmFpbFxuICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgZ2V0OiBmdW5jdGlvbiBnZXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3JlYWRhYmxlU3RhdGUuZmxvd2luZztcbiAgfSxcbiAgc2V0OiBmdW5jdGlvbiBzZXQoc3RhdGUpIHtcbiAgICBpZiAodGhpcy5fcmVhZGFibGVTdGF0ZSkge1xuICAgICAgdGhpcy5fcmVhZGFibGVTdGF0ZS5mbG93aW5nID0gc3RhdGU7XG4gICAgfVxuICB9XG59KTsgLy8gZXhwb3NlZCBmb3IgdGVzdGluZyBwdXJwb3NlcyBvbmx5LlxuXG5SZWFkYWJsZS5fZnJvbUxpc3QgPSBmcm9tTGlzdDtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShSZWFkYWJsZS5wcm90b3R5cGUsICdyZWFkYWJsZUxlbmd0aCcsIHtcbiAgLy8gbWFraW5nIGl0IGV4cGxpY2l0IHRoaXMgcHJvcGVydHkgaXMgbm90IGVudW1lcmFibGVcbiAgLy8gYmVjYXVzZSBvdGhlcndpc2Ugc29tZSBwcm90b3R5cGUgbWFuaXB1bGF0aW9uIGluXG4gIC8vIHVzZXJsYW5kIHdpbGwgZmFpbFxuICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgZ2V0OiBmdW5jdGlvbiBnZXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3JlYWRhYmxlU3RhdGUubGVuZ3RoO1xuICB9XG59KTsgLy8gUGx1Y2sgb2ZmIG4gYnl0ZXMgZnJvbSBhbiBhcnJheSBvZiBidWZmZXJzLlxuLy8gTGVuZ3RoIGlzIHRoZSBjb21iaW5lZCBsZW5ndGhzIG9mIGFsbCB0aGUgYnVmZmVycyBpbiB0aGUgbGlzdC5cbi8vIFRoaXMgZnVuY3Rpb24gaXMgZGVzaWduZWQgdG8gYmUgaW5saW5hYmxlLCBzbyBwbGVhc2UgdGFrZSBjYXJlIHdoZW4gbWFraW5nXG4vLyBjaGFuZ2VzIHRvIHRoZSBmdW5jdGlvbiBib2R5LlxuXG5mdW5jdGlvbiBmcm9tTGlzdChuLCBzdGF0ZSkge1xuICAvLyBub3RoaW5nIGJ1ZmZlcmVkXG4gIGlmIChzdGF0ZS5sZW5ndGggPT09IDApIHJldHVybiBudWxsO1xuICB2YXIgcmV0O1xuICBpZiAoc3RhdGUub2JqZWN0TW9kZSkgcmV0ID0gc3RhdGUuYnVmZmVyLnNoaWZ0KCk7ZWxzZSBpZiAoIW4gfHwgbiA+PSBzdGF0ZS5sZW5ndGgpIHtcbiAgICAvLyByZWFkIGl0IGFsbCwgdHJ1bmNhdGUgdGhlIGxpc3RcbiAgICBpZiAoc3RhdGUuZGVjb2RlcikgcmV0ID0gc3RhdGUuYnVmZmVyLmpvaW4oJycpO2Vsc2UgaWYgKHN0YXRlLmJ1ZmZlci5sZW5ndGggPT09IDEpIHJldCA9IHN0YXRlLmJ1ZmZlci5maXJzdCgpO2Vsc2UgcmV0ID0gc3RhdGUuYnVmZmVyLmNvbmNhdChzdGF0ZS5sZW5ndGgpO1xuICAgIHN0YXRlLmJ1ZmZlci5jbGVhcigpO1xuICB9IGVsc2Uge1xuICAgIC8vIHJlYWQgcGFydCBvZiBsaXN0XG4gICAgcmV0ID0gc3RhdGUuYnVmZmVyLmNvbnN1bWUobiwgc3RhdGUuZGVjb2Rlcik7XG4gIH1cbiAgcmV0dXJuIHJldDtcbn1cblxuZnVuY3Rpb24gZW5kUmVhZGFibGUoc3RyZWFtKSB7XG4gIHZhciBzdGF0ZSA9IHN0cmVhbS5fcmVhZGFibGVTdGF0ZTtcbiAgZGVidWcoJ2VuZFJlYWRhYmxlJywgc3RhdGUuZW5kRW1pdHRlZCk7XG5cbiAgaWYgKCFzdGF0ZS5lbmRFbWl0dGVkKSB7XG4gICAgc3RhdGUuZW5kZWQgPSB0cnVlO1xuICAgIHByb2Nlc3MubmV4dFRpY2soZW5kUmVhZGFibGVOVCwgc3RhdGUsIHN0cmVhbSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gZW5kUmVhZGFibGVOVChzdGF0ZSwgc3RyZWFtKSB7XG4gIGRlYnVnKCdlbmRSZWFkYWJsZU5UJywgc3RhdGUuZW5kRW1pdHRlZCwgc3RhdGUubGVuZ3RoKTsgLy8gQ2hlY2sgdGhhdCB3ZSBkaWRuJ3QgZ2V0IG9uZSBsYXN0IHVuc2hpZnQuXG5cbiAgaWYgKCFzdGF0ZS5lbmRFbWl0dGVkICYmIHN0YXRlLmxlbmd0aCA9PT0gMCkge1xuICAgIHN0YXRlLmVuZEVtaXR0ZWQgPSB0cnVlO1xuICAgIHN0cmVhbS5yZWFkYWJsZSA9IGZhbHNlO1xuICAgIHN0cmVhbS5lbWl0KCdlbmQnKTtcblxuICAgIGlmIChzdGF0ZS5hdXRvRGVzdHJveSkge1xuICAgICAgLy8gSW4gY2FzZSBvZiBkdXBsZXggc3RyZWFtcyB3ZSBuZWVkIGEgd2F5IHRvIGRldGVjdFxuICAgICAgLy8gaWYgdGhlIHdyaXRhYmxlIHNpZGUgaXMgcmVhZHkgZm9yIGF1dG9EZXN0cm95IGFzIHdlbGxcbiAgICAgIHZhciB3U3RhdGUgPSBzdHJlYW0uX3dyaXRhYmxlU3RhdGU7XG5cbiAgICAgIGlmICghd1N0YXRlIHx8IHdTdGF0ZS5hdXRvRGVzdHJveSAmJiB3U3RhdGUuZmluaXNoZWQpIHtcbiAgICAgICAgc3RyZWFtLmRlc3Ryb3koKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuaWYgKHR5cGVvZiBTeW1ib2wgPT09ICdmdW5jdGlvbicpIHtcbiAgUmVhZGFibGUuZnJvbSA9IGZ1bmN0aW9uIChpdGVyYWJsZSwgb3B0cykge1xuICAgIGlmIChmcm9tID09PSB1bmRlZmluZWQpIHtcbiAgICAgIGZyb20gPSByZXF1aXJlKCcuL2ludGVybmFsL3N0cmVhbXMvZnJvbScpO1xuICAgIH1cblxuICAgIHJldHVybiBmcm9tKFJlYWRhYmxlLCBpdGVyYWJsZSwgb3B0cyk7XG4gIH07XG59XG5cbmZ1bmN0aW9uIGluZGV4T2YoeHMsIHgpIHtcbiAgZm9yICh2YXIgaSA9IDAsIGwgPSB4cy5sZW5ndGg7IGkgPCBsOyBpKyspIHtcbiAgICBpZiAoeHNbaV0gPT09IHgpIHJldHVybiBpO1xuICB9XG5cbiAgcmV0dXJuIC0xO1xufSIsIi8vIENvcHlyaWdodCBKb3llbnQsIEluYy4gYW5kIG90aGVyIE5vZGUgY29udHJpYnV0b3JzLlxuLy9cbi8vIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhXG4vLyBjb3B5IG9mIHRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlXG4vLyBcIlNvZnR3YXJlXCIpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZSB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmdcbi8vIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBtZXJnZSwgcHVibGlzaCxcbi8vIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0byBwZXJtaXRcbi8vIHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLCBzdWJqZWN0IHRvIHRoZVxuLy8gZm9sbG93aW5nIGNvbmRpdGlvbnM6XG4vL1xuLy8gVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWRcbi8vIGluIGFsbCBjb3BpZXMgb3Igc3Vic3RhbnRpYWwgcG9ydGlvbnMgb2YgdGhlIFNvZnR3YXJlLlxuLy9cbi8vIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIsIFdJVEhPVVQgV0FSUkFOVFkgT0YgQU5ZIEtJTkQsIEVYUFJFU1Ncbi8vIE9SIElNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0Zcbi8vIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EIE5PTklORlJJTkdFTUVOVC4gSU5cbi8vIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1JTIE9SIENPUFlSSUdIVCBIT0xERVJTIEJFIExJQUJMRSBGT1IgQU5ZIENMQUlNLFxuLy8gREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULCBUT1JUIE9SXG4vLyBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT04gV0lUSCBUSEUgU09GVFdBUkUgT1IgVEhFXG4vLyBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuLy8gYSB0cmFuc2Zvcm0gc3RyZWFtIGlzIGEgcmVhZGFibGUvd3JpdGFibGUgc3RyZWFtIHdoZXJlIHlvdSBkb1xuLy8gc29tZXRoaW5nIHdpdGggdGhlIGRhdGEuICBTb21ldGltZXMgaXQncyBjYWxsZWQgYSBcImZpbHRlclwiLFxuLy8gYnV0IHRoYXQncyBub3QgYSBncmVhdCBuYW1lIGZvciBpdCwgc2luY2UgdGhhdCBpbXBsaWVzIGEgdGhpbmcgd2hlcmVcbi8vIHNvbWUgYml0cyBwYXNzIHRocm91Z2gsIGFuZCBvdGhlcnMgYXJlIHNpbXBseSBpZ25vcmVkLiAgKFRoYXQgd291bGRcbi8vIGJlIGEgdmFsaWQgZXhhbXBsZSBvZiBhIHRyYW5zZm9ybSwgb2YgY291cnNlLilcbi8vXG4vLyBXaGlsZSB0aGUgb3V0cHV0IGlzIGNhdXNhbGx5IHJlbGF0ZWQgdG8gdGhlIGlucHV0LCBpdCdzIG5vdCBhXG4vLyBuZWNlc3NhcmlseSBzeW1tZXRyaWMgb3Igc3luY2hyb25vdXMgdHJhbnNmb3JtYXRpb24uICBGb3IgZXhhbXBsZSxcbi8vIGEgemxpYiBzdHJlYW0gbWlnaHQgdGFrZSBtdWx0aXBsZSBwbGFpbi10ZXh0IHdyaXRlcygpLCBhbmQgdGhlblxuLy8gZW1pdCBhIHNpbmdsZSBjb21wcmVzc2VkIGNodW5rIHNvbWUgdGltZSBpbiB0aGUgZnV0dXJlLlxuLy9cbi8vIEhlcmUncyBob3cgdGhpcyB3b3Jrczpcbi8vXG4vLyBUaGUgVHJhbnNmb3JtIHN0cmVhbSBoYXMgYWxsIHRoZSBhc3BlY3RzIG9mIHRoZSByZWFkYWJsZSBhbmQgd3JpdGFibGVcbi8vIHN0cmVhbSBjbGFzc2VzLiAgV2hlbiB5b3Ugd3JpdGUoY2h1bmspLCB0aGF0IGNhbGxzIF93cml0ZShjaHVuayxjYilcbi8vIGludGVybmFsbHksIGFuZCByZXR1cm5zIGZhbHNlIGlmIHRoZXJlJ3MgYSBsb3Qgb2YgcGVuZGluZyB3cml0ZXNcbi8vIGJ1ZmZlcmVkIHVwLiAgV2hlbiB5b3UgY2FsbCByZWFkKCksIHRoYXQgY2FsbHMgX3JlYWQobikgdW50aWxcbi8vIHRoZXJlJ3MgZW5vdWdoIHBlbmRpbmcgcmVhZGFibGUgZGF0YSBidWZmZXJlZCB1cC5cbi8vXG4vLyBJbiBhIHRyYW5zZm9ybSBzdHJlYW0sIHRoZSB3cml0dGVuIGRhdGEgaXMgcGxhY2VkIGluIGEgYnVmZmVyLiAgV2hlblxuLy8gX3JlYWQobikgaXMgY2FsbGVkLCBpdCB0cmFuc2Zvcm1zIHRoZSBxdWV1ZWQgdXAgZGF0YSwgY2FsbGluZyB0aGVcbi8vIGJ1ZmZlcmVkIF93cml0ZSBjYidzIGFzIGl0IGNvbnN1bWVzIGNodW5rcy4gIElmIGNvbnN1bWluZyBhIHNpbmdsZVxuLy8gd3JpdHRlbiBjaHVuayB3b3VsZCByZXN1bHQgaW4gbXVsdGlwbGUgb3V0cHV0IGNodW5rcywgdGhlbiB0aGUgZmlyc3Rcbi8vIG91dHB1dHRlZCBiaXQgY2FsbHMgdGhlIHJlYWRjYiwgYW5kIHN1YnNlcXVlbnQgY2h1bmtzIGp1c3QgZ28gaW50b1xuLy8gdGhlIHJlYWQgYnVmZmVyLCBhbmQgd2lsbCBjYXVzZSBpdCB0byBlbWl0ICdyZWFkYWJsZScgaWYgbmVjZXNzYXJ5LlxuLy9cbi8vIFRoaXMgd2F5LCBiYWNrLXByZXNzdXJlIGlzIGFjdHVhbGx5IGRldGVybWluZWQgYnkgdGhlIHJlYWRpbmcgc2lkZSxcbi8vIHNpbmNlIF9yZWFkIGhhcyB0byBiZSBjYWxsZWQgdG8gc3RhcnQgcHJvY2Vzc2luZyBhIG5ldyBjaHVuay4gIEhvd2V2ZXIsXG4vLyBhIHBhdGhvbG9naWNhbCBpbmZsYXRlIHR5cGUgb2YgdHJhbnNmb3JtIGNhbiBjYXVzZSBleGNlc3NpdmUgYnVmZmVyaW5nXG4vLyBoZXJlLiAgRm9yIGV4YW1wbGUsIGltYWdpbmUgYSBzdHJlYW0gd2hlcmUgZXZlcnkgYnl0ZSBvZiBpbnB1dCBpc1xuLy8gaW50ZXJwcmV0ZWQgYXMgYW4gaW50ZWdlciBmcm9tIDAtMjU1LCBhbmQgdGhlbiByZXN1bHRzIGluIHRoYXQgbWFueVxuLy8gYnl0ZXMgb2Ygb3V0cHV0LiAgV3JpdGluZyB0aGUgNCBieXRlcyB7ZmYsZmYsZmYsZmZ9IHdvdWxkIHJlc3VsdCBpblxuLy8gMWtiIG9mIGRhdGEgYmVpbmcgb3V0cHV0LiAgSW4gdGhpcyBjYXNlLCB5b3UgY291bGQgd3JpdGUgYSB2ZXJ5IHNtYWxsXG4vLyBhbW91bnQgb2YgaW5wdXQsIGFuZCBlbmQgdXAgd2l0aCBhIHZlcnkgbGFyZ2UgYW1vdW50IG9mIG91dHB1dC4gIEluXG4vLyBzdWNoIGEgcGF0aG9sb2dpY2FsIGluZmxhdGluZyBtZWNoYW5pc20sIHRoZXJlJ2QgYmUgbm8gd2F5IHRvIHRlbGxcbi8vIHRoZSBzeXN0ZW0gdG8gc3RvcCBkb2luZyB0aGUgdHJhbnNmb3JtLiAgQSBzaW5nbGUgNE1CIHdyaXRlIGNvdWxkXG4vLyBjYXVzZSB0aGUgc3lzdGVtIHRvIHJ1biBvdXQgb2YgbWVtb3J5LlxuLy9cbi8vIEhvd2V2ZXIsIGV2ZW4gaW4gc3VjaCBhIHBhdGhvbG9naWNhbCBjYXNlLCBvbmx5IGEgc2luZ2xlIHdyaXR0ZW4gY2h1bmtcbi8vIHdvdWxkIGJlIGNvbnN1bWVkLCBhbmQgdGhlbiB0aGUgcmVzdCB3b3VsZCB3YWl0ICh1bi10cmFuc2Zvcm1lZCkgdW50aWxcbi8vIHRoZSByZXN1bHRzIG9mIHRoZSBwcmV2aW91cyB0cmFuc2Zvcm1lZCBjaHVuayB3ZXJlIGNvbnN1bWVkLlxuJ3VzZSBzdHJpY3QnO1xuXG5tb2R1bGUuZXhwb3J0cyA9IFRyYW5zZm9ybTtcblxudmFyIF9yZXF1aXJlJGNvZGVzID0gcmVxdWlyZSgnLi4vZXJyb3JzJykuY29kZXMsXG4gICAgRVJSX01FVEhPRF9OT1RfSU1QTEVNRU5URUQgPSBfcmVxdWlyZSRjb2Rlcy5FUlJfTUVUSE9EX05PVF9JTVBMRU1FTlRFRCxcbiAgICBFUlJfTVVMVElQTEVfQ0FMTEJBQ0sgPSBfcmVxdWlyZSRjb2Rlcy5FUlJfTVVMVElQTEVfQ0FMTEJBQ0ssXG4gICAgRVJSX1RSQU5TRk9STV9BTFJFQURZX1RSQU5TRk9STUlORyA9IF9yZXF1aXJlJGNvZGVzLkVSUl9UUkFOU0ZPUk1fQUxSRUFEWV9UUkFOU0ZPUk1JTkcsXG4gICAgRVJSX1RSQU5TRk9STV9XSVRIX0xFTkdUSF8wID0gX3JlcXVpcmUkY29kZXMuRVJSX1RSQU5TRk9STV9XSVRIX0xFTkdUSF8wO1xuXG52YXIgRHVwbGV4ID0gcmVxdWlyZSgnLi9fc3RyZWFtX2R1cGxleCcpO1xuXG5yZXF1aXJlKCdpbmhlcml0cycpKFRyYW5zZm9ybSwgRHVwbGV4KTtcblxuZnVuY3Rpb24gYWZ0ZXJUcmFuc2Zvcm0oZXIsIGRhdGEpIHtcbiAgdmFyIHRzID0gdGhpcy5fdHJhbnNmb3JtU3RhdGU7XG4gIHRzLnRyYW5zZm9ybWluZyA9IGZhbHNlO1xuICB2YXIgY2IgPSB0cy53cml0ZWNiO1xuXG4gIGlmIChjYiA9PT0gbnVsbCkge1xuICAgIHJldHVybiB0aGlzLmVtaXQoJ2Vycm9yJywgbmV3IEVSUl9NVUxUSVBMRV9DQUxMQkFDSygpKTtcbiAgfVxuXG4gIHRzLndyaXRlY2h1bmsgPSBudWxsO1xuICB0cy53cml0ZWNiID0gbnVsbDtcbiAgaWYgKGRhdGEgIT0gbnVsbCkgLy8gc2luZ2xlIGVxdWFscyBjaGVjayBmb3IgYm90aCBgbnVsbGAgYW5kIGB1bmRlZmluZWRgXG4gICAgdGhpcy5wdXNoKGRhdGEpO1xuICBjYihlcik7XG4gIHZhciBycyA9IHRoaXMuX3JlYWRhYmxlU3RhdGU7XG4gIHJzLnJlYWRpbmcgPSBmYWxzZTtcblxuICBpZiAocnMubmVlZFJlYWRhYmxlIHx8IHJzLmxlbmd0aCA8IHJzLmhpZ2hXYXRlck1hcmspIHtcbiAgICB0aGlzLl9yZWFkKHJzLmhpZ2hXYXRlck1hcmspO1xuICB9XG59XG5cbmZ1bmN0aW9uIFRyYW5zZm9ybShvcHRpb25zKSB7XG4gIGlmICghKHRoaXMgaW5zdGFuY2VvZiBUcmFuc2Zvcm0pKSByZXR1cm4gbmV3IFRyYW5zZm9ybShvcHRpb25zKTtcbiAgRHVwbGV4LmNhbGwodGhpcywgb3B0aW9ucyk7XG4gIHRoaXMuX3RyYW5zZm9ybVN0YXRlID0ge1xuICAgIGFmdGVyVHJhbnNmb3JtOiBhZnRlclRyYW5zZm9ybS5iaW5kKHRoaXMpLFxuICAgIG5lZWRUcmFuc2Zvcm06IGZhbHNlLFxuICAgIHRyYW5zZm9ybWluZzogZmFsc2UsXG4gICAgd3JpdGVjYjogbnVsbCxcbiAgICB3cml0ZWNodW5rOiBudWxsLFxuICAgIHdyaXRlZW5jb2Rpbmc6IG51bGxcbiAgfTsgLy8gc3RhcnQgb3V0IGFza2luZyBmb3IgYSByZWFkYWJsZSBldmVudCBvbmNlIGRhdGEgaXMgdHJhbnNmb3JtZWQuXG5cbiAgdGhpcy5fcmVhZGFibGVTdGF0ZS5uZWVkUmVhZGFibGUgPSB0cnVlOyAvLyB3ZSBoYXZlIGltcGxlbWVudGVkIHRoZSBfcmVhZCBtZXRob2QsIGFuZCBkb25lIHRoZSBvdGhlciB0aGluZ3NcbiAgLy8gdGhhdCBSZWFkYWJsZSB3YW50cyBiZWZvcmUgdGhlIGZpcnN0IF9yZWFkIGNhbGwsIHNvIHVuc2V0IHRoZVxuICAvLyBzeW5jIGd1YXJkIGZsYWcuXG5cbiAgdGhpcy5fcmVhZGFibGVTdGF0ZS5zeW5jID0gZmFsc2U7XG5cbiAgaWYgKG9wdGlvbnMpIHtcbiAgICBpZiAodHlwZW9mIG9wdGlvbnMudHJhbnNmb3JtID09PSAnZnVuY3Rpb24nKSB0aGlzLl90cmFuc2Zvcm0gPSBvcHRpb25zLnRyYW5zZm9ybTtcbiAgICBpZiAodHlwZW9mIG9wdGlvbnMuZmx1c2ggPT09ICdmdW5jdGlvbicpIHRoaXMuX2ZsdXNoID0gb3B0aW9ucy5mbHVzaDtcbiAgfSAvLyBXaGVuIHRoZSB3cml0YWJsZSBzaWRlIGZpbmlzaGVzLCB0aGVuIGZsdXNoIG91dCBhbnl0aGluZyByZW1haW5pbmcuXG5cblxuICB0aGlzLm9uKCdwcmVmaW5pc2gnLCBwcmVmaW5pc2gpO1xufVxuXG5mdW5jdGlvbiBwcmVmaW5pc2goKSB7XG4gIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgaWYgKHR5cGVvZiB0aGlzLl9mbHVzaCA9PT0gJ2Z1bmN0aW9uJyAmJiAhdGhpcy5fcmVhZGFibGVTdGF0ZS5kZXN0cm95ZWQpIHtcbiAgICB0aGlzLl9mbHVzaChmdW5jdGlvbiAoZXIsIGRhdGEpIHtcbiAgICAgIGRvbmUoX3RoaXMsIGVyLCBkYXRhKTtcbiAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICBkb25lKHRoaXMsIG51bGwsIG51bGwpO1xuICB9XG59XG5cblRyYW5zZm9ybS5wcm90b3R5cGUucHVzaCA9IGZ1bmN0aW9uIChjaHVuaywgZW5jb2RpbmcpIHtcbiAgdGhpcy5fdHJhbnNmb3JtU3RhdGUubmVlZFRyYW5zZm9ybSA9IGZhbHNlO1xuICByZXR1cm4gRHVwbGV4LnByb3RvdHlwZS5wdXNoLmNhbGwodGhpcywgY2h1bmssIGVuY29kaW5nKTtcbn07IC8vIFRoaXMgaXMgdGhlIHBhcnQgd2hlcmUgeW91IGRvIHN0dWZmIVxuLy8gb3ZlcnJpZGUgdGhpcyBmdW5jdGlvbiBpbiBpbXBsZW1lbnRhdGlvbiBjbGFzc2VzLlxuLy8gJ2NodW5rJyBpcyBhbiBpbnB1dCBjaHVuay5cbi8vXG4vLyBDYWxsIGBwdXNoKG5ld0NodW5rKWAgdG8gcGFzcyBhbG9uZyB0cmFuc2Zvcm1lZCBvdXRwdXRcbi8vIHRvIHRoZSByZWFkYWJsZSBzaWRlLiAgWW91IG1heSBjYWxsICdwdXNoJyB6ZXJvIG9yIG1vcmUgdGltZXMuXG4vL1xuLy8gQ2FsbCBgY2IoZXJyKWAgd2hlbiB5b3UgYXJlIGRvbmUgd2l0aCB0aGlzIGNodW5rLiAgSWYgeW91IHBhc3Ncbi8vIGFuIGVycm9yLCB0aGVuIHRoYXQnbGwgcHV0IHRoZSBodXJ0IG9uIHRoZSB3aG9sZSBvcGVyYXRpb24uICBJZiB5b3Vcbi8vIG5ldmVyIGNhbGwgY2IoKSwgdGhlbiB5b3UnbGwgbmV2ZXIgZ2V0IGFub3RoZXIgY2h1bmsuXG5cblxuVHJhbnNmb3JtLnByb3RvdHlwZS5fdHJhbnNmb3JtID0gZnVuY3Rpb24gKGNodW5rLCBlbmNvZGluZywgY2IpIHtcbiAgY2IobmV3IEVSUl9NRVRIT0RfTk9UX0lNUExFTUVOVEVEKCdfdHJhbnNmb3JtKCknKSk7XG59O1xuXG5UcmFuc2Zvcm0ucHJvdG90eXBlLl93cml0ZSA9IGZ1bmN0aW9uIChjaHVuaywgZW5jb2RpbmcsIGNiKSB7XG4gIHZhciB0cyA9IHRoaXMuX3RyYW5zZm9ybVN0YXRlO1xuICB0cy53cml0ZWNiID0gY2I7XG4gIHRzLndyaXRlY2h1bmsgPSBjaHVuaztcbiAgdHMud3JpdGVlbmNvZGluZyA9IGVuY29kaW5nO1xuXG4gIGlmICghdHMudHJhbnNmb3JtaW5nKSB7XG4gICAgdmFyIHJzID0gdGhpcy5fcmVhZGFibGVTdGF0ZTtcbiAgICBpZiAodHMubmVlZFRyYW5zZm9ybSB8fCBycy5uZWVkUmVhZGFibGUgfHwgcnMubGVuZ3RoIDwgcnMuaGlnaFdhdGVyTWFyaykgdGhpcy5fcmVhZChycy5oaWdoV2F0ZXJNYXJrKTtcbiAgfVxufTsgLy8gRG9lc24ndCBtYXR0ZXIgd2hhdCB0aGUgYXJncyBhcmUgaGVyZS5cbi8vIF90cmFuc2Zvcm0gZG9lcyBhbGwgdGhlIHdvcmsuXG4vLyBUaGF0IHdlIGdvdCBoZXJlIG1lYW5zIHRoYXQgdGhlIHJlYWRhYmxlIHNpZGUgd2FudHMgbW9yZSBkYXRhLlxuXG5cblRyYW5zZm9ybS5wcm90b3R5cGUuX3JlYWQgPSBmdW5jdGlvbiAobikge1xuICB2YXIgdHMgPSB0aGlzLl90cmFuc2Zvcm1TdGF0ZTtcblxuICBpZiAodHMud3JpdGVjaHVuayAhPT0gbnVsbCAmJiAhdHMudHJhbnNmb3JtaW5nKSB7XG4gICAgdHMudHJhbnNmb3JtaW5nID0gdHJ1ZTtcblxuICAgIHRoaXMuX3RyYW5zZm9ybSh0cy53cml0ZWNodW5rLCB0cy53cml0ZWVuY29kaW5nLCB0cy5hZnRlclRyYW5zZm9ybSk7XG4gIH0gZWxzZSB7XG4gICAgLy8gbWFyayB0aGF0IHdlIG5lZWQgYSB0cmFuc2Zvcm0sIHNvIHRoYXQgYW55IGRhdGEgdGhhdCBjb21lcyBpblxuICAgIC8vIHdpbGwgZ2V0IHByb2Nlc3NlZCwgbm93IHRoYXQgd2UndmUgYXNrZWQgZm9yIGl0LlxuICAgIHRzLm5lZWRUcmFuc2Zvcm0gPSB0cnVlO1xuICB9XG59O1xuXG5UcmFuc2Zvcm0ucHJvdG90eXBlLl9kZXN0cm95ID0gZnVuY3Rpb24gKGVyciwgY2IpIHtcbiAgRHVwbGV4LnByb3RvdHlwZS5fZGVzdHJveS5jYWxsKHRoaXMsIGVyciwgZnVuY3Rpb24gKGVycjIpIHtcbiAgICBjYihlcnIyKTtcbiAgfSk7XG59O1xuXG5mdW5jdGlvbiBkb25lKHN0cmVhbSwgZXIsIGRhdGEpIHtcbiAgaWYgKGVyKSByZXR1cm4gc3RyZWFtLmVtaXQoJ2Vycm9yJywgZXIpO1xuICBpZiAoZGF0YSAhPSBudWxsKSAvLyBzaW5nbGUgZXF1YWxzIGNoZWNrIGZvciBib3RoIGBudWxsYCBhbmQgYHVuZGVmaW5lZGBcbiAgICBzdHJlYW0ucHVzaChkYXRhKTsgLy8gVE9ETyhCcmlkZ2VBUik6IFdyaXRlIGEgdGVzdCBmb3IgdGhlc2UgdHdvIGVycm9yIGNhc2VzXG4gIC8vIGlmIHRoZXJlJ3Mgbm90aGluZyBpbiB0aGUgd3JpdGUgYnVmZmVyLCB0aGVuIHRoYXQgbWVhbnNcbiAgLy8gdGhhdCBub3RoaW5nIG1vcmUgd2lsbCBldmVyIGJlIHByb3ZpZGVkXG5cbiAgaWYgKHN0cmVhbS5fd3JpdGFibGVTdGF0ZS5sZW5ndGgpIHRocm93IG5ldyBFUlJfVFJBTlNGT1JNX1dJVEhfTEVOR1RIXzAoKTtcbiAgaWYgKHN0cmVhbS5fdHJhbnNmb3JtU3RhdGUudHJhbnNmb3JtaW5nKSB0aHJvdyBuZXcgRVJSX1RSQU5TRk9STV9BTFJFQURZX1RSQU5TRk9STUlORygpO1xuICByZXR1cm4gc3RyZWFtLnB1c2gobnVsbCk7XG59IiwiLy8gQ29weXJpZ2h0IEpveWVudCwgSW5jLiBhbmQgb3RoZXIgTm9kZSBjb250cmlidXRvcnMuXG4vL1xuLy8gUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb24gb2J0YWluaW5nIGFcbi8vIGNvcHkgb2YgdGhpcyBzb2Z0d2FyZSBhbmQgYXNzb2NpYXRlZCBkb2N1bWVudGF0aW9uIGZpbGVzICh0aGVcbi8vIFwiU29mdHdhcmVcIiksIHRvIGRlYWwgaW4gdGhlIFNvZnR3YXJlIHdpdGhvdXQgcmVzdHJpY3Rpb24sIGluY2x1ZGluZ1xuLy8gd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMgdG8gdXNlLCBjb3B5LCBtb2RpZnksIG1lcmdlLCBwdWJsaXNoLFxuLy8gZGlzdHJpYnV0ZSwgc3VibGljZW5zZSwgYW5kL29yIHNlbGwgY29waWVzIG9mIHRoZSBTb2Z0d2FyZSwgYW5kIHRvIHBlcm1pdFxuLy8gcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpcyBmdXJuaXNoZWQgdG8gZG8gc28sIHN1YmplY3QgdG8gdGhlXG4vLyBmb2xsb3dpbmcgY29uZGl0aW9uczpcbi8vXG4vLyBUaGUgYWJvdmUgY29weXJpZ2h0IG5vdGljZSBhbmQgdGhpcyBwZXJtaXNzaW9uIG5vdGljZSBzaGFsbCBiZSBpbmNsdWRlZFxuLy8gaW4gYWxsIGNvcGllcyBvciBzdWJzdGFudGlhbCBwb3J0aW9ucyBvZiB0aGUgU29mdHdhcmUuXG4vL1xuLy8gVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiwgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCwgRVhQUkVTU1xuLy8gT1IgSU1QTElFRCwgSU5DTFVESU5HIEJVVCBOT1QgTElNSVRFRCBUTyBUSEUgV0FSUkFOVElFUyBPRlxuLy8gTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTlxuLy8gTk8gRVZFTlQgU0hBTEwgVEhFIEFVVEhPUlMgT1IgQ09QWVJJR0hUIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTlkgQ0xBSU0sXG4vLyBEQU1BR0VTIE9SIE9USEVSIExJQUJJTElUWSwgV0hFVEhFUiBJTiBBTiBBQ1RJT04gT0YgQ09OVFJBQ1QsIFRPUlQgT1Jcbi8vIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRSBTT0ZUV0FSRSBPUiBUSEVcbi8vIFVTRSBPUiBPVEhFUiBERUFMSU5HUyBJTiBUSEUgU09GVFdBUkUuXG4vLyBBIGJpdCBzaW1wbGVyIHRoYW4gcmVhZGFibGUgc3RyZWFtcy5cbi8vIEltcGxlbWVudCBhbiBhc3luYyAuX3dyaXRlKGNodW5rLCBlbmNvZGluZywgY2IpLCBhbmQgaXQnbGwgaGFuZGxlIGFsbFxuLy8gdGhlIGRyYWluIGV2ZW50IGVtaXNzaW9uIGFuZCBidWZmZXJpbmcuXG4ndXNlIHN0cmljdCc7XG5cbm1vZHVsZS5leHBvcnRzID0gV3JpdGFibGU7XG4vKiA8cmVwbGFjZW1lbnQ+ICovXG5cbmZ1bmN0aW9uIFdyaXRlUmVxKGNodW5rLCBlbmNvZGluZywgY2IpIHtcbiAgdGhpcy5jaHVuayA9IGNodW5rO1xuICB0aGlzLmVuY29kaW5nID0gZW5jb2Rpbmc7XG4gIHRoaXMuY2FsbGJhY2sgPSBjYjtcbiAgdGhpcy5uZXh0ID0gbnVsbDtcbn0gLy8gSXQgc2VlbXMgYSBsaW5rZWQgbGlzdCBidXQgaXQgaXMgbm90XG4vLyB0aGVyZSB3aWxsIGJlIG9ubHkgMiBvZiB0aGVzZSBmb3IgZWFjaCBzdHJlYW1cblxuXG5mdW5jdGlvbiBDb3JrZWRSZXF1ZXN0KHN0YXRlKSB7XG4gIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgdGhpcy5uZXh0ID0gbnVsbDtcbiAgdGhpcy5lbnRyeSA9IG51bGw7XG5cbiAgdGhpcy5maW5pc2ggPSBmdW5jdGlvbiAoKSB7XG4gICAgb25Db3JrZWRGaW5pc2goX3RoaXMsIHN0YXRlKTtcbiAgfTtcbn1cbi8qIDwvcmVwbGFjZW1lbnQ+ICovXG5cbi8qPHJlcGxhY2VtZW50PiovXG5cblxudmFyIER1cGxleDtcbi8qPC9yZXBsYWNlbWVudD4qL1xuXG5Xcml0YWJsZS5Xcml0YWJsZVN0YXRlID0gV3JpdGFibGVTdGF0ZTtcbi8qPHJlcGxhY2VtZW50PiovXG5cbnZhciBpbnRlcm5hbFV0aWwgPSB7XG4gIGRlcHJlY2F0ZTogcmVxdWlyZSgndXRpbC1kZXByZWNhdGUnKVxufTtcbi8qPC9yZXBsYWNlbWVudD4qL1xuXG4vKjxyZXBsYWNlbWVudD4qL1xuXG52YXIgU3RyZWFtID0gcmVxdWlyZSgnLi9pbnRlcm5hbC9zdHJlYW1zL3N0cmVhbScpO1xuLyo8L3JlcGxhY2VtZW50PiovXG5cblxudmFyIEJ1ZmZlciA9IHJlcXVpcmUoJ2J1ZmZlcicpLkJ1ZmZlcjtcblxudmFyIE91clVpbnQ4QXJyYXkgPSBnbG9iYWwuVWludDhBcnJheSB8fCBmdW5jdGlvbiAoKSB7fTtcblxuZnVuY3Rpb24gX3VpbnQ4QXJyYXlUb0J1ZmZlcihjaHVuaykge1xuICByZXR1cm4gQnVmZmVyLmZyb20oY2h1bmspO1xufVxuXG5mdW5jdGlvbiBfaXNVaW50OEFycmF5KG9iaikge1xuICByZXR1cm4gQnVmZmVyLmlzQnVmZmVyKG9iaikgfHwgb2JqIGluc3RhbmNlb2YgT3VyVWludDhBcnJheTtcbn1cblxudmFyIGRlc3Ryb3lJbXBsID0gcmVxdWlyZSgnLi9pbnRlcm5hbC9zdHJlYW1zL2Rlc3Ryb3knKTtcblxudmFyIF9yZXF1aXJlID0gcmVxdWlyZSgnLi9pbnRlcm5hbC9zdHJlYW1zL3N0YXRlJyksXG4gICAgZ2V0SGlnaFdhdGVyTWFyayA9IF9yZXF1aXJlLmdldEhpZ2hXYXRlck1hcms7XG5cbnZhciBfcmVxdWlyZSRjb2RlcyA9IHJlcXVpcmUoJy4uL2Vycm9ycycpLmNvZGVzLFxuICAgIEVSUl9JTlZBTElEX0FSR19UWVBFID0gX3JlcXVpcmUkY29kZXMuRVJSX0lOVkFMSURfQVJHX1RZUEUsXG4gICAgRVJSX01FVEhPRF9OT1RfSU1QTEVNRU5URUQgPSBfcmVxdWlyZSRjb2Rlcy5FUlJfTUVUSE9EX05PVF9JTVBMRU1FTlRFRCxcbiAgICBFUlJfTVVMVElQTEVfQ0FMTEJBQ0sgPSBfcmVxdWlyZSRjb2Rlcy5FUlJfTVVMVElQTEVfQ0FMTEJBQ0ssXG4gICAgRVJSX1NUUkVBTV9DQU5OT1RfUElQRSA9IF9yZXF1aXJlJGNvZGVzLkVSUl9TVFJFQU1fQ0FOTk9UX1BJUEUsXG4gICAgRVJSX1NUUkVBTV9ERVNUUk9ZRUQgPSBfcmVxdWlyZSRjb2Rlcy5FUlJfU1RSRUFNX0RFU1RST1lFRCxcbiAgICBFUlJfU1RSRUFNX05VTExfVkFMVUVTID0gX3JlcXVpcmUkY29kZXMuRVJSX1NUUkVBTV9OVUxMX1ZBTFVFUyxcbiAgICBFUlJfU1RSRUFNX1dSSVRFX0FGVEVSX0VORCA9IF9yZXF1aXJlJGNvZGVzLkVSUl9TVFJFQU1fV1JJVEVfQUZURVJfRU5ELFxuICAgIEVSUl9VTktOT1dOX0VOQ09ESU5HID0gX3JlcXVpcmUkY29kZXMuRVJSX1VOS05PV05fRU5DT0RJTkc7XG5cbnZhciBlcnJvck9yRGVzdHJveSA9IGRlc3Ryb3lJbXBsLmVycm9yT3JEZXN0cm95O1xuXG5yZXF1aXJlKCdpbmhlcml0cycpKFdyaXRhYmxlLCBTdHJlYW0pO1xuXG5mdW5jdGlvbiBub3AoKSB7fVxuXG5mdW5jdGlvbiBXcml0YWJsZVN0YXRlKG9wdGlvbnMsIHN0cmVhbSwgaXNEdXBsZXgpIHtcbiAgRHVwbGV4ID0gRHVwbGV4IHx8IHJlcXVpcmUoJy4vX3N0cmVhbV9kdXBsZXgnKTtcbiAgb3B0aW9ucyA9IG9wdGlvbnMgfHwge307IC8vIER1cGxleCBzdHJlYW1zIGFyZSBib3RoIHJlYWRhYmxlIGFuZCB3cml0YWJsZSwgYnV0IHNoYXJlXG4gIC8vIHRoZSBzYW1lIG9wdGlvbnMgb2JqZWN0LlxuICAvLyBIb3dldmVyLCBzb21lIGNhc2VzIHJlcXVpcmUgc2V0dGluZyBvcHRpb25zIHRvIGRpZmZlcmVudFxuICAvLyB2YWx1ZXMgZm9yIHRoZSByZWFkYWJsZSBhbmQgdGhlIHdyaXRhYmxlIHNpZGVzIG9mIHRoZSBkdXBsZXggc3RyZWFtLFxuICAvLyBlLmcuIG9wdGlvbnMucmVhZGFibGVPYmplY3RNb2RlIHZzLiBvcHRpb25zLndyaXRhYmxlT2JqZWN0TW9kZSwgZXRjLlxuXG4gIGlmICh0eXBlb2YgaXNEdXBsZXggIT09ICdib29sZWFuJykgaXNEdXBsZXggPSBzdHJlYW0gaW5zdGFuY2VvZiBEdXBsZXg7IC8vIG9iamVjdCBzdHJlYW0gZmxhZyB0byBpbmRpY2F0ZSB3aGV0aGVyIG9yIG5vdCB0aGlzIHN0cmVhbVxuICAvLyBjb250YWlucyBidWZmZXJzIG9yIG9iamVjdHMuXG5cbiAgdGhpcy5vYmplY3RNb2RlID0gISFvcHRpb25zLm9iamVjdE1vZGU7XG4gIGlmIChpc0R1cGxleCkgdGhpcy5vYmplY3RNb2RlID0gdGhpcy5vYmplY3RNb2RlIHx8ICEhb3B0aW9ucy53cml0YWJsZU9iamVjdE1vZGU7IC8vIHRoZSBwb2ludCBhdCB3aGljaCB3cml0ZSgpIHN0YXJ0cyByZXR1cm5pbmcgZmFsc2VcbiAgLy8gTm90ZTogMCBpcyBhIHZhbGlkIHZhbHVlLCBtZWFucyB0aGF0IHdlIGFsd2F5cyByZXR1cm4gZmFsc2UgaWZcbiAgLy8gdGhlIGVudGlyZSBidWZmZXIgaXMgbm90IGZsdXNoZWQgaW1tZWRpYXRlbHkgb24gd3JpdGUoKVxuXG4gIHRoaXMuaGlnaFdhdGVyTWFyayA9IGdldEhpZ2hXYXRlck1hcmsodGhpcywgb3B0aW9ucywgJ3dyaXRhYmxlSGlnaFdhdGVyTWFyaycsIGlzRHVwbGV4KTsgLy8gaWYgX2ZpbmFsIGhhcyBiZWVuIGNhbGxlZFxuXG4gIHRoaXMuZmluYWxDYWxsZWQgPSBmYWxzZTsgLy8gZHJhaW4gZXZlbnQgZmxhZy5cblxuICB0aGlzLm5lZWREcmFpbiA9IGZhbHNlOyAvLyBhdCB0aGUgc3RhcnQgb2YgY2FsbGluZyBlbmQoKVxuXG4gIHRoaXMuZW5kaW5nID0gZmFsc2U7IC8vIHdoZW4gZW5kKCkgaGFzIGJlZW4gY2FsbGVkLCBhbmQgcmV0dXJuZWRcblxuICB0aGlzLmVuZGVkID0gZmFsc2U7IC8vIHdoZW4gJ2ZpbmlzaCcgaXMgZW1pdHRlZFxuXG4gIHRoaXMuZmluaXNoZWQgPSBmYWxzZTsgLy8gaGFzIGl0IGJlZW4gZGVzdHJveWVkXG5cbiAgdGhpcy5kZXN0cm95ZWQgPSBmYWxzZTsgLy8gc2hvdWxkIHdlIGRlY29kZSBzdHJpbmdzIGludG8gYnVmZmVycyBiZWZvcmUgcGFzc2luZyB0byBfd3JpdGU/XG4gIC8vIHRoaXMgaXMgaGVyZSBzbyB0aGF0IHNvbWUgbm9kZS1jb3JlIHN0cmVhbXMgY2FuIG9wdGltaXplIHN0cmluZ1xuICAvLyBoYW5kbGluZyBhdCBhIGxvd2VyIGxldmVsLlxuXG4gIHZhciBub0RlY29kZSA9IG9wdGlvbnMuZGVjb2RlU3RyaW5ncyA9PT0gZmFsc2U7XG4gIHRoaXMuZGVjb2RlU3RyaW5ncyA9ICFub0RlY29kZTsgLy8gQ3J5cHRvIGlzIGtpbmQgb2Ygb2xkIGFuZCBjcnVzdHkuICBIaXN0b3JpY2FsbHksIGl0cyBkZWZhdWx0IHN0cmluZ1xuICAvLyBlbmNvZGluZyBpcyAnYmluYXJ5JyBzbyB3ZSBoYXZlIHRvIG1ha2UgdGhpcyBjb25maWd1cmFibGUuXG4gIC8vIEV2ZXJ5dGhpbmcgZWxzZSBpbiB0aGUgdW5pdmVyc2UgdXNlcyAndXRmOCcsIHRob3VnaC5cblxuICB0aGlzLmRlZmF1bHRFbmNvZGluZyA9IG9wdGlvbnMuZGVmYXVsdEVuY29kaW5nIHx8ICd1dGY4JzsgLy8gbm90IGFuIGFjdHVhbCBidWZmZXIgd2Uga2VlcCB0cmFjayBvZiwgYnV0IGEgbWVhc3VyZW1lbnRcbiAgLy8gb2YgaG93IG11Y2ggd2UncmUgd2FpdGluZyB0byBnZXQgcHVzaGVkIHRvIHNvbWUgdW5kZXJseWluZ1xuICAvLyBzb2NrZXQgb3IgZmlsZS5cblxuICB0aGlzLmxlbmd0aCA9IDA7IC8vIGEgZmxhZyB0byBzZWUgd2hlbiB3ZSdyZSBpbiB0aGUgbWlkZGxlIG9mIGEgd3JpdGUuXG5cbiAgdGhpcy53cml0aW5nID0gZmFsc2U7IC8vIHdoZW4gdHJ1ZSBhbGwgd3JpdGVzIHdpbGwgYmUgYnVmZmVyZWQgdW50aWwgLnVuY29yaygpIGNhbGxcblxuICB0aGlzLmNvcmtlZCA9IDA7IC8vIGEgZmxhZyB0byBiZSBhYmxlIHRvIHRlbGwgaWYgdGhlIG9ud3JpdGUgY2IgaXMgY2FsbGVkIGltbWVkaWF0ZWx5LFxuICAvLyBvciBvbiBhIGxhdGVyIHRpY2suICBXZSBzZXQgdGhpcyB0byB0cnVlIGF0IGZpcnN0LCBiZWNhdXNlIGFueVxuICAvLyBhY3Rpb25zIHRoYXQgc2hvdWxkbid0IGhhcHBlbiB1bnRpbCBcImxhdGVyXCIgc2hvdWxkIGdlbmVyYWxseSBhbHNvXG4gIC8vIG5vdCBoYXBwZW4gYmVmb3JlIHRoZSBmaXJzdCB3cml0ZSBjYWxsLlxuXG4gIHRoaXMuc3luYyA9IHRydWU7IC8vIGEgZmxhZyB0byBrbm93IGlmIHdlJ3JlIHByb2Nlc3NpbmcgcHJldmlvdXNseSBidWZmZXJlZCBpdGVtcywgd2hpY2hcbiAgLy8gbWF5IGNhbGwgdGhlIF93cml0ZSgpIGNhbGxiYWNrIGluIHRoZSBzYW1lIHRpY2ssIHNvIHRoYXQgd2UgZG9uJ3RcbiAgLy8gZW5kIHVwIGluIGFuIG92ZXJsYXBwZWQgb253cml0ZSBzaXR1YXRpb24uXG5cbiAgdGhpcy5idWZmZXJQcm9jZXNzaW5nID0gZmFsc2U7IC8vIHRoZSBjYWxsYmFjayB0aGF0J3MgcGFzc2VkIHRvIF93cml0ZShjaHVuayxjYilcblxuICB0aGlzLm9ud3JpdGUgPSBmdW5jdGlvbiAoZXIpIHtcbiAgICBvbndyaXRlKHN0cmVhbSwgZXIpO1xuICB9OyAvLyB0aGUgY2FsbGJhY2sgdGhhdCB0aGUgdXNlciBzdXBwbGllcyB0byB3cml0ZShjaHVuayxlbmNvZGluZyxjYilcblxuXG4gIHRoaXMud3JpdGVjYiA9IG51bGw7IC8vIHRoZSBhbW91bnQgdGhhdCBpcyBiZWluZyB3cml0dGVuIHdoZW4gX3dyaXRlIGlzIGNhbGxlZC5cblxuICB0aGlzLndyaXRlbGVuID0gMDtcbiAgdGhpcy5idWZmZXJlZFJlcXVlc3QgPSBudWxsO1xuICB0aGlzLmxhc3RCdWZmZXJlZFJlcXVlc3QgPSBudWxsOyAvLyBudW1iZXIgb2YgcGVuZGluZyB1c2VyLXN1cHBsaWVkIHdyaXRlIGNhbGxiYWNrc1xuICAvLyB0aGlzIG11c3QgYmUgMCBiZWZvcmUgJ2ZpbmlzaCcgY2FuIGJlIGVtaXR0ZWRcblxuICB0aGlzLnBlbmRpbmdjYiA9IDA7IC8vIGVtaXQgcHJlZmluaXNoIGlmIHRoZSBvbmx5IHRoaW5nIHdlJ3JlIHdhaXRpbmcgZm9yIGlzIF93cml0ZSBjYnNcbiAgLy8gVGhpcyBpcyByZWxldmFudCBmb3Igc3luY2hyb25vdXMgVHJhbnNmb3JtIHN0cmVhbXNcblxuICB0aGlzLnByZWZpbmlzaGVkID0gZmFsc2U7IC8vIFRydWUgaWYgdGhlIGVycm9yIHdhcyBhbHJlYWR5IGVtaXR0ZWQgYW5kIHNob3VsZCBub3QgYmUgdGhyb3duIGFnYWluXG5cbiAgdGhpcy5lcnJvckVtaXR0ZWQgPSBmYWxzZTsgLy8gU2hvdWxkIGNsb3NlIGJlIGVtaXR0ZWQgb24gZGVzdHJveS4gRGVmYXVsdHMgdG8gdHJ1ZS5cblxuICB0aGlzLmVtaXRDbG9zZSA9IG9wdGlvbnMuZW1pdENsb3NlICE9PSBmYWxzZTsgLy8gU2hvdWxkIC5kZXN0cm95KCkgYmUgY2FsbGVkIGFmdGVyICdmaW5pc2gnIChhbmQgcG90ZW50aWFsbHkgJ2VuZCcpXG5cbiAgdGhpcy5hdXRvRGVzdHJveSA9ICEhb3B0aW9ucy5hdXRvRGVzdHJveTsgLy8gY291bnQgYnVmZmVyZWQgcmVxdWVzdHNcblxuICB0aGlzLmJ1ZmZlcmVkUmVxdWVzdENvdW50ID0gMDsgLy8gYWxsb2NhdGUgdGhlIGZpcnN0IENvcmtlZFJlcXVlc3QsIHRoZXJlIGlzIGFsd2F5c1xuICAvLyBvbmUgYWxsb2NhdGVkIGFuZCBmcmVlIHRvIHVzZSwgYW5kIHdlIG1haW50YWluIGF0IG1vc3QgdHdvXG5cbiAgdGhpcy5jb3JrZWRSZXF1ZXN0c0ZyZWUgPSBuZXcgQ29ya2VkUmVxdWVzdCh0aGlzKTtcbn1cblxuV3JpdGFibGVTdGF0ZS5wcm90b3R5cGUuZ2V0QnVmZmVyID0gZnVuY3Rpb24gZ2V0QnVmZmVyKCkge1xuICB2YXIgY3VycmVudCA9IHRoaXMuYnVmZmVyZWRSZXF1ZXN0O1xuICB2YXIgb3V0ID0gW107XG5cbiAgd2hpbGUgKGN1cnJlbnQpIHtcbiAgICBvdXQucHVzaChjdXJyZW50KTtcbiAgICBjdXJyZW50ID0gY3VycmVudC5uZXh0O1xuICB9XG5cbiAgcmV0dXJuIG91dDtcbn07XG5cbihmdW5jdGlvbiAoKSB7XG4gIHRyeSB7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFdyaXRhYmxlU3RhdGUucHJvdG90eXBlLCAnYnVmZmVyJywge1xuICAgICAgZ2V0OiBpbnRlcm5hbFV0aWwuZGVwcmVjYXRlKGZ1bmN0aW9uIHdyaXRhYmxlU3RhdGVCdWZmZXJHZXR0ZXIoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmdldEJ1ZmZlcigpO1xuICAgICAgfSwgJ193cml0YWJsZVN0YXRlLmJ1ZmZlciBpcyBkZXByZWNhdGVkLiBVc2UgX3dyaXRhYmxlU3RhdGUuZ2V0QnVmZmVyICcgKyAnaW5zdGVhZC4nLCAnREVQMDAwMycpXG4gICAgfSk7XG4gIH0gY2F0Y2ggKF8pIHt9XG59KSgpOyAvLyBUZXN0IF93cml0YWJsZVN0YXRlIGZvciBpbmhlcml0YW5jZSB0byBhY2NvdW50IGZvciBEdXBsZXggc3RyZWFtcyxcbi8vIHdob3NlIHByb3RvdHlwZSBjaGFpbiBvbmx5IHBvaW50cyB0byBSZWFkYWJsZS5cblxuXG52YXIgcmVhbEhhc0luc3RhbmNlO1xuXG5pZiAodHlwZW9mIFN5bWJvbCA9PT0gJ2Z1bmN0aW9uJyAmJiBTeW1ib2wuaGFzSW5zdGFuY2UgJiYgdHlwZW9mIEZ1bmN0aW9uLnByb3RvdHlwZVtTeW1ib2wuaGFzSW5zdGFuY2VdID09PSAnZnVuY3Rpb24nKSB7XG4gIHJlYWxIYXNJbnN0YW5jZSA9IEZ1bmN0aW9uLnByb3RvdHlwZVtTeW1ib2wuaGFzSW5zdGFuY2VdO1xuICBPYmplY3QuZGVmaW5lUHJvcGVydHkoV3JpdGFibGUsIFN5bWJvbC5oYXNJbnN0YW5jZSwge1xuICAgIHZhbHVlOiBmdW5jdGlvbiB2YWx1ZShvYmplY3QpIHtcbiAgICAgIGlmIChyZWFsSGFzSW5zdGFuY2UuY2FsbCh0aGlzLCBvYmplY3QpKSByZXR1cm4gdHJ1ZTtcbiAgICAgIGlmICh0aGlzICE9PSBXcml0YWJsZSkgcmV0dXJuIGZhbHNlO1xuICAgICAgcmV0dXJuIG9iamVjdCAmJiBvYmplY3QuX3dyaXRhYmxlU3RhdGUgaW5zdGFuY2VvZiBXcml0YWJsZVN0YXRlO1xuICAgIH1cbiAgfSk7XG59IGVsc2Uge1xuICByZWFsSGFzSW5zdGFuY2UgPSBmdW5jdGlvbiByZWFsSGFzSW5zdGFuY2Uob2JqZWN0KSB7XG4gICAgcmV0dXJuIG9iamVjdCBpbnN0YW5jZW9mIHRoaXM7XG4gIH07XG59XG5cbmZ1bmN0aW9uIFdyaXRhYmxlKG9wdGlvbnMpIHtcbiAgRHVwbGV4ID0gRHVwbGV4IHx8IHJlcXVpcmUoJy4vX3N0cmVhbV9kdXBsZXgnKTsgLy8gV3JpdGFibGUgY3RvciBpcyBhcHBsaWVkIHRvIER1cGxleGVzLCB0b28uXG4gIC8vIGByZWFsSGFzSW5zdGFuY2VgIGlzIG5lY2Vzc2FyeSBiZWNhdXNlIHVzaW5nIHBsYWluIGBpbnN0YW5jZW9mYFxuICAvLyB3b3VsZCByZXR1cm4gZmFsc2UsIGFzIG5vIGBfd3JpdGFibGVTdGF0ZWAgcHJvcGVydHkgaXMgYXR0YWNoZWQuXG4gIC8vIFRyeWluZyB0byB1c2UgdGhlIGN1c3RvbSBgaW5zdGFuY2VvZmAgZm9yIFdyaXRhYmxlIGhlcmUgd2lsbCBhbHNvIGJyZWFrIHRoZVxuICAvLyBOb2RlLmpzIExhenlUcmFuc2Zvcm0gaW1wbGVtZW50YXRpb24sIHdoaWNoIGhhcyBhIG5vbi10cml2aWFsIGdldHRlciBmb3JcbiAgLy8gYF93cml0YWJsZVN0YXRlYCB0aGF0IHdvdWxkIGxlYWQgdG8gaW5maW5pdGUgcmVjdXJzaW9uLlxuICAvLyBDaGVja2luZyBmb3IgYSBTdHJlYW0uRHVwbGV4IGluc3RhbmNlIGlzIGZhc3RlciBoZXJlIGluc3RlYWQgb2YgaW5zaWRlXG4gIC8vIHRoZSBXcml0YWJsZVN0YXRlIGNvbnN0cnVjdG9yLCBhdCBsZWFzdCB3aXRoIFY4IDYuNVxuXG4gIHZhciBpc0R1cGxleCA9IHRoaXMgaW5zdGFuY2VvZiBEdXBsZXg7XG4gIGlmICghaXNEdXBsZXggJiYgIXJlYWxIYXNJbnN0YW5jZS5jYWxsKFdyaXRhYmxlLCB0aGlzKSkgcmV0dXJuIG5ldyBXcml0YWJsZShvcHRpb25zKTtcbiAgdGhpcy5fd3JpdGFibGVTdGF0ZSA9IG5ldyBXcml0YWJsZVN0YXRlKG9wdGlvbnMsIHRoaXMsIGlzRHVwbGV4KTsgLy8gbGVnYWN5LlxuXG4gIHRoaXMud3JpdGFibGUgPSB0cnVlO1xuXG4gIGlmIChvcHRpb25zKSB7XG4gICAgaWYgKHR5cGVvZiBvcHRpb25zLndyaXRlID09PSAnZnVuY3Rpb24nKSB0aGlzLl93cml0ZSA9IG9wdGlvbnMud3JpdGU7XG4gICAgaWYgKHR5cGVvZiBvcHRpb25zLndyaXRldiA9PT0gJ2Z1bmN0aW9uJykgdGhpcy5fd3JpdGV2ID0gb3B0aW9ucy53cml0ZXY7XG4gICAgaWYgKHR5cGVvZiBvcHRpb25zLmRlc3Ryb3kgPT09ICdmdW5jdGlvbicpIHRoaXMuX2Rlc3Ryb3kgPSBvcHRpb25zLmRlc3Ryb3k7XG4gICAgaWYgKHR5cGVvZiBvcHRpb25zLmZpbmFsID09PSAnZnVuY3Rpb24nKSB0aGlzLl9maW5hbCA9IG9wdGlvbnMuZmluYWw7XG4gIH1cblxuICBTdHJlYW0uY2FsbCh0aGlzKTtcbn0gLy8gT3RoZXJ3aXNlIHBlb3BsZSBjYW4gcGlwZSBXcml0YWJsZSBzdHJlYW1zLCB3aGljaCBpcyBqdXN0IHdyb25nLlxuXG5cbldyaXRhYmxlLnByb3RvdHlwZS5waXBlID0gZnVuY3Rpb24gKCkge1xuICBlcnJvck9yRGVzdHJveSh0aGlzLCBuZXcgRVJSX1NUUkVBTV9DQU5OT1RfUElQRSgpKTtcbn07XG5cbmZ1bmN0aW9uIHdyaXRlQWZ0ZXJFbmQoc3RyZWFtLCBjYikge1xuICB2YXIgZXIgPSBuZXcgRVJSX1NUUkVBTV9XUklURV9BRlRFUl9FTkQoKTsgLy8gVE9ETzogZGVmZXIgZXJyb3IgZXZlbnRzIGNvbnNpc3RlbnRseSBldmVyeXdoZXJlLCBub3QganVzdCB0aGUgY2JcblxuICBlcnJvck9yRGVzdHJveShzdHJlYW0sIGVyKTtcbiAgcHJvY2Vzcy5uZXh0VGljayhjYiwgZXIpO1xufSAvLyBDaGVja3MgdGhhdCBhIHVzZXItc3VwcGxpZWQgY2h1bmsgaXMgdmFsaWQsIGVzcGVjaWFsbHkgZm9yIHRoZSBwYXJ0aWN1bGFyXG4vLyBtb2RlIHRoZSBzdHJlYW0gaXMgaW4uIEN1cnJlbnRseSB0aGlzIG1lYW5zIHRoYXQgYG51bGxgIGlzIG5ldmVyIGFjY2VwdGVkXG4vLyBhbmQgdW5kZWZpbmVkL25vbi1zdHJpbmcgdmFsdWVzIGFyZSBvbmx5IGFsbG93ZWQgaW4gb2JqZWN0IG1vZGUuXG5cblxuZnVuY3Rpb24gdmFsaWRDaHVuayhzdHJlYW0sIHN0YXRlLCBjaHVuaywgY2IpIHtcbiAgdmFyIGVyO1xuXG4gIGlmIChjaHVuayA9PT0gbnVsbCkge1xuICAgIGVyID0gbmV3IEVSUl9TVFJFQU1fTlVMTF9WQUxVRVMoKTtcbiAgfSBlbHNlIGlmICh0eXBlb2YgY2h1bmsgIT09ICdzdHJpbmcnICYmICFzdGF0ZS5vYmplY3RNb2RlKSB7XG4gICAgZXIgPSBuZXcgRVJSX0lOVkFMSURfQVJHX1RZUEUoJ2NodW5rJywgWydzdHJpbmcnLCAnQnVmZmVyJ10sIGNodW5rKTtcbiAgfVxuXG4gIGlmIChlcikge1xuICAgIGVycm9yT3JEZXN0cm95KHN0cmVhbSwgZXIpO1xuICAgIHByb2Nlc3MubmV4dFRpY2soY2IsIGVyKTtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICByZXR1cm4gdHJ1ZTtcbn1cblxuV3JpdGFibGUucHJvdG90eXBlLndyaXRlID0gZnVuY3Rpb24gKGNodW5rLCBlbmNvZGluZywgY2IpIHtcbiAgdmFyIHN0YXRlID0gdGhpcy5fd3JpdGFibGVTdGF0ZTtcbiAgdmFyIHJldCA9IGZhbHNlO1xuXG4gIHZhciBpc0J1ZiA9ICFzdGF0ZS5vYmplY3RNb2RlICYmIF9pc1VpbnQ4QXJyYXkoY2h1bmspO1xuXG4gIGlmIChpc0J1ZiAmJiAhQnVmZmVyLmlzQnVmZmVyKGNodW5rKSkge1xuICAgIGNodW5rID0gX3VpbnQ4QXJyYXlUb0J1ZmZlcihjaHVuayk7XG4gIH1cblxuICBpZiAodHlwZW9mIGVuY29kaW5nID09PSAnZnVuY3Rpb24nKSB7XG4gICAgY2IgPSBlbmNvZGluZztcbiAgICBlbmNvZGluZyA9IG51bGw7XG4gIH1cblxuICBpZiAoaXNCdWYpIGVuY29kaW5nID0gJ2J1ZmZlcic7ZWxzZSBpZiAoIWVuY29kaW5nKSBlbmNvZGluZyA9IHN0YXRlLmRlZmF1bHRFbmNvZGluZztcbiAgaWYgKHR5cGVvZiBjYiAhPT0gJ2Z1bmN0aW9uJykgY2IgPSBub3A7XG4gIGlmIChzdGF0ZS5lbmRpbmcpIHdyaXRlQWZ0ZXJFbmQodGhpcywgY2IpO2Vsc2UgaWYgKGlzQnVmIHx8IHZhbGlkQ2h1bmsodGhpcywgc3RhdGUsIGNodW5rLCBjYikpIHtcbiAgICBzdGF0ZS5wZW5kaW5nY2IrKztcbiAgICByZXQgPSB3cml0ZU9yQnVmZmVyKHRoaXMsIHN0YXRlLCBpc0J1ZiwgY2h1bmssIGVuY29kaW5nLCBjYik7XG4gIH1cbiAgcmV0dXJuIHJldDtcbn07XG5cbldyaXRhYmxlLnByb3RvdHlwZS5jb3JrID0gZnVuY3Rpb24gKCkge1xuICB0aGlzLl93cml0YWJsZVN0YXRlLmNvcmtlZCsrO1xufTtcblxuV3JpdGFibGUucHJvdG90eXBlLnVuY29yayA9IGZ1bmN0aW9uICgpIHtcbiAgdmFyIHN0YXRlID0gdGhpcy5fd3JpdGFibGVTdGF0ZTtcblxuICBpZiAoc3RhdGUuY29ya2VkKSB7XG4gICAgc3RhdGUuY29ya2VkLS07XG4gICAgaWYgKCFzdGF0ZS53cml0aW5nICYmICFzdGF0ZS5jb3JrZWQgJiYgIXN0YXRlLmJ1ZmZlclByb2Nlc3NpbmcgJiYgc3RhdGUuYnVmZmVyZWRSZXF1ZXN0KSBjbGVhckJ1ZmZlcih0aGlzLCBzdGF0ZSk7XG4gIH1cbn07XG5cbldyaXRhYmxlLnByb3RvdHlwZS5zZXREZWZhdWx0RW5jb2RpbmcgPSBmdW5jdGlvbiBzZXREZWZhdWx0RW5jb2RpbmcoZW5jb2RpbmcpIHtcbiAgLy8gbm9kZTo6UGFyc2VFbmNvZGluZygpIHJlcXVpcmVzIGxvd2VyIGNhc2UuXG4gIGlmICh0eXBlb2YgZW5jb2RpbmcgPT09ICdzdHJpbmcnKSBlbmNvZGluZyA9IGVuY29kaW5nLnRvTG93ZXJDYXNlKCk7XG4gIGlmICghKFsnaGV4JywgJ3V0ZjgnLCAndXRmLTgnLCAnYXNjaWknLCAnYmluYXJ5JywgJ2Jhc2U2NCcsICd1Y3MyJywgJ3Vjcy0yJywgJ3V0ZjE2bGUnLCAndXRmLTE2bGUnLCAncmF3J10uaW5kZXhPZigoZW5jb2RpbmcgKyAnJykudG9Mb3dlckNhc2UoKSkgPiAtMSkpIHRocm93IG5ldyBFUlJfVU5LTk9XTl9FTkNPRElORyhlbmNvZGluZyk7XG4gIHRoaXMuX3dyaXRhYmxlU3RhdGUuZGVmYXVsdEVuY29kaW5nID0gZW5jb2Rpbmc7XG4gIHJldHVybiB0aGlzO1xufTtcblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KFdyaXRhYmxlLnByb3RvdHlwZSwgJ3dyaXRhYmxlQnVmZmVyJywge1xuICAvLyBtYWtpbmcgaXQgZXhwbGljaXQgdGhpcyBwcm9wZXJ0eSBpcyBub3QgZW51bWVyYWJsZVxuICAvLyBiZWNhdXNlIG90aGVyd2lzZSBzb21lIHByb3RvdHlwZSBtYW5pcHVsYXRpb24gaW5cbiAgLy8gdXNlcmxhbmQgd2lsbCBmYWlsXG4gIGVudW1lcmFibGU6IGZhbHNlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICByZXR1cm4gdGhpcy5fd3JpdGFibGVTdGF0ZSAmJiB0aGlzLl93cml0YWJsZVN0YXRlLmdldEJ1ZmZlcigpO1xuICB9XG59KTtcblxuZnVuY3Rpb24gZGVjb2RlQ2h1bmsoc3RhdGUsIGNodW5rLCBlbmNvZGluZykge1xuICBpZiAoIXN0YXRlLm9iamVjdE1vZGUgJiYgc3RhdGUuZGVjb2RlU3RyaW5ncyAhPT0gZmFsc2UgJiYgdHlwZW9mIGNodW5rID09PSAnc3RyaW5nJykge1xuICAgIGNodW5rID0gQnVmZmVyLmZyb20oY2h1bmssIGVuY29kaW5nKTtcbiAgfVxuXG4gIHJldHVybiBjaHVuaztcbn1cblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KFdyaXRhYmxlLnByb3RvdHlwZSwgJ3dyaXRhYmxlSGlnaFdhdGVyTWFyaycsIHtcbiAgLy8gbWFraW5nIGl0IGV4cGxpY2l0IHRoaXMgcHJvcGVydHkgaXMgbm90IGVudW1lcmFibGVcbiAgLy8gYmVjYXVzZSBvdGhlcndpc2Ugc29tZSBwcm90b3R5cGUgbWFuaXB1bGF0aW9uIGluXG4gIC8vIHVzZXJsYW5kIHdpbGwgZmFpbFxuICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgZ2V0OiBmdW5jdGlvbiBnZXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3dyaXRhYmxlU3RhdGUuaGlnaFdhdGVyTWFyaztcbiAgfVxufSk7IC8vIGlmIHdlJ3JlIGFscmVhZHkgd3JpdGluZyBzb21ldGhpbmcsIHRoZW4ganVzdCBwdXQgdGhpc1xuLy8gaW4gdGhlIHF1ZXVlLCBhbmQgd2FpdCBvdXIgdHVybi4gIE90aGVyd2lzZSwgY2FsbCBfd3JpdGVcbi8vIElmIHdlIHJldHVybiBmYWxzZSwgdGhlbiB3ZSBuZWVkIGEgZHJhaW4gZXZlbnQsIHNvIHNldCB0aGF0IGZsYWcuXG5cbmZ1bmN0aW9uIHdyaXRlT3JCdWZmZXIoc3RyZWFtLCBzdGF0ZSwgaXNCdWYsIGNodW5rLCBlbmNvZGluZywgY2IpIHtcbiAgaWYgKCFpc0J1Zikge1xuICAgIHZhciBuZXdDaHVuayA9IGRlY29kZUNodW5rKHN0YXRlLCBjaHVuaywgZW5jb2RpbmcpO1xuXG4gICAgaWYgKGNodW5rICE9PSBuZXdDaHVuaykge1xuICAgICAgaXNCdWYgPSB0cnVlO1xuICAgICAgZW5jb2RpbmcgPSAnYnVmZmVyJztcbiAgICAgIGNodW5rID0gbmV3Q2h1bms7XG4gICAgfVxuICB9XG5cbiAgdmFyIGxlbiA9IHN0YXRlLm9iamVjdE1vZGUgPyAxIDogY2h1bmsubGVuZ3RoO1xuICBzdGF0ZS5sZW5ndGggKz0gbGVuO1xuICB2YXIgcmV0ID0gc3RhdGUubGVuZ3RoIDwgc3RhdGUuaGlnaFdhdGVyTWFyazsgLy8gd2UgbXVzdCBlbnN1cmUgdGhhdCBwcmV2aW91cyBuZWVkRHJhaW4gd2lsbCBub3QgYmUgcmVzZXQgdG8gZmFsc2UuXG5cbiAgaWYgKCFyZXQpIHN0YXRlLm5lZWREcmFpbiA9IHRydWU7XG5cbiAgaWYgKHN0YXRlLndyaXRpbmcgfHwgc3RhdGUuY29ya2VkKSB7XG4gICAgdmFyIGxhc3QgPSBzdGF0ZS5sYXN0QnVmZmVyZWRSZXF1ZXN0O1xuICAgIHN0YXRlLmxhc3RCdWZmZXJlZFJlcXVlc3QgPSB7XG4gICAgICBjaHVuazogY2h1bmssXG4gICAgICBlbmNvZGluZzogZW5jb2RpbmcsXG4gICAgICBpc0J1ZjogaXNCdWYsXG4gICAgICBjYWxsYmFjazogY2IsXG4gICAgICBuZXh0OiBudWxsXG4gICAgfTtcblxuICAgIGlmIChsYXN0KSB7XG4gICAgICBsYXN0Lm5leHQgPSBzdGF0ZS5sYXN0QnVmZmVyZWRSZXF1ZXN0O1xuICAgIH0gZWxzZSB7XG4gICAgICBzdGF0ZS5idWZmZXJlZFJlcXVlc3QgPSBzdGF0ZS5sYXN0QnVmZmVyZWRSZXF1ZXN0O1xuICAgIH1cblxuICAgIHN0YXRlLmJ1ZmZlcmVkUmVxdWVzdENvdW50ICs9IDE7XG4gIH0gZWxzZSB7XG4gICAgZG9Xcml0ZShzdHJlYW0sIHN0YXRlLCBmYWxzZSwgbGVuLCBjaHVuaywgZW5jb2RpbmcsIGNiKTtcbiAgfVxuXG4gIHJldHVybiByZXQ7XG59XG5cbmZ1bmN0aW9uIGRvV3JpdGUoc3RyZWFtLCBzdGF0ZSwgd3JpdGV2LCBsZW4sIGNodW5rLCBlbmNvZGluZywgY2IpIHtcbiAgc3RhdGUud3JpdGVsZW4gPSBsZW47XG4gIHN0YXRlLndyaXRlY2IgPSBjYjtcbiAgc3RhdGUud3JpdGluZyA9IHRydWU7XG4gIHN0YXRlLnN5bmMgPSB0cnVlO1xuICBpZiAoc3RhdGUuZGVzdHJveWVkKSBzdGF0ZS5vbndyaXRlKG5ldyBFUlJfU1RSRUFNX0RFU1RST1lFRCgnd3JpdGUnKSk7ZWxzZSBpZiAod3JpdGV2KSBzdHJlYW0uX3dyaXRldihjaHVuaywgc3RhdGUub253cml0ZSk7ZWxzZSBzdHJlYW0uX3dyaXRlKGNodW5rLCBlbmNvZGluZywgc3RhdGUub253cml0ZSk7XG4gIHN0YXRlLnN5bmMgPSBmYWxzZTtcbn1cblxuZnVuY3Rpb24gb253cml0ZUVycm9yKHN0cmVhbSwgc3RhdGUsIHN5bmMsIGVyLCBjYikge1xuICAtLXN0YXRlLnBlbmRpbmdjYjtcblxuICBpZiAoc3luYykge1xuICAgIC8vIGRlZmVyIHRoZSBjYWxsYmFjayBpZiB3ZSBhcmUgYmVpbmcgY2FsbGVkIHN5bmNocm9ub3VzbHlcbiAgICAvLyB0byBhdm9pZCBwaWxpbmcgdXAgdGhpbmdzIG9uIHRoZSBzdGFja1xuICAgIHByb2Nlc3MubmV4dFRpY2soY2IsIGVyKTsgLy8gdGhpcyBjYW4gZW1pdCBmaW5pc2gsIGFuZCBpdCB3aWxsIGFsd2F5cyBoYXBwZW5cbiAgICAvLyBhZnRlciBlcnJvclxuXG4gICAgcHJvY2Vzcy5uZXh0VGljayhmaW5pc2hNYXliZSwgc3RyZWFtLCBzdGF0ZSk7XG4gICAgc3RyZWFtLl93cml0YWJsZVN0YXRlLmVycm9yRW1pdHRlZCA9IHRydWU7XG4gICAgZXJyb3JPckRlc3Ryb3koc3RyZWFtLCBlcik7XG4gIH0gZWxzZSB7XG4gICAgLy8gdGhlIGNhbGxlciBleHBlY3QgdGhpcyB0byBoYXBwZW4gYmVmb3JlIGlmXG4gICAgLy8gaXQgaXMgYXN5bmNcbiAgICBjYihlcik7XG4gICAgc3RyZWFtLl93cml0YWJsZVN0YXRlLmVycm9yRW1pdHRlZCA9IHRydWU7XG4gICAgZXJyb3JPckRlc3Ryb3koc3RyZWFtLCBlcik7IC8vIHRoaXMgY2FuIGVtaXQgZmluaXNoLCBidXQgZmluaXNoIG11c3RcbiAgICAvLyBhbHdheXMgZm9sbG93IGVycm9yXG5cbiAgICBmaW5pc2hNYXliZShzdHJlYW0sIHN0YXRlKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBvbndyaXRlU3RhdGVVcGRhdGUoc3RhdGUpIHtcbiAgc3RhdGUud3JpdGluZyA9IGZhbHNlO1xuICBzdGF0ZS53cml0ZWNiID0gbnVsbDtcbiAgc3RhdGUubGVuZ3RoIC09IHN0YXRlLndyaXRlbGVuO1xuICBzdGF0ZS53cml0ZWxlbiA9IDA7XG59XG5cbmZ1bmN0aW9uIG9ud3JpdGUoc3RyZWFtLCBlcikge1xuICB2YXIgc3RhdGUgPSBzdHJlYW0uX3dyaXRhYmxlU3RhdGU7XG4gIHZhciBzeW5jID0gc3RhdGUuc3luYztcbiAgdmFyIGNiID0gc3RhdGUud3JpdGVjYjtcbiAgaWYgKHR5cGVvZiBjYiAhPT0gJ2Z1bmN0aW9uJykgdGhyb3cgbmV3IEVSUl9NVUxUSVBMRV9DQUxMQkFDSygpO1xuICBvbndyaXRlU3RhdGVVcGRhdGUoc3RhdGUpO1xuICBpZiAoZXIpIG9ud3JpdGVFcnJvcihzdHJlYW0sIHN0YXRlLCBzeW5jLCBlciwgY2IpO2Vsc2Uge1xuICAgIC8vIENoZWNrIGlmIHdlJ3JlIGFjdHVhbGx5IHJlYWR5IHRvIGZpbmlzaCwgYnV0IGRvbid0IGVtaXQgeWV0XG4gICAgdmFyIGZpbmlzaGVkID0gbmVlZEZpbmlzaChzdGF0ZSkgfHwgc3RyZWFtLmRlc3Ryb3llZDtcblxuICAgIGlmICghZmluaXNoZWQgJiYgIXN0YXRlLmNvcmtlZCAmJiAhc3RhdGUuYnVmZmVyUHJvY2Vzc2luZyAmJiBzdGF0ZS5idWZmZXJlZFJlcXVlc3QpIHtcbiAgICAgIGNsZWFyQnVmZmVyKHN0cmVhbSwgc3RhdGUpO1xuICAgIH1cblxuICAgIGlmIChzeW5jKSB7XG4gICAgICBwcm9jZXNzLm5leHRUaWNrKGFmdGVyV3JpdGUsIHN0cmVhbSwgc3RhdGUsIGZpbmlzaGVkLCBjYik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGFmdGVyV3JpdGUoc3RyZWFtLCBzdGF0ZSwgZmluaXNoZWQsIGNiKTtcbiAgICB9XG4gIH1cbn1cblxuZnVuY3Rpb24gYWZ0ZXJXcml0ZShzdHJlYW0sIHN0YXRlLCBmaW5pc2hlZCwgY2IpIHtcbiAgaWYgKCFmaW5pc2hlZCkgb253cml0ZURyYWluKHN0cmVhbSwgc3RhdGUpO1xuICBzdGF0ZS5wZW5kaW5nY2ItLTtcbiAgY2IoKTtcbiAgZmluaXNoTWF5YmUoc3RyZWFtLCBzdGF0ZSk7XG59IC8vIE11c3QgZm9yY2UgY2FsbGJhY2sgdG8gYmUgY2FsbGVkIG9uIG5leHRUaWNrLCBzbyB0aGF0IHdlIGRvbid0XG4vLyBlbWl0ICdkcmFpbicgYmVmb3JlIHRoZSB3cml0ZSgpIGNvbnN1bWVyIGdldHMgdGhlICdmYWxzZScgcmV0dXJuXG4vLyB2YWx1ZSwgYW5kIGhhcyBhIGNoYW5jZSB0byBhdHRhY2ggYSAnZHJhaW4nIGxpc3RlbmVyLlxuXG5cbmZ1bmN0aW9uIG9ud3JpdGVEcmFpbihzdHJlYW0sIHN0YXRlKSB7XG4gIGlmIChzdGF0ZS5sZW5ndGggPT09IDAgJiYgc3RhdGUubmVlZERyYWluKSB7XG4gICAgc3RhdGUubmVlZERyYWluID0gZmFsc2U7XG4gICAgc3RyZWFtLmVtaXQoJ2RyYWluJyk7XG4gIH1cbn0gLy8gaWYgdGhlcmUncyBzb21ldGhpbmcgaW4gdGhlIGJ1ZmZlciB3YWl0aW5nLCB0aGVuIHByb2Nlc3MgaXRcblxuXG5mdW5jdGlvbiBjbGVhckJ1ZmZlcihzdHJlYW0sIHN0YXRlKSB7XG4gIHN0YXRlLmJ1ZmZlclByb2Nlc3NpbmcgPSB0cnVlO1xuICB2YXIgZW50cnkgPSBzdGF0ZS5idWZmZXJlZFJlcXVlc3Q7XG5cbiAgaWYgKHN0cmVhbS5fd3JpdGV2ICYmIGVudHJ5ICYmIGVudHJ5Lm5leHQpIHtcbiAgICAvLyBGYXN0IGNhc2UsIHdyaXRlIGV2ZXJ5dGhpbmcgdXNpbmcgX3dyaXRldigpXG4gICAgdmFyIGwgPSBzdGF0ZS5idWZmZXJlZFJlcXVlc3RDb3VudDtcbiAgICB2YXIgYnVmZmVyID0gbmV3IEFycmF5KGwpO1xuICAgIHZhciBob2xkZXIgPSBzdGF0ZS5jb3JrZWRSZXF1ZXN0c0ZyZWU7XG4gICAgaG9sZGVyLmVudHJ5ID0gZW50cnk7XG4gICAgdmFyIGNvdW50ID0gMDtcbiAgICB2YXIgYWxsQnVmZmVycyA9IHRydWU7XG5cbiAgICB3aGlsZSAoZW50cnkpIHtcbiAgICAgIGJ1ZmZlcltjb3VudF0gPSBlbnRyeTtcbiAgICAgIGlmICghZW50cnkuaXNCdWYpIGFsbEJ1ZmZlcnMgPSBmYWxzZTtcbiAgICAgIGVudHJ5ID0gZW50cnkubmV4dDtcbiAgICAgIGNvdW50ICs9IDE7XG4gICAgfVxuXG4gICAgYnVmZmVyLmFsbEJ1ZmZlcnMgPSBhbGxCdWZmZXJzO1xuICAgIGRvV3JpdGUoc3RyZWFtLCBzdGF0ZSwgdHJ1ZSwgc3RhdGUubGVuZ3RoLCBidWZmZXIsICcnLCBob2xkZXIuZmluaXNoKTsgLy8gZG9Xcml0ZSBpcyBhbG1vc3QgYWx3YXlzIGFzeW5jLCBkZWZlciB0aGVzZSB0byBzYXZlIGEgYml0IG9mIHRpbWVcbiAgICAvLyBhcyB0aGUgaG90IHBhdGggZW5kcyB3aXRoIGRvV3JpdGVcblxuICAgIHN0YXRlLnBlbmRpbmdjYisrO1xuICAgIHN0YXRlLmxhc3RCdWZmZXJlZFJlcXVlc3QgPSBudWxsO1xuXG4gICAgaWYgKGhvbGRlci5uZXh0KSB7XG4gICAgICBzdGF0ZS5jb3JrZWRSZXF1ZXN0c0ZyZWUgPSBob2xkZXIubmV4dDtcbiAgICAgIGhvbGRlci5uZXh0ID0gbnVsbDtcbiAgICB9IGVsc2Uge1xuICAgICAgc3RhdGUuY29ya2VkUmVxdWVzdHNGcmVlID0gbmV3IENvcmtlZFJlcXVlc3Qoc3RhdGUpO1xuICAgIH1cblxuICAgIHN0YXRlLmJ1ZmZlcmVkUmVxdWVzdENvdW50ID0gMDtcbiAgfSBlbHNlIHtcbiAgICAvLyBTbG93IGNhc2UsIHdyaXRlIGNodW5rcyBvbmUtYnktb25lXG4gICAgd2hpbGUgKGVudHJ5KSB7XG4gICAgICB2YXIgY2h1bmsgPSBlbnRyeS5jaHVuaztcbiAgICAgIHZhciBlbmNvZGluZyA9IGVudHJ5LmVuY29kaW5nO1xuICAgICAgdmFyIGNiID0gZW50cnkuY2FsbGJhY2s7XG4gICAgICB2YXIgbGVuID0gc3RhdGUub2JqZWN0TW9kZSA/IDEgOiBjaHVuay5sZW5ndGg7XG4gICAgICBkb1dyaXRlKHN0cmVhbSwgc3RhdGUsIGZhbHNlLCBsZW4sIGNodW5rLCBlbmNvZGluZywgY2IpO1xuICAgICAgZW50cnkgPSBlbnRyeS5uZXh0O1xuICAgICAgc3RhdGUuYnVmZmVyZWRSZXF1ZXN0Q291bnQtLTsgLy8gaWYgd2UgZGlkbid0IGNhbGwgdGhlIG9ud3JpdGUgaW1tZWRpYXRlbHksIHRoZW5cbiAgICAgIC8vIGl0IG1lYW5zIHRoYXQgd2UgbmVlZCB0byB3YWl0IHVudGlsIGl0IGRvZXMuXG4gICAgICAvLyBhbHNvLCB0aGF0IG1lYW5zIHRoYXQgdGhlIGNodW5rIGFuZCBjYiBhcmUgY3VycmVudGx5XG4gICAgICAvLyBiZWluZyBwcm9jZXNzZWQsIHNvIG1vdmUgdGhlIGJ1ZmZlciBjb3VudGVyIHBhc3QgdGhlbS5cblxuICAgICAgaWYgKHN0YXRlLndyaXRpbmcpIHtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKGVudHJ5ID09PSBudWxsKSBzdGF0ZS5sYXN0QnVmZmVyZWRSZXF1ZXN0ID0gbnVsbDtcbiAgfVxuXG4gIHN0YXRlLmJ1ZmZlcmVkUmVxdWVzdCA9IGVudHJ5O1xuICBzdGF0ZS5idWZmZXJQcm9jZXNzaW5nID0gZmFsc2U7XG59XG5cbldyaXRhYmxlLnByb3RvdHlwZS5fd3JpdGUgPSBmdW5jdGlvbiAoY2h1bmssIGVuY29kaW5nLCBjYikge1xuICBjYihuZXcgRVJSX01FVEhPRF9OT1RfSU1QTEVNRU5URUQoJ193cml0ZSgpJykpO1xufTtcblxuV3JpdGFibGUucHJvdG90eXBlLl93cml0ZXYgPSBudWxsO1xuXG5Xcml0YWJsZS5wcm90b3R5cGUuZW5kID0gZnVuY3Rpb24gKGNodW5rLCBlbmNvZGluZywgY2IpIHtcbiAgdmFyIHN0YXRlID0gdGhpcy5fd3JpdGFibGVTdGF0ZTtcblxuICBpZiAodHlwZW9mIGNodW5rID09PSAnZnVuY3Rpb24nKSB7XG4gICAgY2IgPSBjaHVuaztcbiAgICBjaHVuayA9IG51bGw7XG4gICAgZW5jb2RpbmcgPSBudWxsO1xuICB9IGVsc2UgaWYgKHR5cGVvZiBlbmNvZGluZyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIGNiID0gZW5jb2Rpbmc7XG4gICAgZW5jb2RpbmcgPSBudWxsO1xuICB9XG5cbiAgaWYgKGNodW5rICE9PSBudWxsICYmIGNodW5rICE9PSB1bmRlZmluZWQpIHRoaXMud3JpdGUoY2h1bmssIGVuY29kaW5nKTsgLy8gLmVuZCgpIGZ1bGx5IHVuY29ya3NcblxuICBpZiAoc3RhdGUuY29ya2VkKSB7XG4gICAgc3RhdGUuY29ya2VkID0gMTtcbiAgICB0aGlzLnVuY29yaygpO1xuICB9IC8vIGlnbm9yZSB1bm5lY2Vzc2FyeSBlbmQoKSBjYWxscy5cblxuXG4gIGlmICghc3RhdGUuZW5kaW5nKSBlbmRXcml0YWJsZSh0aGlzLCBzdGF0ZSwgY2IpO1xuICByZXR1cm4gdGhpcztcbn07XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShXcml0YWJsZS5wcm90b3R5cGUsICd3cml0YWJsZUxlbmd0aCcsIHtcbiAgLy8gbWFraW5nIGl0IGV4cGxpY2l0IHRoaXMgcHJvcGVydHkgaXMgbm90IGVudW1lcmFibGVcbiAgLy8gYmVjYXVzZSBvdGhlcndpc2Ugc29tZSBwcm90b3R5cGUgbWFuaXB1bGF0aW9uIGluXG4gIC8vIHVzZXJsYW5kIHdpbGwgZmFpbFxuICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgZ2V0OiBmdW5jdGlvbiBnZXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3dyaXRhYmxlU3RhdGUubGVuZ3RoO1xuICB9XG59KTtcblxuZnVuY3Rpb24gbmVlZEZpbmlzaChzdGF0ZSkge1xuICByZXR1cm4gc3RhdGUuZW5kaW5nICYmIHN0YXRlLmxlbmd0aCA9PT0gMCAmJiBzdGF0ZS5idWZmZXJlZFJlcXVlc3QgPT09IG51bGwgJiYgIXN0YXRlLmZpbmlzaGVkICYmICFzdGF0ZS53cml0aW5nO1xufVxuXG5mdW5jdGlvbiBjYWxsRmluYWwoc3RyZWFtLCBzdGF0ZSkge1xuICBzdHJlYW0uX2ZpbmFsKGZ1bmN0aW9uIChlcnIpIHtcbiAgICBzdGF0ZS5wZW5kaW5nY2ItLTtcblxuICAgIGlmIChlcnIpIHtcbiAgICAgIGVycm9yT3JEZXN0cm95KHN0cmVhbSwgZXJyKTtcbiAgICB9XG5cbiAgICBzdGF0ZS5wcmVmaW5pc2hlZCA9IHRydWU7XG4gICAgc3RyZWFtLmVtaXQoJ3ByZWZpbmlzaCcpO1xuICAgIGZpbmlzaE1heWJlKHN0cmVhbSwgc3RhdGUpO1xuICB9KTtcbn1cblxuZnVuY3Rpb24gcHJlZmluaXNoKHN0cmVhbSwgc3RhdGUpIHtcbiAgaWYgKCFzdGF0ZS5wcmVmaW5pc2hlZCAmJiAhc3RhdGUuZmluYWxDYWxsZWQpIHtcbiAgICBpZiAodHlwZW9mIHN0cmVhbS5fZmluYWwgPT09ICdmdW5jdGlvbicgJiYgIXN0YXRlLmRlc3Ryb3llZCkge1xuICAgICAgc3RhdGUucGVuZGluZ2NiKys7XG4gICAgICBzdGF0ZS5maW5hbENhbGxlZCA9IHRydWU7XG4gICAgICBwcm9jZXNzLm5leHRUaWNrKGNhbGxGaW5hbCwgc3RyZWFtLCBzdGF0ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHN0YXRlLnByZWZpbmlzaGVkID0gdHJ1ZTtcbiAgICAgIHN0cmVhbS5lbWl0KCdwcmVmaW5pc2gnKTtcbiAgICB9XG4gIH1cbn1cblxuZnVuY3Rpb24gZmluaXNoTWF5YmUoc3RyZWFtLCBzdGF0ZSkge1xuICB2YXIgbmVlZCA9IG5lZWRGaW5pc2goc3RhdGUpO1xuXG4gIGlmIChuZWVkKSB7XG4gICAgcHJlZmluaXNoKHN0cmVhbSwgc3RhdGUpO1xuXG4gICAgaWYgKHN0YXRlLnBlbmRpbmdjYiA9PT0gMCkge1xuICAgICAgc3RhdGUuZmluaXNoZWQgPSB0cnVlO1xuICAgICAgc3RyZWFtLmVtaXQoJ2ZpbmlzaCcpO1xuXG4gICAgICBpZiAoc3RhdGUuYXV0b0Rlc3Ryb3kpIHtcbiAgICAgICAgLy8gSW4gY2FzZSBvZiBkdXBsZXggc3RyZWFtcyB3ZSBuZWVkIGEgd2F5IHRvIGRldGVjdFxuICAgICAgICAvLyBpZiB0aGUgcmVhZGFibGUgc2lkZSBpcyByZWFkeSBmb3IgYXV0b0Rlc3Ryb3kgYXMgd2VsbFxuICAgICAgICB2YXIgclN0YXRlID0gc3RyZWFtLl9yZWFkYWJsZVN0YXRlO1xuXG4gICAgICAgIGlmICghclN0YXRlIHx8IHJTdGF0ZS5hdXRvRGVzdHJveSAmJiByU3RhdGUuZW5kRW1pdHRlZCkge1xuICAgICAgICAgIHN0cmVhbS5kZXN0cm95KCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICByZXR1cm4gbmVlZDtcbn1cblxuZnVuY3Rpb24gZW5kV3JpdGFibGUoc3RyZWFtLCBzdGF0ZSwgY2IpIHtcbiAgc3RhdGUuZW5kaW5nID0gdHJ1ZTtcbiAgZmluaXNoTWF5YmUoc3RyZWFtLCBzdGF0ZSk7XG5cbiAgaWYgKGNiKSB7XG4gICAgaWYgKHN0YXRlLmZpbmlzaGVkKSBwcm9jZXNzLm5leHRUaWNrKGNiKTtlbHNlIHN0cmVhbS5vbmNlKCdmaW5pc2gnLCBjYik7XG4gIH1cblxuICBzdGF0ZS5lbmRlZCA9IHRydWU7XG4gIHN0cmVhbS53cml0YWJsZSA9IGZhbHNlO1xufVxuXG5mdW5jdGlvbiBvbkNvcmtlZEZpbmlzaChjb3JrUmVxLCBzdGF0ZSwgZXJyKSB7XG4gIHZhciBlbnRyeSA9IGNvcmtSZXEuZW50cnk7XG4gIGNvcmtSZXEuZW50cnkgPSBudWxsO1xuXG4gIHdoaWxlIChlbnRyeSkge1xuICAgIHZhciBjYiA9IGVudHJ5LmNhbGxiYWNrO1xuICAgIHN0YXRlLnBlbmRpbmdjYi0tO1xuICAgIGNiKGVycik7XG4gICAgZW50cnkgPSBlbnRyeS5uZXh0O1xuICB9IC8vIHJldXNlIHRoZSBmcmVlIGNvcmtSZXEuXG5cblxuICBzdGF0ZS5jb3JrZWRSZXF1ZXN0c0ZyZWUubmV4dCA9IGNvcmtSZXE7XG59XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShXcml0YWJsZS5wcm90b3R5cGUsICdkZXN0cm95ZWQnLCB7XG4gIC8vIG1ha2luZyBpdCBleHBsaWNpdCB0aGlzIHByb3BlcnR5IGlzIG5vdCBlbnVtZXJhYmxlXG4gIC8vIGJlY2F1c2Ugb3RoZXJ3aXNlIHNvbWUgcHJvdG90eXBlIG1hbmlwdWxhdGlvbiBpblxuICAvLyB1c2VybGFuZCB3aWxsIGZhaWxcbiAgZW51bWVyYWJsZTogZmFsc2UsXG4gIGdldDogZnVuY3Rpb24gZ2V0KCkge1xuICAgIGlmICh0aGlzLl93cml0YWJsZVN0YXRlID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcy5fd3JpdGFibGVTdGF0ZS5kZXN0cm95ZWQ7XG4gIH0sXG4gIHNldDogZnVuY3Rpb24gc2V0KHZhbHVlKSB7XG4gICAgLy8gd2UgaWdub3JlIHRoZSB2YWx1ZSBpZiB0aGUgc3RyZWFtXG4gICAgLy8gaGFzIG5vdCBiZWVuIGluaXRpYWxpemVkIHlldFxuICAgIGlmICghdGhpcy5fd3JpdGFibGVTdGF0ZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH0gLy8gYmFja3dhcmQgY29tcGF0aWJpbGl0eSwgdGhlIHVzZXIgaXMgZXhwbGljaXRseVxuICAgIC8vIG1hbmFnaW5nIGRlc3Ryb3llZFxuXG5cbiAgICB0aGlzLl93cml0YWJsZVN0YXRlLmRlc3Ryb3llZCA9IHZhbHVlO1xuICB9XG59KTtcbldyaXRhYmxlLnByb3RvdHlwZS5kZXN0cm95ID0gZGVzdHJveUltcGwuZGVzdHJveTtcbldyaXRhYmxlLnByb3RvdHlwZS5fdW5kZXN0cm95ID0gZGVzdHJveUltcGwudW5kZXN0cm95O1xuXG5Xcml0YWJsZS5wcm90b3R5cGUuX2Rlc3Ryb3kgPSBmdW5jdGlvbiAoZXJyLCBjYikge1xuICBjYihlcnIpO1xufTsiLCIndXNlIHN0cmljdCc7XG5cbnZhciBfT2JqZWN0JHNldFByb3RvdHlwZU87XG5cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShvYmosIGtleSwgdmFsdWUpIHsgaWYgKGtleSBpbiBvYmopIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KG9iaiwga2V5LCB7IHZhbHVlOiB2YWx1ZSwgZW51bWVyYWJsZTogdHJ1ZSwgY29uZmlndXJhYmxlOiB0cnVlLCB3cml0YWJsZTogdHJ1ZSB9KTsgfSBlbHNlIHsgb2JqW2tleV0gPSB2YWx1ZTsgfSByZXR1cm4gb2JqOyB9XG5cbnZhciBmaW5pc2hlZCA9IHJlcXVpcmUoJy4vZW5kLW9mLXN0cmVhbScpO1xuXG52YXIga0xhc3RSZXNvbHZlID0gU3ltYm9sKCdsYXN0UmVzb2x2ZScpO1xudmFyIGtMYXN0UmVqZWN0ID0gU3ltYm9sKCdsYXN0UmVqZWN0Jyk7XG52YXIga0Vycm9yID0gU3ltYm9sKCdlcnJvcicpO1xudmFyIGtFbmRlZCA9IFN5bWJvbCgnZW5kZWQnKTtcbnZhciBrTGFzdFByb21pc2UgPSBTeW1ib2woJ2xhc3RQcm9taXNlJyk7XG52YXIga0hhbmRsZVByb21pc2UgPSBTeW1ib2woJ2hhbmRsZVByb21pc2UnKTtcbnZhciBrU3RyZWFtID0gU3ltYm9sKCdzdHJlYW0nKTtcblxuZnVuY3Rpb24gY3JlYXRlSXRlclJlc3VsdCh2YWx1ZSwgZG9uZSkge1xuICByZXR1cm4ge1xuICAgIHZhbHVlOiB2YWx1ZSxcbiAgICBkb25lOiBkb25lXG4gIH07XG59XG5cbmZ1bmN0aW9uIHJlYWRBbmRSZXNvbHZlKGl0ZXIpIHtcbiAgdmFyIHJlc29sdmUgPSBpdGVyW2tMYXN0UmVzb2x2ZV07XG5cbiAgaWYgKHJlc29sdmUgIT09IG51bGwpIHtcbiAgICB2YXIgZGF0YSA9IGl0ZXJba1N0cmVhbV0ucmVhZCgpOyAvLyB3ZSBkZWZlciBpZiBkYXRhIGlzIG51bGxcbiAgICAvLyB3ZSBjYW4gYmUgZXhwZWN0aW5nIGVpdGhlciAnZW5kJyBvclxuICAgIC8vICdlcnJvcidcblxuICAgIGlmIChkYXRhICE9PSBudWxsKSB7XG4gICAgICBpdGVyW2tMYXN0UHJvbWlzZV0gPSBudWxsO1xuICAgICAgaXRlcltrTGFzdFJlc29sdmVdID0gbnVsbDtcbiAgICAgIGl0ZXJba0xhc3RSZWplY3RdID0gbnVsbDtcbiAgICAgIHJlc29sdmUoY3JlYXRlSXRlclJlc3VsdChkYXRhLCBmYWxzZSkpO1xuICAgIH1cbiAgfVxufVxuXG5mdW5jdGlvbiBvblJlYWRhYmxlKGl0ZXIpIHtcbiAgLy8gd2Ugd2FpdCBmb3IgdGhlIG5leHQgdGljaywgYmVjYXVzZSBpdCBtaWdodFxuICAvLyBlbWl0IGFuIGVycm9yIHdpdGggcHJvY2Vzcy5uZXh0VGlja1xuICBwcm9jZXNzLm5leHRUaWNrKHJlYWRBbmRSZXNvbHZlLCBpdGVyKTtcbn1cblxuZnVuY3Rpb24gd3JhcEZvck5leHQobGFzdFByb21pc2UsIGl0ZXIpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICBsYXN0UHJvbWlzZS50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgIGlmIChpdGVyW2tFbmRlZF0pIHtcbiAgICAgICAgcmVzb2x2ZShjcmVhdGVJdGVyUmVzdWx0KHVuZGVmaW5lZCwgdHJ1ZSkpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIGl0ZXJba0hhbmRsZVByb21pc2VdKHJlc29sdmUsIHJlamVjdCk7XG4gICAgfSwgcmVqZWN0KTtcbiAgfTtcbn1cblxudmFyIEFzeW5jSXRlcmF0b3JQcm90b3R5cGUgPSBPYmplY3QuZ2V0UHJvdG90eXBlT2YoZnVuY3Rpb24gKCkge30pO1xudmFyIFJlYWRhYmxlU3RyZWFtQXN5bmNJdGVyYXRvclByb3RvdHlwZSA9IE9iamVjdC5zZXRQcm90b3R5cGVPZigoX09iamVjdCRzZXRQcm90b3R5cGVPID0ge1xuICBnZXQgc3RyZWFtKCkge1xuICAgIHJldHVybiB0aGlzW2tTdHJlYW1dO1xuICB9LFxuXG4gIG5leHQ6IGZ1bmN0aW9uIG5leHQoKSB7XG4gICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgIC8vIGlmIHdlIGhhdmUgZGV0ZWN0ZWQgYW4gZXJyb3IgaW4gdGhlIG1lYW53aGlsZVxuICAgIC8vIHJlamVjdCBzdHJhaWdodCBhd2F5XG4gICAgdmFyIGVycm9yID0gdGhpc1trRXJyb3JdO1xuXG4gICAgaWYgKGVycm9yICE9PSBudWxsKSB7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuICAgIH1cblxuICAgIGlmICh0aGlzW2tFbmRlZF0pIHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoY3JlYXRlSXRlclJlc3VsdCh1bmRlZmluZWQsIHRydWUpKTtcbiAgICB9XG5cbiAgICBpZiAodGhpc1trU3RyZWFtXS5kZXN0cm95ZWQpIHtcbiAgICAgIC8vIFdlIG5lZWQgdG8gZGVmZXIgdmlhIG5leHRUaWNrIGJlY2F1c2UgaWYgLmRlc3Ryb3koZXJyKSBpc1xuICAgICAgLy8gY2FsbGVkLCB0aGUgZXJyb3Igd2lsbCBiZSBlbWl0dGVkIHZpYSBuZXh0VGljaywgYW5kXG4gICAgICAvLyB3ZSBjYW5ub3QgZ3VhcmFudGVlIHRoYXQgdGhlcmUgaXMgbm8gZXJyb3IgbGluZ2VyaW5nIGFyb3VuZFxuICAgICAgLy8gd2FpdGluZyB0byBiZSBlbWl0dGVkLlxuICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgcHJvY2Vzcy5uZXh0VGljayhmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgaWYgKF90aGlzW2tFcnJvcl0pIHtcbiAgICAgICAgICAgIHJlamVjdChfdGhpc1trRXJyb3JdKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmVzb2x2ZShjcmVhdGVJdGVyUmVzdWx0KHVuZGVmaW5lZCwgdHJ1ZSkpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9IC8vIGlmIHdlIGhhdmUgbXVsdGlwbGUgbmV4dCgpIGNhbGxzXG4gICAgLy8gd2Ugd2lsbCB3YWl0IGZvciB0aGUgcHJldmlvdXMgUHJvbWlzZSB0byBmaW5pc2hcbiAgICAvLyB0aGlzIGxvZ2ljIGlzIG9wdGltaXplZCB0byBzdXBwb3J0IGZvciBhd2FpdCBsb29wcyxcbiAgICAvLyB3aGVyZSBuZXh0KCkgaXMgb25seSBjYWxsZWQgb25jZSBhdCBhIHRpbWVcblxuXG4gICAgdmFyIGxhc3RQcm9taXNlID0gdGhpc1trTGFzdFByb21pc2VdO1xuICAgIHZhciBwcm9taXNlO1xuXG4gICAgaWYgKGxhc3RQcm9taXNlKSB7XG4gICAgICBwcm9taXNlID0gbmV3IFByb21pc2Uod3JhcEZvck5leHQobGFzdFByb21pc2UsIHRoaXMpKTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gZmFzdCBwYXRoIG5lZWRlZCB0byBzdXBwb3J0IG11bHRpcGxlIHRoaXMucHVzaCgpXG4gICAgICAvLyB3aXRob3V0IHRyaWdnZXJpbmcgdGhlIG5leHQoKSBxdWV1ZVxuICAgICAgdmFyIGRhdGEgPSB0aGlzW2tTdHJlYW1dLnJlYWQoKTtcblxuICAgICAgaWYgKGRhdGEgIT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShjcmVhdGVJdGVyUmVzdWx0KGRhdGEsIGZhbHNlKSk7XG4gICAgICB9XG5cbiAgICAgIHByb21pc2UgPSBuZXcgUHJvbWlzZSh0aGlzW2tIYW5kbGVQcm9taXNlXSk7XG4gICAgfVxuXG4gICAgdGhpc1trTGFzdFByb21pc2VdID0gcHJvbWlzZTtcbiAgICByZXR1cm4gcHJvbWlzZTtcbiAgfVxufSwgX2RlZmluZVByb3BlcnR5KF9PYmplY3Qkc2V0UHJvdG90eXBlTywgU3ltYm9sLmFzeW5jSXRlcmF0b3IsIGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIHRoaXM7XG59KSwgX2RlZmluZVByb3BlcnR5KF9PYmplY3Qkc2V0UHJvdG90eXBlTywgXCJyZXR1cm5cIiwgZnVuY3Rpb24gX3JldHVybigpIHtcbiAgdmFyIF90aGlzMiA9IHRoaXM7XG5cbiAgLy8gZGVzdHJveShlcnIsIGNiKSBpcyBhIHByaXZhdGUgQVBJXG4gIC8vIHdlIGNhbiBndWFyYW50ZWUgd2UgaGF2ZSB0aGF0IGhlcmUsIGJlY2F1c2Ugd2UgY29udHJvbCB0aGVcbiAgLy8gUmVhZGFibGUgY2xhc3MgdGhpcyBpcyBhdHRhY2hlZCB0b1xuICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgIF90aGlzMltrU3RyZWFtXS5kZXN0cm95KG51bGwsIGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgcmVzb2x2ZShjcmVhdGVJdGVyUmVzdWx0KHVuZGVmaW5lZCwgdHJ1ZSkpO1xuICAgIH0pO1xuICB9KTtcbn0pLCBfT2JqZWN0JHNldFByb3RvdHlwZU8pLCBBc3luY0l0ZXJhdG9yUHJvdG90eXBlKTtcblxudmFyIGNyZWF0ZVJlYWRhYmxlU3RyZWFtQXN5bmNJdGVyYXRvciA9IGZ1bmN0aW9uIGNyZWF0ZVJlYWRhYmxlU3RyZWFtQXN5bmNJdGVyYXRvcihzdHJlYW0pIHtcbiAgdmFyIF9PYmplY3QkY3JlYXRlO1xuXG4gIHZhciBpdGVyYXRvciA9IE9iamVjdC5jcmVhdGUoUmVhZGFibGVTdHJlYW1Bc3luY0l0ZXJhdG9yUHJvdG90eXBlLCAoX09iamVjdCRjcmVhdGUgPSB7fSwgX2RlZmluZVByb3BlcnR5KF9PYmplY3QkY3JlYXRlLCBrU3RyZWFtLCB7XG4gICAgdmFsdWU6IHN0cmVhbSxcbiAgICB3cml0YWJsZTogdHJ1ZVxuICB9KSwgX2RlZmluZVByb3BlcnR5KF9PYmplY3QkY3JlYXRlLCBrTGFzdFJlc29sdmUsIHtcbiAgICB2YWx1ZTogbnVsbCxcbiAgICB3cml0YWJsZTogdHJ1ZVxuICB9KSwgX2RlZmluZVByb3BlcnR5KF9PYmplY3QkY3JlYXRlLCBrTGFzdFJlamVjdCwge1xuICAgIHZhbHVlOiBudWxsLFxuICAgIHdyaXRhYmxlOiB0cnVlXG4gIH0pLCBfZGVmaW5lUHJvcGVydHkoX09iamVjdCRjcmVhdGUsIGtFcnJvciwge1xuICAgIHZhbHVlOiBudWxsLFxuICAgIHdyaXRhYmxlOiB0cnVlXG4gIH0pLCBfZGVmaW5lUHJvcGVydHkoX09iamVjdCRjcmVhdGUsIGtFbmRlZCwge1xuICAgIHZhbHVlOiBzdHJlYW0uX3JlYWRhYmxlU3RhdGUuZW5kRW1pdHRlZCxcbiAgICB3cml0YWJsZTogdHJ1ZVxuICB9KSwgX2RlZmluZVByb3BlcnR5KF9PYmplY3QkY3JlYXRlLCBrSGFuZGxlUHJvbWlzZSwge1xuICAgIHZhbHVlOiBmdW5jdGlvbiB2YWx1ZShyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgIHZhciBkYXRhID0gaXRlcmF0b3Jba1N0cmVhbV0ucmVhZCgpO1xuXG4gICAgICBpZiAoZGF0YSkge1xuICAgICAgICBpdGVyYXRvcltrTGFzdFByb21pc2VdID0gbnVsbDtcbiAgICAgICAgaXRlcmF0b3Jba0xhc3RSZXNvbHZlXSA9IG51bGw7XG4gICAgICAgIGl0ZXJhdG9yW2tMYXN0UmVqZWN0XSA9IG51bGw7XG4gICAgICAgIHJlc29sdmUoY3JlYXRlSXRlclJlc3VsdChkYXRhLCBmYWxzZSkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaXRlcmF0b3Jba0xhc3RSZXNvbHZlXSA9IHJlc29sdmU7XG4gICAgICAgIGl0ZXJhdG9yW2tMYXN0UmVqZWN0XSA9IHJlamVjdDtcbiAgICAgIH1cbiAgICB9LFxuICAgIHdyaXRhYmxlOiB0cnVlXG4gIH0pLCBfT2JqZWN0JGNyZWF0ZSkpO1xuICBpdGVyYXRvcltrTGFzdFByb21pc2VdID0gbnVsbDtcbiAgZmluaXNoZWQoc3RyZWFtLCBmdW5jdGlvbiAoZXJyKSB7XG4gICAgaWYgKGVyciAmJiBlcnIuY29kZSAhPT0gJ0VSUl9TVFJFQU1fUFJFTUFUVVJFX0NMT1NFJykge1xuICAgICAgdmFyIHJlamVjdCA9IGl0ZXJhdG9yW2tMYXN0UmVqZWN0XTsgLy8gcmVqZWN0IGlmIHdlIGFyZSB3YWl0aW5nIGZvciBkYXRhIGluIHRoZSBQcm9taXNlXG4gICAgICAvLyByZXR1cm5lZCBieSBuZXh0KCkgYW5kIHN0b3JlIHRoZSBlcnJvclxuXG4gICAgICBpZiAocmVqZWN0ICE9PSBudWxsKSB7XG4gICAgICAgIGl0ZXJhdG9yW2tMYXN0UHJvbWlzZV0gPSBudWxsO1xuICAgICAgICBpdGVyYXRvcltrTGFzdFJlc29sdmVdID0gbnVsbDtcbiAgICAgICAgaXRlcmF0b3Jba0xhc3RSZWplY3RdID0gbnVsbDtcbiAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICB9XG5cbiAgICAgIGl0ZXJhdG9yW2tFcnJvcl0gPSBlcnI7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdmFyIHJlc29sdmUgPSBpdGVyYXRvcltrTGFzdFJlc29sdmVdO1xuXG4gICAgaWYgKHJlc29sdmUgIT09IG51bGwpIHtcbiAgICAgIGl0ZXJhdG9yW2tMYXN0UHJvbWlzZV0gPSBudWxsO1xuICAgICAgaXRlcmF0b3Jba0xhc3RSZXNvbHZlXSA9IG51bGw7XG4gICAgICBpdGVyYXRvcltrTGFzdFJlamVjdF0gPSBudWxsO1xuICAgICAgcmVzb2x2ZShjcmVhdGVJdGVyUmVzdWx0KHVuZGVmaW5lZCwgdHJ1ZSkpO1xuICAgIH1cblxuICAgIGl0ZXJhdG9yW2tFbmRlZF0gPSB0cnVlO1xuICB9KTtcbiAgc3RyZWFtLm9uKCdyZWFkYWJsZScsIG9uUmVhZGFibGUuYmluZChudWxsLCBpdGVyYXRvcikpO1xuICByZXR1cm4gaXRlcmF0b3I7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IGNyZWF0ZVJlYWRhYmxlU3RyZWFtQXN5bmNJdGVyYXRvcjsiLCIndXNlIHN0cmljdCc7XG5cbmZ1bmN0aW9uIG93bktleXMob2JqZWN0LCBlbnVtZXJhYmxlT25seSkgeyB2YXIga2V5cyA9IE9iamVjdC5rZXlzKG9iamVjdCk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBzeW1ib2xzID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhvYmplY3QpOyBpZiAoZW51bWVyYWJsZU9ubHkpIHN5bWJvbHMgPSBzeW1ib2xzLmZpbHRlcihmdW5jdGlvbiAoc3ltKSB7IHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG9iamVjdCwgc3ltKS5lbnVtZXJhYmxlOyB9KTsga2V5cy5wdXNoLmFwcGx5KGtleXMsIHN5bWJvbHMpOyB9IHJldHVybiBrZXlzOyB9XG5cbmZ1bmN0aW9uIF9vYmplY3RTcHJlYWQodGFyZ2V0KSB7IGZvciAodmFyIGkgPSAxOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKSB7IHZhciBzb3VyY2UgPSBhcmd1bWVudHNbaV0gIT0gbnVsbCA/IGFyZ3VtZW50c1tpXSA6IHt9OyBpZiAoaSAlIDIpIHsgb3duS2V5cyhPYmplY3Qoc291cmNlKSwgdHJ1ZSkuZm9yRWFjaChmdW5jdGlvbiAoa2V5KSB7IF9kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGtleSwgc291cmNlW2tleV0pOyB9KTsgfSBlbHNlIGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycykgeyBPYmplY3QuZGVmaW5lUHJvcGVydGllcyh0YXJnZXQsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHNvdXJjZSkpOyB9IGVsc2UgeyBvd25LZXlzKE9iamVjdChzb3VyY2UpKS5mb3JFYWNoKGZ1bmN0aW9uIChrZXkpIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwga2V5LCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHNvdXJjZSwga2V5KSk7IH0pOyB9IH0gcmV0dXJuIHRhcmdldDsgfVxuXG5mdW5jdGlvbiBfZGVmaW5lUHJvcGVydHkob2JqLCBrZXksIHZhbHVlKSB7IGlmIChrZXkgaW4gb2JqKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmosIGtleSwgeyB2YWx1ZTogdmFsdWUsIGVudW1lcmFibGU6IHRydWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSwgd3JpdGFibGU6IHRydWUgfSk7IH0gZWxzZSB7IG9ialtrZXldID0gdmFsdWU7IH0gcmV0dXJuIG9iajsgfVxuXG5mdW5jdGlvbiBfY2xhc3NDYWxsQ2hlY2soaW5zdGFuY2UsIENvbnN0cnVjdG9yKSB7IGlmICghKGluc3RhbmNlIGluc3RhbmNlb2YgQ29uc3RydWN0b3IpKSB7IHRocm93IG5ldyBUeXBlRXJyb3IoXCJDYW5ub3QgY2FsbCBhIGNsYXNzIGFzIGEgZnVuY3Rpb25cIik7IH0gfVxuXG5mdW5jdGlvbiBfZGVmaW5lUHJvcGVydGllcyh0YXJnZXQsIHByb3BzKSB7IGZvciAodmFyIGkgPSAwOyBpIDwgcHJvcHMubGVuZ3RoOyBpKyspIHsgdmFyIGRlc2NyaXB0b3IgPSBwcm9wc1tpXTsgZGVzY3JpcHRvci5lbnVtZXJhYmxlID0gZGVzY3JpcHRvci5lbnVtZXJhYmxlIHx8IGZhbHNlOyBkZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZSA9IHRydWU7IGlmIChcInZhbHVlXCIgaW4gZGVzY3JpcHRvcikgZGVzY3JpcHRvci53cml0YWJsZSA9IHRydWU7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGRlc2NyaXB0b3Iua2V5LCBkZXNjcmlwdG9yKTsgfSB9XG5cbmZ1bmN0aW9uIF9jcmVhdGVDbGFzcyhDb25zdHJ1Y3RvciwgcHJvdG9Qcm9wcywgc3RhdGljUHJvcHMpIHsgaWYgKHByb3RvUHJvcHMpIF9kZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLnByb3RvdHlwZSwgcHJvdG9Qcm9wcyk7IGlmIChzdGF0aWNQcm9wcykgX2RlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IsIHN0YXRpY1Byb3BzKTsgcmV0dXJuIENvbnN0cnVjdG9yOyB9XG5cbnZhciBfcmVxdWlyZSA9IHJlcXVpcmUoJ2J1ZmZlcicpLFxuICAgIEJ1ZmZlciA9IF9yZXF1aXJlLkJ1ZmZlcjtcblxudmFyIF9yZXF1aXJlMiA9IHJlcXVpcmUoJ3V0aWwnKSxcbiAgICBpbnNwZWN0ID0gX3JlcXVpcmUyLmluc3BlY3Q7XG5cbnZhciBjdXN0b20gPSBpbnNwZWN0ICYmIGluc3BlY3QuY3VzdG9tIHx8ICdpbnNwZWN0JztcblxuZnVuY3Rpb24gY29weUJ1ZmZlcihzcmMsIHRhcmdldCwgb2Zmc2V0KSB7XG4gIEJ1ZmZlci5wcm90b3R5cGUuY29weS5jYWxsKHNyYywgdGFyZ2V0LCBvZmZzZXQpO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9XG4vKiNfX1BVUkVfXyovXG5mdW5jdGlvbiAoKSB7XG4gIGZ1bmN0aW9uIEJ1ZmZlckxpc3QoKSB7XG4gICAgX2NsYXNzQ2FsbENoZWNrKHRoaXMsIEJ1ZmZlckxpc3QpO1xuXG4gICAgdGhpcy5oZWFkID0gbnVsbDtcbiAgICB0aGlzLnRhaWwgPSBudWxsO1xuICAgIHRoaXMubGVuZ3RoID0gMDtcbiAgfVxuXG4gIF9jcmVhdGVDbGFzcyhCdWZmZXJMaXN0LCBbe1xuICAgIGtleTogXCJwdXNoXCIsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHB1c2godikge1xuICAgICAgdmFyIGVudHJ5ID0ge1xuICAgICAgICBkYXRhOiB2LFxuICAgICAgICBuZXh0OiBudWxsXG4gICAgICB9O1xuICAgICAgaWYgKHRoaXMubGVuZ3RoID4gMCkgdGhpcy50YWlsLm5leHQgPSBlbnRyeTtlbHNlIHRoaXMuaGVhZCA9IGVudHJ5O1xuICAgICAgdGhpcy50YWlsID0gZW50cnk7XG4gICAgICArK3RoaXMubGVuZ3RoO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogXCJ1bnNoaWZ0XCIsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHVuc2hpZnQodikge1xuICAgICAgdmFyIGVudHJ5ID0ge1xuICAgICAgICBkYXRhOiB2LFxuICAgICAgICBuZXh0OiB0aGlzLmhlYWRcbiAgICAgIH07XG4gICAgICBpZiAodGhpcy5sZW5ndGggPT09IDApIHRoaXMudGFpbCA9IGVudHJ5O1xuICAgICAgdGhpcy5oZWFkID0gZW50cnk7XG4gICAgICArK3RoaXMubGVuZ3RoO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogXCJzaGlmdFwiLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBzaGlmdCgpIHtcbiAgICAgIGlmICh0aGlzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICAgICAgdmFyIHJldCA9IHRoaXMuaGVhZC5kYXRhO1xuICAgICAgaWYgKHRoaXMubGVuZ3RoID09PSAxKSB0aGlzLmhlYWQgPSB0aGlzLnRhaWwgPSBudWxsO2Vsc2UgdGhpcy5oZWFkID0gdGhpcy5oZWFkLm5leHQ7XG4gICAgICAtLXRoaXMubGVuZ3RoO1xuICAgICAgcmV0dXJuIHJldDtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6IFwiY2xlYXJcIixcbiAgICB2YWx1ZTogZnVuY3Rpb24gY2xlYXIoKSB7XG4gICAgICB0aGlzLmhlYWQgPSB0aGlzLnRhaWwgPSBudWxsO1xuICAgICAgdGhpcy5sZW5ndGggPSAwO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogXCJqb2luXCIsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGpvaW4ocykge1xuICAgICAgaWYgKHRoaXMubGVuZ3RoID09PSAwKSByZXR1cm4gJyc7XG4gICAgICB2YXIgcCA9IHRoaXMuaGVhZDtcbiAgICAgIHZhciByZXQgPSAnJyArIHAuZGF0YTtcblxuICAgICAgd2hpbGUgKHAgPSBwLm5leHQpIHtcbiAgICAgICAgcmV0ICs9IHMgKyBwLmRhdGE7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiByZXQ7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiBcImNvbmNhdFwiLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBjb25jYXQobikge1xuICAgICAgaWYgKHRoaXMubGVuZ3RoID09PSAwKSByZXR1cm4gQnVmZmVyLmFsbG9jKDApO1xuICAgICAgdmFyIHJldCA9IEJ1ZmZlci5hbGxvY1Vuc2FmZShuID4+PiAwKTtcbiAgICAgIHZhciBwID0gdGhpcy5oZWFkO1xuICAgICAgdmFyIGkgPSAwO1xuXG4gICAgICB3aGlsZSAocCkge1xuICAgICAgICBjb3B5QnVmZmVyKHAuZGF0YSwgcmV0LCBpKTtcbiAgICAgICAgaSArPSBwLmRhdGEubGVuZ3RoO1xuICAgICAgICBwID0gcC5uZXh0O1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gcmV0O1xuICAgIH0gLy8gQ29uc3VtZXMgYSBzcGVjaWZpZWQgYW1vdW50IG9mIGJ5dGVzIG9yIGNoYXJhY3RlcnMgZnJvbSB0aGUgYnVmZmVyZWQgZGF0YS5cblxuICB9LCB7XG4gICAga2V5OiBcImNvbnN1bWVcIixcbiAgICB2YWx1ZTogZnVuY3Rpb24gY29uc3VtZShuLCBoYXNTdHJpbmdzKSB7XG4gICAgICB2YXIgcmV0O1xuXG4gICAgICBpZiAobiA8IHRoaXMuaGVhZC5kYXRhLmxlbmd0aCkge1xuICAgICAgICAvLyBgc2xpY2VgIGlzIHRoZSBzYW1lIGZvciBidWZmZXJzIGFuZCBzdHJpbmdzLlxuICAgICAgICByZXQgPSB0aGlzLmhlYWQuZGF0YS5zbGljZSgwLCBuKTtcbiAgICAgICAgdGhpcy5oZWFkLmRhdGEgPSB0aGlzLmhlYWQuZGF0YS5zbGljZShuKTtcbiAgICAgIH0gZWxzZSBpZiAobiA9PT0gdGhpcy5oZWFkLmRhdGEubGVuZ3RoKSB7XG4gICAgICAgIC8vIEZpcnN0IGNodW5rIGlzIGEgcGVyZmVjdCBtYXRjaC5cbiAgICAgICAgcmV0ID0gdGhpcy5zaGlmdCgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gUmVzdWx0IHNwYW5zIG1vcmUgdGhhbiBvbmUgYnVmZmVyLlxuICAgICAgICByZXQgPSBoYXNTdHJpbmdzID8gdGhpcy5fZ2V0U3RyaW5nKG4pIDogdGhpcy5fZ2V0QnVmZmVyKG4pO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gcmV0O1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogXCJmaXJzdFwiLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBmaXJzdCgpIHtcbiAgICAgIHJldHVybiB0aGlzLmhlYWQuZGF0YTtcbiAgICB9IC8vIENvbnN1bWVzIGEgc3BlY2lmaWVkIGFtb3VudCBvZiBjaGFyYWN0ZXJzIGZyb20gdGhlIGJ1ZmZlcmVkIGRhdGEuXG5cbiAgfSwge1xuICAgIGtleTogXCJfZ2V0U3RyaW5nXCIsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIF9nZXRTdHJpbmcobikge1xuICAgICAgdmFyIHAgPSB0aGlzLmhlYWQ7XG4gICAgICB2YXIgYyA9IDE7XG4gICAgICB2YXIgcmV0ID0gcC5kYXRhO1xuICAgICAgbiAtPSByZXQubGVuZ3RoO1xuXG4gICAgICB3aGlsZSAocCA9IHAubmV4dCkge1xuICAgICAgICB2YXIgc3RyID0gcC5kYXRhO1xuICAgICAgICB2YXIgbmIgPSBuID4gc3RyLmxlbmd0aCA/IHN0ci5sZW5ndGggOiBuO1xuICAgICAgICBpZiAobmIgPT09IHN0ci5sZW5ndGgpIHJldCArPSBzdHI7ZWxzZSByZXQgKz0gc3RyLnNsaWNlKDAsIG4pO1xuICAgICAgICBuIC09IG5iO1xuXG4gICAgICAgIGlmIChuID09PSAwKSB7XG4gICAgICAgICAgaWYgKG5iID09PSBzdHIubGVuZ3RoKSB7XG4gICAgICAgICAgICArK2M7XG4gICAgICAgICAgICBpZiAocC5uZXh0KSB0aGlzLmhlYWQgPSBwLm5leHQ7ZWxzZSB0aGlzLmhlYWQgPSB0aGlzLnRhaWwgPSBudWxsO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmhlYWQgPSBwO1xuICAgICAgICAgICAgcC5kYXRhID0gc3RyLnNsaWNlKG5iKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuXG4gICAgICAgICsrYztcbiAgICAgIH1cblxuICAgICAgdGhpcy5sZW5ndGggLT0gYztcbiAgICAgIHJldHVybiByZXQ7XG4gICAgfSAvLyBDb25zdW1lcyBhIHNwZWNpZmllZCBhbW91bnQgb2YgYnl0ZXMgZnJvbSB0aGUgYnVmZmVyZWQgZGF0YS5cblxuICB9LCB7XG4gICAga2V5OiBcIl9nZXRCdWZmZXJcIixcbiAgICB2YWx1ZTogZnVuY3Rpb24gX2dldEJ1ZmZlcihuKSB7XG4gICAgICB2YXIgcmV0ID0gQnVmZmVyLmFsbG9jVW5zYWZlKG4pO1xuICAgICAgdmFyIHAgPSB0aGlzLmhlYWQ7XG4gICAgICB2YXIgYyA9IDE7XG4gICAgICBwLmRhdGEuY29weShyZXQpO1xuICAgICAgbiAtPSBwLmRhdGEubGVuZ3RoO1xuXG4gICAgICB3aGlsZSAocCA9IHAubmV4dCkge1xuICAgICAgICB2YXIgYnVmID0gcC5kYXRhO1xuICAgICAgICB2YXIgbmIgPSBuID4gYnVmLmxlbmd0aCA/IGJ1Zi5sZW5ndGggOiBuO1xuICAgICAgICBidWYuY29weShyZXQsIHJldC5sZW5ndGggLSBuLCAwLCBuYik7XG4gICAgICAgIG4gLT0gbmI7XG5cbiAgICAgICAgaWYgKG4gPT09IDApIHtcbiAgICAgICAgICBpZiAobmIgPT09IGJ1Zi5sZW5ndGgpIHtcbiAgICAgICAgICAgICsrYztcbiAgICAgICAgICAgIGlmIChwLm5leHQpIHRoaXMuaGVhZCA9IHAubmV4dDtlbHNlIHRoaXMuaGVhZCA9IHRoaXMudGFpbCA9IG51bGw7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuaGVhZCA9IHA7XG4gICAgICAgICAgICBwLmRhdGEgPSBidWYuc2xpY2UobmIpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG5cbiAgICAgICAgKytjO1xuICAgICAgfVxuXG4gICAgICB0aGlzLmxlbmd0aCAtPSBjO1xuICAgICAgcmV0dXJuIHJldDtcbiAgICB9IC8vIE1ha2Ugc3VyZSB0aGUgbGlua2VkIGxpc3Qgb25seSBzaG93cyB0aGUgbWluaW1hbCBuZWNlc3NhcnkgaW5mb3JtYXRpb24uXG5cbiAgfSwge1xuICAgIGtleTogY3VzdG9tLFxuICAgIHZhbHVlOiBmdW5jdGlvbiB2YWx1ZShfLCBvcHRpb25zKSB7XG4gICAgICByZXR1cm4gaW5zcGVjdCh0aGlzLCBfb2JqZWN0U3ByZWFkKHt9LCBvcHRpb25zLCB7XG4gICAgICAgIC8vIE9ubHkgaW5zcGVjdCBvbmUgbGV2ZWwuXG4gICAgICAgIGRlcHRoOiAwLFxuICAgICAgICAvLyBJdCBzaG91bGQgbm90IHJlY3Vyc2UuXG4gICAgICAgIGN1c3RvbUluc3BlY3Q6IGZhbHNlXG4gICAgICB9KSk7XG4gICAgfVxuICB9XSk7XG5cbiAgcmV0dXJuIEJ1ZmZlckxpc3Q7XG59KCk7IiwiJ3VzZSBzdHJpY3QnOyAvLyB1bmRvY3VtZW50ZWQgY2IoKSBBUEksIG5lZWRlZCBmb3IgY29yZSwgbm90IGZvciBwdWJsaWMgQVBJXG5cbmZ1bmN0aW9uIGRlc3Ryb3koZXJyLCBjYikge1xuICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gIHZhciByZWFkYWJsZURlc3Ryb3llZCA9IHRoaXMuX3JlYWRhYmxlU3RhdGUgJiYgdGhpcy5fcmVhZGFibGVTdGF0ZS5kZXN0cm95ZWQ7XG4gIHZhciB3cml0YWJsZURlc3Ryb3llZCA9IHRoaXMuX3dyaXRhYmxlU3RhdGUgJiYgdGhpcy5fd3JpdGFibGVTdGF0ZS5kZXN0cm95ZWQ7XG5cbiAgaWYgKHJlYWRhYmxlRGVzdHJveWVkIHx8IHdyaXRhYmxlRGVzdHJveWVkKSB7XG4gICAgaWYgKGNiKSB7XG4gICAgICBjYihlcnIpO1xuICAgIH0gZWxzZSBpZiAoZXJyKSB7XG4gICAgICBpZiAoIXRoaXMuX3dyaXRhYmxlU3RhdGUpIHtcbiAgICAgICAgcHJvY2Vzcy5uZXh0VGljayhlbWl0RXJyb3JOVCwgdGhpcywgZXJyKTtcbiAgICAgIH0gZWxzZSBpZiAoIXRoaXMuX3dyaXRhYmxlU3RhdGUuZXJyb3JFbWl0dGVkKSB7XG4gICAgICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUuZXJyb3JFbWl0dGVkID0gdHJ1ZTtcbiAgICAgICAgcHJvY2Vzcy5uZXh0VGljayhlbWl0RXJyb3JOVCwgdGhpcywgZXJyKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcztcbiAgfSAvLyB3ZSBzZXQgZGVzdHJveWVkIHRvIHRydWUgYmVmb3JlIGZpcmluZyBlcnJvciBjYWxsYmFja3MgaW4gb3JkZXJcbiAgLy8gdG8gbWFrZSBpdCByZS1lbnRyYW5jZSBzYWZlIGluIGNhc2UgZGVzdHJveSgpIGlzIGNhbGxlZCB3aXRoaW4gY2FsbGJhY2tzXG5cblxuICBpZiAodGhpcy5fcmVhZGFibGVTdGF0ZSkge1xuICAgIHRoaXMuX3JlYWRhYmxlU3RhdGUuZGVzdHJveWVkID0gdHJ1ZTtcbiAgfSAvLyBpZiB0aGlzIGlzIGEgZHVwbGV4IHN0cmVhbSBtYXJrIHRoZSB3cml0YWJsZSBwYXJ0IGFzIGRlc3Ryb3llZCBhcyB3ZWxsXG5cblxuICBpZiAodGhpcy5fd3JpdGFibGVTdGF0ZSkge1xuICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUuZGVzdHJveWVkID0gdHJ1ZTtcbiAgfVxuXG4gIHRoaXMuX2Rlc3Ryb3koZXJyIHx8IG51bGwsIGZ1bmN0aW9uIChlcnIpIHtcbiAgICBpZiAoIWNiICYmIGVycikge1xuICAgICAgaWYgKCFfdGhpcy5fd3JpdGFibGVTdGF0ZSkge1xuICAgICAgICBwcm9jZXNzLm5leHRUaWNrKGVtaXRFcnJvckFuZENsb3NlTlQsIF90aGlzLCBlcnIpO1xuICAgICAgfSBlbHNlIGlmICghX3RoaXMuX3dyaXRhYmxlU3RhdGUuZXJyb3JFbWl0dGVkKSB7XG4gICAgICAgIF90aGlzLl93cml0YWJsZVN0YXRlLmVycm9yRW1pdHRlZCA9IHRydWU7XG4gICAgICAgIHByb2Nlc3MubmV4dFRpY2soZW1pdEVycm9yQW5kQ2xvc2VOVCwgX3RoaXMsIGVycik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwcm9jZXNzLm5leHRUaWNrKGVtaXRDbG9zZU5ULCBfdGhpcyk7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChjYikge1xuICAgICAgcHJvY2Vzcy5uZXh0VGljayhlbWl0Q2xvc2VOVCwgX3RoaXMpO1xuICAgICAgY2IoZXJyKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcHJvY2Vzcy5uZXh0VGljayhlbWl0Q2xvc2VOVCwgX3RoaXMpO1xuICAgIH1cbiAgfSk7XG5cbiAgcmV0dXJuIHRoaXM7XG59XG5cbmZ1bmN0aW9uIGVtaXRFcnJvckFuZENsb3NlTlQoc2VsZiwgZXJyKSB7XG4gIGVtaXRFcnJvck5UKHNlbGYsIGVycik7XG4gIGVtaXRDbG9zZU5UKHNlbGYpO1xufVxuXG5mdW5jdGlvbiBlbWl0Q2xvc2VOVChzZWxmKSB7XG4gIGlmIChzZWxmLl93cml0YWJsZVN0YXRlICYmICFzZWxmLl93cml0YWJsZVN0YXRlLmVtaXRDbG9zZSkgcmV0dXJuO1xuICBpZiAoc2VsZi5fcmVhZGFibGVTdGF0ZSAmJiAhc2VsZi5fcmVhZGFibGVTdGF0ZS5lbWl0Q2xvc2UpIHJldHVybjtcbiAgc2VsZi5lbWl0KCdjbG9zZScpO1xufVxuXG5mdW5jdGlvbiB1bmRlc3Ryb3koKSB7XG4gIGlmICh0aGlzLl9yZWFkYWJsZVN0YXRlKSB7XG4gICAgdGhpcy5fcmVhZGFibGVTdGF0ZS5kZXN0cm95ZWQgPSBmYWxzZTtcbiAgICB0aGlzLl9yZWFkYWJsZVN0YXRlLnJlYWRpbmcgPSBmYWxzZTtcbiAgICB0aGlzLl9yZWFkYWJsZVN0YXRlLmVuZGVkID0gZmFsc2U7XG4gICAgdGhpcy5fcmVhZGFibGVTdGF0ZS5lbmRFbWl0dGVkID0gZmFsc2U7XG4gIH1cblxuICBpZiAodGhpcy5fd3JpdGFibGVTdGF0ZSkge1xuICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUuZGVzdHJveWVkID0gZmFsc2U7XG4gICAgdGhpcy5fd3JpdGFibGVTdGF0ZS5lbmRlZCA9IGZhbHNlO1xuICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUuZW5kaW5nID0gZmFsc2U7XG4gICAgdGhpcy5fd3JpdGFibGVTdGF0ZS5maW5hbENhbGxlZCA9IGZhbHNlO1xuICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUucHJlZmluaXNoZWQgPSBmYWxzZTtcbiAgICB0aGlzLl93cml0YWJsZVN0YXRlLmZpbmlzaGVkID0gZmFsc2U7XG4gICAgdGhpcy5fd3JpdGFibGVTdGF0ZS5lcnJvckVtaXR0ZWQgPSBmYWxzZTtcbiAgfVxufVxuXG5mdW5jdGlvbiBlbWl0RXJyb3JOVChzZWxmLCBlcnIpIHtcbiAgc2VsZi5lbWl0KCdlcnJvcicsIGVycik7XG59XG5cbmZ1bmN0aW9uIGVycm9yT3JEZXN0cm95KHN0cmVhbSwgZXJyKSB7XG4gIC8vIFdlIGhhdmUgdGVzdHMgdGhhdCByZWx5IG9uIGVycm9ycyBiZWluZyBlbWl0dGVkXG4gIC8vIGluIHRoZSBzYW1lIHRpY2ssIHNvIGNoYW5naW5nIHRoaXMgaXMgc2VtdmVyIG1ham9yLlxuICAvLyBGb3Igbm93IHdoZW4geW91IG9wdC1pbiB0byBhdXRvRGVzdHJveSB3ZSBhbGxvd1xuICAvLyB0aGUgZXJyb3IgdG8gYmUgZW1pdHRlZCBuZXh0VGljay4gSW4gYSBmdXR1cmVcbiAgLy8gc2VtdmVyIG1ham9yIHVwZGF0ZSB3ZSBzaG91bGQgY2hhbmdlIHRoZSBkZWZhdWx0IHRvIHRoaXMuXG4gIHZhciByU3RhdGUgPSBzdHJlYW0uX3JlYWRhYmxlU3RhdGU7XG4gIHZhciB3U3RhdGUgPSBzdHJlYW0uX3dyaXRhYmxlU3RhdGU7XG4gIGlmIChyU3RhdGUgJiYgclN0YXRlLmF1dG9EZXN0cm95IHx8IHdTdGF0ZSAmJiB3U3RhdGUuYXV0b0Rlc3Ryb3kpIHN0cmVhbS5kZXN0cm95KGVycik7ZWxzZSBzdHJlYW0uZW1pdCgnZXJyb3InLCBlcnIpO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgZGVzdHJveTogZGVzdHJveSxcbiAgdW5kZXN0cm95OiB1bmRlc3Ryb3ksXG4gIGVycm9yT3JEZXN0cm95OiBlcnJvck9yRGVzdHJveVxufTsiLCIvLyBQb3J0ZWQgZnJvbSBodHRwczovL2dpdGh1Yi5jb20vbWFmaW50b3NoL2VuZC1vZi1zdHJlYW0gd2l0aFxuLy8gcGVybWlzc2lvbiBmcm9tIHRoZSBhdXRob3IsIE1hdGhpYXMgQnV1cyAoQG1hZmludG9zaCkuXG4ndXNlIHN0cmljdCc7XG5cbnZhciBFUlJfU1RSRUFNX1BSRU1BVFVSRV9DTE9TRSA9IHJlcXVpcmUoJy4uLy4uLy4uL2Vycm9ycycpLmNvZGVzLkVSUl9TVFJFQU1fUFJFTUFUVVJFX0NMT1NFO1xuXG5mdW5jdGlvbiBvbmNlKGNhbGxiYWNrKSB7XG4gIHZhciBjYWxsZWQgPSBmYWxzZTtcbiAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoY2FsbGVkKSByZXR1cm47XG4gICAgY2FsbGVkID0gdHJ1ZTtcblxuICAgIGZvciAodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gbmV3IEFycmF5KF9sZW4pLCBfa2V5ID0gMDsgX2tleSA8IF9sZW47IF9rZXkrKykge1xuICAgICAgYXJnc1tfa2V5XSA9IGFyZ3VtZW50c1tfa2V5XTtcbiAgICB9XG5cbiAgICBjYWxsYmFjay5hcHBseSh0aGlzLCBhcmdzKTtcbiAgfTtcbn1cblxuZnVuY3Rpb24gbm9vcCgpIHt9XG5cbmZ1bmN0aW9uIGlzUmVxdWVzdChzdHJlYW0pIHtcbiAgcmV0dXJuIHN0cmVhbS5zZXRIZWFkZXIgJiYgdHlwZW9mIHN0cmVhbS5hYm9ydCA9PT0gJ2Z1bmN0aW9uJztcbn1cblxuZnVuY3Rpb24gZW9zKHN0cmVhbSwgb3B0cywgY2FsbGJhY2spIHtcbiAgaWYgKHR5cGVvZiBvcHRzID09PSAnZnVuY3Rpb24nKSByZXR1cm4gZW9zKHN0cmVhbSwgbnVsbCwgb3B0cyk7XG4gIGlmICghb3B0cykgb3B0cyA9IHt9O1xuICBjYWxsYmFjayA9IG9uY2UoY2FsbGJhY2sgfHwgbm9vcCk7XG4gIHZhciByZWFkYWJsZSA9IG9wdHMucmVhZGFibGUgfHwgb3B0cy5yZWFkYWJsZSAhPT0gZmFsc2UgJiYgc3RyZWFtLnJlYWRhYmxlO1xuICB2YXIgd3JpdGFibGUgPSBvcHRzLndyaXRhYmxlIHx8IG9wdHMud3JpdGFibGUgIT09IGZhbHNlICYmIHN0cmVhbS53cml0YWJsZTtcblxuICB2YXIgb25sZWdhY3lmaW5pc2ggPSBmdW5jdGlvbiBvbmxlZ2FjeWZpbmlzaCgpIHtcbiAgICBpZiAoIXN0cmVhbS53cml0YWJsZSkgb25maW5pc2goKTtcbiAgfTtcblxuICB2YXIgd3JpdGFibGVFbmRlZCA9IHN0cmVhbS5fd3JpdGFibGVTdGF0ZSAmJiBzdHJlYW0uX3dyaXRhYmxlU3RhdGUuZmluaXNoZWQ7XG5cbiAgdmFyIG9uZmluaXNoID0gZnVuY3Rpb24gb25maW5pc2goKSB7XG4gICAgd3JpdGFibGUgPSBmYWxzZTtcbiAgICB3cml0YWJsZUVuZGVkID0gdHJ1ZTtcbiAgICBpZiAoIXJlYWRhYmxlKSBjYWxsYmFjay5jYWxsKHN0cmVhbSk7XG4gIH07XG5cbiAgdmFyIHJlYWRhYmxlRW5kZWQgPSBzdHJlYW0uX3JlYWRhYmxlU3RhdGUgJiYgc3RyZWFtLl9yZWFkYWJsZVN0YXRlLmVuZEVtaXR0ZWQ7XG5cbiAgdmFyIG9uZW5kID0gZnVuY3Rpb24gb25lbmQoKSB7XG4gICAgcmVhZGFibGUgPSBmYWxzZTtcbiAgICByZWFkYWJsZUVuZGVkID0gdHJ1ZTtcbiAgICBpZiAoIXdyaXRhYmxlKSBjYWxsYmFjay5jYWxsKHN0cmVhbSk7XG4gIH07XG5cbiAgdmFyIG9uZXJyb3IgPSBmdW5jdGlvbiBvbmVycm9yKGVycikge1xuICAgIGNhbGxiYWNrLmNhbGwoc3RyZWFtLCBlcnIpO1xuICB9O1xuXG4gIHZhciBvbmNsb3NlID0gZnVuY3Rpb24gb25jbG9zZSgpIHtcbiAgICB2YXIgZXJyO1xuXG4gICAgaWYgKHJlYWRhYmxlICYmICFyZWFkYWJsZUVuZGVkKSB7XG4gICAgICBpZiAoIXN0cmVhbS5fcmVhZGFibGVTdGF0ZSB8fCAhc3RyZWFtLl9yZWFkYWJsZVN0YXRlLmVuZGVkKSBlcnIgPSBuZXcgRVJSX1NUUkVBTV9QUkVNQVRVUkVfQ0xPU0UoKTtcbiAgICAgIHJldHVybiBjYWxsYmFjay5jYWxsKHN0cmVhbSwgZXJyKTtcbiAgICB9XG5cbiAgICBpZiAod3JpdGFibGUgJiYgIXdyaXRhYmxlRW5kZWQpIHtcbiAgICAgIGlmICghc3RyZWFtLl93cml0YWJsZVN0YXRlIHx8ICFzdHJlYW0uX3dyaXRhYmxlU3RhdGUuZW5kZWQpIGVyciA9IG5ldyBFUlJfU1RSRUFNX1BSRU1BVFVSRV9DTE9TRSgpO1xuICAgICAgcmV0dXJuIGNhbGxiYWNrLmNhbGwoc3RyZWFtLCBlcnIpO1xuICAgIH1cbiAgfTtcblxuICB2YXIgb25yZXF1ZXN0ID0gZnVuY3Rpb24gb25yZXF1ZXN0KCkge1xuICAgIHN0cmVhbS5yZXEub24oJ2ZpbmlzaCcsIG9uZmluaXNoKTtcbiAgfTtcblxuICBpZiAoaXNSZXF1ZXN0KHN0cmVhbSkpIHtcbiAgICBzdHJlYW0ub24oJ2NvbXBsZXRlJywgb25maW5pc2gpO1xuICAgIHN0cmVhbS5vbignYWJvcnQnLCBvbmNsb3NlKTtcbiAgICBpZiAoc3RyZWFtLnJlcSkgb25yZXF1ZXN0KCk7ZWxzZSBzdHJlYW0ub24oJ3JlcXVlc3QnLCBvbnJlcXVlc3QpO1xuICB9IGVsc2UgaWYgKHdyaXRhYmxlICYmICFzdHJlYW0uX3dyaXRhYmxlU3RhdGUpIHtcbiAgICAvLyBsZWdhY3kgc3RyZWFtc1xuICAgIHN0cmVhbS5vbignZW5kJywgb25sZWdhY3lmaW5pc2gpO1xuICAgIHN0cmVhbS5vbignY2xvc2UnLCBvbmxlZ2FjeWZpbmlzaCk7XG4gIH1cblxuICBzdHJlYW0ub24oJ2VuZCcsIG9uZW5kKTtcbiAgc3RyZWFtLm9uKCdmaW5pc2gnLCBvbmZpbmlzaCk7XG4gIGlmIChvcHRzLmVycm9yICE9PSBmYWxzZSkgc3RyZWFtLm9uKCdlcnJvcicsIG9uZXJyb3IpO1xuICBzdHJlYW0ub24oJ2Nsb3NlJywgb25jbG9zZSk7XG4gIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgc3RyZWFtLnJlbW92ZUxpc3RlbmVyKCdjb21wbGV0ZScsIG9uZmluaXNoKTtcbiAgICBzdHJlYW0ucmVtb3ZlTGlzdGVuZXIoJ2Fib3J0Jywgb25jbG9zZSk7XG4gICAgc3RyZWFtLnJlbW92ZUxpc3RlbmVyKCdyZXF1ZXN0Jywgb25yZXF1ZXN0KTtcbiAgICBpZiAoc3RyZWFtLnJlcSkgc3RyZWFtLnJlcS5yZW1vdmVMaXN0ZW5lcignZmluaXNoJywgb25maW5pc2gpO1xuICAgIHN0cmVhbS5yZW1vdmVMaXN0ZW5lcignZW5kJywgb25sZWdhY3lmaW5pc2gpO1xuICAgIHN0cmVhbS5yZW1vdmVMaXN0ZW5lcignY2xvc2UnLCBvbmxlZ2FjeWZpbmlzaCk7XG4gICAgc3RyZWFtLnJlbW92ZUxpc3RlbmVyKCdmaW5pc2gnLCBvbmZpbmlzaCk7XG4gICAgc3RyZWFtLnJlbW92ZUxpc3RlbmVyKCdlbmQnLCBvbmVuZCk7XG4gICAgc3RyZWFtLnJlbW92ZUxpc3RlbmVyKCdlcnJvcicsIG9uZXJyb3IpO1xuICAgIHN0cmVhbS5yZW1vdmVMaXN0ZW5lcignY2xvc2UnLCBvbmNsb3NlKTtcbiAgfTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBlb3M7IiwiJ3VzZSBzdHJpY3QnO1xuXG5mdW5jdGlvbiBhc3luY0dlbmVyYXRvclN0ZXAoZ2VuLCByZXNvbHZlLCByZWplY3QsIF9uZXh0LCBfdGhyb3csIGtleSwgYXJnKSB7IHRyeSB7IHZhciBpbmZvID0gZ2VuW2tleV0oYXJnKTsgdmFyIHZhbHVlID0gaW5mby52YWx1ZTsgfSBjYXRjaCAoZXJyb3IpIHsgcmVqZWN0KGVycm9yKTsgcmV0dXJuOyB9IGlmIChpbmZvLmRvbmUpIHsgcmVzb2x2ZSh2YWx1ZSk7IH0gZWxzZSB7IFByb21pc2UucmVzb2x2ZSh2YWx1ZSkudGhlbihfbmV4dCwgX3Rocm93KTsgfSB9XG5cbmZ1bmN0aW9uIF9hc3luY1RvR2VuZXJhdG9yKGZuKSB7IHJldHVybiBmdW5jdGlvbiAoKSB7IHZhciBzZWxmID0gdGhpcywgYXJncyA9IGFyZ3VtZW50czsgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHsgdmFyIGdlbiA9IGZuLmFwcGx5KHNlbGYsIGFyZ3MpOyBmdW5jdGlvbiBfbmV4dCh2YWx1ZSkgeyBhc3luY0dlbmVyYXRvclN0ZXAoZ2VuLCByZXNvbHZlLCByZWplY3QsIF9uZXh0LCBfdGhyb3csIFwibmV4dFwiLCB2YWx1ZSk7IH0gZnVuY3Rpb24gX3Rocm93KGVycikgeyBhc3luY0dlbmVyYXRvclN0ZXAoZ2VuLCByZXNvbHZlLCByZWplY3QsIF9uZXh0LCBfdGhyb3csIFwidGhyb3dcIiwgZXJyKTsgfSBfbmV4dCh1bmRlZmluZWQpOyB9KTsgfTsgfVxuXG5mdW5jdGlvbiBvd25LZXlzKG9iamVjdCwgZW51bWVyYWJsZU9ubHkpIHsgdmFyIGtleXMgPSBPYmplY3Qua2V5cyhvYmplY3QpOyBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykgeyB2YXIgc3ltYm9scyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMob2JqZWN0KTsgaWYgKGVudW1lcmFibGVPbmx5KSBzeW1ib2xzID0gc3ltYm9scy5maWx0ZXIoZnVuY3Rpb24gKHN5bSkgeyByZXR1cm4gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihvYmplY3QsIHN5bSkuZW51bWVyYWJsZTsgfSk7IGtleXMucHVzaC5hcHBseShrZXlzLCBzeW1ib2xzKTsgfSByZXR1cm4ga2V5czsgfVxuXG5mdW5jdGlvbiBfb2JqZWN0U3ByZWFkKHRhcmdldCkgeyBmb3IgKHZhciBpID0gMTsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7IGkrKykgeyB2YXIgc291cmNlID0gYXJndW1lbnRzW2ldICE9IG51bGwgPyBhcmd1bWVudHNbaV0gOiB7fTsgaWYgKGkgJSAyKSB7IG93bktleXMoT2JqZWN0KHNvdXJjZSksIHRydWUpLmZvckVhY2goZnVuY3Rpb24gKGtleSkgeyBfZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBrZXksIHNvdXJjZVtrZXldKTsgfSk7IH0gZWxzZSBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMpIHsgT2JqZWN0LmRlZmluZVByb3BlcnRpZXModGFyZ2V0LCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyhzb3VyY2UpKTsgfSBlbHNlIHsgb3duS2V5cyhPYmplY3Qoc291cmNlKSkuZm9yRWFjaChmdW5jdGlvbiAoa2V5KSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGtleSwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihzb3VyY2UsIGtleSkpOyB9KTsgfSB9IHJldHVybiB0YXJnZXQ7IH1cblxuZnVuY3Rpb24gX2RlZmluZVByb3BlcnR5KG9iaiwga2V5LCB2YWx1ZSkgeyBpZiAoa2V5IGluIG9iaikgeyBPYmplY3QuZGVmaW5lUHJvcGVydHkob2JqLCBrZXksIHsgdmFsdWU6IHZhbHVlLCBlbnVtZXJhYmxlOiB0cnVlLCBjb25maWd1cmFibGU6IHRydWUsIHdyaXRhYmxlOiB0cnVlIH0pOyB9IGVsc2UgeyBvYmpba2V5XSA9IHZhbHVlOyB9IHJldHVybiBvYmo7IH1cblxudmFyIEVSUl9JTlZBTElEX0FSR19UWVBFID0gcmVxdWlyZSgnLi4vLi4vLi4vZXJyb3JzJykuY29kZXMuRVJSX0lOVkFMSURfQVJHX1RZUEU7XG5cbmZ1bmN0aW9uIGZyb20oUmVhZGFibGUsIGl0ZXJhYmxlLCBvcHRzKSB7XG4gIHZhciBpdGVyYXRvcjtcblxuICBpZiAoaXRlcmFibGUgJiYgdHlwZW9mIGl0ZXJhYmxlLm5leHQgPT09ICdmdW5jdGlvbicpIHtcbiAgICBpdGVyYXRvciA9IGl0ZXJhYmxlO1xuICB9IGVsc2UgaWYgKGl0ZXJhYmxlICYmIGl0ZXJhYmxlW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSkgaXRlcmF0b3IgPSBpdGVyYWJsZVtTeW1ib2wuYXN5bmNJdGVyYXRvcl0oKTtlbHNlIGlmIChpdGVyYWJsZSAmJiBpdGVyYWJsZVtTeW1ib2wuaXRlcmF0b3JdKSBpdGVyYXRvciA9IGl0ZXJhYmxlW1N5bWJvbC5pdGVyYXRvcl0oKTtlbHNlIHRocm93IG5ldyBFUlJfSU5WQUxJRF9BUkdfVFlQRSgnaXRlcmFibGUnLCBbJ0l0ZXJhYmxlJ10sIGl0ZXJhYmxlKTtcblxuICB2YXIgcmVhZGFibGUgPSBuZXcgUmVhZGFibGUoX29iamVjdFNwcmVhZCh7XG4gICAgb2JqZWN0TW9kZTogdHJ1ZVxuICB9LCBvcHRzKSk7IC8vIFJlYWRpbmcgYm9vbGVhbiB0byBwcm90ZWN0IGFnYWluc3QgX3JlYWRcbiAgLy8gYmVpbmcgY2FsbGVkIGJlZm9yZSBsYXN0IGl0ZXJhdGlvbiBjb21wbGV0aW9uLlxuXG4gIHZhciByZWFkaW5nID0gZmFsc2U7XG5cbiAgcmVhZGFibGUuX3JlYWQgPSBmdW5jdGlvbiAoKSB7XG4gICAgaWYgKCFyZWFkaW5nKSB7XG4gICAgICByZWFkaW5nID0gdHJ1ZTtcbiAgICAgIG5leHQoKTtcbiAgICB9XG4gIH07XG5cbiAgZnVuY3Rpb24gbmV4dCgpIHtcbiAgICByZXR1cm4gX25leHQyLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gIH1cblxuICBmdW5jdGlvbiBfbmV4dDIoKSB7XG4gICAgX25leHQyID0gX2FzeW5jVG9HZW5lcmF0b3IoZnVuY3Rpb24qICgpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHZhciBfcmVmID0geWllbGQgaXRlcmF0b3IubmV4dCgpLFxuICAgICAgICAgICAgdmFsdWUgPSBfcmVmLnZhbHVlLFxuICAgICAgICAgICAgZG9uZSA9IF9yZWYuZG9uZTtcblxuICAgICAgICBpZiAoZG9uZSkge1xuICAgICAgICAgIHJlYWRhYmxlLnB1c2gobnVsbCk7XG4gICAgICAgIH0gZWxzZSBpZiAocmVhZGFibGUucHVzaCgoeWllbGQgdmFsdWUpKSkge1xuICAgICAgICAgIG5leHQoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZWFkaW5nID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICByZWFkYWJsZS5kZXN0cm95KGVycik7XG4gICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIF9uZXh0Mi5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICB9XG5cbiAgcmV0dXJuIHJlYWRhYmxlO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGZyb207IiwiLy8gUG9ydGVkIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL21hZmludG9zaC9wdW1wIHdpdGhcbi8vIHBlcm1pc3Npb24gZnJvbSB0aGUgYXV0aG9yLCBNYXRoaWFzIEJ1dXMgKEBtYWZpbnRvc2gpLlxuJ3VzZSBzdHJpY3QnO1xuXG52YXIgZW9zO1xuXG5mdW5jdGlvbiBvbmNlKGNhbGxiYWNrKSB7XG4gIHZhciBjYWxsZWQgPSBmYWxzZTtcbiAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoY2FsbGVkKSByZXR1cm47XG4gICAgY2FsbGVkID0gdHJ1ZTtcbiAgICBjYWxsYmFjay5hcHBseSh2b2lkIDAsIGFyZ3VtZW50cyk7XG4gIH07XG59XG5cbnZhciBfcmVxdWlyZSRjb2RlcyA9IHJlcXVpcmUoJy4uLy4uLy4uL2Vycm9ycycpLmNvZGVzLFxuICAgIEVSUl9NSVNTSU5HX0FSR1MgPSBfcmVxdWlyZSRjb2Rlcy5FUlJfTUlTU0lOR19BUkdTLFxuICAgIEVSUl9TVFJFQU1fREVTVFJPWUVEID0gX3JlcXVpcmUkY29kZXMuRVJSX1NUUkVBTV9ERVNUUk9ZRUQ7XG5cbmZ1bmN0aW9uIG5vb3AoZXJyKSB7XG4gIC8vIFJldGhyb3cgdGhlIGVycm9yIGlmIGl0IGV4aXN0cyB0byBhdm9pZCBzd2FsbG93aW5nIGl0XG4gIGlmIChlcnIpIHRocm93IGVycjtcbn1cblxuZnVuY3Rpb24gaXNSZXF1ZXN0KHN0cmVhbSkge1xuICByZXR1cm4gc3RyZWFtLnNldEhlYWRlciAmJiB0eXBlb2Ygc3RyZWFtLmFib3J0ID09PSAnZnVuY3Rpb24nO1xufVxuXG5mdW5jdGlvbiBkZXN0cm95ZXIoc3RyZWFtLCByZWFkaW5nLCB3cml0aW5nLCBjYWxsYmFjaykge1xuICBjYWxsYmFjayA9IG9uY2UoY2FsbGJhY2spO1xuICB2YXIgY2xvc2VkID0gZmFsc2U7XG4gIHN0cmVhbS5vbignY2xvc2UnLCBmdW5jdGlvbiAoKSB7XG4gICAgY2xvc2VkID0gdHJ1ZTtcbiAgfSk7XG4gIGlmIChlb3MgPT09IHVuZGVmaW5lZCkgZW9zID0gcmVxdWlyZSgnLi9lbmQtb2Ytc3RyZWFtJyk7XG4gIGVvcyhzdHJlYW0sIHtcbiAgICByZWFkYWJsZTogcmVhZGluZyxcbiAgICB3cml0YWJsZTogd3JpdGluZ1xuICB9LCBmdW5jdGlvbiAoZXJyKSB7XG4gICAgaWYgKGVycikgcmV0dXJuIGNhbGxiYWNrKGVycik7XG4gICAgY2xvc2VkID0gdHJ1ZTtcbiAgICBjYWxsYmFjaygpO1xuICB9KTtcbiAgdmFyIGRlc3Ryb3llZCA9IGZhbHNlO1xuICByZXR1cm4gZnVuY3Rpb24gKGVycikge1xuICAgIGlmIChjbG9zZWQpIHJldHVybjtcbiAgICBpZiAoZGVzdHJveWVkKSByZXR1cm47XG4gICAgZGVzdHJveWVkID0gdHJ1ZTsgLy8gcmVxdWVzdC5kZXN0cm95IGp1c3QgZG8gLmVuZCAtIC5hYm9ydCBpcyB3aGF0IHdlIHdhbnRcblxuICAgIGlmIChpc1JlcXVlc3Qoc3RyZWFtKSkgcmV0dXJuIHN0cmVhbS5hYm9ydCgpO1xuICAgIGlmICh0eXBlb2Ygc3RyZWFtLmRlc3Ryb3kgPT09ICdmdW5jdGlvbicpIHJldHVybiBzdHJlYW0uZGVzdHJveSgpO1xuICAgIGNhbGxiYWNrKGVyciB8fCBuZXcgRVJSX1NUUkVBTV9ERVNUUk9ZRUQoJ3BpcGUnKSk7XG4gIH07XG59XG5cbmZ1bmN0aW9uIGNhbGwoZm4pIHtcbiAgZm4oKTtcbn1cblxuZnVuY3Rpb24gcGlwZShmcm9tLCB0bykge1xuICByZXR1cm4gZnJvbS5waXBlKHRvKTtcbn1cblxuZnVuY3Rpb24gcG9wQ2FsbGJhY2soc3RyZWFtcykge1xuICBpZiAoIXN0cmVhbXMubGVuZ3RoKSByZXR1cm4gbm9vcDtcbiAgaWYgKHR5cGVvZiBzdHJlYW1zW3N0cmVhbXMubGVuZ3RoIC0gMV0gIT09ICdmdW5jdGlvbicpIHJldHVybiBub29wO1xuICByZXR1cm4gc3RyZWFtcy5wb3AoKTtcbn1cblxuZnVuY3Rpb24gcGlwZWxpbmUoKSB7XG4gIGZvciAodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBzdHJlYW1zID0gbmV3IEFycmF5KF9sZW4pLCBfa2V5ID0gMDsgX2tleSA8IF9sZW47IF9rZXkrKykge1xuICAgIHN0cmVhbXNbX2tleV0gPSBhcmd1bWVudHNbX2tleV07XG4gIH1cblxuICB2YXIgY2FsbGJhY2sgPSBwb3BDYWxsYmFjayhzdHJlYW1zKTtcbiAgaWYgKEFycmF5LmlzQXJyYXkoc3RyZWFtc1swXSkpIHN0cmVhbXMgPSBzdHJlYW1zWzBdO1xuXG4gIGlmIChzdHJlYW1zLmxlbmd0aCA8IDIpIHtcbiAgICB0aHJvdyBuZXcgRVJSX01JU1NJTkdfQVJHUygnc3RyZWFtcycpO1xuICB9XG5cbiAgdmFyIGVycm9yO1xuICB2YXIgZGVzdHJveXMgPSBzdHJlYW1zLm1hcChmdW5jdGlvbiAoc3RyZWFtLCBpKSB7XG4gICAgdmFyIHJlYWRpbmcgPSBpIDwgc3RyZWFtcy5sZW5ndGggLSAxO1xuICAgIHZhciB3cml0aW5nID0gaSA+IDA7XG4gICAgcmV0dXJuIGRlc3Ryb3llcihzdHJlYW0sIHJlYWRpbmcsIHdyaXRpbmcsIGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgIGlmICghZXJyb3IpIGVycm9yID0gZXJyO1xuICAgICAgaWYgKGVycikgZGVzdHJveXMuZm9yRWFjaChjYWxsKTtcbiAgICAgIGlmIChyZWFkaW5nKSByZXR1cm47XG4gICAgICBkZXN0cm95cy5mb3JFYWNoKGNhbGwpO1xuICAgICAgY2FsbGJhY2soZXJyb3IpO1xuICAgIH0pO1xuICB9KTtcbiAgcmV0dXJuIHN0cmVhbXMucmVkdWNlKHBpcGUpO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHBpcGVsaW5lOyIsIid1c2Ugc3RyaWN0JztcblxudmFyIEVSUl9JTlZBTElEX09QVF9WQUxVRSA9IHJlcXVpcmUoJy4uLy4uLy4uL2Vycm9ycycpLmNvZGVzLkVSUl9JTlZBTElEX09QVF9WQUxVRTtcblxuZnVuY3Rpb24gaGlnaFdhdGVyTWFya0Zyb20ob3B0aW9ucywgaXNEdXBsZXgsIGR1cGxleEtleSkge1xuICByZXR1cm4gb3B0aW9ucy5oaWdoV2F0ZXJNYXJrICE9IG51bGwgPyBvcHRpb25zLmhpZ2hXYXRlck1hcmsgOiBpc0R1cGxleCA/IG9wdGlvbnNbZHVwbGV4S2V5XSA6IG51bGw7XG59XG5cbmZ1bmN0aW9uIGdldEhpZ2hXYXRlck1hcmsoc3RhdGUsIG9wdGlvbnMsIGR1cGxleEtleSwgaXNEdXBsZXgpIHtcbiAgdmFyIGh3bSA9IGhpZ2hXYXRlck1hcmtGcm9tKG9wdGlvbnMsIGlzRHVwbGV4LCBkdXBsZXhLZXkpO1xuXG4gIGlmIChod20gIT0gbnVsbCkge1xuICAgIGlmICghKGlzRmluaXRlKGh3bSkgJiYgTWF0aC5mbG9vcihod20pID09PSBod20pIHx8IGh3bSA8IDApIHtcbiAgICAgIHZhciBuYW1lID0gaXNEdXBsZXggPyBkdXBsZXhLZXkgOiAnaGlnaFdhdGVyTWFyayc7XG4gICAgICB0aHJvdyBuZXcgRVJSX0lOVkFMSURfT1BUX1ZBTFVFKG5hbWUsIGh3bSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIE1hdGguZmxvb3IoaHdtKTtcbiAgfSAvLyBEZWZhdWx0IHZhbHVlXG5cblxuICByZXR1cm4gc3RhdGUub2JqZWN0TW9kZSA/IDE2IDogMTYgKiAxMDI0O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgZ2V0SGlnaFdhdGVyTWFyazogZ2V0SGlnaFdhdGVyTWFya1xufTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJ3N0cmVhbScpO1xuIiwidmFyIFN0cmVhbSA9IHJlcXVpcmUoJ3N0cmVhbScpO1xuaWYgKHByb2Nlc3MuZW52LlJFQURBQkxFX1NUUkVBTSA9PT0gJ2Rpc2FibGUnICYmIFN0cmVhbSkge1xuICBtb2R1bGUuZXhwb3J0cyA9IFN0cmVhbS5SZWFkYWJsZTtcbiAgT2JqZWN0LmFzc2lnbihtb2R1bGUuZXhwb3J0cywgU3RyZWFtKTtcbiAgbW9kdWxlLmV4cG9ydHMuU3RyZWFtID0gU3RyZWFtO1xufSBlbHNlIHtcbiAgZXhwb3J0cyA9IG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9saWIvX3N0cmVhbV9yZWFkYWJsZS5qcycpO1xuICBleHBvcnRzLlN0cmVhbSA9IFN0cmVhbSB8fCBleHBvcnRzO1xuICBleHBvcnRzLlJlYWRhYmxlID0gZXhwb3J0cztcbiAgZXhwb3J0cy5Xcml0YWJsZSA9IHJlcXVpcmUoJy4vbGliL19zdHJlYW1fd3JpdGFibGUuanMnKTtcbiAgZXhwb3J0cy5EdXBsZXggPSByZXF1aXJlKCcuL2xpYi9fc3RyZWFtX2R1cGxleC5qcycpO1xuICBleHBvcnRzLlRyYW5zZm9ybSA9IHJlcXVpcmUoJy4vbGliL19zdHJlYW1fdHJhbnNmb3JtLmpzJyk7XG4gIGV4cG9ydHMuUGFzc1Rocm91Z2ggPSByZXF1aXJlKCcuL2xpYi9fc3RyZWFtX3Bhc3N0aHJvdWdoLmpzJyk7XG4gIGV4cG9ydHMuZmluaXNoZWQgPSByZXF1aXJlKCcuL2xpYi9pbnRlcm5hbC9zdHJlYW1zL2VuZC1vZi1zdHJlYW0uanMnKTtcbiAgZXhwb3J0cy5waXBlbGluZSA9IHJlcXVpcmUoJy4vbGliL2ludGVybmFsL3N0cmVhbXMvcGlwZWxpbmUuanMnKTtcbn1cbiIsIi8qISBzYWZlLWJ1ZmZlci4gTUlUIExpY2Vuc2UuIEZlcm9zcyBBYm91a2hhZGlqZWggPGh0dHBzOi8vZmVyb3NzLm9yZy9vcGVuc291cmNlPiAqL1xuLyogZXNsaW50LWRpc2FibGUgbm9kZS9uby1kZXByZWNhdGVkLWFwaSAqL1xudmFyIGJ1ZmZlciA9IHJlcXVpcmUoJ2J1ZmZlcicpXG52YXIgQnVmZmVyID0gYnVmZmVyLkJ1ZmZlclxuXG4vLyBhbHRlcm5hdGl2ZSB0byB1c2luZyBPYmplY3Qua2V5cyBmb3Igb2xkIGJyb3dzZXJzXG5mdW5jdGlvbiBjb3B5UHJvcHMgKHNyYywgZHN0KSB7XG4gIGZvciAodmFyIGtleSBpbiBzcmMpIHtcbiAgICBkc3Rba2V5XSA9IHNyY1trZXldXG4gIH1cbn1cbmlmIChCdWZmZXIuZnJvbSAmJiBCdWZmZXIuYWxsb2MgJiYgQnVmZmVyLmFsbG9jVW5zYWZlICYmIEJ1ZmZlci5hbGxvY1Vuc2FmZVNsb3cpIHtcbiAgbW9kdWxlLmV4cG9ydHMgPSBidWZmZXJcbn0gZWxzZSB7XG4gIC8vIENvcHkgcHJvcGVydGllcyBmcm9tIHJlcXVpcmUoJ2J1ZmZlcicpXG4gIGNvcHlQcm9wcyhidWZmZXIsIGV4cG9ydHMpXG4gIGV4cG9ydHMuQnVmZmVyID0gU2FmZUJ1ZmZlclxufVxuXG5mdW5jdGlvbiBTYWZlQnVmZmVyIChhcmcsIGVuY29kaW5nT3JPZmZzZXQsIGxlbmd0aCkge1xuICByZXR1cm4gQnVmZmVyKGFyZywgZW5jb2RpbmdPck9mZnNldCwgbGVuZ3RoKVxufVxuXG5TYWZlQnVmZmVyLnByb3RvdHlwZSA9IE9iamVjdC5jcmVhdGUoQnVmZmVyLnByb3RvdHlwZSlcblxuLy8gQ29weSBzdGF0aWMgbWV0aG9kcyBmcm9tIEJ1ZmZlclxuY29weVByb3BzKEJ1ZmZlciwgU2FmZUJ1ZmZlcilcblxuU2FmZUJ1ZmZlci5mcm9tID0gZnVuY3Rpb24gKGFyZywgZW5jb2RpbmdPck9mZnNldCwgbGVuZ3RoKSB7XG4gIGlmICh0eXBlb2YgYXJnID09PSAnbnVtYmVyJykge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ0FyZ3VtZW50IG11c3Qgbm90IGJlIGEgbnVtYmVyJylcbiAgfVxuICByZXR1cm4gQnVmZmVyKGFyZywgZW5jb2RpbmdPck9mZnNldCwgbGVuZ3RoKVxufVxuXG5TYWZlQnVmZmVyLmFsbG9jID0gZnVuY3Rpb24gKHNpemUsIGZpbGwsIGVuY29kaW5nKSB7XG4gIGlmICh0eXBlb2Ygc2l6ZSAhPT0gJ251bWJlcicpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdBcmd1bWVudCBtdXN0IGJlIGEgbnVtYmVyJylcbiAgfVxuICB2YXIgYnVmID0gQnVmZmVyKHNpemUpXG4gIGlmIChmaWxsICE9PSB1bmRlZmluZWQpIHtcbiAgICBpZiAodHlwZW9mIGVuY29kaW5nID09PSAnc3RyaW5nJykge1xuICAgICAgYnVmLmZpbGwoZmlsbCwgZW5jb2RpbmcpXG4gICAgfSBlbHNlIHtcbiAgICAgIGJ1Zi5maWxsKGZpbGwpXG4gICAgfVxuICB9IGVsc2Uge1xuICAgIGJ1Zi5maWxsKDApXG4gIH1cbiAgcmV0dXJuIGJ1ZlxufVxuXG5TYWZlQnVmZmVyLmFsbG9jVW5zYWZlID0gZnVuY3Rpb24gKHNpemUpIHtcbiAgaWYgKHR5cGVvZiBzaXplICE9PSAnbnVtYmVyJykge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ0FyZ3VtZW50IG11c3QgYmUgYSBudW1iZXInKVxuICB9XG4gIHJldHVybiBCdWZmZXIoc2l6ZSlcbn1cblxuU2FmZUJ1ZmZlci5hbGxvY1Vuc2FmZVNsb3cgPSBmdW5jdGlvbiAoc2l6ZSkge1xuICBpZiAodHlwZW9mIHNpemUgIT09ICdudW1iZXInKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignQXJndW1lbnQgbXVzdCBiZSBhIG51bWJlcicpXG4gIH1cbiAgcmV0dXJuIGJ1ZmZlci5TbG93QnVmZmVyKHNpemUpXG59XG4iLCIvKlxuQ29weXJpZ2h0IChjKSAyMDE0LTIwMTgsIE1hdHRlbyBDb2xsaW5hIDxoZWxsb0BtYXR0ZW9jb2xsaW5hLmNvbT5cblxuUGVybWlzc2lvbiB0byB1c2UsIGNvcHksIG1vZGlmeSwgYW5kL29yIGRpc3RyaWJ1dGUgdGhpcyBzb2Z0d2FyZSBmb3IgYW55XG5wdXJwb3NlIHdpdGggb3Igd2l0aG91dCBmZWUgaXMgaGVyZWJ5IGdyYW50ZWQsIHByb3ZpZGVkIHRoYXQgdGhlIGFib3ZlXG5jb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIGFwcGVhciBpbiBhbGwgY29waWVzLlxuXG5USEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiIEFORCBUSEUgQVVUSE9SIERJU0NMQUlNUyBBTEwgV0FSUkFOVElFU1xuV0lUSCBSRUdBUkQgVE8gVEhJUyBTT0ZUV0FSRSBJTkNMVURJTkcgQUxMIElNUExJRUQgV0FSUkFOVElFUyBPRlxuTUVSQ0hBTlRBQklMSVRZIEFORCBGSVRORVNTLiBJTiBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SIEJFIExJQUJMRSBGT1JcbkFOWSBTUEVDSUFMLCBESVJFQ1QsIElORElSRUNULCBPUiBDT05TRVFVRU5USUFMIERBTUFHRVMgT1IgQU5ZIERBTUFHRVNcbldIQVRTT0VWRVIgUkVTVUxUSU5HIEZST00gTE9TUyBPRiBVU0UsIERBVEEgT1IgUFJPRklUUywgV0hFVEhFUiBJTiBBTlxuQUNUSU9OIE9GIENPTlRSQUNULCBORUdMSUdFTkNFIE9SIE9USEVSIFRPUlRJT1VTIEFDVElPTiwgQVJJU0lORyBPVVQgT0YgT1JcbklOIENPTk5FQ1RJT04gV0lUSCBUSEUgVVNFIE9SIFBFUkZPUk1BTkNFIE9GIFRISVMgU09GVFdBUkUuXG4qL1xuXG4ndXNlIHN0cmljdCdcblxuY29uc3QgeyBUcmFuc2Zvcm0gfSA9IHJlcXVpcmUoJ3JlYWRhYmxlLXN0cmVhbScpXG5jb25zdCB7IFN0cmluZ0RlY29kZXIgfSA9IHJlcXVpcmUoJ3N0cmluZ19kZWNvZGVyJylcbmNvbnN0IGtMYXN0ID0gU3ltYm9sKCdsYXN0JylcbmNvbnN0IGtEZWNvZGVyID0gU3ltYm9sKCdkZWNvZGVyJylcblxuZnVuY3Rpb24gdHJhbnNmb3JtIChjaHVuaywgZW5jLCBjYikge1xuICB2YXIgbGlzdFxuICBpZiAodGhpcy5vdmVyZmxvdykgeyAvLyBMaW5lIGJ1ZmZlciBpcyBmdWxsLiBTa2lwIHRvIHN0YXJ0IG9mIG5leHQgbGluZS5cbiAgICB2YXIgYnVmID0gdGhpc1trRGVjb2Rlcl0ud3JpdGUoY2h1bmspXG4gICAgbGlzdCA9IGJ1Zi5zcGxpdCh0aGlzLm1hdGNoZXIpXG5cbiAgICBpZiAobGlzdC5sZW5ndGggPT09IDEpIHJldHVybiBjYigpIC8vIExpbmUgZW5kaW5nIG5vdCBmb3VuZC4gRGlzY2FyZCBlbnRpcmUgY2h1bmsuXG5cbiAgICAvLyBMaW5lIGVuZGluZyBmb3VuZC4gRGlzY2FyZCB0cmFpbGluZyBmcmFnbWVudCBvZiBwcmV2aW91cyBsaW5lIGFuZCByZXNldCBvdmVyZmxvdyBzdGF0ZS5cbiAgICBsaXN0LnNoaWZ0KClcbiAgICB0aGlzLm92ZXJmbG93ID0gZmFsc2VcbiAgfSBlbHNlIHtcbiAgICB0aGlzW2tMYXN0XSArPSB0aGlzW2tEZWNvZGVyXS53cml0ZShjaHVuaylcbiAgICBsaXN0ID0gdGhpc1trTGFzdF0uc3BsaXQodGhpcy5tYXRjaGVyKVxuICB9XG5cbiAgdGhpc1trTGFzdF0gPSBsaXN0LnBvcCgpXG5cbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBsaXN0Lmxlbmd0aDsgaSsrKSB7XG4gICAgdHJ5IHtcbiAgICAgIHB1c2godGhpcywgdGhpcy5tYXBwZXIobGlzdFtpXSkpXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHJldHVybiBjYihlcnJvcilcbiAgICB9XG4gIH1cblxuICB0aGlzLm92ZXJmbG93ID0gdGhpc1trTGFzdF0ubGVuZ3RoID4gdGhpcy5tYXhMZW5ndGhcbiAgaWYgKHRoaXMub3ZlcmZsb3cgJiYgIXRoaXMuc2tpcE92ZXJmbG93KSByZXR1cm4gY2IobmV3IEVycm9yKCdtYXhpbXVtIGJ1ZmZlciByZWFjaGVkJykpXG5cbiAgY2IoKVxufVxuXG5mdW5jdGlvbiBmbHVzaCAoY2IpIHtcbiAgLy8gZm9yd2FyZCBhbnkgZ2liYmVyaXNoIGxlZnQgaW4gdGhlcmVcbiAgdGhpc1trTGFzdF0gKz0gdGhpc1trRGVjb2Rlcl0uZW5kKClcblxuICBpZiAodGhpc1trTGFzdF0pIHtcbiAgICB0cnkge1xuICAgICAgcHVzaCh0aGlzLCB0aGlzLm1hcHBlcih0aGlzW2tMYXN0XSkpXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHJldHVybiBjYihlcnJvcilcbiAgICB9XG4gIH1cblxuICBjYigpXG59XG5cbmZ1bmN0aW9uIHB1c2ggKHNlbGYsIHZhbCkge1xuICBpZiAodmFsICE9PSB1bmRlZmluZWQpIHtcbiAgICBzZWxmLnB1c2godmFsKVxuICB9XG59XG5cbmZ1bmN0aW9uIG5vb3AgKGluY29taW5nKSB7XG4gIHJldHVybiBpbmNvbWluZ1xufVxuXG5mdW5jdGlvbiBzcGxpdCAobWF0Y2hlciwgbWFwcGVyLCBvcHRpb25zKSB7XG4gIC8vIFNldCBkZWZhdWx0cyBmb3IgYW55IGFyZ3VtZW50cyBub3Qgc3VwcGxpZWQuXG4gIG1hdGNoZXIgPSBtYXRjaGVyIHx8IC9cXHI/XFxuL1xuICBtYXBwZXIgPSBtYXBwZXIgfHwgbm9vcFxuICBvcHRpb25zID0gb3B0aW9ucyB8fCB7fVxuXG4gIC8vIFRlc3QgYXJndW1lbnRzIGV4cGxpY2l0bHkuXG4gIHN3aXRjaCAoYXJndW1lbnRzLmxlbmd0aCkge1xuICAgIGNhc2UgMTpcbiAgICAgIC8vIElmIG1hcHBlciBpcyBvbmx5IGFyZ3VtZW50LlxuICAgICAgaWYgKHR5cGVvZiBtYXRjaGVyID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIG1hcHBlciA9IG1hdGNoZXJcbiAgICAgICAgbWF0Y2hlciA9IC9cXHI/XFxuL1xuICAgICAgLy8gSWYgb3B0aW9ucyBpcyBvbmx5IGFyZ3VtZW50LlxuICAgICAgfSBlbHNlIGlmICh0eXBlb2YgbWF0Y2hlciA9PT0gJ29iamVjdCcgJiYgIShtYXRjaGVyIGluc3RhbmNlb2YgUmVnRXhwKSkge1xuICAgICAgICBvcHRpb25zID0gbWF0Y2hlclxuICAgICAgICBtYXRjaGVyID0gL1xccj9cXG4vXG4gICAgICB9XG4gICAgICBicmVha1xuXG4gICAgY2FzZSAyOlxuICAgICAgLy8gSWYgbWFwcGVyIGFuZCBvcHRpb25zIGFyZSBhcmd1bWVudHMuXG4gICAgICBpZiAodHlwZW9mIG1hdGNoZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgb3B0aW9ucyA9IG1hcHBlclxuICAgICAgICBtYXBwZXIgPSBtYXRjaGVyXG4gICAgICAgIG1hdGNoZXIgPSAvXFxyP1xcbi9cbiAgICAgIC8vIElmIG1hdGNoZXIgYW5kIG9wdGlvbnMgYXJlIGFyZ3VtZW50cy5cbiAgICAgIH0gZWxzZSBpZiAodHlwZW9mIG1hcHBlciA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgb3B0aW9ucyA9IG1hcHBlclxuICAgICAgICBtYXBwZXIgPSBub29wXG4gICAgICB9XG4gIH1cblxuICBvcHRpb25zID0gT2JqZWN0LmFzc2lnbih7fSwgb3B0aW9ucylcbiAgb3B0aW9ucy50cmFuc2Zvcm0gPSB0cmFuc2Zvcm1cbiAgb3B0aW9ucy5mbHVzaCA9IGZsdXNoXG4gIG9wdGlvbnMucmVhZGFibGVPYmplY3RNb2RlID0gdHJ1ZVxuXG4gIGNvbnN0IHN0cmVhbSA9IG5ldyBUcmFuc2Zvcm0ob3B0aW9ucylcblxuICBzdHJlYW1ba0xhc3RdID0gJydcbiAgc3RyZWFtW2tEZWNvZGVyXSA9IG5ldyBTdHJpbmdEZWNvZGVyKCd1dGY4JylcbiAgc3RyZWFtLm1hdGNoZXIgPSBtYXRjaGVyXG4gIHN0cmVhbS5tYXBwZXIgPSBtYXBwZXJcbiAgc3RyZWFtLm1heExlbmd0aCA9IG9wdGlvbnMubWF4TGVuZ3RoXG4gIHN0cmVhbS5za2lwT3ZlcmZsb3cgPSBvcHRpb25zLnNraXBPdmVyZmxvd1xuICBzdHJlYW0ub3ZlcmZsb3cgPSBmYWxzZVxuXG4gIHJldHVybiBzdHJlYW1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSBzcGxpdFxuIiwiLy8gQ29weXJpZ2h0IEpveWVudCwgSW5jLiBhbmQgb3RoZXIgTm9kZSBjb250cmlidXRvcnMuXG4vL1xuLy8gUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb24gb2J0YWluaW5nIGFcbi8vIGNvcHkgb2YgdGhpcyBzb2Z0d2FyZSBhbmQgYXNzb2NpYXRlZCBkb2N1bWVudGF0aW9uIGZpbGVzICh0aGVcbi8vIFwiU29mdHdhcmVcIiksIHRvIGRlYWwgaW4gdGhlIFNvZnR3YXJlIHdpdGhvdXQgcmVzdHJpY3Rpb24sIGluY2x1ZGluZ1xuLy8gd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMgdG8gdXNlLCBjb3B5LCBtb2RpZnksIG1lcmdlLCBwdWJsaXNoLFxuLy8gZGlzdHJpYnV0ZSwgc3VibGljZW5zZSwgYW5kL29yIHNlbGwgY29waWVzIG9mIHRoZSBTb2Z0d2FyZSwgYW5kIHRvIHBlcm1pdFxuLy8gcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpcyBmdXJuaXNoZWQgdG8gZG8gc28sIHN1YmplY3QgdG8gdGhlXG4vLyBmb2xsb3dpbmcgY29uZGl0aW9uczpcbi8vXG4vLyBUaGUgYWJvdmUgY29weXJpZ2h0IG5vdGljZSBhbmQgdGhpcyBwZXJtaXNzaW9uIG5vdGljZSBzaGFsbCBiZSBpbmNsdWRlZFxuLy8gaW4gYWxsIGNvcGllcyBvciBzdWJzdGFudGlhbCBwb3J0aW9ucyBvZiB0aGUgU29mdHdhcmUuXG4vL1xuLy8gVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiwgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCwgRVhQUkVTU1xuLy8gT1IgSU1QTElFRCwgSU5DTFVESU5HIEJVVCBOT1QgTElNSVRFRCBUTyBUSEUgV0FSUkFOVElFUyBPRlxuLy8gTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTlxuLy8gTk8gRVZFTlQgU0hBTEwgVEhFIEFVVEhPUlMgT1IgQ09QWVJJR0hUIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTlkgQ0xBSU0sXG4vLyBEQU1BR0VTIE9SIE9USEVSIExJQUJJTElUWSwgV0hFVEhFUiBJTiBBTiBBQ1RJT04gT0YgQ09OVFJBQ1QsIFRPUlQgT1Jcbi8vIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRSBTT0ZUV0FSRSBPUiBUSEVcbi8vIFVTRSBPUiBPVEhFUiBERUFMSU5HUyBJTiBUSEUgU09GVFdBUkUuXG5cbid1c2Ugc3RyaWN0JztcblxuLyo8cmVwbGFjZW1lbnQ+Ki9cblxudmFyIEJ1ZmZlciA9IHJlcXVpcmUoJ3NhZmUtYnVmZmVyJykuQnVmZmVyO1xuLyo8L3JlcGxhY2VtZW50PiovXG5cbnZhciBpc0VuY29kaW5nID0gQnVmZmVyLmlzRW5jb2RpbmcgfHwgZnVuY3Rpb24gKGVuY29kaW5nKSB7XG4gIGVuY29kaW5nID0gJycgKyBlbmNvZGluZztcbiAgc3dpdGNoIChlbmNvZGluZyAmJiBlbmNvZGluZy50b0xvd2VyQ2FzZSgpKSB7XG4gICAgY2FzZSAnaGV4JzpjYXNlICd1dGY4JzpjYXNlICd1dGYtOCc6Y2FzZSAnYXNjaWknOmNhc2UgJ2JpbmFyeSc6Y2FzZSAnYmFzZTY0JzpjYXNlICd1Y3MyJzpjYXNlICd1Y3MtMic6Y2FzZSAndXRmMTZsZSc6Y2FzZSAndXRmLTE2bGUnOmNhc2UgJ3Jhdyc6XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIGZhbHNlO1xuICB9XG59O1xuXG5mdW5jdGlvbiBfbm9ybWFsaXplRW5jb2RpbmcoZW5jKSB7XG4gIGlmICghZW5jKSByZXR1cm4gJ3V0ZjgnO1xuICB2YXIgcmV0cmllZDtcbiAgd2hpbGUgKHRydWUpIHtcbiAgICBzd2l0Y2ggKGVuYykge1xuICAgICAgY2FzZSAndXRmOCc6XG4gICAgICBjYXNlICd1dGYtOCc6XG4gICAgICAgIHJldHVybiAndXRmOCc7XG4gICAgICBjYXNlICd1Y3MyJzpcbiAgICAgIGNhc2UgJ3Vjcy0yJzpcbiAgICAgIGNhc2UgJ3V0ZjE2bGUnOlxuICAgICAgY2FzZSAndXRmLTE2bGUnOlxuICAgICAgICByZXR1cm4gJ3V0ZjE2bGUnO1xuICAgICAgY2FzZSAnbGF0aW4xJzpcbiAgICAgIGNhc2UgJ2JpbmFyeSc6XG4gICAgICAgIHJldHVybiAnbGF0aW4xJztcbiAgICAgIGNhc2UgJ2Jhc2U2NCc6XG4gICAgICBjYXNlICdhc2NpaSc6XG4gICAgICBjYXNlICdoZXgnOlxuICAgICAgICByZXR1cm4gZW5jO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgaWYgKHJldHJpZWQpIHJldHVybjsgLy8gdW5kZWZpbmVkXG4gICAgICAgIGVuYyA9ICgnJyArIGVuYykudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgcmV0cmllZCA9IHRydWU7XG4gICAgfVxuICB9XG59O1xuXG4vLyBEbyBub3QgY2FjaGUgYEJ1ZmZlci5pc0VuY29kaW5nYCB3aGVuIGNoZWNraW5nIGVuY29kaW5nIG5hbWVzIGFzIHNvbWVcbi8vIG1vZHVsZXMgbW9ua2V5LXBhdGNoIGl0IHRvIHN1cHBvcnQgYWRkaXRpb25hbCBlbmNvZGluZ3NcbmZ1bmN0aW9uIG5vcm1hbGl6ZUVuY29kaW5nKGVuYykge1xuICB2YXIgbmVuYyA9IF9ub3JtYWxpemVFbmNvZGluZyhlbmMpO1xuICBpZiAodHlwZW9mIG5lbmMgIT09ICdzdHJpbmcnICYmIChCdWZmZXIuaXNFbmNvZGluZyA9PT0gaXNFbmNvZGluZyB8fCAhaXNFbmNvZGluZyhlbmMpKSkgdGhyb3cgbmV3IEVycm9yKCdVbmtub3duIGVuY29kaW5nOiAnICsgZW5jKTtcbiAgcmV0dXJuIG5lbmMgfHwgZW5jO1xufVxuXG4vLyBTdHJpbmdEZWNvZGVyIHByb3ZpZGVzIGFuIGludGVyZmFjZSBmb3IgZWZmaWNpZW50bHkgc3BsaXR0aW5nIGEgc2VyaWVzIG9mXG4vLyBidWZmZXJzIGludG8gYSBzZXJpZXMgb2YgSlMgc3RyaW5ncyB3aXRob3V0IGJyZWFraW5nIGFwYXJ0IG11bHRpLWJ5dGVcbi8vIGNoYXJhY3RlcnMuXG5leHBvcnRzLlN0cmluZ0RlY29kZXIgPSBTdHJpbmdEZWNvZGVyO1xuZnVuY3Rpb24gU3RyaW5nRGVjb2RlcihlbmNvZGluZykge1xuICB0aGlzLmVuY29kaW5nID0gbm9ybWFsaXplRW5jb2RpbmcoZW5jb2RpbmcpO1xuICB2YXIgbmI7XG4gIHN3aXRjaCAodGhpcy5lbmNvZGluZykge1xuICAgIGNhc2UgJ3V0ZjE2bGUnOlxuICAgICAgdGhpcy50ZXh0ID0gdXRmMTZUZXh0O1xuICAgICAgdGhpcy5lbmQgPSB1dGYxNkVuZDtcbiAgICAgIG5iID0gNDtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ3V0ZjgnOlxuICAgICAgdGhpcy5maWxsTGFzdCA9IHV0ZjhGaWxsTGFzdDtcbiAgICAgIG5iID0gNDtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2Jhc2U2NCc6XG4gICAgICB0aGlzLnRleHQgPSBiYXNlNjRUZXh0O1xuICAgICAgdGhpcy5lbmQgPSBiYXNlNjRFbmQ7XG4gICAgICBuYiA9IDM7XG4gICAgICBicmVhaztcbiAgICBkZWZhdWx0OlxuICAgICAgdGhpcy53cml0ZSA9IHNpbXBsZVdyaXRlO1xuICAgICAgdGhpcy5lbmQgPSBzaW1wbGVFbmQ7XG4gICAgICByZXR1cm47XG4gIH1cbiAgdGhpcy5sYXN0TmVlZCA9IDA7XG4gIHRoaXMubGFzdFRvdGFsID0gMDtcbiAgdGhpcy5sYXN0Q2hhciA9IEJ1ZmZlci5hbGxvY1Vuc2FmZShuYik7XG59XG5cblN0cmluZ0RlY29kZXIucHJvdG90eXBlLndyaXRlID0gZnVuY3Rpb24gKGJ1Zikge1xuICBpZiAoYnVmLmxlbmd0aCA9PT0gMCkgcmV0dXJuICcnO1xuICB2YXIgcjtcbiAgdmFyIGk7XG4gIGlmICh0aGlzLmxhc3ROZWVkKSB7XG4gICAgciA9IHRoaXMuZmlsbExhc3QoYnVmKTtcbiAgICBpZiAociA9PT0gdW5kZWZpbmVkKSByZXR1cm4gJyc7XG4gICAgaSA9IHRoaXMubGFzdE5lZWQ7XG4gICAgdGhpcy5sYXN0TmVlZCA9IDA7XG4gIH0gZWxzZSB7XG4gICAgaSA9IDA7XG4gIH1cbiAgaWYgKGkgPCBidWYubGVuZ3RoKSByZXR1cm4gciA/IHIgKyB0aGlzLnRleHQoYnVmLCBpKSA6IHRoaXMudGV4dChidWYsIGkpO1xuICByZXR1cm4gciB8fCAnJztcbn07XG5cblN0cmluZ0RlY29kZXIucHJvdG90eXBlLmVuZCA9IHV0ZjhFbmQ7XG5cbi8vIFJldHVybnMgb25seSBjb21wbGV0ZSBjaGFyYWN0ZXJzIGluIGEgQnVmZmVyXG5TdHJpbmdEZWNvZGVyLnByb3RvdHlwZS50ZXh0ID0gdXRmOFRleHQ7XG5cbi8vIEF0dGVtcHRzIHRvIGNvbXBsZXRlIGEgcGFydGlhbCBub24tVVRGLTggY2hhcmFjdGVyIHVzaW5nIGJ5dGVzIGZyb20gYSBCdWZmZXJcblN0cmluZ0RlY29kZXIucHJvdG90eXBlLmZpbGxMYXN0ID0gZnVuY3Rpb24gKGJ1Zikge1xuICBpZiAodGhpcy5sYXN0TmVlZCA8PSBidWYubGVuZ3RoKSB7XG4gICAgYnVmLmNvcHkodGhpcy5sYXN0Q2hhciwgdGhpcy5sYXN0VG90YWwgLSB0aGlzLmxhc3ROZWVkLCAwLCB0aGlzLmxhc3ROZWVkKTtcbiAgICByZXR1cm4gdGhpcy5sYXN0Q2hhci50b1N0cmluZyh0aGlzLmVuY29kaW5nLCAwLCB0aGlzLmxhc3RUb3RhbCk7XG4gIH1cbiAgYnVmLmNvcHkodGhpcy5sYXN0Q2hhciwgdGhpcy5sYXN0VG90YWwgLSB0aGlzLmxhc3ROZWVkLCAwLCBidWYubGVuZ3RoKTtcbiAgdGhpcy5sYXN0TmVlZCAtPSBidWYubGVuZ3RoO1xufTtcblxuLy8gQ2hlY2tzIHRoZSB0eXBlIG9mIGEgVVRGLTggYnl0ZSwgd2hldGhlciBpdCdzIEFTQ0lJLCBhIGxlYWRpbmcgYnl0ZSwgb3IgYVxuLy8gY29udGludWF0aW9uIGJ5dGUuIElmIGFuIGludmFsaWQgYnl0ZSBpcyBkZXRlY3RlZCwgLTIgaXMgcmV0dXJuZWQuXG5mdW5jdGlvbiB1dGY4Q2hlY2tCeXRlKGJ5dGUpIHtcbiAgaWYgKGJ5dGUgPD0gMHg3RikgcmV0dXJuIDA7ZWxzZSBpZiAoYnl0ZSA+PiA1ID09PSAweDA2KSByZXR1cm4gMjtlbHNlIGlmIChieXRlID4+IDQgPT09IDB4MEUpIHJldHVybiAzO2Vsc2UgaWYgKGJ5dGUgPj4gMyA9PT0gMHgxRSkgcmV0dXJuIDQ7XG4gIHJldHVybiBieXRlID4+IDYgPT09IDB4MDIgPyAtMSA6IC0yO1xufVxuXG4vLyBDaGVja3MgYXQgbW9zdCAzIGJ5dGVzIGF0IHRoZSBlbmQgb2YgYSBCdWZmZXIgaW4gb3JkZXIgdG8gZGV0ZWN0IGFuXG4vLyBpbmNvbXBsZXRlIG11bHRpLWJ5dGUgVVRGLTggY2hhcmFjdGVyLiBUaGUgdG90YWwgbnVtYmVyIG9mIGJ5dGVzICgyLCAzLCBvciA0KVxuLy8gbmVlZGVkIHRvIGNvbXBsZXRlIHRoZSBVVEYtOCBjaGFyYWN0ZXIgKGlmIGFwcGxpY2FibGUpIGFyZSByZXR1cm5lZC5cbmZ1bmN0aW9uIHV0ZjhDaGVja0luY29tcGxldGUoc2VsZiwgYnVmLCBpKSB7XG4gIHZhciBqID0gYnVmLmxlbmd0aCAtIDE7XG4gIGlmIChqIDwgaSkgcmV0dXJuIDA7XG4gIHZhciBuYiA9IHV0ZjhDaGVja0J5dGUoYnVmW2pdKTtcbiAgaWYgKG5iID49IDApIHtcbiAgICBpZiAobmIgPiAwKSBzZWxmLmxhc3ROZWVkID0gbmIgLSAxO1xuICAgIHJldHVybiBuYjtcbiAgfVxuICBpZiAoLS1qIDwgaSB8fCBuYiA9PT0gLTIpIHJldHVybiAwO1xuICBuYiA9IHV0ZjhDaGVja0J5dGUoYnVmW2pdKTtcbiAgaWYgKG5iID49IDApIHtcbiAgICBpZiAobmIgPiAwKSBzZWxmLmxhc3ROZWVkID0gbmIgLSAyO1xuICAgIHJldHVybiBuYjtcbiAgfVxuICBpZiAoLS1qIDwgaSB8fCBuYiA9PT0gLTIpIHJldHVybiAwO1xuICBuYiA9IHV0ZjhDaGVja0J5dGUoYnVmW2pdKTtcbiAgaWYgKG5iID49IDApIHtcbiAgICBpZiAobmIgPiAwKSB7XG4gICAgICBpZiAobmIgPT09IDIpIG5iID0gMDtlbHNlIHNlbGYubGFzdE5lZWQgPSBuYiAtIDM7XG4gICAgfVxuICAgIHJldHVybiBuYjtcbiAgfVxuICByZXR1cm4gMDtcbn1cblxuLy8gVmFsaWRhdGVzIGFzIG1hbnkgY29udGludWF0aW9uIGJ5dGVzIGZvciBhIG11bHRpLWJ5dGUgVVRGLTggY2hhcmFjdGVyIGFzXG4vLyBuZWVkZWQgb3IgYXJlIGF2YWlsYWJsZS4gSWYgd2Ugc2VlIGEgbm9uLWNvbnRpbnVhdGlvbiBieXRlIHdoZXJlIHdlIGV4cGVjdFxuLy8gb25lLCB3ZSBcInJlcGxhY2VcIiB0aGUgdmFsaWRhdGVkIGNvbnRpbnVhdGlvbiBieXRlcyB3ZSd2ZSBzZWVuIHNvIGZhciB3aXRoXG4vLyBhIHNpbmdsZSBVVEYtOCByZXBsYWNlbWVudCBjaGFyYWN0ZXIgKCdcXHVmZmZkJyksIHRvIG1hdGNoIHY4J3MgVVRGLTggZGVjb2Rpbmdcbi8vIGJlaGF2aW9yLiBUaGUgY29udGludWF0aW9uIGJ5dGUgY2hlY2sgaXMgaW5jbHVkZWQgdGhyZWUgdGltZXMgaW4gdGhlIGNhc2Vcbi8vIHdoZXJlIGFsbCBvZiB0aGUgY29udGludWF0aW9uIGJ5dGVzIGZvciBhIGNoYXJhY3RlciBleGlzdCBpbiB0aGUgc2FtZSBidWZmZXIuXG4vLyBJdCBpcyBhbHNvIGRvbmUgdGhpcyB3YXkgYXMgYSBzbGlnaHQgcGVyZm9ybWFuY2UgaW5jcmVhc2UgaW5zdGVhZCBvZiB1c2luZyBhXG4vLyBsb29wLlxuZnVuY3Rpb24gdXRmOENoZWNrRXh0cmFCeXRlcyhzZWxmLCBidWYsIHApIHtcbiAgaWYgKChidWZbMF0gJiAweEMwKSAhPT0gMHg4MCkge1xuICAgIHNlbGYubGFzdE5lZWQgPSAwO1xuICAgIHJldHVybiAnXFx1ZmZmZCc7XG4gIH1cbiAgaWYgKHNlbGYubGFzdE5lZWQgPiAxICYmIGJ1Zi5sZW5ndGggPiAxKSB7XG4gICAgaWYgKChidWZbMV0gJiAweEMwKSAhPT0gMHg4MCkge1xuICAgICAgc2VsZi5sYXN0TmVlZCA9IDE7XG4gICAgICByZXR1cm4gJ1xcdWZmZmQnO1xuICAgIH1cbiAgICBpZiAoc2VsZi5sYXN0TmVlZCA+IDIgJiYgYnVmLmxlbmd0aCA+IDIpIHtcbiAgICAgIGlmICgoYnVmWzJdICYgMHhDMCkgIT09IDB4ODApIHtcbiAgICAgICAgc2VsZi5sYXN0TmVlZCA9IDI7XG4gICAgICAgIHJldHVybiAnXFx1ZmZmZCc7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbi8vIEF0dGVtcHRzIHRvIGNvbXBsZXRlIGEgbXVsdGktYnl0ZSBVVEYtOCBjaGFyYWN0ZXIgdXNpbmcgYnl0ZXMgZnJvbSBhIEJ1ZmZlci5cbmZ1bmN0aW9uIHV0ZjhGaWxsTGFzdChidWYpIHtcbiAgdmFyIHAgPSB0aGlzLmxhc3RUb3RhbCAtIHRoaXMubGFzdE5lZWQ7XG4gIHZhciByID0gdXRmOENoZWNrRXh0cmFCeXRlcyh0aGlzLCBidWYsIHApO1xuICBpZiAociAhPT0gdW5kZWZpbmVkKSByZXR1cm4gcjtcbiAgaWYgKHRoaXMubGFzdE5lZWQgPD0gYnVmLmxlbmd0aCkge1xuICAgIGJ1Zi5jb3B5KHRoaXMubGFzdENoYXIsIHAsIDAsIHRoaXMubGFzdE5lZWQpO1xuICAgIHJldHVybiB0aGlzLmxhc3RDaGFyLnRvU3RyaW5nKHRoaXMuZW5jb2RpbmcsIDAsIHRoaXMubGFzdFRvdGFsKTtcbiAgfVxuICBidWYuY29weSh0aGlzLmxhc3RDaGFyLCBwLCAwLCBidWYubGVuZ3RoKTtcbiAgdGhpcy5sYXN0TmVlZCAtPSBidWYubGVuZ3RoO1xufVxuXG4vLyBSZXR1cm5zIGFsbCBjb21wbGV0ZSBVVEYtOCBjaGFyYWN0ZXJzIGluIGEgQnVmZmVyLiBJZiB0aGUgQnVmZmVyIGVuZGVkIG9uIGFcbi8vIHBhcnRpYWwgY2hhcmFjdGVyLCB0aGUgY2hhcmFjdGVyJ3MgYnl0ZXMgYXJlIGJ1ZmZlcmVkIHVudGlsIHRoZSByZXF1aXJlZFxuLy8gbnVtYmVyIG9mIGJ5dGVzIGFyZSBhdmFpbGFibGUuXG5mdW5jdGlvbiB1dGY4VGV4dChidWYsIGkpIHtcbiAgdmFyIHRvdGFsID0gdXRmOENoZWNrSW5jb21wbGV0ZSh0aGlzLCBidWYsIGkpO1xuICBpZiAoIXRoaXMubGFzdE5lZWQpIHJldHVybiBidWYudG9TdHJpbmcoJ3V0ZjgnLCBpKTtcbiAgdGhpcy5sYXN0VG90YWwgPSB0b3RhbDtcbiAgdmFyIGVuZCA9IGJ1Zi5sZW5ndGggLSAodG90YWwgLSB0aGlzLmxhc3ROZWVkKTtcbiAgYnVmLmNvcHkodGhpcy5sYXN0Q2hhciwgMCwgZW5kKTtcbiAgcmV0dXJuIGJ1Zi50b1N0cmluZygndXRmOCcsIGksIGVuZCk7XG59XG5cbi8vIEZvciBVVEYtOCwgYSByZXBsYWNlbWVudCBjaGFyYWN0ZXIgaXMgYWRkZWQgd2hlbiBlbmRpbmcgb24gYSBwYXJ0aWFsXG4vLyBjaGFyYWN0ZXIuXG5mdW5jdGlvbiB1dGY4RW5kKGJ1Zikge1xuICB2YXIgciA9IGJ1ZiAmJiBidWYubGVuZ3RoID8gdGhpcy53cml0ZShidWYpIDogJyc7XG4gIGlmICh0aGlzLmxhc3ROZWVkKSByZXR1cm4gciArICdcXHVmZmZkJztcbiAgcmV0dXJuIHI7XG59XG5cbi8vIFVURi0xNkxFIHR5cGljYWxseSBuZWVkcyB0d28gYnl0ZXMgcGVyIGNoYXJhY3RlciwgYnV0IGV2ZW4gaWYgd2UgaGF2ZSBhbiBldmVuXG4vLyBudW1iZXIgb2YgYnl0ZXMgYXZhaWxhYmxlLCB3ZSBuZWVkIHRvIGNoZWNrIGlmIHdlIGVuZCBvbiBhIGxlYWRpbmcvaGlnaFxuLy8gc3Vycm9nYXRlLiBJbiB0aGF0IGNhc2UsIHdlIG5lZWQgdG8gd2FpdCBmb3IgdGhlIG5leHQgdHdvIGJ5dGVzIGluIG9yZGVyIHRvXG4vLyBkZWNvZGUgdGhlIGxhc3QgY2hhcmFjdGVyIHByb3Blcmx5LlxuZnVuY3Rpb24gdXRmMTZUZXh0KGJ1ZiwgaSkge1xuICBpZiAoKGJ1Zi5sZW5ndGggLSBpKSAlIDIgPT09IDApIHtcbiAgICB2YXIgciA9IGJ1Zi50b1N0cmluZygndXRmMTZsZScsIGkpO1xuICAgIGlmIChyKSB7XG4gICAgICB2YXIgYyA9IHIuY2hhckNvZGVBdChyLmxlbmd0aCAtIDEpO1xuICAgICAgaWYgKGMgPj0gMHhEODAwICYmIGMgPD0gMHhEQkZGKSB7XG4gICAgICAgIHRoaXMubGFzdE5lZWQgPSAyO1xuICAgICAgICB0aGlzLmxhc3RUb3RhbCA9IDQ7XG4gICAgICAgIHRoaXMubGFzdENoYXJbMF0gPSBidWZbYnVmLmxlbmd0aCAtIDJdO1xuICAgICAgICB0aGlzLmxhc3RDaGFyWzFdID0gYnVmW2J1Zi5sZW5ndGggLSAxXTtcbiAgICAgICAgcmV0dXJuIHIuc2xpY2UoMCwgLTEpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcjtcbiAgfVxuICB0aGlzLmxhc3ROZWVkID0gMTtcbiAgdGhpcy5sYXN0VG90YWwgPSAyO1xuICB0aGlzLmxhc3RDaGFyWzBdID0gYnVmW2J1Zi5sZW5ndGggLSAxXTtcbiAgcmV0dXJuIGJ1Zi50b1N0cmluZygndXRmMTZsZScsIGksIGJ1Zi5sZW5ndGggLSAxKTtcbn1cblxuLy8gRm9yIFVURi0xNkxFIHdlIGRvIG5vdCBleHBsaWNpdGx5IGFwcGVuZCBzcGVjaWFsIHJlcGxhY2VtZW50IGNoYXJhY3RlcnMgaWYgd2Vcbi8vIGVuZCBvbiBhIHBhcnRpYWwgY2hhcmFjdGVyLCB3ZSBzaW1wbHkgbGV0IHY4IGhhbmRsZSB0aGF0LlxuZnVuY3Rpb24gdXRmMTZFbmQoYnVmKSB7XG4gIHZhciByID0gYnVmICYmIGJ1Zi5sZW5ndGggPyB0aGlzLndyaXRlKGJ1ZikgOiAnJztcbiAgaWYgKHRoaXMubGFzdE5lZWQpIHtcbiAgICB2YXIgZW5kID0gdGhpcy5sYXN0VG90YWwgLSB0aGlzLmxhc3ROZWVkO1xuICAgIHJldHVybiByICsgdGhpcy5sYXN0Q2hhci50b1N0cmluZygndXRmMTZsZScsIDAsIGVuZCk7XG4gIH1cbiAgcmV0dXJuIHI7XG59XG5cbmZ1bmN0aW9uIGJhc2U2NFRleHQoYnVmLCBpKSB7XG4gIHZhciBuID0gKGJ1Zi5sZW5ndGggLSBpKSAlIDM7XG4gIGlmIChuID09PSAwKSByZXR1cm4gYnVmLnRvU3RyaW5nKCdiYXNlNjQnLCBpKTtcbiAgdGhpcy5sYXN0TmVlZCA9IDMgLSBuO1xuICB0aGlzLmxhc3RUb3RhbCA9IDM7XG4gIGlmIChuID09PSAxKSB7XG4gICAgdGhpcy5sYXN0Q2hhclswXSA9IGJ1ZltidWYubGVuZ3RoIC0gMV07XG4gIH0gZWxzZSB7XG4gICAgdGhpcy5sYXN0Q2hhclswXSA9IGJ1ZltidWYubGVuZ3RoIC0gMl07XG4gICAgdGhpcy5sYXN0Q2hhclsxXSA9IGJ1ZltidWYubGVuZ3RoIC0gMV07XG4gIH1cbiAgcmV0dXJuIGJ1Zi50b1N0cmluZygnYmFzZTY0JywgaSwgYnVmLmxlbmd0aCAtIG4pO1xufVxuXG5mdW5jdGlvbiBiYXNlNjRFbmQoYnVmKSB7XG4gIHZhciByID0gYnVmICYmIGJ1Zi5sZW5ndGggPyB0aGlzLndyaXRlKGJ1ZikgOiAnJztcbiAgaWYgKHRoaXMubGFzdE5lZWQpIHJldHVybiByICsgdGhpcy5sYXN0Q2hhci50b1N0cmluZygnYmFzZTY0JywgMCwgMyAtIHRoaXMubGFzdE5lZWQpO1xuICByZXR1cm4gcjtcbn1cblxuLy8gUGFzcyBieXRlcyBvbiB0aHJvdWdoIGZvciBzaW5nbGUtYnl0ZSBlbmNvZGluZ3MgKGUuZy4gYXNjaWksIGxhdGluMSwgaGV4KVxuZnVuY3Rpb24gc2ltcGxlV3JpdGUoYnVmKSB7XG4gIHJldHVybiBidWYudG9TdHJpbmcodGhpcy5lbmNvZGluZyk7XG59XG5cbmZ1bmN0aW9uIHNpbXBsZUVuZChidWYpIHtcbiAgcmV0dXJuIGJ1ZiAmJiBidWYubGVuZ3RoID8gdGhpcy53cml0ZShidWYpIDogJyc7XG59IiwiXG4vKipcbiAqIEZvciBOb2RlLmpzLCBzaW1wbHkgcmUtZXhwb3J0IHRoZSBjb3JlIGB1dGlsLmRlcHJlY2F0ZWAgZnVuY3Rpb24uXG4gKi9cblxubW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCd1dGlsJykuZGVwcmVjYXRlO1xuIiwibW9kdWxlLmV4cG9ydHMgPSBleHRlbmRcblxudmFyIGhhc093blByb3BlcnR5ID0gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eTtcblxuZnVuY3Rpb24gZXh0ZW5kKHRhcmdldCkge1xuICAgIGZvciAodmFyIGkgPSAxOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHZhciBzb3VyY2UgPSBhcmd1bWVudHNbaV1cblxuICAgICAgICBmb3IgKHZhciBrZXkgaW4gc291cmNlKSB7XG4gICAgICAgICAgICBpZiAoaGFzT3duUHJvcGVydHkuY2FsbChzb3VyY2UsIGtleSkpIHtcbiAgICAgICAgICAgICAgICB0YXJnZXRba2V5XSA9IHNvdXJjZVtrZXldXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gdGFyZ2V0XG59XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJhc3NlcnRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiYnVmZmVyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImNyeXB0b1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJkbnNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiZXZlbnRzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImZzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5ldFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJwYXRoXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInN0cmVhbVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJzdHJpbmdfZGVjb2RlclwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJ0bHNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwidXJsXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInV0aWxcIik7IiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsIi8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb25zIGZvciBoYXJtb255IGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uZCA9IChleHBvcnRzLCBkZWZpbml0aW9uKSA9PiB7XG5cdGZvcih2YXIga2V5IGluIGRlZmluaXRpb24pIHtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZGVmaW5pdGlvbiwga2V5KSAmJiAhX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIGtleSkpIHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBkZWZpbml0aW9uW2tleV0gfSk7XG5cdFx0fVxuXHR9XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCIvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSAoZXhwb3J0cykgPT4ge1xuXHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xufTsiLCIiLCIvLyBzdGFydHVwXG4vLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbi8vIFRoaXMgZW50cnkgbW9kdWxlIGRvZXNuJ3QgdGVsbCBhYm91dCBpdCdzIHRvcC1sZXZlbCBkZWNsYXJhdGlvbnMgc28gaXQgY2FuJ3QgYmUgaW5saW5lZFxudmFyIF9fd2VicGFja19leHBvcnRzX18gPSBfX3dlYnBhY2tfcmVxdWlyZV9fKDk4ODkpO1xuIiwiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9