/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 5035:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "handler": () => (/* binding */ handler)
});

;// CONCATENATED MODULE: ./lambdas/db/products.json
const products_namespaceObject = JSON.parse('[{"count":1,"description":"desc 1","id":"7567ec4b-b10c-48c5-9345-fc73c48a80aa","price":2.4,"title":"guitar 1"},{"count":2,"description":"desc 2","id":"7567ec4b-b10c-48c5-9345-fc73c48a80a0","price":10,"title":"guitar 2"},{"count":3,"description":"desc 3","id":"7567ec4b-b10c-48c5-9345-fc73c48a80a2","price":23,"title":"guitar 3"},{"count":4,"description":"desc 4","id":"7567ec4b-b10c-48c5-9345-fc73c48a80a1","price":15,"title":"guitar 4"},{"count":5,"description":"desc 5","id":"7567ec4b-b10c-48c5-9345-fc73c48a80a3","price":23,"title":"guitar 5"},{"count":6,"description":"desc 6","id":"7567ec4b-b10c-48c5-9345-fc73348a80a1","price":15,"title":"guitar 6"},{"count":7,"description":"desc 7","id":"7567ec4b-b10c-48c5-9445-fc73c48a80a2","price":23,"title":"guitar 7"},{"count":8,"description":"desc 8","id":"7567ec4b-b10c-45c5-9345-fc73c48a80a1","price":15,"title":"guitar 8"}]');
// EXTERNAL MODULE: ./node_modules/pg/lib/index.js
var lib = __webpack_require__(8955);
;// CONCATENATED MODULE: ./conection.js



const { PG_HOST, PG_PORT, PG_DATABASE, PG_USERNAME, PG_PASSWORD } = process.env;
const dbOptions = {
    host: PG_HOST,
    port: PG_PORT,
    database: PG_DATABASE,
    user: PG_USERNAME,
    password: PG_PASSWORD,
    ssl: {
        rejectUnauthorized: false,
    },
    connectionTimeoutMillis: 5000,
};
class ConnectDB {
    constructor() {
        this.client = new lib.Client(dbOptions);
    }

    async connect() {
        await this.client.connect();
        return this.client;
    }

    async disconnect() {
        await this.client.end();
    }

    async createTable(tableName, config) {
        await this.client.query(`
  create table if not exist ${tableName} (
    ${config}
  )`);
    }


    async getList(tableName) {
        const { rows } = await this.client.query(select * from `${tableName}`);
        return rows;
    }
}
;// CONCATENATED MODULE: ./lambdas/getProductsById.js




const handler = async (event) => {
    const { productId } = event.pathParameters || {};
    const getProduct = products_namespaceObject.find((item, id) => {
        return item.id == productId;
    });
    const db = new ConnectDB();

    try {
        const client = await db.connect();

        const { rows } = await client.query(`select products.*, stock.count from products left join stock on products.id = stock.product_id where products.id='${productId}'`);
        return {
            headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Methods': '*',
                    'Access-Control-Allow-Origin': '*',
                  },
                statusCode: 200,
                body: JSON.stringify(rows)
            };
    } catch (error) {

    return {
        headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Origin': '*',
              },
            statusCode: 404,
            body: JSON.stringify({ message: error.message })
        };
    } finally {
        db.disconnect();
    }
    // const response = {
    //     headers: {
    //         'Content-Type': 'application/json',
    //         'Access-Control-Allow-Methods': '*',
    //         'Access-Control-Allow-Origin': '*',
    //       },
    //     statusCode: 200,
    // }
    // if (!getProduct)   { 
    //     response.body =  JSON.stringify({ message: 'Error: Product not found!' });

    //     response.statusCode = 404;
    // } else {
    //     response.body = JSON.stringify(getProduct); 
    // }
    // return response;
}

/***/ }),

/***/ 4378:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

try {
  var util = __webpack_require__(1669);
  /* istanbul ignore next */
  if (typeof util.inherits !== 'function') throw '';
  module.exports = util.inherits;
} catch (e) {
  /* istanbul ignore next */
  module.exports = __webpack_require__(5717);
}


/***/ }),

/***/ 5717:
/***/ ((module) => {

if (typeof Object.create === 'function') {
  // implementation from standard node.js 'util' module
  module.exports = function inherits(ctor, superCtor) {
    if (superCtor) {
      ctor.super_ = superCtor
      ctor.prototype = Object.create(superCtor.prototype, {
        constructor: {
          value: ctor,
          enumerable: false,
          writable: true,
          configurable: true
        }
      })
    }
  };
} else {
  // old school shim for old browsers
  module.exports = function inherits(ctor, superCtor) {
    if (superCtor) {
      ctor.super_ = superCtor
      var TempCtor = function () {}
      TempCtor.prototype = superCtor.prototype
      ctor.prototype = new TempCtor()
      ctor.prototype.constructor = ctor
    }
  }
}


/***/ }),

/***/ 5697:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var url = __webpack_require__(8835)
var fs = __webpack_require__(5747)

//Parse method copied from https://github.com/brianc/node-postgres
//Copyright (c) 2010-2014 Brian Carlson (brian.m.carlson@gmail.com)
//MIT License

//parses a connection string
function parse(str) {
  //unix socket
  if (str.charAt(0) === '/') {
    var config = str.split(' ')
    return { host: config[0], database: config[1] }
  }

  // url parse expects spaces encoded as %20
  var result = url.parse(
    / |%[^a-f0-9]|%[a-f0-9][^a-f0-9]/i.test(str) ? encodeURI(str).replace(/\%25(\d\d)/g, '%$1') : str,
    true
  )
  var config = result.query
  for (var k in config) {
    if (Array.isArray(config[k])) {
      config[k] = config[k][config[k].length - 1]
    }
  }

  var auth = (result.auth || ':').split(':')
  config.user = auth[0]
  config.password = auth.splice(1).join(':')

  config.port = result.port
  if (result.protocol == 'socket:') {
    config.host = decodeURI(result.pathname)
    config.database = result.query.db
    config.client_encoding = result.query.encoding
    return config
  }
  if (!config.host) {
    // Only set the host if there is no equivalent query param.
    config.host = result.hostname
  }

  // If the host is missing it might be a URL-encoded path to a socket.
  var pathname = result.pathname
  if (!config.host && pathname && /^%2f/i.test(pathname)) {
    var pathnameSplit = pathname.split('/')
    config.host = decodeURIComponent(pathnameSplit[0])
    pathname = pathnameSplit.splice(1).join('/')
  }
  // result.pathname is not always guaranteed to have a '/' prefix (e.g. relative urls)
  // only strip the slash if it is present.
  if (pathname && pathname.charAt(0) === '/') {
    pathname = pathname.slice(1) || null
  }
  config.database = pathname && decodeURI(pathname)

  if (config.ssl === 'true' || config.ssl === '1') {
    config.ssl = true
  }

  if (config.ssl === '0') {
    config.ssl = false
  }

  if (config.sslcert || config.sslkey || config.sslrootcert || config.sslmode) {
    config.ssl = {}
  }

  if (config.sslcert) {
    config.ssl.cert = fs.readFileSync(config.sslcert).toString()
  }

  if (config.sslkey) {
    config.ssl.key = fs.readFileSync(config.sslkey).toString()
  }

  if (config.sslrootcert) {
    config.ssl.ca = fs.readFileSync(config.sslrootcert).toString()
  }

  switch (config.sslmode) {
    case 'disable': {
      config.ssl = false
      break
    }
    case 'prefer':
    case 'require':
    case 'verify-ca':
    case 'verify-full': {
      break
    }
    case 'no-verify': {
      config.ssl.rejectUnauthorized = false
      break
    }
  }

  return config
}

module.exports = parse

parse.parse = parse


/***/ }),

/***/ 6064:
/***/ ((module) => {

"use strict";


// selected so (BASE - 1) * 0x100000000 + 0xffffffff is a safe integer
var BASE = 1000000;

function readInt8(buffer) {
	var high = buffer.readInt32BE(0);
	var low = buffer.readUInt32BE(4);
	var sign = '';

	if (high < 0) {
		high = ~high + (low === 0);
		low = (~low + 1) >>> 0;
		sign = '-';
	}

	var result = '';
	var carry;
	var t;
	var digits;
	var pad;
	var l;
	var i;

	{
		carry = high % BASE;
		high = high / BASE >>> 0;

		t = 0x100000000 * carry + low;
		low = t / BASE >>> 0;
		digits = '' + (t - BASE * low);

		if (low === 0 && high === 0) {
			return sign + digits + result;
		}

		pad = '';
		l = 6 - digits.length;

		for (i = 0; i < l; i++) {
			pad += '0';
		}

		result = pad + digits + result;
	}

	{
		carry = high % BASE;
		high = high / BASE >>> 0;

		t = 0x100000000 * carry + low;
		low = t / BASE >>> 0;
		digits = '' + (t - BASE * low);

		if (low === 0 && high === 0) {
			return sign + digits + result;
		}

		pad = '';
		l = 6 - digits.length;

		for (i = 0; i < l; i++) {
			pad += '0';
		}

		result = pad + digits + result;
	}

	{
		carry = high % BASE;
		high = high / BASE >>> 0;

		t = 0x100000000 * carry + low;
		low = t / BASE >>> 0;
		digits = '' + (t - BASE * low);

		if (low === 0 && high === 0) {
			return sign + digits + result;
		}

		pad = '';
		l = 6 - digits.length;

		for (i = 0; i < l; i++) {
			pad += '0';
		}

		result = pad + digits + result;
	}

	{
		carry = high % BASE;
		t = 0x100000000 * carry + low;
		digits = '' + t % BASE;

		return sign + digits + result;
	}
}

module.exports = readInt8;


/***/ }),

/***/ 5546:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

const EventEmitter = __webpack_require__(8614).EventEmitter

const NOOP = function () {}

const removeWhere = (list, predicate) => {
  const i = list.findIndex(predicate)

  return i === -1 ? undefined : list.splice(i, 1)[0]
}

class IdleItem {
  constructor(client, idleListener, timeoutId) {
    this.client = client
    this.idleListener = idleListener
    this.timeoutId = timeoutId
  }
}

class PendingItem {
  constructor(callback) {
    this.callback = callback
  }
}

function throwOnDoubleRelease() {
  throw new Error('Release called on client which has already been released to the pool.')
}

function promisify(Promise, callback) {
  if (callback) {
    return { callback: callback, result: undefined }
  }
  let rej
  let res
  const cb = function (err, client) {
    err ? rej(err) : res(client)
  }
  const result = new Promise(function (resolve, reject) {
    res = resolve
    rej = reject
  })
  return { callback: cb, result: result }
}

function makeIdleListener(pool, client) {
  return function idleListener(err) {
    err.client = client

    client.removeListener('error', idleListener)
    client.on('error', () => {
      pool.log('additional client error after disconnection due to error', err)
    })
    pool._remove(client)
    // TODO - document that once the pool emits an error
    // the client has already been closed & purged and is unusable
    pool.emit('error', err, client)
  }
}

class Pool extends EventEmitter {
  constructor(options, Client) {
    super()
    this.options = Object.assign({}, options)

    if (options != null && 'password' in options) {
      // "hiding" the password so it doesn't show up in stack traces
      // or if the client is console.logged
      Object.defineProperty(this.options, 'password', {
        configurable: true,
        enumerable: false,
        writable: true,
        value: options.password,
      })
    }
    if (options != null && options.ssl && options.ssl.key) {
      // "hiding" the ssl->key so it doesn't show up in stack traces
      // or if the client is console.logged
      Object.defineProperty(this.options.ssl, 'key', {
        enumerable: false,
      })
    }

    this.options.max = this.options.max || this.options.poolSize || 10
    this.options.maxUses = this.options.maxUses || Infinity
    this.options.allowExitOnIdle = this.options.allowExitOnIdle || false
    this.log = this.options.log || function () {}
    this.Client = this.options.Client || Client || __webpack_require__(8955).Client
    this.Promise = this.options.Promise || global.Promise

    if (typeof this.options.idleTimeoutMillis === 'undefined') {
      this.options.idleTimeoutMillis = 10000
    }

    this._clients = []
    this._idle = []
    this._pendingQueue = []
    this._endCallback = undefined
    this.ending = false
    this.ended = false
  }

  _isFull() {
    return this._clients.length >= this.options.max
  }

  _pulseQueue() {
    this.log('pulse queue')
    if (this.ended) {
      this.log('pulse queue ended')
      return
    }
    if (this.ending) {
      this.log('pulse queue on ending')
      if (this._idle.length) {
        this._idle.slice().map((item) => {
          this._remove(item.client)
        })
      }
      if (!this._clients.length) {
        this.ended = true
        this._endCallback()
      }
      return
    }
    // if we don't have any waiting, do nothing
    if (!this._pendingQueue.length) {
      this.log('no queued requests')
      return
    }
    // if we don't have any idle clients and we have no more room do nothing
    if (!this._idle.length && this._isFull()) {
      return
    }
    const pendingItem = this._pendingQueue.shift()
    if (this._idle.length) {
      const idleItem = this._idle.pop()
      clearTimeout(idleItem.timeoutId)
      const client = idleItem.client
      client.ref && client.ref()
      const idleListener = idleItem.idleListener

      return this._acquireClient(client, pendingItem, idleListener, false)
    }
    if (!this._isFull()) {
      return this.newClient(pendingItem)
    }
    throw new Error('unexpected condition')
  }

  _remove(client) {
    const removed = removeWhere(this._idle, (item) => item.client === client)

    if (removed !== undefined) {
      clearTimeout(removed.timeoutId)
    }

    this._clients = this._clients.filter((c) => c !== client)
    client.end()
    this.emit('remove', client)
  }

  connect(cb) {
    if (this.ending) {
      const err = new Error('Cannot use a pool after calling end on the pool')
      return cb ? cb(err) : this.Promise.reject(err)
    }

    const response = promisify(this.Promise, cb)
    const result = response.result

    // if we don't have to connect a new client, don't do so
    if (this._isFull() || this._idle.length) {
      // if we have idle clients schedule a pulse immediately
      if (this._idle.length) {
        process.nextTick(() => this._pulseQueue())
      }

      if (!this.options.connectionTimeoutMillis) {
        this._pendingQueue.push(new PendingItem(response.callback))
        return result
      }

      const queueCallback = (err, res, done) => {
        clearTimeout(tid)
        response.callback(err, res, done)
      }

      const pendingItem = new PendingItem(queueCallback)

      // set connection timeout on checking out an existing client
      const tid = setTimeout(() => {
        // remove the callback from pending waiters because
        // we're going to call it with a timeout error
        removeWhere(this._pendingQueue, (i) => i.callback === queueCallback)
        pendingItem.timedOut = true
        response.callback(new Error('timeout exceeded when trying to connect'))
      }, this.options.connectionTimeoutMillis)

      this._pendingQueue.push(pendingItem)
      return result
    }

    this.newClient(new PendingItem(response.callback))

    return result
  }

  newClient(pendingItem) {
    const client = new this.Client(this.options)
    this._clients.push(client)
    const idleListener = makeIdleListener(this, client)

    this.log('checking client timeout')

    // connection timeout logic
    let tid
    let timeoutHit = false
    if (this.options.connectionTimeoutMillis) {
      tid = setTimeout(() => {
        this.log('ending client due to timeout')
        timeoutHit = true
        // force kill the node driver, and let libpq do its teardown
        client.connection ? client.connection.stream.destroy() : client.end()
      }, this.options.connectionTimeoutMillis)
    }

    this.log('connecting new client')
    client.connect((err) => {
      if (tid) {
        clearTimeout(tid)
      }
      client.on('error', idleListener)
      if (err) {
        this.log('client failed to connect', err)
        // remove the dead client from our list of clients
        this._clients = this._clients.filter((c) => c !== client)
        if (timeoutHit) {
          err.message = 'Connection terminated due to connection timeout'
        }

        // this client won’t be released, so move on immediately
        this._pulseQueue()

        if (!pendingItem.timedOut) {
          pendingItem.callback(err, undefined, NOOP)
        }
      } else {
        this.log('new client connected')

        return this._acquireClient(client, pendingItem, idleListener, true)
      }
    })
  }

  // acquire a client for a pending work item
  _acquireClient(client, pendingItem, idleListener, isNew) {
    if (isNew) {
      this.emit('connect', client)
    }

    this.emit('acquire', client)

    client.release = this._releaseOnce(client, idleListener)

    client.removeListener('error', idleListener)

    if (!pendingItem.timedOut) {
      if (isNew && this.options.verify) {
        this.options.verify(client, (err) => {
          if (err) {
            client.release(err)
            return pendingItem.callback(err, undefined, NOOP)
          }

          pendingItem.callback(undefined, client, client.release)
        })
      } else {
        pendingItem.callback(undefined, client, client.release)
      }
    } else {
      if (isNew && this.options.verify) {
        this.options.verify(client, client.release)
      } else {
        client.release()
      }
    }
  }

  // returns a function that wraps _release and throws if called more than once
  _releaseOnce(client, idleListener) {
    let released = false

    return (err) => {
      if (released) {
        throwOnDoubleRelease()
      }

      released = true
      this._release(client, idleListener, err)
    }
  }

  // release a client back to the poll, include an error
  // to remove it from the pool
  _release(client, idleListener, err) {
    client.on('error', idleListener)

    client._poolUseCount = (client._poolUseCount || 0) + 1

    // TODO(bmc): expose a proper, public interface _queryable and _ending
    if (err || this.ending || !client._queryable || client._ending || client._poolUseCount >= this.options.maxUses) {
      if (client._poolUseCount >= this.options.maxUses) {
        this.log('remove expended client')
      }
      this._remove(client)
      this._pulseQueue()
      return
    }

    // idle timeout
    let tid
    if (this.options.idleTimeoutMillis) {
      tid = setTimeout(() => {
        this.log('remove idle client')
        this._remove(client)
      }, this.options.idleTimeoutMillis)

      if (this.options.allowExitOnIdle) {
        // allow Node to exit if this is all that's left
        tid.unref()
      }
    }

    if (this.options.allowExitOnIdle) {
      client.unref()
    }

    this._idle.push(new IdleItem(client, idleListener, tid))
    this._pulseQueue()
  }

  query(text, values, cb) {
    // guard clause against passing a function as the first parameter
    if (typeof text === 'function') {
      const response = promisify(this.Promise, text)
      setImmediate(function () {
        return response.callback(new Error('Passing a function as the first parameter to pool.query is not supported'))
      })
      return response.result
    }

    // allow plain text query without values
    if (typeof values === 'function') {
      cb = values
      values = undefined
    }
    const response = promisify(this.Promise, cb)
    cb = response.callback

    this.connect((err, client) => {
      if (err) {
        return cb(err)
      }

      let clientReleased = false
      const onError = (err) => {
        if (clientReleased) {
          return
        }
        clientReleased = true
        client.release(err)
        cb(err)
      }

      client.once('error', onError)
      this.log('dispatching query')
      client.query(text, values, (err, res) => {
        this.log('query dispatched')
        client.removeListener('error', onError)
        if (clientReleased) {
          return
        }
        clientReleased = true
        client.release(err)
        if (err) {
          return cb(err)
        } else {
          return cb(undefined, res)
        }
      })
    })
    return response.result
  }

  end(cb) {
    this.log('ending')
    if (this.ending) {
      const err = new Error('Called end on pool more than once')
      return cb ? cb(err) : this.Promise.reject(err)
    }
    this.ending = true
    const promised = promisify(this.Promise, cb)
    this._endCallback = promised.callback
    this._pulseQueue()
    return promised.result
  }

  get waitingCount() {
    return this._pendingQueue.length
  }

  get idleCount() {
    return this._idle.length
  }

  get totalCount() {
    return this._clients.length
  }
}
module.exports = Pool


/***/ }),

/***/ 1144:
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BufferReader = void 0;
const emptyBuffer = Buffer.allocUnsafe(0);
class BufferReader {
    constructor(offset = 0) {
        this.offset = offset;
        this.buffer = emptyBuffer;
        // TODO(bmc): support non-utf8 encoding?
        this.encoding = 'utf-8';
    }
    setBuffer(offset, buffer) {
        this.offset = offset;
        this.buffer = buffer;
    }
    int16() {
        const result = this.buffer.readInt16BE(this.offset);
        this.offset += 2;
        return result;
    }
    byte() {
        const result = this.buffer[this.offset];
        this.offset++;
        return result;
    }
    int32() {
        const result = this.buffer.readInt32BE(this.offset);
        this.offset += 4;
        return result;
    }
    string(length) {
        const result = this.buffer.toString(this.encoding, this.offset, this.offset + length);
        this.offset += length;
        return result;
    }
    cstring() {
        const start = this.offset;
        let end = start;
        while (this.buffer[end++] !== 0) { }
        this.offset = end;
        return this.buffer.toString(this.encoding, start, end - 1);
    }
    bytes(length) {
        const result = this.buffer.slice(this.offset, this.offset + length);
        this.offset += length;
        return result;
    }
}
exports.BufferReader = BufferReader;
//# sourceMappingURL=buffer-reader.js.map

/***/ }),

/***/ 246:
/***/ ((__unused_webpack_module, exports) => {

"use strict";

//binary data writer tuned for encoding binary specific to the postgres binary protocol
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Writer = void 0;
class Writer {
    constructor(size = 256) {
        this.size = size;
        this.offset = 5;
        this.headerPosition = 0;
        this.buffer = Buffer.allocUnsafe(size);
    }
    ensure(size) {
        var remaining = this.buffer.length - this.offset;
        if (remaining < size) {
            var oldBuffer = this.buffer;
            // exponential growth factor of around ~ 1.5
            // https://stackoverflow.com/questions/2269063/buffer-growth-strategy
            var newSize = oldBuffer.length + (oldBuffer.length >> 1) + size;
            this.buffer = Buffer.allocUnsafe(newSize);
            oldBuffer.copy(this.buffer);
        }
    }
    addInt32(num) {
        this.ensure(4);
        this.buffer[this.offset++] = (num >>> 24) & 0xff;
        this.buffer[this.offset++] = (num >>> 16) & 0xff;
        this.buffer[this.offset++] = (num >>> 8) & 0xff;
        this.buffer[this.offset++] = (num >>> 0) & 0xff;
        return this;
    }
    addInt16(num) {
        this.ensure(2);
        this.buffer[this.offset++] = (num >>> 8) & 0xff;
        this.buffer[this.offset++] = (num >>> 0) & 0xff;
        return this;
    }
    addCString(string) {
        if (!string) {
            this.ensure(1);
        }
        else {
            var len = Buffer.byteLength(string);
            this.ensure(len + 1); // +1 for null terminator
            this.buffer.write(string, this.offset, 'utf-8');
            this.offset += len;
        }
        this.buffer[this.offset++] = 0; // null terminator
        return this;
    }
    addString(string = '') {
        var len = Buffer.byteLength(string);
        this.ensure(len);
        this.buffer.write(string, this.offset);
        this.offset += len;
        return this;
    }
    add(otherBuffer) {
        this.ensure(otherBuffer.length);
        otherBuffer.copy(this.buffer, this.offset);
        this.offset += otherBuffer.length;
        return this;
    }
    join(code) {
        if (code) {
            this.buffer[this.headerPosition] = code;
            //length is everything in this packet minus the code
            const length = this.offset - (this.headerPosition + 1);
            this.buffer.writeInt32BE(length, this.headerPosition + 1);
        }
        return this.buffer.slice(code ? 0 : 5, this.offset);
    }
    flush(code) {
        var result = this.join(code);
        this.offset = 5;
        this.headerPosition = 0;
        this.buffer = Buffer.allocUnsafe(this.size);
        return result;
    }
}
exports.Writer = Writer;
//# sourceMappingURL=buffer-writer.js.map

/***/ }),

/***/ 8152:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DatabaseError = exports.serialize = exports.parse = void 0;
const messages_1 = __webpack_require__(2510);
Object.defineProperty(exports, "DatabaseError", ({ enumerable: true, get: function () { return messages_1.DatabaseError; } }));
const serializer_1 = __webpack_require__(9209);
Object.defineProperty(exports, "serialize", ({ enumerable: true, get: function () { return serializer_1.serialize; } }));
const parser_1 = __webpack_require__(946);
function parse(stream, callback) {
    const parser = new parser_1.Parser();
    stream.on('data', (buffer) => parser.parse(buffer, callback));
    return new Promise((resolve) => stream.on('end', () => resolve()));
}
exports.parse = parse;
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 2510:
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.NoticeMessage = exports.DataRowMessage = exports.CommandCompleteMessage = exports.ReadyForQueryMessage = exports.NotificationResponseMessage = exports.BackendKeyDataMessage = exports.AuthenticationMD5Password = exports.ParameterStatusMessage = exports.ParameterDescriptionMessage = exports.RowDescriptionMessage = exports.Field = exports.CopyResponse = exports.CopyDataMessage = exports.DatabaseError = exports.copyDone = exports.emptyQuery = exports.replicationStart = exports.portalSuspended = exports.noData = exports.closeComplete = exports.bindComplete = exports.parseComplete = void 0;
exports.parseComplete = {
    name: 'parseComplete',
    length: 5,
};
exports.bindComplete = {
    name: 'bindComplete',
    length: 5,
};
exports.closeComplete = {
    name: 'closeComplete',
    length: 5,
};
exports.noData = {
    name: 'noData',
    length: 5,
};
exports.portalSuspended = {
    name: 'portalSuspended',
    length: 5,
};
exports.replicationStart = {
    name: 'replicationStart',
    length: 4,
};
exports.emptyQuery = {
    name: 'emptyQuery',
    length: 4,
};
exports.copyDone = {
    name: 'copyDone',
    length: 4,
};
class DatabaseError extends Error {
    constructor(message, length, name) {
        super(message);
        this.length = length;
        this.name = name;
    }
}
exports.DatabaseError = DatabaseError;
class CopyDataMessage {
    constructor(length, chunk) {
        this.length = length;
        this.chunk = chunk;
        this.name = 'copyData';
    }
}
exports.CopyDataMessage = CopyDataMessage;
class CopyResponse {
    constructor(length, name, binary, columnCount) {
        this.length = length;
        this.name = name;
        this.binary = binary;
        this.columnTypes = new Array(columnCount);
    }
}
exports.CopyResponse = CopyResponse;
class Field {
    constructor(name, tableID, columnID, dataTypeID, dataTypeSize, dataTypeModifier, format) {
        this.name = name;
        this.tableID = tableID;
        this.columnID = columnID;
        this.dataTypeID = dataTypeID;
        this.dataTypeSize = dataTypeSize;
        this.dataTypeModifier = dataTypeModifier;
        this.format = format;
    }
}
exports.Field = Field;
class RowDescriptionMessage {
    constructor(length, fieldCount) {
        this.length = length;
        this.fieldCount = fieldCount;
        this.name = 'rowDescription';
        this.fields = new Array(this.fieldCount);
    }
}
exports.RowDescriptionMessage = RowDescriptionMessage;
class ParameterDescriptionMessage {
    constructor(length, parameterCount) {
        this.length = length;
        this.parameterCount = parameterCount;
        this.name = 'parameterDescription';
        this.dataTypeIDs = new Array(this.parameterCount);
    }
}
exports.ParameterDescriptionMessage = ParameterDescriptionMessage;
class ParameterStatusMessage {
    constructor(length, parameterName, parameterValue) {
        this.length = length;
        this.parameterName = parameterName;
        this.parameterValue = parameterValue;
        this.name = 'parameterStatus';
    }
}
exports.ParameterStatusMessage = ParameterStatusMessage;
class AuthenticationMD5Password {
    constructor(length, salt) {
        this.length = length;
        this.salt = salt;
        this.name = 'authenticationMD5Password';
    }
}
exports.AuthenticationMD5Password = AuthenticationMD5Password;
class BackendKeyDataMessage {
    constructor(length, processID, secretKey) {
        this.length = length;
        this.processID = processID;
        this.secretKey = secretKey;
        this.name = 'backendKeyData';
    }
}
exports.BackendKeyDataMessage = BackendKeyDataMessage;
class NotificationResponseMessage {
    constructor(length, processId, channel, payload) {
        this.length = length;
        this.processId = processId;
        this.channel = channel;
        this.payload = payload;
        this.name = 'notification';
    }
}
exports.NotificationResponseMessage = NotificationResponseMessage;
class ReadyForQueryMessage {
    constructor(length, status) {
        this.length = length;
        this.status = status;
        this.name = 'readyForQuery';
    }
}
exports.ReadyForQueryMessage = ReadyForQueryMessage;
class CommandCompleteMessage {
    constructor(length, text) {
        this.length = length;
        this.text = text;
        this.name = 'commandComplete';
    }
}
exports.CommandCompleteMessage = CommandCompleteMessage;
class DataRowMessage {
    constructor(length, fields) {
        this.length = length;
        this.fields = fields;
        this.name = 'dataRow';
        this.fieldCount = fields.length;
    }
}
exports.DataRowMessage = DataRowMessage;
class NoticeMessage {
    constructor(length, message) {
        this.length = length;
        this.message = message;
        this.name = 'notice';
    }
}
exports.NoticeMessage = NoticeMessage;
//# sourceMappingURL=messages.js.map

/***/ }),

/***/ 946:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Parser = void 0;
const messages_1 = __webpack_require__(2510);
const buffer_reader_1 = __webpack_require__(1144);
const assert_1 = __importDefault(__webpack_require__(2357));
// every message is prefixed with a single bye
const CODE_LENGTH = 1;
// every message has an int32 length which includes itself but does
// NOT include the code in the length
const LEN_LENGTH = 4;
const HEADER_LENGTH = CODE_LENGTH + LEN_LENGTH;
const emptyBuffer = Buffer.allocUnsafe(0);
class Parser {
    constructor(opts) {
        this.buffer = emptyBuffer;
        this.bufferLength = 0;
        this.bufferOffset = 0;
        this.reader = new buffer_reader_1.BufferReader();
        if ((opts === null || opts === void 0 ? void 0 : opts.mode) === 'binary') {
            throw new Error('Binary mode not supported yet');
        }
        this.mode = (opts === null || opts === void 0 ? void 0 : opts.mode) || 'text';
    }
    parse(buffer, callback) {
        this.mergeBuffer(buffer);
        const bufferFullLength = this.bufferOffset + this.bufferLength;
        let offset = this.bufferOffset;
        while (offset + HEADER_LENGTH <= bufferFullLength) {
            // code is 1 byte long - it identifies the message type
            const code = this.buffer[offset];
            // length is 1 Uint32BE - it is the length of the message EXCLUDING the code
            const length = this.buffer.readUInt32BE(offset + CODE_LENGTH);
            const fullMessageLength = CODE_LENGTH + length;
            if (fullMessageLength + offset <= bufferFullLength) {
                const message = this.handlePacket(offset + HEADER_LENGTH, code, length, this.buffer);
                callback(message);
                offset += fullMessageLength;
            }
            else {
                break;
            }
        }
        if (offset === bufferFullLength) {
            // No more use for the buffer
            this.buffer = emptyBuffer;
            this.bufferLength = 0;
            this.bufferOffset = 0;
        }
        else {
            // Adjust the cursors of remainingBuffer
            this.bufferLength = bufferFullLength - offset;
            this.bufferOffset = offset;
        }
    }
    mergeBuffer(buffer) {
        if (this.bufferLength > 0) {
            const newLength = this.bufferLength + buffer.byteLength;
            const newFullLength = newLength + this.bufferOffset;
            if (newFullLength > this.buffer.byteLength) {
                // We can't concat the new buffer with the remaining one
                let newBuffer;
                if (newLength <= this.buffer.byteLength && this.bufferOffset >= this.bufferLength) {
                    // We can move the relevant part to the beginning of the buffer instead of allocating a new buffer
                    newBuffer = this.buffer;
                }
                else {
                    // Allocate a new larger buffer
                    let newBufferLength = this.buffer.byteLength * 2;
                    while (newLength >= newBufferLength) {
                        newBufferLength *= 2;
                    }
                    newBuffer = Buffer.allocUnsafe(newBufferLength);
                }
                // Move the remaining buffer to the new one
                this.buffer.copy(newBuffer, 0, this.bufferOffset, this.bufferOffset + this.bufferLength);
                this.buffer = newBuffer;
                this.bufferOffset = 0;
            }
            // Concat the new buffer with the remaining one
            buffer.copy(this.buffer, this.bufferOffset + this.bufferLength);
            this.bufferLength = newLength;
        }
        else {
            this.buffer = buffer;
            this.bufferOffset = 0;
            this.bufferLength = buffer.byteLength;
        }
    }
    handlePacket(offset, code, length, bytes) {
        switch (code) {
            case 50 /* BindComplete */:
                return messages_1.bindComplete;
            case 49 /* ParseComplete */:
                return messages_1.parseComplete;
            case 51 /* CloseComplete */:
                return messages_1.closeComplete;
            case 110 /* NoData */:
                return messages_1.noData;
            case 115 /* PortalSuspended */:
                return messages_1.portalSuspended;
            case 99 /* CopyDone */:
                return messages_1.copyDone;
            case 87 /* ReplicationStart */:
                return messages_1.replicationStart;
            case 73 /* EmptyQuery */:
                return messages_1.emptyQuery;
            case 68 /* DataRow */:
                return this.parseDataRowMessage(offset, length, bytes);
            case 67 /* CommandComplete */:
                return this.parseCommandCompleteMessage(offset, length, bytes);
            case 90 /* ReadyForQuery */:
                return this.parseReadyForQueryMessage(offset, length, bytes);
            case 65 /* NotificationResponse */:
                return this.parseNotificationMessage(offset, length, bytes);
            case 82 /* AuthenticationResponse */:
                return this.parseAuthenticationResponse(offset, length, bytes);
            case 83 /* ParameterStatus */:
                return this.parseParameterStatusMessage(offset, length, bytes);
            case 75 /* BackendKeyData */:
                return this.parseBackendKeyData(offset, length, bytes);
            case 69 /* ErrorMessage */:
                return this.parseErrorMessage(offset, length, bytes, 'error');
            case 78 /* NoticeMessage */:
                return this.parseErrorMessage(offset, length, bytes, 'notice');
            case 84 /* RowDescriptionMessage */:
                return this.parseRowDescriptionMessage(offset, length, bytes);
            case 116 /* ParameterDescriptionMessage */:
                return this.parseParameterDescriptionMessage(offset, length, bytes);
            case 71 /* CopyIn */:
                return this.parseCopyInMessage(offset, length, bytes);
            case 72 /* CopyOut */:
                return this.parseCopyOutMessage(offset, length, bytes);
            case 100 /* CopyData */:
                return this.parseCopyData(offset, length, bytes);
            default:
                assert_1.default.fail(`unknown message code: ${code.toString(16)}`);
        }
    }
    parseReadyForQueryMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const status = this.reader.string(1);
        return new messages_1.ReadyForQueryMessage(length, status);
    }
    parseCommandCompleteMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const text = this.reader.cstring();
        return new messages_1.CommandCompleteMessage(length, text);
    }
    parseCopyData(offset, length, bytes) {
        const chunk = bytes.slice(offset, offset + (length - 4));
        return new messages_1.CopyDataMessage(length, chunk);
    }
    parseCopyInMessage(offset, length, bytes) {
        return this.parseCopyMessage(offset, length, bytes, 'copyInResponse');
    }
    parseCopyOutMessage(offset, length, bytes) {
        return this.parseCopyMessage(offset, length, bytes, 'copyOutResponse');
    }
    parseCopyMessage(offset, length, bytes, messageName) {
        this.reader.setBuffer(offset, bytes);
        const isBinary = this.reader.byte() !== 0;
        const columnCount = this.reader.int16();
        const message = new messages_1.CopyResponse(length, messageName, isBinary, columnCount);
        for (let i = 0; i < columnCount; i++) {
            message.columnTypes[i] = this.reader.int16();
        }
        return message;
    }
    parseNotificationMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const processId = this.reader.int32();
        const channel = this.reader.cstring();
        const payload = this.reader.cstring();
        return new messages_1.NotificationResponseMessage(length, processId, channel, payload);
    }
    parseRowDescriptionMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const fieldCount = this.reader.int16();
        const message = new messages_1.RowDescriptionMessage(length, fieldCount);
        for (let i = 0; i < fieldCount; i++) {
            message.fields[i] = this.parseField();
        }
        return message;
    }
    parseField() {
        const name = this.reader.cstring();
        const tableID = this.reader.int32();
        const columnID = this.reader.int16();
        const dataTypeID = this.reader.int32();
        const dataTypeSize = this.reader.int16();
        const dataTypeModifier = this.reader.int32();
        const mode = this.reader.int16() === 0 ? 'text' : 'binary';
        return new messages_1.Field(name, tableID, columnID, dataTypeID, dataTypeSize, dataTypeModifier, mode);
    }
    parseParameterDescriptionMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const parameterCount = this.reader.int16();
        const message = new messages_1.ParameterDescriptionMessage(length, parameterCount);
        for (let i = 0; i < parameterCount; i++) {
            message.dataTypeIDs[i] = this.reader.int32();
        }
        return message;
    }
    parseDataRowMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const fieldCount = this.reader.int16();
        const fields = new Array(fieldCount);
        for (let i = 0; i < fieldCount; i++) {
            const len = this.reader.int32();
            // a -1 for length means the value of the field is null
            fields[i] = len === -1 ? null : this.reader.string(len);
        }
        return new messages_1.DataRowMessage(length, fields);
    }
    parseParameterStatusMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const name = this.reader.cstring();
        const value = this.reader.cstring();
        return new messages_1.ParameterStatusMessage(length, name, value);
    }
    parseBackendKeyData(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const processID = this.reader.int32();
        const secretKey = this.reader.int32();
        return new messages_1.BackendKeyDataMessage(length, processID, secretKey);
    }
    parseAuthenticationResponse(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const code = this.reader.int32();
        // TODO(bmc): maybe better types here
        const message = {
            name: 'authenticationOk',
            length,
        };
        switch (code) {
            case 0: // AuthenticationOk
                break;
            case 3: // AuthenticationCleartextPassword
                if (message.length === 8) {
                    message.name = 'authenticationCleartextPassword';
                }
                break;
            case 5: // AuthenticationMD5Password
                if (message.length === 12) {
                    message.name = 'authenticationMD5Password';
                    const salt = this.reader.bytes(4);
                    return new messages_1.AuthenticationMD5Password(length, salt);
                }
                break;
            case 10: // AuthenticationSASL
                message.name = 'authenticationSASL';
                message.mechanisms = [];
                let mechanism;
                do {
                    mechanism = this.reader.cstring();
                    if (mechanism) {
                        message.mechanisms.push(mechanism);
                    }
                } while (mechanism);
                break;
            case 11: // AuthenticationSASLContinue
                message.name = 'authenticationSASLContinue';
                message.data = this.reader.string(length - 8);
                break;
            case 12: // AuthenticationSASLFinal
                message.name = 'authenticationSASLFinal';
                message.data = this.reader.string(length - 8);
                break;
            default:
                throw new Error('Unknown authenticationOk message type ' + code);
        }
        return message;
    }
    parseErrorMessage(offset, length, bytes, name) {
        this.reader.setBuffer(offset, bytes);
        const fields = {};
        let fieldType = this.reader.string(1);
        while (fieldType !== '\0') {
            fields[fieldType] = this.reader.cstring();
            fieldType = this.reader.string(1);
        }
        const messageValue = fields.M;
        const message = name === 'notice' ? new messages_1.NoticeMessage(length, messageValue) : new messages_1.DatabaseError(messageValue, length, name);
        message.severity = fields.S;
        message.code = fields.C;
        message.detail = fields.D;
        message.hint = fields.H;
        message.position = fields.P;
        message.internalPosition = fields.p;
        message.internalQuery = fields.q;
        message.where = fields.W;
        message.schema = fields.s;
        message.table = fields.t;
        message.column = fields.c;
        message.dataType = fields.d;
        message.constraint = fields.n;
        message.file = fields.F;
        message.line = fields.L;
        message.routine = fields.R;
        return message;
    }
}
exports.Parser = Parser;
//# sourceMappingURL=parser.js.map

/***/ }),

/***/ 9209:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.serialize = void 0;
const buffer_writer_1 = __webpack_require__(246);
const writer = new buffer_writer_1.Writer();
const startup = (opts) => {
    // protocol version
    writer.addInt16(3).addInt16(0);
    for (const key of Object.keys(opts)) {
        writer.addCString(key).addCString(opts[key]);
    }
    writer.addCString('client_encoding').addCString('UTF8');
    var bodyBuffer = writer.addCString('').flush();
    // this message is sent without a code
    var length = bodyBuffer.length + 4;
    return new buffer_writer_1.Writer().addInt32(length).add(bodyBuffer).flush();
};
const requestSsl = () => {
    const response = Buffer.allocUnsafe(8);
    response.writeInt32BE(8, 0);
    response.writeInt32BE(80877103, 4);
    return response;
};
const password = (password) => {
    return writer.addCString(password).flush(112 /* startup */);
};
const sendSASLInitialResponseMessage = function (mechanism, initialResponse) {
    // 0x70 = 'p'
    writer.addCString(mechanism).addInt32(Buffer.byteLength(initialResponse)).addString(initialResponse);
    return writer.flush(112 /* startup */);
};
const sendSCRAMClientFinalMessage = function (additionalData) {
    return writer.addString(additionalData).flush(112 /* startup */);
};
const query = (text) => {
    return writer.addCString(text).flush(81 /* query */);
};
const emptyArray = [];
const parse = (query) => {
    // expect something like this:
    // { name: 'queryName',
    //   text: 'select * from blah',
    //   types: ['int8', 'bool'] }
    // normalize missing query names to allow for null
    const name = query.name || '';
    if (name.length > 63) {
        /* eslint-disable no-console */
        console.error('Warning! Postgres only supports 63 characters for query names.');
        console.error('You supplied %s (%s)', name, name.length);
        console.error('This can cause conflicts and silent errors executing queries');
        /* eslint-enable no-console */
    }
    const types = query.types || emptyArray;
    var len = types.length;
    var buffer = writer
        .addCString(name) // name of query
        .addCString(query.text) // actual query text
        .addInt16(len);
    for (var i = 0; i < len; i++) {
        buffer.addInt32(types[i]);
    }
    return writer.flush(80 /* parse */);
};
const paramWriter = new buffer_writer_1.Writer();
const writeValues = function (values, valueMapper) {
    for (let i = 0; i < values.length; i++) {
        const mappedVal = valueMapper ? valueMapper(values[i], i) : values[i];
        if (mappedVal == null) {
            // add the param type (string) to the writer
            writer.addInt16(0 /* STRING */);
            // write -1 to the param writer to indicate null
            paramWriter.addInt32(-1);
        }
        else if (mappedVal instanceof Buffer) {
            // add the param type (binary) to the writer
            writer.addInt16(1 /* BINARY */);
            // add the buffer to the param writer
            paramWriter.addInt32(mappedVal.length);
            paramWriter.add(mappedVal);
        }
        else {
            // add the param type (string) to the writer
            writer.addInt16(0 /* STRING */);
            paramWriter.addInt32(Buffer.byteLength(mappedVal));
            paramWriter.addString(mappedVal);
        }
    }
};
const bind = (config = {}) => {
    // normalize config
    const portal = config.portal || '';
    const statement = config.statement || '';
    const binary = config.binary || false;
    const values = config.values || emptyArray;
    const len = values.length;
    writer.addCString(portal).addCString(statement);
    writer.addInt16(len);
    writeValues(values, config.valueMapper);
    writer.addInt16(len);
    writer.add(paramWriter.flush());
    // format code
    writer.addInt16(binary ? 1 /* BINARY */ : 0 /* STRING */);
    return writer.flush(66 /* bind */);
};
const emptyExecute = Buffer.from([69 /* execute */, 0x00, 0x00, 0x00, 0x09, 0x00, 0x00, 0x00, 0x00, 0x00]);
const execute = (config) => {
    // this is the happy path for most queries
    if (!config || (!config.portal && !config.rows)) {
        return emptyExecute;
    }
    const portal = config.portal || '';
    const rows = config.rows || 0;
    const portalLength = Buffer.byteLength(portal);
    const len = 4 + portalLength + 1 + 4;
    // one extra bit for code
    const buff = Buffer.allocUnsafe(1 + len);
    buff[0] = 69 /* execute */;
    buff.writeInt32BE(len, 1);
    buff.write(portal, 5, 'utf-8');
    buff[portalLength + 5] = 0; // null terminate portal cString
    buff.writeUInt32BE(rows, buff.length - 4);
    return buff;
};
const cancel = (processID, secretKey) => {
    const buffer = Buffer.allocUnsafe(16);
    buffer.writeInt32BE(16, 0);
    buffer.writeInt16BE(1234, 4);
    buffer.writeInt16BE(5678, 6);
    buffer.writeInt32BE(processID, 8);
    buffer.writeInt32BE(secretKey, 12);
    return buffer;
};
const cstringMessage = (code, string) => {
    const stringLen = Buffer.byteLength(string);
    const len = 4 + stringLen + 1;
    // one extra bit for code
    const buffer = Buffer.allocUnsafe(1 + len);
    buffer[0] = code;
    buffer.writeInt32BE(len, 1);
    buffer.write(string, 5, 'utf-8');
    buffer[len] = 0; // null terminate cString
    return buffer;
};
const emptyDescribePortal = writer.addCString('P').flush(68 /* describe */);
const emptyDescribeStatement = writer.addCString('S').flush(68 /* describe */);
const describe = (msg) => {
    return msg.name
        ? cstringMessage(68 /* describe */, `${msg.type}${msg.name || ''}`)
        : msg.type === 'P'
            ? emptyDescribePortal
            : emptyDescribeStatement;
};
const close = (msg) => {
    const text = `${msg.type}${msg.name || ''}`;
    return cstringMessage(67 /* close */, text);
};
const copyData = (chunk) => {
    return writer.add(chunk).flush(100 /* copyFromChunk */);
};
const copyFail = (message) => {
    return cstringMessage(102 /* copyFail */, message);
};
const codeOnlyBuffer = (code) => Buffer.from([code, 0x00, 0x00, 0x00, 0x04]);
const flushBuffer = codeOnlyBuffer(72 /* flush */);
const syncBuffer = codeOnlyBuffer(83 /* sync */);
const endBuffer = codeOnlyBuffer(88 /* end */);
const copyDoneBuffer = codeOnlyBuffer(99 /* copyDone */);
const serialize = {
    startup,
    password,
    requestSsl,
    sendSASLInitialResponseMessage,
    sendSCRAMClientFinalMessage,
    query,
    parse,
    bind,
    execute,
    describe,
    close,
    flush: () => flushBuffer,
    sync: () => syncBuffer,
    end: () => endBuffer,
    copyData,
    copyDone: () => copyDoneBuffer,
    copyFail,
    cancel,
};
exports.serialize = serialize;
//# sourceMappingURL=serializer.js.map

/***/ }),

/***/ 3619:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var textParsers = __webpack_require__(2980);
var binaryParsers = __webpack_require__(1931);
var arrayParser = __webpack_require__(6169);
var builtinTypes = __webpack_require__(8078);

exports.getTypeParser = getTypeParser;
exports.setTypeParser = setTypeParser;
exports.arrayParser = arrayParser;
exports.builtins = builtinTypes;

var typeParsers = {
  text: {},
  binary: {}
};

//the empty parse function
function noParse (val) {
  return String(val);
};

//returns a function used to convert a specific type (specified by
//oid) into a result javascript type
//note: the oid can be obtained via the following sql query:
//SELECT oid FROM pg_type WHERE typname = 'TYPE_NAME_HERE';
function getTypeParser (oid, format) {
  format = format || 'text';
  if (!typeParsers[format]) {
    return noParse;
  }
  return typeParsers[format][oid] || noParse;
};

function setTypeParser (oid, format, parseFn) {
  if(typeof format == 'function') {
    parseFn = format;
    format = 'text';
  }
  typeParsers[format][oid] = parseFn;
};

textParsers.init(function(oid, converter) {
  typeParsers.text[oid] = converter;
});

binaryParsers.init(function(oid, converter) {
  typeParsers.binary[oid] = converter;
});


/***/ }),

/***/ 6169:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var array = __webpack_require__(7315);

module.exports = {
  create: function (source, transform) {
    return {
      parse: function() {
        return array.parse(source, transform);
      }
    };
  }
};


/***/ }),

/***/ 1931:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var parseInt64 = __webpack_require__(6064);

var parseBits = function(data, bits, offset, invert, callback) {
  offset = offset || 0;
  invert = invert || false;
  callback = callback || function(lastValue, newValue, bits) { return (lastValue * Math.pow(2, bits)) + newValue; };
  var offsetBytes = offset >> 3;

  var inv = function(value) {
    if (invert) {
      return ~value & 0xff;
    }

    return value;
  };

  // read first (maybe partial) byte
  var mask = 0xff;
  var firstBits = 8 - (offset % 8);
  if (bits < firstBits) {
    mask = (0xff << (8 - bits)) & 0xff;
    firstBits = bits;
  }

  if (offset) {
    mask = mask >> (offset % 8);
  }

  var result = 0;
  if ((offset % 8) + bits >= 8) {
    result = callback(0, inv(data[offsetBytes]) & mask, firstBits);
  }

  // read bytes
  var bytes = (bits + offset) >> 3;
  for (var i = offsetBytes + 1; i < bytes; i++) {
    result = callback(result, inv(data[i]), 8);
  }

  // bits to read, that are not a complete byte
  var lastBits = (bits + offset) % 8;
  if (lastBits > 0) {
    result = callback(result, inv(data[bytes]) >> (8 - lastBits), lastBits);
  }

  return result;
};

var parseFloatFromBits = function(data, precisionBits, exponentBits) {
  var bias = Math.pow(2, exponentBits - 1) - 1;
  var sign = parseBits(data, 1);
  var exponent = parseBits(data, exponentBits, 1);

  if (exponent === 0) {
    return 0;
  }

  // parse mantissa
  var precisionBitsCounter = 1;
  var parsePrecisionBits = function(lastValue, newValue, bits) {
    if (lastValue === 0) {
      lastValue = 1;
    }

    for (var i = 1; i <= bits; i++) {
      precisionBitsCounter /= 2;
      if ((newValue & (0x1 << (bits - i))) > 0) {
        lastValue += precisionBitsCounter;
      }
    }

    return lastValue;
  };

  var mantissa = parseBits(data, precisionBits, exponentBits + 1, false, parsePrecisionBits);

  // special cases
  if (exponent == (Math.pow(2, exponentBits + 1) - 1)) {
    if (mantissa === 0) {
      return (sign === 0) ? Infinity : -Infinity;
    }

    return NaN;
  }

  // normale number
  return ((sign === 0) ? 1 : -1) * Math.pow(2, exponent - bias) * mantissa;
};

var parseInt16 = function(value) {
  if (parseBits(value, 1) == 1) {
    return -1 * (parseBits(value, 15, 1, true) + 1);
  }

  return parseBits(value, 15, 1);
};

var parseInt32 = function(value) {
  if (parseBits(value, 1) == 1) {
    return -1 * (parseBits(value, 31, 1, true) + 1);
  }

  return parseBits(value, 31, 1);
};

var parseFloat32 = function(value) {
  return parseFloatFromBits(value, 23, 8);
};

var parseFloat64 = function(value) {
  return parseFloatFromBits(value, 52, 11);
};

var parseNumeric = function(value) {
  var sign = parseBits(value, 16, 32);
  if (sign == 0xc000) {
    return NaN;
  }

  var weight = Math.pow(10000, parseBits(value, 16, 16));
  var result = 0;

  var digits = [];
  var ndigits = parseBits(value, 16);
  for (var i = 0; i < ndigits; i++) {
    result += parseBits(value, 16, 64 + (16 * i)) * weight;
    weight /= 10000;
  }

  var scale = Math.pow(10, parseBits(value, 16, 48));
  return ((sign === 0) ? 1 : -1) * Math.round(result * scale) / scale;
};

var parseDate = function(isUTC, value) {
  var sign = parseBits(value, 1);
  var rawValue = parseBits(value, 63, 1);

  // discard usecs and shift from 2000 to 1970
  var result = new Date((((sign === 0) ? 1 : -1) * rawValue / 1000) + 946684800000);

  if (!isUTC) {
    result.setTime(result.getTime() + result.getTimezoneOffset() * 60000);
  }

  // add microseconds to the date
  result.usec = rawValue % 1000;
  result.getMicroSeconds = function() {
    return this.usec;
  };
  result.setMicroSeconds = function(value) {
    this.usec = value;
  };
  result.getUTCMicroSeconds = function() {
    return this.usec;
  };

  return result;
};

var parseArray = function(value) {
  var dim = parseBits(value, 32);

  var flags = parseBits(value, 32, 32);
  var elementType = parseBits(value, 32, 64);

  var offset = 96;
  var dims = [];
  for (var i = 0; i < dim; i++) {
    // parse dimension
    dims[i] = parseBits(value, 32, offset);
    offset += 32;

    // ignore lower bounds
    offset += 32;
  }

  var parseElement = function(elementType) {
    // parse content length
    var length = parseBits(value, 32, offset);
    offset += 32;

    // parse null values
    if (length == 0xffffffff) {
      return null;
    }

    var result;
    if ((elementType == 0x17) || (elementType == 0x14)) {
      // int/bigint
      result = parseBits(value, length * 8, offset);
      offset += length * 8;
      return result;
    }
    else if (elementType == 0x19) {
      // string
      result = value.toString(this.encoding, offset >> 3, (offset += (length << 3)) >> 3);
      return result;
    }
    else {
      console.log("ERROR: ElementType not implemented: " + elementType);
    }
  };

  var parse = function(dimension, elementType) {
    var array = [];
    var i;

    if (dimension.length > 1) {
      var count = dimension.shift();
      for (i = 0; i < count; i++) {
        array[i] = parse(dimension, elementType);
      }
      dimension.unshift(count);
    }
    else {
      for (i = 0; i < dimension[0]; i++) {
        array[i] = parseElement(elementType);
      }
    }

    return array;
  };

  return parse(dims, elementType);
};

var parseText = function(value) {
  return value.toString('utf8');
};

var parseBool = function(value) {
  if(value === null) return null;
  return (parseBits(value, 8) > 0);
};

var init = function(register) {
  register(20, parseInt64);
  register(21, parseInt16);
  register(23, parseInt32);
  register(26, parseInt32);
  register(1700, parseNumeric);
  register(700, parseFloat32);
  register(701, parseFloat64);
  register(16, parseBool);
  register(1114, parseDate.bind(null, false));
  register(1184, parseDate.bind(null, true));
  register(1000, parseArray);
  register(1007, parseArray);
  register(1016, parseArray);
  register(1008, parseArray);
  register(1009, parseArray);
  register(25, parseText);
};

module.exports = {
  init: init
};


/***/ }),

/***/ 8078:
/***/ ((module) => {

/**
 * Following query was used to generate this file:

 SELECT json_object_agg(UPPER(PT.typname), PT.oid::int4 ORDER BY pt.oid)
 FROM pg_type PT
 WHERE typnamespace = (SELECT pgn.oid FROM pg_namespace pgn WHERE nspname = 'pg_catalog') -- Take only builting Postgres types with stable OID (extension types are not guaranted to be stable)
 AND typtype = 'b' -- Only basic types
 AND typelem = 0 -- Ignore aliases
 AND typisdefined -- Ignore undefined types
 */

module.exports = {
    BOOL: 16,
    BYTEA: 17,
    CHAR: 18,
    INT8: 20,
    INT2: 21,
    INT4: 23,
    REGPROC: 24,
    TEXT: 25,
    OID: 26,
    TID: 27,
    XID: 28,
    CID: 29,
    JSON: 114,
    XML: 142,
    PG_NODE_TREE: 194,
    SMGR: 210,
    PATH: 602,
    POLYGON: 604,
    CIDR: 650,
    FLOAT4: 700,
    FLOAT8: 701,
    ABSTIME: 702,
    RELTIME: 703,
    TINTERVAL: 704,
    CIRCLE: 718,
    MACADDR8: 774,
    MONEY: 790,
    MACADDR: 829,
    INET: 869,
    ACLITEM: 1033,
    BPCHAR: 1042,
    VARCHAR: 1043,
    DATE: 1082,
    TIME: 1083,
    TIMESTAMP: 1114,
    TIMESTAMPTZ: 1184,
    INTERVAL: 1186,
    TIMETZ: 1266,
    BIT: 1560,
    VARBIT: 1562,
    NUMERIC: 1700,
    REFCURSOR: 1790,
    REGPROCEDURE: 2202,
    REGOPER: 2203,
    REGOPERATOR: 2204,
    REGCLASS: 2205,
    REGTYPE: 2206,
    UUID: 2950,
    TXID_SNAPSHOT: 2970,
    PG_LSN: 3220,
    PG_NDISTINCT: 3361,
    PG_DEPENDENCIES: 3402,
    TSVECTOR: 3614,
    TSQUERY: 3615,
    GTSVECTOR: 3642,
    REGCONFIG: 3734,
    REGDICTIONARY: 3769,
    JSONB: 3802,
    REGNAMESPACE: 4089,
    REGROLE: 4096
};


/***/ }),

/***/ 2980:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var array = __webpack_require__(7315)
var arrayParser = __webpack_require__(6169);
var parseDate = __webpack_require__(3765);
var parseInterval = __webpack_require__(1055);
var parseByteA = __webpack_require__(3712);

function allowNull (fn) {
  return function nullAllowed (value) {
    if (value === null) return value
    return fn(value)
  }
}

function parseBool (value) {
  if (value === null) return value
  return value === 'TRUE' ||
    value === 't' ||
    value === 'true' ||
    value === 'y' ||
    value === 'yes' ||
    value === 'on' ||
    value === '1';
}

function parseBoolArray (value) {
  if (!value) return null
  return array.parse(value, parseBool)
}

function parseBaseTenInt (string) {
  return parseInt(string, 10)
}

function parseIntegerArray (value) {
  if (!value) return null
  return array.parse(value, allowNull(parseBaseTenInt))
}

function parseBigIntegerArray (value) {
  if (!value) return null
  return array.parse(value, allowNull(function (entry) {
    return parseBigInteger(entry).trim()
  }))
}

var parsePointArray = function(value) {
  if(!value) { return null; }
  var p = arrayParser.create(value, function(entry) {
    if(entry !== null) {
      entry = parsePoint(entry);
    }
    return entry;
  });

  return p.parse();
};

var parseFloatArray = function(value) {
  if(!value) { return null; }
  var p = arrayParser.create(value, function(entry) {
    if(entry !== null) {
      entry = parseFloat(entry);
    }
    return entry;
  });

  return p.parse();
};

var parseStringArray = function(value) {
  if(!value) { return null; }

  var p = arrayParser.create(value);
  return p.parse();
};

var parseDateArray = function(value) {
  if (!value) { return null; }

  var p = arrayParser.create(value, function(entry) {
    if (entry !== null) {
      entry = parseDate(entry);
    }
    return entry;
  });

  return p.parse();
};

var parseIntervalArray = function(value) {
  if (!value) { return null; }

  var p = arrayParser.create(value, function(entry) {
    if (entry !== null) {
      entry = parseInterval(entry);
    }
    return entry;
  });

  return p.parse();
};

var parseByteAArray = function(value) {
  if (!value) { return null; }

  return array.parse(value, allowNull(parseByteA));
};

var parseInteger = function(value) {
  return parseInt(value, 10);
};

var parseBigInteger = function(value) {
  var valStr = String(value);
  if (/^\d+$/.test(valStr)) { return valStr; }
  return value;
};

var parseJsonArray = function(value) {
  if (!value) { return null; }

  return array.parse(value, allowNull(JSON.parse));
};

var parsePoint = function(value) {
  if (value[0] !== '(') { return null; }

  value = value.substring( 1, value.length - 1 ).split(',');

  return {
    x: parseFloat(value[0])
  , y: parseFloat(value[1])
  };
};

var parseCircle = function(value) {
  if (value[0] !== '<' && value[1] !== '(') { return null; }

  var point = '(';
  var radius = '';
  var pointParsed = false;
  for (var i = 2; i < value.length - 1; i++){
    if (!pointParsed) {
      point += value[i];
    }

    if (value[i] === ')') {
      pointParsed = true;
      continue;
    } else if (!pointParsed) {
      continue;
    }

    if (value[i] === ','){
      continue;
    }

    radius += value[i];
  }
  var result = parsePoint(point);
  result.radius = parseFloat(radius);

  return result;
};

var init = function(register) {
  register(20, parseBigInteger); // int8
  register(21, parseInteger); // int2
  register(23, parseInteger); // int4
  register(26, parseInteger); // oid
  register(700, parseFloat); // float4/real
  register(701, parseFloat); // float8/double
  register(16, parseBool);
  register(1082, parseDate); // date
  register(1114, parseDate); // timestamp without timezone
  register(1184, parseDate); // timestamp
  register(600, parsePoint); // point
  register(651, parseStringArray); // cidr[]
  register(718, parseCircle); // circle
  register(1000, parseBoolArray);
  register(1001, parseByteAArray);
  register(1005, parseIntegerArray); // _int2
  register(1007, parseIntegerArray); // _int4
  register(1028, parseIntegerArray); // oid[]
  register(1016, parseBigIntegerArray); // _int8
  register(1017, parsePointArray); // point[]
  register(1021, parseFloatArray); // _float4
  register(1022, parseFloatArray); // _float8
  register(1231, parseFloatArray); // _numeric
  register(1014, parseStringArray); //char
  register(1015, parseStringArray); //varchar
  register(1008, parseStringArray);
  register(1009, parseStringArray);
  register(1040, parseStringArray); // macaddr[]
  register(1041, parseStringArray); // inet[]
  register(1115, parseDateArray); // timestamp without time zone[]
  register(1182, parseDateArray); // _date
  register(1185, parseDateArray); // timestamp with time zone[]
  register(1186, parseInterval);
  register(1187, parseIntervalArray);
  register(17, parseByteA);
  register(114, JSON.parse.bind(JSON)); // json
  register(3802, JSON.parse.bind(JSON)); // jsonb
  register(199, parseJsonArray); // json[]
  register(3807, parseJsonArray); // jsonb[]
  register(3907, parseStringArray); // numrange[]
  register(2951, parseStringArray); // uuid[]
  register(791, parseStringArray); // money[]
  register(1183, parseStringArray); // time[]
  register(1270, parseStringArray); // timetz[]
};

module.exports = {
  init: init
};


/***/ }),

/***/ 7442:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var EventEmitter = __webpack_require__(8614).EventEmitter
var util = __webpack_require__(1669)
var utils = __webpack_require__(1262)
var sasl = __webpack_require__(4615)
var pgPass = __webpack_require__(8812)
var TypeOverrides = __webpack_require__(5701)

var ConnectionParameters = __webpack_require__(8048)
var Query = __webpack_require__(1134)
var defaults = __webpack_require__(7433)
var Connection = __webpack_require__(1964)

class Client extends EventEmitter {
  constructor(config) {
    super()

    this.connectionParameters = new ConnectionParameters(config)
    this.user = this.connectionParameters.user
    this.database = this.connectionParameters.database
    this.port = this.connectionParameters.port
    this.host = this.connectionParameters.host

    // "hiding" the password so it doesn't show up in stack traces
    // or if the client is console.logged
    Object.defineProperty(this, 'password', {
      configurable: true,
      enumerable: false,
      writable: true,
      value: this.connectionParameters.password,
    })

    this.replication = this.connectionParameters.replication

    var c = config || {}

    this._Promise = c.Promise || global.Promise
    this._types = new TypeOverrides(c.types)
    this._ending = false
    this._connecting = false
    this._connected = false
    this._connectionError = false
    this._queryable = true

    this.connection =
      c.connection ||
      new Connection({
        stream: c.stream,
        ssl: this.connectionParameters.ssl,
        keepAlive: c.keepAlive || false,
        keepAliveInitialDelayMillis: c.keepAliveInitialDelayMillis || 0,
        encoding: this.connectionParameters.client_encoding || 'utf8',
      })
    this.queryQueue = []
    this.binary = c.binary || defaults.binary
    this.processID = null
    this.secretKey = null
    this.ssl = this.connectionParameters.ssl || false
    // As with Password, make SSL->Key (the private key) non-enumerable.
    // It won't show up in stack traces
    // or if the client is console.logged
    if (this.ssl && this.ssl.key) {
      Object.defineProperty(this.ssl, 'key', {
        enumerable: false,
      })
    }

    this._connectionTimeoutMillis = c.connectionTimeoutMillis || 0
  }

  _errorAllQueries(err) {
    const enqueueError = (query) => {
      process.nextTick(() => {
        query.handleError(err, this.connection)
      })
    }

    if (this.activeQuery) {
      enqueueError(this.activeQuery)
      this.activeQuery = null
    }

    this.queryQueue.forEach(enqueueError)
    this.queryQueue.length = 0
  }

  _connect(callback) {
    var self = this
    var con = this.connection
    this._connectionCallback = callback

    if (this._connecting || this._connected) {
      const err = new Error('Client has already been connected. You cannot reuse a client.')
      process.nextTick(() => {
        callback(err)
      })
      return
    }
    this._connecting = true

    this.connectionTimeoutHandle
    if (this._connectionTimeoutMillis > 0) {
      this.connectionTimeoutHandle = setTimeout(() => {
        con._ending = true
        con.stream.destroy(new Error('timeout expired'))
      }, this._connectionTimeoutMillis)
    }

    if (this.host && this.host.indexOf('/') === 0) {
      con.connect(this.host + '/.s.PGSQL.' + this.port)
    } else {
      con.connect(this.port, this.host)
    }

    // once connection is established send startup message
    con.on('connect', function () {
      if (self.ssl) {
        con.requestSsl()
      } else {
        con.startup(self.getStartupConf())
      }
    })

    con.on('sslconnect', function () {
      con.startup(self.getStartupConf())
    })

    this._attachListeners(con)

    con.once('end', () => {
      const error = this._ending ? new Error('Connection terminated') : new Error('Connection terminated unexpectedly')

      clearTimeout(this.connectionTimeoutHandle)
      this._errorAllQueries(error)

      if (!this._ending) {
        // if the connection is ended without us calling .end()
        // on this client then we have an unexpected disconnection
        // treat this as an error unless we've already emitted an error
        // during connection.
        if (this._connecting && !this._connectionError) {
          if (this._connectionCallback) {
            this._connectionCallback(error)
          } else {
            this._handleErrorEvent(error)
          }
        } else if (!this._connectionError) {
          this._handleErrorEvent(error)
        }
      }

      process.nextTick(() => {
        this.emit('end')
      })
    })
  }

  connect(callback) {
    if (callback) {
      this._connect(callback)
      return
    }

    return new this._Promise((resolve, reject) => {
      this._connect((error) => {
        if (error) {
          reject(error)
        } else {
          resolve()
        }
      })
    })
  }

  _attachListeners(con) {
    // password request handling
    con.on('authenticationCleartextPassword', this._handleAuthCleartextPassword.bind(this))
    // password request handling
    con.on('authenticationMD5Password', this._handleAuthMD5Password.bind(this))
    // password request handling (SASL)
    con.on('authenticationSASL', this._handleAuthSASL.bind(this))
    con.on('authenticationSASLContinue', this._handleAuthSASLContinue.bind(this))
    con.on('authenticationSASLFinal', this._handleAuthSASLFinal.bind(this))
    con.on('backendKeyData', this._handleBackendKeyData.bind(this))
    con.on('error', this._handleErrorEvent.bind(this))
    con.on('errorMessage', this._handleErrorMessage.bind(this))
    con.on('readyForQuery', this._handleReadyForQuery.bind(this))
    con.on('notice', this._handleNotice.bind(this))
    con.on('rowDescription', this._handleRowDescription.bind(this))
    con.on('dataRow', this._handleDataRow.bind(this))
    con.on('portalSuspended', this._handlePortalSuspended.bind(this))
    con.on('emptyQuery', this._handleEmptyQuery.bind(this))
    con.on('commandComplete', this._handleCommandComplete.bind(this))
    con.on('parseComplete', this._handleParseComplete.bind(this))
    con.on('copyInResponse', this._handleCopyInResponse.bind(this))
    con.on('copyData', this._handleCopyData.bind(this))
    con.on('notification', this._handleNotification.bind(this))
  }

  // TODO(bmc): deprecate pgpass "built in" integration since this.password can be a function
  // it can be supplied by the user if required - this is a breaking change!
  _checkPgPass(cb) {
    const con = this.connection
    if (typeof this.password === 'function') {
      this._Promise
        .resolve()
        .then(() => this.password())
        .then((pass) => {
          if (pass !== undefined) {
            if (typeof pass !== 'string') {
              con.emit('error', new TypeError('Password must be a string'))
              return
            }
            this.connectionParameters.password = this.password = pass
          } else {
            this.connectionParameters.password = this.password = null
          }
          cb()
        })
        .catch((err) => {
          con.emit('error', err)
        })
    } else if (this.password !== null) {
      cb()
    } else {
      pgPass(this.connectionParameters, (pass) => {
        if (undefined !== pass) {
          this.connectionParameters.password = this.password = pass
        }
        cb()
      })
    }
  }

  _handleAuthCleartextPassword(msg) {
    this._checkPgPass(() => {
      this.connection.password(this.password)
    })
  }

  _handleAuthMD5Password(msg) {
    this._checkPgPass(() => {
      const hashedPassword = utils.postgresMd5PasswordHash(this.user, this.password, msg.salt)
      this.connection.password(hashedPassword)
    })
  }

  _handleAuthSASL(msg) {
    this._checkPgPass(() => {
      this.saslSession = sasl.startSession(msg.mechanisms)
      this.connection.sendSASLInitialResponseMessage(this.saslSession.mechanism, this.saslSession.response)
    })
  }

  _handleAuthSASLContinue(msg) {
    sasl.continueSession(this.saslSession, this.password, msg.data)
    this.connection.sendSCRAMClientFinalMessage(this.saslSession.response)
  }

  _handleAuthSASLFinal(msg) {
    sasl.finalizeSession(this.saslSession, msg.data)
    this.saslSession = null
  }

  _handleBackendKeyData(msg) {
    this.processID = msg.processID
    this.secretKey = msg.secretKey
  }

  _handleReadyForQuery(msg) {
    if (this._connecting) {
      this._connecting = false
      this._connected = true
      clearTimeout(this.connectionTimeoutHandle)

      // process possible callback argument to Client#connect
      if (this._connectionCallback) {
        this._connectionCallback(null, this)
        // remove callback for proper error handling
        // after the connect event
        this._connectionCallback = null
      }
      this.emit('connect')
    }
    const { activeQuery } = this
    this.activeQuery = null
    this.readyForQuery = true
    if (activeQuery) {
      activeQuery.handleReadyForQuery(this.connection)
    }
    this._pulseQueryQueue()
  }

  // if we receieve an error event or error message
  // during the connection process we handle it here
  _handleErrorWhileConnecting(err) {
    if (this._connectionError) {
      // TODO(bmc): this is swallowing errors - we shouldn't do this
      return
    }
    this._connectionError = true
    clearTimeout(this.connectionTimeoutHandle)
    if (this._connectionCallback) {
      return this._connectionCallback(err)
    }
    this.emit('error', err)
  }

  // if we're connected and we receive an error event from the connection
  // this means the socket is dead - do a hard abort of all queries and emit
  // the socket error on the client as well
  _handleErrorEvent(err) {
    if (this._connecting) {
      return this._handleErrorWhileConnecting(err)
    }
    this._queryable = false
    this._errorAllQueries(err)
    this.emit('error', err)
  }

  // handle error messages from the postgres backend
  _handleErrorMessage(msg) {
    if (this._connecting) {
      return this._handleErrorWhileConnecting(msg)
    }
    const activeQuery = this.activeQuery

    if (!activeQuery) {
      this._handleErrorEvent(msg)
      return
    }

    this.activeQuery = null
    activeQuery.handleError(msg, this.connection)
  }

  _handleRowDescription(msg) {
    // delegate rowDescription to active query
    this.activeQuery.handleRowDescription(msg)
  }

  _handleDataRow(msg) {
    // delegate dataRow to active query
    this.activeQuery.handleDataRow(msg)
  }

  _handlePortalSuspended(msg) {
    // delegate portalSuspended to active query
    this.activeQuery.handlePortalSuspended(this.connection)
  }

  _handleEmptyQuery(msg) {
    // delegate emptyQuery to active query
    this.activeQuery.handleEmptyQuery(this.connection)
  }

  _handleCommandComplete(msg) {
    // delegate commandComplete to active query
    this.activeQuery.handleCommandComplete(msg, this.connection)
  }

  _handleParseComplete(msg) {
    // if a prepared statement has a name and properly parses
    // we track that its already been executed so we don't parse
    // it again on the same client
    if (this.activeQuery.name) {
      this.connection.parsedStatements[this.activeQuery.name] = this.activeQuery.text
    }
  }

  _handleCopyInResponse(msg) {
    this.activeQuery.handleCopyInResponse(this.connection)
  }

  _handleCopyData(msg) {
    this.activeQuery.handleCopyData(msg, this.connection)
  }

  _handleNotification(msg) {
    this.emit('notification', msg)
  }

  _handleNotice(msg) {
    this.emit('notice', msg)
  }

  getStartupConf() {
    var params = this.connectionParameters

    var data = {
      user: params.user,
      database: params.database,
    }

    var appName = params.application_name || params.fallback_application_name
    if (appName) {
      data.application_name = appName
    }
    if (params.replication) {
      data.replication = '' + params.replication
    }
    if (params.statement_timeout) {
      data.statement_timeout = String(parseInt(params.statement_timeout, 10))
    }
    if (params.idle_in_transaction_session_timeout) {
      data.idle_in_transaction_session_timeout = String(parseInt(params.idle_in_transaction_session_timeout, 10))
    }
    if (params.options) {
      data.options = params.options
    }

    return data
  }

  cancel(client, query) {
    if (client.activeQuery === query) {
      var con = this.connection

      if (this.host && this.host.indexOf('/') === 0) {
        con.connect(this.host + '/.s.PGSQL.' + this.port)
      } else {
        con.connect(this.port, this.host)
      }

      // once connection is established send cancel message
      con.on('connect', function () {
        con.cancel(client.processID, client.secretKey)
      })
    } else if (client.queryQueue.indexOf(query) !== -1) {
      client.queryQueue.splice(client.queryQueue.indexOf(query), 1)
    }
  }

  setTypeParser(oid, format, parseFn) {
    return this._types.setTypeParser(oid, format, parseFn)
  }

  getTypeParser(oid, format) {
    return this._types.getTypeParser(oid, format)
  }

  // Ported from PostgreSQL 9.2.4 source code in src/interfaces/libpq/fe-exec.c
  escapeIdentifier(str) {
    return '"' + str.replace(/"/g, '""') + '"'
  }

  // Ported from PostgreSQL 9.2.4 source code in src/interfaces/libpq/fe-exec.c
  escapeLiteral(str) {
    var hasBackslash = false
    var escaped = "'"

    for (var i = 0; i < str.length; i++) {
      var c = str[i]
      if (c === "'") {
        escaped += c + c
      } else if (c === '\\') {
        escaped += c + c
        hasBackslash = true
      } else {
        escaped += c
      }
    }

    escaped += "'"

    if (hasBackslash === true) {
      escaped = ' E' + escaped
    }

    return escaped
  }

  _pulseQueryQueue() {
    if (this.readyForQuery === true) {
      this.activeQuery = this.queryQueue.shift()
      if (this.activeQuery) {
        this.readyForQuery = false
        this.hasExecuted = true

        const queryError = this.activeQuery.submit(this.connection)
        if (queryError) {
          process.nextTick(() => {
            this.activeQuery.handleError(queryError, this.connection)
            this.readyForQuery = true
            this._pulseQueryQueue()
          })
        }
      } else if (this.hasExecuted) {
        this.activeQuery = null
        this.emit('drain')
      }
    }
  }

  query(config, values, callback) {
    // can take in strings, config object or query object
    var query
    var result
    var readTimeout
    var readTimeoutTimer
    var queryCallback

    if (config === null || config === undefined) {
      throw new TypeError('Client was passed a null or undefined query')
    } else if (typeof config.submit === 'function') {
      readTimeout = config.query_timeout || this.connectionParameters.query_timeout
      result = query = config
      if (typeof values === 'function') {
        query.callback = query.callback || values
      }
    } else {
      readTimeout = this.connectionParameters.query_timeout
      query = new Query(config, values, callback)
      if (!query.callback) {
        result = new this._Promise((resolve, reject) => {
          query.callback = (err, res) => (err ? reject(err) : resolve(res))
        })
      }
    }

    if (readTimeout) {
      queryCallback = query.callback

      readTimeoutTimer = setTimeout(() => {
        var error = new Error('Query read timeout')

        process.nextTick(() => {
          query.handleError(error, this.connection)
        })

        queryCallback(error)

        // we already returned an error,
        // just do nothing if query completes
        query.callback = () => {}

        // Remove from queue
        var index = this.queryQueue.indexOf(query)
        if (index > -1) {
          this.queryQueue.splice(index, 1)
        }

        this._pulseQueryQueue()
      }, readTimeout)

      query.callback = (err, res) => {
        clearTimeout(readTimeoutTimer)
        queryCallback(err, res)
      }
    }

    if (this.binary && !query.binary) {
      query.binary = true
    }

    if (query._result && !query._result._types) {
      query._result._types = this._types
    }

    if (!this._queryable) {
      process.nextTick(() => {
        query.handleError(new Error('Client has encountered a connection error and is not queryable'), this.connection)
      })
      return result
    }

    if (this._ending) {
      process.nextTick(() => {
        query.handleError(new Error('Client was closed and is not queryable'), this.connection)
      })
      return result
    }

    this.queryQueue.push(query)
    this._pulseQueryQueue()
    return result
  }

  ref() {
    this.connection.ref()
  }

  unref() {
    this.connection.unref()
  }

  end(cb) {
    this._ending = true

    // if we have never connected, then end is a noop, callback immediately
    if (!this.connection._connecting) {
      if (cb) {
        cb()
      } else {
        return this._Promise.resolve()
      }
    }

    if (this.activeQuery || !this._queryable) {
      // if we have an active query we need to force a disconnect
      // on the socket - otherwise a hung query could block end forever
      this.connection.stream.destroy()
    } else {
      this.connection.end()
    }

    if (cb) {
      this.connection.once('end', cb)
    } else {
      return new this._Promise((resolve) => {
        this.connection.once('end', resolve)
      })
    }
  }
}

// expose a Query constructor
Client.Query = Query

module.exports = Client


/***/ }),

/***/ 8048:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var dns = __webpack_require__(881)

var defaults = __webpack_require__(7433)

var parse = __webpack_require__(5697).parse // parses a connection string

var val = function (key, config, envVar) {
  if (envVar === undefined) {
    envVar = process.env['PG' + key.toUpperCase()]
  } else if (envVar === false) {
    // do nothing ... use false
  } else {
    envVar = process.env[envVar]
  }

  return config[key] || envVar || defaults[key]
}

var readSSLConfigFromEnvironment = function () {
  switch (process.env.PGSSLMODE) {
    case 'disable':
      return false
    case 'prefer':
    case 'require':
    case 'verify-ca':
    case 'verify-full':
      return true
    case 'no-verify':
      return { rejectUnauthorized: false }
  }
  return defaults.ssl
}

// Convert arg to a string, surround in single quotes, and escape single quotes and backslashes
var quoteParamValue = function (value) {
  return "'" + ('' + value).replace(/\\/g, '\\\\').replace(/'/g, "\\'") + "'"
}

var add = function (params, config, paramName) {
  var value = config[paramName]
  if (value !== undefined && value !== null) {
    params.push(paramName + '=' + quoteParamValue(value))
  }
}

class ConnectionParameters {
  constructor(config) {
    // if a string is passed, it is a raw connection string so we parse it into a config
    config = typeof config === 'string' ? parse(config) : config || {}

    // if the config has a connectionString defined, parse IT into the config we use
    // this will override other default values with what is stored in connectionString
    if (config.connectionString) {
      config = Object.assign({}, config, parse(config.connectionString))
    }

    this.user = val('user', config)
    this.database = val('database', config)

    if (this.database === undefined) {
      this.database = this.user
    }

    this.port = parseInt(val('port', config), 10)
    this.host = val('host', config)

    // "hiding" the password so it doesn't show up in stack traces
    // or if the client is console.logged
    Object.defineProperty(this, 'password', {
      configurable: true,
      enumerable: false,
      writable: true,
      value: val('password', config),
    })

    this.binary = val('binary', config)
    this.options = val('options', config)

    this.ssl = typeof config.ssl === 'undefined' ? readSSLConfigFromEnvironment() : config.ssl

    if (typeof this.ssl === 'string') {
      if (this.ssl === 'true') {
        this.ssl = true
      }
    }
    // support passing in ssl=no-verify via connection string
    if (this.ssl === 'no-verify') {
      this.ssl = { rejectUnauthorized: false }
    }
    if (this.ssl && this.ssl.key) {
      Object.defineProperty(this.ssl, 'key', {
        enumerable: false,
      })
    }

    this.client_encoding = val('client_encoding', config)
    this.replication = val('replication', config)
    // a domain socket begins with '/'
    this.isDomainSocket = !(this.host || '').indexOf('/')

    this.application_name = val('application_name', config, 'PGAPPNAME')
    this.fallback_application_name = val('fallback_application_name', config, false)
    this.statement_timeout = val('statement_timeout', config, false)
    this.idle_in_transaction_session_timeout = val('idle_in_transaction_session_timeout', config, false)
    this.query_timeout = val('query_timeout', config, false)

    if (config.connectionTimeoutMillis === undefined) {
      this.connect_timeout = process.env.PGCONNECT_TIMEOUT || 0
    } else {
      this.connect_timeout = Math.floor(config.connectionTimeoutMillis / 1000)
    }

    if (config.keepAlive === false) {
      this.keepalives = 0
    } else if (config.keepAlive === true) {
      this.keepalives = 1
    }

    if (typeof config.keepAliveInitialDelayMillis === 'number') {
      this.keepalives_idle = Math.floor(config.keepAliveInitialDelayMillis / 1000)
    }
  }

  getLibpqConnectionString(cb) {
    var params = []
    add(params, this, 'user')
    add(params, this, 'password')
    add(params, this, 'port')
    add(params, this, 'application_name')
    add(params, this, 'fallback_application_name')
    add(params, this, 'connect_timeout')
    add(params, this, 'options')

    var ssl = typeof this.ssl === 'object' ? this.ssl : this.ssl ? { sslmode: this.ssl } : {}
    add(params, ssl, 'sslmode')
    add(params, ssl, 'sslca')
    add(params, ssl, 'sslkey')
    add(params, ssl, 'sslcert')
    add(params, ssl, 'sslrootcert')

    if (this.database) {
      params.push('dbname=' + quoteParamValue(this.database))
    }
    if (this.replication) {
      params.push('replication=' + quoteParamValue(this.replication))
    }
    if (this.host) {
      params.push('host=' + quoteParamValue(this.host))
    }
    if (this.isDomainSocket) {
      return cb(null, params.join(' '))
    }
    if (this.client_encoding) {
      params.push('client_encoding=' + quoteParamValue(this.client_encoding))
    }
    dns.lookup(this.host, function (err, address) {
      if (err) return cb(err, null)
      params.push('hostaddr=' + quoteParamValue(address))
      return cb(null, params.join(' '))
    })
  }
}

module.exports = ConnectionParameters


/***/ }),

/***/ 1964:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var net = __webpack_require__(1631)
var EventEmitter = __webpack_require__(8614).EventEmitter

const { parse, serialize } = __webpack_require__(8152)

const flushBuffer = serialize.flush()
const syncBuffer = serialize.sync()
const endBuffer = serialize.end()

// TODO(bmc) support binary mode at some point
class Connection extends EventEmitter {
  constructor(config) {
    super()
    config = config || {}
    this.stream = config.stream || new net.Socket()
    this._keepAlive = config.keepAlive
    this._keepAliveInitialDelayMillis = config.keepAliveInitialDelayMillis
    this.lastBuffer = false
    this.parsedStatements = {}
    this.ssl = config.ssl || false
    this._ending = false
    this._emitMessage = false
    var self = this
    this.on('newListener', function (eventName) {
      if (eventName === 'message') {
        self._emitMessage = true
      }
    })
  }

  connect(port, host) {
    var self = this

    this._connecting = true
    this.stream.setNoDelay(true)
    this.stream.connect(port, host)

    this.stream.once('connect', function () {
      if (self._keepAlive) {
        self.stream.setKeepAlive(true, self._keepAliveInitialDelayMillis)
      }
      self.emit('connect')
    })

    const reportStreamError = function (error) {
      // errors about disconnections should be ignored during disconnect
      if (self._ending && (error.code === 'ECONNRESET' || error.code === 'EPIPE')) {
        return
      }
      self.emit('error', error)
    }
    this.stream.on('error', reportStreamError)

    this.stream.on('close', function () {
      self.emit('end')
    })

    if (!this.ssl) {
      return this.attachListeners(this.stream)
    }

    this.stream.once('data', function (buffer) {
      var responseCode = buffer.toString('utf8')
      switch (responseCode) {
        case 'S': // Server supports SSL connections, continue with a secure connection
          break
        case 'N': // Server does not support SSL connections
          self.stream.end()
          return self.emit('error', new Error('The server does not support SSL connections'))
        default:
          // Any other response byte, including 'E' (ErrorResponse) indicating a server error
          self.stream.end()
          return self.emit('error', new Error('There was an error establishing an SSL connection'))
      }
      var tls = __webpack_require__(4016)
      const options = {
        socket: self.stream,
      }

      if (self.ssl !== true) {
        Object.assign(options, self.ssl)

        if ('key' in self.ssl) {
          options.key = self.ssl.key
        }
      }

      if (net.isIP(host) === 0) {
        options.servername = host
      }
      try {
        self.stream = tls.connect(options)
      } catch (err) {
        return self.emit('error', err)
      }
      self.attachListeners(self.stream)
      self.stream.on('error', reportStreamError)

      self.emit('sslconnect')
    })
  }

  attachListeners(stream) {
    stream.on('end', () => {
      this.emit('end')
    })
    parse(stream, (msg) => {
      var eventName = msg.name === 'error' ? 'errorMessage' : msg.name
      if (this._emitMessage) {
        this.emit('message', msg)
      }
      this.emit(eventName, msg)
    })
  }

  requestSsl() {
    this.stream.write(serialize.requestSsl())
  }

  startup(config) {
    this.stream.write(serialize.startup(config))
  }

  cancel(processID, secretKey) {
    this._send(serialize.cancel(processID, secretKey))
  }

  password(password) {
    this._send(serialize.password(password))
  }

  sendSASLInitialResponseMessage(mechanism, initialResponse) {
    this._send(serialize.sendSASLInitialResponseMessage(mechanism, initialResponse))
  }

  sendSCRAMClientFinalMessage(additionalData) {
    this._send(serialize.sendSCRAMClientFinalMessage(additionalData))
  }

  _send(buffer) {
    if (!this.stream.writable) {
      return false
    }
    return this.stream.write(buffer)
  }

  query(text) {
    this._send(serialize.query(text))
  }

  // send parse message
  parse(query) {
    this._send(serialize.parse(query))
  }

  // send bind message
  bind(config) {
    this._send(serialize.bind(config))
  }

  // send execute message
  execute(config) {
    this._send(serialize.execute(config))
  }

  flush() {
    if (this.stream.writable) {
      this.stream.write(flushBuffer)
    }
  }

  sync() {
    this._ending = true
    this._send(flushBuffer)
    this._send(syncBuffer)
  }

  ref() {
    this.stream.ref()
  }

  unref() {
    this.stream.unref()
  }

  end() {
    // 0x58 = 'X'
    this._ending = true
    if (!this._connecting || !this.stream.writable) {
      this.stream.end()
      return
    }
    return this.stream.write(endBuffer, () => {
      this.stream.end()
    })
  }

  close(msg) {
    this._send(serialize.close(msg))
  }

  describe(msg) {
    this._send(serialize.describe(msg))
  }

  sendCopyFromChunk(chunk) {
    this._send(serialize.copyData(chunk))
  }

  endCopyFrom() {
    this._send(serialize.copyDone())
  }

  sendCopyFail(msg) {
    this._send(serialize.copyFail(msg))
  }
}

module.exports = Connection


/***/ }),

/***/ 7433:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


module.exports = {
  // database host. defaults to localhost
  host: 'localhost',

  // database user's name
  user: process.platform === 'win32' ? process.env.USERNAME : process.env.USER,

  // name of database to connect
  database: undefined,

  // database user's password
  password: null,

  // a Postgres connection string to be used instead of setting individual connection items
  // NOTE:  Setting this value will cause it to override any other value (such as database or user) defined
  // in the defaults object.
  connectionString: undefined,

  // database port
  port: 5432,

  // number of rows to return at a time from a prepared statement's
  // portal. 0 will return all rows at once
  rows: 0,

  // binary result mode
  binary: false,

  // Connection pool options - see https://github.com/brianc/node-pg-pool

  // number of connections to use in connection pool
  // 0 will disable connection pooling
  max: 10,

  // max milliseconds a client can go unused before it is removed
  // from the pool and destroyed
  idleTimeoutMillis: 30000,

  client_encoding: '',

  ssl: false,

  application_name: undefined,

  fallback_application_name: undefined,

  options: undefined,

  parseInputDatesAsUTC: false,

  // max milliseconds any query using this connection will execute for before timing out in error.
  // false=unlimited
  statement_timeout: false,

  // Terminate any session with an open transaction that has been idle for longer than the specified duration in milliseconds
  // false=unlimited
  idle_in_transaction_session_timeout: false,

  // max milliseconds to wait for query to complete (client side)
  query_timeout: false,

  connect_timeout: 0,

  keepalives: 1,

  keepalives_idle: 0,
}

var pgTypes = __webpack_require__(3619)
// save default parsers
var parseBigInteger = pgTypes.getTypeParser(20, 'text')
var parseBigIntegerArray = pgTypes.getTypeParser(1016, 'text')

// parse int8 so you can get your count values as actual numbers
module.exports.__defineSetter__('parseInt8', function (val) {
  pgTypes.setTypeParser(20, 'text', val ? pgTypes.getTypeParser(23, 'text') : parseBigInteger)
  pgTypes.setTypeParser(1016, 'text', val ? pgTypes.getTypeParser(1007, 'text') : parseBigIntegerArray)
})


/***/ }),

/***/ 8955:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var Client = __webpack_require__(7442)
var defaults = __webpack_require__(7433)
var Connection = __webpack_require__(1964)
var Pool = __webpack_require__(5546)
const { DatabaseError } = __webpack_require__(8152)

const poolFactory = (Client) => {
  return class BoundPool extends Pool {
    constructor(options) {
      super(options, Client)
    }
  }
}

var PG = function (clientConstructor) {
  this.defaults = defaults
  this.Client = clientConstructor
  this.Query = this.Client.Query
  this.Pool = poolFactory(this.Client)
  this._pools = []
  this.Connection = Connection
  this.types = __webpack_require__(3619)
  this.DatabaseError = DatabaseError
}

if (typeof process.env.NODE_PG_FORCE_NATIVE !== 'undefined') {
  module.exports = new PG(__webpack_require__(6221))
} else {
  module.exports = new PG(Client)

  // lazy require native module...the native module may not have installed
  Object.defineProperty(module.exports, "native", ({
    configurable: true,
    enumerable: false,
    get() {
      var native = null
      try {
        native = new PG(__webpack_require__(6221))
      } catch (err) {
        if (err.code !== 'MODULE_NOT_FOUND') {
          throw err
        }
      }

      // overwrite module.exports.native so that getter is never called again
      Object.defineProperty(module.exports, "native", ({
        value: native,
      }))

      return native
    },
  }))
}


/***/ }),

/***/ 6033:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// eslint-disable-next-line
var Native = __webpack_require__(Object(function webpackMissingModule() { var e = new Error("Cannot find module 'pg-native'"); e.code = 'MODULE_NOT_FOUND'; throw e; }()))
var TypeOverrides = __webpack_require__(5701)
var pkg = __webpack_require__(2466)
var EventEmitter = __webpack_require__(8614).EventEmitter
var util = __webpack_require__(1669)
var ConnectionParameters = __webpack_require__(8048)

var NativeQuery = __webpack_require__(7839)

var Client = (module.exports = function (config) {
  EventEmitter.call(this)
  config = config || {}

  this._Promise = config.Promise || global.Promise
  this._types = new TypeOverrides(config.types)

  this.native = new Native({
    types: this._types,
  })

  this._queryQueue = []
  this._ending = false
  this._connecting = false
  this._connected = false
  this._queryable = true

  // keep these on the object for legacy reasons
  // for the time being. TODO: deprecate all this jazz
  var cp = (this.connectionParameters = new ConnectionParameters(config))
  this.user = cp.user

  // "hiding" the password so it doesn't show up in stack traces
  // or if the client is console.logged
  Object.defineProperty(this, 'password', {
    configurable: true,
    enumerable: false,
    writable: true,
    value: cp.password,
  })
  this.database = cp.database
  this.host = cp.host
  this.port = cp.port

  // a hash to hold named queries
  this.namedQueries = {}
})

Client.Query = NativeQuery

util.inherits(Client, EventEmitter)

Client.prototype._errorAllQueries = function (err) {
  const enqueueError = (query) => {
    process.nextTick(() => {
      query.native = this.native
      query.handleError(err)
    })
  }

  if (this._hasActiveQuery()) {
    enqueueError(this._activeQuery)
    this._activeQuery = null
  }

  this._queryQueue.forEach(enqueueError)
  this._queryQueue.length = 0
}

// connect to the backend
// pass an optional callback to be called once connected
// or with an error if there was a connection error
Client.prototype._connect = function (cb) {
  var self = this

  if (this._connecting) {
    process.nextTick(() => cb(new Error('Client has already been connected. You cannot reuse a client.')))
    return
  }

  this._connecting = true

  this.connectionParameters.getLibpqConnectionString(function (err, conString) {
    if (err) return cb(err)
    self.native.connect(conString, function (err) {
      if (err) {
        self.native.end()
        return cb(err)
      }

      // set internal states to connected
      self._connected = true

      // handle connection errors from the native layer
      self.native.on('error', function (err) {
        self._queryable = false
        self._errorAllQueries(err)
        self.emit('error', err)
      })

      self.native.on('notification', function (msg) {
        self.emit('notification', {
          channel: msg.relname,
          payload: msg.extra,
        })
      })

      // signal we are connected now
      self.emit('connect')
      self._pulseQueryQueue(true)

      cb()
    })
  })
}

Client.prototype.connect = function (callback) {
  if (callback) {
    this._connect(callback)
    return
  }

  return new this._Promise((resolve, reject) => {
    this._connect((error) => {
      if (error) {
        reject(error)
      } else {
        resolve()
      }
    })
  })
}

// send a query to the server
// this method is highly overloaded to take
// 1) string query, optional array of parameters, optional function callback
// 2) object query with {
//    string query
//    optional array values,
//    optional function callback instead of as a separate parameter
//    optional string name to name & cache the query plan
//    optional string rowMode = 'array' for an array of results
//  }
Client.prototype.query = function (config, values, callback) {
  var query
  var result
  var readTimeout
  var readTimeoutTimer
  var queryCallback

  if (config === null || config === undefined) {
    throw new TypeError('Client was passed a null or undefined query')
  } else if (typeof config.submit === 'function') {
    readTimeout = config.query_timeout || this.connectionParameters.query_timeout
    result = query = config
    // accept query(new Query(...), (err, res) => { }) style
    if (typeof values === 'function') {
      config.callback = values
    }
  } else {
    readTimeout = this.connectionParameters.query_timeout
    query = new NativeQuery(config, values, callback)
    if (!query.callback) {
      let resolveOut, rejectOut
      result = new this._Promise((resolve, reject) => {
        resolveOut = resolve
        rejectOut = reject
      })
      query.callback = (err, res) => (err ? rejectOut(err) : resolveOut(res))
    }
  }

  if (readTimeout) {
    queryCallback = query.callback

    readTimeoutTimer = setTimeout(() => {
      var error = new Error('Query read timeout')

      process.nextTick(() => {
        query.handleError(error, this.connection)
      })

      queryCallback(error)

      // we already returned an error,
      // just do nothing if query completes
      query.callback = () => {}

      // Remove from queue
      var index = this._queryQueue.indexOf(query)
      if (index > -1) {
        this._queryQueue.splice(index, 1)
      }

      this._pulseQueryQueue()
    }, readTimeout)

    query.callback = (err, res) => {
      clearTimeout(readTimeoutTimer)
      queryCallback(err, res)
    }
  }

  if (!this._queryable) {
    query.native = this.native
    process.nextTick(() => {
      query.handleError(new Error('Client has encountered a connection error and is not queryable'))
    })
    return result
  }

  if (this._ending) {
    query.native = this.native
    process.nextTick(() => {
      query.handleError(new Error('Client was closed and is not queryable'))
    })
    return result
  }

  this._queryQueue.push(query)
  this._pulseQueryQueue()
  return result
}

// disconnect from the backend server
Client.prototype.end = function (cb) {
  var self = this

  this._ending = true

  if (!this._connected) {
    this.once('connect', this.end.bind(this, cb))
  }
  var result
  if (!cb) {
    result = new this._Promise(function (resolve, reject) {
      cb = (err) => (err ? reject(err) : resolve())
    })
  }
  this.native.end(function () {
    self._errorAllQueries(new Error('Connection terminated'))

    process.nextTick(() => {
      self.emit('end')
      if (cb) cb()
    })
  })
  return result
}

Client.prototype._hasActiveQuery = function () {
  return this._activeQuery && this._activeQuery.state !== 'error' && this._activeQuery.state !== 'end'
}

Client.prototype._pulseQueryQueue = function (initialConnection) {
  if (!this._connected) {
    return
  }
  if (this._hasActiveQuery()) {
    return
  }
  var query = this._queryQueue.shift()
  if (!query) {
    if (!initialConnection) {
      this.emit('drain')
    }
    return
  }
  this._activeQuery = query
  query.submit(this)
  var self = this
  query.once('_done', function () {
    self._pulseQueryQueue()
  })
}

// attempt to cancel an in-progress query
Client.prototype.cancel = function (query) {
  if (this._activeQuery === query) {
    this.native.cancel(function () {})
  } else if (this._queryQueue.indexOf(query) !== -1) {
    this._queryQueue.splice(this._queryQueue.indexOf(query), 1)
  }
}

Client.prototype.ref = function () {}
Client.prototype.unref = function () {}

Client.prototype.setTypeParser = function (oid, format, parseFn) {
  return this._types.setTypeParser(oid, format, parseFn)
}

Client.prototype.getTypeParser = function (oid, format) {
  return this._types.getTypeParser(oid, format)
}


/***/ }),

/***/ 6221:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

module.exports = __webpack_require__(6033)


/***/ }),

/***/ 7839:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var EventEmitter = __webpack_require__(8614).EventEmitter
var util = __webpack_require__(1669)
var utils = __webpack_require__(1262)

var NativeQuery = (module.exports = function (config, values, callback) {
  EventEmitter.call(this)
  config = utils.normalizeQueryConfig(config, values, callback)
  this.text = config.text
  this.values = config.values
  this.name = config.name
  this.callback = config.callback
  this.state = 'new'
  this._arrayMode = config.rowMode === 'array'

  // if the 'row' event is listened for
  // then emit them as they come in
  // without setting singleRowMode to true
  // this has almost no meaning because libpq
  // reads all rows into memory befor returning any
  this._emitRowEvents = false
  this.on(
    'newListener',
    function (event) {
      if (event === 'row') this._emitRowEvents = true
    }.bind(this)
  )
})

util.inherits(NativeQuery, EventEmitter)

var errorFieldMap = {
  /* eslint-disable quote-props */
  sqlState: 'code',
  statementPosition: 'position',
  messagePrimary: 'message',
  context: 'where',
  schemaName: 'schema',
  tableName: 'table',
  columnName: 'column',
  dataTypeName: 'dataType',
  constraintName: 'constraint',
  sourceFile: 'file',
  sourceLine: 'line',
  sourceFunction: 'routine',
}

NativeQuery.prototype.handleError = function (err) {
  // copy pq error fields into the error object
  var fields = this.native.pq.resultErrorFields()
  if (fields) {
    for (var key in fields) {
      var normalizedFieldName = errorFieldMap[key] || key
      err[normalizedFieldName] = fields[key]
    }
  }
  if (this.callback) {
    this.callback(err)
  } else {
    this.emit('error', err)
  }
  this.state = 'error'
}

NativeQuery.prototype.then = function (onSuccess, onFailure) {
  return this._getPromise().then(onSuccess, onFailure)
}

NativeQuery.prototype.catch = function (callback) {
  return this._getPromise().catch(callback)
}

NativeQuery.prototype._getPromise = function () {
  if (this._promise) return this._promise
  this._promise = new Promise(
    function (resolve, reject) {
      this._once('end', resolve)
      this._once('error', reject)
    }.bind(this)
  )
  return this._promise
}

NativeQuery.prototype.submit = function (client) {
  this.state = 'running'
  var self = this
  this.native = client.native
  client.native.arrayMode = this._arrayMode

  var after = function (err, rows, results) {
    client.native.arrayMode = false
    setImmediate(function () {
      self.emit('_done')
    })

    // handle possible query error
    if (err) {
      return self.handleError(err)
    }

    // emit row events for each row in the result
    if (self._emitRowEvents) {
      if (results.length > 1) {
        rows.forEach((rowOfRows, i) => {
          rowOfRows.forEach((row) => {
            self.emit('row', row, results[i])
          })
        })
      } else {
        rows.forEach(function (row) {
          self.emit('row', row, results)
        })
      }
    }

    // handle successful result
    self.state = 'end'
    self.emit('end', results)
    if (self.callback) {
      self.callback(null, results)
    }
  }

  if (process.domain) {
    after = process.domain.bind(after)
  }

  // named query
  if (this.name) {
    if (this.name.length > 63) {
      /* eslint-disable no-console */
      console.error('Warning! Postgres only supports 63 characters for query names.')
      console.error('You supplied %s (%s)', this.name, this.name.length)
      console.error('This can cause conflicts and silent errors executing queries')
      /* eslint-enable no-console */
    }
    var values = (this.values || []).map(utils.prepareValue)

    // check if the client has already executed this named query
    // if so...just execute it again - skip the planning phase
    if (client.namedQueries[this.name]) {
      if (this.text && client.namedQueries[this.name] !== this.text) {
        const err = new Error(`Prepared statements must be unique - '${this.name}' was used for a different statement`)
        return after(err)
      }
      return client.native.execute(this.name, values, after)
    }
    // plan the named query the first time, then execute it
    return client.native.prepare(this.name, this.text, values.length, function (err) {
      if (err) return after(err)
      client.namedQueries[self.name] = self.text
      return self.native.execute(self.name, values, after)
    })
  } else if (this.values) {
    if (!Array.isArray(this.values)) {
      const err = new Error('Query values must be an array')
      return after(err)
    }
    var vals = this.values.map(utils.prepareValue)
    client.native.query(this.text, vals, after)
  } else {
    client.native.query(this.text, after)
  }
}


/***/ }),

/***/ 1134:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


const { EventEmitter } = __webpack_require__(8614)

const Result = __webpack_require__(3758)
const utils = __webpack_require__(1262)

class Query extends EventEmitter {
  constructor(config, values, callback) {
    super()

    config = utils.normalizeQueryConfig(config, values, callback)

    this.text = config.text
    this.values = config.values
    this.rows = config.rows
    this.types = config.types
    this.name = config.name
    this.binary = config.binary
    // use unique portal name each time
    this.portal = config.portal || ''
    this.callback = config.callback
    this._rowMode = config.rowMode
    if (process.domain && config.callback) {
      this.callback = process.domain.bind(config.callback)
    }
    this._result = new Result(this._rowMode, this.types)

    // potential for multiple results
    this._results = this._result
    this.isPreparedStatement = false
    this._canceledDueToError = false
    this._promise = null
  }

  requiresPreparation() {
    // named queries must always be prepared
    if (this.name) {
      return true
    }
    // always prepare if there are max number of rows expected per
    // portal execution
    if (this.rows) {
      return true
    }
    // don't prepare empty text queries
    if (!this.text) {
      return false
    }
    // prepare if there are values
    if (!this.values) {
      return false
    }
    return this.values.length > 0
  }

  _checkForMultirow() {
    // if we already have a result with a command property
    // then we've already executed one query in a multi-statement simple query
    // turn our results into an array of results
    if (this._result.command) {
      if (!Array.isArray(this._results)) {
        this._results = [this._result]
      }
      this._result = new Result(this._rowMode, this.types)
      this._results.push(this._result)
    }
  }

  // associates row metadata from the supplied
  // message with this query object
  // metadata used when parsing row results
  handleRowDescription(msg) {
    this._checkForMultirow()
    this._result.addFields(msg.fields)
    this._accumulateRows = this.callback || !this.listeners('row').length
  }

  handleDataRow(msg) {
    let row

    if (this._canceledDueToError) {
      return
    }

    try {
      row = this._result.parseRow(msg.fields)
    } catch (err) {
      this._canceledDueToError = err
      return
    }

    this.emit('row', row, this._result)
    if (this._accumulateRows) {
      this._result.addRow(row)
    }
  }

  handleCommandComplete(msg, connection) {
    this._checkForMultirow()
    this._result.addCommandComplete(msg)
    // need to sync after each command complete of a prepared statement
    // if we were using a row count which results in multiple calls to _getRows
    if (this.rows) {
      connection.sync()
    }
  }

  // if a named prepared statement is created with empty query text
  // the backend will send an emptyQuery message but *not* a command complete message
  // since we pipeline sync immediately after execute we don't need to do anything here
  // unless we have rows specified, in which case we did not pipeline the intial sync call
  handleEmptyQuery(connection) {
    if (this.rows) {
      connection.sync()
    }
  }

  handleError(err, connection) {
    // need to sync after error during a prepared statement
    if (this._canceledDueToError) {
      err = this._canceledDueToError
      this._canceledDueToError = false
    }
    // if callback supplied do not emit error event as uncaught error
    // events will bubble up to node process
    if (this.callback) {
      return this.callback(err)
    }
    this.emit('error', err)
  }

  handleReadyForQuery(con) {
    if (this._canceledDueToError) {
      return this.handleError(this._canceledDueToError, con)
    }
    if (this.callback) {
      this.callback(null, this._results)
    }
    this.emit('end', this._results)
  }

  submit(connection) {
    if (typeof this.text !== 'string' && typeof this.name !== 'string') {
      return new Error('A query must have either text or a name. Supplying neither is unsupported.')
    }
    const previous = connection.parsedStatements[this.name]
    if (this.text && previous && this.text !== previous) {
      return new Error(`Prepared statements must be unique - '${this.name}' was used for a different statement`)
    }
    if (this.values && !Array.isArray(this.values)) {
      return new Error('Query values must be an array')
    }
    if (this.requiresPreparation()) {
      this.prepare(connection)
    } else {
      connection.query(this.text)
    }
    return null
  }

  hasBeenParsed(connection) {
    return this.name && connection.parsedStatements[this.name]
  }

  handlePortalSuspended(connection) {
    this._getRows(connection, this.rows)
  }

  _getRows(connection, rows) {
    connection.execute({
      portal: this.portal,
      rows: rows,
    })
    // if we're not reading pages of rows send the sync command
    // to indicate the pipeline is finished
    if (!rows) {
      connection.sync()
    } else {
      // otherwise flush the call out to read more rows
      connection.flush()
    }
  }

  // http://developer.postgresql.org/pgdocs/postgres/protocol-flow.html#PROTOCOL-FLOW-EXT-QUERY
  prepare(connection) {
    // prepared statements need sync to be called after each command
    // complete or when an error is encountered
    this.isPreparedStatement = true

    // TODO refactor this poor encapsulation
    if (!this.hasBeenParsed(connection)) {
      connection.parse({
        text: this.text,
        name: this.name,
        types: this.types,
      })
    }

    // because we're mapping user supplied values to
    // postgres wire protocol compatible values it could
    // throw an exception, so try/catch this section
    try {
      connection.bind({
        portal: this.portal,
        statement: this.name,
        values: this.values,
        binary: this.binary,
        valueMapper: utils.prepareValue,
      })
    } catch (err) {
      this.handleError(err, connection)
      return
    }

    connection.describe({
      type: 'P',
      name: this.portal || '',
    })

    this._getRows(connection, this.rows)
  }

  handleCopyInResponse(connection) {
    connection.sendCopyFail('No source stream defined')
  }

  // eslint-disable-next-line no-unused-vars
  handleCopyData(msg, connection) {
    // noop
  }
}

module.exports = Query


/***/ }),

/***/ 3758:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var types = __webpack_require__(3619)

var matchRegexp = /^([A-Za-z]+)(?: (\d+))?(?: (\d+))?/

// result object returned from query
// in the 'end' event and also
// passed as second argument to provided callback
class Result {
  constructor(rowMode, types) {
    this.command = null
    this.rowCount = null
    this.oid = null
    this.rows = []
    this.fields = []
    this._parsers = undefined
    this._types = types
    this.RowCtor = null
    this.rowAsArray = rowMode === 'array'
    if (this.rowAsArray) {
      this.parseRow = this._parseRowAsArray
    }
  }

  // adds a command complete message
  addCommandComplete(msg) {
    var match
    if (msg.text) {
      // pure javascript
      match = matchRegexp.exec(msg.text)
    } else {
      // native bindings
      match = matchRegexp.exec(msg.command)
    }
    if (match) {
      this.command = match[1]
      if (match[3]) {
        // COMMMAND OID ROWS
        this.oid = parseInt(match[2], 10)
        this.rowCount = parseInt(match[3], 10)
      } else if (match[2]) {
        // COMMAND ROWS
        this.rowCount = parseInt(match[2], 10)
      }
    }
  }

  _parseRowAsArray(rowData) {
    var row = new Array(rowData.length)
    for (var i = 0, len = rowData.length; i < len; i++) {
      var rawValue = rowData[i]
      if (rawValue !== null) {
        row[i] = this._parsers[i](rawValue)
      } else {
        row[i] = null
      }
    }
    return row
  }

  parseRow(rowData) {
    var row = {}
    for (var i = 0, len = rowData.length; i < len; i++) {
      var rawValue = rowData[i]
      var field = this.fields[i].name
      if (rawValue !== null) {
        row[field] = this._parsers[i](rawValue)
      } else {
        row[field] = null
      }
    }
    return row
  }

  addRow(row) {
    this.rows.push(row)
  }

  addFields(fieldDescriptions) {
    // clears field definitions
    // multiple query statements in 1 action can result in multiple sets
    // of rowDescriptions...eg: 'select NOW(); select 1::int;'
    // you need to reset the fields
    this.fields = fieldDescriptions
    if (this.fields.length) {
      this._parsers = new Array(fieldDescriptions.length)
    }
    for (var i = 0; i < fieldDescriptions.length; i++) {
      var desc = fieldDescriptions[i]
      if (this._types) {
        this._parsers[i] = this._types.getTypeParser(desc.dataTypeID, desc.format || 'text')
      } else {
        this._parsers[i] = types.getTypeParser(desc.dataTypeID, desc.format || 'text')
      }
    }
  }
}

module.exports = Result


/***/ }),

/***/ 4615:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

const crypto = __webpack_require__(6417)

function startSession(mechanisms) {
  if (mechanisms.indexOf('SCRAM-SHA-256') === -1) {
    throw new Error('SASL: Only mechanism SCRAM-SHA-256 is currently supported')
  }

  const clientNonce = crypto.randomBytes(18).toString('base64')

  return {
    mechanism: 'SCRAM-SHA-256',
    clientNonce,
    response: 'n,,n=*,r=' + clientNonce,
    message: 'SASLInitialResponse',
  }
}

function continueSession(session, password, serverData) {
  if (session.message !== 'SASLInitialResponse') {
    throw new Error('SASL: Last message was not SASLInitialResponse')
  }
  if (typeof password !== 'string') {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: client password must be a string')
  }
  if (typeof serverData !== 'string') {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: serverData must be a string')
  }

  const sv = parseServerFirstMessage(serverData)

  if (!sv.nonce.startsWith(session.clientNonce)) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: server nonce does not start with client nonce')
  } else if (sv.nonce.length === session.clientNonce.length) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: server nonce is too short')
  }

  var saltBytes = Buffer.from(sv.salt, 'base64')

  var saltedPassword = Hi(password, saltBytes, sv.iteration)

  var clientKey = hmacSha256(saltedPassword, 'Client Key')
  var storedKey = sha256(clientKey)

  var clientFirstMessageBare = 'n=*,r=' + session.clientNonce
  var serverFirstMessage = 'r=' + sv.nonce + ',s=' + sv.salt + ',i=' + sv.iteration

  var clientFinalMessageWithoutProof = 'c=biws,r=' + sv.nonce

  var authMessage = clientFirstMessageBare + ',' + serverFirstMessage + ',' + clientFinalMessageWithoutProof

  var clientSignature = hmacSha256(storedKey, authMessage)
  var clientProofBytes = xorBuffers(clientKey, clientSignature)
  var clientProof = clientProofBytes.toString('base64')

  var serverKey = hmacSha256(saltedPassword, 'Server Key')
  var serverSignatureBytes = hmacSha256(serverKey, authMessage)

  session.message = 'SASLResponse'
  session.serverSignature = serverSignatureBytes.toString('base64')
  session.response = clientFinalMessageWithoutProof + ',p=' + clientProof
}

function finalizeSession(session, serverData) {
  if (session.message !== 'SASLResponse') {
    throw new Error('SASL: Last message was not SASLResponse')
  }
  if (typeof serverData !== 'string') {
    throw new Error('SASL: SCRAM-SERVER-FINAL-MESSAGE: serverData must be a string')
  }

  const { serverSignature } = parseServerFinalMessage(serverData)

  if (serverSignature !== session.serverSignature) {
    throw new Error('SASL: SCRAM-SERVER-FINAL-MESSAGE: server signature does not match')
  }
}

/**
 * printable       = %x21-2B / %x2D-7E
 *                   ;; Printable ASCII except ",".
 *                   ;; Note that any "printable" is also
 *                   ;; a valid "value".
 */
function isPrintableChars(text) {
  if (typeof text !== 'string') {
    throw new TypeError('SASL: text must be a string')
  }
  return text
    .split('')
    .map((_, i) => text.charCodeAt(i))
    .every((c) => (c >= 0x21 && c <= 0x2b) || (c >= 0x2d && c <= 0x7e))
}

/**
 * base64-char     = ALPHA / DIGIT / "/" / "+"
 *
 * base64-4        = 4base64-char
 *
 * base64-3        = 3base64-char "="
 *
 * base64-2        = 2base64-char "=="
 *
 * base64          = *base64-4 [base64-3 / base64-2]
 */
function isBase64(text) {
  return /^(?:[a-zA-Z0-9+/]{4})*(?:[a-zA-Z0-9+/]{2}==|[a-zA-Z0-9+/]{3}=)?$/.test(text)
}

function parseAttributePairs(text) {
  if (typeof text !== 'string') {
    throw new TypeError('SASL: attribute pairs text must be a string')
  }

  return new Map(
    text.split(',').map((attrValue) => {
      if (!/^.=/.test(attrValue)) {
        throw new Error('SASL: Invalid attribute pair entry')
      }
      const name = attrValue[0]
      const value = attrValue.substring(2)
      return [name, value]
    })
  )
}

function parseServerFirstMessage(data) {
  const attrPairs = parseAttributePairs(data)

  const nonce = attrPairs.get('r')
  if (!nonce) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: nonce missing')
  } else if (!isPrintableChars(nonce)) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: nonce must only contain printable characters')
  }
  const salt = attrPairs.get('s')
  if (!salt) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: salt missing')
  } else if (!isBase64(salt)) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: salt must be base64')
  }
  const iterationText = attrPairs.get('i')
  if (!iterationText) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: iteration missing')
  } else if (!/^[1-9][0-9]*$/.test(iterationText)) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: invalid iteration count')
  }
  const iteration = parseInt(iterationText, 10)

  return {
    nonce,
    salt,
    iteration,
  }
}

function parseServerFinalMessage(serverData) {
  const attrPairs = parseAttributePairs(serverData)
  const serverSignature = attrPairs.get('v')
  if (!serverSignature) {
    throw new Error('SASL: SCRAM-SERVER-FINAL-MESSAGE: server signature is missing')
  } else if (!isBase64(serverSignature)) {
    throw new Error('SASL: SCRAM-SERVER-FINAL-MESSAGE: server signature must be base64')
  }
  return {
    serverSignature,
  }
}

function xorBuffers(a, b) {
  if (!Buffer.isBuffer(a)) {
    throw new TypeError('first argument must be a Buffer')
  }
  if (!Buffer.isBuffer(b)) {
    throw new TypeError('second argument must be a Buffer')
  }
  if (a.length !== b.length) {
    throw new Error('Buffer lengths must match')
  }
  if (a.length === 0) {
    throw new Error('Buffers cannot be empty')
  }
  return Buffer.from(a.map((_, i) => a[i] ^ b[i]))
}

function sha256(text) {
  return crypto.createHash('sha256').update(text).digest()
}

function hmacSha256(key, msg) {
  return crypto.createHmac('sha256', key).update(msg).digest()
}

function Hi(password, saltBytes, iterations) {
  var ui1 = hmacSha256(password, Buffer.concat([saltBytes, Buffer.from([0, 0, 0, 1])]))
  var ui = ui1
  for (var i = 0; i < iterations - 1; i++) {
    ui1 = hmacSha256(password, ui1)
    ui = xorBuffers(ui, ui1)
  }

  return ui
}

module.exports = {
  startSession,
  continueSession,
  finalizeSession,
}


/***/ }),

/***/ 5701:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var types = __webpack_require__(3619)

function TypeOverrides(userTypes) {
  this._types = userTypes || types
  this.text = {}
  this.binary = {}
}

TypeOverrides.prototype.getOverrides = function (format) {
  switch (format) {
    case 'text':
      return this.text
    case 'binary':
      return this.binary
    default:
      return {}
  }
}

TypeOverrides.prototype.setTypeParser = function (oid, format, parseFn) {
  if (typeof format === 'function') {
    parseFn = format
    format = 'text'
  }
  this.getOverrides(format)[oid] = parseFn
}

TypeOverrides.prototype.getTypeParser = function (oid, format) {
  format = format || 'text'
  return this.getOverrides(format)[oid] || this._types.getTypeParser(oid, format)
}

module.exports = TypeOverrides


/***/ }),

/***/ 1262:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


const crypto = __webpack_require__(6417)

const defaults = __webpack_require__(7433)

function escapeElement(elementRepresentation) {
  var escaped = elementRepresentation.replace(/\\/g, '\\\\').replace(/"/g, '\\"')

  return '"' + escaped + '"'
}

// convert a JS array to a postgres array literal
// uses comma separator so won't work for types like box that use
// a different array separator.
function arrayString(val) {
  var result = '{'
  for (var i = 0; i < val.length; i++) {
    if (i > 0) {
      result = result + ','
    }
    if (val[i] === null || typeof val[i] === 'undefined') {
      result = result + 'NULL'
    } else if (Array.isArray(val[i])) {
      result = result + arrayString(val[i])
    } else if (val[i] instanceof Buffer) {
      result += '\\\\x' + val[i].toString('hex')
    } else {
      result += escapeElement(prepareValue(val[i]))
    }
  }
  result = result + '}'
  return result
}

// converts values from javascript types
// to their 'raw' counterparts for use as a postgres parameter
// note: you can override this function to provide your own conversion mechanism
// for complex types, etc...
var prepareValue = function (val, seen) {
  // null and undefined are both null for postgres
  if (val == null) {
    return null
  }
  if (val instanceof Buffer) {
    return val
  }
  if (ArrayBuffer.isView(val)) {
    var buf = Buffer.from(val.buffer, val.byteOffset, val.byteLength)
    if (buf.length === val.byteLength) {
      return buf
    }
    return buf.slice(val.byteOffset, val.byteOffset + val.byteLength) // Node.js v4 does not support those Buffer.from params
  }
  if (val instanceof Date) {
    if (defaults.parseInputDatesAsUTC) {
      return dateToStringUTC(val)
    } else {
      return dateToString(val)
    }
  }
  if (Array.isArray(val)) {
    return arrayString(val)
  }
  if (typeof val === 'object') {
    return prepareObject(val, seen)
  }
  return val.toString()
}

function prepareObject(val, seen) {
  if (val && typeof val.toPostgres === 'function') {
    seen = seen || []
    if (seen.indexOf(val) !== -1) {
      throw new Error('circular reference detected while preparing "' + val + '" for query')
    }
    seen.push(val)

    return prepareValue(val.toPostgres(prepareValue), seen)
  }
  return JSON.stringify(val)
}

function pad(number, digits) {
  number = '' + number
  while (number.length < digits) {
    number = '0' + number
  }
  return number
}

function dateToString(date) {
  var offset = -date.getTimezoneOffset()

  var year = date.getFullYear()
  var isBCYear = year < 1
  if (isBCYear) year = Math.abs(year) + 1 // negative years are 1 off their BC representation

  var ret =
    pad(year, 4) +
    '-' +
    pad(date.getMonth() + 1, 2) +
    '-' +
    pad(date.getDate(), 2) +
    'T' +
    pad(date.getHours(), 2) +
    ':' +
    pad(date.getMinutes(), 2) +
    ':' +
    pad(date.getSeconds(), 2) +
    '.' +
    pad(date.getMilliseconds(), 3)

  if (offset < 0) {
    ret += '-'
    offset *= -1
  } else {
    ret += '+'
  }

  ret += pad(Math.floor(offset / 60), 2) + ':' + pad(offset % 60, 2)
  if (isBCYear) ret += ' BC'
  return ret
}

function dateToStringUTC(date) {
  var year = date.getUTCFullYear()
  var isBCYear = year < 1
  if (isBCYear) year = Math.abs(year) + 1 // negative years are 1 off their BC representation

  var ret =
    pad(year, 4) +
    '-' +
    pad(date.getUTCMonth() + 1, 2) +
    '-' +
    pad(date.getUTCDate(), 2) +
    'T' +
    pad(date.getUTCHours(), 2) +
    ':' +
    pad(date.getUTCMinutes(), 2) +
    ':' +
    pad(date.getUTCSeconds(), 2) +
    '.' +
    pad(date.getUTCMilliseconds(), 3)

  ret += '+00:00'
  if (isBCYear) ret += ' BC'
  return ret
}

function normalizeQueryConfig(config, values, callback) {
  // can take in strings or config objects
  config = typeof config === 'string' ? { text: config } : config
  if (values) {
    if (typeof values === 'function') {
      config.callback = values
    } else {
      config.values = values
    }
  }
  if (callback) {
    config.callback = callback
  }
  return config
}

const md5 = function (string) {
  return crypto.createHash('md5').update(string, 'utf-8').digest('hex')
}

// See AuthenticationMD5Password at https://www.postgresql.org/docs/current/static/protocol-flow.html
const postgresMd5PasswordHash = function (user, password, salt) {
  var inner = md5(password + user)
  var outer = md5(Buffer.concat([Buffer.from(inner), salt]))
  return 'md5' + outer
}

module.exports = {
  prepareValue: function prepareValueWrapper(value) {
    // this ensures that extra arguments do not get passed into prepareValue
    // by accident, eg: from calling values.map(utils.prepareValue)
    return prepareValue(value)
  },
  normalizeQueryConfig,
  postgresMd5PasswordHash,
  md5,
}


/***/ }),

/***/ 8242:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var path = __webpack_require__(5622)
  , Stream = __webpack_require__(2413).Stream
  , split = __webpack_require__(861)
  , util = __webpack_require__(1669)
  , defaultPort = 5432
  , isWin = (process.platform === 'win32')
  , warnStream = process.stderr
;


var S_IRWXG = 56     //    00070(8)
  , S_IRWXO = 7      //    00007(8)
  , S_IFMT  = 61440  // 00170000(8)
  , S_IFREG = 32768  //  0100000(8)
;
function isRegFile(mode) {
    return ((mode & S_IFMT) == S_IFREG);
}

var fieldNames = [ 'host', 'port', 'database', 'user', 'password' ];
var nrOfFields = fieldNames.length;
var passKey = fieldNames[ nrOfFields -1 ];


function warn() {
    var isWritable = (
        warnStream instanceof Stream &&
          true === warnStream.writable
    );

    if (isWritable) {
        var args = Array.prototype.slice.call(arguments).concat("\n");
        warnStream.write( util.format.apply(util, args) );
    }
}


Object.defineProperty(module.exports, "isWin", ({
    get : function() {
        return isWin;
    } ,
    set : function(val) {
        isWin = val;
    }
}));


module.exports.warnTo = function(stream) {
    var old = warnStream;
    warnStream = stream;
    return old;
};

module.exports.getFileName = function(rawEnv){
    var env = rawEnv || process.env;
    var file = env.PGPASSFILE || (
        isWin ?
          path.join( env.APPDATA || './' , 'postgresql', 'pgpass.conf' ) :
          path.join( env.HOME || './', '.pgpass' )
    );
    return file;
};

module.exports.usePgPass = function(stats, fname) {
    if (Object.prototype.hasOwnProperty.call(process.env, 'PGPASSWORD')) {
        return false;
    }

    if (isWin) {
        return true;
    }

    fname = fname || '<unkn>';

    if (! isRegFile(stats.mode)) {
        warn('WARNING: password file "%s" is not a plain file', fname);
        return false;
    }

    if (stats.mode & (S_IRWXG | S_IRWXO)) {
        /* If password file is insecure, alert the user and ignore it. */
        warn('WARNING: password file "%s" has group or world access; permissions should be u=rw (0600) or less', fname);
        return false;
    }

    return true;
};


var matcher = module.exports.match = function(connInfo, entry) {
    return fieldNames.slice(0, -1).reduce(function(prev, field, idx){
        if (idx == 1) {
            // the port
            if ( Number( connInfo[field] || defaultPort ) === Number( entry[field] ) ) {
                return prev && true;
            }
        }
        return prev && (
            entry[field] === '*' ||
              entry[field] === connInfo[field]
        );
    }, true);
};


module.exports.getPassword = function(connInfo, stream, cb) {
    var pass;
    var lineStream = stream.pipe(split());

    function onLine(line) {
        var entry = parseLine(line);
        if (entry && isValidEntry(entry) && matcher(connInfo, entry)) {
            pass = entry[passKey];
            lineStream.end(); // -> calls onEnd(), but pass is set now
        }
    }

    var onEnd = function() {
        stream.destroy();
        cb(pass);
    };

    var onErr = function(err) {
        stream.destroy();
        warn('WARNING: error on reading file: %s', err);
        cb(undefined);
    };

    stream.on('error', onErr);
    lineStream
        .on('data', onLine)
        .on('end', onEnd)
        .on('error', onErr)
    ;

};


var parseLine = module.exports.parseLine = function(line) {
    if (line.length < 11 || line.match(/^\s+#/)) {
        return null;
    }

    var curChar = '';
    var prevChar = '';
    var fieldIdx = 0;
    var startIdx = 0;
    var endIdx = 0;
    var obj = {};
    var isLastField = false;
    var addToObj = function(idx, i0, i1) {
        var field = line.substring(i0, i1);

        if (! Object.hasOwnProperty.call(process.env, 'PGPASS_NO_DEESCAPE')) {
            field = field.replace(/\\([:\\])/g, '$1');
        }

        obj[ fieldNames[idx] ] = field;
    };

    for (var i = 0 ; i < line.length-1 ; i += 1) {
        curChar = line.charAt(i+1);
        prevChar = line.charAt(i);

        isLastField = (fieldIdx == nrOfFields-1);

        if (isLastField) {
            addToObj(fieldIdx, startIdx);
            break;
        }

        if (i >= 0 && curChar == ':' && prevChar !== '\\') {
            addToObj(fieldIdx, startIdx, i+1);

            startIdx = i+2;
            fieldIdx += 1;
        }
    }

    obj = ( Object.keys(obj).length === nrOfFields ) ? obj : null;

    return obj;
};


var isValidEntry = module.exports.isValidEntry = function(entry){
    var rules = {
        // host
        0 : function(x){
            return x.length > 0;
        } ,
        // port
        1 : function(x){
            if (x === '*') {
                return true;
            }
            x = Number(x);
            return (
                isFinite(x) &&
                  x > 0 &&
                  x < 9007199254740992 &&
                  Math.floor(x) === x
            );
        } ,
        // database
        2 : function(x){
            return x.length > 0;
        } ,
        // username
        3 : function(x){
            return x.length > 0;
        } ,
        // password
        4 : function(x){
            return x.length > 0;
        }
    };

    for (var idx = 0 ; idx < fieldNames.length ; idx += 1) {
        var rule = rules[idx];
        var value = entry[ fieldNames[idx] ] || '';

        var res = rule(value);
        if (!res) {
            return false;
        }
    }

    return true;
};



/***/ }),

/***/ 8812:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var path = __webpack_require__(5622)
  , fs = __webpack_require__(5747)
  , helper = __webpack_require__(8242)
;


module.exports = function(connInfo, cb) {
    var file = helper.getFileName();
    
    fs.stat(file, function(err, stat){
        if (err || !helper.usePgPass(stat, file)) {
            return cb(undefined);
        }

        var st = fs.createReadStream(file);

        helper.getPassword(connInfo, st, cb);
    });
};

module.exports.warnTo = helper.warnTo;


/***/ }),

/***/ 7315:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


exports.parse = function (source, transform) {
  return new ArrayParser(source, transform).parse()
}

class ArrayParser {
  constructor (source, transform) {
    this.source = source
    this.transform = transform || identity
    this.position = 0
    this.entries = []
    this.recorded = []
    this.dimension = 0
  }

  isEof () {
    return this.position >= this.source.length
  }

  nextCharacter () {
    var character = this.source[this.position++]
    if (character === '\\') {
      return {
        value: this.source[this.position++],
        escaped: true
      }
    }
    return {
      value: character,
      escaped: false
    }
  }

  record (character) {
    this.recorded.push(character)
  }

  newEntry (includeEmpty) {
    var entry
    if (this.recorded.length > 0 || includeEmpty) {
      entry = this.recorded.join('')
      if (entry === 'NULL' && !includeEmpty) {
        entry = null
      }
      if (entry !== null) entry = this.transform(entry)
      this.entries.push(entry)
      this.recorded = []
    }
  }

  consumeDimensions () {
    if (this.source[0] === '[') {
      while (!this.isEof()) {
        var char = this.nextCharacter()
        if (char.value === '=') break
      }
    }
  }

  parse (nested) {
    var character, parser, quote
    this.consumeDimensions()
    while (!this.isEof()) {
      character = this.nextCharacter()
      if (character.value === '{' && !quote) {
        this.dimension++
        if (this.dimension > 1) {
          parser = new ArrayParser(this.source.substr(this.position - 1), this.transform)
          this.entries.push(parser.parse(true))
          this.position += parser.position - 2
        }
      } else if (character.value === '}' && !quote) {
        this.dimension--
        if (!this.dimension) {
          this.newEntry()
          if (nested) return this.entries
        }
      } else if (character.value === '"' && !character.escaped) {
        if (quote) this.newEntry(true)
        quote = !quote
      } else if (character.value === ',' && !quote) {
        this.newEntry()
      } else {
        this.record(character.value)
      }
    }
    if (this.dimension !== 0) {
      throw new Error('array dimension not balanced')
    }
    return this.entries
  }
}

function identity (value) {
  return value
}


/***/ }),

/***/ 3712:
/***/ ((module) => {

"use strict";


module.exports = function parseBytea (input) {
  if (/^\\x/.test(input)) {
    // new 'hex' style response (pg >9.0)
    return new Buffer(input.substr(2), 'hex')
  }
  var output = ''
  var i = 0
  while (i < input.length) {
    if (input[i] !== '\\') {
      output += input[i]
      ++i
    } else {
      if (/[0-7]{3}/.test(input.substr(i + 1, 3))) {
        output += String.fromCharCode(parseInt(input.substr(i + 1, 3), 8))
        i += 4
      } else {
        var backslashes = 1
        while (i + backslashes < input.length && input[i + backslashes] === '\\') {
          backslashes++
        }
        for (var k = 0; k < Math.floor(backslashes / 2); ++k) {
          output += '\\'
        }
        i += Math.floor(backslashes / 2) * 2
      }
    }
  }
  return new Buffer(output, 'binary')
}


/***/ }),

/***/ 3765:
/***/ ((module) => {

"use strict";


var DATE_TIME = /(\d{1,})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})(\.\d{1,})?.*?( BC)?$/
var DATE = /^(\d{1,})-(\d{2})-(\d{2})( BC)?$/
var TIME_ZONE = /([Z+-])(\d{2})?:?(\d{2})?:?(\d{2})?/
var INFINITY = /^-?infinity$/

module.exports = function parseDate (isoDate) {
  if (INFINITY.test(isoDate)) {
    // Capitalize to Infinity before passing to Number
    return Number(isoDate.replace('i', 'I'))
  }
  var matches = DATE_TIME.exec(isoDate)

  if (!matches) {
    // Force YYYY-MM-DD dates to be parsed as local time
    return getDate(isoDate) || null
  }

  var isBC = !!matches[8]
  var year = parseInt(matches[1], 10)
  if (isBC) {
    year = bcYearToNegativeYear(year)
  }

  var month = parseInt(matches[2], 10) - 1
  var day = matches[3]
  var hour = parseInt(matches[4], 10)
  var minute = parseInt(matches[5], 10)
  var second = parseInt(matches[6], 10)

  var ms = matches[7]
  ms = ms ? 1000 * parseFloat(ms) : 0

  var date
  var offset = timeZoneOffset(isoDate)
  if (offset != null) {
    date = new Date(Date.UTC(year, month, day, hour, minute, second, ms))

    // Account for years from 0 to 99 being interpreted as 1900-1999
    // by Date.UTC / the multi-argument form of the Date constructor
    if (is0To99(year)) {
      date.setUTCFullYear(year)
    }

    if (offset !== 0) {
      date.setTime(date.getTime() - offset)
    }
  } else {
    date = new Date(year, month, day, hour, minute, second, ms)

    if (is0To99(year)) {
      date.setFullYear(year)
    }
  }

  return date
}

function getDate (isoDate) {
  var matches = DATE.exec(isoDate)
  if (!matches) {
    return
  }

  var year = parseInt(matches[1], 10)
  var isBC = !!matches[4]
  if (isBC) {
    year = bcYearToNegativeYear(year)
  }

  var month = parseInt(matches[2], 10) - 1
  var day = matches[3]
  // YYYY-MM-DD will be parsed as local time
  var date = new Date(year, month, day)

  if (is0To99(year)) {
    date.setFullYear(year)
  }

  return date
}

// match timezones:
// Z (UTC)
// -05
// +06:30
function timeZoneOffset (isoDate) {
  if (isoDate.endsWith('+00')) {
    return 0
  }

  var zone = TIME_ZONE.exec(isoDate.split(' ')[1])
  if (!zone) return
  var type = zone[1]

  if (type === 'Z') {
    return 0
  }
  var sign = type === '-' ? -1 : 1
  var offset = parseInt(zone[2], 10) * 3600 +
    parseInt(zone[3] || 0, 10) * 60 +
    parseInt(zone[4] || 0, 10)

  return offset * sign * 1000
}

function bcYearToNegativeYear (year) {
  // Account for numerical difference between representations of BC years
  // See: https://github.com/bendrucker/postgres-date/issues/5
  return -(year - 1)
}

function is0To99 (num) {
  return num >= 0 && num < 100
}


/***/ }),

/***/ 1055:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var extend = __webpack_require__(9820)

module.exports = PostgresInterval

function PostgresInterval (raw) {
  if (!(this instanceof PostgresInterval)) {
    return new PostgresInterval(raw)
  }
  extend(this, parse(raw))
}
var properties = ['seconds', 'minutes', 'hours', 'days', 'months', 'years']
PostgresInterval.prototype.toPostgres = function () {
  var filtered = properties.filter(this.hasOwnProperty, this)

  // In addition to `properties`, we need to account for fractions of seconds.
  if (this.milliseconds && filtered.indexOf('seconds') < 0) {
    filtered.push('seconds')
  }

  if (filtered.length === 0) return '0'
  return filtered
    .map(function (property) {
      var value = this[property] || 0

      // Account for fractional part of seconds,
      // remove trailing zeroes.
      if (property === 'seconds' && this.milliseconds) {
        value = (value + this.milliseconds / 1000).toFixed(6).replace(/\.?0+$/, '')
      }

      return value + ' ' + property
    }, this)
    .join(' ')
}

var propertiesISOEquivalent = {
  years: 'Y',
  months: 'M',
  days: 'D',
  hours: 'H',
  minutes: 'M',
  seconds: 'S'
}
var dateProperties = ['years', 'months', 'days']
var timeProperties = ['hours', 'minutes', 'seconds']
// according to ISO 8601
PostgresInterval.prototype.toISOString = PostgresInterval.prototype.toISO = function () {
  var datePart = dateProperties
    .map(buildProperty, this)
    .join('')

  var timePart = timeProperties
    .map(buildProperty, this)
    .join('')

  return 'P' + datePart + 'T' + timePart

  function buildProperty (property) {
    var value = this[property] || 0

    // Account for fractional part of seconds,
    // remove trailing zeroes.
    if (property === 'seconds' && this.milliseconds) {
      value = (value + this.milliseconds / 1000).toFixed(6).replace(/0+$/, '')
    }

    return value + propertiesISOEquivalent[property]
  }
}

var NUMBER = '([+-]?\\d+)'
var YEAR = NUMBER + '\\s+years?'
var MONTH = NUMBER + '\\s+mons?'
var DAY = NUMBER + '\\s+days?'
var TIME = '([+-])?([\\d]*):(\\d\\d):(\\d\\d)\\.?(\\d{1,6})?'
var INTERVAL = new RegExp([YEAR, MONTH, DAY, TIME].map(function (regexString) {
  return '(' + regexString + ')?'
})
  .join('\\s*'))

// Positions of values in regex match
var positions = {
  years: 2,
  months: 4,
  days: 6,
  hours: 9,
  minutes: 10,
  seconds: 11,
  milliseconds: 12
}
// We can use negative time
var negatives = ['hours', 'minutes', 'seconds', 'milliseconds']

function parseMilliseconds (fraction) {
  // add omitted zeroes
  var microseconds = fraction + '000000'.slice(fraction.length)
  return parseInt(microseconds, 10) / 1000
}

function parse (interval) {
  if (!interval) return {}
  var matches = INTERVAL.exec(interval)
  var isNegative = matches[8] === '-'
  return Object.keys(positions)
    .reduce(function (parsed, property) {
      var position = positions[property]
      var value = matches[position]
      // no empty string
      if (!value) return parsed
      // milliseconds are actually microseconds (up to 6 digits)
      // with omitted trailing zeroes.
      value = property === 'milliseconds'
        ? parseMilliseconds(value)
        : parseInt(value, 10)
      // no zeros
      if (!value) return parsed
      if (isNegative && ~negatives.indexOf(property)) {
        value *= -1
      }
      parsed[property] = value
      return parsed
    }, {})
}


/***/ }),

/***/ 4012:
/***/ ((module) => {

"use strict";


const codes = {};

function createErrorType(code, message, Base) {
  if (!Base) {
    Base = Error
  }

  function getMessage (arg1, arg2, arg3) {
    if (typeof message === 'string') {
      return message
    } else {
      return message(arg1, arg2, arg3)
    }
  }

  class NodeError extends Base {
    constructor (arg1, arg2, arg3) {
      super(getMessage(arg1, arg2, arg3));
    }
  }

  NodeError.prototype.name = Base.name;
  NodeError.prototype.code = code;

  codes[code] = NodeError;
}

// https://github.com/nodejs/node/blob/v10.8.0/lib/internal/errors.js
function oneOf(expected, thing) {
  if (Array.isArray(expected)) {
    const len = expected.length;
    expected = expected.map((i) => String(i));
    if (len > 2) {
      return `one of ${thing} ${expected.slice(0, len - 1).join(', ')}, or ` +
             expected[len - 1];
    } else if (len === 2) {
      return `one of ${thing} ${expected[0]} or ${expected[1]}`;
    } else {
      return `of ${thing} ${expected[0]}`;
    }
  } else {
    return `of ${thing} ${String(expected)}`;
  }
}

// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/startsWith
function startsWith(str, search, pos) {
	return str.substr(!pos || pos < 0 ? 0 : +pos, search.length) === search;
}

// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/endsWith
function endsWith(str, search, this_len) {
	if (this_len === undefined || this_len > str.length) {
		this_len = str.length;
	}
	return str.substring(this_len - search.length, this_len) === search;
}

// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/includes
function includes(str, search, start) {
  if (typeof start !== 'number') {
    start = 0;
  }

  if (start + search.length > str.length) {
    return false;
  } else {
    return str.indexOf(search, start) !== -1;
  }
}

createErrorType('ERR_INVALID_OPT_VALUE', function (name, value) {
  return 'The value "' + value + '" is invalid for option "' + name + '"'
}, TypeError);
createErrorType('ERR_INVALID_ARG_TYPE', function (name, expected, actual) {
  // determiner: 'must be' or 'must not be'
  let determiner;
  if (typeof expected === 'string' && startsWith(expected, 'not ')) {
    determiner = 'must not be';
    expected = expected.replace(/^not /, '');
  } else {
    determiner = 'must be';
  }

  let msg;
  if (endsWith(name, ' argument')) {
    // For cases like 'first argument'
    msg = `The ${name} ${determiner} ${oneOf(expected, 'type')}`;
  } else {
    const type = includes(name, '.') ? 'property' : 'argument';
    msg = `The "${name}" ${type} ${determiner} ${oneOf(expected, 'type')}`;
  }

  msg += `. Received type ${typeof actual}`;
  return msg;
}, TypeError);
createErrorType('ERR_STREAM_PUSH_AFTER_EOF', 'stream.push() after EOF');
createErrorType('ERR_METHOD_NOT_IMPLEMENTED', function (name) {
  return 'The ' + name + ' method is not implemented'
});
createErrorType('ERR_STREAM_PREMATURE_CLOSE', 'Premature close');
createErrorType('ERR_STREAM_DESTROYED', function (name) {
  return 'Cannot call ' + name + ' after a stream was destroyed';
});
createErrorType('ERR_MULTIPLE_CALLBACK', 'Callback called multiple times');
createErrorType('ERR_STREAM_CANNOT_PIPE', 'Cannot pipe, not readable');
createErrorType('ERR_STREAM_WRITE_AFTER_END', 'write after end');
createErrorType('ERR_STREAM_NULL_VALUES', 'May not write null values to stream', TypeError);
createErrorType('ERR_UNKNOWN_ENCODING', function (arg) {
  return 'Unknown encoding: ' + arg
}, TypeError);
createErrorType('ERR_STREAM_UNSHIFT_AFTER_END_EVENT', 'stream.unshift() after end event');

module.exports.q = codes;


/***/ }),

/***/ 6753:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.
// a duplex stream is just a stream that is both readable and writable.
// Since JS doesn't have multiple prototypal inheritance, this class
// prototypally inherits from Readable, and then parasitically from
// Writable.

/*<replacement>*/

var objectKeys = Object.keys || function (obj) {
  var keys = [];

  for (var key in obj) {
    keys.push(key);
  }

  return keys;
};
/*</replacement>*/


module.exports = Duplex;

var Readable = __webpack_require__(9481);

var Writable = __webpack_require__(4229);

__webpack_require__(4378)(Duplex, Readable);

{
  // Allow the keys array to be GC'ed.
  var keys = objectKeys(Writable.prototype);

  for (var v = 0; v < keys.length; v++) {
    var method = keys[v];
    if (!Duplex.prototype[method]) Duplex.prototype[method] = Writable.prototype[method];
  }
}

function Duplex(options) {
  if (!(this instanceof Duplex)) return new Duplex(options);
  Readable.call(this, options);
  Writable.call(this, options);
  this.allowHalfOpen = true;

  if (options) {
    if (options.readable === false) this.readable = false;
    if (options.writable === false) this.writable = false;

    if (options.allowHalfOpen === false) {
      this.allowHalfOpen = false;
      this.once('end', onend);
    }
  }
}

Object.defineProperty(Duplex.prototype, 'writableHighWaterMark', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._writableState.highWaterMark;
  }
});
Object.defineProperty(Duplex.prototype, 'writableBuffer', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._writableState && this._writableState.getBuffer();
  }
});
Object.defineProperty(Duplex.prototype, 'writableLength', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._writableState.length;
  }
}); // the no-half-open enforcer

function onend() {
  // If the writable side ended, then we're ok.
  if (this._writableState.ended) return; // no more data can be written.
  // But allow more writes to happen in this tick.

  process.nextTick(onEndNT, this);
}

function onEndNT(self) {
  self.end();
}

Object.defineProperty(Duplex.prototype, 'destroyed', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    if (this._readableState === undefined || this._writableState === undefined) {
      return false;
    }

    return this._readableState.destroyed && this._writableState.destroyed;
  },
  set: function set(value) {
    // we ignore the value if the stream
    // has not been initialized yet
    if (this._readableState === undefined || this._writableState === undefined) {
      return;
    } // backward compatibility, the user is explicitly
    // managing destroyed


    this._readableState.destroyed = value;
    this._writableState.destroyed = value;
  }
});

/***/ }),

/***/ 2725:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.
// a passthrough stream.
// basically just the most minimal sort of Transform stream.
// Every written chunk gets output as-is.


module.exports = PassThrough;

var Transform = __webpack_require__(4605);

__webpack_require__(4378)(PassThrough, Transform);

function PassThrough(options) {
  if (!(this instanceof PassThrough)) return new PassThrough(options);
  Transform.call(this, options);
}

PassThrough.prototype._transform = function (chunk, encoding, cb) {
  cb(null, chunk);
};

/***/ }),

/***/ 9481:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.


module.exports = Readable;
/*<replacement>*/

var Duplex;
/*</replacement>*/

Readable.ReadableState = ReadableState;
/*<replacement>*/

var EE = __webpack_require__(8614).EventEmitter;

var EElistenerCount = function EElistenerCount(emitter, type) {
  return emitter.listeners(type).length;
};
/*</replacement>*/

/*<replacement>*/


var Stream = __webpack_require__(9740);
/*</replacement>*/


var Buffer = __webpack_require__(4293).Buffer;

var OurUint8Array = global.Uint8Array || function () {};

function _uint8ArrayToBuffer(chunk) {
  return Buffer.from(chunk);
}

function _isUint8Array(obj) {
  return Buffer.isBuffer(obj) || obj instanceof OurUint8Array;
}
/*<replacement>*/


var debugUtil = __webpack_require__(1669);

var debug;

if (debugUtil && debugUtil.debuglog) {
  debug = debugUtil.debuglog('stream');
} else {
  debug = function debug() {};
}
/*</replacement>*/


var BufferList = __webpack_require__(7327);

var destroyImpl = __webpack_require__(1195);

var _require = __webpack_require__(2457),
    getHighWaterMark = _require.getHighWaterMark;

var _require$codes = __webpack_require__(4012)/* .codes */ .q,
    ERR_INVALID_ARG_TYPE = _require$codes.ERR_INVALID_ARG_TYPE,
    ERR_STREAM_PUSH_AFTER_EOF = _require$codes.ERR_STREAM_PUSH_AFTER_EOF,
    ERR_METHOD_NOT_IMPLEMENTED = _require$codes.ERR_METHOD_NOT_IMPLEMENTED,
    ERR_STREAM_UNSHIFT_AFTER_END_EVENT = _require$codes.ERR_STREAM_UNSHIFT_AFTER_END_EVENT; // Lazy loaded to improve the startup performance.


var StringDecoder;
var createReadableStreamAsyncIterator;
var from;

__webpack_require__(4378)(Readable, Stream);

var errorOrDestroy = destroyImpl.errorOrDestroy;
var kProxyEvents = ['error', 'close', 'destroy', 'pause', 'resume'];

function prependListener(emitter, event, fn) {
  // Sadly this is not cacheable as some libraries bundle their own
  // event emitter implementation with them.
  if (typeof emitter.prependListener === 'function') return emitter.prependListener(event, fn); // This is a hack to make sure that our error handler is attached before any
  // userland ones.  NEVER DO THIS. This is here only because this code needs
  // to continue to work with older versions of Node.js that do not include
  // the prependListener() method. The goal is to eventually remove this hack.

  if (!emitter._events || !emitter._events[event]) emitter.on(event, fn);else if (Array.isArray(emitter._events[event])) emitter._events[event].unshift(fn);else emitter._events[event] = [fn, emitter._events[event]];
}

function ReadableState(options, stream, isDuplex) {
  Duplex = Duplex || __webpack_require__(6753);
  options = options || {}; // Duplex streams are both readable and writable, but share
  // the same options object.
  // However, some cases require setting options to different
  // values for the readable and the writable sides of the duplex stream.
  // These options can be provided separately as readableXXX and writableXXX.

  if (typeof isDuplex !== 'boolean') isDuplex = stream instanceof Duplex; // object stream flag. Used to make read(n) ignore n and to
  // make all the buffer merging and length checks go away

  this.objectMode = !!options.objectMode;
  if (isDuplex) this.objectMode = this.objectMode || !!options.readableObjectMode; // the point at which it stops calling _read() to fill the buffer
  // Note: 0 is a valid value, means "don't call _read preemptively ever"

  this.highWaterMark = getHighWaterMark(this, options, 'readableHighWaterMark', isDuplex); // A linked list is used to store data chunks instead of an array because the
  // linked list can remove elements from the beginning faster than
  // array.shift()

  this.buffer = new BufferList();
  this.length = 0;
  this.pipes = null;
  this.pipesCount = 0;
  this.flowing = null;
  this.ended = false;
  this.endEmitted = false;
  this.reading = false; // a flag to be able to tell if the event 'readable'/'data' is emitted
  // immediately, or on a later tick.  We set this to true at first, because
  // any actions that shouldn't happen until "later" should generally also
  // not happen before the first read call.

  this.sync = true; // whenever we return null, then we set a flag to say
  // that we're awaiting a 'readable' event emission.

  this.needReadable = false;
  this.emittedReadable = false;
  this.readableListening = false;
  this.resumeScheduled = false;
  this.paused = true; // Should close be emitted on destroy. Defaults to true.

  this.emitClose = options.emitClose !== false; // Should .destroy() be called after 'end' (and potentially 'finish')

  this.autoDestroy = !!options.autoDestroy; // has it been destroyed

  this.destroyed = false; // Crypto is kind of old and crusty.  Historically, its default string
  // encoding is 'binary' so we have to make this configurable.
  // Everything else in the universe uses 'utf8', though.

  this.defaultEncoding = options.defaultEncoding || 'utf8'; // the number of writers that are awaiting a drain event in .pipe()s

  this.awaitDrain = 0; // if true, a maybeReadMore has been scheduled

  this.readingMore = false;
  this.decoder = null;
  this.encoding = null;

  if (options.encoding) {
    if (!StringDecoder) StringDecoder = __webpack_require__(2553)/* .StringDecoder */ .s;
    this.decoder = new StringDecoder(options.encoding);
    this.encoding = options.encoding;
  }
}

function Readable(options) {
  Duplex = Duplex || __webpack_require__(6753);
  if (!(this instanceof Readable)) return new Readable(options); // Checking for a Stream.Duplex instance is faster here instead of inside
  // the ReadableState constructor, at least with V8 6.5

  var isDuplex = this instanceof Duplex;
  this._readableState = new ReadableState(options, this, isDuplex); // legacy

  this.readable = true;

  if (options) {
    if (typeof options.read === 'function') this._read = options.read;
    if (typeof options.destroy === 'function') this._destroy = options.destroy;
  }

  Stream.call(this);
}

Object.defineProperty(Readable.prototype, 'destroyed', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    if (this._readableState === undefined) {
      return false;
    }

    return this._readableState.destroyed;
  },
  set: function set(value) {
    // we ignore the value if the stream
    // has not been initialized yet
    if (!this._readableState) {
      return;
    } // backward compatibility, the user is explicitly
    // managing destroyed


    this._readableState.destroyed = value;
  }
});
Readable.prototype.destroy = destroyImpl.destroy;
Readable.prototype._undestroy = destroyImpl.undestroy;

Readable.prototype._destroy = function (err, cb) {
  cb(err);
}; // Manually shove something into the read() buffer.
// This returns true if the highWaterMark has not been hit yet,
// similar to how Writable.write() returns true if you should
// write() some more.


Readable.prototype.push = function (chunk, encoding) {
  var state = this._readableState;
  var skipChunkCheck;

  if (!state.objectMode) {
    if (typeof chunk === 'string') {
      encoding = encoding || state.defaultEncoding;

      if (encoding !== state.encoding) {
        chunk = Buffer.from(chunk, encoding);
        encoding = '';
      }

      skipChunkCheck = true;
    }
  } else {
    skipChunkCheck = true;
  }

  return readableAddChunk(this, chunk, encoding, false, skipChunkCheck);
}; // Unshift should *always* be something directly out of read()


Readable.prototype.unshift = function (chunk) {
  return readableAddChunk(this, chunk, null, true, false);
};

function readableAddChunk(stream, chunk, encoding, addToFront, skipChunkCheck) {
  debug('readableAddChunk', chunk);
  var state = stream._readableState;

  if (chunk === null) {
    state.reading = false;
    onEofChunk(stream, state);
  } else {
    var er;
    if (!skipChunkCheck) er = chunkInvalid(state, chunk);

    if (er) {
      errorOrDestroy(stream, er);
    } else if (state.objectMode || chunk && chunk.length > 0) {
      if (typeof chunk !== 'string' && !state.objectMode && Object.getPrototypeOf(chunk) !== Buffer.prototype) {
        chunk = _uint8ArrayToBuffer(chunk);
      }

      if (addToFront) {
        if (state.endEmitted) errorOrDestroy(stream, new ERR_STREAM_UNSHIFT_AFTER_END_EVENT());else addChunk(stream, state, chunk, true);
      } else if (state.ended) {
        errorOrDestroy(stream, new ERR_STREAM_PUSH_AFTER_EOF());
      } else if (state.destroyed) {
        return false;
      } else {
        state.reading = false;

        if (state.decoder && !encoding) {
          chunk = state.decoder.write(chunk);
          if (state.objectMode || chunk.length !== 0) addChunk(stream, state, chunk, false);else maybeReadMore(stream, state);
        } else {
          addChunk(stream, state, chunk, false);
        }
      }
    } else if (!addToFront) {
      state.reading = false;
      maybeReadMore(stream, state);
    }
  } // We can push more data if we are below the highWaterMark.
  // Also, if we have no data yet, we can stand some more bytes.
  // This is to work around cases where hwm=0, such as the repl.


  return !state.ended && (state.length < state.highWaterMark || state.length === 0);
}

function addChunk(stream, state, chunk, addToFront) {
  if (state.flowing && state.length === 0 && !state.sync) {
    state.awaitDrain = 0;
    stream.emit('data', chunk);
  } else {
    // update the buffer info.
    state.length += state.objectMode ? 1 : chunk.length;
    if (addToFront) state.buffer.unshift(chunk);else state.buffer.push(chunk);
    if (state.needReadable) emitReadable(stream);
  }

  maybeReadMore(stream, state);
}

function chunkInvalid(state, chunk) {
  var er;

  if (!_isUint8Array(chunk) && typeof chunk !== 'string' && chunk !== undefined && !state.objectMode) {
    er = new ERR_INVALID_ARG_TYPE('chunk', ['string', 'Buffer', 'Uint8Array'], chunk);
  }

  return er;
}

Readable.prototype.isPaused = function () {
  return this._readableState.flowing === false;
}; // backwards compatibility.


Readable.prototype.setEncoding = function (enc) {
  if (!StringDecoder) StringDecoder = __webpack_require__(2553)/* .StringDecoder */ .s;
  var decoder = new StringDecoder(enc);
  this._readableState.decoder = decoder; // If setEncoding(null), decoder.encoding equals utf8

  this._readableState.encoding = this._readableState.decoder.encoding; // Iterate over current buffer to convert already stored Buffers:

  var p = this._readableState.buffer.head;
  var content = '';

  while (p !== null) {
    content += decoder.write(p.data);
    p = p.next;
  }

  this._readableState.buffer.clear();

  if (content !== '') this._readableState.buffer.push(content);
  this._readableState.length = content.length;
  return this;
}; // Don't raise the hwm > 1GB


var MAX_HWM = 0x40000000;

function computeNewHighWaterMark(n) {
  if (n >= MAX_HWM) {
    // TODO(ronag): Throw ERR_VALUE_OUT_OF_RANGE.
    n = MAX_HWM;
  } else {
    // Get the next highest power of 2 to prevent increasing hwm excessively in
    // tiny amounts
    n--;
    n |= n >>> 1;
    n |= n >>> 2;
    n |= n >>> 4;
    n |= n >>> 8;
    n |= n >>> 16;
    n++;
  }

  return n;
} // This function is designed to be inlinable, so please take care when making
// changes to the function body.


function howMuchToRead(n, state) {
  if (n <= 0 || state.length === 0 && state.ended) return 0;
  if (state.objectMode) return 1;

  if (n !== n) {
    // Only flow one buffer at a time
    if (state.flowing && state.length) return state.buffer.head.data.length;else return state.length;
  } // If we're asking for more than the current hwm, then raise the hwm.


  if (n > state.highWaterMark) state.highWaterMark = computeNewHighWaterMark(n);
  if (n <= state.length) return n; // Don't have enough

  if (!state.ended) {
    state.needReadable = true;
    return 0;
  }

  return state.length;
} // you can override either this method, or the async _read(n) below.


Readable.prototype.read = function (n) {
  debug('read', n);
  n = parseInt(n, 10);
  var state = this._readableState;
  var nOrig = n;
  if (n !== 0) state.emittedReadable = false; // if we're doing read(0) to trigger a readable event, but we
  // already have a bunch of data in the buffer, then just trigger
  // the 'readable' event and move on.

  if (n === 0 && state.needReadable && ((state.highWaterMark !== 0 ? state.length >= state.highWaterMark : state.length > 0) || state.ended)) {
    debug('read: emitReadable', state.length, state.ended);
    if (state.length === 0 && state.ended) endReadable(this);else emitReadable(this);
    return null;
  }

  n = howMuchToRead(n, state); // if we've ended, and we're now clear, then finish it up.

  if (n === 0 && state.ended) {
    if (state.length === 0) endReadable(this);
    return null;
  } // All the actual chunk generation logic needs to be
  // *below* the call to _read.  The reason is that in certain
  // synthetic stream cases, such as passthrough streams, _read
  // may be a completely synchronous operation which may change
  // the state of the read buffer, providing enough data when
  // before there was *not* enough.
  //
  // So, the steps are:
  // 1. Figure out what the state of things will be after we do
  // a read from the buffer.
  //
  // 2. If that resulting state will trigger a _read, then call _read.
  // Note that this may be asynchronous, or synchronous.  Yes, it is
  // deeply ugly to write APIs this way, but that still doesn't mean
  // that the Readable class should behave improperly, as streams are
  // designed to be sync/async agnostic.
  // Take note if the _read call is sync or async (ie, if the read call
  // has returned yet), so that we know whether or not it's safe to emit
  // 'readable' etc.
  //
  // 3. Actually pull the requested chunks out of the buffer and return.
  // if we need a readable event, then we need to do some reading.


  var doRead = state.needReadable;
  debug('need readable', doRead); // if we currently have less than the highWaterMark, then also read some

  if (state.length === 0 || state.length - n < state.highWaterMark) {
    doRead = true;
    debug('length less than watermark', doRead);
  } // however, if we've ended, then there's no point, and if we're already
  // reading, then it's unnecessary.


  if (state.ended || state.reading) {
    doRead = false;
    debug('reading or ended', doRead);
  } else if (doRead) {
    debug('do read');
    state.reading = true;
    state.sync = true; // if the length is currently zero, then we *need* a readable event.

    if (state.length === 0) state.needReadable = true; // call internal read method

    this._read(state.highWaterMark);

    state.sync = false; // If _read pushed data synchronously, then `reading` will be false,
    // and we need to re-evaluate how much data we can return to the user.

    if (!state.reading) n = howMuchToRead(nOrig, state);
  }

  var ret;
  if (n > 0) ret = fromList(n, state);else ret = null;

  if (ret === null) {
    state.needReadable = state.length <= state.highWaterMark;
    n = 0;
  } else {
    state.length -= n;
    state.awaitDrain = 0;
  }

  if (state.length === 0) {
    // If we have nothing in the buffer, then we want to know
    // as soon as we *do* get something into the buffer.
    if (!state.ended) state.needReadable = true; // If we tried to read() past the EOF, then emit end on the next tick.

    if (nOrig !== n && state.ended) endReadable(this);
  }

  if (ret !== null) this.emit('data', ret);
  return ret;
};

function onEofChunk(stream, state) {
  debug('onEofChunk');
  if (state.ended) return;

  if (state.decoder) {
    var chunk = state.decoder.end();

    if (chunk && chunk.length) {
      state.buffer.push(chunk);
      state.length += state.objectMode ? 1 : chunk.length;
    }
  }

  state.ended = true;

  if (state.sync) {
    // if we are sync, wait until next tick to emit the data.
    // Otherwise we risk emitting data in the flow()
    // the readable code triggers during a read() call
    emitReadable(stream);
  } else {
    // emit 'readable' now to make sure it gets picked up.
    state.needReadable = false;

    if (!state.emittedReadable) {
      state.emittedReadable = true;
      emitReadable_(stream);
    }
  }
} // Don't emit readable right away in sync mode, because this can trigger
// another read() call => stack overflow.  This way, it might trigger
// a nextTick recursion warning, but that's not so bad.


function emitReadable(stream) {
  var state = stream._readableState;
  debug('emitReadable', state.needReadable, state.emittedReadable);
  state.needReadable = false;

  if (!state.emittedReadable) {
    debug('emitReadable', state.flowing);
    state.emittedReadable = true;
    process.nextTick(emitReadable_, stream);
  }
}

function emitReadable_(stream) {
  var state = stream._readableState;
  debug('emitReadable_', state.destroyed, state.length, state.ended);

  if (!state.destroyed && (state.length || state.ended)) {
    stream.emit('readable');
    state.emittedReadable = false;
  } // The stream needs another readable event if
  // 1. It is not flowing, as the flow mechanism will take
  //    care of it.
  // 2. It is not ended.
  // 3. It is below the highWaterMark, so we can schedule
  //    another readable later.


  state.needReadable = !state.flowing && !state.ended && state.length <= state.highWaterMark;
  flow(stream);
} // at this point, the user has presumably seen the 'readable' event,
// and called read() to consume some data.  that may have triggered
// in turn another _read(n) call, in which case reading = true if
// it's in progress.
// However, if we're not ended, or reading, and the length < hwm,
// then go ahead and try to read some more preemptively.


function maybeReadMore(stream, state) {
  if (!state.readingMore) {
    state.readingMore = true;
    process.nextTick(maybeReadMore_, stream, state);
  }
}

function maybeReadMore_(stream, state) {
  // Attempt to read more data if we should.
  //
  // The conditions for reading more data are (one of):
  // - Not enough data buffered (state.length < state.highWaterMark). The loop
  //   is responsible for filling the buffer with enough data if such data
  //   is available. If highWaterMark is 0 and we are not in the flowing mode
  //   we should _not_ attempt to buffer any extra data. We'll get more data
  //   when the stream consumer calls read() instead.
  // - No data in the buffer, and the stream is in flowing mode. In this mode
  //   the loop below is responsible for ensuring read() is called. Failing to
  //   call read here would abort the flow and there's no other mechanism for
  //   continuing the flow if the stream consumer has just subscribed to the
  //   'data' event.
  //
  // In addition to the above conditions to keep reading data, the following
  // conditions prevent the data from being read:
  // - The stream has ended (state.ended).
  // - There is already a pending 'read' operation (state.reading). This is a
  //   case where the the stream has called the implementation defined _read()
  //   method, but they are processing the call asynchronously and have _not_
  //   called push() with new data. In this case we skip performing more
  //   read()s. The execution ends in this method again after the _read() ends
  //   up calling push() with more data.
  while (!state.reading && !state.ended && (state.length < state.highWaterMark || state.flowing && state.length === 0)) {
    var len = state.length;
    debug('maybeReadMore read 0');
    stream.read(0);
    if (len === state.length) // didn't get any data, stop spinning.
      break;
  }

  state.readingMore = false;
} // abstract method.  to be overridden in specific implementation classes.
// call cb(er, data) where data is <= n in length.
// for virtual (non-string, non-buffer) streams, "length" is somewhat
// arbitrary, and perhaps not very meaningful.


Readable.prototype._read = function (n) {
  errorOrDestroy(this, new ERR_METHOD_NOT_IMPLEMENTED('_read()'));
};

Readable.prototype.pipe = function (dest, pipeOpts) {
  var src = this;
  var state = this._readableState;

  switch (state.pipesCount) {
    case 0:
      state.pipes = dest;
      break;

    case 1:
      state.pipes = [state.pipes, dest];
      break;

    default:
      state.pipes.push(dest);
      break;
  }

  state.pipesCount += 1;
  debug('pipe count=%d opts=%j', state.pipesCount, pipeOpts);
  var doEnd = (!pipeOpts || pipeOpts.end !== false) && dest !== process.stdout && dest !== process.stderr;
  var endFn = doEnd ? onend : unpipe;
  if (state.endEmitted) process.nextTick(endFn);else src.once('end', endFn);
  dest.on('unpipe', onunpipe);

  function onunpipe(readable, unpipeInfo) {
    debug('onunpipe');

    if (readable === src) {
      if (unpipeInfo && unpipeInfo.hasUnpiped === false) {
        unpipeInfo.hasUnpiped = true;
        cleanup();
      }
    }
  }

  function onend() {
    debug('onend');
    dest.end();
  } // when the dest drains, it reduces the awaitDrain counter
  // on the source.  This would be more elegant with a .once()
  // handler in flow(), but adding and removing repeatedly is
  // too slow.


  var ondrain = pipeOnDrain(src);
  dest.on('drain', ondrain);
  var cleanedUp = false;

  function cleanup() {
    debug('cleanup'); // cleanup event handlers once the pipe is broken

    dest.removeListener('close', onclose);
    dest.removeListener('finish', onfinish);
    dest.removeListener('drain', ondrain);
    dest.removeListener('error', onerror);
    dest.removeListener('unpipe', onunpipe);
    src.removeListener('end', onend);
    src.removeListener('end', unpipe);
    src.removeListener('data', ondata);
    cleanedUp = true; // if the reader is waiting for a drain event from this
    // specific writer, then it would cause it to never start
    // flowing again.
    // So, if this is awaiting a drain, then we just call it now.
    // If we don't know, then assume that we are waiting for one.

    if (state.awaitDrain && (!dest._writableState || dest._writableState.needDrain)) ondrain();
  }

  src.on('data', ondata);

  function ondata(chunk) {
    debug('ondata');
    var ret = dest.write(chunk);
    debug('dest.write', ret);

    if (ret === false) {
      // If the user unpiped during `dest.write()`, it is possible
      // to get stuck in a permanently paused state if that write
      // also returned false.
      // => Check whether `dest` is still a piping destination.
      if ((state.pipesCount === 1 && state.pipes === dest || state.pipesCount > 1 && indexOf(state.pipes, dest) !== -1) && !cleanedUp) {
        debug('false write response, pause', state.awaitDrain);
        state.awaitDrain++;
      }

      src.pause();
    }
  } // if the dest has an error, then stop piping into it.
  // however, don't suppress the throwing behavior for this.


  function onerror(er) {
    debug('onerror', er);
    unpipe();
    dest.removeListener('error', onerror);
    if (EElistenerCount(dest, 'error') === 0) errorOrDestroy(dest, er);
  } // Make sure our error handler is attached before userland ones.


  prependListener(dest, 'error', onerror); // Both close and finish should trigger unpipe, but only once.

  function onclose() {
    dest.removeListener('finish', onfinish);
    unpipe();
  }

  dest.once('close', onclose);

  function onfinish() {
    debug('onfinish');
    dest.removeListener('close', onclose);
    unpipe();
  }

  dest.once('finish', onfinish);

  function unpipe() {
    debug('unpipe');
    src.unpipe(dest);
  } // tell the dest that it's being piped to


  dest.emit('pipe', src); // start the flow if it hasn't been started already.

  if (!state.flowing) {
    debug('pipe resume');
    src.resume();
  }

  return dest;
};

function pipeOnDrain(src) {
  return function pipeOnDrainFunctionResult() {
    var state = src._readableState;
    debug('pipeOnDrain', state.awaitDrain);
    if (state.awaitDrain) state.awaitDrain--;

    if (state.awaitDrain === 0 && EElistenerCount(src, 'data')) {
      state.flowing = true;
      flow(src);
    }
  };
}

Readable.prototype.unpipe = function (dest) {
  var state = this._readableState;
  var unpipeInfo = {
    hasUnpiped: false
  }; // if we're not piping anywhere, then do nothing.

  if (state.pipesCount === 0) return this; // just one destination.  most common case.

  if (state.pipesCount === 1) {
    // passed in one, but it's not the right one.
    if (dest && dest !== state.pipes) return this;
    if (!dest) dest = state.pipes; // got a match.

    state.pipes = null;
    state.pipesCount = 0;
    state.flowing = false;
    if (dest) dest.emit('unpipe', this, unpipeInfo);
    return this;
  } // slow case. multiple pipe destinations.


  if (!dest) {
    // remove all.
    var dests = state.pipes;
    var len = state.pipesCount;
    state.pipes = null;
    state.pipesCount = 0;
    state.flowing = false;

    for (var i = 0; i < len; i++) {
      dests[i].emit('unpipe', this, {
        hasUnpiped: false
      });
    }

    return this;
  } // try to find the right one.


  var index = indexOf(state.pipes, dest);
  if (index === -1) return this;
  state.pipes.splice(index, 1);
  state.pipesCount -= 1;
  if (state.pipesCount === 1) state.pipes = state.pipes[0];
  dest.emit('unpipe', this, unpipeInfo);
  return this;
}; // set up data events if they are asked for
// Ensure readable listeners eventually get something


Readable.prototype.on = function (ev, fn) {
  var res = Stream.prototype.on.call(this, ev, fn);
  var state = this._readableState;

  if (ev === 'data') {
    // update readableListening so that resume() may be a no-op
    // a few lines down. This is needed to support once('readable').
    state.readableListening = this.listenerCount('readable') > 0; // Try start flowing on next tick if stream isn't explicitly paused

    if (state.flowing !== false) this.resume();
  } else if (ev === 'readable') {
    if (!state.endEmitted && !state.readableListening) {
      state.readableListening = state.needReadable = true;
      state.flowing = false;
      state.emittedReadable = false;
      debug('on readable', state.length, state.reading);

      if (state.length) {
        emitReadable(this);
      } else if (!state.reading) {
        process.nextTick(nReadingNextTick, this);
      }
    }
  }

  return res;
};

Readable.prototype.addListener = Readable.prototype.on;

Readable.prototype.removeListener = function (ev, fn) {
  var res = Stream.prototype.removeListener.call(this, ev, fn);

  if (ev === 'readable') {
    // We need to check if there is someone still listening to
    // readable and reset the state. However this needs to happen
    // after readable has been emitted but before I/O (nextTick) to
    // support once('readable', fn) cycles. This means that calling
    // resume within the same tick will have no
    // effect.
    process.nextTick(updateReadableListening, this);
  }

  return res;
};

Readable.prototype.removeAllListeners = function (ev) {
  var res = Stream.prototype.removeAllListeners.apply(this, arguments);

  if (ev === 'readable' || ev === undefined) {
    // We need to check if there is someone still listening to
    // readable and reset the state. However this needs to happen
    // after readable has been emitted but before I/O (nextTick) to
    // support once('readable', fn) cycles. This means that calling
    // resume within the same tick will have no
    // effect.
    process.nextTick(updateReadableListening, this);
  }

  return res;
};

function updateReadableListening(self) {
  var state = self._readableState;
  state.readableListening = self.listenerCount('readable') > 0;

  if (state.resumeScheduled && !state.paused) {
    // flowing needs to be set to true now, otherwise
    // the upcoming resume will not flow.
    state.flowing = true; // crude way to check if we should resume
  } else if (self.listenerCount('data') > 0) {
    self.resume();
  }
}

function nReadingNextTick(self) {
  debug('readable nexttick read 0');
  self.read(0);
} // pause() and resume() are remnants of the legacy readable stream API
// If the user uses them, then switch into old mode.


Readable.prototype.resume = function () {
  var state = this._readableState;

  if (!state.flowing) {
    debug('resume'); // we flow only if there is no one listening
    // for readable, but we still have to call
    // resume()

    state.flowing = !state.readableListening;
    resume(this, state);
  }

  state.paused = false;
  return this;
};

function resume(stream, state) {
  if (!state.resumeScheduled) {
    state.resumeScheduled = true;
    process.nextTick(resume_, stream, state);
  }
}

function resume_(stream, state) {
  debug('resume', state.reading);

  if (!state.reading) {
    stream.read(0);
  }

  state.resumeScheduled = false;
  stream.emit('resume');
  flow(stream);
  if (state.flowing && !state.reading) stream.read(0);
}

Readable.prototype.pause = function () {
  debug('call pause flowing=%j', this._readableState.flowing);

  if (this._readableState.flowing !== false) {
    debug('pause');
    this._readableState.flowing = false;
    this.emit('pause');
  }

  this._readableState.paused = true;
  return this;
};

function flow(stream) {
  var state = stream._readableState;
  debug('flow', state.flowing);

  while (state.flowing && stream.read() !== null) {
    ;
  }
} // wrap an old-style stream as the async data source.
// This is *not* part of the readable stream interface.
// It is an ugly unfortunate mess of history.


Readable.prototype.wrap = function (stream) {
  var _this = this;

  var state = this._readableState;
  var paused = false;
  stream.on('end', function () {
    debug('wrapped end');

    if (state.decoder && !state.ended) {
      var chunk = state.decoder.end();
      if (chunk && chunk.length) _this.push(chunk);
    }

    _this.push(null);
  });
  stream.on('data', function (chunk) {
    debug('wrapped data');
    if (state.decoder) chunk = state.decoder.write(chunk); // don't skip over falsy values in objectMode

    if (state.objectMode && (chunk === null || chunk === undefined)) return;else if (!state.objectMode && (!chunk || !chunk.length)) return;

    var ret = _this.push(chunk);

    if (!ret) {
      paused = true;
      stream.pause();
    }
  }); // proxy all the other methods.
  // important when wrapping filters and duplexes.

  for (var i in stream) {
    if (this[i] === undefined && typeof stream[i] === 'function') {
      this[i] = function methodWrap(method) {
        return function methodWrapReturnFunction() {
          return stream[method].apply(stream, arguments);
        };
      }(i);
    }
  } // proxy certain important events.


  for (var n = 0; n < kProxyEvents.length; n++) {
    stream.on(kProxyEvents[n], this.emit.bind(this, kProxyEvents[n]));
  } // when we try to consume some more bytes, simply unpause the
  // underlying stream.


  this._read = function (n) {
    debug('wrapped _read', n);

    if (paused) {
      paused = false;
      stream.resume();
    }
  };

  return this;
};

if (typeof Symbol === 'function') {
  Readable.prototype[Symbol.asyncIterator] = function () {
    if (createReadableStreamAsyncIterator === undefined) {
      createReadableStreamAsyncIterator = __webpack_require__(5850);
    }

    return createReadableStreamAsyncIterator(this);
  };
}

Object.defineProperty(Readable.prototype, 'readableHighWaterMark', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._readableState.highWaterMark;
  }
});
Object.defineProperty(Readable.prototype, 'readableBuffer', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._readableState && this._readableState.buffer;
  }
});
Object.defineProperty(Readable.prototype, 'readableFlowing', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._readableState.flowing;
  },
  set: function set(state) {
    if (this._readableState) {
      this._readableState.flowing = state;
    }
  }
}); // exposed for testing purposes only.

Readable._fromList = fromList;
Object.defineProperty(Readable.prototype, 'readableLength', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._readableState.length;
  }
}); // Pluck off n bytes from an array of buffers.
// Length is the combined lengths of all the buffers in the list.
// This function is designed to be inlinable, so please take care when making
// changes to the function body.

function fromList(n, state) {
  // nothing buffered
  if (state.length === 0) return null;
  var ret;
  if (state.objectMode) ret = state.buffer.shift();else if (!n || n >= state.length) {
    // read it all, truncate the list
    if (state.decoder) ret = state.buffer.join('');else if (state.buffer.length === 1) ret = state.buffer.first();else ret = state.buffer.concat(state.length);
    state.buffer.clear();
  } else {
    // read part of list
    ret = state.buffer.consume(n, state.decoder);
  }
  return ret;
}

function endReadable(stream) {
  var state = stream._readableState;
  debug('endReadable', state.endEmitted);

  if (!state.endEmitted) {
    state.ended = true;
    process.nextTick(endReadableNT, state, stream);
  }
}

function endReadableNT(state, stream) {
  debug('endReadableNT', state.endEmitted, state.length); // Check that we didn't get one last unshift.

  if (!state.endEmitted && state.length === 0) {
    state.endEmitted = true;
    stream.readable = false;
    stream.emit('end');

    if (state.autoDestroy) {
      // In case of duplex streams we need a way to detect
      // if the writable side is ready for autoDestroy as well
      var wState = stream._writableState;

      if (!wState || wState.autoDestroy && wState.finished) {
        stream.destroy();
      }
    }
  }
}

if (typeof Symbol === 'function') {
  Readable.from = function (iterable, opts) {
    if (from === undefined) {
      from = __webpack_require__(6307);
    }

    return from(Readable, iterable, opts);
  };
}

function indexOf(xs, x) {
  for (var i = 0, l = xs.length; i < l; i++) {
    if (xs[i] === x) return i;
  }

  return -1;
}

/***/ }),

/***/ 4605:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.
// a transform stream is a readable/writable stream where you do
// something with the data.  Sometimes it's called a "filter",
// but that's not a great name for it, since that implies a thing where
// some bits pass through, and others are simply ignored.  (That would
// be a valid example of a transform, of course.)
//
// While the output is causally related to the input, it's not a
// necessarily symmetric or synchronous transformation.  For example,
// a zlib stream might take multiple plain-text writes(), and then
// emit a single compressed chunk some time in the future.
//
// Here's how this works:
//
// The Transform stream has all the aspects of the readable and writable
// stream classes.  When you write(chunk), that calls _write(chunk,cb)
// internally, and returns false if there's a lot of pending writes
// buffered up.  When you call read(), that calls _read(n) until
// there's enough pending readable data buffered up.
//
// In a transform stream, the written data is placed in a buffer.  When
// _read(n) is called, it transforms the queued up data, calling the
// buffered _write cb's as it consumes chunks.  If consuming a single
// written chunk would result in multiple output chunks, then the first
// outputted bit calls the readcb, and subsequent chunks just go into
// the read buffer, and will cause it to emit 'readable' if necessary.
//
// This way, back-pressure is actually determined by the reading side,
// since _read has to be called to start processing a new chunk.  However,
// a pathological inflate type of transform can cause excessive buffering
// here.  For example, imagine a stream where every byte of input is
// interpreted as an integer from 0-255, and then results in that many
// bytes of output.  Writing the 4 bytes {ff,ff,ff,ff} would result in
// 1kb of data being output.  In this case, you could write a very small
// amount of input, and end up with a very large amount of output.  In
// such a pathological inflating mechanism, there'd be no way to tell
// the system to stop doing the transform.  A single 4MB write could
// cause the system to run out of memory.
//
// However, even in such a pathological case, only a single written chunk
// would be consumed, and then the rest would wait (un-transformed) until
// the results of the previous transformed chunk were consumed.


module.exports = Transform;

var _require$codes = __webpack_require__(4012)/* .codes */ .q,
    ERR_METHOD_NOT_IMPLEMENTED = _require$codes.ERR_METHOD_NOT_IMPLEMENTED,
    ERR_MULTIPLE_CALLBACK = _require$codes.ERR_MULTIPLE_CALLBACK,
    ERR_TRANSFORM_ALREADY_TRANSFORMING = _require$codes.ERR_TRANSFORM_ALREADY_TRANSFORMING,
    ERR_TRANSFORM_WITH_LENGTH_0 = _require$codes.ERR_TRANSFORM_WITH_LENGTH_0;

var Duplex = __webpack_require__(6753);

__webpack_require__(4378)(Transform, Duplex);

function afterTransform(er, data) {
  var ts = this._transformState;
  ts.transforming = false;
  var cb = ts.writecb;

  if (cb === null) {
    return this.emit('error', new ERR_MULTIPLE_CALLBACK());
  }

  ts.writechunk = null;
  ts.writecb = null;
  if (data != null) // single equals check for both `null` and `undefined`
    this.push(data);
  cb(er);
  var rs = this._readableState;
  rs.reading = false;

  if (rs.needReadable || rs.length < rs.highWaterMark) {
    this._read(rs.highWaterMark);
  }
}

function Transform(options) {
  if (!(this instanceof Transform)) return new Transform(options);
  Duplex.call(this, options);
  this._transformState = {
    afterTransform: afterTransform.bind(this),
    needTransform: false,
    transforming: false,
    writecb: null,
    writechunk: null,
    writeencoding: null
  }; // start out asking for a readable event once data is transformed.

  this._readableState.needReadable = true; // we have implemented the _read method, and done the other things
  // that Readable wants before the first _read call, so unset the
  // sync guard flag.

  this._readableState.sync = false;

  if (options) {
    if (typeof options.transform === 'function') this._transform = options.transform;
    if (typeof options.flush === 'function') this._flush = options.flush;
  } // When the writable side finishes, then flush out anything remaining.


  this.on('prefinish', prefinish);
}

function prefinish() {
  var _this = this;

  if (typeof this._flush === 'function' && !this._readableState.destroyed) {
    this._flush(function (er, data) {
      done(_this, er, data);
    });
  } else {
    done(this, null, null);
  }
}

Transform.prototype.push = function (chunk, encoding) {
  this._transformState.needTransform = false;
  return Duplex.prototype.push.call(this, chunk, encoding);
}; // This is the part where you do stuff!
// override this function in implementation classes.
// 'chunk' is an input chunk.
//
// Call `push(newChunk)` to pass along transformed output
// to the readable side.  You may call 'push' zero or more times.
//
// Call `cb(err)` when you are done with this chunk.  If you pass
// an error, then that'll put the hurt on the whole operation.  If you
// never call cb(), then you'll never get another chunk.


Transform.prototype._transform = function (chunk, encoding, cb) {
  cb(new ERR_METHOD_NOT_IMPLEMENTED('_transform()'));
};

Transform.prototype._write = function (chunk, encoding, cb) {
  var ts = this._transformState;
  ts.writecb = cb;
  ts.writechunk = chunk;
  ts.writeencoding = encoding;

  if (!ts.transforming) {
    var rs = this._readableState;
    if (ts.needTransform || rs.needReadable || rs.length < rs.highWaterMark) this._read(rs.highWaterMark);
  }
}; // Doesn't matter what the args are here.
// _transform does all the work.
// That we got here means that the readable side wants more data.


Transform.prototype._read = function (n) {
  var ts = this._transformState;

  if (ts.writechunk !== null && !ts.transforming) {
    ts.transforming = true;

    this._transform(ts.writechunk, ts.writeencoding, ts.afterTransform);
  } else {
    // mark that we need a transform, so that any data that comes in
    // will get processed, now that we've asked for it.
    ts.needTransform = true;
  }
};

Transform.prototype._destroy = function (err, cb) {
  Duplex.prototype._destroy.call(this, err, function (err2) {
    cb(err2);
  });
};

function done(stream, er, data) {
  if (er) return stream.emit('error', er);
  if (data != null) // single equals check for both `null` and `undefined`
    stream.push(data); // TODO(BridgeAR): Write a test for these two error cases
  // if there's nothing in the write buffer, then that means
  // that nothing more will ever be provided

  if (stream._writableState.length) throw new ERR_TRANSFORM_WITH_LENGTH_0();
  if (stream._transformState.transforming) throw new ERR_TRANSFORM_ALREADY_TRANSFORMING();
  return stream.push(null);
}

/***/ }),

/***/ 4229:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.
// A bit simpler than readable streams.
// Implement an async ._write(chunk, encoding, cb), and it'll handle all
// the drain event emission and buffering.


module.exports = Writable;
/* <replacement> */

function WriteReq(chunk, encoding, cb) {
  this.chunk = chunk;
  this.encoding = encoding;
  this.callback = cb;
  this.next = null;
} // It seems a linked list but it is not
// there will be only 2 of these for each stream


function CorkedRequest(state) {
  var _this = this;

  this.next = null;
  this.entry = null;

  this.finish = function () {
    onCorkedFinish(_this, state);
  };
}
/* </replacement> */

/*<replacement>*/


var Duplex;
/*</replacement>*/

Writable.WritableState = WritableState;
/*<replacement>*/

var internalUtil = {
  deprecate: __webpack_require__(1159)
};
/*</replacement>*/

/*<replacement>*/

var Stream = __webpack_require__(9740);
/*</replacement>*/


var Buffer = __webpack_require__(4293).Buffer;

var OurUint8Array = global.Uint8Array || function () {};

function _uint8ArrayToBuffer(chunk) {
  return Buffer.from(chunk);
}

function _isUint8Array(obj) {
  return Buffer.isBuffer(obj) || obj instanceof OurUint8Array;
}

var destroyImpl = __webpack_require__(1195);

var _require = __webpack_require__(2457),
    getHighWaterMark = _require.getHighWaterMark;

var _require$codes = __webpack_require__(4012)/* .codes */ .q,
    ERR_INVALID_ARG_TYPE = _require$codes.ERR_INVALID_ARG_TYPE,
    ERR_METHOD_NOT_IMPLEMENTED = _require$codes.ERR_METHOD_NOT_IMPLEMENTED,
    ERR_MULTIPLE_CALLBACK = _require$codes.ERR_MULTIPLE_CALLBACK,
    ERR_STREAM_CANNOT_PIPE = _require$codes.ERR_STREAM_CANNOT_PIPE,
    ERR_STREAM_DESTROYED = _require$codes.ERR_STREAM_DESTROYED,
    ERR_STREAM_NULL_VALUES = _require$codes.ERR_STREAM_NULL_VALUES,
    ERR_STREAM_WRITE_AFTER_END = _require$codes.ERR_STREAM_WRITE_AFTER_END,
    ERR_UNKNOWN_ENCODING = _require$codes.ERR_UNKNOWN_ENCODING;

var errorOrDestroy = destroyImpl.errorOrDestroy;

__webpack_require__(4378)(Writable, Stream);

function nop() {}

function WritableState(options, stream, isDuplex) {
  Duplex = Duplex || __webpack_require__(6753);
  options = options || {}; // Duplex streams are both readable and writable, but share
  // the same options object.
  // However, some cases require setting options to different
  // values for the readable and the writable sides of the duplex stream,
  // e.g. options.readableObjectMode vs. options.writableObjectMode, etc.

  if (typeof isDuplex !== 'boolean') isDuplex = stream instanceof Duplex; // object stream flag to indicate whether or not this stream
  // contains buffers or objects.

  this.objectMode = !!options.objectMode;
  if (isDuplex) this.objectMode = this.objectMode || !!options.writableObjectMode; // the point at which write() starts returning false
  // Note: 0 is a valid value, means that we always return false if
  // the entire buffer is not flushed immediately on write()

  this.highWaterMark = getHighWaterMark(this, options, 'writableHighWaterMark', isDuplex); // if _final has been called

  this.finalCalled = false; // drain event flag.

  this.needDrain = false; // at the start of calling end()

  this.ending = false; // when end() has been called, and returned

  this.ended = false; // when 'finish' is emitted

  this.finished = false; // has it been destroyed

  this.destroyed = false; // should we decode strings into buffers before passing to _write?
  // this is here so that some node-core streams can optimize string
  // handling at a lower level.

  var noDecode = options.decodeStrings === false;
  this.decodeStrings = !noDecode; // Crypto is kind of old and crusty.  Historically, its default string
  // encoding is 'binary' so we have to make this configurable.
  // Everything else in the universe uses 'utf8', though.

  this.defaultEncoding = options.defaultEncoding || 'utf8'; // not an actual buffer we keep track of, but a measurement
  // of how much we're waiting to get pushed to some underlying
  // socket or file.

  this.length = 0; // a flag to see when we're in the middle of a write.

  this.writing = false; // when true all writes will be buffered until .uncork() call

  this.corked = 0; // a flag to be able to tell if the onwrite cb is called immediately,
  // or on a later tick.  We set this to true at first, because any
  // actions that shouldn't happen until "later" should generally also
  // not happen before the first write call.

  this.sync = true; // a flag to know if we're processing previously buffered items, which
  // may call the _write() callback in the same tick, so that we don't
  // end up in an overlapped onwrite situation.

  this.bufferProcessing = false; // the callback that's passed to _write(chunk,cb)

  this.onwrite = function (er) {
    onwrite(stream, er);
  }; // the callback that the user supplies to write(chunk,encoding,cb)


  this.writecb = null; // the amount that is being written when _write is called.

  this.writelen = 0;
  this.bufferedRequest = null;
  this.lastBufferedRequest = null; // number of pending user-supplied write callbacks
  // this must be 0 before 'finish' can be emitted

  this.pendingcb = 0; // emit prefinish if the only thing we're waiting for is _write cbs
  // This is relevant for synchronous Transform streams

  this.prefinished = false; // True if the error was already emitted and should not be thrown again

  this.errorEmitted = false; // Should close be emitted on destroy. Defaults to true.

  this.emitClose = options.emitClose !== false; // Should .destroy() be called after 'finish' (and potentially 'end')

  this.autoDestroy = !!options.autoDestroy; // count buffered requests

  this.bufferedRequestCount = 0; // allocate the first CorkedRequest, there is always
  // one allocated and free to use, and we maintain at most two

  this.corkedRequestsFree = new CorkedRequest(this);
}

WritableState.prototype.getBuffer = function getBuffer() {
  var current = this.bufferedRequest;
  var out = [];

  while (current) {
    out.push(current);
    current = current.next;
  }

  return out;
};

(function () {
  try {
    Object.defineProperty(WritableState.prototype, 'buffer', {
      get: internalUtil.deprecate(function writableStateBufferGetter() {
        return this.getBuffer();
      }, '_writableState.buffer is deprecated. Use _writableState.getBuffer ' + 'instead.', 'DEP0003')
    });
  } catch (_) {}
})(); // Test _writableState for inheritance to account for Duplex streams,
// whose prototype chain only points to Readable.


var realHasInstance;

if (typeof Symbol === 'function' && Symbol.hasInstance && typeof Function.prototype[Symbol.hasInstance] === 'function') {
  realHasInstance = Function.prototype[Symbol.hasInstance];
  Object.defineProperty(Writable, Symbol.hasInstance, {
    value: function value(object) {
      if (realHasInstance.call(this, object)) return true;
      if (this !== Writable) return false;
      return object && object._writableState instanceof WritableState;
    }
  });
} else {
  realHasInstance = function realHasInstance(object) {
    return object instanceof this;
  };
}

function Writable(options) {
  Duplex = Duplex || __webpack_require__(6753); // Writable ctor is applied to Duplexes, too.
  // `realHasInstance` is necessary because using plain `instanceof`
  // would return false, as no `_writableState` property is attached.
  // Trying to use the custom `instanceof` for Writable here will also break the
  // Node.js LazyTransform implementation, which has a non-trivial getter for
  // `_writableState` that would lead to infinite recursion.
  // Checking for a Stream.Duplex instance is faster here instead of inside
  // the WritableState constructor, at least with V8 6.5

  var isDuplex = this instanceof Duplex;
  if (!isDuplex && !realHasInstance.call(Writable, this)) return new Writable(options);
  this._writableState = new WritableState(options, this, isDuplex); // legacy.

  this.writable = true;

  if (options) {
    if (typeof options.write === 'function') this._write = options.write;
    if (typeof options.writev === 'function') this._writev = options.writev;
    if (typeof options.destroy === 'function') this._destroy = options.destroy;
    if (typeof options.final === 'function') this._final = options.final;
  }

  Stream.call(this);
} // Otherwise people can pipe Writable streams, which is just wrong.


Writable.prototype.pipe = function () {
  errorOrDestroy(this, new ERR_STREAM_CANNOT_PIPE());
};

function writeAfterEnd(stream, cb) {
  var er = new ERR_STREAM_WRITE_AFTER_END(); // TODO: defer error events consistently everywhere, not just the cb

  errorOrDestroy(stream, er);
  process.nextTick(cb, er);
} // Checks that a user-supplied chunk is valid, especially for the particular
// mode the stream is in. Currently this means that `null` is never accepted
// and undefined/non-string values are only allowed in object mode.


function validChunk(stream, state, chunk, cb) {
  var er;

  if (chunk === null) {
    er = new ERR_STREAM_NULL_VALUES();
  } else if (typeof chunk !== 'string' && !state.objectMode) {
    er = new ERR_INVALID_ARG_TYPE('chunk', ['string', 'Buffer'], chunk);
  }

  if (er) {
    errorOrDestroy(stream, er);
    process.nextTick(cb, er);
    return false;
  }

  return true;
}

Writable.prototype.write = function (chunk, encoding, cb) {
  var state = this._writableState;
  var ret = false;

  var isBuf = !state.objectMode && _isUint8Array(chunk);

  if (isBuf && !Buffer.isBuffer(chunk)) {
    chunk = _uint8ArrayToBuffer(chunk);
  }

  if (typeof encoding === 'function') {
    cb = encoding;
    encoding = null;
  }

  if (isBuf) encoding = 'buffer';else if (!encoding) encoding = state.defaultEncoding;
  if (typeof cb !== 'function') cb = nop;
  if (state.ending) writeAfterEnd(this, cb);else if (isBuf || validChunk(this, state, chunk, cb)) {
    state.pendingcb++;
    ret = writeOrBuffer(this, state, isBuf, chunk, encoding, cb);
  }
  return ret;
};

Writable.prototype.cork = function () {
  this._writableState.corked++;
};

Writable.prototype.uncork = function () {
  var state = this._writableState;

  if (state.corked) {
    state.corked--;
    if (!state.writing && !state.corked && !state.bufferProcessing && state.bufferedRequest) clearBuffer(this, state);
  }
};

Writable.prototype.setDefaultEncoding = function setDefaultEncoding(encoding) {
  // node::ParseEncoding() requires lower case.
  if (typeof encoding === 'string') encoding = encoding.toLowerCase();
  if (!(['hex', 'utf8', 'utf-8', 'ascii', 'binary', 'base64', 'ucs2', 'ucs-2', 'utf16le', 'utf-16le', 'raw'].indexOf((encoding + '').toLowerCase()) > -1)) throw new ERR_UNKNOWN_ENCODING(encoding);
  this._writableState.defaultEncoding = encoding;
  return this;
};

Object.defineProperty(Writable.prototype, 'writableBuffer', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._writableState && this._writableState.getBuffer();
  }
});

function decodeChunk(state, chunk, encoding) {
  if (!state.objectMode && state.decodeStrings !== false && typeof chunk === 'string') {
    chunk = Buffer.from(chunk, encoding);
  }

  return chunk;
}

Object.defineProperty(Writable.prototype, 'writableHighWaterMark', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._writableState.highWaterMark;
  }
}); // if we're already writing something, then just put this
// in the queue, and wait our turn.  Otherwise, call _write
// If we return false, then we need a drain event, so set that flag.

function writeOrBuffer(stream, state, isBuf, chunk, encoding, cb) {
  if (!isBuf) {
    var newChunk = decodeChunk(state, chunk, encoding);

    if (chunk !== newChunk) {
      isBuf = true;
      encoding = 'buffer';
      chunk = newChunk;
    }
  }

  var len = state.objectMode ? 1 : chunk.length;
  state.length += len;
  var ret = state.length < state.highWaterMark; // we must ensure that previous needDrain will not be reset to false.

  if (!ret) state.needDrain = true;

  if (state.writing || state.corked) {
    var last = state.lastBufferedRequest;
    state.lastBufferedRequest = {
      chunk: chunk,
      encoding: encoding,
      isBuf: isBuf,
      callback: cb,
      next: null
    };

    if (last) {
      last.next = state.lastBufferedRequest;
    } else {
      state.bufferedRequest = state.lastBufferedRequest;
    }

    state.bufferedRequestCount += 1;
  } else {
    doWrite(stream, state, false, len, chunk, encoding, cb);
  }

  return ret;
}

function doWrite(stream, state, writev, len, chunk, encoding, cb) {
  state.writelen = len;
  state.writecb = cb;
  state.writing = true;
  state.sync = true;
  if (state.destroyed) state.onwrite(new ERR_STREAM_DESTROYED('write'));else if (writev) stream._writev(chunk, state.onwrite);else stream._write(chunk, encoding, state.onwrite);
  state.sync = false;
}

function onwriteError(stream, state, sync, er, cb) {
  --state.pendingcb;

  if (sync) {
    // defer the callback if we are being called synchronously
    // to avoid piling up things on the stack
    process.nextTick(cb, er); // this can emit finish, and it will always happen
    // after error

    process.nextTick(finishMaybe, stream, state);
    stream._writableState.errorEmitted = true;
    errorOrDestroy(stream, er);
  } else {
    // the caller expect this to happen before if
    // it is async
    cb(er);
    stream._writableState.errorEmitted = true;
    errorOrDestroy(stream, er); // this can emit finish, but finish must
    // always follow error

    finishMaybe(stream, state);
  }
}

function onwriteStateUpdate(state) {
  state.writing = false;
  state.writecb = null;
  state.length -= state.writelen;
  state.writelen = 0;
}

function onwrite(stream, er) {
  var state = stream._writableState;
  var sync = state.sync;
  var cb = state.writecb;
  if (typeof cb !== 'function') throw new ERR_MULTIPLE_CALLBACK();
  onwriteStateUpdate(state);
  if (er) onwriteError(stream, state, sync, er, cb);else {
    // Check if we're actually ready to finish, but don't emit yet
    var finished = needFinish(state) || stream.destroyed;

    if (!finished && !state.corked && !state.bufferProcessing && state.bufferedRequest) {
      clearBuffer(stream, state);
    }

    if (sync) {
      process.nextTick(afterWrite, stream, state, finished, cb);
    } else {
      afterWrite(stream, state, finished, cb);
    }
  }
}

function afterWrite(stream, state, finished, cb) {
  if (!finished) onwriteDrain(stream, state);
  state.pendingcb--;
  cb();
  finishMaybe(stream, state);
} // Must force callback to be called on nextTick, so that we don't
// emit 'drain' before the write() consumer gets the 'false' return
// value, and has a chance to attach a 'drain' listener.


function onwriteDrain(stream, state) {
  if (state.length === 0 && state.needDrain) {
    state.needDrain = false;
    stream.emit('drain');
  }
} // if there's something in the buffer waiting, then process it


function clearBuffer(stream, state) {
  state.bufferProcessing = true;
  var entry = state.bufferedRequest;

  if (stream._writev && entry && entry.next) {
    // Fast case, write everything using _writev()
    var l = state.bufferedRequestCount;
    var buffer = new Array(l);
    var holder = state.corkedRequestsFree;
    holder.entry = entry;
    var count = 0;
    var allBuffers = true;

    while (entry) {
      buffer[count] = entry;
      if (!entry.isBuf) allBuffers = false;
      entry = entry.next;
      count += 1;
    }

    buffer.allBuffers = allBuffers;
    doWrite(stream, state, true, state.length, buffer, '', holder.finish); // doWrite is almost always async, defer these to save a bit of time
    // as the hot path ends with doWrite

    state.pendingcb++;
    state.lastBufferedRequest = null;

    if (holder.next) {
      state.corkedRequestsFree = holder.next;
      holder.next = null;
    } else {
      state.corkedRequestsFree = new CorkedRequest(state);
    }

    state.bufferedRequestCount = 0;
  } else {
    // Slow case, write chunks one-by-one
    while (entry) {
      var chunk = entry.chunk;
      var encoding = entry.encoding;
      var cb = entry.callback;
      var len = state.objectMode ? 1 : chunk.length;
      doWrite(stream, state, false, len, chunk, encoding, cb);
      entry = entry.next;
      state.bufferedRequestCount--; // if we didn't call the onwrite immediately, then
      // it means that we need to wait until it does.
      // also, that means that the chunk and cb are currently
      // being processed, so move the buffer counter past them.

      if (state.writing) {
        break;
      }
    }

    if (entry === null) state.lastBufferedRequest = null;
  }

  state.bufferedRequest = entry;
  state.bufferProcessing = false;
}

Writable.prototype._write = function (chunk, encoding, cb) {
  cb(new ERR_METHOD_NOT_IMPLEMENTED('_write()'));
};

Writable.prototype._writev = null;

Writable.prototype.end = function (chunk, encoding, cb) {
  var state = this._writableState;

  if (typeof chunk === 'function') {
    cb = chunk;
    chunk = null;
    encoding = null;
  } else if (typeof encoding === 'function') {
    cb = encoding;
    encoding = null;
  }

  if (chunk !== null && chunk !== undefined) this.write(chunk, encoding); // .end() fully uncorks

  if (state.corked) {
    state.corked = 1;
    this.uncork();
  } // ignore unnecessary end() calls.


  if (!state.ending) endWritable(this, state, cb);
  return this;
};

Object.defineProperty(Writable.prototype, 'writableLength', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._writableState.length;
  }
});

function needFinish(state) {
  return state.ending && state.length === 0 && state.bufferedRequest === null && !state.finished && !state.writing;
}

function callFinal(stream, state) {
  stream._final(function (err) {
    state.pendingcb--;

    if (err) {
      errorOrDestroy(stream, err);
    }

    state.prefinished = true;
    stream.emit('prefinish');
    finishMaybe(stream, state);
  });
}

function prefinish(stream, state) {
  if (!state.prefinished && !state.finalCalled) {
    if (typeof stream._final === 'function' && !state.destroyed) {
      state.pendingcb++;
      state.finalCalled = true;
      process.nextTick(callFinal, stream, state);
    } else {
      state.prefinished = true;
      stream.emit('prefinish');
    }
  }
}

function finishMaybe(stream, state) {
  var need = needFinish(state);

  if (need) {
    prefinish(stream, state);

    if (state.pendingcb === 0) {
      state.finished = true;
      stream.emit('finish');

      if (state.autoDestroy) {
        // In case of duplex streams we need a way to detect
        // if the readable side is ready for autoDestroy as well
        var rState = stream._readableState;

        if (!rState || rState.autoDestroy && rState.endEmitted) {
          stream.destroy();
        }
      }
    }
  }

  return need;
}

function endWritable(stream, state, cb) {
  state.ending = true;
  finishMaybe(stream, state);

  if (cb) {
    if (state.finished) process.nextTick(cb);else stream.once('finish', cb);
  }

  state.ended = true;
  stream.writable = false;
}

function onCorkedFinish(corkReq, state, err) {
  var entry = corkReq.entry;
  corkReq.entry = null;

  while (entry) {
    var cb = entry.callback;
    state.pendingcb--;
    cb(err);
    entry = entry.next;
  } // reuse the free corkReq.


  state.corkedRequestsFree.next = corkReq;
}

Object.defineProperty(Writable.prototype, 'destroyed', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    if (this._writableState === undefined) {
      return false;
    }

    return this._writableState.destroyed;
  },
  set: function set(value) {
    // we ignore the value if the stream
    // has not been initialized yet
    if (!this._writableState) {
      return;
    } // backward compatibility, the user is explicitly
    // managing destroyed


    this._writableState.destroyed = value;
  }
});
Writable.prototype.destroy = destroyImpl.destroy;
Writable.prototype._undestroy = destroyImpl.undestroy;

Writable.prototype._destroy = function (err, cb) {
  cb(err);
};

/***/ }),

/***/ 5850:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var _Object$setPrototypeO;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var finished = __webpack_require__(8610);

var kLastResolve = Symbol('lastResolve');
var kLastReject = Symbol('lastReject');
var kError = Symbol('error');
var kEnded = Symbol('ended');
var kLastPromise = Symbol('lastPromise');
var kHandlePromise = Symbol('handlePromise');
var kStream = Symbol('stream');

function createIterResult(value, done) {
  return {
    value: value,
    done: done
  };
}

function readAndResolve(iter) {
  var resolve = iter[kLastResolve];

  if (resolve !== null) {
    var data = iter[kStream].read(); // we defer if data is null
    // we can be expecting either 'end' or
    // 'error'

    if (data !== null) {
      iter[kLastPromise] = null;
      iter[kLastResolve] = null;
      iter[kLastReject] = null;
      resolve(createIterResult(data, false));
    }
  }
}

function onReadable(iter) {
  // we wait for the next tick, because it might
  // emit an error with process.nextTick
  process.nextTick(readAndResolve, iter);
}

function wrapForNext(lastPromise, iter) {
  return function (resolve, reject) {
    lastPromise.then(function () {
      if (iter[kEnded]) {
        resolve(createIterResult(undefined, true));
        return;
      }

      iter[kHandlePromise](resolve, reject);
    }, reject);
  };
}

var AsyncIteratorPrototype = Object.getPrototypeOf(function () {});
var ReadableStreamAsyncIteratorPrototype = Object.setPrototypeOf((_Object$setPrototypeO = {
  get stream() {
    return this[kStream];
  },

  next: function next() {
    var _this = this;

    // if we have detected an error in the meanwhile
    // reject straight away
    var error = this[kError];

    if (error !== null) {
      return Promise.reject(error);
    }

    if (this[kEnded]) {
      return Promise.resolve(createIterResult(undefined, true));
    }

    if (this[kStream].destroyed) {
      // We need to defer via nextTick because if .destroy(err) is
      // called, the error will be emitted via nextTick, and
      // we cannot guarantee that there is no error lingering around
      // waiting to be emitted.
      return new Promise(function (resolve, reject) {
        process.nextTick(function () {
          if (_this[kError]) {
            reject(_this[kError]);
          } else {
            resolve(createIterResult(undefined, true));
          }
        });
      });
    } // if we have multiple next() calls
    // we will wait for the previous Promise to finish
    // this logic is optimized to support for await loops,
    // where next() is only called once at a time


    var lastPromise = this[kLastPromise];
    var promise;

    if (lastPromise) {
      promise = new Promise(wrapForNext(lastPromise, this));
    } else {
      // fast path needed to support multiple this.push()
      // without triggering the next() queue
      var data = this[kStream].read();

      if (data !== null) {
        return Promise.resolve(createIterResult(data, false));
      }

      promise = new Promise(this[kHandlePromise]);
    }

    this[kLastPromise] = promise;
    return promise;
  }
}, _defineProperty(_Object$setPrototypeO, Symbol.asyncIterator, function () {
  return this;
}), _defineProperty(_Object$setPrototypeO, "return", function _return() {
  var _this2 = this;

  // destroy(err, cb) is a private API
  // we can guarantee we have that here, because we control the
  // Readable class this is attached to
  return new Promise(function (resolve, reject) {
    _this2[kStream].destroy(null, function (err) {
      if (err) {
        reject(err);
        return;
      }

      resolve(createIterResult(undefined, true));
    });
  });
}), _Object$setPrototypeO), AsyncIteratorPrototype);

var createReadableStreamAsyncIterator = function createReadableStreamAsyncIterator(stream) {
  var _Object$create;

  var iterator = Object.create(ReadableStreamAsyncIteratorPrototype, (_Object$create = {}, _defineProperty(_Object$create, kStream, {
    value: stream,
    writable: true
  }), _defineProperty(_Object$create, kLastResolve, {
    value: null,
    writable: true
  }), _defineProperty(_Object$create, kLastReject, {
    value: null,
    writable: true
  }), _defineProperty(_Object$create, kError, {
    value: null,
    writable: true
  }), _defineProperty(_Object$create, kEnded, {
    value: stream._readableState.endEmitted,
    writable: true
  }), _defineProperty(_Object$create, kHandlePromise, {
    value: function value(resolve, reject) {
      var data = iterator[kStream].read();

      if (data) {
        iterator[kLastPromise] = null;
        iterator[kLastResolve] = null;
        iterator[kLastReject] = null;
        resolve(createIterResult(data, false));
      } else {
        iterator[kLastResolve] = resolve;
        iterator[kLastReject] = reject;
      }
    },
    writable: true
  }), _Object$create));
  iterator[kLastPromise] = null;
  finished(stream, function (err) {
    if (err && err.code !== 'ERR_STREAM_PREMATURE_CLOSE') {
      var reject = iterator[kLastReject]; // reject if we are waiting for data in the Promise
      // returned by next() and store the error

      if (reject !== null) {
        iterator[kLastPromise] = null;
        iterator[kLastResolve] = null;
        iterator[kLastReject] = null;
        reject(err);
      }

      iterator[kError] = err;
      return;
    }

    var resolve = iterator[kLastResolve];

    if (resolve !== null) {
      iterator[kLastPromise] = null;
      iterator[kLastResolve] = null;
      iterator[kLastReject] = null;
      resolve(createIterResult(undefined, true));
    }

    iterator[kEnded] = true;
  });
  stream.on('readable', onReadable.bind(null, iterator));
  return iterator;
};

module.exports = createReadableStreamAsyncIterator;

/***/ }),

/***/ 7327:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var _require = __webpack_require__(4293),
    Buffer = _require.Buffer;

var _require2 = __webpack_require__(1669),
    inspect = _require2.inspect;

var custom = inspect && inspect.custom || 'inspect';

function copyBuffer(src, target, offset) {
  Buffer.prototype.copy.call(src, target, offset);
}

module.exports =
/*#__PURE__*/
function () {
  function BufferList() {
    _classCallCheck(this, BufferList);

    this.head = null;
    this.tail = null;
    this.length = 0;
  }

  _createClass(BufferList, [{
    key: "push",
    value: function push(v) {
      var entry = {
        data: v,
        next: null
      };
      if (this.length > 0) this.tail.next = entry;else this.head = entry;
      this.tail = entry;
      ++this.length;
    }
  }, {
    key: "unshift",
    value: function unshift(v) {
      var entry = {
        data: v,
        next: this.head
      };
      if (this.length === 0) this.tail = entry;
      this.head = entry;
      ++this.length;
    }
  }, {
    key: "shift",
    value: function shift() {
      if (this.length === 0) return;
      var ret = this.head.data;
      if (this.length === 1) this.head = this.tail = null;else this.head = this.head.next;
      --this.length;
      return ret;
    }
  }, {
    key: "clear",
    value: function clear() {
      this.head = this.tail = null;
      this.length = 0;
    }
  }, {
    key: "join",
    value: function join(s) {
      if (this.length === 0) return '';
      var p = this.head;
      var ret = '' + p.data;

      while (p = p.next) {
        ret += s + p.data;
      }

      return ret;
    }
  }, {
    key: "concat",
    value: function concat(n) {
      if (this.length === 0) return Buffer.alloc(0);
      var ret = Buffer.allocUnsafe(n >>> 0);
      var p = this.head;
      var i = 0;

      while (p) {
        copyBuffer(p.data, ret, i);
        i += p.data.length;
        p = p.next;
      }

      return ret;
    } // Consumes a specified amount of bytes or characters from the buffered data.

  }, {
    key: "consume",
    value: function consume(n, hasStrings) {
      var ret;

      if (n < this.head.data.length) {
        // `slice` is the same for buffers and strings.
        ret = this.head.data.slice(0, n);
        this.head.data = this.head.data.slice(n);
      } else if (n === this.head.data.length) {
        // First chunk is a perfect match.
        ret = this.shift();
      } else {
        // Result spans more than one buffer.
        ret = hasStrings ? this._getString(n) : this._getBuffer(n);
      }

      return ret;
    }
  }, {
    key: "first",
    value: function first() {
      return this.head.data;
    } // Consumes a specified amount of characters from the buffered data.

  }, {
    key: "_getString",
    value: function _getString(n) {
      var p = this.head;
      var c = 1;
      var ret = p.data;
      n -= ret.length;

      while (p = p.next) {
        var str = p.data;
        var nb = n > str.length ? str.length : n;
        if (nb === str.length) ret += str;else ret += str.slice(0, n);
        n -= nb;

        if (n === 0) {
          if (nb === str.length) {
            ++c;
            if (p.next) this.head = p.next;else this.head = this.tail = null;
          } else {
            this.head = p;
            p.data = str.slice(nb);
          }

          break;
        }

        ++c;
      }

      this.length -= c;
      return ret;
    } // Consumes a specified amount of bytes from the buffered data.

  }, {
    key: "_getBuffer",
    value: function _getBuffer(n) {
      var ret = Buffer.allocUnsafe(n);
      var p = this.head;
      var c = 1;
      p.data.copy(ret);
      n -= p.data.length;

      while (p = p.next) {
        var buf = p.data;
        var nb = n > buf.length ? buf.length : n;
        buf.copy(ret, ret.length - n, 0, nb);
        n -= nb;

        if (n === 0) {
          if (nb === buf.length) {
            ++c;
            if (p.next) this.head = p.next;else this.head = this.tail = null;
          } else {
            this.head = p;
            p.data = buf.slice(nb);
          }

          break;
        }

        ++c;
      }

      this.length -= c;
      return ret;
    } // Make sure the linked list only shows the minimal necessary information.

  }, {
    key: custom,
    value: function value(_, options) {
      return inspect(this, _objectSpread({}, options, {
        // Only inspect one level.
        depth: 0,
        // It should not recurse.
        customInspect: false
      }));
    }
  }]);

  return BufferList;
}();

/***/ }),

/***/ 1195:
/***/ ((module) => {

"use strict";
 // undocumented cb() API, needed for core, not for public API

function destroy(err, cb) {
  var _this = this;

  var readableDestroyed = this._readableState && this._readableState.destroyed;
  var writableDestroyed = this._writableState && this._writableState.destroyed;

  if (readableDestroyed || writableDestroyed) {
    if (cb) {
      cb(err);
    } else if (err) {
      if (!this._writableState) {
        process.nextTick(emitErrorNT, this, err);
      } else if (!this._writableState.errorEmitted) {
        this._writableState.errorEmitted = true;
        process.nextTick(emitErrorNT, this, err);
      }
    }

    return this;
  } // we set destroyed to true before firing error callbacks in order
  // to make it re-entrance safe in case destroy() is called within callbacks


  if (this._readableState) {
    this._readableState.destroyed = true;
  } // if this is a duplex stream mark the writable part as destroyed as well


  if (this._writableState) {
    this._writableState.destroyed = true;
  }

  this._destroy(err || null, function (err) {
    if (!cb && err) {
      if (!_this._writableState) {
        process.nextTick(emitErrorAndCloseNT, _this, err);
      } else if (!_this._writableState.errorEmitted) {
        _this._writableState.errorEmitted = true;
        process.nextTick(emitErrorAndCloseNT, _this, err);
      } else {
        process.nextTick(emitCloseNT, _this);
      }
    } else if (cb) {
      process.nextTick(emitCloseNT, _this);
      cb(err);
    } else {
      process.nextTick(emitCloseNT, _this);
    }
  });

  return this;
}

function emitErrorAndCloseNT(self, err) {
  emitErrorNT(self, err);
  emitCloseNT(self);
}

function emitCloseNT(self) {
  if (self._writableState && !self._writableState.emitClose) return;
  if (self._readableState && !self._readableState.emitClose) return;
  self.emit('close');
}

function undestroy() {
  if (this._readableState) {
    this._readableState.destroyed = false;
    this._readableState.reading = false;
    this._readableState.ended = false;
    this._readableState.endEmitted = false;
  }

  if (this._writableState) {
    this._writableState.destroyed = false;
    this._writableState.ended = false;
    this._writableState.ending = false;
    this._writableState.finalCalled = false;
    this._writableState.prefinished = false;
    this._writableState.finished = false;
    this._writableState.errorEmitted = false;
  }
}

function emitErrorNT(self, err) {
  self.emit('error', err);
}

function errorOrDestroy(stream, err) {
  // We have tests that rely on errors being emitted
  // in the same tick, so changing this is semver major.
  // For now when you opt-in to autoDestroy we allow
  // the error to be emitted nextTick. In a future
  // semver major update we should change the default to this.
  var rState = stream._readableState;
  var wState = stream._writableState;
  if (rState && rState.autoDestroy || wState && wState.autoDestroy) stream.destroy(err);else stream.emit('error', err);
}

module.exports = {
  destroy: destroy,
  undestroy: undestroy,
  errorOrDestroy: errorOrDestroy
};

/***/ }),

/***/ 8610:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Ported from https://github.com/mafintosh/end-of-stream with
// permission from the author, Mathias Buus (@mafintosh).


var ERR_STREAM_PREMATURE_CLOSE = __webpack_require__(4012)/* .codes.ERR_STREAM_PREMATURE_CLOSE */ .q.ERR_STREAM_PREMATURE_CLOSE;

function once(callback) {
  var called = false;
  return function () {
    if (called) return;
    called = true;

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    callback.apply(this, args);
  };
}

function noop() {}

function isRequest(stream) {
  return stream.setHeader && typeof stream.abort === 'function';
}

function eos(stream, opts, callback) {
  if (typeof opts === 'function') return eos(stream, null, opts);
  if (!opts) opts = {};
  callback = once(callback || noop);
  var readable = opts.readable || opts.readable !== false && stream.readable;
  var writable = opts.writable || opts.writable !== false && stream.writable;

  var onlegacyfinish = function onlegacyfinish() {
    if (!stream.writable) onfinish();
  };

  var writableEnded = stream._writableState && stream._writableState.finished;

  var onfinish = function onfinish() {
    writable = false;
    writableEnded = true;
    if (!readable) callback.call(stream);
  };

  var readableEnded = stream._readableState && stream._readableState.endEmitted;

  var onend = function onend() {
    readable = false;
    readableEnded = true;
    if (!writable) callback.call(stream);
  };

  var onerror = function onerror(err) {
    callback.call(stream, err);
  };

  var onclose = function onclose() {
    var err;

    if (readable && !readableEnded) {
      if (!stream._readableState || !stream._readableState.ended) err = new ERR_STREAM_PREMATURE_CLOSE();
      return callback.call(stream, err);
    }

    if (writable && !writableEnded) {
      if (!stream._writableState || !stream._writableState.ended) err = new ERR_STREAM_PREMATURE_CLOSE();
      return callback.call(stream, err);
    }
  };

  var onrequest = function onrequest() {
    stream.req.on('finish', onfinish);
  };

  if (isRequest(stream)) {
    stream.on('complete', onfinish);
    stream.on('abort', onclose);
    if (stream.req) onrequest();else stream.on('request', onrequest);
  } else if (writable && !stream._writableState) {
    // legacy streams
    stream.on('end', onlegacyfinish);
    stream.on('close', onlegacyfinish);
  }

  stream.on('end', onend);
  stream.on('finish', onfinish);
  if (opts.error !== false) stream.on('error', onerror);
  stream.on('close', onclose);
  return function () {
    stream.removeListener('complete', onfinish);
    stream.removeListener('abort', onclose);
    stream.removeListener('request', onrequest);
    if (stream.req) stream.req.removeListener('finish', onfinish);
    stream.removeListener('end', onlegacyfinish);
    stream.removeListener('close', onlegacyfinish);
    stream.removeListener('finish', onfinish);
    stream.removeListener('end', onend);
    stream.removeListener('error', onerror);
    stream.removeListener('close', onclose);
  };
}

module.exports = eos;

/***/ }),

/***/ 6307:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var ERR_INVALID_ARG_TYPE = __webpack_require__(4012)/* .codes.ERR_INVALID_ARG_TYPE */ .q.ERR_INVALID_ARG_TYPE;

function from(Readable, iterable, opts) {
  var iterator;

  if (iterable && typeof iterable.next === 'function') {
    iterator = iterable;
  } else if (iterable && iterable[Symbol.asyncIterator]) iterator = iterable[Symbol.asyncIterator]();else if (iterable && iterable[Symbol.iterator]) iterator = iterable[Symbol.iterator]();else throw new ERR_INVALID_ARG_TYPE('iterable', ['Iterable'], iterable);

  var readable = new Readable(_objectSpread({
    objectMode: true
  }, opts)); // Reading boolean to protect against _read
  // being called before last iteration completion.

  var reading = false;

  readable._read = function () {
    if (!reading) {
      reading = true;
      next();
    }
  };

  function next() {
    return _next2.apply(this, arguments);
  }

  function _next2() {
    _next2 = _asyncToGenerator(function* () {
      try {
        var _ref = yield iterator.next(),
            value = _ref.value,
            done = _ref.done;

        if (done) {
          readable.push(null);
        } else if (readable.push((yield value))) {
          next();
        } else {
          reading = false;
        }
      } catch (err) {
        readable.destroy(err);
      }
    });
    return _next2.apply(this, arguments);
  }

  return readable;
}

module.exports = from;

/***/ }),

/***/ 9946:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Ported from https://github.com/mafintosh/pump with
// permission from the author, Mathias Buus (@mafintosh).


var eos;

function once(callback) {
  var called = false;
  return function () {
    if (called) return;
    called = true;
    callback.apply(void 0, arguments);
  };
}

var _require$codes = __webpack_require__(4012)/* .codes */ .q,
    ERR_MISSING_ARGS = _require$codes.ERR_MISSING_ARGS,
    ERR_STREAM_DESTROYED = _require$codes.ERR_STREAM_DESTROYED;

function noop(err) {
  // Rethrow the error if it exists to avoid swallowing it
  if (err) throw err;
}

function isRequest(stream) {
  return stream.setHeader && typeof stream.abort === 'function';
}

function destroyer(stream, reading, writing, callback) {
  callback = once(callback);
  var closed = false;
  stream.on('close', function () {
    closed = true;
  });
  if (eos === undefined) eos = __webpack_require__(8610);
  eos(stream, {
    readable: reading,
    writable: writing
  }, function (err) {
    if (err) return callback(err);
    closed = true;
    callback();
  });
  var destroyed = false;
  return function (err) {
    if (closed) return;
    if (destroyed) return;
    destroyed = true; // request.destroy just do .end - .abort is what we want

    if (isRequest(stream)) return stream.abort();
    if (typeof stream.destroy === 'function') return stream.destroy();
    callback(err || new ERR_STREAM_DESTROYED('pipe'));
  };
}

function call(fn) {
  fn();
}

function pipe(from, to) {
  return from.pipe(to);
}

function popCallback(streams) {
  if (!streams.length) return noop;
  if (typeof streams[streams.length - 1] !== 'function') return noop;
  return streams.pop();
}

function pipeline() {
  for (var _len = arguments.length, streams = new Array(_len), _key = 0; _key < _len; _key++) {
    streams[_key] = arguments[_key];
  }

  var callback = popCallback(streams);
  if (Array.isArray(streams[0])) streams = streams[0];

  if (streams.length < 2) {
    throw new ERR_MISSING_ARGS('streams');
  }

  var error;
  var destroys = streams.map(function (stream, i) {
    var reading = i < streams.length - 1;
    var writing = i > 0;
    return destroyer(stream, reading, writing, function (err) {
      if (!error) error = err;
      if (err) destroys.forEach(call);
      if (reading) return;
      destroys.forEach(call);
      callback(error);
    });
  });
  return streams.reduce(pipe);
}

module.exports = pipeline;

/***/ }),

/***/ 2457:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var ERR_INVALID_OPT_VALUE = __webpack_require__(4012)/* .codes.ERR_INVALID_OPT_VALUE */ .q.ERR_INVALID_OPT_VALUE;

function highWaterMarkFrom(options, isDuplex, duplexKey) {
  return options.highWaterMark != null ? options.highWaterMark : isDuplex ? options[duplexKey] : null;
}

function getHighWaterMark(state, options, duplexKey, isDuplex) {
  var hwm = highWaterMarkFrom(options, isDuplex, duplexKey);

  if (hwm != null) {
    if (!(isFinite(hwm) && Math.floor(hwm) === hwm) || hwm < 0) {
      var name = isDuplex ? duplexKey : 'highWaterMark';
      throw new ERR_INVALID_OPT_VALUE(name, hwm);
    }

    return Math.floor(hwm);
  } // Default value


  return state.objectMode ? 16 : 16 * 1024;
}

module.exports = {
  getHighWaterMark: getHighWaterMark
};

/***/ }),

/***/ 9740:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(2413);


/***/ }),

/***/ 1451:
/***/ ((module, exports, __webpack_require__) => {

var Stream = __webpack_require__(2413);
if (process.env.READABLE_STREAM === 'disable' && Stream) {
  module.exports = Stream.Readable;
  Object.assign(module.exports, Stream);
  module.exports.Stream = Stream;
} else {
  exports = module.exports = __webpack_require__(9481);
  exports.Stream = Stream || exports;
  exports.Readable = exports;
  exports.Writable = __webpack_require__(4229);
  exports.Duplex = __webpack_require__(6753);
  exports.Transform = __webpack_require__(4605);
  exports.PassThrough = __webpack_require__(2725);
  exports.finished = __webpack_require__(8610);
  exports.pipeline = __webpack_require__(9946);
}


/***/ }),

/***/ 9509:
/***/ ((module, exports, __webpack_require__) => {

/*! safe-buffer. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
/* eslint-disable node/no-deprecated-api */
var buffer = __webpack_require__(4293)
var Buffer = buffer.Buffer

// alternative to using Object.keys for old browsers
function copyProps (src, dst) {
  for (var key in src) {
    dst[key] = src[key]
  }
}
if (Buffer.from && Buffer.alloc && Buffer.allocUnsafe && Buffer.allocUnsafeSlow) {
  module.exports = buffer
} else {
  // Copy properties from require('buffer')
  copyProps(buffer, exports)
  exports.Buffer = SafeBuffer
}

function SafeBuffer (arg, encodingOrOffset, length) {
  return Buffer(arg, encodingOrOffset, length)
}

SafeBuffer.prototype = Object.create(Buffer.prototype)

// Copy static methods from Buffer
copyProps(Buffer, SafeBuffer)

SafeBuffer.from = function (arg, encodingOrOffset, length) {
  if (typeof arg === 'number') {
    throw new TypeError('Argument must not be a number')
  }
  return Buffer(arg, encodingOrOffset, length)
}

SafeBuffer.alloc = function (size, fill, encoding) {
  if (typeof size !== 'number') {
    throw new TypeError('Argument must be a number')
  }
  var buf = Buffer(size)
  if (fill !== undefined) {
    if (typeof encoding === 'string') {
      buf.fill(fill, encoding)
    } else {
      buf.fill(fill)
    }
  } else {
    buf.fill(0)
  }
  return buf
}

SafeBuffer.allocUnsafe = function (size) {
  if (typeof size !== 'number') {
    throw new TypeError('Argument must be a number')
  }
  return Buffer(size)
}

SafeBuffer.allocUnsafeSlow = function (size) {
  if (typeof size !== 'number') {
    throw new TypeError('Argument must be a number')
  }
  return buffer.SlowBuffer(size)
}


/***/ }),

/***/ 861:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
/*
Copyright (c) 2014-2018, Matteo Collina <hello@matteocollina.com>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/



const { Transform } = __webpack_require__(1451)
const { StringDecoder } = __webpack_require__(4304)
const kLast = Symbol('last')
const kDecoder = Symbol('decoder')

function transform (chunk, enc, cb) {
  var list
  if (this.overflow) { // Line buffer is full. Skip to start of next line.
    var buf = this[kDecoder].write(chunk)
    list = buf.split(this.matcher)

    if (list.length === 1) return cb() // Line ending not found. Discard entire chunk.

    // Line ending found. Discard trailing fragment of previous line and reset overflow state.
    list.shift()
    this.overflow = false
  } else {
    this[kLast] += this[kDecoder].write(chunk)
    list = this[kLast].split(this.matcher)
  }

  this[kLast] = list.pop()

  for (var i = 0; i < list.length; i++) {
    try {
      push(this, this.mapper(list[i]))
    } catch (error) {
      return cb(error)
    }
  }

  this.overflow = this[kLast].length > this.maxLength
  if (this.overflow && !this.skipOverflow) return cb(new Error('maximum buffer reached'))

  cb()
}

function flush (cb) {
  // forward any gibberish left in there
  this[kLast] += this[kDecoder].end()

  if (this[kLast]) {
    try {
      push(this, this.mapper(this[kLast]))
    } catch (error) {
      return cb(error)
    }
  }

  cb()
}

function push (self, val) {
  if (val !== undefined) {
    self.push(val)
  }
}

function noop (incoming) {
  return incoming
}

function split (matcher, mapper, options) {
  // Set defaults for any arguments not supplied.
  matcher = matcher || /\r?\n/
  mapper = mapper || noop
  options = options || {}

  // Test arguments explicitly.
  switch (arguments.length) {
    case 1:
      // If mapper is only argument.
      if (typeof matcher === 'function') {
        mapper = matcher
        matcher = /\r?\n/
      // If options is only argument.
      } else if (typeof matcher === 'object' && !(matcher instanceof RegExp)) {
        options = matcher
        matcher = /\r?\n/
      }
      break

    case 2:
      // If mapper and options are arguments.
      if (typeof matcher === 'function') {
        options = mapper
        mapper = matcher
        matcher = /\r?\n/
      // If matcher and options are arguments.
      } else if (typeof mapper === 'object') {
        options = mapper
        mapper = noop
      }
  }

  options = Object.assign({}, options)
  options.transform = transform
  options.flush = flush
  options.readableObjectMode = true

  const stream = new Transform(options)

  stream[kLast] = ''
  stream[kDecoder] = new StringDecoder('utf8')
  stream.matcher = matcher
  stream.mapper = mapper
  stream.maxLength = options.maxLength
  stream.skipOverflow = options.skipOverflow
  stream.overflow = false

  return stream
}

module.exports = split


/***/ }),

/***/ 2553:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.



/*<replacement>*/

var Buffer = __webpack_require__(9509).Buffer;
/*</replacement>*/

var isEncoding = Buffer.isEncoding || function (encoding) {
  encoding = '' + encoding;
  switch (encoding && encoding.toLowerCase()) {
    case 'hex':case 'utf8':case 'utf-8':case 'ascii':case 'binary':case 'base64':case 'ucs2':case 'ucs-2':case 'utf16le':case 'utf-16le':case 'raw':
      return true;
    default:
      return false;
  }
};

function _normalizeEncoding(enc) {
  if (!enc) return 'utf8';
  var retried;
  while (true) {
    switch (enc) {
      case 'utf8':
      case 'utf-8':
        return 'utf8';
      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return 'utf16le';
      case 'latin1':
      case 'binary':
        return 'latin1';
      case 'base64':
      case 'ascii':
      case 'hex':
        return enc;
      default:
        if (retried) return; // undefined
        enc = ('' + enc).toLowerCase();
        retried = true;
    }
  }
};

// Do not cache `Buffer.isEncoding` when checking encoding names as some
// modules monkey-patch it to support additional encodings
function normalizeEncoding(enc) {
  var nenc = _normalizeEncoding(enc);
  if (typeof nenc !== 'string' && (Buffer.isEncoding === isEncoding || !isEncoding(enc))) throw new Error('Unknown encoding: ' + enc);
  return nenc || enc;
}

// StringDecoder provides an interface for efficiently splitting a series of
// buffers into a series of JS strings without breaking apart multi-byte
// characters.
exports.s = StringDecoder;
function StringDecoder(encoding) {
  this.encoding = normalizeEncoding(encoding);
  var nb;
  switch (this.encoding) {
    case 'utf16le':
      this.text = utf16Text;
      this.end = utf16End;
      nb = 4;
      break;
    case 'utf8':
      this.fillLast = utf8FillLast;
      nb = 4;
      break;
    case 'base64':
      this.text = base64Text;
      this.end = base64End;
      nb = 3;
      break;
    default:
      this.write = simpleWrite;
      this.end = simpleEnd;
      return;
  }
  this.lastNeed = 0;
  this.lastTotal = 0;
  this.lastChar = Buffer.allocUnsafe(nb);
}

StringDecoder.prototype.write = function (buf) {
  if (buf.length === 0) return '';
  var r;
  var i;
  if (this.lastNeed) {
    r = this.fillLast(buf);
    if (r === undefined) return '';
    i = this.lastNeed;
    this.lastNeed = 0;
  } else {
    i = 0;
  }
  if (i < buf.length) return r ? r + this.text(buf, i) : this.text(buf, i);
  return r || '';
};

StringDecoder.prototype.end = utf8End;

// Returns only complete characters in a Buffer
StringDecoder.prototype.text = utf8Text;

// Attempts to complete a partial non-UTF-8 character using bytes from a Buffer
StringDecoder.prototype.fillLast = function (buf) {
  if (this.lastNeed <= buf.length) {
    buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, this.lastNeed);
    return this.lastChar.toString(this.encoding, 0, this.lastTotal);
  }
  buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, buf.length);
  this.lastNeed -= buf.length;
};

// Checks the type of a UTF-8 byte, whether it's ASCII, a leading byte, or a
// continuation byte. If an invalid byte is detected, -2 is returned.
function utf8CheckByte(byte) {
  if (byte <= 0x7F) return 0;else if (byte >> 5 === 0x06) return 2;else if (byte >> 4 === 0x0E) return 3;else if (byte >> 3 === 0x1E) return 4;
  return byte >> 6 === 0x02 ? -1 : -2;
}

// Checks at most 3 bytes at the end of a Buffer in order to detect an
// incomplete multi-byte UTF-8 character. The total number of bytes (2, 3, or 4)
// needed to complete the UTF-8 character (if applicable) are returned.
function utf8CheckIncomplete(self, buf, i) {
  var j = buf.length - 1;
  if (j < i) return 0;
  var nb = utf8CheckByte(buf[j]);
  if (nb >= 0) {
    if (nb > 0) self.lastNeed = nb - 1;
    return nb;
  }
  if (--j < i || nb === -2) return 0;
  nb = utf8CheckByte(buf[j]);
  if (nb >= 0) {
    if (nb > 0) self.lastNeed = nb - 2;
    return nb;
  }
  if (--j < i || nb === -2) return 0;
  nb = utf8CheckByte(buf[j]);
  if (nb >= 0) {
    if (nb > 0) {
      if (nb === 2) nb = 0;else self.lastNeed = nb - 3;
    }
    return nb;
  }
  return 0;
}

// Validates as many continuation bytes for a multi-byte UTF-8 character as
// needed or are available. If we see a non-continuation byte where we expect
// one, we "replace" the validated continuation bytes we've seen so far with
// a single UTF-8 replacement character ('\ufffd'), to match v8's UTF-8 decoding
// behavior. The continuation byte check is included three times in the case
// where all of the continuation bytes for a character exist in the same buffer.
// It is also done this way as a slight performance increase instead of using a
// loop.
function utf8CheckExtraBytes(self, buf, p) {
  if ((buf[0] & 0xC0) !== 0x80) {
    self.lastNeed = 0;
    return '\ufffd';
  }
  if (self.lastNeed > 1 && buf.length > 1) {
    if ((buf[1] & 0xC0) !== 0x80) {
      self.lastNeed = 1;
      return '\ufffd';
    }
    if (self.lastNeed > 2 && buf.length > 2) {
      if ((buf[2] & 0xC0) !== 0x80) {
        self.lastNeed = 2;
        return '\ufffd';
      }
    }
  }
}

// Attempts to complete a multi-byte UTF-8 character using bytes from a Buffer.
function utf8FillLast(buf) {
  var p = this.lastTotal - this.lastNeed;
  var r = utf8CheckExtraBytes(this, buf, p);
  if (r !== undefined) return r;
  if (this.lastNeed <= buf.length) {
    buf.copy(this.lastChar, p, 0, this.lastNeed);
    return this.lastChar.toString(this.encoding, 0, this.lastTotal);
  }
  buf.copy(this.lastChar, p, 0, buf.length);
  this.lastNeed -= buf.length;
}

// Returns all complete UTF-8 characters in a Buffer. If the Buffer ended on a
// partial character, the character's bytes are buffered until the required
// number of bytes are available.
function utf8Text(buf, i) {
  var total = utf8CheckIncomplete(this, buf, i);
  if (!this.lastNeed) return buf.toString('utf8', i);
  this.lastTotal = total;
  var end = buf.length - (total - this.lastNeed);
  buf.copy(this.lastChar, 0, end);
  return buf.toString('utf8', i, end);
}

// For UTF-8, a replacement character is added when ending on a partial
// character.
function utf8End(buf) {
  var r = buf && buf.length ? this.write(buf) : '';
  if (this.lastNeed) return r + '\ufffd';
  return r;
}

// UTF-16LE typically needs two bytes per character, but even if we have an even
// number of bytes available, we need to check if we end on a leading/high
// surrogate. In that case, we need to wait for the next two bytes in order to
// decode the last character properly.
function utf16Text(buf, i) {
  if ((buf.length - i) % 2 === 0) {
    var r = buf.toString('utf16le', i);
    if (r) {
      var c = r.charCodeAt(r.length - 1);
      if (c >= 0xD800 && c <= 0xDBFF) {
        this.lastNeed = 2;
        this.lastTotal = 4;
        this.lastChar[0] = buf[buf.length - 2];
        this.lastChar[1] = buf[buf.length - 1];
        return r.slice(0, -1);
      }
    }
    return r;
  }
  this.lastNeed = 1;
  this.lastTotal = 2;
  this.lastChar[0] = buf[buf.length - 1];
  return buf.toString('utf16le', i, buf.length - 1);
}

// For UTF-16LE we do not explicitly append special replacement characters if we
// end on a partial character, we simply let v8 handle that.
function utf16End(buf) {
  var r = buf && buf.length ? this.write(buf) : '';
  if (this.lastNeed) {
    var end = this.lastTotal - this.lastNeed;
    return r + this.lastChar.toString('utf16le', 0, end);
  }
  return r;
}

function base64Text(buf, i) {
  var n = (buf.length - i) % 3;
  if (n === 0) return buf.toString('base64', i);
  this.lastNeed = 3 - n;
  this.lastTotal = 3;
  if (n === 1) {
    this.lastChar[0] = buf[buf.length - 1];
  } else {
    this.lastChar[0] = buf[buf.length - 2];
    this.lastChar[1] = buf[buf.length - 1];
  }
  return buf.toString('base64', i, buf.length - n);
}

function base64End(buf) {
  var r = buf && buf.length ? this.write(buf) : '';
  if (this.lastNeed) return r + this.lastChar.toString('base64', 0, 3 - this.lastNeed);
  return r;
}

// Pass bytes on through for single-byte encodings (e.g. ascii, latin1, hex)
function simpleWrite(buf) {
  return buf.toString(this.encoding);
}

function simpleEnd(buf) {
  return buf && buf.length ? this.write(buf) : '';
}

/***/ }),

/***/ 1159:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


/**
 * For Node.js, simply re-export the core `util.deprecate` function.
 */

module.exports = __webpack_require__(1669).deprecate;


/***/ }),

/***/ 9820:
/***/ ((module) => {

module.exports = extend

var hasOwnProperty = Object.prototype.hasOwnProperty;

function extend(target) {
    for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i]

        for (var key in source) {
            if (hasOwnProperty.call(source, key)) {
                target[key] = source[key]
            }
        }
    }

    return target
}


/***/ }),

/***/ 2357:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 4293:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6417:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 881:
/***/ ((module) => {

"use strict";
module.exports = require("dns");

/***/ }),

/***/ 8614:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 5747:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 1631:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 5622:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 2413:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 4304:
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ 4016:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 8835:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 1669:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 2466:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"name":"pg","version":"8.7.1","description":"PostgreSQL client - pure javascript & libpq with the same API","keywords":["database","libpq","pg","postgre","postgres","postgresql","rdbms"],"homepage":"https://github.com/brianc/node-postgres","repository":{"type":"git","url":"git://github.com/brianc/node-postgres.git","directory":"packages/pg"},"author":"Brian Carlson <brian.m.carlson@gmail.com>","main":"./lib","dependencies":{"buffer-writer":"2.0.0","packet-reader":"1.0.0","pg-connection-string":"^2.5.0","pg-pool":"^3.4.1","pg-protocol":"^1.5.0","pg-types":"^2.1.0","pgpass":"1.x"},"devDependencies":{"async":"0.9.0","bluebird":"3.5.2","co":"4.6.0","pg-copy-streams":"0.3.0"},"peerDependencies":{"pg-native":">=2.0.0"},"peerDependenciesMeta":{"pg-native":{"optional":true}},"scripts":{"test":"make test-all"},"files":["lib","SPONSORS.md"],"license":"MIT","engines":{"node":">= 8.0.0"},"gitHead":"92b4d37926c276d343bfe56447ff6f526af757cf"}');

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module doesn't tell about it's top-level declarations so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(5035);
/******/ 	var __webpack_export_target__ = exports;
/******/ 	for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
/******/ 	if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGFtYmRhcy9nZXRQcm9kdWN0c0J5SWQuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDekNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7O0FDdERBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUNSQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQzFCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDekdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUNuR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ3BhQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ2pEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDaEZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUNkQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUMvSkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUNuVEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7O0FDNUxBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDOUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDVkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUNoUUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDeEVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ3ROQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQzVtQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ3JLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUM1TkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDL0VBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUN0REE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUN4U0E7QUFDQTs7Ozs7Ozs7O0FDREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUNwS0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUN6T0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ25HQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUNoTkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDbENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUMxTEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDeE9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ3RCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDaEdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUM5QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDbkhBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQzVIQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUNuSEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDMUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUN0Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUNubUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUN4TUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDeHJCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDOU1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUNqTkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ3hHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ3ZHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUMvREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDaEdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7OztBQzFCQTs7Ozs7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUNmQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUNoRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUNuSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7OztBQ3ZTQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDTEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDaEJBOzs7Ozs7OztBQ0FBOzs7Ozs7OztBQ0FBOzs7Ozs7OztBQ0FBOzs7Ozs7OztBQ0FBOzs7Ozs7OztBQ0FBOzs7Ozs7OztBQ0FBOzs7Ozs7OztBQ0FBOzs7Ozs7OztBQ0FBOzs7Ozs7OztBQ0FBOzs7Ozs7OztBQ0FBOzs7Ozs7OztBQ0FBOzs7Ozs7OztBQ0FBOzs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7OztBQ3ZCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7OztBQ1BBOzs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7OztBRU5BO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vY29uZWN0aW9uLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL2xhbWJkYXMvZ2V0UHJvZHVjdHNCeUlkLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9pbmhlcml0cy9pbmhlcml0cy5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvaW5oZXJpdHMvaW5oZXJpdHNfYnJvd3Nlci5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGctY29ubmVjdGlvbi1zdHJpbmcvaW5kZXguanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnLWludDgvaW5kZXguanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnLXBvb2wvaW5kZXguanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnLXByb3RvY29sL2Rpc3QvYnVmZmVyLXJlYWRlci5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGctcHJvdG9jb2wvZGlzdC9idWZmZXItd3JpdGVyLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy1wcm90b2NvbC9kaXN0L2luZGV4LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy1wcm90b2NvbC9kaXN0L21lc3NhZ2VzLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy1wcm90b2NvbC9kaXN0L3BhcnNlci5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGctcHJvdG9jb2wvZGlzdC9zZXJpYWxpemVyLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy10eXBlcy9pbmRleC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGctdHlwZXMvbGliL2FycmF5UGFyc2VyLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy10eXBlcy9saWIvYmluYXJ5UGFyc2Vycy5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGctdHlwZXMvbGliL2J1aWx0aW5zLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy10eXBlcy9saWIvdGV4dFBhcnNlcnMuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnL2xpYi9jbGllbnQuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnL2xpYi9jb25uZWN0aW9uLXBhcmFtZXRlcnMuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnL2xpYi9jb25uZWN0aW9uLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy9saWIvZGVmYXVsdHMuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnL2xpYi9pbmRleC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGcvbGliL25hdGl2ZS9jbGllbnQuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnL2xpYi9uYXRpdmUvaW5kZXguanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnL2xpYi9uYXRpdmUvcXVlcnkuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnL2xpYi9xdWVyeS5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGcvbGliL3Jlc3VsdC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGcvbGliL3Nhc2wuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnL2xpYi90eXBlLW92ZXJyaWRlcy5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGcvbGliL3V0aWxzLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZ3Bhc3MvbGliL2hlbHBlci5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGdwYXNzL2xpYi9pbmRleC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcG9zdGdyZXMtYXJyYXkvaW5kZXguanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3Bvc3RncmVzLWJ5dGVhL2luZGV4LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wb3N0Z3Jlcy1kYXRlL2luZGV4LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wb3N0Z3Jlcy1pbnRlcnZhbC9pbmRleC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcmVhZGFibGUtc3RyZWFtL2Vycm9ycy5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcmVhZGFibGUtc3RyZWFtL2xpYi9fc3RyZWFtX2R1cGxleC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcmVhZGFibGUtc3RyZWFtL2xpYi9fc3RyZWFtX3Bhc3N0aHJvdWdoLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9yZWFkYWJsZS1zdHJlYW0vbGliL19zdHJlYW1fcmVhZGFibGUuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3JlYWRhYmxlLXN0cmVhbS9saWIvX3N0cmVhbV90cmFuc2Zvcm0uanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3JlYWRhYmxlLXN0cmVhbS9saWIvX3N0cmVhbV93cml0YWJsZS5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcmVhZGFibGUtc3RyZWFtL2xpYi9pbnRlcm5hbC9zdHJlYW1zL2FzeW5jX2l0ZXJhdG9yLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9yZWFkYWJsZS1zdHJlYW0vbGliL2ludGVybmFsL3N0cmVhbXMvYnVmZmVyX2xpc3QuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3JlYWRhYmxlLXN0cmVhbS9saWIvaW50ZXJuYWwvc3RyZWFtcy9kZXN0cm95LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9yZWFkYWJsZS1zdHJlYW0vbGliL2ludGVybmFsL3N0cmVhbXMvZW5kLW9mLXN0cmVhbS5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcmVhZGFibGUtc3RyZWFtL2xpYi9pbnRlcm5hbC9zdHJlYW1zL2Zyb20uanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3JlYWRhYmxlLXN0cmVhbS9saWIvaW50ZXJuYWwvc3RyZWFtcy9waXBlbGluZS5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcmVhZGFibGUtc3RyZWFtL2xpYi9pbnRlcm5hbC9zdHJlYW1zL3N0YXRlLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9yZWFkYWJsZS1zdHJlYW0vbGliL2ludGVybmFsL3N0cmVhbXMvc3RyZWFtLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9yZWFkYWJsZS1zdHJlYW0vcmVhZGFibGUuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3NhZmUtYnVmZmVyL2luZGV4LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9zcGxpdDIvaW5kZXguanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3N0cmluZ19kZWNvZGVyL2xpYi9zdHJpbmdfZGVjb2Rlci5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvdXRpbC1kZXByZWNhdGUvbm9kZS5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMveHRlbmQvbXV0YWJsZS5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvZXh0ZXJuYWwgXCJhc3NlcnRcIiIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvZXh0ZXJuYWwgXCJidWZmZXJcIiIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvZXh0ZXJuYWwgXCJjcnlwdG9cIiIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvZXh0ZXJuYWwgXCJkbnNcIiIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvZXh0ZXJuYWwgXCJldmVudHNcIiIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvZXh0ZXJuYWwgXCJmc1wiIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS9leHRlcm5hbCBcIm5ldFwiIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS9leHRlcm5hbCBcInBhdGhcIiIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvZXh0ZXJuYWwgXCJzdHJlYW1cIiIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvZXh0ZXJuYWwgXCJzdHJpbmdfZGVjb2RlclwiIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS9leHRlcm5hbCBcInRsc1wiIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS9leHRlcm5hbCBcInVybFwiIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS9leHRlcm5hbCBcInV0aWxcIiIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2Uvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL3dlYnBhY2svcnVudGltZS9kZWZpbmUgcHJvcGVydHkgZ2V0dGVycyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2Uvd2VicGFjay9ydW50aW1lL2hhc093blByb3BlcnR5IHNob3J0aGFuZCIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2Uvd2VicGFjay9ydW50aW1lL21ha2UgbmFtZXNwYWNlIG9iamVjdCIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2Uvd2VicGFjay9iZWZvcmUtc3RhcnR1cCIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2Uvd2VicGFjay9zdGFydHVwIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS93ZWJwYWNrL2FmdGVyLXN0YXJ0dXAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ2xpZW50IH0gZnJvbSAncGcnO1xyXG5cclxuXHJcbmNvbnN0IHsgUEdfSE9TVCwgUEdfUE9SVCwgUEdfREFUQUJBU0UsIFBHX1VTRVJOQU1FLCBQR19QQVNTV09SRCB9ID0gcHJvY2Vzcy5lbnY7XHJcbmV4cG9ydCBjb25zdCBkYk9wdGlvbnMgPSB7XHJcbiAgICBob3N0OiBQR19IT1NULFxyXG4gICAgcG9ydDogUEdfUE9SVCxcclxuICAgIGRhdGFiYXNlOiBQR19EQVRBQkFTRSxcclxuICAgIHVzZXI6IFBHX1VTRVJOQU1FLFxyXG4gICAgcGFzc3dvcmQ6IFBHX1BBU1NXT1JELFxyXG4gICAgc3NsOiB7XHJcbiAgICAgICAgcmVqZWN0VW5hdXRob3JpemVkOiBmYWxzZSxcclxuICAgIH0sXHJcbiAgICBjb25uZWN0aW9uVGltZW91dE1pbGxpczogNTAwMCxcclxufTtcclxuZXhwb3J0IGNsYXNzIENvbm5lY3REQiB7XHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgICB0aGlzLmNsaWVudCA9IG5ldyBDbGllbnQoZGJPcHRpb25zKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBjb25uZWN0KCkge1xyXG4gICAgICAgIGF3YWl0IHRoaXMuY2xpZW50LmNvbm5lY3QoKTtcclxuICAgICAgICByZXR1cm4gdGhpcy5jbGllbnQ7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZGlzY29ubmVjdCgpIHtcclxuICAgICAgICBhd2FpdCB0aGlzLmNsaWVudC5lbmQoKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBjcmVhdGVUYWJsZSh0YWJsZU5hbWUsIGNvbmZpZykge1xyXG4gICAgICAgIGF3YWl0IHRoaXMuY2xpZW50LnF1ZXJ5KGBcclxuICBjcmVhdGUgdGFibGUgaWYgbm90IGV4aXN0ICR7dGFibGVOYW1lfSAoXHJcbiAgICAke2NvbmZpZ31cclxuICApYCk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIGFzeW5jIGdldExpc3QodGFibGVOYW1lKSB7XHJcbiAgICAgICAgY29uc3QgeyByb3dzIH0gPSBhd2FpdCB0aGlzLmNsaWVudC5xdWVyeShzZWxlY3QgKiBmcm9tIGAke3RhYmxlTmFtZX1gKTtcclxuICAgICAgICByZXR1cm4gcm93cztcclxuICAgIH1cclxufSIsImltcG9ydCBwcm9kdWN0cyBmcm9tICcuL2RiL3Byb2R1Y3RzLmpzb24nO1xyXG5pbXBvcnQgeyBDbGllbnQgfSBmcm9tICdwZyc7XHJcbmltcG9ydCB7IENvbm5lY3REQiwgZGJPcHRpb25zIH0gZnJvbSAnLi4vY29uZWN0aW9uJ1xyXG5cclxuZXhwb3J0IGNvbnN0IGhhbmRsZXIgPSBhc3luYyAoZXZlbnQpID0+IHtcclxuICAgIGNvbnN0IHsgcHJvZHVjdElkIH0gPSBldmVudC5wYXRoUGFyYW1ldGVycyB8fCB7fTtcclxuICAgIGNvbnN0IGdldFByb2R1Y3QgPSBwcm9kdWN0cy5maW5kKChpdGVtLCBpZCkgPT4ge1xyXG4gICAgICAgIHJldHVybiBpdGVtLmlkID09IHByb2R1Y3RJZDtcclxuICAgIH0pO1xyXG4gICAgY29uc3QgZGIgPSBuZXcgQ29ubmVjdERCKCk7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBjbGllbnQgPSBhd2FpdCBkYi5jb25uZWN0KCk7XHJcblxyXG4gICAgICAgIGNvbnN0IHsgcm93cyB9ID0gYXdhaXQgY2xpZW50LnF1ZXJ5KGBzZWxlY3QgcHJvZHVjdHMuKiwgc3RvY2suY291bnQgZnJvbSBwcm9kdWN0cyBsZWZ0IGpvaW4gc3RvY2sgb24gcHJvZHVjdHMuaWQgPSBzdG9jay5wcm9kdWN0X2lkIHdoZXJlIHByb2R1Y3RzLmlkPScke3Byb2R1Y3RJZH0nYCk7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICAgICAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU1ldGhvZHMnOiAnKicsXHJcbiAgICAgICAgICAgICAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICcqJyxcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcclxuICAgICAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHJvd3MpXHJcbiAgICAgICAgICAgIH07XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1NZXRob2RzJzogJyonLFxyXG4gICAgICAgICAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICcqJyxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzdGF0dXNDb2RlOiA0MDQsXHJcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgbWVzc2FnZTogZXJyb3IubWVzc2FnZSB9KVxyXG4gICAgICAgIH07XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIGRiLmRpc2Nvbm5lY3QoKTtcclxuICAgIH1cclxuICAgIC8vIGNvbnN0IHJlc3BvbnNlID0ge1xyXG4gICAgLy8gICAgIGhlYWRlcnM6IHtcclxuICAgIC8vICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgIC8vICAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU1ldGhvZHMnOiAnKicsXHJcbiAgICAvLyAgICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nOiAnKicsXHJcbiAgICAvLyAgICAgICB9LFxyXG4gICAgLy8gICAgIHN0YXR1c0NvZGU6IDIwMCxcclxuICAgIC8vIH1cclxuICAgIC8vIGlmICghZ2V0UHJvZHVjdCkgICB7IFxyXG4gICAgLy8gICAgIHJlc3BvbnNlLmJvZHkgPSAgSlNPTi5zdHJpbmdpZnkoeyBtZXNzYWdlOiAnRXJyb3I6IFByb2R1Y3Qgbm90IGZvdW5kIScgfSk7XHJcblxyXG4gICAgLy8gICAgIHJlc3BvbnNlLnN0YXR1c0NvZGUgPSA0MDQ7XHJcbiAgICAvLyB9IGVsc2Uge1xyXG4gICAgLy8gICAgIHJlc3BvbnNlLmJvZHkgPSBKU09OLnN0cmluZ2lmeShnZXRQcm9kdWN0KTsgXHJcbiAgICAvLyB9XHJcbiAgICAvLyByZXR1cm4gcmVzcG9uc2U7XHJcbn0iLCJ0cnkge1xuICB2YXIgdXRpbCA9IHJlcXVpcmUoJ3V0aWwnKTtcbiAgLyogaXN0YW5idWwgaWdub3JlIG5leHQgKi9cbiAgaWYgKHR5cGVvZiB1dGlsLmluaGVyaXRzICE9PSAnZnVuY3Rpb24nKSB0aHJvdyAnJztcbiAgbW9kdWxlLmV4cG9ydHMgPSB1dGlsLmluaGVyaXRzO1xufSBjYXRjaCAoZSkge1xuICAvKiBpc3RhbmJ1bCBpZ25vcmUgbmV4dCAqL1xuICBtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vaW5oZXJpdHNfYnJvd3Nlci5qcycpO1xufVxuIiwiaWYgKHR5cGVvZiBPYmplY3QuY3JlYXRlID09PSAnZnVuY3Rpb24nKSB7XG4gIC8vIGltcGxlbWVudGF0aW9uIGZyb20gc3RhbmRhcmQgbm9kZS5qcyAndXRpbCcgbW9kdWxlXG4gIG1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gaW5oZXJpdHMoY3Rvciwgc3VwZXJDdG9yKSB7XG4gICAgaWYgKHN1cGVyQ3Rvcikge1xuICAgICAgY3Rvci5zdXBlcl8gPSBzdXBlckN0b3JcbiAgICAgIGN0b3IucHJvdG90eXBlID0gT2JqZWN0LmNyZWF0ZShzdXBlckN0b3IucHJvdG90eXBlLCB7XG4gICAgICAgIGNvbnN0cnVjdG9yOiB7XG4gICAgICAgICAgdmFsdWU6IGN0b3IsXG4gICAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfVxuICB9O1xufSBlbHNlIHtcbiAgLy8gb2xkIHNjaG9vbCBzaGltIGZvciBvbGQgYnJvd3NlcnNcbiAgbW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBpbmhlcml0cyhjdG9yLCBzdXBlckN0b3IpIHtcbiAgICBpZiAoc3VwZXJDdG9yKSB7XG4gICAgICBjdG9yLnN1cGVyXyA9IHN1cGVyQ3RvclxuICAgICAgdmFyIFRlbXBDdG9yID0gZnVuY3Rpb24gKCkge31cbiAgICAgIFRlbXBDdG9yLnByb3RvdHlwZSA9IHN1cGVyQ3Rvci5wcm90b3R5cGVcbiAgICAgIGN0b3IucHJvdG90eXBlID0gbmV3IFRlbXBDdG9yKClcbiAgICAgIGN0b3IucHJvdG90eXBlLmNvbnN0cnVjdG9yID0gY3RvclxuICAgIH1cbiAgfVxufVxuIiwiJ3VzZSBzdHJpY3QnXG5cbnZhciB1cmwgPSByZXF1aXJlKCd1cmwnKVxudmFyIGZzID0gcmVxdWlyZSgnZnMnKVxuXG4vL1BhcnNlIG1ldGhvZCBjb3BpZWQgZnJvbSBodHRwczovL2dpdGh1Yi5jb20vYnJpYW5jL25vZGUtcG9zdGdyZXNcbi8vQ29weXJpZ2h0IChjKSAyMDEwLTIwMTQgQnJpYW4gQ2FybHNvbiAoYnJpYW4ubS5jYXJsc29uQGdtYWlsLmNvbSlcbi8vTUlUIExpY2Vuc2VcblxuLy9wYXJzZXMgYSBjb25uZWN0aW9uIHN0cmluZ1xuZnVuY3Rpb24gcGFyc2Uoc3RyKSB7XG4gIC8vdW5peCBzb2NrZXRcbiAgaWYgKHN0ci5jaGFyQXQoMCkgPT09ICcvJykge1xuICAgIHZhciBjb25maWcgPSBzdHIuc3BsaXQoJyAnKVxuICAgIHJldHVybiB7IGhvc3Q6IGNvbmZpZ1swXSwgZGF0YWJhc2U6IGNvbmZpZ1sxXSB9XG4gIH1cblxuICAvLyB1cmwgcGFyc2UgZXhwZWN0cyBzcGFjZXMgZW5jb2RlZCBhcyAlMjBcbiAgdmFyIHJlc3VsdCA9IHVybC5wYXJzZShcbiAgICAvIHwlW15hLWYwLTldfCVbYS1mMC05XVteYS1mMC05XS9pLnRlc3Qoc3RyKSA/IGVuY29kZVVSSShzdHIpLnJlcGxhY2UoL1xcJTI1KFxcZFxcZCkvZywgJyUkMScpIDogc3RyLFxuICAgIHRydWVcbiAgKVxuICB2YXIgY29uZmlnID0gcmVzdWx0LnF1ZXJ5XG4gIGZvciAodmFyIGsgaW4gY29uZmlnKSB7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoY29uZmlnW2tdKSkge1xuICAgICAgY29uZmlnW2tdID0gY29uZmlnW2tdW2NvbmZpZ1trXS5sZW5ndGggLSAxXVxuICAgIH1cbiAgfVxuXG4gIHZhciBhdXRoID0gKHJlc3VsdC5hdXRoIHx8ICc6Jykuc3BsaXQoJzonKVxuICBjb25maWcudXNlciA9IGF1dGhbMF1cbiAgY29uZmlnLnBhc3N3b3JkID0gYXV0aC5zcGxpY2UoMSkuam9pbignOicpXG5cbiAgY29uZmlnLnBvcnQgPSByZXN1bHQucG9ydFxuICBpZiAocmVzdWx0LnByb3RvY29sID09ICdzb2NrZXQ6Jykge1xuICAgIGNvbmZpZy5ob3N0ID0gZGVjb2RlVVJJKHJlc3VsdC5wYXRobmFtZSlcbiAgICBjb25maWcuZGF0YWJhc2UgPSByZXN1bHQucXVlcnkuZGJcbiAgICBjb25maWcuY2xpZW50X2VuY29kaW5nID0gcmVzdWx0LnF1ZXJ5LmVuY29kaW5nXG4gICAgcmV0dXJuIGNvbmZpZ1xuICB9XG4gIGlmICghY29uZmlnLmhvc3QpIHtcbiAgICAvLyBPbmx5IHNldCB0aGUgaG9zdCBpZiB0aGVyZSBpcyBubyBlcXVpdmFsZW50IHF1ZXJ5IHBhcmFtLlxuICAgIGNvbmZpZy5ob3N0ID0gcmVzdWx0Lmhvc3RuYW1lXG4gIH1cblxuICAvLyBJZiB0aGUgaG9zdCBpcyBtaXNzaW5nIGl0IG1pZ2h0IGJlIGEgVVJMLWVuY29kZWQgcGF0aCB0byBhIHNvY2tldC5cbiAgdmFyIHBhdGhuYW1lID0gcmVzdWx0LnBhdGhuYW1lXG4gIGlmICghY29uZmlnLmhvc3QgJiYgcGF0aG5hbWUgJiYgL14lMmYvaS50ZXN0KHBhdGhuYW1lKSkge1xuICAgIHZhciBwYXRobmFtZVNwbGl0ID0gcGF0aG5hbWUuc3BsaXQoJy8nKVxuICAgIGNvbmZpZy5ob3N0ID0gZGVjb2RlVVJJQ29tcG9uZW50KHBhdGhuYW1lU3BsaXRbMF0pXG4gICAgcGF0aG5hbWUgPSBwYXRobmFtZVNwbGl0LnNwbGljZSgxKS5qb2luKCcvJylcbiAgfVxuICAvLyByZXN1bHQucGF0aG5hbWUgaXMgbm90IGFsd2F5cyBndWFyYW50ZWVkIHRvIGhhdmUgYSAnLycgcHJlZml4IChlLmcuIHJlbGF0aXZlIHVybHMpXG4gIC8vIG9ubHkgc3RyaXAgdGhlIHNsYXNoIGlmIGl0IGlzIHByZXNlbnQuXG4gIGlmIChwYXRobmFtZSAmJiBwYXRobmFtZS5jaGFyQXQoMCkgPT09ICcvJykge1xuICAgIHBhdGhuYW1lID0gcGF0aG5hbWUuc2xpY2UoMSkgfHwgbnVsbFxuICB9XG4gIGNvbmZpZy5kYXRhYmFzZSA9IHBhdGhuYW1lICYmIGRlY29kZVVSSShwYXRobmFtZSlcblxuICBpZiAoY29uZmlnLnNzbCA9PT0gJ3RydWUnIHx8IGNvbmZpZy5zc2wgPT09ICcxJykge1xuICAgIGNvbmZpZy5zc2wgPSB0cnVlXG4gIH1cblxuICBpZiAoY29uZmlnLnNzbCA9PT0gJzAnKSB7XG4gICAgY29uZmlnLnNzbCA9IGZhbHNlXG4gIH1cblxuICBpZiAoY29uZmlnLnNzbGNlcnQgfHwgY29uZmlnLnNzbGtleSB8fCBjb25maWcuc3Nscm9vdGNlcnQgfHwgY29uZmlnLnNzbG1vZGUpIHtcbiAgICBjb25maWcuc3NsID0ge31cbiAgfVxuXG4gIGlmIChjb25maWcuc3NsY2VydCkge1xuICAgIGNvbmZpZy5zc2wuY2VydCA9IGZzLnJlYWRGaWxlU3luYyhjb25maWcuc3NsY2VydCkudG9TdHJpbmcoKVxuICB9XG5cbiAgaWYgKGNvbmZpZy5zc2xrZXkpIHtcbiAgICBjb25maWcuc3NsLmtleSA9IGZzLnJlYWRGaWxlU3luYyhjb25maWcuc3Nsa2V5KS50b1N0cmluZygpXG4gIH1cblxuICBpZiAoY29uZmlnLnNzbHJvb3RjZXJ0KSB7XG4gICAgY29uZmlnLnNzbC5jYSA9IGZzLnJlYWRGaWxlU3luYyhjb25maWcuc3Nscm9vdGNlcnQpLnRvU3RyaW5nKClcbiAgfVxuXG4gIHN3aXRjaCAoY29uZmlnLnNzbG1vZGUpIHtcbiAgICBjYXNlICdkaXNhYmxlJzoge1xuICAgICAgY29uZmlnLnNzbCA9IGZhbHNlXG4gICAgICBicmVha1xuICAgIH1cbiAgICBjYXNlICdwcmVmZXInOlxuICAgIGNhc2UgJ3JlcXVpcmUnOlxuICAgIGNhc2UgJ3ZlcmlmeS1jYSc6XG4gICAgY2FzZSAndmVyaWZ5LWZ1bGwnOiB7XG4gICAgICBicmVha1xuICAgIH1cbiAgICBjYXNlICduby12ZXJpZnknOiB7XG4gICAgICBjb25maWcuc3NsLnJlamVjdFVuYXV0aG9yaXplZCA9IGZhbHNlXG4gICAgICBicmVha1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiBjb25maWdcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBwYXJzZVxuXG5wYXJzZS5wYXJzZSA9IHBhcnNlXG4iLCIndXNlIHN0cmljdCc7XG5cbi8vIHNlbGVjdGVkIHNvIChCQVNFIC0gMSkgKiAweDEwMDAwMDAwMCArIDB4ZmZmZmZmZmYgaXMgYSBzYWZlIGludGVnZXJcbnZhciBCQVNFID0gMTAwMDAwMDtcblxuZnVuY3Rpb24gcmVhZEludDgoYnVmZmVyKSB7XG5cdHZhciBoaWdoID0gYnVmZmVyLnJlYWRJbnQzMkJFKDApO1xuXHR2YXIgbG93ID0gYnVmZmVyLnJlYWRVSW50MzJCRSg0KTtcblx0dmFyIHNpZ24gPSAnJztcblxuXHRpZiAoaGlnaCA8IDApIHtcblx0XHRoaWdoID0gfmhpZ2ggKyAobG93ID09PSAwKTtcblx0XHRsb3cgPSAofmxvdyArIDEpID4+PiAwO1xuXHRcdHNpZ24gPSAnLSc7XG5cdH1cblxuXHR2YXIgcmVzdWx0ID0gJyc7XG5cdHZhciBjYXJyeTtcblx0dmFyIHQ7XG5cdHZhciBkaWdpdHM7XG5cdHZhciBwYWQ7XG5cdHZhciBsO1xuXHR2YXIgaTtcblxuXHR7XG5cdFx0Y2FycnkgPSBoaWdoICUgQkFTRTtcblx0XHRoaWdoID0gaGlnaCAvIEJBU0UgPj4+IDA7XG5cblx0XHR0ID0gMHgxMDAwMDAwMDAgKiBjYXJyeSArIGxvdztcblx0XHRsb3cgPSB0IC8gQkFTRSA+Pj4gMDtcblx0XHRkaWdpdHMgPSAnJyArICh0IC0gQkFTRSAqIGxvdyk7XG5cblx0XHRpZiAobG93ID09PSAwICYmIGhpZ2ggPT09IDApIHtcblx0XHRcdHJldHVybiBzaWduICsgZGlnaXRzICsgcmVzdWx0O1xuXHRcdH1cblxuXHRcdHBhZCA9ICcnO1xuXHRcdGwgPSA2IC0gZGlnaXRzLmxlbmd0aDtcblxuXHRcdGZvciAoaSA9IDA7IGkgPCBsOyBpKyspIHtcblx0XHRcdHBhZCArPSAnMCc7XG5cdFx0fVxuXG5cdFx0cmVzdWx0ID0gcGFkICsgZGlnaXRzICsgcmVzdWx0O1xuXHR9XG5cblx0e1xuXHRcdGNhcnJ5ID0gaGlnaCAlIEJBU0U7XG5cdFx0aGlnaCA9IGhpZ2ggLyBCQVNFID4+PiAwO1xuXG5cdFx0dCA9IDB4MTAwMDAwMDAwICogY2FycnkgKyBsb3c7XG5cdFx0bG93ID0gdCAvIEJBU0UgPj4+IDA7XG5cdFx0ZGlnaXRzID0gJycgKyAodCAtIEJBU0UgKiBsb3cpO1xuXG5cdFx0aWYgKGxvdyA9PT0gMCAmJiBoaWdoID09PSAwKSB7XG5cdFx0XHRyZXR1cm4gc2lnbiArIGRpZ2l0cyArIHJlc3VsdDtcblx0XHR9XG5cblx0XHRwYWQgPSAnJztcblx0XHRsID0gNiAtIGRpZ2l0cy5sZW5ndGg7XG5cblx0XHRmb3IgKGkgPSAwOyBpIDwgbDsgaSsrKSB7XG5cdFx0XHRwYWQgKz0gJzAnO1xuXHRcdH1cblxuXHRcdHJlc3VsdCA9IHBhZCArIGRpZ2l0cyArIHJlc3VsdDtcblx0fVxuXG5cdHtcblx0XHRjYXJyeSA9IGhpZ2ggJSBCQVNFO1xuXHRcdGhpZ2ggPSBoaWdoIC8gQkFTRSA+Pj4gMDtcblxuXHRcdHQgPSAweDEwMDAwMDAwMCAqIGNhcnJ5ICsgbG93O1xuXHRcdGxvdyA9IHQgLyBCQVNFID4+PiAwO1xuXHRcdGRpZ2l0cyA9ICcnICsgKHQgLSBCQVNFICogbG93KTtcblxuXHRcdGlmIChsb3cgPT09IDAgJiYgaGlnaCA9PT0gMCkge1xuXHRcdFx0cmV0dXJuIHNpZ24gKyBkaWdpdHMgKyByZXN1bHQ7XG5cdFx0fVxuXG5cdFx0cGFkID0gJyc7XG5cdFx0bCA9IDYgLSBkaWdpdHMubGVuZ3RoO1xuXG5cdFx0Zm9yIChpID0gMDsgaSA8IGw7IGkrKykge1xuXHRcdFx0cGFkICs9ICcwJztcblx0XHR9XG5cblx0XHRyZXN1bHQgPSBwYWQgKyBkaWdpdHMgKyByZXN1bHQ7XG5cdH1cblxuXHR7XG5cdFx0Y2FycnkgPSBoaWdoICUgQkFTRTtcblx0XHR0ID0gMHgxMDAwMDAwMDAgKiBjYXJyeSArIGxvdztcblx0XHRkaWdpdHMgPSAnJyArIHQgJSBCQVNFO1xuXG5cdFx0cmV0dXJuIHNpZ24gKyBkaWdpdHMgKyByZXN1bHQ7XG5cdH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSByZWFkSW50ODtcbiIsIid1c2Ugc3RyaWN0J1xuY29uc3QgRXZlbnRFbWl0dGVyID0gcmVxdWlyZSgnZXZlbnRzJykuRXZlbnRFbWl0dGVyXG5cbmNvbnN0IE5PT1AgPSBmdW5jdGlvbiAoKSB7fVxuXG5jb25zdCByZW1vdmVXaGVyZSA9IChsaXN0LCBwcmVkaWNhdGUpID0+IHtcbiAgY29uc3QgaSA9IGxpc3QuZmluZEluZGV4KHByZWRpY2F0ZSlcblxuICByZXR1cm4gaSA9PT0gLTEgPyB1bmRlZmluZWQgOiBsaXN0LnNwbGljZShpLCAxKVswXVxufVxuXG5jbGFzcyBJZGxlSXRlbSB7XG4gIGNvbnN0cnVjdG9yKGNsaWVudCwgaWRsZUxpc3RlbmVyLCB0aW1lb3V0SWQpIHtcbiAgICB0aGlzLmNsaWVudCA9IGNsaWVudFxuICAgIHRoaXMuaWRsZUxpc3RlbmVyID0gaWRsZUxpc3RlbmVyXG4gICAgdGhpcy50aW1lb3V0SWQgPSB0aW1lb3V0SWRcbiAgfVxufVxuXG5jbGFzcyBQZW5kaW5nSXRlbSB7XG4gIGNvbnN0cnVjdG9yKGNhbGxiYWNrKSB7XG4gICAgdGhpcy5jYWxsYmFjayA9IGNhbGxiYWNrXG4gIH1cbn1cblxuZnVuY3Rpb24gdGhyb3dPbkRvdWJsZVJlbGVhc2UoKSB7XG4gIHRocm93IG5ldyBFcnJvcignUmVsZWFzZSBjYWxsZWQgb24gY2xpZW50IHdoaWNoIGhhcyBhbHJlYWR5IGJlZW4gcmVsZWFzZWQgdG8gdGhlIHBvb2wuJylcbn1cblxuZnVuY3Rpb24gcHJvbWlzaWZ5KFByb21pc2UsIGNhbGxiYWNrKSB7XG4gIGlmIChjYWxsYmFjaykge1xuICAgIHJldHVybiB7IGNhbGxiYWNrOiBjYWxsYmFjaywgcmVzdWx0OiB1bmRlZmluZWQgfVxuICB9XG4gIGxldCByZWpcbiAgbGV0IHJlc1xuICBjb25zdCBjYiA9IGZ1bmN0aW9uIChlcnIsIGNsaWVudCkge1xuICAgIGVyciA/IHJlaihlcnIpIDogcmVzKGNsaWVudClcbiAgfVxuICBjb25zdCByZXN1bHQgPSBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgcmVzID0gcmVzb2x2ZVxuICAgIHJlaiA9IHJlamVjdFxuICB9KVxuICByZXR1cm4geyBjYWxsYmFjazogY2IsIHJlc3VsdDogcmVzdWx0IH1cbn1cblxuZnVuY3Rpb24gbWFrZUlkbGVMaXN0ZW5lcihwb29sLCBjbGllbnQpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIGlkbGVMaXN0ZW5lcihlcnIpIHtcbiAgICBlcnIuY2xpZW50ID0gY2xpZW50XG5cbiAgICBjbGllbnQucmVtb3ZlTGlzdGVuZXIoJ2Vycm9yJywgaWRsZUxpc3RlbmVyKVxuICAgIGNsaWVudC5vbignZXJyb3InLCAoKSA9PiB7XG4gICAgICBwb29sLmxvZygnYWRkaXRpb25hbCBjbGllbnQgZXJyb3IgYWZ0ZXIgZGlzY29ubmVjdGlvbiBkdWUgdG8gZXJyb3InLCBlcnIpXG4gICAgfSlcbiAgICBwb29sLl9yZW1vdmUoY2xpZW50KVxuICAgIC8vIFRPRE8gLSBkb2N1bWVudCB0aGF0IG9uY2UgdGhlIHBvb2wgZW1pdHMgYW4gZXJyb3JcbiAgICAvLyB0aGUgY2xpZW50IGhhcyBhbHJlYWR5IGJlZW4gY2xvc2VkICYgcHVyZ2VkIGFuZCBpcyB1bnVzYWJsZVxuICAgIHBvb2wuZW1pdCgnZXJyb3InLCBlcnIsIGNsaWVudClcbiAgfVxufVxuXG5jbGFzcyBQb29sIGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgY29uc3RydWN0b3Iob3B0aW9ucywgQ2xpZW50KSB7XG4gICAgc3VwZXIoKVxuICAgIHRoaXMub3B0aW9ucyA9IE9iamVjdC5hc3NpZ24oe30sIG9wdGlvbnMpXG5cbiAgICBpZiAob3B0aW9ucyAhPSBudWxsICYmICdwYXNzd29yZCcgaW4gb3B0aW9ucykge1xuICAgICAgLy8gXCJoaWRpbmdcIiB0aGUgcGFzc3dvcmQgc28gaXQgZG9lc24ndCBzaG93IHVwIGluIHN0YWNrIHRyYWNlc1xuICAgICAgLy8gb3IgaWYgdGhlIGNsaWVudCBpcyBjb25zb2xlLmxvZ2dlZFxuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMub3B0aW9ucywgJ3Bhc3N3b3JkJywge1xuICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgdmFsdWU6IG9wdGlvbnMucGFzc3dvcmQsXG4gICAgICB9KVxuICAgIH1cbiAgICBpZiAob3B0aW9ucyAhPSBudWxsICYmIG9wdGlvbnMuc3NsICYmIG9wdGlvbnMuc3NsLmtleSkge1xuICAgICAgLy8gXCJoaWRpbmdcIiB0aGUgc3NsLT5rZXkgc28gaXQgZG9lc24ndCBzaG93IHVwIGluIHN0YWNrIHRyYWNlc1xuICAgICAgLy8gb3IgaWYgdGhlIGNsaWVudCBpcyBjb25zb2xlLmxvZ2dlZFxuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMub3B0aW9ucy5zc2wsICdrZXknLCB7XG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgfSlcbiAgICB9XG5cbiAgICB0aGlzLm9wdGlvbnMubWF4ID0gdGhpcy5vcHRpb25zLm1heCB8fCB0aGlzLm9wdGlvbnMucG9vbFNpemUgfHwgMTBcbiAgICB0aGlzLm9wdGlvbnMubWF4VXNlcyA9IHRoaXMub3B0aW9ucy5tYXhVc2VzIHx8IEluZmluaXR5XG4gICAgdGhpcy5vcHRpb25zLmFsbG93RXhpdE9uSWRsZSA9IHRoaXMub3B0aW9ucy5hbGxvd0V4aXRPbklkbGUgfHwgZmFsc2VcbiAgICB0aGlzLmxvZyA9IHRoaXMub3B0aW9ucy5sb2cgfHwgZnVuY3Rpb24gKCkge31cbiAgICB0aGlzLkNsaWVudCA9IHRoaXMub3B0aW9ucy5DbGllbnQgfHwgQ2xpZW50IHx8IHJlcXVpcmUoJ3BnJykuQ2xpZW50XG4gICAgdGhpcy5Qcm9taXNlID0gdGhpcy5vcHRpb25zLlByb21pc2UgfHwgZ2xvYmFsLlByb21pc2VcblxuICAgIGlmICh0eXBlb2YgdGhpcy5vcHRpb25zLmlkbGVUaW1lb3V0TWlsbGlzID09PSAndW5kZWZpbmVkJykge1xuICAgICAgdGhpcy5vcHRpb25zLmlkbGVUaW1lb3V0TWlsbGlzID0gMTAwMDBcbiAgICB9XG5cbiAgICB0aGlzLl9jbGllbnRzID0gW11cbiAgICB0aGlzLl9pZGxlID0gW11cbiAgICB0aGlzLl9wZW5kaW5nUXVldWUgPSBbXVxuICAgIHRoaXMuX2VuZENhbGxiYWNrID0gdW5kZWZpbmVkXG4gICAgdGhpcy5lbmRpbmcgPSBmYWxzZVxuICAgIHRoaXMuZW5kZWQgPSBmYWxzZVxuICB9XG5cbiAgX2lzRnVsbCgpIHtcbiAgICByZXR1cm4gdGhpcy5fY2xpZW50cy5sZW5ndGggPj0gdGhpcy5vcHRpb25zLm1heFxuICB9XG5cbiAgX3B1bHNlUXVldWUoKSB7XG4gICAgdGhpcy5sb2coJ3B1bHNlIHF1ZXVlJylcbiAgICBpZiAodGhpcy5lbmRlZCkge1xuICAgICAgdGhpcy5sb2coJ3B1bHNlIHF1ZXVlIGVuZGVkJylcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICBpZiAodGhpcy5lbmRpbmcpIHtcbiAgICAgIHRoaXMubG9nKCdwdWxzZSBxdWV1ZSBvbiBlbmRpbmcnKVxuICAgICAgaWYgKHRoaXMuX2lkbGUubGVuZ3RoKSB7XG4gICAgICAgIHRoaXMuX2lkbGUuc2xpY2UoKS5tYXAoKGl0ZW0pID0+IHtcbiAgICAgICAgICB0aGlzLl9yZW1vdmUoaXRlbS5jbGllbnQpXG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgICBpZiAoIXRoaXMuX2NsaWVudHMubGVuZ3RoKSB7XG4gICAgICAgIHRoaXMuZW5kZWQgPSB0cnVlXG4gICAgICAgIHRoaXMuX2VuZENhbGxiYWNrKClcbiAgICAgIH1cbiAgICAgIHJldHVyblxuICAgIH1cbiAgICAvLyBpZiB3ZSBkb24ndCBoYXZlIGFueSB3YWl0aW5nLCBkbyBub3RoaW5nXG4gICAgaWYgKCF0aGlzLl9wZW5kaW5nUXVldWUubGVuZ3RoKSB7XG4gICAgICB0aGlzLmxvZygnbm8gcXVldWVkIHJlcXVlc3RzJylcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICAvLyBpZiB3ZSBkb24ndCBoYXZlIGFueSBpZGxlIGNsaWVudHMgYW5kIHdlIGhhdmUgbm8gbW9yZSByb29tIGRvIG5vdGhpbmdcbiAgICBpZiAoIXRoaXMuX2lkbGUubGVuZ3RoICYmIHRoaXMuX2lzRnVsbCgpKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgY29uc3QgcGVuZGluZ0l0ZW0gPSB0aGlzLl9wZW5kaW5nUXVldWUuc2hpZnQoKVxuICAgIGlmICh0aGlzLl9pZGxlLmxlbmd0aCkge1xuICAgICAgY29uc3QgaWRsZUl0ZW0gPSB0aGlzLl9pZGxlLnBvcCgpXG4gICAgICBjbGVhclRpbWVvdXQoaWRsZUl0ZW0udGltZW91dElkKVxuICAgICAgY29uc3QgY2xpZW50ID0gaWRsZUl0ZW0uY2xpZW50XG4gICAgICBjbGllbnQucmVmICYmIGNsaWVudC5yZWYoKVxuICAgICAgY29uc3QgaWRsZUxpc3RlbmVyID0gaWRsZUl0ZW0uaWRsZUxpc3RlbmVyXG5cbiAgICAgIHJldHVybiB0aGlzLl9hY3F1aXJlQ2xpZW50KGNsaWVudCwgcGVuZGluZ0l0ZW0sIGlkbGVMaXN0ZW5lciwgZmFsc2UpXG4gICAgfVxuICAgIGlmICghdGhpcy5faXNGdWxsKCkpIHtcbiAgICAgIHJldHVybiB0aGlzLm5ld0NsaWVudChwZW5kaW5nSXRlbSlcbiAgICB9XG4gICAgdGhyb3cgbmV3IEVycm9yKCd1bmV4cGVjdGVkIGNvbmRpdGlvbicpXG4gIH1cblxuICBfcmVtb3ZlKGNsaWVudCkge1xuICAgIGNvbnN0IHJlbW92ZWQgPSByZW1vdmVXaGVyZSh0aGlzLl9pZGxlLCAoaXRlbSkgPT4gaXRlbS5jbGllbnQgPT09IGNsaWVudClcblxuICAgIGlmIChyZW1vdmVkICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGNsZWFyVGltZW91dChyZW1vdmVkLnRpbWVvdXRJZClcbiAgICB9XG5cbiAgICB0aGlzLl9jbGllbnRzID0gdGhpcy5fY2xpZW50cy5maWx0ZXIoKGMpID0+IGMgIT09IGNsaWVudClcbiAgICBjbGllbnQuZW5kKClcbiAgICB0aGlzLmVtaXQoJ3JlbW92ZScsIGNsaWVudClcbiAgfVxuXG4gIGNvbm5lY3QoY2IpIHtcbiAgICBpZiAodGhpcy5lbmRpbmcpIHtcbiAgICAgIGNvbnN0IGVyciA9IG5ldyBFcnJvcignQ2Fubm90IHVzZSBhIHBvb2wgYWZ0ZXIgY2FsbGluZyBlbmQgb24gdGhlIHBvb2wnKVxuICAgICAgcmV0dXJuIGNiID8gY2IoZXJyKSA6IHRoaXMuUHJvbWlzZS5yZWplY3QoZXJyKVxuICAgIH1cblxuICAgIGNvbnN0IHJlc3BvbnNlID0gcHJvbWlzaWZ5KHRoaXMuUHJvbWlzZSwgY2IpXG4gICAgY29uc3QgcmVzdWx0ID0gcmVzcG9uc2UucmVzdWx0XG5cbiAgICAvLyBpZiB3ZSBkb24ndCBoYXZlIHRvIGNvbm5lY3QgYSBuZXcgY2xpZW50LCBkb24ndCBkbyBzb1xuICAgIGlmICh0aGlzLl9pc0Z1bGwoKSB8fCB0aGlzLl9pZGxlLmxlbmd0aCkge1xuICAgICAgLy8gaWYgd2UgaGF2ZSBpZGxlIGNsaWVudHMgc2NoZWR1bGUgYSBwdWxzZSBpbW1lZGlhdGVseVxuICAgICAgaWYgKHRoaXMuX2lkbGUubGVuZ3RoKSB7XG4gICAgICAgIHByb2Nlc3MubmV4dFRpY2soKCkgPT4gdGhpcy5fcHVsc2VRdWV1ZSgpKVxuICAgICAgfVxuXG4gICAgICBpZiAoIXRoaXMub3B0aW9ucy5jb25uZWN0aW9uVGltZW91dE1pbGxpcykge1xuICAgICAgICB0aGlzLl9wZW5kaW5nUXVldWUucHVzaChuZXcgUGVuZGluZ0l0ZW0ocmVzcG9uc2UuY2FsbGJhY2spKVxuICAgICAgICByZXR1cm4gcmVzdWx0XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHF1ZXVlQ2FsbGJhY2sgPSAoZXJyLCByZXMsIGRvbmUpID0+IHtcbiAgICAgICAgY2xlYXJUaW1lb3V0KHRpZClcbiAgICAgICAgcmVzcG9uc2UuY2FsbGJhY2soZXJyLCByZXMsIGRvbmUpXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHBlbmRpbmdJdGVtID0gbmV3IFBlbmRpbmdJdGVtKHF1ZXVlQ2FsbGJhY2spXG5cbiAgICAgIC8vIHNldCBjb25uZWN0aW9uIHRpbWVvdXQgb24gY2hlY2tpbmcgb3V0IGFuIGV4aXN0aW5nIGNsaWVudFxuICAgICAgY29uc3QgdGlkID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIC8vIHJlbW92ZSB0aGUgY2FsbGJhY2sgZnJvbSBwZW5kaW5nIHdhaXRlcnMgYmVjYXVzZVxuICAgICAgICAvLyB3ZSdyZSBnb2luZyB0byBjYWxsIGl0IHdpdGggYSB0aW1lb3V0IGVycm9yXG4gICAgICAgIHJlbW92ZVdoZXJlKHRoaXMuX3BlbmRpbmdRdWV1ZSwgKGkpID0+IGkuY2FsbGJhY2sgPT09IHF1ZXVlQ2FsbGJhY2spXG4gICAgICAgIHBlbmRpbmdJdGVtLnRpbWVkT3V0ID0gdHJ1ZVxuICAgICAgICByZXNwb25zZS5jYWxsYmFjayhuZXcgRXJyb3IoJ3RpbWVvdXQgZXhjZWVkZWQgd2hlbiB0cnlpbmcgdG8gY29ubmVjdCcpKVxuICAgICAgfSwgdGhpcy5vcHRpb25zLmNvbm5lY3Rpb25UaW1lb3V0TWlsbGlzKVxuXG4gICAgICB0aGlzLl9wZW5kaW5nUXVldWUucHVzaChwZW5kaW5nSXRlbSlcbiAgICAgIHJldHVybiByZXN1bHRcbiAgICB9XG5cbiAgICB0aGlzLm5ld0NsaWVudChuZXcgUGVuZGluZ0l0ZW0ocmVzcG9uc2UuY2FsbGJhY2spKVxuXG4gICAgcmV0dXJuIHJlc3VsdFxuICB9XG5cbiAgbmV3Q2xpZW50KHBlbmRpbmdJdGVtKSB7XG4gICAgY29uc3QgY2xpZW50ID0gbmV3IHRoaXMuQ2xpZW50KHRoaXMub3B0aW9ucylcbiAgICB0aGlzLl9jbGllbnRzLnB1c2goY2xpZW50KVxuICAgIGNvbnN0IGlkbGVMaXN0ZW5lciA9IG1ha2VJZGxlTGlzdGVuZXIodGhpcywgY2xpZW50KVxuXG4gICAgdGhpcy5sb2coJ2NoZWNraW5nIGNsaWVudCB0aW1lb3V0JylcblxuICAgIC8vIGNvbm5lY3Rpb24gdGltZW91dCBsb2dpY1xuICAgIGxldCB0aWRcbiAgICBsZXQgdGltZW91dEhpdCA9IGZhbHNlXG4gICAgaWYgKHRoaXMub3B0aW9ucy5jb25uZWN0aW9uVGltZW91dE1pbGxpcykge1xuICAgICAgdGlkID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHRoaXMubG9nKCdlbmRpbmcgY2xpZW50IGR1ZSB0byB0aW1lb3V0JylcbiAgICAgICAgdGltZW91dEhpdCA9IHRydWVcbiAgICAgICAgLy8gZm9yY2Uga2lsbCB0aGUgbm9kZSBkcml2ZXIsIGFuZCBsZXQgbGlicHEgZG8gaXRzIHRlYXJkb3duXG4gICAgICAgIGNsaWVudC5jb25uZWN0aW9uID8gY2xpZW50LmNvbm5lY3Rpb24uc3RyZWFtLmRlc3Ryb3koKSA6IGNsaWVudC5lbmQoKVxuICAgICAgfSwgdGhpcy5vcHRpb25zLmNvbm5lY3Rpb25UaW1lb3V0TWlsbGlzKVxuICAgIH1cblxuICAgIHRoaXMubG9nKCdjb25uZWN0aW5nIG5ldyBjbGllbnQnKVxuICAgIGNsaWVudC5jb25uZWN0KChlcnIpID0+IHtcbiAgICAgIGlmICh0aWQpIHtcbiAgICAgICAgY2xlYXJUaW1lb3V0KHRpZClcbiAgICAgIH1cbiAgICAgIGNsaWVudC5vbignZXJyb3InLCBpZGxlTGlzdGVuZXIpXG4gICAgICBpZiAoZXJyKSB7XG4gICAgICAgIHRoaXMubG9nKCdjbGllbnQgZmFpbGVkIHRvIGNvbm5lY3QnLCBlcnIpXG4gICAgICAgIC8vIHJlbW92ZSB0aGUgZGVhZCBjbGllbnQgZnJvbSBvdXIgbGlzdCBvZiBjbGllbnRzXG4gICAgICAgIHRoaXMuX2NsaWVudHMgPSB0aGlzLl9jbGllbnRzLmZpbHRlcigoYykgPT4gYyAhPT0gY2xpZW50KVxuICAgICAgICBpZiAodGltZW91dEhpdCkge1xuICAgICAgICAgIGVyci5tZXNzYWdlID0gJ0Nvbm5lY3Rpb24gdGVybWluYXRlZCBkdWUgdG8gY29ubmVjdGlvbiB0aW1lb3V0J1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gdGhpcyBjbGllbnQgd29u4oCZdCBiZSByZWxlYXNlZCwgc28gbW92ZSBvbiBpbW1lZGlhdGVseVxuICAgICAgICB0aGlzLl9wdWxzZVF1ZXVlKClcblxuICAgICAgICBpZiAoIXBlbmRpbmdJdGVtLnRpbWVkT3V0KSB7XG4gICAgICAgICAgcGVuZGluZ0l0ZW0uY2FsbGJhY2soZXJyLCB1bmRlZmluZWQsIE5PT1ApXG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMubG9nKCduZXcgY2xpZW50IGNvbm5lY3RlZCcpXG5cbiAgICAgICAgcmV0dXJuIHRoaXMuX2FjcXVpcmVDbGllbnQoY2xpZW50LCBwZW5kaW5nSXRlbSwgaWRsZUxpc3RlbmVyLCB0cnVlKVxuICAgICAgfVxuICAgIH0pXG4gIH1cblxuICAvLyBhY3F1aXJlIGEgY2xpZW50IGZvciBhIHBlbmRpbmcgd29yayBpdGVtXG4gIF9hY3F1aXJlQ2xpZW50KGNsaWVudCwgcGVuZGluZ0l0ZW0sIGlkbGVMaXN0ZW5lciwgaXNOZXcpIHtcbiAgICBpZiAoaXNOZXcpIHtcbiAgICAgIHRoaXMuZW1pdCgnY29ubmVjdCcsIGNsaWVudClcbiAgICB9XG5cbiAgICB0aGlzLmVtaXQoJ2FjcXVpcmUnLCBjbGllbnQpXG5cbiAgICBjbGllbnQucmVsZWFzZSA9IHRoaXMuX3JlbGVhc2VPbmNlKGNsaWVudCwgaWRsZUxpc3RlbmVyKVxuXG4gICAgY2xpZW50LnJlbW92ZUxpc3RlbmVyKCdlcnJvcicsIGlkbGVMaXN0ZW5lcilcblxuICAgIGlmICghcGVuZGluZ0l0ZW0udGltZWRPdXQpIHtcbiAgICAgIGlmIChpc05ldyAmJiB0aGlzLm9wdGlvbnMudmVyaWZ5KSB7XG4gICAgICAgIHRoaXMub3B0aW9ucy52ZXJpZnkoY2xpZW50LCAoZXJyKSA9PiB7XG4gICAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgICAgY2xpZW50LnJlbGVhc2UoZXJyKVxuICAgICAgICAgICAgcmV0dXJuIHBlbmRpbmdJdGVtLmNhbGxiYWNrKGVyciwgdW5kZWZpbmVkLCBOT09QKVxuICAgICAgICAgIH1cblxuICAgICAgICAgIHBlbmRpbmdJdGVtLmNhbGxiYWNrKHVuZGVmaW5lZCwgY2xpZW50LCBjbGllbnQucmVsZWFzZSlcbiAgICAgICAgfSlcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHBlbmRpbmdJdGVtLmNhbGxiYWNrKHVuZGVmaW5lZCwgY2xpZW50LCBjbGllbnQucmVsZWFzZSlcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKGlzTmV3ICYmIHRoaXMub3B0aW9ucy52ZXJpZnkpIHtcbiAgICAgICAgdGhpcy5vcHRpb25zLnZlcmlmeShjbGllbnQsIGNsaWVudC5yZWxlYXNlKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY2xpZW50LnJlbGVhc2UoKVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8vIHJldHVybnMgYSBmdW5jdGlvbiB0aGF0IHdyYXBzIF9yZWxlYXNlIGFuZCB0aHJvd3MgaWYgY2FsbGVkIG1vcmUgdGhhbiBvbmNlXG4gIF9yZWxlYXNlT25jZShjbGllbnQsIGlkbGVMaXN0ZW5lcikge1xuICAgIGxldCByZWxlYXNlZCA9IGZhbHNlXG5cbiAgICByZXR1cm4gKGVycikgPT4ge1xuICAgICAgaWYgKHJlbGVhc2VkKSB7XG4gICAgICAgIHRocm93T25Eb3VibGVSZWxlYXNlKClcbiAgICAgIH1cblxuICAgICAgcmVsZWFzZWQgPSB0cnVlXG4gICAgICB0aGlzLl9yZWxlYXNlKGNsaWVudCwgaWRsZUxpc3RlbmVyLCBlcnIpXG4gICAgfVxuICB9XG5cbiAgLy8gcmVsZWFzZSBhIGNsaWVudCBiYWNrIHRvIHRoZSBwb2xsLCBpbmNsdWRlIGFuIGVycm9yXG4gIC8vIHRvIHJlbW92ZSBpdCBmcm9tIHRoZSBwb29sXG4gIF9yZWxlYXNlKGNsaWVudCwgaWRsZUxpc3RlbmVyLCBlcnIpIHtcbiAgICBjbGllbnQub24oJ2Vycm9yJywgaWRsZUxpc3RlbmVyKVxuXG4gICAgY2xpZW50Ll9wb29sVXNlQ291bnQgPSAoY2xpZW50Ll9wb29sVXNlQ291bnQgfHwgMCkgKyAxXG5cbiAgICAvLyBUT0RPKGJtYyk6IGV4cG9zZSBhIHByb3BlciwgcHVibGljIGludGVyZmFjZSBfcXVlcnlhYmxlIGFuZCBfZW5kaW5nXG4gICAgaWYgKGVyciB8fCB0aGlzLmVuZGluZyB8fCAhY2xpZW50Ll9xdWVyeWFibGUgfHwgY2xpZW50Ll9lbmRpbmcgfHwgY2xpZW50Ll9wb29sVXNlQ291bnQgPj0gdGhpcy5vcHRpb25zLm1heFVzZXMpIHtcbiAgICAgIGlmIChjbGllbnQuX3Bvb2xVc2VDb3VudCA+PSB0aGlzLm9wdGlvbnMubWF4VXNlcykge1xuICAgICAgICB0aGlzLmxvZygncmVtb3ZlIGV4cGVuZGVkIGNsaWVudCcpXG4gICAgICB9XG4gICAgICB0aGlzLl9yZW1vdmUoY2xpZW50KVxuICAgICAgdGhpcy5fcHVsc2VRdWV1ZSgpXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICAvLyBpZGxlIHRpbWVvdXRcbiAgICBsZXQgdGlkXG4gICAgaWYgKHRoaXMub3B0aW9ucy5pZGxlVGltZW91dE1pbGxpcykge1xuICAgICAgdGlkID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHRoaXMubG9nKCdyZW1vdmUgaWRsZSBjbGllbnQnKVxuICAgICAgICB0aGlzLl9yZW1vdmUoY2xpZW50KVxuICAgICAgfSwgdGhpcy5vcHRpb25zLmlkbGVUaW1lb3V0TWlsbGlzKVxuXG4gICAgICBpZiAodGhpcy5vcHRpb25zLmFsbG93RXhpdE9uSWRsZSkge1xuICAgICAgICAvLyBhbGxvdyBOb2RlIHRvIGV4aXQgaWYgdGhpcyBpcyBhbGwgdGhhdCdzIGxlZnRcbiAgICAgICAgdGlkLnVucmVmKClcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLmFsbG93RXhpdE9uSWRsZSkge1xuICAgICAgY2xpZW50LnVucmVmKClcbiAgICB9XG5cbiAgICB0aGlzLl9pZGxlLnB1c2gobmV3IElkbGVJdGVtKGNsaWVudCwgaWRsZUxpc3RlbmVyLCB0aWQpKVxuICAgIHRoaXMuX3B1bHNlUXVldWUoKVxuICB9XG5cbiAgcXVlcnkodGV4dCwgdmFsdWVzLCBjYikge1xuICAgIC8vIGd1YXJkIGNsYXVzZSBhZ2FpbnN0IHBhc3NpbmcgYSBmdW5jdGlvbiBhcyB0aGUgZmlyc3QgcGFyYW1ldGVyXG4gICAgaWYgKHR5cGVvZiB0ZXh0ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IHByb21pc2lmeSh0aGlzLlByb21pc2UsIHRleHQpXG4gICAgICBzZXRJbW1lZGlhdGUoZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuY2FsbGJhY2sobmV3IEVycm9yKCdQYXNzaW5nIGEgZnVuY3Rpb24gYXMgdGhlIGZpcnN0IHBhcmFtZXRlciB0byBwb29sLnF1ZXJ5IGlzIG5vdCBzdXBwb3J0ZWQnKSlcbiAgICAgIH0pXG4gICAgICByZXR1cm4gcmVzcG9uc2UucmVzdWx0XG4gICAgfVxuXG4gICAgLy8gYWxsb3cgcGxhaW4gdGV4dCBxdWVyeSB3aXRob3V0IHZhbHVlc1xuICAgIGlmICh0eXBlb2YgdmFsdWVzID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICBjYiA9IHZhbHVlc1xuICAgICAgdmFsdWVzID0gdW5kZWZpbmVkXG4gICAgfVxuICAgIGNvbnN0IHJlc3BvbnNlID0gcHJvbWlzaWZ5KHRoaXMuUHJvbWlzZSwgY2IpXG4gICAgY2IgPSByZXNwb25zZS5jYWxsYmFja1xuXG4gICAgdGhpcy5jb25uZWN0KChlcnIsIGNsaWVudCkgPT4ge1xuICAgICAgaWYgKGVycikge1xuICAgICAgICByZXR1cm4gY2IoZXJyKVxuICAgICAgfVxuXG4gICAgICBsZXQgY2xpZW50UmVsZWFzZWQgPSBmYWxzZVxuICAgICAgY29uc3Qgb25FcnJvciA9IChlcnIpID0+IHtcbiAgICAgICAgaWYgKGNsaWVudFJlbGVhc2VkKSB7XG4gICAgICAgICAgcmV0dXJuXG4gICAgICAgIH1cbiAgICAgICAgY2xpZW50UmVsZWFzZWQgPSB0cnVlXG4gICAgICAgIGNsaWVudC5yZWxlYXNlKGVycilcbiAgICAgICAgY2IoZXJyKVxuICAgICAgfVxuXG4gICAgICBjbGllbnQub25jZSgnZXJyb3InLCBvbkVycm9yKVxuICAgICAgdGhpcy5sb2coJ2Rpc3BhdGNoaW5nIHF1ZXJ5JylcbiAgICAgIGNsaWVudC5xdWVyeSh0ZXh0LCB2YWx1ZXMsIChlcnIsIHJlcykgPT4ge1xuICAgICAgICB0aGlzLmxvZygncXVlcnkgZGlzcGF0Y2hlZCcpXG4gICAgICAgIGNsaWVudC5yZW1vdmVMaXN0ZW5lcignZXJyb3InLCBvbkVycm9yKVxuICAgICAgICBpZiAoY2xpZW50UmVsZWFzZWQpIHtcbiAgICAgICAgICByZXR1cm5cbiAgICAgICAgfVxuICAgICAgICBjbGllbnRSZWxlYXNlZCA9IHRydWVcbiAgICAgICAgY2xpZW50LnJlbGVhc2UoZXJyKVxuICAgICAgICBpZiAoZXJyKSB7XG4gICAgICAgICAgcmV0dXJuIGNiKGVycilcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gY2IodW5kZWZpbmVkLCByZXMpXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfSlcbiAgICByZXR1cm4gcmVzcG9uc2UucmVzdWx0XG4gIH1cblxuICBlbmQoY2IpIHtcbiAgICB0aGlzLmxvZygnZW5kaW5nJylcbiAgICBpZiAodGhpcy5lbmRpbmcpIHtcbiAgICAgIGNvbnN0IGVyciA9IG5ldyBFcnJvcignQ2FsbGVkIGVuZCBvbiBwb29sIG1vcmUgdGhhbiBvbmNlJylcbiAgICAgIHJldHVybiBjYiA/IGNiKGVycikgOiB0aGlzLlByb21pc2UucmVqZWN0KGVycilcbiAgICB9XG4gICAgdGhpcy5lbmRpbmcgPSB0cnVlXG4gICAgY29uc3QgcHJvbWlzZWQgPSBwcm9taXNpZnkodGhpcy5Qcm9taXNlLCBjYilcbiAgICB0aGlzLl9lbmRDYWxsYmFjayA9IHByb21pc2VkLmNhbGxiYWNrXG4gICAgdGhpcy5fcHVsc2VRdWV1ZSgpXG4gICAgcmV0dXJuIHByb21pc2VkLnJlc3VsdFxuICB9XG5cbiAgZ2V0IHdhaXRpbmdDb3VudCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcGVuZGluZ1F1ZXVlLmxlbmd0aFxuICB9XG5cbiAgZ2V0IGlkbGVDb3VudCgpIHtcbiAgICByZXR1cm4gdGhpcy5faWRsZS5sZW5ndGhcbiAgfVxuXG4gIGdldCB0b3RhbENvdW50KCkge1xuICAgIHJldHVybiB0aGlzLl9jbGllbnRzLmxlbmd0aFxuICB9XG59XG5tb2R1bGUuZXhwb3J0cyA9IFBvb2xcbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5CdWZmZXJSZWFkZXIgPSB2b2lkIDA7XG5jb25zdCBlbXB0eUJ1ZmZlciA9IEJ1ZmZlci5hbGxvY1Vuc2FmZSgwKTtcbmNsYXNzIEJ1ZmZlclJlYWRlciB7XG4gICAgY29uc3RydWN0b3Iob2Zmc2V0ID0gMCkge1xuICAgICAgICB0aGlzLm9mZnNldCA9IG9mZnNldDtcbiAgICAgICAgdGhpcy5idWZmZXIgPSBlbXB0eUJ1ZmZlcjtcbiAgICAgICAgLy8gVE9ETyhibWMpOiBzdXBwb3J0IG5vbi11dGY4IGVuY29kaW5nP1xuICAgICAgICB0aGlzLmVuY29kaW5nID0gJ3V0Zi04JztcbiAgICB9XG4gICAgc2V0QnVmZmVyKG9mZnNldCwgYnVmZmVyKSB7XG4gICAgICAgIHRoaXMub2Zmc2V0ID0gb2Zmc2V0O1xuICAgICAgICB0aGlzLmJ1ZmZlciA9IGJ1ZmZlcjtcbiAgICB9XG4gICAgaW50MTYoKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMuYnVmZmVyLnJlYWRJbnQxNkJFKHRoaXMub2Zmc2V0KTtcbiAgICAgICAgdGhpcy5vZmZzZXQgKz0gMjtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgYnl0ZSgpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gdGhpcy5idWZmZXJbdGhpcy5vZmZzZXRdO1xuICAgICAgICB0aGlzLm9mZnNldCsrO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBpbnQzMigpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gdGhpcy5idWZmZXIucmVhZEludDMyQkUodGhpcy5vZmZzZXQpO1xuICAgICAgICB0aGlzLm9mZnNldCArPSA0O1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBzdHJpbmcobGVuZ3RoKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMuYnVmZmVyLnRvU3RyaW5nKHRoaXMuZW5jb2RpbmcsIHRoaXMub2Zmc2V0LCB0aGlzLm9mZnNldCArIGxlbmd0aCk7XG4gICAgICAgIHRoaXMub2Zmc2V0ICs9IGxlbmd0aDtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgY3N0cmluZygpIHtcbiAgICAgICAgY29uc3Qgc3RhcnQgPSB0aGlzLm9mZnNldDtcbiAgICAgICAgbGV0IGVuZCA9IHN0YXJ0O1xuICAgICAgICB3aGlsZSAodGhpcy5idWZmZXJbZW5kKytdICE9PSAwKSB7IH1cbiAgICAgICAgdGhpcy5vZmZzZXQgPSBlbmQ7XG4gICAgICAgIHJldHVybiB0aGlzLmJ1ZmZlci50b1N0cmluZyh0aGlzLmVuY29kaW5nLCBzdGFydCwgZW5kIC0gMSk7XG4gICAgfVxuICAgIGJ5dGVzKGxlbmd0aCkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSB0aGlzLmJ1ZmZlci5zbGljZSh0aGlzLm9mZnNldCwgdGhpcy5vZmZzZXQgKyBsZW5ndGgpO1xuICAgICAgICB0aGlzLm9mZnNldCArPSBsZW5ndGg7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxufVxuZXhwb3J0cy5CdWZmZXJSZWFkZXIgPSBCdWZmZXJSZWFkZXI7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1idWZmZXItcmVhZGVyLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuLy9iaW5hcnkgZGF0YSB3cml0ZXIgdHVuZWQgZm9yIGVuY29kaW5nIGJpbmFyeSBzcGVjaWZpYyB0byB0aGUgcG9zdGdyZXMgYmluYXJ5IHByb3RvY29sXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLldyaXRlciA9IHZvaWQgMDtcbmNsYXNzIFdyaXRlciB7XG4gICAgY29uc3RydWN0b3Ioc2l6ZSA9IDI1Nikge1xuICAgICAgICB0aGlzLnNpemUgPSBzaXplO1xuICAgICAgICB0aGlzLm9mZnNldCA9IDU7XG4gICAgICAgIHRoaXMuaGVhZGVyUG9zaXRpb24gPSAwO1xuICAgICAgICB0aGlzLmJ1ZmZlciA9IEJ1ZmZlci5hbGxvY1Vuc2FmZShzaXplKTtcbiAgICB9XG4gICAgZW5zdXJlKHNpemUpIHtcbiAgICAgICAgdmFyIHJlbWFpbmluZyA9IHRoaXMuYnVmZmVyLmxlbmd0aCAtIHRoaXMub2Zmc2V0O1xuICAgICAgICBpZiAocmVtYWluaW5nIDwgc2l6ZSkge1xuICAgICAgICAgICAgdmFyIG9sZEJ1ZmZlciA9IHRoaXMuYnVmZmVyO1xuICAgICAgICAgICAgLy8gZXhwb25lbnRpYWwgZ3Jvd3RoIGZhY3RvciBvZiBhcm91bmQgfiAxLjVcbiAgICAgICAgICAgIC8vIGh0dHBzOi8vc3RhY2tvdmVyZmxvdy5jb20vcXVlc3Rpb25zLzIyNjkwNjMvYnVmZmVyLWdyb3d0aC1zdHJhdGVneVxuICAgICAgICAgICAgdmFyIG5ld1NpemUgPSBvbGRCdWZmZXIubGVuZ3RoICsgKG9sZEJ1ZmZlci5sZW5ndGggPj4gMSkgKyBzaXplO1xuICAgICAgICAgICAgdGhpcy5idWZmZXIgPSBCdWZmZXIuYWxsb2NVbnNhZmUobmV3U2l6ZSk7XG4gICAgICAgICAgICBvbGRCdWZmZXIuY29weSh0aGlzLmJ1ZmZlcik7XG4gICAgICAgIH1cbiAgICB9XG4gICAgYWRkSW50MzIobnVtKSB7XG4gICAgICAgIHRoaXMuZW5zdXJlKDQpO1xuICAgICAgICB0aGlzLmJ1ZmZlclt0aGlzLm9mZnNldCsrXSA9IChudW0gPj4+IDI0KSAmIDB4ZmY7XG4gICAgICAgIHRoaXMuYnVmZmVyW3RoaXMub2Zmc2V0KytdID0gKG51bSA+Pj4gMTYpICYgMHhmZjtcbiAgICAgICAgdGhpcy5idWZmZXJbdGhpcy5vZmZzZXQrK10gPSAobnVtID4+PiA4KSAmIDB4ZmY7XG4gICAgICAgIHRoaXMuYnVmZmVyW3RoaXMub2Zmc2V0KytdID0gKG51bSA+Pj4gMCkgJiAweGZmO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgYWRkSW50MTYobnVtKSB7XG4gICAgICAgIHRoaXMuZW5zdXJlKDIpO1xuICAgICAgICB0aGlzLmJ1ZmZlclt0aGlzLm9mZnNldCsrXSA9IChudW0gPj4+IDgpICYgMHhmZjtcbiAgICAgICAgdGhpcy5idWZmZXJbdGhpcy5vZmZzZXQrK10gPSAobnVtID4+PiAwKSAmIDB4ZmY7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBhZGRDU3RyaW5nKHN0cmluZykge1xuICAgICAgICBpZiAoIXN0cmluZykge1xuICAgICAgICAgICAgdGhpcy5lbnN1cmUoMSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB2YXIgbGVuID0gQnVmZmVyLmJ5dGVMZW5ndGgoc3RyaW5nKTtcbiAgICAgICAgICAgIHRoaXMuZW5zdXJlKGxlbiArIDEpOyAvLyArMSBmb3IgbnVsbCB0ZXJtaW5hdG9yXG4gICAgICAgICAgICB0aGlzLmJ1ZmZlci53cml0ZShzdHJpbmcsIHRoaXMub2Zmc2V0LCAndXRmLTgnKTtcbiAgICAgICAgICAgIHRoaXMub2Zmc2V0ICs9IGxlbjtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmJ1ZmZlclt0aGlzLm9mZnNldCsrXSA9IDA7IC8vIG51bGwgdGVybWluYXRvclxuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgYWRkU3RyaW5nKHN0cmluZyA9ICcnKSB7XG4gICAgICAgIHZhciBsZW4gPSBCdWZmZXIuYnl0ZUxlbmd0aChzdHJpbmcpO1xuICAgICAgICB0aGlzLmVuc3VyZShsZW4pO1xuICAgICAgICB0aGlzLmJ1ZmZlci53cml0ZShzdHJpbmcsIHRoaXMub2Zmc2V0KTtcbiAgICAgICAgdGhpcy5vZmZzZXQgKz0gbGVuO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgYWRkKG90aGVyQnVmZmVyKSB7XG4gICAgICAgIHRoaXMuZW5zdXJlKG90aGVyQnVmZmVyLmxlbmd0aCk7XG4gICAgICAgIG90aGVyQnVmZmVyLmNvcHkodGhpcy5idWZmZXIsIHRoaXMub2Zmc2V0KTtcbiAgICAgICAgdGhpcy5vZmZzZXQgKz0gb3RoZXJCdWZmZXIubGVuZ3RoO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgam9pbihjb2RlKSB7XG4gICAgICAgIGlmIChjb2RlKSB7XG4gICAgICAgICAgICB0aGlzLmJ1ZmZlclt0aGlzLmhlYWRlclBvc2l0aW9uXSA9IGNvZGU7XG4gICAgICAgICAgICAvL2xlbmd0aCBpcyBldmVyeXRoaW5nIGluIHRoaXMgcGFja2V0IG1pbnVzIHRoZSBjb2RlXG4gICAgICAgICAgICBjb25zdCBsZW5ndGggPSB0aGlzLm9mZnNldCAtICh0aGlzLmhlYWRlclBvc2l0aW9uICsgMSk7XG4gICAgICAgICAgICB0aGlzLmJ1ZmZlci53cml0ZUludDMyQkUobGVuZ3RoLCB0aGlzLmhlYWRlclBvc2l0aW9uICsgMSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuYnVmZmVyLnNsaWNlKGNvZGUgPyAwIDogNSwgdGhpcy5vZmZzZXQpO1xuICAgIH1cbiAgICBmbHVzaChjb2RlKSB7XG4gICAgICAgIHZhciByZXN1bHQgPSB0aGlzLmpvaW4oY29kZSk7XG4gICAgICAgIHRoaXMub2Zmc2V0ID0gNTtcbiAgICAgICAgdGhpcy5oZWFkZXJQb3NpdGlvbiA9IDA7XG4gICAgICAgIHRoaXMuYnVmZmVyID0gQnVmZmVyLmFsbG9jVW5zYWZlKHRoaXMuc2l6ZSk7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxufVxuZXhwb3J0cy5Xcml0ZXIgPSBXcml0ZXI7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1idWZmZXItd3JpdGVyLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5EYXRhYmFzZUVycm9yID0gZXhwb3J0cy5zZXJpYWxpemUgPSBleHBvcnRzLnBhcnNlID0gdm9pZCAwO1xuY29uc3QgbWVzc2FnZXNfMSA9IHJlcXVpcmUoXCIuL21lc3NhZ2VzXCIpO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiRGF0YWJhc2VFcnJvclwiLCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZnVuY3Rpb24gKCkgeyByZXR1cm4gbWVzc2FnZXNfMS5EYXRhYmFzZUVycm9yOyB9IH0pO1xuY29uc3Qgc2VyaWFsaXplcl8xID0gcmVxdWlyZShcIi4vc2VyaWFsaXplclwiKTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcInNlcmlhbGl6ZVwiLCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZnVuY3Rpb24gKCkgeyByZXR1cm4gc2VyaWFsaXplcl8xLnNlcmlhbGl6ZTsgfSB9KTtcbmNvbnN0IHBhcnNlcl8xID0gcmVxdWlyZShcIi4vcGFyc2VyXCIpO1xuZnVuY3Rpb24gcGFyc2Uoc3RyZWFtLCBjYWxsYmFjaykge1xuICAgIGNvbnN0IHBhcnNlciA9IG5ldyBwYXJzZXJfMS5QYXJzZXIoKTtcbiAgICBzdHJlYW0ub24oJ2RhdGEnLCAoYnVmZmVyKSA9PiBwYXJzZXIucGFyc2UoYnVmZmVyLCBjYWxsYmFjaykpO1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4gc3RyZWFtLm9uKCdlbmQnLCAoKSA9PiByZXNvbHZlKCkpKTtcbn1cbmV4cG9ydHMucGFyc2UgPSBwYXJzZTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5Ob3RpY2VNZXNzYWdlID0gZXhwb3J0cy5EYXRhUm93TWVzc2FnZSA9IGV4cG9ydHMuQ29tbWFuZENvbXBsZXRlTWVzc2FnZSA9IGV4cG9ydHMuUmVhZHlGb3JRdWVyeU1lc3NhZ2UgPSBleHBvcnRzLk5vdGlmaWNhdGlvblJlc3BvbnNlTWVzc2FnZSA9IGV4cG9ydHMuQmFja2VuZEtleURhdGFNZXNzYWdlID0gZXhwb3J0cy5BdXRoZW50aWNhdGlvbk1ENVBhc3N3b3JkID0gZXhwb3J0cy5QYXJhbWV0ZXJTdGF0dXNNZXNzYWdlID0gZXhwb3J0cy5QYXJhbWV0ZXJEZXNjcmlwdGlvbk1lc3NhZ2UgPSBleHBvcnRzLlJvd0Rlc2NyaXB0aW9uTWVzc2FnZSA9IGV4cG9ydHMuRmllbGQgPSBleHBvcnRzLkNvcHlSZXNwb25zZSA9IGV4cG9ydHMuQ29weURhdGFNZXNzYWdlID0gZXhwb3J0cy5EYXRhYmFzZUVycm9yID0gZXhwb3J0cy5jb3B5RG9uZSA9IGV4cG9ydHMuZW1wdHlRdWVyeSA9IGV4cG9ydHMucmVwbGljYXRpb25TdGFydCA9IGV4cG9ydHMucG9ydGFsU3VzcGVuZGVkID0gZXhwb3J0cy5ub0RhdGEgPSBleHBvcnRzLmNsb3NlQ29tcGxldGUgPSBleHBvcnRzLmJpbmRDb21wbGV0ZSA9IGV4cG9ydHMucGFyc2VDb21wbGV0ZSA9IHZvaWQgMDtcbmV4cG9ydHMucGFyc2VDb21wbGV0ZSA9IHtcbiAgICBuYW1lOiAncGFyc2VDb21wbGV0ZScsXG4gICAgbGVuZ3RoOiA1LFxufTtcbmV4cG9ydHMuYmluZENvbXBsZXRlID0ge1xuICAgIG5hbWU6ICdiaW5kQ29tcGxldGUnLFxuICAgIGxlbmd0aDogNSxcbn07XG5leHBvcnRzLmNsb3NlQ29tcGxldGUgPSB7XG4gICAgbmFtZTogJ2Nsb3NlQ29tcGxldGUnLFxuICAgIGxlbmd0aDogNSxcbn07XG5leHBvcnRzLm5vRGF0YSA9IHtcbiAgICBuYW1lOiAnbm9EYXRhJyxcbiAgICBsZW5ndGg6IDUsXG59O1xuZXhwb3J0cy5wb3J0YWxTdXNwZW5kZWQgPSB7XG4gICAgbmFtZTogJ3BvcnRhbFN1c3BlbmRlZCcsXG4gICAgbGVuZ3RoOiA1LFxufTtcbmV4cG9ydHMucmVwbGljYXRpb25TdGFydCA9IHtcbiAgICBuYW1lOiAncmVwbGljYXRpb25TdGFydCcsXG4gICAgbGVuZ3RoOiA0LFxufTtcbmV4cG9ydHMuZW1wdHlRdWVyeSA9IHtcbiAgICBuYW1lOiAnZW1wdHlRdWVyeScsXG4gICAgbGVuZ3RoOiA0LFxufTtcbmV4cG9ydHMuY29weURvbmUgPSB7XG4gICAgbmFtZTogJ2NvcHlEb25lJyxcbiAgICBsZW5ndGg6IDQsXG59O1xuY2xhc3MgRGF0YWJhc2VFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcihtZXNzYWdlLCBsZW5ndGgsIG5hbWUpIHtcbiAgICAgICAgc3VwZXIobWVzc2FnZSk7XG4gICAgICAgIHRoaXMubGVuZ3RoID0gbGVuZ3RoO1xuICAgICAgICB0aGlzLm5hbWUgPSBuYW1lO1xuICAgIH1cbn1cbmV4cG9ydHMuRGF0YWJhc2VFcnJvciA9IERhdGFiYXNlRXJyb3I7XG5jbGFzcyBDb3B5RGF0YU1lc3NhZ2Uge1xuICAgIGNvbnN0cnVjdG9yKGxlbmd0aCwgY2h1bmspIHtcbiAgICAgICAgdGhpcy5sZW5ndGggPSBsZW5ndGg7XG4gICAgICAgIHRoaXMuY2h1bmsgPSBjaHVuaztcbiAgICAgICAgdGhpcy5uYW1lID0gJ2NvcHlEYXRhJztcbiAgICB9XG59XG5leHBvcnRzLkNvcHlEYXRhTWVzc2FnZSA9IENvcHlEYXRhTWVzc2FnZTtcbmNsYXNzIENvcHlSZXNwb25zZSB7XG4gICAgY29uc3RydWN0b3IobGVuZ3RoLCBuYW1lLCBiaW5hcnksIGNvbHVtbkNvdW50KSB7XG4gICAgICAgIHRoaXMubGVuZ3RoID0gbGVuZ3RoO1xuICAgICAgICB0aGlzLm5hbWUgPSBuYW1lO1xuICAgICAgICB0aGlzLmJpbmFyeSA9IGJpbmFyeTtcbiAgICAgICAgdGhpcy5jb2x1bW5UeXBlcyA9IG5ldyBBcnJheShjb2x1bW5Db3VudCk7XG4gICAgfVxufVxuZXhwb3J0cy5Db3B5UmVzcG9uc2UgPSBDb3B5UmVzcG9uc2U7XG5jbGFzcyBGaWVsZCB7XG4gICAgY29uc3RydWN0b3IobmFtZSwgdGFibGVJRCwgY29sdW1uSUQsIGRhdGFUeXBlSUQsIGRhdGFUeXBlU2l6ZSwgZGF0YVR5cGVNb2RpZmllciwgZm9ybWF0KSB7XG4gICAgICAgIHRoaXMubmFtZSA9IG5hbWU7XG4gICAgICAgIHRoaXMudGFibGVJRCA9IHRhYmxlSUQ7XG4gICAgICAgIHRoaXMuY29sdW1uSUQgPSBjb2x1bW5JRDtcbiAgICAgICAgdGhpcy5kYXRhVHlwZUlEID0gZGF0YVR5cGVJRDtcbiAgICAgICAgdGhpcy5kYXRhVHlwZVNpemUgPSBkYXRhVHlwZVNpemU7XG4gICAgICAgIHRoaXMuZGF0YVR5cGVNb2RpZmllciA9IGRhdGFUeXBlTW9kaWZpZXI7XG4gICAgICAgIHRoaXMuZm9ybWF0ID0gZm9ybWF0O1xuICAgIH1cbn1cbmV4cG9ydHMuRmllbGQgPSBGaWVsZDtcbmNsYXNzIFJvd0Rlc2NyaXB0aW9uTWVzc2FnZSB7XG4gICAgY29uc3RydWN0b3IobGVuZ3RoLCBmaWVsZENvdW50KSB7XG4gICAgICAgIHRoaXMubGVuZ3RoID0gbGVuZ3RoO1xuICAgICAgICB0aGlzLmZpZWxkQ291bnQgPSBmaWVsZENvdW50O1xuICAgICAgICB0aGlzLm5hbWUgPSAncm93RGVzY3JpcHRpb24nO1xuICAgICAgICB0aGlzLmZpZWxkcyA9IG5ldyBBcnJheSh0aGlzLmZpZWxkQ291bnQpO1xuICAgIH1cbn1cbmV4cG9ydHMuUm93RGVzY3JpcHRpb25NZXNzYWdlID0gUm93RGVzY3JpcHRpb25NZXNzYWdlO1xuY2xhc3MgUGFyYW1ldGVyRGVzY3JpcHRpb25NZXNzYWdlIHtcbiAgICBjb25zdHJ1Y3RvcihsZW5ndGgsIHBhcmFtZXRlckNvdW50KSB7XG4gICAgICAgIHRoaXMubGVuZ3RoID0gbGVuZ3RoO1xuICAgICAgICB0aGlzLnBhcmFtZXRlckNvdW50ID0gcGFyYW1ldGVyQ291bnQ7XG4gICAgICAgIHRoaXMubmFtZSA9ICdwYXJhbWV0ZXJEZXNjcmlwdGlvbic7XG4gICAgICAgIHRoaXMuZGF0YVR5cGVJRHMgPSBuZXcgQXJyYXkodGhpcy5wYXJhbWV0ZXJDb3VudCk7XG4gICAgfVxufVxuZXhwb3J0cy5QYXJhbWV0ZXJEZXNjcmlwdGlvbk1lc3NhZ2UgPSBQYXJhbWV0ZXJEZXNjcmlwdGlvbk1lc3NhZ2U7XG5jbGFzcyBQYXJhbWV0ZXJTdGF0dXNNZXNzYWdlIHtcbiAgICBjb25zdHJ1Y3RvcihsZW5ndGgsIHBhcmFtZXRlck5hbWUsIHBhcmFtZXRlclZhbHVlKSB7XG4gICAgICAgIHRoaXMubGVuZ3RoID0gbGVuZ3RoO1xuICAgICAgICB0aGlzLnBhcmFtZXRlck5hbWUgPSBwYXJhbWV0ZXJOYW1lO1xuICAgICAgICB0aGlzLnBhcmFtZXRlclZhbHVlID0gcGFyYW1ldGVyVmFsdWU7XG4gICAgICAgIHRoaXMubmFtZSA9ICdwYXJhbWV0ZXJTdGF0dXMnO1xuICAgIH1cbn1cbmV4cG9ydHMuUGFyYW1ldGVyU3RhdHVzTWVzc2FnZSA9IFBhcmFtZXRlclN0YXR1c01lc3NhZ2U7XG5jbGFzcyBBdXRoZW50aWNhdGlvbk1ENVBhc3N3b3JkIHtcbiAgICBjb25zdHJ1Y3RvcihsZW5ndGgsIHNhbHQpIHtcbiAgICAgICAgdGhpcy5sZW5ndGggPSBsZW5ndGg7XG4gICAgICAgIHRoaXMuc2FsdCA9IHNhbHQ7XG4gICAgICAgIHRoaXMubmFtZSA9ICdhdXRoZW50aWNhdGlvbk1ENVBhc3N3b3JkJztcbiAgICB9XG59XG5leHBvcnRzLkF1dGhlbnRpY2F0aW9uTUQ1UGFzc3dvcmQgPSBBdXRoZW50aWNhdGlvbk1ENVBhc3N3b3JkO1xuY2xhc3MgQmFja2VuZEtleURhdGFNZXNzYWdlIHtcbiAgICBjb25zdHJ1Y3RvcihsZW5ndGgsIHByb2Nlc3NJRCwgc2VjcmV0S2V5KSB7XG4gICAgICAgIHRoaXMubGVuZ3RoID0gbGVuZ3RoO1xuICAgICAgICB0aGlzLnByb2Nlc3NJRCA9IHByb2Nlc3NJRDtcbiAgICAgICAgdGhpcy5zZWNyZXRLZXkgPSBzZWNyZXRLZXk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdiYWNrZW5kS2V5RGF0YSc7XG4gICAgfVxufVxuZXhwb3J0cy5CYWNrZW5kS2V5RGF0YU1lc3NhZ2UgPSBCYWNrZW5kS2V5RGF0YU1lc3NhZ2U7XG5jbGFzcyBOb3RpZmljYXRpb25SZXNwb25zZU1lc3NhZ2Uge1xuICAgIGNvbnN0cnVjdG9yKGxlbmd0aCwgcHJvY2Vzc0lkLCBjaGFubmVsLCBwYXlsb2FkKSB7XG4gICAgICAgIHRoaXMubGVuZ3RoID0gbGVuZ3RoO1xuICAgICAgICB0aGlzLnByb2Nlc3NJZCA9IHByb2Nlc3NJZDtcbiAgICAgICAgdGhpcy5jaGFubmVsID0gY2hhbm5lbDtcbiAgICAgICAgdGhpcy5wYXlsb2FkID0gcGF5bG9hZDtcbiAgICAgICAgdGhpcy5uYW1lID0gJ25vdGlmaWNhdGlvbic7XG4gICAgfVxufVxuZXhwb3J0cy5Ob3RpZmljYXRpb25SZXNwb25zZU1lc3NhZ2UgPSBOb3RpZmljYXRpb25SZXNwb25zZU1lc3NhZ2U7XG5jbGFzcyBSZWFkeUZvclF1ZXJ5TWVzc2FnZSB7XG4gICAgY29uc3RydWN0b3IobGVuZ3RoLCBzdGF0dXMpIHtcbiAgICAgICAgdGhpcy5sZW5ndGggPSBsZW5ndGg7XG4gICAgICAgIHRoaXMuc3RhdHVzID0gc3RhdHVzO1xuICAgICAgICB0aGlzLm5hbWUgPSAncmVhZHlGb3JRdWVyeSc7XG4gICAgfVxufVxuZXhwb3J0cy5SZWFkeUZvclF1ZXJ5TWVzc2FnZSA9IFJlYWR5Rm9yUXVlcnlNZXNzYWdlO1xuY2xhc3MgQ29tbWFuZENvbXBsZXRlTWVzc2FnZSB7XG4gICAgY29uc3RydWN0b3IobGVuZ3RoLCB0ZXh0KSB7XG4gICAgICAgIHRoaXMubGVuZ3RoID0gbGVuZ3RoO1xuICAgICAgICB0aGlzLnRleHQgPSB0ZXh0O1xuICAgICAgICB0aGlzLm5hbWUgPSAnY29tbWFuZENvbXBsZXRlJztcbiAgICB9XG59XG5leHBvcnRzLkNvbW1hbmRDb21wbGV0ZU1lc3NhZ2UgPSBDb21tYW5kQ29tcGxldGVNZXNzYWdlO1xuY2xhc3MgRGF0YVJvd01lc3NhZ2Uge1xuICAgIGNvbnN0cnVjdG9yKGxlbmd0aCwgZmllbGRzKSB7XG4gICAgICAgIHRoaXMubGVuZ3RoID0gbGVuZ3RoO1xuICAgICAgICB0aGlzLmZpZWxkcyA9IGZpZWxkcztcbiAgICAgICAgdGhpcy5uYW1lID0gJ2RhdGFSb3cnO1xuICAgICAgICB0aGlzLmZpZWxkQ291bnQgPSBmaWVsZHMubGVuZ3RoO1xuICAgIH1cbn1cbmV4cG9ydHMuRGF0YVJvd01lc3NhZ2UgPSBEYXRhUm93TWVzc2FnZTtcbmNsYXNzIE5vdGljZU1lc3NhZ2Uge1xuICAgIGNvbnN0cnVjdG9yKGxlbmd0aCwgbWVzc2FnZSkge1xuICAgICAgICB0aGlzLmxlbmd0aCA9IGxlbmd0aDtcbiAgICAgICAgdGhpcy5tZXNzYWdlID0gbWVzc2FnZTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ25vdGljZSc7XG4gICAgfVxufVxuZXhwb3J0cy5Ob3RpY2VNZXNzYWdlID0gTm90aWNlTWVzc2FnZTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW1lc3NhZ2VzLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xudmFyIF9faW1wb3J0RGVmYXVsdCA9ICh0aGlzICYmIHRoaXMuX19pbXBvcnREZWZhdWx0KSB8fCBmdW5jdGlvbiAobW9kKSB7XG4gICAgcmV0dXJuIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpID8gbW9kIDogeyBcImRlZmF1bHRcIjogbW9kIH07XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5QYXJzZXIgPSB2b2lkIDA7XG5jb25zdCBtZXNzYWdlc18xID0gcmVxdWlyZShcIi4vbWVzc2FnZXNcIik7XG5jb25zdCBidWZmZXJfcmVhZGVyXzEgPSByZXF1aXJlKFwiLi9idWZmZXItcmVhZGVyXCIpO1xuY29uc3QgYXNzZXJ0XzEgPSBfX2ltcG9ydERlZmF1bHQocmVxdWlyZShcImFzc2VydFwiKSk7XG4vLyBldmVyeSBtZXNzYWdlIGlzIHByZWZpeGVkIHdpdGggYSBzaW5nbGUgYnllXG5jb25zdCBDT0RFX0xFTkdUSCA9IDE7XG4vLyBldmVyeSBtZXNzYWdlIGhhcyBhbiBpbnQzMiBsZW5ndGggd2hpY2ggaW5jbHVkZXMgaXRzZWxmIGJ1dCBkb2VzXG4vLyBOT1QgaW5jbHVkZSB0aGUgY29kZSBpbiB0aGUgbGVuZ3RoXG5jb25zdCBMRU5fTEVOR1RIID0gNDtcbmNvbnN0IEhFQURFUl9MRU5HVEggPSBDT0RFX0xFTkdUSCArIExFTl9MRU5HVEg7XG5jb25zdCBlbXB0eUJ1ZmZlciA9IEJ1ZmZlci5hbGxvY1Vuc2FmZSgwKTtcbmNsYXNzIFBhcnNlciB7XG4gICAgY29uc3RydWN0b3Iob3B0cykge1xuICAgICAgICB0aGlzLmJ1ZmZlciA9IGVtcHR5QnVmZmVyO1xuICAgICAgICB0aGlzLmJ1ZmZlckxlbmd0aCA9IDA7XG4gICAgICAgIHRoaXMuYnVmZmVyT2Zmc2V0ID0gMDtcbiAgICAgICAgdGhpcy5yZWFkZXIgPSBuZXcgYnVmZmVyX3JlYWRlcl8xLkJ1ZmZlclJlYWRlcigpO1xuICAgICAgICBpZiAoKG9wdHMgPT09IG51bGwgfHwgb3B0cyA9PT0gdm9pZCAwID8gdm9pZCAwIDogb3B0cy5tb2RlKSA9PT0gJ2JpbmFyeScpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQmluYXJ5IG1vZGUgbm90IHN1cHBvcnRlZCB5ZXQnKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLm1vZGUgPSAob3B0cyA9PT0gbnVsbCB8fCBvcHRzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBvcHRzLm1vZGUpIHx8ICd0ZXh0JztcbiAgICB9XG4gICAgcGFyc2UoYnVmZmVyLCBjYWxsYmFjaykge1xuICAgICAgICB0aGlzLm1lcmdlQnVmZmVyKGJ1ZmZlcik7XG4gICAgICAgIGNvbnN0IGJ1ZmZlckZ1bGxMZW5ndGggPSB0aGlzLmJ1ZmZlck9mZnNldCArIHRoaXMuYnVmZmVyTGVuZ3RoO1xuICAgICAgICBsZXQgb2Zmc2V0ID0gdGhpcy5idWZmZXJPZmZzZXQ7XG4gICAgICAgIHdoaWxlIChvZmZzZXQgKyBIRUFERVJfTEVOR1RIIDw9IGJ1ZmZlckZ1bGxMZW5ndGgpIHtcbiAgICAgICAgICAgIC8vIGNvZGUgaXMgMSBieXRlIGxvbmcgLSBpdCBpZGVudGlmaWVzIHRoZSBtZXNzYWdlIHR5cGVcbiAgICAgICAgICAgIGNvbnN0IGNvZGUgPSB0aGlzLmJ1ZmZlcltvZmZzZXRdO1xuICAgICAgICAgICAgLy8gbGVuZ3RoIGlzIDEgVWludDMyQkUgLSBpdCBpcyB0aGUgbGVuZ3RoIG9mIHRoZSBtZXNzYWdlIEVYQ0xVRElORyB0aGUgY29kZVxuICAgICAgICAgICAgY29uc3QgbGVuZ3RoID0gdGhpcy5idWZmZXIucmVhZFVJbnQzMkJFKG9mZnNldCArIENPREVfTEVOR1RIKTtcbiAgICAgICAgICAgIGNvbnN0IGZ1bGxNZXNzYWdlTGVuZ3RoID0gQ09ERV9MRU5HVEggKyBsZW5ndGg7XG4gICAgICAgICAgICBpZiAoZnVsbE1lc3NhZ2VMZW5ndGggKyBvZmZzZXQgPD0gYnVmZmVyRnVsbExlbmd0aCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IG1lc3NhZ2UgPSB0aGlzLmhhbmRsZVBhY2tldChvZmZzZXQgKyBIRUFERVJfTEVOR1RILCBjb2RlLCBsZW5ndGgsIHRoaXMuYnVmZmVyKTtcbiAgICAgICAgICAgICAgICBjYWxsYmFjayhtZXNzYWdlKTtcbiAgICAgICAgICAgICAgICBvZmZzZXQgKz0gZnVsbE1lc3NhZ2VMZW5ndGg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAob2Zmc2V0ID09PSBidWZmZXJGdWxsTGVuZ3RoKSB7XG4gICAgICAgICAgICAvLyBObyBtb3JlIHVzZSBmb3IgdGhlIGJ1ZmZlclxuICAgICAgICAgICAgdGhpcy5idWZmZXIgPSBlbXB0eUJ1ZmZlcjtcbiAgICAgICAgICAgIHRoaXMuYnVmZmVyTGVuZ3RoID0gMDtcbiAgICAgICAgICAgIHRoaXMuYnVmZmVyT2Zmc2V0ID0gMDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIC8vIEFkanVzdCB0aGUgY3Vyc29ycyBvZiByZW1haW5pbmdCdWZmZXJcbiAgICAgICAgICAgIHRoaXMuYnVmZmVyTGVuZ3RoID0gYnVmZmVyRnVsbExlbmd0aCAtIG9mZnNldDtcbiAgICAgICAgICAgIHRoaXMuYnVmZmVyT2Zmc2V0ID0gb2Zmc2V0O1xuICAgICAgICB9XG4gICAgfVxuICAgIG1lcmdlQnVmZmVyKGJ1ZmZlcikge1xuICAgICAgICBpZiAodGhpcy5idWZmZXJMZW5ndGggPiAwKSB7XG4gICAgICAgICAgICBjb25zdCBuZXdMZW5ndGggPSB0aGlzLmJ1ZmZlckxlbmd0aCArIGJ1ZmZlci5ieXRlTGVuZ3RoO1xuICAgICAgICAgICAgY29uc3QgbmV3RnVsbExlbmd0aCA9IG5ld0xlbmd0aCArIHRoaXMuYnVmZmVyT2Zmc2V0O1xuICAgICAgICAgICAgaWYgKG5ld0Z1bGxMZW5ndGggPiB0aGlzLmJ1ZmZlci5ieXRlTGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgLy8gV2UgY2FuJ3QgY29uY2F0IHRoZSBuZXcgYnVmZmVyIHdpdGggdGhlIHJlbWFpbmluZyBvbmVcbiAgICAgICAgICAgICAgICBsZXQgbmV3QnVmZmVyO1xuICAgICAgICAgICAgICAgIGlmIChuZXdMZW5ndGggPD0gdGhpcy5idWZmZXIuYnl0ZUxlbmd0aCAmJiB0aGlzLmJ1ZmZlck9mZnNldCA+PSB0aGlzLmJ1ZmZlckxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgICAvLyBXZSBjYW4gbW92ZSB0aGUgcmVsZXZhbnQgcGFydCB0byB0aGUgYmVnaW5uaW5nIG9mIHRoZSBidWZmZXIgaW5zdGVhZCBvZiBhbGxvY2F0aW5nIGEgbmV3IGJ1ZmZlclxuICAgICAgICAgICAgICAgICAgICBuZXdCdWZmZXIgPSB0aGlzLmJ1ZmZlcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIEFsbG9jYXRlIGEgbmV3IGxhcmdlciBidWZmZXJcbiAgICAgICAgICAgICAgICAgICAgbGV0IG5ld0J1ZmZlckxlbmd0aCA9IHRoaXMuYnVmZmVyLmJ5dGVMZW5ndGggKiAyO1xuICAgICAgICAgICAgICAgICAgICB3aGlsZSAobmV3TGVuZ3RoID49IG5ld0J1ZmZlckxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmV3QnVmZmVyTGVuZ3RoICo9IDI7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgbmV3QnVmZmVyID0gQnVmZmVyLmFsbG9jVW5zYWZlKG5ld0J1ZmZlckxlbmd0aCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vIE1vdmUgdGhlIHJlbWFpbmluZyBidWZmZXIgdG8gdGhlIG5ldyBvbmVcbiAgICAgICAgICAgICAgICB0aGlzLmJ1ZmZlci5jb3B5KG5ld0J1ZmZlciwgMCwgdGhpcy5idWZmZXJPZmZzZXQsIHRoaXMuYnVmZmVyT2Zmc2V0ICsgdGhpcy5idWZmZXJMZW5ndGgpO1xuICAgICAgICAgICAgICAgIHRoaXMuYnVmZmVyID0gbmV3QnVmZmVyO1xuICAgICAgICAgICAgICAgIHRoaXMuYnVmZmVyT2Zmc2V0ID0gMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIENvbmNhdCB0aGUgbmV3IGJ1ZmZlciB3aXRoIHRoZSByZW1haW5pbmcgb25lXG4gICAgICAgICAgICBidWZmZXIuY29weSh0aGlzLmJ1ZmZlciwgdGhpcy5idWZmZXJPZmZzZXQgKyB0aGlzLmJ1ZmZlckxlbmd0aCk7XG4gICAgICAgICAgICB0aGlzLmJ1ZmZlckxlbmd0aCA9IG5ld0xlbmd0aDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuYnVmZmVyID0gYnVmZmVyO1xuICAgICAgICAgICAgdGhpcy5idWZmZXJPZmZzZXQgPSAwO1xuICAgICAgICAgICAgdGhpcy5idWZmZXJMZW5ndGggPSBidWZmZXIuYnl0ZUxlbmd0aDtcbiAgICAgICAgfVxuICAgIH1cbiAgICBoYW5kbGVQYWNrZXQob2Zmc2V0LCBjb2RlLCBsZW5ndGgsIGJ5dGVzKSB7XG4gICAgICAgIHN3aXRjaCAoY29kZSkge1xuICAgICAgICAgICAgY2FzZSA1MCAvKiBCaW5kQ29tcGxldGUgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2VzXzEuYmluZENvbXBsZXRlO1xuICAgICAgICAgICAgY2FzZSA0OSAvKiBQYXJzZUNvbXBsZXRlICovOlxuICAgICAgICAgICAgICAgIHJldHVybiBtZXNzYWdlc18xLnBhcnNlQ29tcGxldGU7XG4gICAgICAgICAgICBjYXNlIDUxIC8qIENsb3NlQ29tcGxldGUgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2VzXzEuY2xvc2VDb21wbGV0ZTtcbiAgICAgICAgICAgIGNhc2UgMTEwIC8qIE5vRGF0YSAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gbWVzc2FnZXNfMS5ub0RhdGE7XG4gICAgICAgICAgICBjYXNlIDExNSAvKiBQb3J0YWxTdXNwZW5kZWQgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2VzXzEucG9ydGFsU3VzcGVuZGVkO1xuICAgICAgICAgICAgY2FzZSA5OSAvKiBDb3B5RG9uZSAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gbWVzc2FnZXNfMS5jb3B5RG9uZTtcbiAgICAgICAgICAgIGNhc2UgODcgLyogUmVwbGljYXRpb25TdGFydCAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gbWVzc2FnZXNfMS5yZXBsaWNhdGlvblN0YXJ0O1xuICAgICAgICAgICAgY2FzZSA3MyAvKiBFbXB0eVF1ZXJ5ICovOlxuICAgICAgICAgICAgICAgIHJldHVybiBtZXNzYWdlc18xLmVtcHR5UXVlcnk7XG4gICAgICAgICAgICBjYXNlIDY4IC8qIERhdGFSb3cgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VEYXRhUm93TWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpO1xuICAgICAgICAgICAgY2FzZSA2NyAvKiBDb21tYW5kQ29tcGxldGUgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VDb21tYW5kQ29tcGxldGVNZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcyk7XG4gICAgICAgICAgICBjYXNlIDkwIC8qIFJlYWR5Rm9yUXVlcnkgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VSZWFkeUZvclF1ZXJ5TWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpO1xuICAgICAgICAgICAgY2FzZSA2NSAvKiBOb3RpZmljYXRpb25SZXNwb25zZSAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZU5vdGlmaWNhdGlvbk1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKTtcbiAgICAgICAgICAgIGNhc2UgODIgLyogQXV0aGVudGljYXRpb25SZXNwb25zZSAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZUF1dGhlbnRpY2F0aW9uUmVzcG9uc2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKTtcbiAgICAgICAgICAgIGNhc2UgODMgLyogUGFyYW1ldGVyU3RhdHVzICovOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlUGFyYW1ldGVyU3RhdHVzTWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpO1xuICAgICAgICAgICAgY2FzZSA3NSAvKiBCYWNrZW5kS2V5RGF0YSAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZUJhY2tlbmRLZXlEYXRhKG9mZnNldCwgbGVuZ3RoLCBieXRlcyk7XG4gICAgICAgICAgICBjYXNlIDY5IC8qIEVycm9yTWVzc2FnZSAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZUVycm9yTWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMsICdlcnJvcicpO1xuICAgICAgICAgICAgY2FzZSA3OCAvKiBOb3RpY2VNZXNzYWdlICovOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlRXJyb3JNZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcywgJ25vdGljZScpO1xuICAgICAgICAgICAgY2FzZSA4NCAvKiBSb3dEZXNjcmlwdGlvbk1lc3NhZ2UgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VSb3dEZXNjcmlwdGlvbk1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKTtcbiAgICAgICAgICAgIGNhc2UgMTE2IC8qIFBhcmFtZXRlckRlc2NyaXB0aW9uTWVzc2FnZSAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZVBhcmFtZXRlckRlc2NyaXB0aW9uTWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpO1xuICAgICAgICAgICAgY2FzZSA3MSAvKiBDb3B5SW4gKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VDb3B5SW5NZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcyk7XG4gICAgICAgICAgICBjYXNlIDcyIC8qIENvcHlPdXQgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VDb3B5T3V0TWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpO1xuICAgICAgICAgICAgY2FzZSAxMDAgLyogQ29weURhdGEgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VDb3B5RGF0YShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICBhc3NlcnRfMS5kZWZhdWx0LmZhaWwoYHVua25vd24gbWVzc2FnZSBjb2RlOiAke2NvZGUudG9TdHJpbmcoMTYpfWApO1xuICAgICAgICB9XG4gICAgfVxuICAgIHBhcnNlUmVhZHlGb3JRdWVyeU1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKSB7XG4gICAgICAgIHRoaXMucmVhZGVyLnNldEJ1ZmZlcihvZmZzZXQsIGJ5dGVzKTtcbiAgICAgICAgY29uc3Qgc3RhdHVzID0gdGhpcy5yZWFkZXIuc3RyaW5nKDEpO1xuICAgICAgICByZXR1cm4gbmV3IG1lc3NhZ2VzXzEuUmVhZHlGb3JRdWVyeU1lc3NhZ2UobGVuZ3RoLCBzdGF0dXMpO1xuICAgIH1cbiAgICBwYXJzZUNvbW1hbmRDb21wbGV0ZU1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKSB7XG4gICAgICAgIHRoaXMucmVhZGVyLnNldEJ1ZmZlcihvZmZzZXQsIGJ5dGVzKTtcbiAgICAgICAgY29uc3QgdGV4dCA9IHRoaXMucmVhZGVyLmNzdHJpbmcoKTtcbiAgICAgICAgcmV0dXJuIG5ldyBtZXNzYWdlc18xLkNvbW1hbmRDb21wbGV0ZU1lc3NhZ2UobGVuZ3RoLCB0ZXh0KTtcbiAgICB9XG4gICAgcGFyc2VDb3B5RGF0YShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpIHtcbiAgICAgICAgY29uc3QgY2h1bmsgPSBieXRlcy5zbGljZShvZmZzZXQsIG9mZnNldCArIChsZW5ndGggLSA0KSk7XG4gICAgICAgIHJldHVybiBuZXcgbWVzc2FnZXNfMS5Db3B5RGF0YU1lc3NhZ2UobGVuZ3RoLCBjaHVuayk7XG4gICAgfVxuICAgIHBhcnNlQ29weUluTWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VDb3B5TWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMsICdjb3B5SW5SZXNwb25zZScpO1xuICAgIH1cbiAgICBwYXJzZUNvcHlPdXRNZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcykge1xuICAgICAgICByZXR1cm4gdGhpcy5wYXJzZUNvcHlNZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcywgJ2NvcHlPdXRSZXNwb25zZScpO1xuICAgIH1cbiAgICBwYXJzZUNvcHlNZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcywgbWVzc2FnZU5hbWUpIHtcbiAgICAgICAgdGhpcy5yZWFkZXIuc2V0QnVmZmVyKG9mZnNldCwgYnl0ZXMpO1xuICAgICAgICBjb25zdCBpc0JpbmFyeSA9IHRoaXMucmVhZGVyLmJ5dGUoKSAhPT0gMDtcbiAgICAgICAgY29uc3QgY29sdW1uQ291bnQgPSB0aGlzLnJlYWRlci5pbnQxNigpO1xuICAgICAgICBjb25zdCBtZXNzYWdlID0gbmV3IG1lc3NhZ2VzXzEuQ29weVJlc3BvbnNlKGxlbmd0aCwgbWVzc2FnZU5hbWUsIGlzQmluYXJ5LCBjb2x1bW5Db3VudCk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY29sdW1uQ291bnQ7IGkrKykge1xuICAgICAgICAgICAgbWVzc2FnZS5jb2x1bW5UeXBlc1tpXSA9IHRoaXMucmVhZGVyLmludDE2KCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgfVxuICAgIHBhcnNlTm90aWZpY2F0aW9uTWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpIHtcbiAgICAgICAgdGhpcy5yZWFkZXIuc2V0QnVmZmVyKG9mZnNldCwgYnl0ZXMpO1xuICAgICAgICBjb25zdCBwcm9jZXNzSWQgPSB0aGlzLnJlYWRlci5pbnQzMigpO1xuICAgICAgICBjb25zdCBjaGFubmVsID0gdGhpcy5yZWFkZXIuY3N0cmluZygpO1xuICAgICAgICBjb25zdCBwYXlsb2FkID0gdGhpcy5yZWFkZXIuY3N0cmluZygpO1xuICAgICAgICByZXR1cm4gbmV3IG1lc3NhZ2VzXzEuTm90aWZpY2F0aW9uUmVzcG9uc2VNZXNzYWdlKGxlbmd0aCwgcHJvY2Vzc0lkLCBjaGFubmVsLCBwYXlsb2FkKTtcbiAgICB9XG4gICAgcGFyc2VSb3dEZXNjcmlwdGlvbk1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKSB7XG4gICAgICAgIHRoaXMucmVhZGVyLnNldEJ1ZmZlcihvZmZzZXQsIGJ5dGVzKTtcbiAgICAgICAgY29uc3QgZmllbGRDb3VudCA9IHRoaXMucmVhZGVyLmludDE2KCk7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBuZXcgbWVzc2FnZXNfMS5Sb3dEZXNjcmlwdGlvbk1lc3NhZ2UobGVuZ3RoLCBmaWVsZENvdW50KTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBmaWVsZENvdW50OyBpKyspIHtcbiAgICAgICAgICAgIG1lc3NhZ2UuZmllbGRzW2ldID0gdGhpcy5wYXJzZUZpZWxkKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgfVxuICAgIHBhcnNlRmllbGQoKSB7XG4gICAgICAgIGNvbnN0IG5hbWUgPSB0aGlzLnJlYWRlci5jc3RyaW5nKCk7XG4gICAgICAgIGNvbnN0IHRhYmxlSUQgPSB0aGlzLnJlYWRlci5pbnQzMigpO1xuICAgICAgICBjb25zdCBjb2x1bW5JRCA9IHRoaXMucmVhZGVyLmludDE2KCk7XG4gICAgICAgIGNvbnN0IGRhdGFUeXBlSUQgPSB0aGlzLnJlYWRlci5pbnQzMigpO1xuICAgICAgICBjb25zdCBkYXRhVHlwZVNpemUgPSB0aGlzLnJlYWRlci5pbnQxNigpO1xuICAgICAgICBjb25zdCBkYXRhVHlwZU1vZGlmaWVyID0gdGhpcy5yZWFkZXIuaW50MzIoKTtcbiAgICAgICAgY29uc3QgbW9kZSA9IHRoaXMucmVhZGVyLmludDE2KCkgPT09IDAgPyAndGV4dCcgOiAnYmluYXJ5JztcbiAgICAgICAgcmV0dXJuIG5ldyBtZXNzYWdlc18xLkZpZWxkKG5hbWUsIHRhYmxlSUQsIGNvbHVtbklELCBkYXRhVHlwZUlELCBkYXRhVHlwZVNpemUsIGRhdGFUeXBlTW9kaWZpZXIsIG1vZGUpO1xuICAgIH1cbiAgICBwYXJzZVBhcmFtZXRlckRlc2NyaXB0aW9uTWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpIHtcbiAgICAgICAgdGhpcy5yZWFkZXIuc2V0QnVmZmVyKG9mZnNldCwgYnl0ZXMpO1xuICAgICAgICBjb25zdCBwYXJhbWV0ZXJDb3VudCA9IHRoaXMucmVhZGVyLmludDE2KCk7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBuZXcgbWVzc2FnZXNfMS5QYXJhbWV0ZXJEZXNjcmlwdGlvbk1lc3NhZ2UobGVuZ3RoLCBwYXJhbWV0ZXJDb3VudCk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcGFyYW1ldGVyQ291bnQ7IGkrKykge1xuICAgICAgICAgICAgbWVzc2FnZS5kYXRhVHlwZUlEc1tpXSA9IHRoaXMucmVhZGVyLmludDMyKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgfVxuICAgIHBhcnNlRGF0YVJvd01lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKSB7XG4gICAgICAgIHRoaXMucmVhZGVyLnNldEJ1ZmZlcihvZmZzZXQsIGJ5dGVzKTtcbiAgICAgICAgY29uc3QgZmllbGRDb3VudCA9IHRoaXMucmVhZGVyLmludDE2KCk7XG4gICAgICAgIGNvbnN0IGZpZWxkcyA9IG5ldyBBcnJheShmaWVsZENvdW50KTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBmaWVsZENvdW50OyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGxlbiA9IHRoaXMucmVhZGVyLmludDMyKCk7XG4gICAgICAgICAgICAvLyBhIC0xIGZvciBsZW5ndGggbWVhbnMgdGhlIHZhbHVlIG9mIHRoZSBmaWVsZCBpcyBudWxsXG4gICAgICAgICAgICBmaWVsZHNbaV0gPSBsZW4gPT09IC0xID8gbnVsbCA6IHRoaXMucmVhZGVyLnN0cmluZyhsZW4pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBuZXcgbWVzc2FnZXNfMS5EYXRhUm93TWVzc2FnZShsZW5ndGgsIGZpZWxkcyk7XG4gICAgfVxuICAgIHBhcnNlUGFyYW1ldGVyU3RhdHVzTWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpIHtcbiAgICAgICAgdGhpcy5yZWFkZXIuc2V0QnVmZmVyKG9mZnNldCwgYnl0ZXMpO1xuICAgICAgICBjb25zdCBuYW1lID0gdGhpcy5yZWFkZXIuY3N0cmluZygpO1xuICAgICAgICBjb25zdCB2YWx1ZSA9IHRoaXMucmVhZGVyLmNzdHJpbmcoKTtcbiAgICAgICAgcmV0dXJuIG5ldyBtZXNzYWdlc18xLlBhcmFtZXRlclN0YXR1c01lc3NhZ2UobGVuZ3RoLCBuYW1lLCB2YWx1ZSk7XG4gICAgfVxuICAgIHBhcnNlQmFja2VuZEtleURhdGEob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKSB7XG4gICAgICAgIHRoaXMucmVhZGVyLnNldEJ1ZmZlcihvZmZzZXQsIGJ5dGVzKTtcbiAgICAgICAgY29uc3QgcHJvY2Vzc0lEID0gdGhpcy5yZWFkZXIuaW50MzIoKTtcbiAgICAgICAgY29uc3Qgc2VjcmV0S2V5ID0gdGhpcy5yZWFkZXIuaW50MzIoKTtcbiAgICAgICAgcmV0dXJuIG5ldyBtZXNzYWdlc18xLkJhY2tlbmRLZXlEYXRhTWVzc2FnZShsZW5ndGgsIHByb2Nlc3NJRCwgc2VjcmV0S2V5KTtcbiAgICB9XG4gICAgcGFyc2VBdXRoZW50aWNhdGlvblJlc3BvbnNlKG9mZnNldCwgbGVuZ3RoLCBieXRlcykge1xuICAgICAgICB0aGlzLnJlYWRlci5zZXRCdWZmZXIob2Zmc2V0LCBieXRlcyk7XG4gICAgICAgIGNvbnN0IGNvZGUgPSB0aGlzLnJlYWRlci5pbnQzMigpO1xuICAgICAgICAvLyBUT0RPKGJtYyk6IG1heWJlIGJldHRlciB0eXBlcyBoZXJlXG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSB7XG4gICAgICAgICAgICBuYW1lOiAnYXV0aGVudGljYXRpb25PaycsXG4gICAgICAgICAgICBsZW5ndGgsXG4gICAgICAgIH07XG4gICAgICAgIHN3aXRjaCAoY29kZSkge1xuICAgICAgICAgICAgY2FzZSAwOiAvLyBBdXRoZW50aWNhdGlvbk9rXG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIDM6IC8vIEF1dGhlbnRpY2F0aW9uQ2xlYXJ0ZXh0UGFzc3dvcmRcbiAgICAgICAgICAgICAgICBpZiAobWVzc2FnZS5sZW5ndGggPT09IDgpIHtcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5uYW1lID0gJ2F1dGhlbnRpY2F0aW9uQ2xlYXJ0ZXh0UGFzc3dvcmQnO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgNTogLy8gQXV0aGVudGljYXRpb25NRDVQYXNzd29yZFxuICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLmxlbmd0aCA9PT0gMTIpIHtcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5uYW1lID0gJ2F1dGhlbnRpY2F0aW9uTUQ1UGFzc3dvcmQnO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBzYWx0ID0gdGhpcy5yZWFkZXIuYnl0ZXMoNCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBuZXcgbWVzc2FnZXNfMS5BdXRoZW50aWNhdGlvbk1ENVBhc3N3b3JkKGxlbmd0aCwgc2FsdCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAxMDogLy8gQXV0aGVudGljYXRpb25TQVNMXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5uYW1lID0gJ2F1dGhlbnRpY2F0aW9uU0FTTCc7XG4gICAgICAgICAgICAgICAgbWVzc2FnZS5tZWNoYW5pc21zID0gW107XG4gICAgICAgICAgICAgICAgbGV0IG1lY2hhbmlzbTtcbiAgICAgICAgICAgICAgICBkbyB7XG4gICAgICAgICAgICAgICAgICAgIG1lY2hhbmlzbSA9IHRoaXMucmVhZGVyLmNzdHJpbmcoKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG1lY2hhbmlzbSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5tZWNoYW5pc21zLnB1c2gobWVjaGFuaXNtKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gd2hpbGUgKG1lY2hhbmlzbSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIDExOiAvLyBBdXRoZW50aWNhdGlvblNBU0xDb250aW51ZVxuICAgICAgICAgICAgICAgIG1lc3NhZ2UubmFtZSA9ICdhdXRoZW50aWNhdGlvblNBU0xDb250aW51ZSc7XG4gICAgICAgICAgICAgICAgbWVzc2FnZS5kYXRhID0gdGhpcy5yZWFkZXIuc3RyaW5nKGxlbmd0aCAtIDgpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAxMjogLy8gQXV0aGVudGljYXRpb25TQVNMRmluYWxcbiAgICAgICAgICAgICAgICBtZXNzYWdlLm5hbWUgPSAnYXV0aGVudGljYXRpb25TQVNMRmluYWwnO1xuICAgICAgICAgICAgICAgIG1lc3NhZ2UuZGF0YSA9IHRoaXMucmVhZGVyLnN0cmluZyhsZW5ndGggLSA4KTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbmtub3duIGF1dGhlbnRpY2F0aW9uT2sgbWVzc2FnZSB0eXBlICcgKyBjb2RlKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbWVzc2FnZTtcbiAgICB9XG4gICAgcGFyc2VFcnJvck1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzLCBuYW1lKSB7XG4gICAgICAgIHRoaXMucmVhZGVyLnNldEJ1ZmZlcihvZmZzZXQsIGJ5dGVzKTtcbiAgICAgICAgY29uc3QgZmllbGRzID0ge307XG4gICAgICAgIGxldCBmaWVsZFR5cGUgPSB0aGlzLnJlYWRlci5zdHJpbmcoMSk7XG4gICAgICAgIHdoaWxlIChmaWVsZFR5cGUgIT09ICdcXDAnKSB7XG4gICAgICAgICAgICBmaWVsZHNbZmllbGRUeXBlXSA9IHRoaXMucmVhZGVyLmNzdHJpbmcoKTtcbiAgICAgICAgICAgIGZpZWxkVHlwZSA9IHRoaXMucmVhZGVyLnN0cmluZygxKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBtZXNzYWdlVmFsdWUgPSBmaWVsZHMuTTtcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IG5hbWUgPT09ICdub3RpY2UnID8gbmV3IG1lc3NhZ2VzXzEuTm90aWNlTWVzc2FnZShsZW5ndGgsIG1lc3NhZ2VWYWx1ZSkgOiBuZXcgbWVzc2FnZXNfMS5EYXRhYmFzZUVycm9yKG1lc3NhZ2VWYWx1ZSwgbGVuZ3RoLCBuYW1lKTtcbiAgICAgICAgbWVzc2FnZS5zZXZlcml0eSA9IGZpZWxkcy5TO1xuICAgICAgICBtZXNzYWdlLmNvZGUgPSBmaWVsZHMuQztcbiAgICAgICAgbWVzc2FnZS5kZXRhaWwgPSBmaWVsZHMuRDtcbiAgICAgICAgbWVzc2FnZS5oaW50ID0gZmllbGRzLkg7XG4gICAgICAgIG1lc3NhZ2UucG9zaXRpb24gPSBmaWVsZHMuUDtcbiAgICAgICAgbWVzc2FnZS5pbnRlcm5hbFBvc2l0aW9uID0gZmllbGRzLnA7XG4gICAgICAgIG1lc3NhZ2UuaW50ZXJuYWxRdWVyeSA9IGZpZWxkcy5xO1xuICAgICAgICBtZXNzYWdlLndoZXJlID0gZmllbGRzLlc7XG4gICAgICAgIG1lc3NhZ2Uuc2NoZW1hID0gZmllbGRzLnM7XG4gICAgICAgIG1lc3NhZ2UudGFibGUgPSBmaWVsZHMudDtcbiAgICAgICAgbWVzc2FnZS5jb2x1bW4gPSBmaWVsZHMuYztcbiAgICAgICAgbWVzc2FnZS5kYXRhVHlwZSA9IGZpZWxkcy5kO1xuICAgICAgICBtZXNzYWdlLmNvbnN0cmFpbnQgPSBmaWVsZHMubjtcbiAgICAgICAgbWVzc2FnZS5maWxlID0gZmllbGRzLkY7XG4gICAgICAgIG1lc3NhZ2UubGluZSA9IGZpZWxkcy5MO1xuICAgICAgICBtZXNzYWdlLnJvdXRpbmUgPSBmaWVsZHMuUjtcbiAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgfVxufVxuZXhwb3J0cy5QYXJzZXIgPSBQYXJzZXI7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1wYXJzZXIuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLnNlcmlhbGl6ZSA9IHZvaWQgMDtcbmNvbnN0IGJ1ZmZlcl93cml0ZXJfMSA9IHJlcXVpcmUoXCIuL2J1ZmZlci13cml0ZXJcIik7XG5jb25zdCB3cml0ZXIgPSBuZXcgYnVmZmVyX3dyaXRlcl8xLldyaXRlcigpO1xuY29uc3Qgc3RhcnR1cCA9IChvcHRzKSA9PiB7XG4gICAgLy8gcHJvdG9jb2wgdmVyc2lvblxuICAgIHdyaXRlci5hZGRJbnQxNigzKS5hZGRJbnQxNigwKTtcbiAgICBmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhvcHRzKSkge1xuICAgICAgICB3cml0ZXIuYWRkQ1N0cmluZyhrZXkpLmFkZENTdHJpbmcob3B0c1trZXldKTtcbiAgICB9XG4gICAgd3JpdGVyLmFkZENTdHJpbmcoJ2NsaWVudF9lbmNvZGluZycpLmFkZENTdHJpbmcoJ1VURjgnKTtcbiAgICB2YXIgYm9keUJ1ZmZlciA9IHdyaXRlci5hZGRDU3RyaW5nKCcnKS5mbHVzaCgpO1xuICAgIC8vIHRoaXMgbWVzc2FnZSBpcyBzZW50IHdpdGhvdXQgYSBjb2RlXG4gICAgdmFyIGxlbmd0aCA9IGJvZHlCdWZmZXIubGVuZ3RoICsgNDtcbiAgICByZXR1cm4gbmV3IGJ1ZmZlcl93cml0ZXJfMS5Xcml0ZXIoKS5hZGRJbnQzMihsZW5ndGgpLmFkZChib2R5QnVmZmVyKS5mbHVzaCgpO1xufTtcbmNvbnN0IHJlcXVlc3RTc2wgPSAoKSA9PiB7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBCdWZmZXIuYWxsb2NVbnNhZmUoOCk7XG4gICAgcmVzcG9uc2Uud3JpdGVJbnQzMkJFKDgsIDApO1xuICAgIHJlc3BvbnNlLndyaXRlSW50MzJCRSg4MDg3NzEwMywgNCk7XG4gICAgcmV0dXJuIHJlc3BvbnNlO1xufTtcbmNvbnN0IHBhc3N3b3JkID0gKHBhc3N3b3JkKSA9PiB7XG4gICAgcmV0dXJuIHdyaXRlci5hZGRDU3RyaW5nKHBhc3N3b3JkKS5mbHVzaCgxMTIgLyogc3RhcnR1cCAqLyk7XG59O1xuY29uc3Qgc2VuZFNBU0xJbml0aWFsUmVzcG9uc2VNZXNzYWdlID0gZnVuY3Rpb24gKG1lY2hhbmlzbSwgaW5pdGlhbFJlc3BvbnNlKSB7XG4gICAgLy8gMHg3MCA9ICdwJ1xuICAgIHdyaXRlci5hZGRDU3RyaW5nKG1lY2hhbmlzbSkuYWRkSW50MzIoQnVmZmVyLmJ5dGVMZW5ndGgoaW5pdGlhbFJlc3BvbnNlKSkuYWRkU3RyaW5nKGluaXRpYWxSZXNwb25zZSk7XG4gICAgcmV0dXJuIHdyaXRlci5mbHVzaCgxMTIgLyogc3RhcnR1cCAqLyk7XG59O1xuY29uc3Qgc2VuZFNDUkFNQ2xpZW50RmluYWxNZXNzYWdlID0gZnVuY3Rpb24gKGFkZGl0aW9uYWxEYXRhKSB7XG4gICAgcmV0dXJuIHdyaXRlci5hZGRTdHJpbmcoYWRkaXRpb25hbERhdGEpLmZsdXNoKDExMiAvKiBzdGFydHVwICovKTtcbn07XG5jb25zdCBxdWVyeSA9ICh0ZXh0KSA9PiB7XG4gICAgcmV0dXJuIHdyaXRlci5hZGRDU3RyaW5nKHRleHQpLmZsdXNoKDgxIC8qIHF1ZXJ5ICovKTtcbn07XG5jb25zdCBlbXB0eUFycmF5ID0gW107XG5jb25zdCBwYXJzZSA9IChxdWVyeSkgPT4ge1xuICAgIC8vIGV4cGVjdCBzb21ldGhpbmcgbGlrZSB0aGlzOlxuICAgIC8vIHsgbmFtZTogJ3F1ZXJ5TmFtZScsXG4gICAgLy8gICB0ZXh0OiAnc2VsZWN0ICogZnJvbSBibGFoJyxcbiAgICAvLyAgIHR5cGVzOiBbJ2ludDgnLCAnYm9vbCddIH1cbiAgICAvLyBub3JtYWxpemUgbWlzc2luZyBxdWVyeSBuYW1lcyB0byBhbGxvdyBmb3IgbnVsbFxuICAgIGNvbnN0IG5hbWUgPSBxdWVyeS5uYW1lIHx8ICcnO1xuICAgIGlmIChuYW1lLmxlbmd0aCA+IDYzKSB7XG4gICAgICAgIC8qIGVzbGludC1kaXNhYmxlIG5vLWNvbnNvbGUgKi9cbiAgICAgICAgY29uc29sZS5lcnJvcignV2FybmluZyEgUG9zdGdyZXMgb25seSBzdXBwb3J0cyA2MyBjaGFyYWN0ZXJzIGZvciBxdWVyeSBuYW1lcy4nKTtcbiAgICAgICAgY29uc29sZS5lcnJvcignWW91IHN1cHBsaWVkICVzICglcyknLCBuYW1lLCBuYW1lLmxlbmd0aCk7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ1RoaXMgY2FuIGNhdXNlIGNvbmZsaWN0cyBhbmQgc2lsZW50IGVycm9ycyBleGVjdXRpbmcgcXVlcmllcycpO1xuICAgICAgICAvKiBlc2xpbnQtZW5hYmxlIG5vLWNvbnNvbGUgKi9cbiAgICB9XG4gICAgY29uc3QgdHlwZXMgPSBxdWVyeS50eXBlcyB8fCBlbXB0eUFycmF5O1xuICAgIHZhciBsZW4gPSB0eXBlcy5sZW5ndGg7XG4gICAgdmFyIGJ1ZmZlciA9IHdyaXRlclxuICAgICAgICAuYWRkQ1N0cmluZyhuYW1lKSAvLyBuYW1lIG9mIHF1ZXJ5XG4gICAgICAgIC5hZGRDU3RyaW5nKHF1ZXJ5LnRleHQpIC8vIGFjdHVhbCBxdWVyeSB0ZXh0XG4gICAgICAgIC5hZGRJbnQxNihsZW4pO1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgICAgYnVmZmVyLmFkZEludDMyKHR5cGVzW2ldKTtcbiAgICB9XG4gICAgcmV0dXJuIHdyaXRlci5mbHVzaCg4MCAvKiBwYXJzZSAqLyk7XG59O1xuY29uc3QgcGFyYW1Xcml0ZXIgPSBuZXcgYnVmZmVyX3dyaXRlcl8xLldyaXRlcigpO1xuY29uc3Qgd3JpdGVWYWx1ZXMgPSBmdW5jdGlvbiAodmFsdWVzLCB2YWx1ZU1hcHBlcikge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdmFsdWVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IG1hcHBlZFZhbCA9IHZhbHVlTWFwcGVyID8gdmFsdWVNYXBwZXIodmFsdWVzW2ldLCBpKSA6IHZhbHVlc1tpXTtcbiAgICAgICAgaWYgKG1hcHBlZFZhbCA9PSBudWxsKSB7XG4gICAgICAgICAgICAvLyBhZGQgdGhlIHBhcmFtIHR5cGUgKHN0cmluZykgdG8gdGhlIHdyaXRlclxuICAgICAgICAgICAgd3JpdGVyLmFkZEludDE2KDAgLyogU1RSSU5HICovKTtcbiAgICAgICAgICAgIC8vIHdyaXRlIC0xIHRvIHRoZSBwYXJhbSB3cml0ZXIgdG8gaW5kaWNhdGUgbnVsbFxuICAgICAgICAgICAgcGFyYW1Xcml0ZXIuYWRkSW50MzIoLTEpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1hcHBlZFZhbCBpbnN0YW5jZW9mIEJ1ZmZlcikge1xuICAgICAgICAgICAgLy8gYWRkIHRoZSBwYXJhbSB0eXBlIChiaW5hcnkpIHRvIHRoZSB3cml0ZXJcbiAgICAgICAgICAgIHdyaXRlci5hZGRJbnQxNigxIC8qIEJJTkFSWSAqLyk7XG4gICAgICAgICAgICAvLyBhZGQgdGhlIGJ1ZmZlciB0byB0aGUgcGFyYW0gd3JpdGVyXG4gICAgICAgICAgICBwYXJhbVdyaXRlci5hZGRJbnQzMihtYXBwZWRWYWwubGVuZ3RoKTtcbiAgICAgICAgICAgIHBhcmFtV3JpdGVyLmFkZChtYXBwZWRWYWwpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgLy8gYWRkIHRoZSBwYXJhbSB0eXBlIChzdHJpbmcpIHRvIHRoZSB3cml0ZXJcbiAgICAgICAgICAgIHdyaXRlci5hZGRJbnQxNigwIC8qIFNUUklORyAqLyk7XG4gICAgICAgICAgICBwYXJhbVdyaXRlci5hZGRJbnQzMihCdWZmZXIuYnl0ZUxlbmd0aChtYXBwZWRWYWwpKTtcbiAgICAgICAgICAgIHBhcmFtV3JpdGVyLmFkZFN0cmluZyhtYXBwZWRWYWwpO1xuICAgICAgICB9XG4gICAgfVxufTtcbmNvbnN0IGJpbmQgPSAoY29uZmlnID0ge30pID0+IHtcbiAgICAvLyBub3JtYWxpemUgY29uZmlnXG4gICAgY29uc3QgcG9ydGFsID0gY29uZmlnLnBvcnRhbCB8fCAnJztcbiAgICBjb25zdCBzdGF0ZW1lbnQgPSBjb25maWcuc3RhdGVtZW50IHx8ICcnO1xuICAgIGNvbnN0IGJpbmFyeSA9IGNvbmZpZy5iaW5hcnkgfHwgZmFsc2U7XG4gICAgY29uc3QgdmFsdWVzID0gY29uZmlnLnZhbHVlcyB8fCBlbXB0eUFycmF5O1xuICAgIGNvbnN0IGxlbiA9IHZhbHVlcy5sZW5ndGg7XG4gICAgd3JpdGVyLmFkZENTdHJpbmcocG9ydGFsKS5hZGRDU3RyaW5nKHN0YXRlbWVudCk7XG4gICAgd3JpdGVyLmFkZEludDE2KGxlbik7XG4gICAgd3JpdGVWYWx1ZXModmFsdWVzLCBjb25maWcudmFsdWVNYXBwZXIpO1xuICAgIHdyaXRlci5hZGRJbnQxNihsZW4pO1xuICAgIHdyaXRlci5hZGQocGFyYW1Xcml0ZXIuZmx1c2goKSk7XG4gICAgLy8gZm9ybWF0IGNvZGVcbiAgICB3cml0ZXIuYWRkSW50MTYoYmluYXJ5ID8gMSAvKiBCSU5BUlkgKi8gOiAwIC8qIFNUUklORyAqLyk7XG4gICAgcmV0dXJuIHdyaXRlci5mbHVzaCg2NiAvKiBiaW5kICovKTtcbn07XG5jb25zdCBlbXB0eUV4ZWN1dGUgPSBCdWZmZXIuZnJvbShbNjkgLyogZXhlY3V0ZSAqLywgMHgwMCwgMHgwMCwgMHgwMCwgMHgwOSwgMHgwMCwgMHgwMCwgMHgwMCwgMHgwMCwgMHgwMF0pO1xuY29uc3QgZXhlY3V0ZSA9IChjb25maWcpID0+IHtcbiAgICAvLyB0aGlzIGlzIHRoZSBoYXBweSBwYXRoIGZvciBtb3N0IHF1ZXJpZXNcbiAgICBpZiAoIWNvbmZpZyB8fCAoIWNvbmZpZy5wb3J0YWwgJiYgIWNvbmZpZy5yb3dzKSkge1xuICAgICAgICByZXR1cm4gZW1wdHlFeGVjdXRlO1xuICAgIH1cbiAgICBjb25zdCBwb3J0YWwgPSBjb25maWcucG9ydGFsIHx8ICcnO1xuICAgIGNvbnN0IHJvd3MgPSBjb25maWcucm93cyB8fCAwO1xuICAgIGNvbnN0IHBvcnRhbExlbmd0aCA9IEJ1ZmZlci5ieXRlTGVuZ3RoKHBvcnRhbCk7XG4gICAgY29uc3QgbGVuID0gNCArIHBvcnRhbExlbmd0aCArIDEgKyA0O1xuICAgIC8vIG9uZSBleHRyYSBiaXQgZm9yIGNvZGVcbiAgICBjb25zdCBidWZmID0gQnVmZmVyLmFsbG9jVW5zYWZlKDEgKyBsZW4pO1xuICAgIGJ1ZmZbMF0gPSA2OSAvKiBleGVjdXRlICovO1xuICAgIGJ1ZmYud3JpdGVJbnQzMkJFKGxlbiwgMSk7XG4gICAgYnVmZi53cml0ZShwb3J0YWwsIDUsICd1dGYtOCcpO1xuICAgIGJ1ZmZbcG9ydGFsTGVuZ3RoICsgNV0gPSAwOyAvLyBudWxsIHRlcm1pbmF0ZSBwb3J0YWwgY1N0cmluZ1xuICAgIGJ1ZmYud3JpdGVVSW50MzJCRShyb3dzLCBidWZmLmxlbmd0aCAtIDQpO1xuICAgIHJldHVybiBidWZmO1xufTtcbmNvbnN0IGNhbmNlbCA9IChwcm9jZXNzSUQsIHNlY3JldEtleSkgPT4ge1xuICAgIGNvbnN0IGJ1ZmZlciA9IEJ1ZmZlci5hbGxvY1Vuc2FmZSgxNik7XG4gICAgYnVmZmVyLndyaXRlSW50MzJCRSgxNiwgMCk7XG4gICAgYnVmZmVyLndyaXRlSW50MTZCRSgxMjM0LCA0KTtcbiAgICBidWZmZXIud3JpdGVJbnQxNkJFKDU2NzgsIDYpO1xuICAgIGJ1ZmZlci53cml0ZUludDMyQkUocHJvY2Vzc0lELCA4KTtcbiAgICBidWZmZXIud3JpdGVJbnQzMkJFKHNlY3JldEtleSwgMTIpO1xuICAgIHJldHVybiBidWZmZXI7XG59O1xuY29uc3QgY3N0cmluZ01lc3NhZ2UgPSAoY29kZSwgc3RyaW5nKSA9PiB7XG4gICAgY29uc3Qgc3RyaW5nTGVuID0gQnVmZmVyLmJ5dGVMZW5ndGgoc3RyaW5nKTtcbiAgICBjb25zdCBsZW4gPSA0ICsgc3RyaW5nTGVuICsgMTtcbiAgICAvLyBvbmUgZXh0cmEgYml0IGZvciBjb2RlXG4gICAgY29uc3QgYnVmZmVyID0gQnVmZmVyLmFsbG9jVW5zYWZlKDEgKyBsZW4pO1xuICAgIGJ1ZmZlclswXSA9IGNvZGU7XG4gICAgYnVmZmVyLndyaXRlSW50MzJCRShsZW4sIDEpO1xuICAgIGJ1ZmZlci53cml0ZShzdHJpbmcsIDUsICd1dGYtOCcpO1xuICAgIGJ1ZmZlcltsZW5dID0gMDsgLy8gbnVsbCB0ZXJtaW5hdGUgY1N0cmluZ1xuICAgIHJldHVybiBidWZmZXI7XG59O1xuY29uc3QgZW1wdHlEZXNjcmliZVBvcnRhbCA9IHdyaXRlci5hZGRDU3RyaW5nKCdQJykuZmx1c2goNjggLyogZGVzY3JpYmUgKi8pO1xuY29uc3QgZW1wdHlEZXNjcmliZVN0YXRlbWVudCA9IHdyaXRlci5hZGRDU3RyaW5nKCdTJykuZmx1c2goNjggLyogZGVzY3JpYmUgKi8pO1xuY29uc3QgZGVzY3JpYmUgPSAobXNnKSA9PiB7XG4gICAgcmV0dXJuIG1zZy5uYW1lXG4gICAgICAgID8gY3N0cmluZ01lc3NhZ2UoNjggLyogZGVzY3JpYmUgKi8sIGAke21zZy50eXBlfSR7bXNnLm5hbWUgfHwgJyd9YClcbiAgICAgICAgOiBtc2cudHlwZSA9PT0gJ1AnXG4gICAgICAgICAgICA/IGVtcHR5RGVzY3JpYmVQb3J0YWxcbiAgICAgICAgICAgIDogZW1wdHlEZXNjcmliZVN0YXRlbWVudDtcbn07XG5jb25zdCBjbG9zZSA9IChtc2cpID0+IHtcbiAgICBjb25zdCB0ZXh0ID0gYCR7bXNnLnR5cGV9JHttc2cubmFtZSB8fCAnJ31gO1xuICAgIHJldHVybiBjc3RyaW5nTWVzc2FnZSg2NyAvKiBjbG9zZSAqLywgdGV4dCk7XG59O1xuY29uc3QgY29weURhdGEgPSAoY2h1bmspID0+IHtcbiAgICByZXR1cm4gd3JpdGVyLmFkZChjaHVuaykuZmx1c2goMTAwIC8qIGNvcHlGcm9tQ2h1bmsgKi8pO1xufTtcbmNvbnN0IGNvcHlGYWlsID0gKG1lc3NhZ2UpID0+IHtcbiAgICByZXR1cm4gY3N0cmluZ01lc3NhZ2UoMTAyIC8qIGNvcHlGYWlsICovLCBtZXNzYWdlKTtcbn07XG5jb25zdCBjb2RlT25seUJ1ZmZlciA9IChjb2RlKSA9PiBCdWZmZXIuZnJvbShbY29kZSwgMHgwMCwgMHgwMCwgMHgwMCwgMHgwNF0pO1xuY29uc3QgZmx1c2hCdWZmZXIgPSBjb2RlT25seUJ1ZmZlcig3MiAvKiBmbHVzaCAqLyk7XG5jb25zdCBzeW5jQnVmZmVyID0gY29kZU9ubHlCdWZmZXIoODMgLyogc3luYyAqLyk7XG5jb25zdCBlbmRCdWZmZXIgPSBjb2RlT25seUJ1ZmZlcig4OCAvKiBlbmQgKi8pO1xuY29uc3QgY29weURvbmVCdWZmZXIgPSBjb2RlT25seUJ1ZmZlcig5OSAvKiBjb3B5RG9uZSAqLyk7XG5jb25zdCBzZXJpYWxpemUgPSB7XG4gICAgc3RhcnR1cCxcbiAgICBwYXNzd29yZCxcbiAgICByZXF1ZXN0U3NsLFxuICAgIHNlbmRTQVNMSW5pdGlhbFJlc3BvbnNlTWVzc2FnZSxcbiAgICBzZW5kU0NSQU1DbGllbnRGaW5hbE1lc3NhZ2UsXG4gICAgcXVlcnksXG4gICAgcGFyc2UsXG4gICAgYmluZCxcbiAgICBleGVjdXRlLFxuICAgIGRlc2NyaWJlLFxuICAgIGNsb3NlLFxuICAgIGZsdXNoOiAoKSA9PiBmbHVzaEJ1ZmZlcixcbiAgICBzeW5jOiAoKSA9PiBzeW5jQnVmZmVyLFxuICAgIGVuZDogKCkgPT4gZW5kQnVmZmVyLFxuICAgIGNvcHlEYXRhLFxuICAgIGNvcHlEb25lOiAoKSA9PiBjb3B5RG9uZUJ1ZmZlcixcbiAgICBjb3B5RmFpbCxcbiAgICBjYW5jZWwsXG59O1xuZXhwb3J0cy5zZXJpYWxpemUgPSBzZXJpYWxpemU7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1zZXJpYWxpemVyLmpzLm1hcCIsInZhciB0ZXh0UGFyc2VycyA9IHJlcXVpcmUoJy4vbGliL3RleHRQYXJzZXJzJyk7XG52YXIgYmluYXJ5UGFyc2VycyA9IHJlcXVpcmUoJy4vbGliL2JpbmFyeVBhcnNlcnMnKTtcbnZhciBhcnJheVBhcnNlciA9IHJlcXVpcmUoJy4vbGliL2FycmF5UGFyc2VyJyk7XG52YXIgYnVpbHRpblR5cGVzID0gcmVxdWlyZSgnLi9saWIvYnVpbHRpbnMnKTtcblxuZXhwb3J0cy5nZXRUeXBlUGFyc2VyID0gZ2V0VHlwZVBhcnNlcjtcbmV4cG9ydHMuc2V0VHlwZVBhcnNlciA9IHNldFR5cGVQYXJzZXI7XG5leHBvcnRzLmFycmF5UGFyc2VyID0gYXJyYXlQYXJzZXI7XG5leHBvcnRzLmJ1aWx0aW5zID0gYnVpbHRpblR5cGVzO1xuXG52YXIgdHlwZVBhcnNlcnMgPSB7XG4gIHRleHQ6IHt9LFxuICBiaW5hcnk6IHt9XG59O1xuXG4vL3RoZSBlbXB0eSBwYXJzZSBmdW5jdGlvblxuZnVuY3Rpb24gbm9QYXJzZSAodmFsKSB7XG4gIHJldHVybiBTdHJpbmcodmFsKTtcbn07XG5cbi8vcmV0dXJucyBhIGZ1bmN0aW9uIHVzZWQgdG8gY29udmVydCBhIHNwZWNpZmljIHR5cGUgKHNwZWNpZmllZCBieVxuLy9vaWQpIGludG8gYSByZXN1bHQgamF2YXNjcmlwdCB0eXBlXG4vL25vdGU6IHRoZSBvaWQgY2FuIGJlIG9idGFpbmVkIHZpYSB0aGUgZm9sbG93aW5nIHNxbCBxdWVyeTpcbi8vU0VMRUNUIG9pZCBGUk9NIHBnX3R5cGUgV0hFUkUgdHlwbmFtZSA9ICdUWVBFX05BTUVfSEVSRSc7XG5mdW5jdGlvbiBnZXRUeXBlUGFyc2VyIChvaWQsIGZvcm1hdCkge1xuICBmb3JtYXQgPSBmb3JtYXQgfHwgJ3RleHQnO1xuICBpZiAoIXR5cGVQYXJzZXJzW2Zvcm1hdF0pIHtcbiAgICByZXR1cm4gbm9QYXJzZTtcbiAgfVxuICByZXR1cm4gdHlwZVBhcnNlcnNbZm9ybWF0XVtvaWRdIHx8IG5vUGFyc2U7XG59O1xuXG5mdW5jdGlvbiBzZXRUeXBlUGFyc2VyIChvaWQsIGZvcm1hdCwgcGFyc2VGbikge1xuICBpZih0eXBlb2YgZm9ybWF0ID09ICdmdW5jdGlvbicpIHtcbiAgICBwYXJzZUZuID0gZm9ybWF0O1xuICAgIGZvcm1hdCA9ICd0ZXh0JztcbiAgfVxuICB0eXBlUGFyc2Vyc1tmb3JtYXRdW29pZF0gPSBwYXJzZUZuO1xufTtcblxudGV4dFBhcnNlcnMuaW5pdChmdW5jdGlvbihvaWQsIGNvbnZlcnRlcikge1xuICB0eXBlUGFyc2Vycy50ZXh0W29pZF0gPSBjb252ZXJ0ZXI7XG59KTtcblxuYmluYXJ5UGFyc2Vycy5pbml0KGZ1bmN0aW9uKG9pZCwgY29udmVydGVyKSB7XG4gIHR5cGVQYXJzZXJzLmJpbmFyeVtvaWRdID0gY29udmVydGVyO1xufSk7XG4iLCJ2YXIgYXJyYXkgPSByZXF1aXJlKCdwb3N0Z3Jlcy1hcnJheScpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgY3JlYXRlOiBmdW5jdGlvbiAoc291cmNlLCB0cmFuc2Zvcm0pIHtcbiAgICByZXR1cm4ge1xuICAgICAgcGFyc2U6IGZ1bmN0aW9uKCkge1xuICAgICAgICByZXR1cm4gYXJyYXkucGFyc2Uoc291cmNlLCB0cmFuc2Zvcm0pO1xuICAgICAgfVxuICAgIH07XG4gIH1cbn07XG4iLCJ2YXIgcGFyc2VJbnQ2NCA9IHJlcXVpcmUoJ3BnLWludDgnKTtcblxudmFyIHBhcnNlQml0cyA9IGZ1bmN0aW9uKGRhdGEsIGJpdHMsIG9mZnNldCwgaW52ZXJ0LCBjYWxsYmFjaykge1xuICBvZmZzZXQgPSBvZmZzZXQgfHwgMDtcbiAgaW52ZXJ0ID0gaW52ZXJ0IHx8IGZhbHNlO1xuICBjYWxsYmFjayA9IGNhbGxiYWNrIHx8IGZ1bmN0aW9uKGxhc3RWYWx1ZSwgbmV3VmFsdWUsIGJpdHMpIHsgcmV0dXJuIChsYXN0VmFsdWUgKiBNYXRoLnBvdygyLCBiaXRzKSkgKyBuZXdWYWx1ZTsgfTtcbiAgdmFyIG9mZnNldEJ5dGVzID0gb2Zmc2V0ID4+IDM7XG5cbiAgdmFyIGludiA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gICAgaWYgKGludmVydCkge1xuICAgICAgcmV0dXJuIH52YWx1ZSAmIDB4ZmY7XG4gICAgfVxuXG4gICAgcmV0dXJuIHZhbHVlO1xuICB9O1xuXG4gIC8vIHJlYWQgZmlyc3QgKG1heWJlIHBhcnRpYWwpIGJ5dGVcbiAgdmFyIG1hc2sgPSAweGZmO1xuICB2YXIgZmlyc3RCaXRzID0gOCAtIChvZmZzZXQgJSA4KTtcbiAgaWYgKGJpdHMgPCBmaXJzdEJpdHMpIHtcbiAgICBtYXNrID0gKDB4ZmYgPDwgKDggLSBiaXRzKSkgJiAweGZmO1xuICAgIGZpcnN0Qml0cyA9IGJpdHM7XG4gIH1cblxuICBpZiAob2Zmc2V0KSB7XG4gICAgbWFzayA9IG1hc2sgPj4gKG9mZnNldCAlIDgpO1xuICB9XG5cbiAgdmFyIHJlc3VsdCA9IDA7XG4gIGlmICgob2Zmc2V0ICUgOCkgKyBiaXRzID49IDgpIHtcbiAgICByZXN1bHQgPSBjYWxsYmFjaygwLCBpbnYoZGF0YVtvZmZzZXRCeXRlc10pICYgbWFzaywgZmlyc3RCaXRzKTtcbiAgfVxuXG4gIC8vIHJlYWQgYnl0ZXNcbiAgdmFyIGJ5dGVzID0gKGJpdHMgKyBvZmZzZXQpID4+IDM7XG4gIGZvciAodmFyIGkgPSBvZmZzZXRCeXRlcyArIDE7IGkgPCBieXRlczsgaSsrKSB7XG4gICAgcmVzdWx0ID0gY2FsbGJhY2socmVzdWx0LCBpbnYoZGF0YVtpXSksIDgpO1xuICB9XG5cbiAgLy8gYml0cyB0byByZWFkLCB0aGF0IGFyZSBub3QgYSBjb21wbGV0ZSBieXRlXG4gIHZhciBsYXN0Qml0cyA9IChiaXRzICsgb2Zmc2V0KSAlIDg7XG4gIGlmIChsYXN0Qml0cyA+IDApIHtcbiAgICByZXN1bHQgPSBjYWxsYmFjayhyZXN1bHQsIGludihkYXRhW2J5dGVzXSkgPj4gKDggLSBsYXN0Qml0cyksIGxhc3RCaXRzKTtcbiAgfVxuXG4gIHJldHVybiByZXN1bHQ7XG59O1xuXG52YXIgcGFyc2VGbG9hdEZyb21CaXRzID0gZnVuY3Rpb24oZGF0YSwgcHJlY2lzaW9uQml0cywgZXhwb25lbnRCaXRzKSB7XG4gIHZhciBiaWFzID0gTWF0aC5wb3coMiwgZXhwb25lbnRCaXRzIC0gMSkgLSAxO1xuICB2YXIgc2lnbiA9IHBhcnNlQml0cyhkYXRhLCAxKTtcbiAgdmFyIGV4cG9uZW50ID0gcGFyc2VCaXRzKGRhdGEsIGV4cG9uZW50Qml0cywgMSk7XG5cbiAgaWYgKGV4cG9uZW50ID09PSAwKSB7XG4gICAgcmV0dXJuIDA7XG4gIH1cblxuICAvLyBwYXJzZSBtYW50aXNzYVxuICB2YXIgcHJlY2lzaW9uQml0c0NvdW50ZXIgPSAxO1xuICB2YXIgcGFyc2VQcmVjaXNpb25CaXRzID0gZnVuY3Rpb24obGFzdFZhbHVlLCBuZXdWYWx1ZSwgYml0cykge1xuICAgIGlmIChsYXN0VmFsdWUgPT09IDApIHtcbiAgICAgIGxhc3RWYWx1ZSA9IDE7XG4gICAgfVxuXG4gICAgZm9yICh2YXIgaSA9IDE7IGkgPD0gYml0czsgaSsrKSB7XG4gICAgICBwcmVjaXNpb25CaXRzQ291bnRlciAvPSAyO1xuICAgICAgaWYgKChuZXdWYWx1ZSAmICgweDEgPDwgKGJpdHMgLSBpKSkpID4gMCkge1xuICAgICAgICBsYXN0VmFsdWUgKz0gcHJlY2lzaW9uQml0c0NvdW50ZXI7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGxhc3RWYWx1ZTtcbiAgfTtcblxuICB2YXIgbWFudGlzc2EgPSBwYXJzZUJpdHMoZGF0YSwgcHJlY2lzaW9uQml0cywgZXhwb25lbnRCaXRzICsgMSwgZmFsc2UsIHBhcnNlUHJlY2lzaW9uQml0cyk7XG5cbiAgLy8gc3BlY2lhbCBjYXNlc1xuICBpZiAoZXhwb25lbnQgPT0gKE1hdGgucG93KDIsIGV4cG9uZW50Qml0cyArIDEpIC0gMSkpIHtcbiAgICBpZiAobWFudGlzc2EgPT09IDApIHtcbiAgICAgIHJldHVybiAoc2lnbiA9PT0gMCkgPyBJbmZpbml0eSA6IC1JbmZpbml0eTtcbiAgICB9XG5cbiAgICByZXR1cm4gTmFOO1xuICB9XG5cbiAgLy8gbm9ybWFsZSBudW1iZXJcbiAgcmV0dXJuICgoc2lnbiA9PT0gMCkgPyAxIDogLTEpICogTWF0aC5wb3coMiwgZXhwb25lbnQgLSBiaWFzKSAqIG1hbnRpc3NhO1xufTtcblxudmFyIHBhcnNlSW50MTYgPSBmdW5jdGlvbih2YWx1ZSkge1xuICBpZiAocGFyc2VCaXRzKHZhbHVlLCAxKSA9PSAxKSB7XG4gICAgcmV0dXJuIC0xICogKHBhcnNlQml0cyh2YWx1ZSwgMTUsIDEsIHRydWUpICsgMSk7XG4gIH1cblxuICByZXR1cm4gcGFyc2VCaXRzKHZhbHVlLCAxNSwgMSk7XG59O1xuXG52YXIgcGFyc2VJbnQzMiA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIGlmIChwYXJzZUJpdHModmFsdWUsIDEpID09IDEpIHtcbiAgICByZXR1cm4gLTEgKiAocGFyc2VCaXRzKHZhbHVlLCAzMSwgMSwgdHJ1ZSkgKyAxKTtcbiAgfVxuXG4gIHJldHVybiBwYXJzZUJpdHModmFsdWUsIDMxLCAxKTtcbn07XG5cbnZhciBwYXJzZUZsb2F0MzIgPSBmdW5jdGlvbih2YWx1ZSkge1xuICByZXR1cm4gcGFyc2VGbG9hdEZyb21CaXRzKHZhbHVlLCAyMywgOCk7XG59O1xuXG52YXIgcGFyc2VGbG9hdDY0ID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgcmV0dXJuIHBhcnNlRmxvYXRGcm9tQml0cyh2YWx1ZSwgNTIsIDExKTtcbn07XG5cbnZhciBwYXJzZU51bWVyaWMgPSBmdW5jdGlvbih2YWx1ZSkge1xuICB2YXIgc2lnbiA9IHBhcnNlQml0cyh2YWx1ZSwgMTYsIDMyKTtcbiAgaWYgKHNpZ24gPT0gMHhjMDAwKSB7XG4gICAgcmV0dXJuIE5hTjtcbiAgfVxuXG4gIHZhciB3ZWlnaHQgPSBNYXRoLnBvdygxMDAwMCwgcGFyc2VCaXRzKHZhbHVlLCAxNiwgMTYpKTtcbiAgdmFyIHJlc3VsdCA9IDA7XG5cbiAgdmFyIGRpZ2l0cyA9IFtdO1xuICB2YXIgbmRpZ2l0cyA9IHBhcnNlQml0cyh2YWx1ZSwgMTYpO1xuICBmb3IgKHZhciBpID0gMDsgaSA8IG5kaWdpdHM7IGkrKykge1xuICAgIHJlc3VsdCArPSBwYXJzZUJpdHModmFsdWUsIDE2LCA2NCArICgxNiAqIGkpKSAqIHdlaWdodDtcbiAgICB3ZWlnaHQgLz0gMTAwMDA7XG4gIH1cblxuICB2YXIgc2NhbGUgPSBNYXRoLnBvdygxMCwgcGFyc2VCaXRzKHZhbHVlLCAxNiwgNDgpKTtcbiAgcmV0dXJuICgoc2lnbiA9PT0gMCkgPyAxIDogLTEpICogTWF0aC5yb3VuZChyZXN1bHQgKiBzY2FsZSkgLyBzY2FsZTtcbn07XG5cbnZhciBwYXJzZURhdGUgPSBmdW5jdGlvbihpc1VUQywgdmFsdWUpIHtcbiAgdmFyIHNpZ24gPSBwYXJzZUJpdHModmFsdWUsIDEpO1xuICB2YXIgcmF3VmFsdWUgPSBwYXJzZUJpdHModmFsdWUsIDYzLCAxKTtcblxuICAvLyBkaXNjYXJkIHVzZWNzIGFuZCBzaGlmdCBmcm9tIDIwMDAgdG8gMTk3MFxuICB2YXIgcmVzdWx0ID0gbmV3IERhdGUoKCgoc2lnbiA9PT0gMCkgPyAxIDogLTEpICogcmF3VmFsdWUgLyAxMDAwKSArIDk0NjY4NDgwMDAwMCk7XG5cbiAgaWYgKCFpc1VUQykge1xuICAgIHJlc3VsdC5zZXRUaW1lKHJlc3VsdC5nZXRUaW1lKCkgKyByZXN1bHQuZ2V0VGltZXpvbmVPZmZzZXQoKSAqIDYwMDAwKTtcbiAgfVxuXG4gIC8vIGFkZCBtaWNyb3NlY29uZHMgdG8gdGhlIGRhdGVcbiAgcmVzdWx0LnVzZWMgPSByYXdWYWx1ZSAlIDEwMDA7XG4gIHJlc3VsdC5nZXRNaWNyb1NlY29uZHMgPSBmdW5jdGlvbigpIHtcbiAgICByZXR1cm4gdGhpcy51c2VjO1xuICB9O1xuICByZXN1bHQuc2V0TWljcm9TZWNvbmRzID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgICB0aGlzLnVzZWMgPSB2YWx1ZTtcbiAgfTtcbiAgcmVzdWx0LmdldFVUQ01pY3JvU2Vjb25kcyA9IGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLnVzZWM7XG4gIH07XG5cbiAgcmV0dXJuIHJlc3VsdDtcbn07XG5cbnZhciBwYXJzZUFycmF5ID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgdmFyIGRpbSA9IHBhcnNlQml0cyh2YWx1ZSwgMzIpO1xuXG4gIHZhciBmbGFncyA9IHBhcnNlQml0cyh2YWx1ZSwgMzIsIDMyKTtcbiAgdmFyIGVsZW1lbnRUeXBlID0gcGFyc2VCaXRzKHZhbHVlLCAzMiwgNjQpO1xuXG4gIHZhciBvZmZzZXQgPSA5NjtcbiAgdmFyIGRpbXMgPSBbXTtcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBkaW07IGkrKykge1xuICAgIC8vIHBhcnNlIGRpbWVuc2lvblxuICAgIGRpbXNbaV0gPSBwYXJzZUJpdHModmFsdWUsIDMyLCBvZmZzZXQpO1xuICAgIG9mZnNldCArPSAzMjtcblxuICAgIC8vIGlnbm9yZSBsb3dlciBib3VuZHNcbiAgICBvZmZzZXQgKz0gMzI7XG4gIH1cblxuICB2YXIgcGFyc2VFbGVtZW50ID0gZnVuY3Rpb24oZWxlbWVudFR5cGUpIHtcbiAgICAvLyBwYXJzZSBjb250ZW50IGxlbmd0aFxuICAgIHZhciBsZW5ndGggPSBwYXJzZUJpdHModmFsdWUsIDMyLCBvZmZzZXQpO1xuICAgIG9mZnNldCArPSAzMjtcblxuICAgIC8vIHBhcnNlIG51bGwgdmFsdWVzXG4gICAgaWYgKGxlbmd0aCA9PSAweGZmZmZmZmZmKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG5cbiAgICB2YXIgcmVzdWx0O1xuICAgIGlmICgoZWxlbWVudFR5cGUgPT0gMHgxNykgfHwgKGVsZW1lbnRUeXBlID09IDB4MTQpKSB7XG4gICAgICAvLyBpbnQvYmlnaW50XG4gICAgICByZXN1bHQgPSBwYXJzZUJpdHModmFsdWUsIGxlbmd0aCAqIDgsIG9mZnNldCk7XG4gICAgICBvZmZzZXQgKz0gbGVuZ3RoICogODtcbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIGVsc2UgaWYgKGVsZW1lbnRUeXBlID09IDB4MTkpIHtcbiAgICAgIC8vIHN0cmluZ1xuICAgICAgcmVzdWx0ID0gdmFsdWUudG9TdHJpbmcodGhpcy5lbmNvZGluZywgb2Zmc2V0ID4+IDMsIChvZmZzZXQgKz0gKGxlbmd0aCA8PCAzKSkgPj4gMyk7XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIGNvbnNvbGUubG9nKFwiRVJST1I6IEVsZW1lbnRUeXBlIG5vdCBpbXBsZW1lbnRlZDogXCIgKyBlbGVtZW50VHlwZSk7XG4gICAgfVxuICB9O1xuXG4gIHZhciBwYXJzZSA9IGZ1bmN0aW9uKGRpbWVuc2lvbiwgZWxlbWVudFR5cGUpIHtcbiAgICB2YXIgYXJyYXkgPSBbXTtcbiAgICB2YXIgaTtcblxuICAgIGlmIChkaW1lbnNpb24ubGVuZ3RoID4gMSkge1xuICAgICAgdmFyIGNvdW50ID0gZGltZW5zaW9uLnNoaWZ0KCk7XG4gICAgICBmb3IgKGkgPSAwOyBpIDwgY291bnQ7IGkrKykge1xuICAgICAgICBhcnJheVtpXSA9IHBhcnNlKGRpbWVuc2lvbiwgZWxlbWVudFR5cGUpO1xuICAgICAgfVxuICAgICAgZGltZW5zaW9uLnVuc2hpZnQoY291bnQpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIGZvciAoaSA9IDA7IGkgPCBkaW1lbnNpb25bMF07IGkrKykge1xuICAgICAgICBhcnJheVtpXSA9IHBhcnNlRWxlbWVudChlbGVtZW50VHlwZSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGFycmF5O1xuICB9O1xuXG4gIHJldHVybiBwYXJzZShkaW1zLCBlbGVtZW50VHlwZSk7XG59O1xuXG52YXIgcGFyc2VUZXh0ID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgcmV0dXJuIHZhbHVlLnRvU3RyaW5nKCd1dGY4Jyk7XG59O1xuXG52YXIgcGFyc2VCb29sID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgaWYodmFsdWUgPT09IG51bGwpIHJldHVybiBudWxsO1xuICByZXR1cm4gKHBhcnNlQml0cyh2YWx1ZSwgOCkgPiAwKTtcbn07XG5cbnZhciBpbml0ID0gZnVuY3Rpb24ocmVnaXN0ZXIpIHtcbiAgcmVnaXN0ZXIoMjAsIHBhcnNlSW50NjQpO1xuICByZWdpc3RlcigyMSwgcGFyc2VJbnQxNik7XG4gIHJlZ2lzdGVyKDIzLCBwYXJzZUludDMyKTtcbiAgcmVnaXN0ZXIoMjYsIHBhcnNlSW50MzIpO1xuICByZWdpc3RlcigxNzAwLCBwYXJzZU51bWVyaWMpO1xuICByZWdpc3Rlcig3MDAsIHBhcnNlRmxvYXQzMik7XG4gIHJlZ2lzdGVyKDcwMSwgcGFyc2VGbG9hdDY0KTtcbiAgcmVnaXN0ZXIoMTYsIHBhcnNlQm9vbCk7XG4gIHJlZ2lzdGVyKDExMTQsIHBhcnNlRGF0ZS5iaW5kKG51bGwsIGZhbHNlKSk7XG4gIHJlZ2lzdGVyKDExODQsIHBhcnNlRGF0ZS5iaW5kKG51bGwsIHRydWUpKTtcbiAgcmVnaXN0ZXIoMTAwMCwgcGFyc2VBcnJheSk7XG4gIHJlZ2lzdGVyKDEwMDcsIHBhcnNlQXJyYXkpO1xuICByZWdpc3RlcigxMDE2LCBwYXJzZUFycmF5KTtcbiAgcmVnaXN0ZXIoMTAwOCwgcGFyc2VBcnJheSk7XG4gIHJlZ2lzdGVyKDEwMDksIHBhcnNlQXJyYXkpO1xuICByZWdpc3RlcigyNSwgcGFyc2VUZXh0KTtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICBpbml0OiBpbml0XG59O1xuIiwiLyoqXG4gKiBGb2xsb3dpbmcgcXVlcnkgd2FzIHVzZWQgdG8gZ2VuZXJhdGUgdGhpcyBmaWxlOlxuXG4gU0VMRUNUIGpzb25fb2JqZWN0X2FnZyhVUFBFUihQVC50eXBuYW1lKSwgUFQub2lkOjppbnQ0IE9SREVSIEJZIHB0Lm9pZClcbiBGUk9NIHBnX3R5cGUgUFRcbiBXSEVSRSB0eXBuYW1lc3BhY2UgPSAoU0VMRUNUIHBnbi5vaWQgRlJPTSBwZ19uYW1lc3BhY2UgcGduIFdIRVJFIG5zcG5hbWUgPSAncGdfY2F0YWxvZycpIC0tIFRha2Ugb25seSBidWlsdGluZyBQb3N0Z3JlcyB0eXBlcyB3aXRoIHN0YWJsZSBPSUQgKGV4dGVuc2lvbiB0eXBlcyBhcmUgbm90IGd1YXJhbnRlZCB0byBiZSBzdGFibGUpXG4gQU5EIHR5cHR5cGUgPSAnYicgLS0gT25seSBiYXNpYyB0eXBlc1xuIEFORCB0eXBlbGVtID0gMCAtLSBJZ25vcmUgYWxpYXNlc1xuIEFORCB0eXBpc2RlZmluZWQgLS0gSWdub3JlIHVuZGVmaW5lZCB0eXBlc1xuICovXG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICAgIEJPT0w6IDE2LFxuICAgIEJZVEVBOiAxNyxcbiAgICBDSEFSOiAxOCxcbiAgICBJTlQ4OiAyMCxcbiAgICBJTlQyOiAyMSxcbiAgICBJTlQ0OiAyMyxcbiAgICBSRUdQUk9DOiAyNCxcbiAgICBURVhUOiAyNSxcbiAgICBPSUQ6IDI2LFxuICAgIFRJRDogMjcsXG4gICAgWElEOiAyOCxcbiAgICBDSUQ6IDI5LFxuICAgIEpTT046IDExNCxcbiAgICBYTUw6IDE0MixcbiAgICBQR19OT0RFX1RSRUU6IDE5NCxcbiAgICBTTUdSOiAyMTAsXG4gICAgUEFUSDogNjAyLFxuICAgIFBPTFlHT046IDYwNCxcbiAgICBDSURSOiA2NTAsXG4gICAgRkxPQVQ0OiA3MDAsXG4gICAgRkxPQVQ4OiA3MDEsXG4gICAgQUJTVElNRTogNzAyLFxuICAgIFJFTFRJTUU6IDcwMyxcbiAgICBUSU5URVJWQUw6IDcwNCxcbiAgICBDSVJDTEU6IDcxOCxcbiAgICBNQUNBRERSODogNzc0LFxuICAgIE1PTkVZOiA3OTAsXG4gICAgTUFDQUREUjogODI5LFxuICAgIElORVQ6IDg2OSxcbiAgICBBQ0xJVEVNOiAxMDMzLFxuICAgIEJQQ0hBUjogMTA0MixcbiAgICBWQVJDSEFSOiAxMDQzLFxuICAgIERBVEU6IDEwODIsXG4gICAgVElNRTogMTA4MyxcbiAgICBUSU1FU1RBTVA6IDExMTQsXG4gICAgVElNRVNUQU1QVFo6IDExODQsXG4gICAgSU5URVJWQUw6IDExODYsXG4gICAgVElNRVRaOiAxMjY2LFxuICAgIEJJVDogMTU2MCxcbiAgICBWQVJCSVQ6IDE1NjIsXG4gICAgTlVNRVJJQzogMTcwMCxcbiAgICBSRUZDVVJTT1I6IDE3OTAsXG4gICAgUkVHUFJPQ0VEVVJFOiAyMjAyLFxuICAgIFJFR09QRVI6IDIyMDMsXG4gICAgUkVHT1BFUkFUT1I6IDIyMDQsXG4gICAgUkVHQ0xBU1M6IDIyMDUsXG4gICAgUkVHVFlQRTogMjIwNixcbiAgICBVVUlEOiAyOTUwLFxuICAgIFRYSURfU05BUFNIT1Q6IDI5NzAsXG4gICAgUEdfTFNOOiAzMjIwLFxuICAgIFBHX05ESVNUSU5DVDogMzM2MSxcbiAgICBQR19ERVBFTkRFTkNJRVM6IDM0MDIsXG4gICAgVFNWRUNUT1I6IDM2MTQsXG4gICAgVFNRVUVSWTogMzYxNSxcbiAgICBHVFNWRUNUT1I6IDM2NDIsXG4gICAgUkVHQ09ORklHOiAzNzM0LFxuICAgIFJFR0RJQ1RJT05BUlk6IDM3NjksXG4gICAgSlNPTkI6IDM4MDIsXG4gICAgUkVHTkFNRVNQQUNFOiA0MDg5LFxuICAgIFJFR1JPTEU6IDQwOTZcbn07XG4iLCJ2YXIgYXJyYXkgPSByZXF1aXJlKCdwb3N0Z3Jlcy1hcnJheScpXG52YXIgYXJyYXlQYXJzZXIgPSByZXF1aXJlKCcuL2FycmF5UGFyc2VyJyk7XG52YXIgcGFyc2VEYXRlID0gcmVxdWlyZSgncG9zdGdyZXMtZGF0ZScpO1xudmFyIHBhcnNlSW50ZXJ2YWwgPSByZXF1aXJlKCdwb3N0Z3Jlcy1pbnRlcnZhbCcpO1xudmFyIHBhcnNlQnl0ZUEgPSByZXF1aXJlKCdwb3N0Z3Jlcy1ieXRlYScpO1xuXG5mdW5jdGlvbiBhbGxvd051bGwgKGZuKSB7XG4gIHJldHVybiBmdW5jdGlvbiBudWxsQWxsb3dlZCAodmFsdWUpIHtcbiAgICBpZiAodmFsdWUgPT09IG51bGwpIHJldHVybiB2YWx1ZVxuICAgIHJldHVybiBmbih2YWx1ZSlcbiAgfVxufVxuXG5mdW5jdGlvbiBwYXJzZUJvb2wgKHZhbHVlKSB7XG4gIGlmICh2YWx1ZSA9PT0gbnVsbCkgcmV0dXJuIHZhbHVlXG4gIHJldHVybiB2YWx1ZSA9PT0gJ1RSVUUnIHx8XG4gICAgdmFsdWUgPT09ICd0JyB8fFxuICAgIHZhbHVlID09PSAndHJ1ZScgfHxcbiAgICB2YWx1ZSA9PT0gJ3knIHx8XG4gICAgdmFsdWUgPT09ICd5ZXMnIHx8XG4gICAgdmFsdWUgPT09ICdvbicgfHxcbiAgICB2YWx1ZSA9PT0gJzEnO1xufVxuXG5mdW5jdGlvbiBwYXJzZUJvb2xBcnJheSAodmFsdWUpIHtcbiAgaWYgKCF2YWx1ZSkgcmV0dXJuIG51bGxcbiAgcmV0dXJuIGFycmF5LnBhcnNlKHZhbHVlLCBwYXJzZUJvb2wpXG59XG5cbmZ1bmN0aW9uIHBhcnNlQmFzZVRlbkludCAoc3RyaW5nKSB7XG4gIHJldHVybiBwYXJzZUludChzdHJpbmcsIDEwKVxufVxuXG5mdW5jdGlvbiBwYXJzZUludGVnZXJBcnJheSAodmFsdWUpIHtcbiAgaWYgKCF2YWx1ZSkgcmV0dXJuIG51bGxcbiAgcmV0dXJuIGFycmF5LnBhcnNlKHZhbHVlLCBhbGxvd051bGwocGFyc2VCYXNlVGVuSW50KSlcbn1cblxuZnVuY3Rpb24gcGFyc2VCaWdJbnRlZ2VyQXJyYXkgKHZhbHVlKSB7XG4gIGlmICghdmFsdWUpIHJldHVybiBudWxsXG4gIHJldHVybiBhcnJheS5wYXJzZSh2YWx1ZSwgYWxsb3dOdWxsKGZ1bmN0aW9uIChlbnRyeSkge1xuICAgIHJldHVybiBwYXJzZUJpZ0ludGVnZXIoZW50cnkpLnRyaW0oKVxuICB9KSlcbn1cblxudmFyIHBhcnNlUG9pbnRBcnJheSA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIGlmKCF2YWx1ZSkgeyByZXR1cm4gbnVsbDsgfVxuICB2YXIgcCA9IGFycmF5UGFyc2VyLmNyZWF0ZSh2YWx1ZSwgZnVuY3Rpb24oZW50cnkpIHtcbiAgICBpZihlbnRyeSAhPT0gbnVsbCkge1xuICAgICAgZW50cnkgPSBwYXJzZVBvaW50KGVudHJ5KTtcbiAgICB9XG4gICAgcmV0dXJuIGVudHJ5O1xuICB9KTtcblxuICByZXR1cm4gcC5wYXJzZSgpO1xufTtcblxudmFyIHBhcnNlRmxvYXRBcnJheSA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIGlmKCF2YWx1ZSkgeyByZXR1cm4gbnVsbDsgfVxuICB2YXIgcCA9IGFycmF5UGFyc2VyLmNyZWF0ZSh2YWx1ZSwgZnVuY3Rpb24oZW50cnkpIHtcbiAgICBpZihlbnRyeSAhPT0gbnVsbCkge1xuICAgICAgZW50cnkgPSBwYXJzZUZsb2F0KGVudHJ5KTtcbiAgICB9XG4gICAgcmV0dXJuIGVudHJ5O1xuICB9KTtcblxuICByZXR1cm4gcC5wYXJzZSgpO1xufTtcblxudmFyIHBhcnNlU3RyaW5nQXJyYXkgPSBmdW5jdGlvbih2YWx1ZSkge1xuICBpZighdmFsdWUpIHsgcmV0dXJuIG51bGw7IH1cblxuICB2YXIgcCA9IGFycmF5UGFyc2VyLmNyZWF0ZSh2YWx1ZSk7XG4gIHJldHVybiBwLnBhcnNlKCk7XG59O1xuXG52YXIgcGFyc2VEYXRlQXJyYXkgPSBmdW5jdGlvbih2YWx1ZSkge1xuICBpZiAoIXZhbHVlKSB7IHJldHVybiBudWxsOyB9XG5cbiAgdmFyIHAgPSBhcnJheVBhcnNlci5jcmVhdGUodmFsdWUsIGZ1bmN0aW9uKGVudHJ5KSB7XG4gICAgaWYgKGVudHJ5ICE9PSBudWxsKSB7XG4gICAgICBlbnRyeSA9IHBhcnNlRGF0ZShlbnRyeSk7XG4gICAgfVxuICAgIHJldHVybiBlbnRyeTtcbiAgfSk7XG5cbiAgcmV0dXJuIHAucGFyc2UoKTtcbn07XG5cbnZhciBwYXJzZUludGVydmFsQXJyYXkgPSBmdW5jdGlvbih2YWx1ZSkge1xuICBpZiAoIXZhbHVlKSB7IHJldHVybiBudWxsOyB9XG5cbiAgdmFyIHAgPSBhcnJheVBhcnNlci5jcmVhdGUodmFsdWUsIGZ1bmN0aW9uKGVudHJ5KSB7XG4gICAgaWYgKGVudHJ5ICE9PSBudWxsKSB7XG4gICAgICBlbnRyeSA9IHBhcnNlSW50ZXJ2YWwoZW50cnkpO1xuICAgIH1cbiAgICByZXR1cm4gZW50cnk7XG4gIH0pO1xuXG4gIHJldHVybiBwLnBhcnNlKCk7XG59O1xuXG52YXIgcGFyc2VCeXRlQUFycmF5ID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgaWYgKCF2YWx1ZSkgeyByZXR1cm4gbnVsbDsgfVxuXG4gIHJldHVybiBhcnJheS5wYXJzZSh2YWx1ZSwgYWxsb3dOdWxsKHBhcnNlQnl0ZUEpKTtcbn07XG5cbnZhciBwYXJzZUludGVnZXIgPSBmdW5jdGlvbih2YWx1ZSkge1xuICByZXR1cm4gcGFyc2VJbnQodmFsdWUsIDEwKTtcbn07XG5cbnZhciBwYXJzZUJpZ0ludGVnZXIgPSBmdW5jdGlvbih2YWx1ZSkge1xuICB2YXIgdmFsU3RyID0gU3RyaW5nKHZhbHVlKTtcbiAgaWYgKC9eXFxkKyQvLnRlc3QodmFsU3RyKSkgeyByZXR1cm4gdmFsU3RyOyB9XG4gIHJldHVybiB2YWx1ZTtcbn07XG5cbnZhciBwYXJzZUpzb25BcnJheSA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIGlmICghdmFsdWUpIHsgcmV0dXJuIG51bGw7IH1cblxuICByZXR1cm4gYXJyYXkucGFyc2UodmFsdWUsIGFsbG93TnVsbChKU09OLnBhcnNlKSk7XG59O1xuXG52YXIgcGFyc2VQb2ludCA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIGlmICh2YWx1ZVswXSAhPT0gJygnKSB7IHJldHVybiBudWxsOyB9XG5cbiAgdmFsdWUgPSB2YWx1ZS5zdWJzdHJpbmcoIDEsIHZhbHVlLmxlbmd0aCAtIDEgKS5zcGxpdCgnLCcpO1xuXG4gIHJldHVybiB7XG4gICAgeDogcGFyc2VGbG9hdCh2YWx1ZVswXSlcbiAgLCB5OiBwYXJzZUZsb2F0KHZhbHVlWzFdKVxuICB9O1xufTtcblxudmFyIHBhcnNlQ2lyY2xlID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgaWYgKHZhbHVlWzBdICE9PSAnPCcgJiYgdmFsdWVbMV0gIT09ICcoJykgeyByZXR1cm4gbnVsbDsgfVxuXG4gIHZhciBwb2ludCA9ICcoJztcbiAgdmFyIHJhZGl1cyA9ICcnO1xuICB2YXIgcG9pbnRQYXJzZWQgPSBmYWxzZTtcbiAgZm9yICh2YXIgaSA9IDI7IGkgPCB2YWx1ZS5sZW5ndGggLSAxOyBpKyspe1xuICAgIGlmICghcG9pbnRQYXJzZWQpIHtcbiAgICAgIHBvaW50ICs9IHZhbHVlW2ldO1xuICAgIH1cblxuICAgIGlmICh2YWx1ZVtpXSA9PT0gJyknKSB7XG4gICAgICBwb2ludFBhcnNlZCA9IHRydWU7XG4gICAgICBjb250aW51ZTtcbiAgICB9IGVsc2UgaWYgKCFwb2ludFBhcnNlZCkge1xuICAgICAgY29udGludWU7XG4gICAgfVxuXG4gICAgaWYgKHZhbHVlW2ldID09PSAnLCcpe1xuICAgICAgY29udGludWU7XG4gICAgfVxuXG4gICAgcmFkaXVzICs9IHZhbHVlW2ldO1xuICB9XG4gIHZhciByZXN1bHQgPSBwYXJzZVBvaW50KHBvaW50KTtcbiAgcmVzdWx0LnJhZGl1cyA9IHBhcnNlRmxvYXQocmFkaXVzKTtcblxuICByZXR1cm4gcmVzdWx0O1xufTtcblxudmFyIGluaXQgPSBmdW5jdGlvbihyZWdpc3Rlcikge1xuICByZWdpc3RlcigyMCwgcGFyc2VCaWdJbnRlZ2VyKTsgLy8gaW50OFxuICByZWdpc3RlcigyMSwgcGFyc2VJbnRlZ2VyKTsgLy8gaW50MlxuICByZWdpc3RlcigyMywgcGFyc2VJbnRlZ2VyKTsgLy8gaW50NFxuICByZWdpc3RlcigyNiwgcGFyc2VJbnRlZ2VyKTsgLy8gb2lkXG4gIHJlZ2lzdGVyKDcwMCwgcGFyc2VGbG9hdCk7IC8vIGZsb2F0NC9yZWFsXG4gIHJlZ2lzdGVyKDcwMSwgcGFyc2VGbG9hdCk7IC8vIGZsb2F0OC9kb3VibGVcbiAgcmVnaXN0ZXIoMTYsIHBhcnNlQm9vbCk7XG4gIHJlZ2lzdGVyKDEwODIsIHBhcnNlRGF0ZSk7IC8vIGRhdGVcbiAgcmVnaXN0ZXIoMTExNCwgcGFyc2VEYXRlKTsgLy8gdGltZXN0YW1wIHdpdGhvdXQgdGltZXpvbmVcbiAgcmVnaXN0ZXIoMTE4NCwgcGFyc2VEYXRlKTsgLy8gdGltZXN0YW1wXG4gIHJlZ2lzdGVyKDYwMCwgcGFyc2VQb2ludCk7IC8vIHBvaW50XG4gIHJlZ2lzdGVyKDY1MSwgcGFyc2VTdHJpbmdBcnJheSk7IC8vIGNpZHJbXVxuICByZWdpc3Rlcig3MTgsIHBhcnNlQ2lyY2xlKTsgLy8gY2lyY2xlXG4gIHJlZ2lzdGVyKDEwMDAsIHBhcnNlQm9vbEFycmF5KTtcbiAgcmVnaXN0ZXIoMTAwMSwgcGFyc2VCeXRlQUFycmF5KTtcbiAgcmVnaXN0ZXIoMTAwNSwgcGFyc2VJbnRlZ2VyQXJyYXkpOyAvLyBfaW50MlxuICByZWdpc3RlcigxMDA3LCBwYXJzZUludGVnZXJBcnJheSk7IC8vIF9pbnQ0XG4gIHJlZ2lzdGVyKDEwMjgsIHBhcnNlSW50ZWdlckFycmF5KTsgLy8gb2lkW11cbiAgcmVnaXN0ZXIoMTAxNiwgcGFyc2VCaWdJbnRlZ2VyQXJyYXkpOyAvLyBfaW50OFxuICByZWdpc3RlcigxMDE3LCBwYXJzZVBvaW50QXJyYXkpOyAvLyBwb2ludFtdXG4gIHJlZ2lzdGVyKDEwMjEsIHBhcnNlRmxvYXRBcnJheSk7IC8vIF9mbG9hdDRcbiAgcmVnaXN0ZXIoMTAyMiwgcGFyc2VGbG9hdEFycmF5KTsgLy8gX2Zsb2F0OFxuICByZWdpc3RlcigxMjMxLCBwYXJzZUZsb2F0QXJyYXkpOyAvLyBfbnVtZXJpY1xuICByZWdpc3RlcigxMDE0LCBwYXJzZVN0cmluZ0FycmF5KTsgLy9jaGFyXG4gIHJlZ2lzdGVyKDEwMTUsIHBhcnNlU3RyaW5nQXJyYXkpOyAvL3ZhcmNoYXJcbiAgcmVnaXN0ZXIoMTAwOCwgcGFyc2VTdHJpbmdBcnJheSk7XG4gIHJlZ2lzdGVyKDEwMDksIHBhcnNlU3RyaW5nQXJyYXkpO1xuICByZWdpc3RlcigxMDQwLCBwYXJzZVN0cmluZ0FycmF5KTsgLy8gbWFjYWRkcltdXG4gIHJlZ2lzdGVyKDEwNDEsIHBhcnNlU3RyaW5nQXJyYXkpOyAvLyBpbmV0W11cbiAgcmVnaXN0ZXIoMTExNSwgcGFyc2VEYXRlQXJyYXkpOyAvLyB0aW1lc3RhbXAgd2l0aG91dCB0aW1lIHpvbmVbXVxuICByZWdpc3RlcigxMTgyLCBwYXJzZURhdGVBcnJheSk7IC8vIF9kYXRlXG4gIHJlZ2lzdGVyKDExODUsIHBhcnNlRGF0ZUFycmF5KTsgLy8gdGltZXN0YW1wIHdpdGggdGltZSB6b25lW11cbiAgcmVnaXN0ZXIoMTE4NiwgcGFyc2VJbnRlcnZhbCk7XG4gIHJlZ2lzdGVyKDExODcsIHBhcnNlSW50ZXJ2YWxBcnJheSk7XG4gIHJlZ2lzdGVyKDE3LCBwYXJzZUJ5dGVBKTtcbiAgcmVnaXN0ZXIoMTE0LCBKU09OLnBhcnNlLmJpbmQoSlNPTikpOyAvLyBqc29uXG4gIHJlZ2lzdGVyKDM4MDIsIEpTT04ucGFyc2UuYmluZChKU09OKSk7IC8vIGpzb25iXG4gIHJlZ2lzdGVyKDE5OSwgcGFyc2VKc29uQXJyYXkpOyAvLyBqc29uW11cbiAgcmVnaXN0ZXIoMzgwNywgcGFyc2VKc29uQXJyYXkpOyAvLyBqc29uYltdXG4gIHJlZ2lzdGVyKDM5MDcsIHBhcnNlU3RyaW5nQXJyYXkpOyAvLyBudW1yYW5nZVtdXG4gIHJlZ2lzdGVyKDI5NTEsIHBhcnNlU3RyaW5nQXJyYXkpOyAvLyB1dWlkW11cbiAgcmVnaXN0ZXIoNzkxLCBwYXJzZVN0cmluZ0FycmF5KTsgLy8gbW9uZXlbXVxuICByZWdpc3RlcigxMTgzLCBwYXJzZVN0cmluZ0FycmF5KTsgLy8gdGltZVtdXG4gIHJlZ2lzdGVyKDEyNzAsIHBhcnNlU3RyaW5nQXJyYXkpOyAvLyB0aW1ldHpbXVxufTtcblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gIGluaXQ6IGluaXRcbn07XG4iLCIndXNlIHN0cmljdCdcblxudmFyIEV2ZW50RW1pdHRlciA9IHJlcXVpcmUoJ2V2ZW50cycpLkV2ZW50RW1pdHRlclxudmFyIHV0aWwgPSByZXF1aXJlKCd1dGlsJylcbnZhciB1dGlscyA9IHJlcXVpcmUoJy4vdXRpbHMnKVxudmFyIHNhc2wgPSByZXF1aXJlKCcuL3Nhc2wnKVxudmFyIHBnUGFzcyA9IHJlcXVpcmUoJ3BncGFzcycpXG52YXIgVHlwZU92ZXJyaWRlcyA9IHJlcXVpcmUoJy4vdHlwZS1vdmVycmlkZXMnKVxuXG52YXIgQ29ubmVjdGlvblBhcmFtZXRlcnMgPSByZXF1aXJlKCcuL2Nvbm5lY3Rpb24tcGFyYW1ldGVycycpXG52YXIgUXVlcnkgPSByZXF1aXJlKCcuL3F1ZXJ5JylcbnZhciBkZWZhdWx0cyA9IHJlcXVpcmUoJy4vZGVmYXVsdHMnKVxudmFyIENvbm5lY3Rpb24gPSByZXF1aXJlKCcuL2Nvbm5lY3Rpb24nKVxuXG5jbGFzcyBDbGllbnQgZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBjb25zdHJ1Y3Rvcihjb25maWcpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzID0gbmV3IENvbm5lY3Rpb25QYXJhbWV0ZXJzKGNvbmZpZylcbiAgICB0aGlzLnVzZXIgPSB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLnVzZXJcbiAgICB0aGlzLmRhdGFiYXNlID0gdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy5kYXRhYmFzZVxuICAgIHRoaXMucG9ydCA9IHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMucG9ydFxuICAgIHRoaXMuaG9zdCA9IHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMuaG9zdFxuXG4gICAgLy8gXCJoaWRpbmdcIiB0aGUgcGFzc3dvcmQgc28gaXQgZG9lc24ndCBzaG93IHVwIGluIHN0YWNrIHRyYWNlc1xuICAgIC8vIG9yIGlmIHRoZSBjbGllbnQgaXMgY29uc29sZS5sb2dnZWRcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgJ3Bhc3N3b3JkJywge1xuICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIHZhbHVlOiB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLnBhc3N3b3JkLFxuICAgIH0pXG5cbiAgICB0aGlzLnJlcGxpY2F0aW9uID0gdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy5yZXBsaWNhdGlvblxuXG4gICAgdmFyIGMgPSBjb25maWcgfHwge31cblxuICAgIHRoaXMuX1Byb21pc2UgPSBjLlByb21pc2UgfHwgZ2xvYmFsLlByb21pc2VcbiAgICB0aGlzLl90eXBlcyA9IG5ldyBUeXBlT3ZlcnJpZGVzKGMudHlwZXMpXG4gICAgdGhpcy5fZW5kaW5nID0gZmFsc2VcbiAgICB0aGlzLl9jb25uZWN0aW5nID0gZmFsc2VcbiAgICB0aGlzLl9jb25uZWN0ZWQgPSBmYWxzZVxuICAgIHRoaXMuX2Nvbm5lY3Rpb25FcnJvciA9IGZhbHNlXG4gICAgdGhpcy5fcXVlcnlhYmxlID0gdHJ1ZVxuXG4gICAgdGhpcy5jb25uZWN0aW9uID1cbiAgICAgIGMuY29ubmVjdGlvbiB8fFxuICAgICAgbmV3IENvbm5lY3Rpb24oe1xuICAgICAgICBzdHJlYW06IGMuc3RyZWFtLFxuICAgICAgICBzc2w6IHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMuc3NsLFxuICAgICAgICBrZWVwQWxpdmU6IGMua2VlcEFsaXZlIHx8IGZhbHNlLFxuICAgICAgICBrZWVwQWxpdmVJbml0aWFsRGVsYXlNaWxsaXM6IGMua2VlcEFsaXZlSW5pdGlhbERlbGF5TWlsbGlzIHx8IDAsXG4gICAgICAgIGVuY29kaW5nOiB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLmNsaWVudF9lbmNvZGluZyB8fCAndXRmOCcsXG4gICAgICB9KVxuICAgIHRoaXMucXVlcnlRdWV1ZSA9IFtdXG4gICAgdGhpcy5iaW5hcnkgPSBjLmJpbmFyeSB8fCBkZWZhdWx0cy5iaW5hcnlcbiAgICB0aGlzLnByb2Nlc3NJRCA9IG51bGxcbiAgICB0aGlzLnNlY3JldEtleSA9IG51bGxcbiAgICB0aGlzLnNzbCA9IHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMuc3NsIHx8IGZhbHNlXG4gICAgLy8gQXMgd2l0aCBQYXNzd29yZCwgbWFrZSBTU0wtPktleSAodGhlIHByaXZhdGUga2V5KSBub24tZW51bWVyYWJsZS5cbiAgICAvLyBJdCB3b24ndCBzaG93IHVwIGluIHN0YWNrIHRyYWNlc1xuICAgIC8vIG9yIGlmIHRoZSBjbGllbnQgaXMgY29uc29sZS5sb2dnZWRcbiAgICBpZiAodGhpcy5zc2wgJiYgdGhpcy5zc2wua2V5KSB7XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcy5zc2wsICdrZXknLCB7XG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgfSlcbiAgICB9XG5cbiAgICB0aGlzLl9jb25uZWN0aW9uVGltZW91dE1pbGxpcyA9IGMuY29ubmVjdGlvblRpbWVvdXRNaWxsaXMgfHwgMFxuICB9XG5cbiAgX2Vycm9yQWxsUXVlcmllcyhlcnIpIHtcbiAgICBjb25zdCBlbnF1ZXVlRXJyb3IgPSAocXVlcnkpID0+IHtcbiAgICAgIHByb2Nlc3MubmV4dFRpY2soKCkgPT4ge1xuICAgICAgICBxdWVyeS5oYW5kbGVFcnJvcihlcnIsIHRoaXMuY29ubmVjdGlvbilcbiAgICAgIH0pXG4gICAgfVxuXG4gICAgaWYgKHRoaXMuYWN0aXZlUXVlcnkpIHtcbiAgICAgIGVucXVldWVFcnJvcih0aGlzLmFjdGl2ZVF1ZXJ5KVxuICAgICAgdGhpcy5hY3RpdmVRdWVyeSA9IG51bGxcbiAgICB9XG5cbiAgICB0aGlzLnF1ZXJ5UXVldWUuZm9yRWFjaChlbnF1ZXVlRXJyb3IpXG4gICAgdGhpcy5xdWVyeVF1ZXVlLmxlbmd0aCA9IDBcbiAgfVxuXG4gIF9jb25uZWN0KGNhbGxiYWNrKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzXG4gICAgdmFyIGNvbiA9IHRoaXMuY29ubmVjdGlvblxuICAgIHRoaXMuX2Nvbm5lY3Rpb25DYWxsYmFjayA9IGNhbGxiYWNrXG5cbiAgICBpZiAodGhpcy5fY29ubmVjdGluZyB8fCB0aGlzLl9jb25uZWN0ZWQpIHtcbiAgICAgIGNvbnN0IGVyciA9IG5ldyBFcnJvcignQ2xpZW50IGhhcyBhbHJlYWR5IGJlZW4gY29ubmVjdGVkLiBZb3UgY2Fubm90IHJldXNlIGEgY2xpZW50LicpXG4gICAgICBwcm9jZXNzLm5leHRUaWNrKCgpID0+IHtcbiAgICAgICAgY2FsbGJhY2soZXJyKVxuICAgICAgfSlcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICB0aGlzLl9jb25uZWN0aW5nID0gdHJ1ZVxuXG4gICAgdGhpcy5jb25uZWN0aW9uVGltZW91dEhhbmRsZVxuICAgIGlmICh0aGlzLl9jb25uZWN0aW9uVGltZW91dE1pbGxpcyA+IDApIHtcbiAgICAgIHRoaXMuY29ubmVjdGlvblRpbWVvdXRIYW5kbGUgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgY29uLl9lbmRpbmcgPSB0cnVlXG4gICAgICAgIGNvbi5zdHJlYW0uZGVzdHJveShuZXcgRXJyb3IoJ3RpbWVvdXQgZXhwaXJlZCcpKVxuICAgICAgfSwgdGhpcy5fY29ubmVjdGlvblRpbWVvdXRNaWxsaXMpXG4gICAgfVxuXG4gICAgaWYgKHRoaXMuaG9zdCAmJiB0aGlzLmhvc3QuaW5kZXhPZignLycpID09PSAwKSB7XG4gICAgICBjb24uY29ubmVjdCh0aGlzLmhvc3QgKyAnLy5zLlBHU1FMLicgKyB0aGlzLnBvcnQpXG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbi5jb25uZWN0KHRoaXMucG9ydCwgdGhpcy5ob3N0KVxuICAgIH1cblxuICAgIC8vIG9uY2UgY29ubmVjdGlvbiBpcyBlc3RhYmxpc2hlZCBzZW5kIHN0YXJ0dXAgbWVzc2FnZVxuICAgIGNvbi5vbignY29ubmVjdCcsIGZ1bmN0aW9uICgpIHtcbiAgICAgIGlmIChzZWxmLnNzbCkge1xuICAgICAgICBjb24ucmVxdWVzdFNzbCgpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb24uc3RhcnR1cChzZWxmLmdldFN0YXJ0dXBDb25mKCkpXG4gICAgICB9XG4gICAgfSlcblxuICAgIGNvbi5vbignc3NsY29ubmVjdCcsIGZ1bmN0aW9uICgpIHtcbiAgICAgIGNvbi5zdGFydHVwKHNlbGYuZ2V0U3RhcnR1cENvbmYoKSlcbiAgICB9KVxuXG4gICAgdGhpcy5fYXR0YWNoTGlzdGVuZXJzKGNvbilcblxuICAgIGNvbi5vbmNlKCdlbmQnLCAoKSA9PiB7XG4gICAgICBjb25zdCBlcnJvciA9IHRoaXMuX2VuZGluZyA/IG5ldyBFcnJvcignQ29ubmVjdGlvbiB0ZXJtaW5hdGVkJykgOiBuZXcgRXJyb3IoJ0Nvbm5lY3Rpb24gdGVybWluYXRlZCB1bmV4cGVjdGVkbHknKVxuXG4gICAgICBjbGVhclRpbWVvdXQodGhpcy5jb25uZWN0aW9uVGltZW91dEhhbmRsZSlcbiAgICAgIHRoaXMuX2Vycm9yQWxsUXVlcmllcyhlcnJvcilcblxuICAgICAgaWYgKCF0aGlzLl9lbmRpbmcpIHtcbiAgICAgICAgLy8gaWYgdGhlIGNvbm5lY3Rpb24gaXMgZW5kZWQgd2l0aG91dCB1cyBjYWxsaW5nIC5lbmQoKVxuICAgICAgICAvLyBvbiB0aGlzIGNsaWVudCB0aGVuIHdlIGhhdmUgYW4gdW5leHBlY3RlZCBkaXNjb25uZWN0aW9uXG4gICAgICAgIC8vIHRyZWF0IHRoaXMgYXMgYW4gZXJyb3IgdW5sZXNzIHdlJ3ZlIGFscmVhZHkgZW1pdHRlZCBhbiBlcnJvclxuICAgICAgICAvLyBkdXJpbmcgY29ubmVjdGlvbi5cbiAgICAgICAgaWYgKHRoaXMuX2Nvbm5lY3RpbmcgJiYgIXRoaXMuX2Nvbm5lY3Rpb25FcnJvcikge1xuICAgICAgICAgIGlmICh0aGlzLl9jb25uZWN0aW9uQ2FsbGJhY2spIHtcbiAgICAgICAgICAgIHRoaXMuX2Nvbm5lY3Rpb25DYWxsYmFjayhlcnJvcilcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5faGFuZGxlRXJyb3JFdmVudChlcnJvcilcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAoIXRoaXMuX2Nvbm5lY3Rpb25FcnJvcikge1xuICAgICAgICAgIHRoaXMuX2hhbmRsZUVycm9yRXZlbnQoZXJyb3IpXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgcHJvY2Vzcy5uZXh0VGljaygoKSA9PiB7XG4gICAgICAgIHRoaXMuZW1pdCgnZW5kJylcbiAgICAgIH0pXG4gICAgfSlcbiAgfVxuXG4gIGNvbm5lY3QoY2FsbGJhY2spIHtcbiAgICBpZiAoY2FsbGJhY2spIHtcbiAgICAgIHRoaXMuX2Nvbm5lY3QoY2FsbGJhY2spXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IHRoaXMuX1Byb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgdGhpcy5fY29ubmVjdCgoZXJyb3IpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgcmVqZWN0KGVycm9yKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlc29sdmUoKVxuICAgICAgICB9XG4gICAgICB9KVxuICAgIH0pXG4gIH1cblxuICBfYXR0YWNoTGlzdGVuZXJzKGNvbikge1xuICAgIC8vIHBhc3N3b3JkIHJlcXVlc3QgaGFuZGxpbmdcbiAgICBjb24ub24oJ2F1dGhlbnRpY2F0aW9uQ2xlYXJ0ZXh0UGFzc3dvcmQnLCB0aGlzLl9oYW5kbGVBdXRoQ2xlYXJ0ZXh0UGFzc3dvcmQuYmluZCh0aGlzKSlcbiAgICAvLyBwYXNzd29yZCByZXF1ZXN0IGhhbmRsaW5nXG4gICAgY29uLm9uKCdhdXRoZW50aWNhdGlvbk1ENVBhc3N3b3JkJywgdGhpcy5faGFuZGxlQXV0aE1ENVBhc3N3b3JkLmJpbmQodGhpcykpXG4gICAgLy8gcGFzc3dvcmQgcmVxdWVzdCBoYW5kbGluZyAoU0FTTClcbiAgICBjb24ub24oJ2F1dGhlbnRpY2F0aW9uU0FTTCcsIHRoaXMuX2hhbmRsZUF1dGhTQVNMLmJpbmQodGhpcykpXG4gICAgY29uLm9uKCdhdXRoZW50aWNhdGlvblNBU0xDb250aW51ZScsIHRoaXMuX2hhbmRsZUF1dGhTQVNMQ29udGludWUuYmluZCh0aGlzKSlcbiAgICBjb24ub24oJ2F1dGhlbnRpY2F0aW9uU0FTTEZpbmFsJywgdGhpcy5faGFuZGxlQXV0aFNBU0xGaW5hbC5iaW5kKHRoaXMpKVxuICAgIGNvbi5vbignYmFja2VuZEtleURhdGEnLCB0aGlzLl9oYW5kbGVCYWNrZW5kS2V5RGF0YS5iaW5kKHRoaXMpKVxuICAgIGNvbi5vbignZXJyb3InLCB0aGlzLl9oYW5kbGVFcnJvckV2ZW50LmJpbmQodGhpcykpXG4gICAgY29uLm9uKCdlcnJvck1lc3NhZ2UnLCB0aGlzLl9oYW5kbGVFcnJvck1lc3NhZ2UuYmluZCh0aGlzKSlcbiAgICBjb24ub24oJ3JlYWR5Rm9yUXVlcnknLCB0aGlzLl9oYW5kbGVSZWFkeUZvclF1ZXJ5LmJpbmQodGhpcykpXG4gICAgY29uLm9uKCdub3RpY2UnLCB0aGlzLl9oYW5kbGVOb3RpY2UuYmluZCh0aGlzKSlcbiAgICBjb24ub24oJ3Jvd0Rlc2NyaXB0aW9uJywgdGhpcy5faGFuZGxlUm93RGVzY3JpcHRpb24uYmluZCh0aGlzKSlcbiAgICBjb24ub24oJ2RhdGFSb3cnLCB0aGlzLl9oYW5kbGVEYXRhUm93LmJpbmQodGhpcykpXG4gICAgY29uLm9uKCdwb3J0YWxTdXNwZW5kZWQnLCB0aGlzLl9oYW5kbGVQb3J0YWxTdXNwZW5kZWQuYmluZCh0aGlzKSlcbiAgICBjb24ub24oJ2VtcHR5UXVlcnknLCB0aGlzLl9oYW5kbGVFbXB0eVF1ZXJ5LmJpbmQodGhpcykpXG4gICAgY29uLm9uKCdjb21tYW5kQ29tcGxldGUnLCB0aGlzLl9oYW5kbGVDb21tYW5kQ29tcGxldGUuYmluZCh0aGlzKSlcbiAgICBjb24ub24oJ3BhcnNlQ29tcGxldGUnLCB0aGlzLl9oYW5kbGVQYXJzZUNvbXBsZXRlLmJpbmQodGhpcykpXG4gICAgY29uLm9uKCdjb3B5SW5SZXNwb25zZScsIHRoaXMuX2hhbmRsZUNvcHlJblJlc3BvbnNlLmJpbmQodGhpcykpXG4gICAgY29uLm9uKCdjb3B5RGF0YScsIHRoaXMuX2hhbmRsZUNvcHlEYXRhLmJpbmQodGhpcykpXG4gICAgY29uLm9uKCdub3RpZmljYXRpb24nLCB0aGlzLl9oYW5kbGVOb3RpZmljYXRpb24uYmluZCh0aGlzKSlcbiAgfVxuXG4gIC8vIFRPRE8oYm1jKTogZGVwcmVjYXRlIHBncGFzcyBcImJ1aWx0IGluXCIgaW50ZWdyYXRpb24gc2luY2UgdGhpcy5wYXNzd29yZCBjYW4gYmUgYSBmdW5jdGlvblxuICAvLyBpdCBjYW4gYmUgc3VwcGxpZWQgYnkgdGhlIHVzZXIgaWYgcmVxdWlyZWQgLSB0aGlzIGlzIGEgYnJlYWtpbmcgY2hhbmdlIVxuICBfY2hlY2tQZ1Bhc3MoY2IpIHtcbiAgICBjb25zdCBjb24gPSB0aGlzLmNvbm5lY3Rpb25cbiAgICBpZiAodHlwZW9mIHRoaXMucGFzc3dvcmQgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIHRoaXMuX1Byb21pc2VcbiAgICAgICAgLnJlc29sdmUoKVxuICAgICAgICAudGhlbigoKSA9PiB0aGlzLnBhc3N3b3JkKCkpXG4gICAgICAgIC50aGVuKChwYXNzKSA9PiB7XG4gICAgICAgICAgaWYgKHBhc3MgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBwYXNzICE9PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgICBjb24uZW1pdCgnZXJyb3InLCBuZXcgVHlwZUVycm9yKCdQYXNzd29yZCBtdXN0IGJlIGEgc3RyaW5nJykpXG4gICAgICAgICAgICAgIHJldHVyblxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy5wYXNzd29yZCA9IHRoaXMucGFzc3dvcmQgPSBwYXNzXG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMucGFzc3dvcmQgPSB0aGlzLnBhc3N3b3JkID0gbnVsbFxuICAgICAgICAgIH1cbiAgICAgICAgICBjYigpXG4gICAgICAgIH0pXG4gICAgICAgIC5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgICAgY29uLmVtaXQoJ2Vycm9yJywgZXJyKVxuICAgICAgICB9KVxuICAgIH0gZWxzZSBpZiAodGhpcy5wYXNzd29yZCAhPT0gbnVsbCkge1xuICAgICAgY2IoKVxuICAgIH0gZWxzZSB7XG4gICAgICBwZ1Bhc3ModGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycywgKHBhc3MpID0+IHtcbiAgICAgICAgaWYgKHVuZGVmaW5lZCAhPT0gcGFzcykge1xuICAgICAgICAgIHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMucGFzc3dvcmQgPSB0aGlzLnBhc3N3b3JkID0gcGFzc1xuICAgICAgICB9XG4gICAgICAgIGNiKClcbiAgICAgIH0pXG4gICAgfVxuICB9XG5cbiAgX2hhbmRsZUF1dGhDbGVhcnRleHRQYXNzd29yZChtc2cpIHtcbiAgICB0aGlzLl9jaGVja1BnUGFzcygoKSA9PiB7XG4gICAgICB0aGlzLmNvbm5lY3Rpb24ucGFzc3dvcmQodGhpcy5wYXNzd29yZClcbiAgICB9KVxuICB9XG5cbiAgX2hhbmRsZUF1dGhNRDVQYXNzd29yZChtc2cpIHtcbiAgICB0aGlzLl9jaGVja1BnUGFzcygoKSA9PiB7XG4gICAgICBjb25zdCBoYXNoZWRQYXNzd29yZCA9IHV0aWxzLnBvc3RncmVzTWQ1UGFzc3dvcmRIYXNoKHRoaXMudXNlciwgdGhpcy5wYXNzd29yZCwgbXNnLnNhbHQpXG4gICAgICB0aGlzLmNvbm5lY3Rpb24ucGFzc3dvcmQoaGFzaGVkUGFzc3dvcmQpXG4gICAgfSlcbiAgfVxuXG4gIF9oYW5kbGVBdXRoU0FTTChtc2cpIHtcbiAgICB0aGlzLl9jaGVja1BnUGFzcygoKSA9PiB7XG4gICAgICB0aGlzLnNhc2xTZXNzaW9uID0gc2FzbC5zdGFydFNlc3Npb24obXNnLm1lY2hhbmlzbXMpXG4gICAgICB0aGlzLmNvbm5lY3Rpb24uc2VuZFNBU0xJbml0aWFsUmVzcG9uc2VNZXNzYWdlKHRoaXMuc2FzbFNlc3Npb24ubWVjaGFuaXNtLCB0aGlzLnNhc2xTZXNzaW9uLnJlc3BvbnNlKVxuICAgIH0pXG4gIH1cblxuICBfaGFuZGxlQXV0aFNBU0xDb250aW51ZShtc2cpIHtcbiAgICBzYXNsLmNvbnRpbnVlU2Vzc2lvbih0aGlzLnNhc2xTZXNzaW9uLCB0aGlzLnBhc3N3b3JkLCBtc2cuZGF0YSlcbiAgICB0aGlzLmNvbm5lY3Rpb24uc2VuZFNDUkFNQ2xpZW50RmluYWxNZXNzYWdlKHRoaXMuc2FzbFNlc3Npb24ucmVzcG9uc2UpXG4gIH1cblxuICBfaGFuZGxlQXV0aFNBU0xGaW5hbChtc2cpIHtcbiAgICBzYXNsLmZpbmFsaXplU2Vzc2lvbih0aGlzLnNhc2xTZXNzaW9uLCBtc2cuZGF0YSlcbiAgICB0aGlzLnNhc2xTZXNzaW9uID0gbnVsbFxuICB9XG5cbiAgX2hhbmRsZUJhY2tlbmRLZXlEYXRhKG1zZykge1xuICAgIHRoaXMucHJvY2Vzc0lEID0gbXNnLnByb2Nlc3NJRFxuICAgIHRoaXMuc2VjcmV0S2V5ID0gbXNnLnNlY3JldEtleVxuICB9XG5cbiAgX2hhbmRsZVJlYWR5Rm9yUXVlcnkobXNnKSB7XG4gICAgaWYgKHRoaXMuX2Nvbm5lY3RpbmcpIHtcbiAgICAgIHRoaXMuX2Nvbm5lY3RpbmcgPSBmYWxzZVxuICAgICAgdGhpcy5fY29ubmVjdGVkID0gdHJ1ZVxuICAgICAgY2xlYXJUaW1lb3V0KHRoaXMuY29ubmVjdGlvblRpbWVvdXRIYW5kbGUpXG5cbiAgICAgIC8vIHByb2Nlc3MgcG9zc2libGUgY2FsbGJhY2sgYXJndW1lbnQgdG8gQ2xpZW50I2Nvbm5lY3RcbiAgICAgIGlmICh0aGlzLl9jb25uZWN0aW9uQ2FsbGJhY2spIHtcbiAgICAgICAgdGhpcy5fY29ubmVjdGlvbkNhbGxiYWNrKG51bGwsIHRoaXMpXG4gICAgICAgIC8vIHJlbW92ZSBjYWxsYmFjayBmb3IgcHJvcGVyIGVycm9yIGhhbmRsaW5nXG4gICAgICAgIC8vIGFmdGVyIHRoZSBjb25uZWN0IGV2ZW50XG4gICAgICAgIHRoaXMuX2Nvbm5lY3Rpb25DYWxsYmFjayA9IG51bGxcbiAgICAgIH1cbiAgICAgIHRoaXMuZW1pdCgnY29ubmVjdCcpXG4gICAgfVxuICAgIGNvbnN0IHsgYWN0aXZlUXVlcnkgfSA9IHRoaXNcbiAgICB0aGlzLmFjdGl2ZVF1ZXJ5ID0gbnVsbFxuICAgIHRoaXMucmVhZHlGb3JRdWVyeSA9IHRydWVcbiAgICBpZiAoYWN0aXZlUXVlcnkpIHtcbiAgICAgIGFjdGl2ZVF1ZXJ5LmhhbmRsZVJlYWR5Rm9yUXVlcnkodGhpcy5jb25uZWN0aW9uKVxuICAgIH1cbiAgICB0aGlzLl9wdWxzZVF1ZXJ5UXVldWUoKVxuICB9XG5cbiAgLy8gaWYgd2UgcmVjZWlldmUgYW4gZXJyb3IgZXZlbnQgb3IgZXJyb3IgbWVzc2FnZVxuICAvLyBkdXJpbmcgdGhlIGNvbm5lY3Rpb24gcHJvY2VzcyB3ZSBoYW5kbGUgaXQgaGVyZVxuICBfaGFuZGxlRXJyb3JXaGlsZUNvbm5lY3RpbmcoZXJyKSB7XG4gICAgaWYgKHRoaXMuX2Nvbm5lY3Rpb25FcnJvcikge1xuICAgICAgLy8gVE9ETyhibWMpOiB0aGlzIGlzIHN3YWxsb3dpbmcgZXJyb3JzIC0gd2Ugc2hvdWxkbid0IGRvIHRoaXNcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICB0aGlzLl9jb25uZWN0aW9uRXJyb3IgPSB0cnVlXG4gICAgY2xlYXJUaW1lb3V0KHRoaXMuY29ubmVjdGlvblRpbWVvdXRIYW5kbGUpXG4gICAgaWYgKHRoaXMuX2Nvbm5lY3Rpb25DYWxsYmFjaykge1xuICAgICAgcmV0dXJuIHRoaXMuX2Nvbm5lY3Rpb25DYWxsYmFjayhlcnIpXG4gICAgfVxuICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpXG4gIH1cblxuICAvLyBpZiB3ZSdyZSBjb25uZWN0ZWQgYW5kIHdlIHJlY2VpdmUgYW4gZXJyb3IgZXZlbnQgZnJvbSB0aGUgY29ubmVjdGlvblxuICAvLyB0aGlzIG1lYW5zIHRoZSBzb2NrZXQgaXMgZGVhZCAtIGRvIGEgaGFyZCBhYm9ydCBvZiBhbGwgcXVlcmllcyBhbmQgZW1pdFxuICAvLyB0aGUgc29ja2V0IGVycm9yIG9uIHRoZSBjbGllbnQgYXMgd2VsbFxuICBfaGFuZGxlRXJyb3JFdmVudChlcnIpIHtcbiAgICBpZiAodGhpcy5fY29ubmVjdGluZykge1xuICAgICAgcmV0dXJuIHRoaXMuX2hhbmRsZUVycm9yV2hpbGVDb25uZWN0aW5nKGVycilcbiAgICB9XG4gICAgdGhpcy5fcXVlcnlhYmxlID0gZmFsc2VcbiAgICB0aGlzLl9lcnJvckFsbFF1ZXJpZXMoZXJyKVxuICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpXG4gIH1cblxuICAvLyBoYW5kbGUgZXJyb3IgbWVzc2FnZXMgZnJvbSB0aGUgcG9zdGdyZXMgYmFja2VuZFxuICBfaGFuZGxlRXJyb3JNZXNzYWdlKG1zZykge1xuICAgIGlmICh0aGlzLl9jb25uZWN0aW5nKSB7XG4gICAgICByZXR1cm4gdGhpcy5faGFuZGxlRXJyb3JXaGlsZUNvbm5lY3RpbmcobXNnKVxuICAgIH1cbiAgICBjb25zdCBhY3RpdmVRdWVyeSA9IHRoaXMuYWN0aXZlUXVlcnlcblxuICAgIGlmICghYWN0aXZlUXVlcnkpIHtcbiAgICAgIHRoaXMuX2hhbmRsZUVycm9yRXZlbnQobXNnKVxuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgdGhpcy5hY3RpdmVRdWVyeSA9IG51bGxcbiAgICBhY3RpdmVRdWVyeS5oYW5kbGVFcnJvcihtc2csIHRoaXMuY29ubmVjdGlvbilcbiAgfVxuXG4gIF9oYW5kbGVSb3dEZXNjcmlwdGlvbihtc2cpIHtcbiAgICAvLyBkZWxlZ2F0ZSByb3dEZXNjcmlwdGlvbiB0byBhY3RpdmUgcXVlcnlcbiAgICB0aGlzLmFjdGl2ZVF1ZXJ5LmhhbmRsZVJvd0Rlc2NyaXB0aW9uKG1zZylcbiAgfVxuXG4gIF9oYW5kbGVEYXRhUm93KG1zZykge1xuICAgIC8vIGRlbGVnYXRlIGRhdGFSb3cgdG8gYWN0aXZlIHF1ZXJ5XG4gICAgdGhpcy5hY3RpdmVRdWVyeS5oYW5kbGVEYXRhUm93KG1zZylcbiAgfVxuXG4gIF9oYW5kbGVQb3J0YWxTdXNwZW5kZWQobXNnKSB7XG4gICAgLy8gZGVsZWdhdGUgcG9ydGFsU3VzcGVuZGVkIHRvIGFjdGl2ZSBxdWVyeVxuICAgIHRoaXMuYWN0aXZlUXVlcnkuaGFuZGxlUG9ydGFsU3VzcGVuZGVkKHRoaXMuY29ubmVjdGlvbilcbiAgfVxuXG4gIF9oYW5kbGVFbXB0eVF1ZXJ5KG1zZykge1xuICAgIC8vIGRlbGVnYXRlIGVtcHR5UXVlcnkgdG8gYWN0aXZlIHF1ZXJ5XG4gICAgdGhpcy5hY3RpdmVRdWVyeS5oYW5kbGVFbXB0eVF1ZXJ5KHRoaXMuY29ubmVjdGlvbilcbiAgfVxuXG4gIF9oYW5kbGVDb21tYW5kQ29tcGxldGUobXNnKSB7XG4gICAgLy8gZGVsZWdhdGUgY29tbWFuZENvbXBsZXRlIHRvIGFjdGl2ZSBxdWVyeVxuICAgIHRoaXMuYWN0aXZlUXVlcnkuaGFuZGxlQ29tbWFuZENvbXBsZXRlKG1zZywgdGhpcy5jb25uZWN0aW9uKVxuICB9XG5cbiAgX2hhbmRsZVBhcnNlQ29tcGxldGUobXNnKSB7XG4gICAgLy8gaWYgYSBwcmVwYXJlZCBzdGF0ZW1lbnQgaGFzIGEgbmFtZSBhbmQgcHJvcGVybHkgcGFyc2VzXG4gICAgLy8gd2UgdHJhY2sgdGhhdCBpdHMgYWxyZWFkeSBiZWVuIGV4ZWN1dGVkIHNvIHdlIGRvbid0IHBhcnNlXG4gICAgLy8gaXQgYWdhaW4gb24gdGhlIHNhbWUgY2xpZW50XG4gICAgaWYgKHRoaXMuYWN0aXZlUXVlcnkubmFtZSkge1xuICAgICAgdGhpcy5jb25uZWN0aW9uLnBhcnNlZFN0YXRlbWVudHNbdGhpcy5hY3RpdmVRdWVyeS5uYW1lXSA9IHRoaXMuYWN0aXZlUXVlcnkudGV4dFxuICAgIH1cbiAgfVxuXG4gIF9oYW5kbGVDb3B5SW5SZXNwb25zZShtc2cpIHtcbiAgICB0aGlzLmFjdGl2ZVF1ZXJ5LmhhbmRsZUNvcHlJblJlc3BvbnNlKHRoaXMuY29ubmVjdGlvbilcbiAgfVxuXG4gIF9oYW5kbGVDb3B5RGF0YShtc2cpIHtcbiAgICB0aGlzLmFjdGl2ZVF1ZXJ5LmhhbmRsZUNvcHlEYXRhKG1zZywgdGhpcy5jb25uZWN0aW9uKVxuICB9XG5cbiAgX2hhbmRsZU5vdGlmaWNhdGlvbihtc2cpIHtcbiAgICB0aGlzLmVtaXQoJ25vdGlmaWNhdGlvbicsIG1zZylcbiAgfVxuXG4gIF9oYW5kbGVOb3RpY2UobXNnKSB7XG4gICAgdGhpcy5lbWl0KCdub3RpY2UnLCBtc2cpXG4gIH1cblxuICBnZXRTdGFydHVwQ29uZigpIHtcbiAgICB2YXIgcGFyYW1zID0gdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVyc1xuXG4gICAgdmFyIGRhdGEgPSB7XG4gICAgICB1c2VyOiBwYXJhbXMudXNlcixcbiAgICAgIGRhdGFiYXNlOiBwYXJhbXMuZGF0YWJhc2UsXG4gICAgfVxuXG4gICAgdmFyIGFwcE5hbWUgPSBwYXJhbXMuYXBwbGljYXRpb25fbmFtZSB8fCBwYXJhbXMuZmFsbGJhY2tfYXBwbGljYXRpb25fbmFtZVxuICAgIGlmIChhcHBOYW1lKSB7XG4gICAgICBkYXRhLmFwcGxpY2F0aW9uX25hbWUgPSBhcHBOYW1lXG4gICAgfVxuICAgIGlmIChwYXJhbXMucmVwbGljYXRpb24pIHtcbiAgICAgIGRhdGEucmVwbGljYXRpb24gPSAnJyArIHBhcmFtcy5yZXBsaWNhdGlvblxuICAgIH1cbiAgICBpZiAocGFyYW1zLnN0YXRlbWVudF90aW1lb3V0KSB7XG4gICAgICBkYXRhLnN0YXRlbWVudF90aW1lb3V0ID0gU3RyaW5nKHBhcnNlSW50KHBhcmFtcy5zdGF0ZW1lbnRfdGltZW91dCwgMTApKVxuICAgIH1cbiAgICBpZiAocGFyYW1zLmlkbGVfaW5fdHJhbnNhY3Rpb25fc2Vzc2lvbl90aW1lb3V0KSB7XG4gICAgICBkYXRhLmlkbGVfaW5fdHJhbnNhY3Rpb25fc2Vzc2lvbl90aW1lb3V0ID0gU3RyaW5nKHBhcnNlSW50KHBhcmFtcy5pZGxlX2luX3RyYW5zYWN0aW9uX3Nlc3Npb25fdGltZW91dCwgMTApKVxuICAgIH1cbiAgICBpZiAocGFyYW1zLm9wdGlvbnMpIHtcbiAgICAgIGRhdGEub3B0aW9ucyA9IHBhcmFtcy5vcHRpb25zXG4gICAgfVxuXG4gICAgcmV0dXJuIGRhdGFcbiAgfVxuXG4gIGNhbmNlbChjbGllbnQsIHF1ZXJ5KSB7XG4gICAgaWYgKGNsaWVudC5hY3RpdmVRdWVyeSA9PT0gcXVlcnkpIHtcbiAgICAgIHZhciBjb24gPSB0aGlzLmNvbm5lY3Rpb25cblxuICAgICAgaWYgKHRoaXMuaG9zdCAmJiB0aGlzLmhvc3QuaW5kZXhPZignLycpID09PSAwKSB7XG4gICAgICAgIGNvbi5jb25uZWN0KHRoaXMuaG9zdCArICcvLnMuUEdTUUwuJyArIHRoaXMucG9ydClcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbi5jb25uZWN0KHRoaXMucG9ydCwgdGhpcy5ob3N0KVxuICAgICAgfVxuXG4gICAgICAvLyBvbmNlIGNvbm5lY3Rpb24gaXMgZXN0YWJsaXNoZWQgc2VuZCBjYW5jZWwgbWVzc2FnZVxuICAgICAgY29uLm9uKCdjb25uZWN0JywgZnVuY3Rpb24gKCkge1xuICAgICAgICBjb24uY2FuY2VsKGNsaWVudC5wcm9jZXNzSUQsIGNsaWVudC5zZWNyZXRLZXkpXG4gICAgICB9KVxuICAgIH0gZWxzZSBpZiAoY2xpZW50LnF1ZXJ5UXVldWUuaW5kZXhPZihxdWVyeSkgIT09IC0xKSB7XG4gICAgICBjbGllbnQucXVlcnlRdWV1ZS5zcGxpY2UoY2xpZW50LnF1ZXJ5UXVldWUuaW5kZXhPZihxdWVyeSksIDEpXG4gICAgfVxuICB9XG5cbiAgc2V0VHlwZVBhcnNlcihvaWQsIGZvcm1hdCwgcGFyc2VGbikge1xuICAgIHJldHVybiB0aGlzLl90eXBlcy5zZXRUeXBlUGFyc2VyKG9pZCwgZm9ybWF0LCBwYXJzZUZuKVxuICB9XG5cbiAgZ2V0VHlwZVBhcnNlcihvaWQsIGZvcm1hdCkge1xuICAgIHJldHVybiB0aGlzLl90eXBlcy5nZXRUeXBlUGFyc2VyKG9pZCwgZm9ybWF0KVxuICB9XG5cbiAgLy8gUG9ydGVkIGZyb20gUG9zdGdyZVNRTCA5LjIuNCBzb3VyY2UgY29kZSBpbiBzcmMvaW50ZXJmYWNlcy9saWJwcS9mZS1leGVjLmNcbiAgZXNjYXBlSWRlbnRpZmllcihzdHIpIHtcbiAgICByZXR1cm4gJ1wiJyArIHN0ci5yZXBsYWNlKC9cIi9nLCAnXCJcIicpICsgJ1wiJ1xuICB9XG5cbiAgLy8gUG9ydGVkIGZyb20gUG9zdGdyZVNRTCA5LjIuNCBzb3VyY2UgY29kZSBpbiBzcmMvaW50ZXJmYWNlcy9saWJwcS9mZS1leGVjLmNcbiAgZXNjYXBlTGl0ZXJhbChzdHIpIHtcbiAgICB2YXIgaGFzQmFja3NsYXNoID0gZmFsc2VcbiAgICB2YXIgZXNjYXBlZCA9IFwiJ1wiXG5cbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IHN0ci5sZW5ndGg7IGkrKykge1xuICAgICAgdmFyIGMgPSBzdHJbaV1cbiAgICAgIGlmIChjID09PSBcIidcIikge1xuICAgICAgICBlc2NhcGVkICs9IGMgKyBjXG4gICAgICB9IGVsc2UgaWYgKGMgPT09ICdcXFxcJykge1xuICAgICAgICBlc2NhcGVkICs9IGMgKyBjXG4gICAgICAgIGhhc0JhY2tzbGFzaCA9IHRydWVcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGVzY2FwZWQgKz0gY1xuICAgICAgfVxuICAgIH1cblxuICAgIGVzY2FwZWQgKz0gXCInXCJcblxuICAgIGlmIChoYXNCYWNrc2xhc2ggPT09IHRydWUpIHtcbiAgICAgIGVzY2FwZWQgPSAnIEUnICsgZXNjYXBlZFxuICAgIH1cblxuICAgIHJldHVybiBlc2NhcGVkXG4gIH1cblxuICBfcHVsc2VRdWVyeVF1ZXVlKCkge1xuICAgIGlmICh0aGlzLnJlYWR5Rm9yUXVlcnkgPT09IHRydWUpIHtcbiAgICAgIHRoaXMuYWN0aXZlUXVlcnkgPSB0aGlzLnF1ZXJ5UXVldWUuc2hpZnQoKVxuICAgICAgaWYgKHRoaXMuYWN0aXZlUXVlcnkpIHtcbiAgICAgICAgdGhpcy5yZWFkeUZvclF1ZXJ5ID0gZmFsc2VcbiAgICAgICAgdGhpcy5oYXNFeGVjdXRlZCA9IHRydWVcblxuICAgICAgICBjb25zdCBxdWVyeUVycm9yID0gdGhpcy5hY3RpdmVRdWVyeS5zdWJtaXQodGhpcy5jb25uZWN0aW9uKVxuICAgICAgICBpZiAocXVlcnlFcnJvcikge1xuICAgICAgICAgIHByb2Nlc3MubmV4dFRpY2soKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5hY3RpdmVRdWVyeS5oYW5kbGVFcnJvcihxdWVyeUVycm9yLCB0aGlzLmNvbm5lY3Rpb24pXG4gICAgICAgICAgICB0aGlzLnJlYWR5Rm9yUXVlcnkgPSB0cnVlXG4gICAgICAgICAgICB0aGlzLl9wdWxzZVF1ZXJ5UXVldWUoKVxuICAgICAgICAgIH0pXG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAodGhpcy5oYXNFeGVjdXRlZCkge1xuICAgICAgICB0aGlzLmFjdGl2ZVF1ZXJ5ID0gbnVsbFxuICAgICAgICB0aGlzLmVtaXQoJ2RyYWluJylcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBxdWVyeShjb25maWcsIHZhbHVlcywgY2FsbGJhY2spIHtcbiAgICAvLyBjYW4gdGFrZSBpbiBzdHJpbmdzLCBjb25maWcgb2JqZWN0IG9yIHF1ZXJ5IG9iamVjdFxuICAgIHZhciBxdWVyeVxuICAgIHZhciByZXN1bHRcbiAgICB2YXIgcmVhZFRpbWVvdXRcbiAgICB2YXIgcmVhZFRpbWVvdXRUaW1lclxuICAgIHZhciBxdWVyeUNhbGxiYWNrXG5cbiAgICBpZiAoY29uZmlnID09PSBudWxsIHx8IGNvbmZpZyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdDbGllbnQgd2FzIHBhc3NlZCBhIG51bGwgb3IgdW5kZWZpbmVkIHF1ZXJ5JylcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiBjb25maWcuc3VibWl0ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICByZWFkVGltZW91dCA9IGNvbmZpZy5xdWVyeV90aW1lb3V0IHx8IHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMucXVlcnlfdGltZW91dFxuICAgICAgcmVzdWx0ID0gcXVlcnkgPSBjb25maWdcbiAgICAgIGlmICh0eXBlb2YgdmFsdWVzID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIHF1ZXJ5LmNhbGxiYWNrID0gcXVlcnkuY2FsbGJhY2sgfHwgdmFsdWVzXG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHJlYWRUaW1lb3V0ID0gdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy5xdWVyeV90aW1lb3V0XG4gICAgICBxdWVyeSA9IG5ldyBRdWVyeShjb25maWcsIHZhbHVlcywgY2FsbGJhY2spXG4gICAgICBpZiAoIXF1ZXJ5LmNhbGxiYWNrKSB7XG4gICAgICAgIHJlc3VsdCA9IG5ldyB0aGlzLl9Qcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICBxdWVyeS5jYWxsYmFjayA9IChlcnIsIHJlcykgPT4gKGVyciA/IHJlamVjdChlcnIpIDogcmVzb2x2ZShyZXMpKVxuICAgICAgICB9KVxuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChyZWFkVGltZW91dCkge1xuICAgICAgcXVlcnlDYWxsYmFjayA9IHF1ZXJ5LmNhbGxiYWNrXG5cbiAgICAgIHJlYWRUaW1lb3V0VGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgdmFyIGVycm9yID0gbmV3IEVycm9yKCdRdWVyeSByZWFkIHRpbWVvdXQnKVxuXG4gICAgICAgIHByb2Nlc3MubmV4dFRpY2soKCkgPT4ge1xuICAgICAgICAgIHF1ZXJ5LmhhbmRsZUVycm9yKGVycm9yLCB0aGlzLmNvbm5lY3Rpb24pXG4gICAgICAgIH0pXG5cbiAgICAgICAgcXVlcnlDYWxsYmFjayhlcnJvcilcblxuICAgICAgICAvLyB3ZSBhbHJlYWR5IHJldHVybmVkIGFuIGVycm9yLFxuICAgICAgICAvLyBqdXN0IGRvIG5vdGhpbmcgaWYgcXVlcnkgY29tcGxldGVzXG4gICAgICAgIHF1ZXJ5LmNhbGxiYWNrID0gKCkgPT4ge31cblxuICAgICAgICAvLyBSZW1vdmUgZnJvbSBxdWV1ZVxuICAgICAgICB2YXIgaW5kZXggPSB0aGlzLnF1ZXJ5UXVldWUuaW5kZXhPZihxdWVyeSlcbiAgICAgICAgaWYgKGluZGV4ID4gLTEpIHtcbiAgICAgICAgICB0aGlzLnF1ZXJ5UXVldWUuc3BsaWNlKGluZGV4LCAxKVxuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5fcHVsc2VRdWVyeVF1ZXVlKClcbiAgICAgIH0sIHJlYWRUaW1lb3V0KVxuXG4gICAgICBxdWVyeS5jYWxsYmFjayA9IChlcnIsIHJlcykgPT4ge1xuICAgICAgICBjbGVhclRpbWVvdXQocmVhZFRpbWVvdXRUaW1lcilcbiAgICAgICAgcXVlcnlDYWxsYmFjayhlcnIsIHJlcylcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAodGhpcy5iaW5hcnkgJiYgIXF1ZXJ5LmJpbmFyeSkge1xuICAgICAgcXVlcnkuYmluYXJ5ID0gdHJ1ZVxuICAgIH1cblxuICAgIGlmIChxdWVyeS5fcmVzdWx0ICYmICFxdWVyeS5fcmVzdWx0Ll90eXBlcykge1xuICAgICAgcXVlcnkuX3Jlc3VsdC5fdHlwZXMgPSB0aGlzLl90eXBlc1xuICAgIH1cblxuICAgIGlmICghdGhpcy5fcXVlcnlhYmxlKSB7XG4gICAgICBwcm9jZXNzLm5leHRUaWNrKCgpID0+IHtcbiAgICAgICAgcXVlcnkuaGFuZGxlRXJyb3IobmV3IEVycm9yKCdDbGllbnQgaGFzIGVuY291bnRlcmVkIGEgY29ubmVjdGlvbiBlcnJvciBhbmQgaXMgbm90IHF1ZXJ5YWJsZScpLCB0aGlzLmNvbm5lY3Rpb24pXG4gICAgICB9KVxuICAgICAgcmV0dXJuIHJlc3VsdFxuICAgIH1cblxuICAgIGlmICh0aGlzLl9lbmRpbmcpIHtcbiAgICAgIHByb2Nlc3MubmV4dFRpY2soKCkgPT4ge1xuICAgICAgICBxdWVyeS5oYW5kbGVFcnJvcihuZXcgRXJyb3IoJ0NsaWVudCB3YXMgY2xvc2VkIGFuZCBpcyBub3QgcXVlcnlhYmxlJyksIHRoaXMuY29ubmVjdGlvbilcbiAgICAgIH0pXG4gICAgICByZXR1cm4gcmVzdWx0XG4gICAgfVxuXG4gICAgdGhpcy5xdWVyeVF1ZXVlLnB1c2gocXVlcnkpXG4gICAgdGhpcy5fcHVsc2VRdWVyeVF1ZXVlKClcbiAgICByZXR1cm4gcmVzdWx0XG4gIH1cblxuICByZWYoKSB7XG4gICAgdGhpcy5jb25uZWN0aW9uLnJlZigpXG4gIH1cblxuICB1bnJlZigpIHtcbiAgICB0aGlzLmNvbm5lY3Rpb24udW5yZWYoKVxuICB9XG5cbiAgZW5kKGNiKSB7XG4gICAgdGhpcy5fZW5kaW5nID0gdHJ1ZVxuXG4gICAgLy8gaWYgd2UgaGF2ZSBuZXZlciBjb25uZWN0ZWQsIHRoZW4gZW5kIGlzIGEgbm9vcCwgY2FsbGJhY2sgaW1tZWRpYXRlbHlcbiAgICBpZiAoIXRoaXMuY29ubmVjdGlvbi5fY29ubmVjdGluZykge1xuICAgICAgaWYgKGNiKSB7XG4gICAgICAgIGNiKClcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9Qcm9taXNlLnJlc29sdmUoKVxuICAgICAgfVxuICAgIH1cblxuICAgIGlmICh0aGlzLmFjdGl2ZVF1ZXJ5IHx8ICF0aGlzLl9xdWVyeWFibGUpIHtcbiAgICAgIC8vIGlmIHdlIGhhdmUgYW4gYWN0aXZlIHF1ZXJ5IHdlIG5lZWQgdG8gZm9yY2UgYSBkaXNjb25uZWN0XG4gICAgICAvLyBvbiB0aGUgc29ja2V0IC0gb3RoZXJ3aXNlIGEgaHVuZyBxdWVyeSBjb3VsZCBibG9jayBlbmQgZm9yZXZlclxuICAgICAgdGhpcy5jb25uZWN0aW9uLnN0cmVhbS5kZXN0cm95KClcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5jb25uZWN0aW9uLmVuZCgpXG4gICAgfVxuXG4gICAgaWYgKGNiKSB7XG4gICAgICB0aGlzLmNvbm5lY3Rpb24ub25jZSgnZW5kJywgY2IpXG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBuZXcgdGhpcy5fUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICB0aGlzLmNvbm5lY3Rpb24ub25jZSgnZW5kJywgcmVzb2x2ZSlcbiAgICAgIH0pXG4gICAgfVxuICB9XG59XG5cbi8vIGV4cG9zZSBhIFF1ZXJ5IGNvbnN0cnVjdG9yXG5DbGllbnQuUXVlcnkgPSBRdWVyeVxuXG5tb2R1bGUuZXhwb3J0cyA9IENsaWVudFxuIiwiJ3VzZSBzdHJpY3QnXG5cbnZhciBkbnMgPSByZXF1aXJlKCdkbnMnKVxuXG52YXIgZGVmYXVsdHMgPSByZXF1aXJlKCcuL2RlZmF1bHRzJylcblxudmFyIHBhcnNlID0gcmVxdWlyZSgncGctY29ubmVjdGlvbi1zdHJpbmcnKS5wYXJzZSAvLyBwYXJzZXMgYSBjb25uZWN0aW9uIHN0cmluZ1xuXG52YXIgdmFsID0gZnVuY3Rpb24gKGtleSwgY29uZmlnLCBlbnZWYXIpIHtcbiAgaWYgKGVudlZhciA9PT0gdW5kZWZpbmVkKSB7XG4gICAgZW52VmFyID0gcHJvY2Vzcy5lbnZbJ1BHJyArIGtleS50b1VwcGVyQ2FzZSgpXVxuICB9IGVsc2UgaWYgKGVudlZhciA9PT0gZmFsc2UpIHtcbiAgICAvLyBkbyBub3RoaW5nIC4uLiB1c2UgZmFsc2VcbiAgfSBlbHNlIHtcbiAgICBlbnZWYXIgPSBwcm9jZXNzLmVudltlbnZWYXJdXG4gIH1cblxuICByZXR1cm4gY29uZmlnW2tleV0gfHwgZW52VmFyIHx8IGRlZmF1bHRzW2tleV1cbn1cblxudmFyIHJlYWRTU0xDb25maWdGcm9tRW52aXJvbm1lbnQgPSBmdW5jdGlvbiAoKSB7XG4gIHN3aXRjaCAocHJvY2Vzcy5lbnYuUEdTU0xNT0RFKSB7XG4gICAgY2FzZSAnZGlzYWJsZSc6XG4gICAgICByZXR1cm4gZmFsc2VcbiAgICBjYXNlICdwcmVmZXInOlxuICAgIGNhc2UgJ3JlcXVpcmUnOlxuICAgIGNhc2UgJ3ZlcmlmeS1jYSc6XG4gICAgY2FzZSAndmVyaWZ5LWZ1bGwnOlxuICAgICAgcmV0dXJuIHRydWVcbiAgICBjYXNlICduby12ZXJpZnknOlxuICAgICAgcmV0dXJuIHsgcmVqZWN0VW5hdXRob3JpemVkOiBmYWxzZSB9XG4gIH1cbiAgcmV0dXJuIGRlZmF1bHRzLnNzbFxufVxuXG4vLyBDb252ZXJ0IGFyZyB0byBhIHN0cmluZywgc3Vycm91bmQgaW4gc2luZ2xlIHF1b3RlcywgYW5kIGVzY2FwZSBzaW5nbGUgcXVvdGVzIGFuZCBiYWNrc2xhc2hlc1xudmFyIHF1b3RlUGFyYW1WYWx1ZSA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICByZXR1cm4gXCInXCIgKyAoJycgKyB2YWx1ZSkucmVwbGFjZSgvXFxcXC9nLCAnXFxcXFxcXFwnKS5yZXBsYWNlKC8nL2csIFwiXFxcXCdcIikgKyBcIidcIlxufVxuXG52YXIgYWRkID0gZnVuY3Rpb24gKHBhcmFtcywgY29uZmlnLCBwYXJhbU5hbWUpIHtcbiAgdmFyIHZhbHVlID0gY29uZmlnW3BhcmFtTmFtZV1cbiAgaWYgKHZhbHVlICE9PSB1bmRlZmluZWQgJiYgdmFsdWUgIT09IG51bGwpIHtcbiAgICBwYXJhbXMucHVzaChwYXJhbU5hbWUgKyAnPScgKyBxdW90ZVBhcmFtVmFsdWUodmFsdWUpKVxuICB9XG59XG5cbmNsYXNzIENvbm5lY3Rpb25QYXJhbWV0ZXJzIHtcbiAgY29uc3RydWN0b3IoY29uZmlnKSB7XG4gICAgLy8gaWYgYSBzdHJpbmcgaXMgcGFzc2VkLCBpdCBpcyBhIHJhdyBjb25uZWN0aW9uIHN0cmluZyBzbyB3ZSBwYXJzZSBpdCBpbnRvIGEgY29uZmlnXG4gICAgY29uZmlnID0gdHlwZW9mIGNvbmZpZyA9PT0gJ3N0cmluZycgPyBwYXJzZShjb25maWcpIDogY29uZmlnIHx8IHt9XG5cbiAgICAvLyBpZiB0aGUgY29uZmlnIGhhcyBhIGNvbm5lY3Rpb25TdHJpbmcgZGVmaW5lZCwgcGFyc2UgSVQgaW50byB0aGUgY29uZmlnIHdlIHVzZVxuICAgIC8vIHRoaXMgd2lsbCBvdmVycmlkZSBvdGhlciBkZWZhdWx0IHZhbHVlcyB3aXRoIHdoYXQgaXMgc3RvcmVkIGluIGNvbm5lY3Rpb25TdHJpbmdcbiAgICBpZiAoY29uZmlnLmNvbm5lY3Rpb25TdHJpbmcpIHtcbiAgICAgIGNvbmZpZyA9IE9iamVjdC5hc3NpZ24oe30sIGNvbmZpZywgcGFyc2UoY29uZmlnLmNvbm5lY3Rpb25TdHJpbmcpKVxuICAgIH1cblxuICAgIHRoaXMudXNlciA9IHZhbCgndXNlcicsIGNvbmZpZylcbiAgICB0aGlzLmRhdGFiYXNlID0gdmFsKCdkYXRhYmFzZScsIGNvbmZpZylcblxuICAgIGlmICh0aGlzLmRhdGFiYXNlID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMuZGF0YWJhc2UgPSB0aGlzLnVzZXJcbiAgICB9XG5cbiAgICB0aGlzLnBvcnQgPSBwYXJzZUludCh2YWwoJ3BvcnQnLCBjb25maWcpLCAxMClcbiAgICB0aGlzLmhvc3QgPSB2YWwoJ2hvc3QnLCBjb25maWcpXG5cbiAgICAvLyBcImhpZGluZ1wiIHRoZSBwYXNzd29yZCBzbyBpdCBkb2Vzbid0IHNob3cgdXAgaW4gc3RhY2sgdHJhY2VzXG4gICAgLy8gb3IgaWYgdGhlIGNsaWVudCBpcyBjb25zb2xlLmxvZ2dlZFxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCAncGFzc3dvcmQnLCB7XG4gICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgdmFsdWU6IHZhbCgncGFzc3dvcmQnLCBjb25maWcpLFxuICAgIH0pXG5cbiAgICB0aGlzLmJpbmFyeSA9IHZhbCgnYmluYXJ5JywgY29uZmlnKVxuICAgIHRoaXMub3B0aW9ucyA9IHZhbCgnb3B0aW9ucycsIGNvbmZpZylcblxuICAgIHRoaXMuc3NsID0gdHlwZW9mIGNvbmZpZy5zc2wgPT09ICd1bmRlZmluZWQnID8gcmVhZFNTTENvbmZpZ0Zyb21FbnZpcm9ubWVudCgpIDogY29uZmlnLnNzbFxuXG4gICAgaWYgKHR5cGVvZiB0aGlzLnNzbCA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGlmICh0aGlzLnNzbCA9PT0gJ3RydWUnKSB7XG4gICAgICAgIHRoaXMuc3NsID0gdHJ1ZVxuICAgICAgfVxuICAgIH1cbiAgICAvLyBzdXBwb3J0IHBhc3NpbmcgaW4gc3NsPW5vLXZlcmlmeSB2aWEgY29ubmVjdGlvbiBzdHJpbmdcbiAgICBpZiAodGhpcy5zc2wgPT09ICduby12ZXJpZnknKSB7XG4gICAgICB0aGlzLnNzbCA9IHsgcmVqZWN0VW5hdXRob3JpemVkOiBmYWxzZSB9XG4gICAgfVxuICAgIGlmICh0aGlzLnNzbCAmJiB0aGlzLnNzbC5rZXkpIHtcbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLnNzbCwgJ2tleScsIHtcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICB9KVxuICAgIH1cblxuICAgIHRoaXMuY2xpZW50X2VuY29kaW5nID0gdmFsKCdjbGllbnRfZW5jb2RpbmcnLCBjb25maWcpXG4gICAgdGhpcy5yZXBsaWNhdGlvbiA9IHZhbCgncmVwbGljYXRpb24nLCBjb25maWcpXG4gICAgLy8gYSBkb21haW4gc29ja2V0IGJlZ2lucyB3aXRoICcvJ1xuICAgIHRoaXMuaXNEb21haW5Tb2NrZXQgPSAhKHRoaXMuaG9zdCB8fCAnJykuaW5kZXhPZignLycpXG5cbiAgICB0aGlzLmFwcGxpY2F0aW9uX25hbWUgPSB2YWwoJ2FwcGxpY2F0aW9uX25hbWUnLCBjb25maWcsICdQR0FQUE5BTUUnKVxuICAgIHRoaXMuZmFsbGJhY2tfYXBwbGljYXRpb25fbmFtZSA9IHZhbCgnZmFsbGJhY2tfYXBwbGljYXRpb25fbmFtZScsIGNvbmZpZywgZmFsc2UpXG4gICAgdGhpcy5zdGF0ZW1lbnRfdGltZW91dCA9IHZhbCgnc3RhdGVtZW50X3RpbWVvdXQnLCBjb25maWcsIGZhbHNlKVxuICAgIHRoaXMuaWRsZV9pbl90cmFuc2FjdGlvbl9zZXNzaW9uX3RpbWVvdXQgPSB2YWwoJ2lkbGVfaW5fdHJhbnNhY3Rpb25fc2Vzc2lvbl90aW1lb3V0JywgY29uZmlnLCBmYWxzZSlcbiAgICB0aGlzLnF1ZXJ5X3RpbWVvdXQgPSB2YWwoJ3F1ZXJ5X3RpbWVvdXQnLCBjb25maWcsIGZhbHNlKVxuXG4gICAgaWYgKGNvbmZpZy5jb25uZWN0aW9uVGltZW91dE1pbGxpcyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aGlzLmNvbm5lY3RfdGltZW91dCA9IHByb2Nlc3MuZW52LlBHQ09OTkVDVF9USU1FT1VUIHx8IDBcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5jb25uZWN0X3RpbWVvdXQgPSBNYXRoLmZsb29yKGNvbmZpZy5jb25uZWN0aW9uVGltZW91dE1pbGxpcyAvIDEwMDApXG4gICAgfVxuXG4gICAgaWYgKGNvbmZpZy5rZWVwQWxpdmUgPT09IGZhbHNlKSB7XG4gICAgICB0aGlzLmtlZXBhbGl2ZXMgPSAwXG4gICAgfSBlbHNlIGlmIChjb25maWcua2VlcEFsaXZlID09PSB0cnVlKSB7XG4gICAgICB0aGlzLmtlZXBhbGl2ZXMgPSAxXG4gICAgfVxuXG4gICAgaWYgKHR5cGVvZiBjb25maWcua2VlcEFsaXZlSW5pdGlhbERlbGF5TWlsbGlzID09PSAnbnVtYmVyJykge1xuICAgICAgdGhpcy5rZWVwYWxpdmVzX2lkbGUgPSBNYXRoLmZsb29yKGNvbmZpZy5rZWVwQWxpdmVJbml0aWFsRGVsYXlNaWxsaXMgLyAxMDAwKVxuICAgIH1cbiAgfVxuXG4gIGdldExpYnBxQ29ubmVjdGlvblN0cmluZyhjYikge1xuICAgIHZhciBwYXJhbXMgPSBbXVxuICAgIGFkZChwYXJhbXMsIHRoaXMsICd1c2VyJylcbiAgICBhZGQocGFyYW1zLCB0aGlzLCAncGFzc3dvcmQnKVxuICAgIGFkZChwYXJhbXMsIHRoaXMsICdwb3J0JylcbiAgICBhZGQocGFyYW1zLCB0aGlzLCAnYXBwbGljYXRpb25fbmFtZScpXG4gICAgYWRkKHBhcmFtcywgdGhpcywgJ2ZhbGxiYWNrX2FwcGxpY2F0aW9uX25hbWUnKVxuICAgIGFkZChwYXJhbXMsIHRoaXMsICdjb25uZWN0X3RpbWVvdXQnKVxuICAgIGFkZChwYXJhbXMsIHRoaXMsICdvcHRpb25zJylcblxuICAgIHZhciBzc2wgPSB0eXBlb2YgdGhpcy5zc2wgPT09ICdvYmplY3QnID8gdGhpcy5zc2wgOiB0aGlzLnNzbCA/IHsgc3NsbW9kZTogdGhpcy5zc2wgfSA6IHt9XG4gICAgYWRkKHBhcmFtcywgc3NsLCAnc3NsbW9kZScpXG4gICAgYWRkKHBhcmFtcywgc3NsLCAnc3NsY2EnKVxuICAgIGFkZChwYXJhbXMsIHNzbCwgJ3NzbGtleScpXG4gICAgYWRkKHBhcmFtcywgc3NsLCAnc3NsY2VydCcpXG4gICAgYWRkKHBhcmFtcywgc3NsLCAnc3Nscm9vdGNlcnQnKVxuXG4gICAgaWYgKHRoaXMuZGF0YWJhc2UpIHtcbiAgICAgIHBhcmFtcy5wdXNoKCdkYm5hbWU9JyArIHF1b3RlUGFyYW1WYWx1ZSh0aGlzLmRhdGFiYXNlKSlcbiAgICB9XG4gICAgaWYgKHRoaXMucmVwbGljYXRpb24pIHtcbiAgICAgIHBhcmFtcy5wdXNoKCdyZXBsaWNhdGlvbj0nICsgcXVvdGVQYXJhbVZhbHVlKHRoaXMucmVwbGljYXRpb24pKVxuICAgIH1cbiAgICBpZiAodGhpcy5ob3N0KSB7XG4gICAgICBwYXJhbXMucHVzaCgnaG9zdD0nICsgcXVvdGVQYXJhbVZhbHVlKHRoaXMuaG9zdCkpXG4gICAgfVxuICAgIGlmICh0aGlzLmlzRG9tYWluU29ja2V0KSB7XG4gICAgICByZXR1cm4gY2IobnVsbCwgcGFyYW1zLmpvaW4oJyAnKSlcbiAgICB9XG4gICAgaWYgKHRoaXMuY2xpZW50X2VuY29kaW5nKSB7XG4gICAgICBwYXJhbXMucHVzaCgnY2xpZW50X2VuY29kaW5nPScgKyBxdW90ZVBhcmFtVmFsdWUodGhpcy5jbGllbnRfZW5jb2RpbmcpKVxuICAgIH1cbiAgICBkbnMubG9va3VwKHRoaXMuaG9zdCwgZnVuY3Rpb24gKGVyciwgYWRkcmVzcykge1xuICAgICAgaWYgKGVycikgcmV0dXJuIGNiKGVyciwgbnVsbClcbiAgICAgIHBhcmFtcy5wdXNoKCdob3N0YWRkcj0nICsgcXVvdGVQYXJhbVZhbHVlKGFkZHJlc3MpKVxuICAgICAgcmV0dXJuIGNiKG51bGwsIHBhcmFtcy5qb2luKCcgJykpXG4gICAgfSlcbiAgfVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IENvbm5lY3Rpb25QYXJhbWV0ZXJzXG4iLCIndXNlIHN0cmljdCdcblxudmFyIG5ldCA9IHJlcXVpcmUoJ25ldCcpXG52YXIgRXZlbnRFbWl0dGVyID0gcmVxdWlyZSgnZXZlbnRzJykuRXZlbnRFbWl0dGVyXG5cbmNvbnN0IHsgcGFyc2UsIHNlcmlhbGl6ZSB9ID0gcmVxdWlyZSgncGctcHJvdG9jb2wnKVxuXG5jb25zdCBmbHVzaEJ1ZmZlciA9IHNlcmlhbGl6ZS5mbHVzaCgpXG5jb25zdCBzeW5jQnVmZmVyID0gc2VyaWFsaXplLnN5bmMoKVxuY29uc3QgZW5kQnVmZmVyID0gc2VyaWFsaXplLmVuZCgpXG5cbi8vIFRPRE8oYm1jKSBzdXBwb3J0IGJpbmFyeSBtb2RlIGF0IHNvbWUgcG9pbnRcbmNsYXNzIENvbm5lY3Rpb24gZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBjb25zdHJ1Y3Rvcihjb25maWcpIHtcbiAgICBzdXBlcigpXG4gICAgY29uZmlnID0gY29uZmlnIHx8IHt9XG4gICAgdGhpcy5zdHJlYW0gPSBjb25maWcuc3RyZWFtIHx8IG5ldyBuZXQuU29ja2V0KClcbiAgICB0aGlzLl9rZWVwQWxpdmUgPSBjb25maWcua2VlcEFsaXZlXG4gICAgdGhpcy5fa2VlcEFsaXZlSW5pdGlhbERlbGF5TWlsbGlzID0gY29uZmlnLmtlZXBBbGl2ZUluaXRpYWxEZWxheU1pbGxpc1xuICAgIHRoaXMubGFzdEJ1ZmZlciA9IGZhbHNlXG4gICAgdGhpcy5wYXJzZWRTdGF0ZW1lbnRzID0ge31cbiAgICB0aGlzLnNzbCA9IGNvbmZpZy5zc2wgfHwgZmFsc2VcbiAgICB0aGlzLl9lbmRpbmcgPSBmYWxzZVxuICAgIHRoaXMuX2VtaXRNZXNzYWdlID0gZmFsc2VcbiAgICB2YXIgc2VsZiA9IHRoaXNcbiAgICB0aGlzLm9uKCduZXdMaXN0ZW5lcicsIGZ1bmN0aW9uIChldmVudE5hbWUpIHtcbiAgICAgIGlmIChldmVudE5hbWUgPT09ICdtZXNzYWdlJykge1xuICAgICAgICBzZWxmLl9lbWl0TWVzc2FnZSA9IHRydWVcbiAgICAgIH1cbiAgICB9KVxuICB9XG5cbiAgY29ubmVjdChwb3J0LCBob3N0KSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzXG5cbiAgICB0aGlzLl9jb25uZWN0aW5nID0gdHJ1ZVxuICAgIHRoaXMuc3RyZWFtLnNldE5vRGVsYXkodHJ1ZSlcbiAgICB0aGlzLnN0cmVhbS5jb25uZWN0KHBvcnQsIGhvc3QpXG5cbiAgICB0aGlzLnN0cmVhbS5vbmNlKCdjb25uZWN0JywgZnVuY3Rpb24gKCkge1xuICAgICAgaWYgKHNlbGYuX2tlZXBBbGl2ZSkge1xuICAgICAgICBzZWxmLnN0cmVhbS5zZXRLZWVwQWxpdmUodHJ1ZSwgc2VsZi5fa2VlcEFsaXZlSW5pdGlhbERlbGF5TWlsbGlzKVxuICAgICAgfVxuICAgICAgc2VsZi5lbWl0KCdjb25uZWN0JylcbiAgICB9KVxuXG4gICAgY29uc3QgcmVwb3J0U3RyZWFtRXJyb3IgPSBmdW5jdGlvbiAoZXJyb3IpIHtcbiAgICAgIC8vIGVycm9ycyBhYm91dCBkaXNjb25uZWN0aW9ucyBzaG91bGQgYmUgaWdub3JlZCBkdXJpbmcgZGlzY29ubmVjdFxuICAgICAgaWYgKHNlbGYuX2VuZGluZyAmJiAoZXJyb3IuY29kZSA9PT0gJ0VDT05OUkVTRVQnIHx8IGVycm9yLmNvZGUgPT09ICdFUElQRScpKSB7XG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgICAgc2VsZi5lbWl0KCdlcnJvcicsIGVycm9yKVxuICAgIH1cbiAgICB0aGlzLnN0cmVhbS5vbignZXJyb3InLCByZXBvcnRTdHJlYW1FcnJvcilcblxuICAgIHRoaXMuc3RyZWFtLm9uKCdjbG9zZScsIGZ1bmN0aW9uICgpIHtcbiAgICAgIHNlbGYuZW1pdCgnZW5kJylcbiAgICB9KVxuXG4gICAgaWYgKCF0aGlzLnNzbCkge1xuICAgICAgcmV0dXJuIHRoaXMuYXR0YWNoTGlzdGVuZXJzKHRoaXMuc3RyZWFtKVxuICAgIH1cblxuICAgIHRoaXMuc3RyZWFtLm9uY2UoJ2RhdGEnLCBmdW5jdGlvbiAoYnVmZmVyKSB7XG4gICAgICB2YXIgcmVzcG9uc2VDb2RlID0gYnVmZmVyLnRvU3RyaW5nKCd1dGY4JylcbiAgICAgIHN3aXRjaCAocmVzcG9uc2VDb2RlKSB7XG4gICAgICAgIGNhc2UgJ1MnOiAvLyBTZXJ2ZXIgc3VwcG9ydHMgU1NMIGNvbm5lY3Rpb25zLCBjb250aW51ZSB3aXRoIGEgc2VjdXJlIGNvbm5lY3Rpb25cbiAgICAgICAgICBicmVha1xuICAgICAgICBjYXNlICdOJzogLy8gU2VydmVyIGRvZXMgbm90IHN1cHBvcnQgU1NMIGNvbm5lY3Rpb25zXG4gICAgICAgICAgc2VsZi5zdHJlYW0uZW5kKClcbiAgICAgICAgICByZXR1cm4gc2VsZi5lbWl0KCdlcnJvcicsIG5ldyBFcnJvcignVGhlIHNlcnZlciBkb2VzIG5vdCBzdXBwb3J0IFNTTCBjb25uZWN0aW9ucycpKVxuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgIC8vIEFueSBvdGhlciByZXNwb25zZSBieXRlLCBpbmNsdWRpbmcgJ0UnIChFcnJvclJlc3BvbnNlKSBpbmRpY2F0aW5nIGEgc2VydmVyIGVycm9yXG4gICAgICAgICAgc2VsZi5zdHJlYW0uZW5kKClcbiAgICAgICAgICByZXR1cm4gc2VsZi5lbWl0KCdlcnJvcicsIG5ldyBFcnJvcignVGhlcmUgd2FzIGFuIGVycm9yIGVzdGFibGlzaGluZyBhbiBTU0wgY29ubmVjdGlvbicpKVxuICAgICAgfVxuICAgICAgdmFyIHRscyA9IHJlcXVpcmUoJ3RscycpXG4gICAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgICBzb2NrZXQ6IHNlbGYuc3RyZWFtLFxuICAgICAgfVxuXG4gICAgICBpZiAoc2VsZi5zc2wgIT09IHRydWUpIHtcbiAgICAgICAgT2JqZWN0LmFzc2lnbihvcHRpb25zLCBzZWxmLnNzbClcblxuICAgICAgICBpZiAoJ2tleScgaW4gc2VsZi5zc2wpIHtcbiAgICAgICAgICBvcHRpb25zLmtleSA9IHNlbGYuc3NsLmtleVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmIChuZXQuaXNJUChob3N0KSA9PT0gMCkge1xuICAgICAgICBvcHRpb25zLnNlcnZlcm5hbWUgPSBob3N0XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICBzZWxmLnN0cmVhbSA9IHRscy5jb25uZWN0KG9wdGlvbnMpXG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgcmV0dXJuIHNlbGYuZW1pdCgnZXJyb3InLCBlcnIpXG4gICAgICB9XG4gICAgICBzZWxmLmF0dGFjaExpc3RlbmVycyhzZWxmLnN0cmVhbSlcbiAgICAgIHNlbGYuc3RyZWFtLm9uKCdlcnJvcicsIHJlcG9ydFN0cmVhbUVycm9yKVxuXG4gICAgICBzZWxmLmVtaXQoJ3NzbGNvbm5lY3QnKVxuICAgIH0pXG4gIH1cblxuICBhdHRhY2hMaXN0ZW5lcnMoc3RyZWFtKSB7XG4gICAgc3RyZWFtLm9uKCdlbmQnLCAoKSA9PiB7XG4gICAgICB0aGlzLmVtaXQoJ2VuZCcpXG4gICAgfSlcbiAgICBwYXJzZShzdHJlYW0sIChtc2cpID0+IHtcbiAgICAgIHZhciBldmVudE5hbWUgPSBtc2cubmFtZSA9PT0gJ2Vycm9yJyA/ICdlcnJvck1lc3NhZ2UnIDogbXNnLm5hbWVcbiAgICAgIGlmICh0aGlzLl9lbWl0TWVzc2FnZSkge1xuICAgICAgICB0aGlzLmVtaXQoJ21lc3NhZ2UnLCBtc2cpXG4gICAgICB9XG4gICAgICB0aGlzLmVtaXQoZXZlbnROYW1lLCBtc2cpXG4gICAgfSlcbiAgfVxuXG4gIHJlcXVlc3RTc2woKSB7XG4gICAgdGhpcy5zdHJlYW0ud3JpdGUoc2VyaWFsaXplLnJlcXVlc3RTc2woKSlcbiAgfVxuXG4gIHN0YXJ0dXAoY29uZmlnKSB7XG4gICAgdGhpcy5zdHJlYW0ud3JpdGUoc2VyaWFsaXplLnN0YXJ0dXAoY29uZmlnKSlcbiAgfVxuXG4gIGNhbmNlbChwcm9jZXNzSUQsIHNlY3JldEtleSkge1xuICAgIHRoaXMuX3NlbmQoc2VyaWFsaXplLmNhbmNlbChwcm9jZXNzSUQsIHNlY3JldEtleSkpXG4gIH1cblxuICBwYXNzd29yZChwYXNzd29yZCkge1xuICAgIHRoaXMuX3NlbmQoc2VyaWFsaXplLnBhc3N3b3JkKHBhc3N3b3JkKSlcbiAgfVxuXG4gIHNlbmRTQVNMSW5pdGlhbFJlc3BvbnNlTWVzc2FnZShtZWNoYW5pc20sIGluaXRpYWxSZXNwb25zZSkge1xuICAgIHRoaXMuX3NlbmQoc2VyaWFsaXplLnNlbmRTQVNMSW5pdGlhbFJlc3BvbnNlTWVzc2FnZShtZWNoYW5pc20sIGluaXRpYWxSZXNwb25zZSkpXG4gIH1cblxuICBzZW5kU0NSQU1DbGllbnRGaW5hbE1lc3NhZ2UoYWRkaXRpb25hbERhdGEpIHtcbiAgICB0aGlzLl9zZW5kKHNlcmlhbGl6ZS5zZW5kU0NSQU1DbGllbnRGaW5hbE1lc3NhZ2UoYWRkaXRpb25hbERhdGEpKVxuICB9XG5cbiAgX3NlbmQoYnVmZmVyKSB7XG4gICAgaWYgKCF0aGlzLnN0cmVhbS53cml0YWJsZSkge1xuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuICAgIHJldHVybiB0aGlzLnN0cmVhbS53cml0ZShidWZmZXIpXG4gIH1cblxuICBxdWVyeSh0ZXh0KSB7XG4gICAgdGhpcy5fc2VuZChzZXJpYWxpemUucXVlcnkodGV4dCkpXG4gIH1cblxuICAvLyBzZW5kIHBhcnNlIG1lc3NhZ2VcbiAgcGFyc2UocXVlcnkpIHtcbiAgICB0aGlzLl9zZW5kKHNlcmlhbGl6ZS5wYXJzZShxdWVyeSkpXG4gIH1cblxuICAvLyBzZW5kIGJpbmQgbWVzc2FnZVxuICBiaW5kKGNvbmZpZykge1xuICAgIHRoaXMuX3NlbmQoc2VyaWFsaXplLmJpbmQoY29uZmlnKSlcbiAgfVxuXG4gIC8vIHNlbmQgZXhlY3V0ZSBtZXNzYWdlXG4gIGV4ZWN1dGUoY29uZmlnKSB7XG4gICAgdGhpcy5fc2VuZChzZXJpYWxpemUuZXhlY3V0ZShjb25maWcpKVxuICB9XG5cbiAgZmx1c2goKSB7XG4gICAgaWYgKHRoaXMuc3RyZWFtLndyaXRhYmxlKSB7XG4gICAgICB0aGlzLnN0cmVhbS53cml0ZShmbHVzaEJ1ZmZlcilcbiAgICB9XG4gIH1cblxuICBzeW5jKCkge1xuICAgIHRoaXMuX2VuZGluZyA9IHRydWVcbiAgICB0aGlzLl9zZW5kKGZsdXNoQnVmZmVyKVxuICAgIHRoaXMuX3NlbmQoc3luY0J1ZmZlcilcbiAgfVxuXG4gIHJlZigpIHtcbiAgICB0aGlzLnN0cmVhbS5yZWYoKVxuICB9XG5cbiAgdW5yZWYoKSB7XG4gICAgdGhpcy5zdHJlYW0udW5yZWYoKVxuICB9XG5cbiAgZW5kKCkge1xuICAgIC8vIDB4NTggPSAnWCdcbiAgICB0aGlzLl9lbmRpbmcgPSB0cnVlXG4gICAgaWYgKCF0aGlzLl9jb25uZWN0aW5nIHx8ICF0aGlzLnN0cmVhbS53cml0YWJsZSkge1xuICAgICAgdGhpcy5zdHJlYW0uZW5kKClcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICByZXR1cm4gdGhpcy5zdHJlYW0ud3JpdGUoZW5kQnVmZmVyLCAoKSA9PiB7XG4gICAgICB0aGlzLnN0cmVhbS5lbmQoKVxuICAgIH0pXG4gIH1cblxuICBjbG9zZShtc2cpIHtcbiAgICB0aGlzLl9zZW5kKHNlcmlhbGl6ZS5jbG9zZShtc2cpKVxuICB9XG5cbiAgZGVzY3JpYmUobXNnKSB7XG4gICAgdGhpcy5fc2VuZChzZXJpYWxpemUuZGVzY3JpYmUobXNnKSlcbiAgfVxuXG4gIHNlbmRDb3B5RnJvbUNodW5rKGNodW5rKSB7XG4gICAgdGhpcy5fc2VuZChzZXJpYWxpemUuY29weURhdGEoY2h1bmspKVxuICB9XG5cbiAgZW5kQ29weUZyb20oKSB7XG4gICAgdGhpcy5fc2VuZChzZXJpYWxpemUuY29weURvbmUoKSlcbiAgfVxuXG4gIHNlbmRDb3B5RmFpbChtc2cpIHtcbiAgICB0aGlzLl9zZW5kKHNlcmlhbGl6ZS5jb3B5RmFpbChtc2cpKVxuICB9XG59XG5cbm1vZHVsZS5leHBvcnRzID0gQ29ubmVjdGlvblxuIiwiJ3VzZSBzdHJpY3QnXG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICAvLyBkYXRhYmFzZSBob3N0LiBkZWZhdWx0cyB0byBsb2NhbGhvc3RcbiAgaG9zdDogJ2xvY2FsaG9zdCcsXG5cbiAgLy8gZGF0YWJhc2UgdXNlcidzIG5hbWVcbiAgdXNlcjogcHJvY2Vzcy5wbGF0Zm9ybSA9PT0gJ3dpbjMyJyA/IHByb2Nlc3MuZW52LlVTRVJOQU1FIDogcHJvY2Vzcy5lbnYuVVNFUixcblxuICAvLyBuYW1lIG9mIGRhdGFiYXNlIHRvIGNvbm5lY3RcbiAgZGF0YWJhc2U6IHVuZGVmaW5lZCxcblxuICAvLyBkYXRhYmFzZSB1c2VyJ3MgcGFzc3dvcmRcbiAgcGFzc3dvcmQ6IG51bGwsXG5cbiAgLy8gYSBQb3N0Z3JlcyBjb25uZWN0aW9uIHN0cmluZyB0byBiZSB1c2VkIGluc3RlYWQgb2Ygc2V0dGluZyBpbmRpdmlkdWFsIGNvbm5lY3Rpb24gaXRlbXNcbiAgLy8gTk9URTogIFNldHRpbmcgdGhpcyB2YWx1ZSB3aWxsIGNhdXNlIGl0IHRvIG92ZXJyaWRlIGFueSBvdGhlciB2YWx1ZSAoc3VjaCBhcyBkYXRhYmFzZSBvciB1c2VyKSBkZWZpbmVkXG4gIC8vIGluIHRoZSBkZWZhdWx0cyBvYmplY3QuXG4gIGNvbm5lY3Rpb25TdHJpbmc6IHVuZGVmaW5lZCxcblxuICAvLyBkYXRhYmFzZSBwb3J0XG4gIHBvcnQ6IDU0MzIsXG5cbiAgLy8gbnVtYmVyIG9mIHJvd3MgdG8gcmV0dXJuIGF0IGEgdGltZSBmcm9tIGEgcHJlcGFyZWQgc3RhdGVtZW50J3NcbiAgLy8gcG9ydGFsLiAwIHdpbGwgcmV0dXJuIGFsbCByb3dzIGF0IG9uY2VcbiAgcm93czogMCxcblxuICAvLyBiaW5hcnkgcmVzdWx0IG1vZGVcbiAgYmluYXJ5OiBmYWxzZSxcblxuICAvLyBDb25uZWN0aW9uIHBvb2wgb3B0aW9ucyAtIHNlZSBodHRwczovL2dpdGh1Yi5jb20vYnJpYW5jL25vZGUtcGctcG9vbFxuXG4gIC8vIG51bWJlciBvZiBjb25uZWN0aW9ucyB0byB1c2UgaW4gY29ubmVjdGlvbiBwb29sXG4gIC8vIDAgd2lsbCBkaXNhYmxlIGNvbm5lY3Rpb24gcG9vbGluZ1xuICBtYXg6IDEwLFxuXG4gIC8vIG1heCBtaWxsaXNlY29uZHMgYSBjbGllbnQgY2FuIGdvIHVudXNlZCBiZWZvcmUgaXQgaXMgcmVtb3ZlZFxuICAvLyBmcm9tIHRoZSBwb29sIGFuZCBkZXN0cm95ZWRcbiAgaWRsZVRpbWVvdXRNaWxsaXM6IDMwMDAwLFxuXG4gIGNsaWVudF9lbmNvZGluZzogJycsXG5cbiAgc3NsOiBmYWxzZSxcblxuICBhcHBsaWNhdGlvbl9uYW1lOiB1bmRlZmluZWQsXG5cbiAgZmFsbGJhY2tfYXBwbGljYXRpb25fbmFtZTogdW5kZWZpbmVkLFxuXG4gIG9wdGlvbnM6IHVuZGVmaW5lZCxcblxuICBwYXJzZUlucHV0RGF0ZXNBc1VUQzogZmFsc2UsXG5cbiAgLy8gbWF4IG1pbGxpc2Vjb25kcyBhbnkgcXVlcnkgdXNpbmcgdGhpcyBjb25uZWN0aW9uIHdpbGwgZXhlY3V0ZSBmb3IgYmVmb3JlIHRpbWluZyBvdXQgaW4gZXJyb3IuXG4gIC8vIGZhbHNlPXVubGltaXRlZFxuICBzdGF0ZW1lbnRfdGltZW91dDogZmFsc2UsXG5cbiAgLy8gVGVybWluYXRlIGFueSBzZXNzaW9uIHdpdGggYW4gb3BlbiB0cmFuc2FjdGlvbiB0aGF0IGhhcyBiZWVuIGlkbGUgZm9yIGxvbmdlciB0aGFuIHRoZSBzcGVjaWZpZWQgZHVyYXRpb24gaW4gbWlsbGlzZWNvbmRzXG4gIC8vIGZhbHNlPXVubGltaXRlZFxuICBpZGxlX2luX3RyYW5zYWN0aW9uX3Nlc3Npb25fdGltZW91dDogZmFsc2UsXG5cbiAgLy8gbWF4IG1pbGxpc2Vjb25kcyB0byB3YWl0IGZvciBxdWVyeSB0byBjb21wbGV0ZSAoY2xpZW50IHNpZGUpXG4gIHF1ZXJ5X3RpbWVvdXQ6IGZhbHNlLFxuXG4gIGNvbm5lY3RfdGltZW91dDogMCxcblxuICBrZWVwYWxpdmVzOiAxLFxuXG4gIGtlZXBhbGl2ZXNfaWRsZTogMCxcbn1cblxudmFyIHBnVHlwZXMgPSByZXF1aXJlKCdwZy10eXBlcycpXG4vLyBzYXZlIGRlZmF1bHQgcGFyc2Vyc1xudmFyIHBhcnNlQmlnSW50ZWdlciA9IHBnVHlwZXMuZ2V0VHlwZVBhcnNlcigyMCwgJ3RleHQnKVxudmFyIHBhcnNlQmlnSW50ZWdlckFycmF5ID0gcGdUeXBlcy5nZXRUeXBlUGFyc2VyKDEwMTYsICd0ZXh0JylcblxuLy8gcGFyc2UgaW50OCBzbyB5b3UgY2FuIGdldCB5b3VyIGNvdW50IHZhbHVlcyBhcyBhY3R1YWwgbnVtYmVyc1xubW9kdWxlLmV4cG9ydHMuX19kZWZpbmVTZXR0ZXJfXygncGFyc2VJbnQ4JywgZnVuY3Rpb24gKHZhbCkge1xuICBwZ1R5cGVzLnNldFR5cGVQYXJzZXIoMjAsICd0ZXh0JywgdmFsID8gcGdUeXBlcy5nZXRUeXBlUGFyc2VyKDIzLCAndGV4dCcpIDogcGFyc2VCaWdJbnRlZ2VyKVxuICBwZ1R5cGVzLnNldFR5cGVQYXJzZXIoMTAxNiwgJ3RleHQnLCB2YWwgPyBwZ1R5cGVzLmdldFR5cGVQYXJzZXIoMTAwNywgJ3RleHQnKSA6IHBhcnNlQmlnSW50ZWdlckFycmF5KVxufSlcbiIsIid1c2Ugc3RyaWN0J1xuXG52YXIgQ2xpZW50ID0gcmVxdWlyZSgnLi9jbGllbnQnKVxudmFyIGRlZmF1bHRzID0gcmVxdWlyZSgnLi9kZWZhdWx0cycpXG52YXIgQ29ubmVjdGlvbiA9IHJlcXVpcmUoJy4vY29ubmVjdGlvbicpXG52YXIgUG9vbCA9IHJlcXVpcmUoJ3BnLXBvb2wnKVxuY29uc3QgeyBEYXRhYmFzZUVycm9yIH0gPSByZXF1aXJlKCdwZy1wcm90b2NvbCcpXG5cbmNvbnN0IHBvb2xGYWN0b3J5ID0gKENsaWVudCkgPT4ge1xuICByZXR1cm4gY2xhc3MgQm91bmRQb29sIGV4dGVuZHMgUG9vbCB7XG4gICAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgICAgc3VwZXIob3B0aW9ucywgQ2xpZW50KVxuICAgIH1cbiAgfVxufVxuXG52YXIgUEcgPSBmdW5jdGlvbiAoY2xpZW50Q29uc3RydWN0b3IpIHtcbiAgdGhpcy5kZWZhdWx0cyA9IGRlZmF1bHRzXG4gIHRoaXMuQ2xpZW50ID0gY2xpZW50Q29uc3RydWN0b3JcbiAgdGhpcy5RdWVyeSA9IHRoaXMuQ2xpZW50LlF1ZXJ5XG4gIHRoaXMuUG9vbCA9IHBvb2xGYWN0b3J5KHRoaXMuQ2xpZW50KVxuICB0aGlzLl9wb29scyA9IFtdXG4gIHRoaXMuQ29ubmVjdGlvbiA9IENvbm5lY3Rpb25cbiAgdGhpcy50eXBlcyA9IHJlcXVpcmUoJ3BnLXR5cGVzJylcbiAgdGhpcy5EYXRhYmFzZUVycm9yID0gRGF0YWJhc2VFcnJvclxufVxuXG5pZiAodHlwZW9mIHByb2Nlc3MuZW52Lk5PREVfUEdfRk9SQ0VfTkFUSVZFICE9PSAndW5kZWZpbmVkJykge1xuICBtb2R1bGUuZXhwb3J0cyA9IG5ldyBQRyhyZXF1aXJlKCcuL25hdGl2ZScpKVxufSBlbHNlIHtcbiAgbW9kdWxlLmV4cG9ydHMgPSBuZXcgUEcoQ2xpZW50KVxuXG4gIC8vIGxhenkgcmVxdWlyZSBuYXRpdmUgbW9kdWxlLi4udGhlIG5hdGl2ZSBtb2R1bGUgbWF5IG5vdCBoYXZlIGluc3RhbGxlZFxuICBPYmplY3QuZGVmaW5lUHJvcGVydHkobW9kdWxlLmV4cG9ydHMsICduYXRpdmUnLCB7XG4gICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgIGdldCgpIHtcbiAgICAgIHZhciBuYXRpdmUgPSBudWxsXG4gICAgICB0cnkge1xuICAgICAgICBuYXRpdmUgPSBuZXcgUEcocmVxdWlyZSgnLi9uYXRpdmUnKSlcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBpZiAoZXJyLmNvZGUgIT09ICdNT0RVTEVfTk9UX0ZPVU5EJykge1xuICAgICAgICAgIHRocm93IGVyclxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIG92ZXJ3cml0ZSBtb2R1bGUuZXhwb3J0cy5uYXRpdmUgc28gdGhhdCBnZXR0ZXIgaXMgbmV2ZXIgY2FsbGVkIGFnYWluXG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkobW9kdWxlLmV4cG9ydHMsICduYXRpdmUnLCB7XG4gICAgICAgIHZhbHVlOiBuYXRpdmUsXG4gICAgICB9KVxuXG4gICAgICByZXR1cm4gbmF0aXZlXG4gICAgfSxcbiAgfSlcbn1cbiIsIid1c2Ugc3RyaWN0J1xuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmVcbnZhciBOYXRpdmUgPSByZXF1aXJlKCdwZy1uYXRpdmUnKVxudmFyIFR5cGVPdmVycmlkZXMgPSByZXF1aXJlKCcuLi90eXBlLW92ZXJyaWRlcycpXG52YXIgcGtnID0gcmVxdWlyZSgnLi4vLi4vcGFja2FnZS5qc29uJylcbnZhciBFdmVudEVtaXR0ZXIgPSByZXF1aXJlKCdldmVudHMnKS5FdmVudEVtaXR0ZXJcbnZhciB1dGlsID0gcmVxdWlyZSgndXRpbCcpXG52YXIgQ29ubmVjdGlvblBhcmFtZXRlcnMgPSByZXF1aXJlKCcuLi9jb25uZWN0aW9uLXBhcmFtZXRlcnMnKVxuXG52YXIgTmF0aXZlUXVlcnkgPSByZXF1aXJlKCcuL3F1ZXJ5JylcblxudmFyIENsaWVudCA9IChtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChjb25maWcpIHtcbiAgRXZlbnRFbWl0dGVyLmNhbGwodGhpcylcbiAgY29uZmlnID0gY29uZmlnIHx8IHt9XG5cbiAgdGhpcy5fUHJvbWlzZSA9IGNvbmZpZy5Qcm9taXNlIHx8IGdsb2JhbC5Qcm9taXNlXG4gIHRoaXMuX3R5cGVzID0gbmV3IFR5cGVPdmVycmlkZXMoY29uZmlnLnR5cGVzKVxuXG4gIHRoaXMubmF0aXZlID0gbmV3IE5hdGl2ZSh7XG4gICAgdHlwZXM6IHRoaXMuX3R5cGVzLFxuICB9KVxuXG4gIHRoaXMuX3F1ZXJ5UXVldWUgPSBbXVxuICB0aGlzLl9lbmRpbmcgPSBmYWxzZVxuICB0aGlzLl9jb25uZWN0aW5nID0gZmFsc2VcbiAgdGhpcy5fY29ubmVjdGVkID0gZmFsc2VcbiAgdGhpcy5fcXVlcnlhYmxlID0gdHJ1ZVxuXG4gIC8vIGtlZXAgdGhlc2Ugb24gdGhlIG9iamVjdCBmb3IgbGVnYWN5IHJlYXNvbnNcbiAgLy8gZm9yIHRoZSB0aW1lIGJlaW5nLiBUT0RPOiBkZXByZWNhdGUgYWxsIHRoaXMgamF6elxuICB2YXIgY3AgPSAodGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycyA9IG5ldyBDb25uZWN0aW9uUGFyYW1ldGVycyhjb25maWcpKVxuICB0aGlzLnVzZXIgPSBjcC51c2VyXG5cbiAgLy8gXCJoaWRpbmdcIiB0aGUgcGFzc3dvcmQgc28gaXQgZG9lc24ndCBzaG93IHVwIGluIHN0YWNrIHRyYWNlc1xuICAvLyBvciBpZiB0aGUgY2xpZW50IGlzIGNvbnNvbGUubG9nZ2VkXG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCAncGFzc3dvcmQnLCB7XG4gICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgIHZhbHVlOiBjcC5wYXNzd29yZCxcbiAgfSlcbiAgdGhpcy5kYXRhYmFzZSA9IGNwLmRhdGFiYXNlXG4gIHRoaXMuaG9zdCA9IGNwLmhvc3RcbiAgdGhpcy5wb3J0ID0gY3AucG9ydFxuXG4gIC8vIGEgaGFzaCB0byBob2xkIG5hbWVkIHF1ZXJpZXNcbiAgdGhpcy5uYW1lZFF1ZXJpZXMgPSB7fVxufSlcblxuQ2xpZW50LlF1ZXJ5ID0gTmF0aXZlUXVlcnlcblxudXRpbC5pbmhlcml0cyhDbGllbnQsIEV2ZW50RW1pdHRlcilcblxuQ2xpZW50LnByb3RvdHlwZS5fZXJyb3JBbGxRdWVyaWVzID0gZnVuY3Rpb24gKGVycikge1xuICBjb25zdCBlbnF1ZXVlRXJyb3IgPSAocXVlcnkpID0+IHtcbiAgICBwcm9jZXNzLm5leHRUaWNrKCgpID0+IHtcbiAgICAgIHF1ZXJ5Lm5hdGl2ZSA9IHRoaXMubmF0aXZlXG4gICAgICBxdWVyeS5oYW5kbGVFcnJvcihlcnIpXG4gICAgfSlcbiAgfVxuXG4gIGlmICh0aGlzLl9oYXNBY3RpdmVRdWVyeSgpKSB7XG4gICAgZW5xdWV1ZUVycm9yKHRoaXMuX2FjdGl2ZVF1ZXJ5KVxuICAgIHRoaXMuX2FjdGl2ZVF1ZXJ5ID0gbnVsbFxuICB9XG5cbiAgdGhpcy5fcXVlcnlRdWV1ZS5mb3JFYWNoKGVucXVldWVFcnJvcilcbiAgdGhpcy5fcXVlcnlRdWV1ZS5sZW5ndGggPSAwXG59XG5cbi8vIGNvbm5lY3QgdG8gdGhlIGJhY2tlbmRcbi8vIHBhc3MgYW4gb3B0aW9uYWwgY2FsbGJhY2sgdG8gYmUgY2FsbGVkIG9uY2UgY29ubmVjdGVkXG4vLyBvciB3aXRoIGFuIGVycm9yIGlmIHRoZXJlIHdhcyBhIGNvbm5lY3Rpb24gZXJyb3JcbkNsaWVudC5wcm90b3R5cGUuX2Nvbm5lY3QgPSBmdW5jdGlvbiAoY2IpIHtcbiAgdmFyIHNlbGYgPSB0aGlzXG5cbiAgaWYgKHRoaXMuX2Nvbm5lY3RpbmcpIHtcbiAgICBwcm9jZXNzLm5leHRUaWNrKCgpID0+IGNiKG5ldyBFcnJvcignQ2xpZW50IGhhcyBhbHJlYWR5IGJlZW4gY29ubmVjdGVkLiBZb3UgY2Fubm90IHJldXNlIGEgY2xpZW50LicpKSlcbiAgICByZXR1cm5cbiAgfVxuXG4gIHRoaXMuX2Nvbm5lY3RpbmcgPSB0cnVlXG5cbiAgdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy5nZXRMaWJwcUNvbm5lY3Rpb25TdHJpbmcoZnVuY3Rpb24gKGVyciwgY29uU3RyaW5nKSB7XG4gICAgaWYgKGVycikgcmV0dXJuIGNiKGVycilcbiAgICBzZWxmLm5hdGl2ZS5jb25uZWN0KGNvblN0cmluZywgZnVuY3Rpb24gKGVycikge1xuICAgICAgaWYgKGVycikge1xuICAgICAgICBzZWxmLm5hdGl2ZS5lbmQoKVxuICAgICAgICByZXR1cm4gY2IoZXJyKVxuICAgICAgfVxuXG4gICAgICAvLyBzZXQgaW50ZXJuYWwgc3RhdGVzIHRvIGNvbm5lY3RlZFxuICAgICAgc2VsZi5fY29ubmVjdGVkID0gdHJ1ZVxuXG4gICAgICAvLyBoYW5kbGUgY29ubmVjdGlvbiBlcnJvcnMgZnJvbSB0aGUgbmF0aXZlIGxheWVyXG4gICAgICBzZWxmLm5hdGl2ZS5vbignZXJyb3InLCBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgIHNlbGYuX3F1ZXJ5YWJsZSA9IGZhbHNlXG4gICAgICAgIHNlbGYuX2Vycm9yQWxsUXVlcmllcyhlcnIpXG4gICAgICAgIHNlbGYuZW1pdCgnZXJyb3InLCBlcnIpXG4gICAgICB9KVxuXG4gICAgICBzZWxmLm5hdGl2ZS5vbignbm90aWZpY2F0aW9uJywgZnVuY3Rpb24gKG1zZykge1xuICAgICAgICBzZWxmLmVtaXQoJ25vdGlmaWNhdGlvbicsIHtcbiAgICAgICAgICBjaGFubmVsOiBtc2cucmVsbmFtZSxcbiAgICAgICAgICBwYXlsb2FkOiBtc2cuZXh0cmEsXG4gICAgICAgIH0pXG4gICAgICB9KVxuXG4gICAgICAvLyBzaWduYWwgd2UgYXJlIGNvbm5lY3RlZCBub3dcbiAgICAgIHNlbGYuZW1pdCgnY29ubmVjdCcpXG4gICAgICBzZWxmLl9wdWxzZVF1ZXJ5UXVldWUodHJ1ZSlcblxuICAgICAgY2IoKVxuICAgIH0pXG4gIH0pXG59XG5cbkNsaWVudC5wcm90b3R5cGUuY29ubmVjdCA9IGZ1bmN0aW9uIChjYWxsYmFjaykge1xuICBpZiAoY2FsbGJhY2spIHtcbiAgICB0aGlzLl9jb25uZWN0KGNhbGxiYWNrKVxuICAgIHJldHVyblxuICB9XG5cbiAgcmV0dXJuIG5ldyB0aGlzLl9Qcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICB0aGlzLl9jb25uZWN0KChlcnJvcikgPT4ge1xuICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgIHJlamVjdChlcnJvcilcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlc29sdmUoKVxuICAgICAgfVxuICAgIH0pXG4gIH0pXG59XG5cbi8vIHNlbmQgYSBxdWVyeSB0byB0aGUgc2VydmVyXG4vLyB0aGlzIG1ldGhvZCBpcyBoaWdobHkgb3ZlcmxvYWRlZCB0byB0YWtlXG4vLyAxKSBzdHJpbmcgcXVlcnksIG9wdGlvbmFsIGFycmF5IG9mIHBhcmFtZXRlcnMsIG9wdGlvbmFsIGZ1bmN0aW9uIGNhbGxiYWNrXG4vLyAyKSBvYmplY3QgcXVlcnkgd2l0aCB7XG4vLyAgICBzdHJpbmcgcXVlcnlcbi8vICAgIG9wdGlvbmFsIGFycmF5IHZhbHVlcyxcbi8vICAgIG9wdGlvbmFsIGZ1bmN0aW9uIGNhbGxiYWNrIGluc3RlYWQgb2YgYXMgYSBzZXBhcmF0ZSBwYXJhbWV0ZXJcbi8vICAgIG9wdGlvbmFsIHN0cmluZyBuYW1lIHRvIG5hbWUgJiBjYWNoZSB0aGUgcXVlcnkgcGxhblxuLy8gICAgb3B0aW9uYWwgc3RyaW5nIHJvd01vZGUgPSAnYXJyYXknIGZvciBhbiBhcnJheSBvZiByZXN1bHRzXG4vLyAgfVxuQ2xpZW50LnByb3RvdHlwZS5xdWVyeSA9IGZ1bmN0aW9uIChjb25maWcsIHZhbHVlcywgY2FsbGJhY2spIHtcbiAgdmFyIHF1ZXJ5XG4gIHZhciByZXN1bHRcbiAgdmFyIHJlYWRUaW1lb3V0XG4gIHZhciByZWFkVGltZW91dFRpbWVyXG4gIHZhciBxdWVyeUNhbGxiYWNrXG5cbiAgaWYgKGNvbmZpZyA9PT0gbnVsbCB8fCBjb25maWcgPT09IHVuZGVmaW5lZCkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ0NsaWVudCB3YXMgcGFzc2VkIGEgbnVsbCBvciB1bmRlZmluZWQgcXVlcnknKVxuICB9IGVsc2UgaWYgKHR5cGVvZiBjb25maWcuc3VibWl0ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgcmVhZFRpbWVvdXQgPSBjb25maWcucXVlcnlfdGltZW91dCB8fCB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLnF1ZXJ5X3RpbWVvdXRcbiAgICByZXN1bHQgPSBxdWVyeSA9IGNvbmZpZ1xuICAgIC8vIGFjY2VwdCBxdWVyeShuZXcgUXVlcnkoLi4uKSwgKGVyciwgcmVzKSA9PiB7IH0pIHN0eWxlXG4gICAgaWYgKHR5cGVvZiB2YWx1ZXMgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIGNvbmZpZy5jYWxsYmFjayA9IHZhbHVlc1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICByZWFkVGltZW91dCA9IHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMucXVlcnlfdGltZW91dFxuICAgIHF1ZXJ5ID0gbmV3IE5hdGl2ZVF1ZXJ5KGNvbmZpZywgdmFsdWVzLCBjYWxsYmFjaylcbiAgICBpZiAoIXF1ZXJ5LmNhbGxiYWNrKSB7XG4gICAgICBsZXQgcmVzb2x2ZU91dCwgcmVqZWN0T3V0XG4gICAgICByZXN1bHQgPSBuZXcgdGhpcy5fUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIHJlc29sdmVPdXQgPSByZXNvbHZlXG4gICAgICAgIHJlamVjdE91dCA9IHJlamVjdFxuICAgICAgfSlcbiAgICAgIHF1ZXJ5LmNhbGxiYWNrID0gKGVyciwgcmVzKSA9PiAoZXJyID8gcmVqZWN0T3V0KGVycikgOiByZXNvbHZlT3V0KHJlcykpXG4gICAgfVxuICB9XG5cbiAgaWYgKHJlYWRUaW1lb3V0KSB7XG4gICAgcXVlcnlDYWxsYmFjayA9IHF1ZXJ5LmNhbGxiYWNrXG5cbiAgICByZWFkVGltZW91dFRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICB2YXIgZXJyb3IgPSBuZXcgRXJyb3IoJ1F1ZXJ5IHJlYWQgdGltZW91dCcpXG5cbiAgICAgIHByb2Nlc3MubmV4dFRpY2soKCkgPT4ge1xuICAgICAgICBxdWVyeS5oYW5kbGVFcnJvcihlcnJvciwgdGhpcy5jb25uZWN0aW9uKVxuICAgICAgfSlcblxuICAgICAgcXVlcnlDYWxsYmFjayhlcnJvcilcblxuICAgICAgLy8gd2UgYWxyZWFkeSByZXR1cm5lZCBhbiBlcnJvcixcbiAgICAgIC8vIGp1c3QgZG8gbm90aGluZyBpZiBxdWVyeSBjb21wbGV0ZXNcbiAgICAgIHF1ZXJ5LmNhbGxiYWNrID0gKCkgPT4ge31cblxuICAgICAgLy8gUmVtb3ZlIGZyb20gcXVldWVcbiAgICAgIHZhciBpbmRleCA9IHRoaXMuX3F1ZXJ5UXVldWUuaW5kZXhPZihxdWVyeSlcbiAgICAgIGlmIChpbmRleCA+IC0xKSB7XG4gICAgICAgIHRoaXMuX3F1ZXJ5UXVldWUuc3BsaWNlKGluZGV4LCAxKVxuICAgICAgfVxuXG4gICAgICB0aGlzLl9wdWxzZVF1ZXJ5UXVldWUoKVxuICAgIH0sIHJlYWRUaW1lb3V0KVxuXG4gICAgcXVlcnkuY2FsbGJhY2sgPSAoZXJyLCByZXMpID0+IHtcbiAgICAgIGNsZWFyVGltZW91dChyZWFkVGltZW91dFRpbWVyKVxuICAgICAgcXVlcnlDYWxsYmFjayhlcnIsIHJlcylcbiAgICB9XG4gIH1cblxuICBpZiAoIXRoaXMuX3F1ZXJ5YWJsZSkge1xuICAgIHF1ZXJ5Lm5hdGl2ZSA9IHRoaXMubmF0aXZlXG4gICAgcHJvY2Vzcy5uZXh0VGljaygoKSA9PiB7XG4gICAgICBxdWVyeS5oYW5kbGVFcnJvcihuZXcgRXJyb3IoJ0NsaWVudCBoYXMgZW5jb3VudGVyZWQgYSBjb25uZWN0aW9uIGVycm9yIGFuZCBpcyBub3QgcXVlcnlhYmxlJykpXG4gICAgfSlcbiAgICByZXR1cm4gcmVzdWx0XG4gIH1cblxuICBpZiAodGhpcy5fZW5kaW5nKSB7XG4gICAgcXVlcnkubmF0aXZlID0gdGhpcy5uYXRpdmVcbiAgICBwcm9jZXNzLm5leHRUaWNrKCgpID0+IHtcbiAgICAgIHF1ZXJ5LmhhbmRsZUVycm9yKG5ldyBFcnJvcignQ2xpZW50IHdhcyBjbG9zZWQgYW5kIGlzIG5vdCBxdWVyeWFibGUnKSlcbiAgICB9KVxuICAgIHJldHVybiByZXN1bHRcbiAgfVxuXG4gIHRoaXMuX3F1ZXJ5UXVldWUucHVzaChxdWVyeSlcbiAgdGhpcy5fcHVsc2VRdWVyeVF1ZXVlKClcbiAgcmV0dXJuIHJlc3VsdFxufVxuXG4vLyBkaXNjb25uZWN0IGZyb20gdGhlIGJhY2tlbmQgc2VydmVyXG5DbGllbnQucHJvdG90eXBlLmVuZCA9IGZ1bmN0aW9uIChjYikge1xuICB2YXIgc2VsZiA9IHRoaXNcblxuICB0aGlzLl9lbmRpbmcgPSB0cnVlXG5cbiAgaWYgKCF0aGlzLl9jb25uZWN0ZWQpIHtcbiAgICB0aGlzLm9uY2UoJ2Nvbm5lY3QnLCB0aGlzLmVuZC5iaW5kKHRoaXMsIGNiKSlcbiAgfVxuICB2YXIgcmVzdWx0XG4gIGlmICghY2IpIHtcbiAgICByZXN1bHQgPSBuZXcgdGhpcy5fUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICBjYiA9IChlcnIpID0+IChlcnIgPyByZWplY3QoZXJyKSA6IHJlc29sdmUoKSlcbiAgICB9KVxuICB9XG4gIHRoaXMubmF0aXZlLmVuZChmdW5jdGlvbiAoKSB7XG4gICAgc2VsZi5fZXJyb3JBbGxRdWVyaWVzKG5ldyBFcnJvcignQ29ubmVjdGlvbiB0ZXJtaW5hdGVkJykpXG5cbiAgICBwcm9jZXNzLm5leHRUaWNrKCgpID0+IHtcbiAgICAgIHNlbGYuZW1pdCgnZW5kJylcbiAgICAgIGlmIChjYikgY2IoKVxuICAgIH0pXG4gIH0pXG4gIHJldHVybiByZXN1bHRcbn1cblxuQ2xpZW50LnByb3RvdHlwZS5faGFzQWN0aXZlUXVlcnkgPSBmdW5jdGlvbiAoKSB7XG4gIHJldHVybiB0aGlzLl9hY3RpdmVRdWVyeSAmJiB0aGlzLl9hY3RpdmVRdWVyeS5zdGF0ZSAhPT0gJ2Vycm9yJyAmJiB0aGlzLl9hY3RpdmVRdWVyeS5zdGF0ZSAhPT0gJ2VuZCdcbn1cblxuQ2xpZW50LnByb3RvdHlwZS5fcHVsc2VRdWVyeVF1ZXVlID0gZnVuY3Rpb24gKGluaXRpYWxDb25uZWN0aW9uKSB7XG4gIGlmICghdGhpcy5fY29ubmVjdGVkKSB7XG4gICAgcmV0dXJuXG4gIH1cbiAgaWYgKHRoaXMuX2hhc0FjdGl2ZVF1ZXJ5KCkpIHtcbiAgICByZXR1cm5cbiAgfVxuICB2YXIgcXVlcnkgPSB0aGlzLl9xdWVyeVF1ZXVlLnNoaWZ0KClcbiAgaWYgKCFxdWVyeSkge1xuICAgIGlmICghaW5pdGlhbENvbm5lY3Rpb24pIHtcbiAgICAgIHRoaXMuZW1pdCgnZHJhaW4nKVxuICAgIH1cbiAgICByZXR1cm5cbiAgfVxuICB0aGlzLl9hY3RpdmVRdWVyeSA9IHF1ZXJ5XG4gIHF1ZXJ5LnN1Ym1pdCh0aGlzKVxuICB2YXIgc2VsZiA9IHRoaXNcbiAgcXVlcnkub25jZSgnX2RvbmUnLCBmdW5jdGlvbiAoKSB7XG4gICAgc2VsZi5fcHVsc2VRdWVyeVF1ZXVlKClcbiAgfSlcbn1cblxuLy8gYXR0ZW1wdCB0byBjYW5jZWwgYW4gaW4tcHJvZ3Jlc3MgcXVlcnlcbkNsaWVudC5wcm90b3R5cGUuY2FuY2VsID0gZnVuY3Rpb24gKHF1ZXJ5KSB7XG4gIGlmICh0aGlzLl9hY3RpdmVRdWVyeSA9PT0gcXVlcnkpIHtcbiAgICB0aGlzLm5hdGl2ZS5jYW5jZWwoZnVuY3Rpb24gKCkge30pXG4gIH0gZWxzZSBpZiAodGhpcy5fcXVlcnlRdWV1ZS5pbmRleE9mKHF1ZXJ5KSAhPT0gLTEpIHtcbiAgICB0aGlzLl9xdWVyeVF1ZXVlLnNwbGljZSh0aGlzLl9xdWVyeVF1ZXVlLmluZGV4T2YocXVlcnkpLCAxKVxuICB9XG59XG5cbkNsaWVudC5wcm90b3R5cGUucmVmID0gZnVuY3Rpb24gKCkge31cbkNsaWVudC5wcm90b3R5cGUudW5yZWYgPSBmdW5jdGlvbiAoKSB7fVxuXG5DbGllbnQucHJvdG90eXBlLnNldFR5cGVQYXJzZXIgPSBmdW5jdGlvbiAob2lkLCBmb3JtYXQsIHBhcnNlRm4pIHtcbiAgcmV0dXJuIHRoaXMuX3R5cGVzLnNldFR5cGVQYXJzZXIob2lkLCBmb3JtYXQsIHBhcnNlRm4pXG59XG5cbkNsaWVudC5wcm90b3R5cGUuZ2V0VHlwZVBhcnNlciA9IGZ1bmN0aW9uIChvaWQsIGZvcm1hdCkge1xuICByZXR1cm4gdGhpcy5fdHlwZXMuZ2V0VHlwZVBhcnNlcihvaWQsIGZvcm1hdClcbn1cbiIsIid1c2Ugc3RyaWN0J1xubW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuL2NsaWVudCcpXG4iLCIndXNlIHN0cmljdCdcblxudmFyIEV2ZW50RW1pdHRlciA9IHJlcXVpcmUoJ2V2ZW50cycpLkV2ZW50RW1pdHRlclxudmFyIHV0aWwgPSByZXF1aXJlKCd1dGlsJylcbnZhciB1dGlscyA9IHJlcXVpcmUoJy4uL3V0aWxzJylcblxudmFyIE5hdGl2ZVF1ZXJ5ID0gKG1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGNvbmZpZywgdmFsdWVzLCBjYWxsYmFjaykge1xuICBFdmVudEVtaXR0ZXIuY2FsbCh0aGlzKVxuICBjb25maWcgPSB1dGlscy5ub3JtYWxpemVRdWVyeUNvbmZpZyhjb25maWcsIHZhbHVlcywgY2FsbGJhY2spXG4gIHRoaXMudGV4dCA9IGNvbmZpZy50ZXh0XG4gIHRoaXMudmFsdWVzID0gY29uZmlnLnZhbHVlc1xuICB0aGlzLm5hbWUgPSBjb25maWcubmFtZVxuICB0aGlzLmNhbGxiYWNrID0gY29uZmlnLmNhbGxiYWNrXG4gIHRoaXMuc3RhdGUgPSAnbmV3J1xuICB0aGlzLl9hcnJheU1vZGUgPSBjb25maWcucm93TW9kZSA9PT0gJ2FycmF5J1xuXG4gIC8vIGlmIHRoZSAncm93JyBldmVudCBpcyBsaXN0ZW5lZCBmb3JcbiAgLy8gdGhlbiBlbWl0IHRoZW0gYXMgdGhleSBjb21lIGluXG4gIC8vIHdpdGhvdXQgc2V0dGluZyBzaW5nbGVSb3dNb2RlIHRvIHRydWVcbiAgLy8gdGhpcyBoYXMgYWxtb3N0IG5vIG1lYW5pbmcgYmVjYXVzZSBsaWJwcVxuICAvLyByZWFkcyBhbGwgcm93cyBpbnRvIG1lbW9yeSBiZWZvciByZXR1cm5pbmcgYW55XG4gIHRoaXMuX2VtaXRSb3dFdmVudHMgPSBmYWxzZVxuICB0aGlzLm9uKFxuICAgICduZXdMaXN0ZW5lcicsXG4gICAgZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICBpZiAoZXZlbnQgPT09ICdyb3cnKSB0aGlzLl9lbWl0Um93RXZlbnRzID0gdHJ1ZVxuICAgIH0uYmluZCh0aGlzKVxuICApXG59KVxuXG51dGlsLmluaGVyaXRzKE5hdGl2ZVF1ZXJ5LCBFdmVudEVtaXR0ZXIpXG5cbnZhciBlcnJvckZpZWxkTWFwID0ge1xuICAvKiBlc2xpbnQtZGlzYWJsZSBxdW90ZS1wcm9wcyAqL1xuICBzcWxTdGF0ZTogJ2NvZGUnLFxuICBzdGF0ZW1lbnRQb3NpdGlvbjogJ3Bvc2l0aW9uJyxcbiAgbWVzc2FnZVByaW1hcnk6ICdtZXNzYWdlJyxcbiAgY29udGV4dDogJ3doZXJlJyxcbiAgc2NoZW1hTmFtZTogJ3NjaGVtYScsXG4gIHRhYmxlTmFtZTogJ3RhYmxlJyxcbiAgY29sdW1uTmFtZTogJ2NvbHVtbicsXG4gIGRhdGFUeXBlTmFtZTogJ2RhdGFUeXBlJyxcbiAgY29uc3RyYWludE5hbWU6ICdjb25zdHJhaW50JyxcbiAgc291cmNlRmlsZTogJ2ZpbGUnLFxuICBzb3VyY2VMaW5lOiAnbGluZScsXG4gIHNvdXJjZUZ1bmN0aW9uOiAncm91dGluZScsXG59XG5cbk5hdGl2ZVF1ZXJ5LnByb3RvdHlwZS5oYW5kbGVFcnJvciA9IGZ1bmN0aW9uIChlcnIpIHtcbiAgLy8gY29weSBwcSBlcnJvciBmaWVsZHMgaW50byB0aGUgZXJyb3Igb2JqZWN0XG4gIHZhciBmaWVsZHMgPSB0aGlzLm5hdGl2ZS5wcS5yZXN1bHRFcnJvckZpZWxkcygpXG4gIGlmIChmaWVsZHMpIHtcbiAgICBmb3IgKHZhciBrZXkgaW4gZmllbGRzKSB7XG4gICAgICB2YXIgbm9ybWFsaXplZEZpZWxkTmFtZSA9IGVycm9yRmllbGRNYXBba2V5XSB8fCBrZXlcbiAgICAgIGVycltub3JtYWxpemVkRmllbGROYW1lXSA9IGZpZWxkc1trZXldXG4gICAgfVxuICB9XG4gIGlmICh0aGlzLmNhbGxiYWNrKSB7XG4gICAgdGhpcy5jYWxsYmFjayhlcnIpXG4gIH0gZWxzZSB7XG4gICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycilcbiAgfVxuICB0aGlzLnN0YXRlID0gJ2Vycm9yJ1xufVxuXG5OYXRpdmVRdWVyeS5wcm90b3R5cGUudGhlbiA9IGZ1bmN0aW9uIChvblN1Y2Nlc3MsIG9uRmFpbHVyZSkge1xuICByZXR1cm4gdGhpcy5fZ2V0UHJvbWlzZSgpLnRoZW4ob25TdWNjZXNzLCBvbkZhaWx1cmUpXG59XG5cbk5hdGl2ZVF1ZXJ5LnByb3RvdHlwZS5jYXRjaCA9IGZ1bmN0aW9uIChjYWxsYmFjaykge1xuICByZXR1cm4gdGhpcy5fZ2V0UHJvbWlzZSgpLmNhdGNoKGNhbGxiYWNrKVxufVxuXG5OYXRpdmVRdWVyeS5wcm90b3R5cGUuX2dldFByb21pc2UgPSBmdW5jdGlvbiAoKSB7XG4gIGlmICh0aGlzLl9wcm9taXNlKSByZXR1cm4gdGhpcy5fcHJvbWlzZVxuICB0aGlzLl9wcm9taXNlID0gbmV3IFByb21pc2UoXG4gICAgZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgdGhpcy5fb25jZSgnZW5kJywgcmVzb2x2ZSlcbiAgICAgIHRoaXMuX29uY2UoJ2Vycm9yJywgcmVqZWN0KVxuICAgIH0uYmluZCh0aGlzKVxuICApXG4gIHJldHVybiB0aGlzLl9wcm9taXNlXG59XG5cbk5hdGl2ZVF1ZXJ5LnByb3RvdHlwZS5zdWJtaXQgPSBmdW5jdGlvbiAoY2xpZW50KSB7XG4gIHRoaXMuc3RhdGUgPSAncnVubmluZydcbiAgdmFyIHNlbGYgPSB0aGlzXG4gIHRoaXMubmF0aXZlID0gY2xpZW50Lm5hdGl2ZVxuICBjbGllbnQubmF0aXZlLmFycmF5TW9kZSA9IHRoaXMuX2FycmF5TW9kZVxuXG4gIHZhciBhZnRlciA9IGZ1bmN0aW9uIChlcnIsIHJvd3MsIHJlc3VsdHMpIHtcbiAgICBjbGllbnQubmF0aXZlLmFycmF5TW9kZSA9IGZhbHNlXG4gICAgc2V0SW1tZWRpYXRlKGZ1bmN0aW9uICgpIHtcbiAgICAgIHNlbGYuZW1pdCgnX2RvbmUnKVxuICAgIH0pXG5cbiAgICAvLyBoYW5kbGUgcG9zc2libGUgcXVlcnkgZXJyb3JcbiAgICBpZiAoZXJyKSB7XG4gICAgICByZXR1cm4gc2VsZi5oYW5kbGVFcnJvcihlcnIpXG4gICAgfVxuXG4gICAgLy8gZW1pdCByb3cgZXZlbnRzIGZvciBlYWNoIHJvdyBpbiB0aGUgcmVzdWx0XG4gICAgaWYgKHNlbGYuX2VtaXRSb3dFdmVudHMpIHtcbiAgICAgIGlmIChyZXN1bHRzLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgcm93cy5mb3JFYWNoKChyb3dPZlJvd3MsIGkpID0+IHtcbiAgICAgICAgICByb3dPZlJvd3MuZm9yRWFjaCgocm93KSA9PiB7XG4gICAgICAgICAgICBzZWxmLmVtaXQoJ3JvdycsIHJvdywgcmVzdWx0c1tpXSlcbiAgICAgICAgICB9KVxuICAgICAgICB9KVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcm93cy5mb3JFYWNoKGZ1bmN0aW9uIChyb3cpIHtcbiAgICAgICAgICBzZWxmLmVtaXQoJ3JvdycsIHJvdywgcmVzdWx0cylcbiAgICAgICAgfSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBoYW5kbGUgc3VjY2Vzc2Z1bCByZXN1bHRcbiAgICBzZWxmLnN0YXRlID0gJ2VuZCdcbiAgICBzZWxmLmVtaXQoJ2VuZCcsIHJlc3VsdHMpXG4gICAgaWYgKHNlbGYuY2FsbGJhY2spIHtcbiAgICAgIHNlbGYuY2FsbGJhY2sobnVsbCwgcmVzdWx0cylcbiAgICB9XG4gIH1cblxuICBpZiAocHJvY2Vzcy5kb21haW4pIHtcbiAgICBhZnRlciA9IHByb2Nlc3MuZG9tYWluLmJpbmQoYWZ0ZXIpXG4gIH1cblxuICAvLyBuYW1lZCBxdWVyeVxuICBpZiAodGhpcy5uYW1lKSB7XG4gICAgaWYgKHRoaXMubmFtZS5sZW5ndGggPiA2Mykge1xuICAgICAgLyogZXNsaW50LWRpc2FibGUgbm8tY29uc29sZSAqL1xuICAgICAgY29uc29sZS5lcnJvcignV2FybmluZyEgUG9zdGdyZXMgb25seSBzdXBwb3J0cyA2MyBjaGFyYWN0ZXJzIGZvciBxdWVyeSBuYW1lcy4nKVxuICAgICAgY29uc29sZS5lcnJvcignWW91IHN1cHBsaWVkICVzICglcyknLCB0aGlzLm5hbWUsIHRoaXMubmFtZS5sZW5ndGgpXG4gICAgICBjb25zb2xlLmVycm9yKCdUaGlzIGNhbiBjYXVzZSBjb25mbGljdHMgYW5kIHNpbGVudCBlcnJvcnMgZXhlY3V0aW5nIHF1ZXJpZXMnKVxuICAgICAgLyogZXNsaW50LWVuYWJsZSBuby1jb25zb2xlICovXG4gICAgfVxuICAgIHZhciB2YWx1ZXMgPSAodGhpcy52YWx1ZXMgfHwgW10pLm1hcCh1dGlscy5wcmVwYXJlVmFsdWUpXG5cbiAgICAvLyBjaGVjayBpZiB0aGUgY2xpZW50IGhhcyBhbHJlYWR5IGV4ZWN1dGVkIHRoaXMgbmFtZWQgcXVlcnlcbiAgICAvLyBpZiBzby4uLmp1c3QgZXhlY3V0ZSBpdCBhZ2FpbiAtIHNraXAgdGhlIHBsYW5uaW5nIHBoYXNlXG4gICAgaWYgKGNsaWVudC5uYW1lZFF1ZXJpZXNbdGhpcy5uYW1lXSkge1xuICAgICAgaWYgKHRoaXMudGV4dCAmJiBjbGllbnQubmFtZWRRdWVyaWVzW3RoaXMubmFtZV0gIT09IHRoaXMudGV4dCkge1xuICAgICAgICBjb25zdCBlcnIgPSBuZXcgRXJyb3IoYFByZXBhcmVkIHN0YXRlbWVudHMgbXVzdCBiZSB1bmlxdWUgLSAnJHt0aGlzLm5hbWV9JyB3YXMgdXNlZCBmb3IgYSBkaWZmZXJlbnQgc3RhdGVtZW50YClcbiAgICAgICAgcmV0dXJuIGFmdGVyKGVycilcbiAgICAgIH1cbiAgICAgIHJldHVybiBjbGllbnQubmF0aXZlLmV4ZWN1dGUodGhpcy5uYW1lLCB2YWx1ZXMsIGFmdGVyKVxuICAgIH1cbiAgICAvLyBwbGFuIHRoZSBuYW1lZCBxdWVyeSB0aGUgZmlyc3QgdGltZSwgdGhlbiBleGVjdXRlIGl0XG4gICAgcmV0dXJuIGNsaWVudC5uYXRpdmUucHJlcGFyZSh0aGlzLm5hbWUsIHRoaXMudGV4dCwgdmFsdWVzLmxlbmd0aCwgZnVuY3Rpb24gKGVycikge1xuICAgICAgaWYgKGVycikgcmV0dXJuIGFmdGVyKGVycilcbiAgICAgIGNsaWVudC5uYW1lZFF1ZXJpZXNbc2VsZi5uYW1lXSA9IHNlbGYudGV4dFxuICAgICAgcmV0dXJuIHNlbGYubmF0aXZlLmV4ZWN1dGUoc2VsZi5uYW1lLCB2YWx1ZXMsIGFmdGVyKVxuICAgIH0pXG4gIH0gZWxzZSBpZiAodGhpcy52YWx1ZXMpIHtcbiAgICBpZiAoIUFycmF5LmlzQXJyYXkodGhpcy52YWx1ZXMpKSB7XG4gICAgICBjb25zdCBlcnIgPSBuZXcgRXJyb3IoJ1F1ZXJ5IHZhbHVlcyBtdXN0IGJlIGFuIGFycmF5JylcbiAgICAgIHJldHVybiBhZnRlcihlcnIpXG4gICAgfVxuICAgIHZhciB2YWxzID0gdGhpcy52YWx1ZXMubWFwKHV0aWxzLnByZXBhcmVWYWx1ZSlcbiAgICBjbGllbnQubmF0aXZlLnF1ZXJ5KHRoaXMudGV4dCwgdmFscywgYWZ0ZXIpXG4gIH0gZWxzZSB7XG4gICAgY2xpZW50Lm5hdGl2ZS5xdWVyeSh0aGlzLnRleHQsIGFmdGVyKVxuICB9XG59XG4iLCIndXNlIHN0cmljdCdcblxuY29uc3QgeyBFdmVudEVtaXR0ZXIgfSA9IHJlcXVpcmUoJ2V2ZW50cycpXG5cbmNvbnN0IFJlc3VsdCA9IHJlcXVpcmUoJy4vcmVzdWx0JylcbmNvbnN0IHV0aWxzID0gcmVxdWlyZSgnLi91dGlscycpXG5cbmNsYXNzIFF1ZXJ5IGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgY29uc3RydWN0b3IoY29uZmlnLCB2YWx1ZXMsIGNhbGxiYWNrKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgY29uZmlnID0gdXRpbHMubm9ybWFsaXplUXVlcnlDb25maWcoY29uZmlnLCB2YWx1ZXMsIGNhbGxiYWNrKVxuXG4gICAgdGhpcy50ZXh0ID0gY29uZmlnLnRleHRcbiAgICB0aGlzLnZhbHVlcyA9IGNvbmZpZy52YWx1ZXNcbiAgICB0aGlzLnJvd3MgPSBjb25maWcucm93c1xuICAgIHRoaXMudHlwZXMgPSBjb25maWcudHlwZXNcbiAgICB0aGlzLm5hbWUgPSBjb25maWcubmFtZVxuICAgIHRoaXMuYmluYXJ5ID0gY29uZmlnLmJpbmFyeVxuICAgIC8vIHVzZSB1bmlxdWUgcG9ydGFsIG5hbWUgZWFjaCB0aW1lXG4gICAgdGhpcy5wb3J0YWwgPSBjb25maWcucG9ydGFsIHx8ICcnXG4gICAgdGhpcy5jYWxsYmFjayA9IGNvbmZpZy5jYWxsYmFja1xuICAgIHRoaXMuX3Jvd01vZGUgPSBjb25maWcucm93TW9kZVxuICAgIGlmIChwcm9jZXNzLmRvbWFpbiAmJiBjb25maWcuY2FsbGJhY2spIHtcbiAgICAgIHRoaXMuY2FsbGJhY2sgPSBwcm9jZXNzLmRvbWFpbi5iaW5kKGNvbmZpZy5jYWxsYmFjaylcbiAgICB9XG4gICAgdGhpcy5fcmVzdWx0ID0gbmV3IFJlc3VsdCh0aGlzLl9yb3dNb2RlLCB0aGlzLnR5cGVzKVxuXG4gICAgLy8gcG90ZW50aWFsIGZvciBtdWx0aXBsZSByZXN1bHRzXG4gICAgdGhpcy5fcmVzdWx0cyA9IHRoaXMuX3Jlc3VsdFxuICAgIHRoaXMuaXNQcmVwYXJlZFN0YXRlbWVudCA9IGZhbHNlXG4gICAgdGhpcy5fY2FuY2VsZWREdWVUb0Vycm9yID0gZmFsc2VcbiAgICB0aGlzLl9wcm9taXNlID0gbnVsbFxuICB9XG5cbiAgcmVxdWlyZXNQcmVwYXJhdGlvbigpIHtcbiAgICAvLyBuYW1lZCBxdWVyaWVzIG11c3QgYWx3YXlzIGJlIHByZXBhcmVkXG4gICAgaWYgKHRoaXMubmFtZSkge1xuICAgICAgcmV0dXJuIHRydWVcbiAgICB9XG4gICAgLy8gYWx3YXlzIHByZXBhcmUgaWYgdGhlcmUgYXJlIG1heCBudW1iZXIgb2Ygcm93cyBleHBlY3RlZCBwZXJcbiAgICAvLyBwb3J0YWwgZXhlY3V0aW9uXG4gICAgaWYgKHRoaXMucm93cykge1xuICAgICAgcmV0dXJuIHRydWVcbiAgICB9XG4gICAgLy8gZG9uJ3QgcHJlcGFyZSBlbXB0eSB0ZXh0IHF1ZXJpZXNcbiAgICBpZiAoIXRoaXMudGV4dCkge1xuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuICAgIC8vIHByZXBhcmUgaWYgdGhlcmUgYXJlIHZhbHVlc1xuICAgIGlmICghdGhpcy52YWx1ZXMpIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgICByZXR1cm4gdGhpcy52YWx1ZXMubGVuZ3RoID4gMFxuICB9XG5cbiAgX2NoZWNrRm9yTXVsdGlyb3coKSB7XG4gICAgLy8gaWYgd2UgYWxyZWFkeSBoYXZlIGEgcmVzdWx0IHdpdGggYSBjb21tYW5kIHByb3BlcnR5XG4gICAgLy8gdGhlbiB3ZSd2ZSBhbHJlYWR5IGV4ZWN1dGVkIG9uZSBxdWVyeSBpbiBhIG11bHRpLXN0YXRlbWVudCBzaW1wbGUgcXVlcnlcbiAgICAvLyB0dXJuIG91ciByZXN1bHRzIGludG8gYW4gYXJyYXkgb2YgcmVzdWx0c1xuICAgIGlmICh0aGlzLl9yZXN1bHQuY29tbWFuZCkge1xuICAgICAgaWYgKCFBcnJheS5pc0FycmF5KHRoaXMuX3Jlc3VsdHMpKSB7XG4gICAgICAgIHRoaXMuX3Jlc3VsdHMgPSBbdGhpcy5fcmVzdWx0XVxuICAgICAgfVxuICAgICAgdGhpcy5fcmVzdWx0ID0gbmV3IFJlc3VsdCh0aGlzLl9yb3dNb2RlLCB0aGlzLnR5cGVzKVxuICAgICAgdGhpcy5fcmVzdWx0cy5wdXNoKHRoaXMuX3Jlc3VsdClcbiAgICB9XG4gIH1cblxuICAvLyBhc3NvY2lhdGVzIHJvdyBtZXRhZGF0YSBmcm9tIHRoZSBzdXBwbGllZFxuICAvLyBtZXNzYWdlIHdpdGggdGhpcyBxdWVyeSBvYmplY3RcbiAgLy8gbWV0YWRhdGEgdXNlZCB3aGVuIHBhcnNpbmcgcm93IHJlc3VsdHNcbiAgaGFuZGxlUm93RGVzY3JpcHRpb24obXNnKSB7XG4gICAgdGhpcy5fY2hlY2tGb3JNdWx0aXJvdygpXG4gICAgdGhpcy5fcmVzdWx0LmFkZEZpZWxkcyhtc2cuZmllbGRzKVxuICAgIHRoaXMuX2FjY3VtdWxhdGVSb3dzID0gdGhpcy5jYWxsYmFjayB8fCAhdGhpcy5saXN0ZW5lcnMoJ3JvdycpLmxlbmd0aFxuICB9XG5cbiAgaGFuZGxlRGF0YVJvdyhtc2cpIHtcbiAgICBsZXQgcm93XG5cbiAgICBpZiAodGhpcy5fY2FuY2VsZWREdWVUb0Vycm9yKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICB0cnkge1xuICAgICAgcm93ID0gdGhpcy5fcmVzdWx0LnBhcnNlUm93KG1zZy5maWVsZHMpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aGlzLl9jYW5jZWxlZER1ZVRvRXJyb3IgPSBlcnJcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIHRoaXMuZW1pdCgncm93Jywgcm93LCB0aGlzLl9yZXN1bHQpXG4gICAgaWYgKHRoaXMuX2FjY3VtdWxhdGVSb3dzKSB7XG4gICAgICB0aGlzLl9yZXN1bHQuYWRkUm93KHJvdylcbiAgICB9XG4gIH1cblxuICBoYW5kbGVDb21tYW5kQ29tcGxldGUobXNnLCBjb25uZWN0aW9uKSB7XG4gICAgdGhpcy5fY2hlY2tGb3JNdWx0aXJvdygpXG4gICAgdGhpcy5fcmVzdWx0LmFkZENvbW1hbmRDb21wbGV0ZShtc2cpXG4gICAgLy8gbmVlZCB0byBzeW5jIGFmdGVyIGVhY2ggY29tbWFuZCBjb21wbGV0ZSBvZiBhIHByZXBhcmVkIHN0YXRlbWVudFxuICAgIC8vIGlmIHdlIHdlcmUgdXNpbmcgYSByb3cgY291bnQgd2hpY2ggcmVzdWx0cyBpbiBtdWx0aXBsZSBjYWxscyB0byBfZ2V0Um93c1xuICAgIGlmICh0aGlzLnJvd3MpIHtcbiAgICAgIGNvbm5lY3Rpb24uc3luYygpXG4gICAgfVxuICB9XG5cbiAgLy8gaWYgYSBuYW1lZCBwcmVwYXJlZCBzdGF0ZW1lbnQgaXMgY3JlYXRlZCB3aXRoIGVtcHR5IHF1ZXJ5IHRleHRcbiAgLy8gdGhlIGJhY2tlbmQgd2lsbCBzZW5kIGFuIGVtcHR5UXVlcnkgbWVzc2FnZSBidXQgKm5vdCogYSBjb21tYW5kIGNvbXBsZXRlIG1lc3NhZ2VcbiAgLy8gc2luY2Ugd2UgcGlwZWxpbmUgc3luYyBpbW1lZGlhdGVseSBhZnRlciBleGVjdXRlIHdlIGRvbid0IG5lZWQgdG8gZG8gYW55dGhpbmcgaGVyZVxuICAvLyB1bmxlc3Mgd2UgaGF2ZSByb3dzIHNwZWNpZmllZCwgaW4gd2hpY2ggY2FzZSB3ZSBkaWQgbm90IHBpcGVsaW5lIHRoZSBpbnRpYWwgc3luYyBjYWxsXG4gIGhhbmRsZUVtcHR5UXVlcnkoY29ubmVjdGlvbikge1xuICAgIGlmICh0aGlzLnJvd3MpIHtcbiAgICAgIGNvbm5lY3Rpb24uc3luYygpXG4gICAgfVxuICB9XG5cbiAgaGFuZGxlRXJyb3IoZXJyLCBjb25uZWN0aW9uKSB7XG4gICAgLy8gbmVlZCB0byBzeW5jIGFmdGVyIGVycm9yIGR1cmluZyBhIHByZXBhcmVkIHN0YXRlbWVudFxuICAgIGlmICh0aGlzLl9jYW5jZWxlZER1ZVRvRXJyb3IpIHtcbiAgICAgIGVyciA9IHRoaXMuX2NhbmNlbGVkRHVlVG9FcnJvclxuICAgICAgdGhpcy5fY2FuY2VsZWREdWVUb0Vycm9yID0gZmFsc2VcbiAgICB9XG4gICAgLy8gaWYgY2FsbGJhY2sgc3VwcGxpZWQgZG8gbm90IGVtaXQgZXJyb3IgZXZlbnQgYXMgdW5jYXVnaHQgZXJyb3JcbiAgICAvLyBldmVudHMgd2lsbCBidWJibGUgdXAgdG8gbm9kZSBwcm9jZXNzXG4gICAgaWYgKHRoaXMuY2FsbGJhY2spIHtcbiAgICAgIHJldHVybiB0aGlzLmNhbGxiYWNrKGVycilcbiAgICB9XG4gICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycilcbiAgfVxuXG4gIGhhbmRsZVJlYWR5Rm9yUXVlcnkoY29uKSB7XG4gICAgaWYgKHRoaXMuX2NhbmNlbGVkRHVlVG9FcnJvcikge1xuICAgICAgcmV0dXJuIHRoaXMuaGFuZGxlRXJyb3IodGhpcy5fY2FuY2VsZWREdWVUb0Vycm9yLCBjb24pXG4gICAgfVxuICAgIGlmICh0aGlzLmNhbGxiYWNrKSB7XG4gICAgICB0aGlzLmNhbGxiYWNrKG51bGwsIHRoaXMuX3Jlc3VsdHMpXG4gICAgfVxuICAgIHRoaXMuZW1pdCgnZW5kJywgdGhpcy5fcmVzdWx0cylcbiAgfVxuXG4gIHN1Ym1pdChjb25uZWN0aW9uKSB7XG4gICAgaWYgKHR5cGVvZiB0aGlzLnRleHQgIT09ICdzdHJpbmcnICYmIHR5cGVvZiB0aGlzLm5hbWUgIT09ICdzdHJpbmcnKSB7XG4gICAgICByZXR1cm4gbmV3IEVycm9yKCdBIHF1ZXJ5IG11c3QgaGF2ZSBlaXRoZXIgdGV4dCBvciBhIG5hbWUuIFN1cHBseWluZyBuZWl0aGVyIGlzIHVuc3VwcG9ydGVkLicpXG4gICAgfVxuICAgIGNvbnN0IHByZXZpb3VzID0gY29ubmVjdGlvbi5wYXJzZWRTdGF0ZW1lbnRzW3RoaXMubmFtZV1cbiAgICBpZiAodGhpcy50ZXh0ICYmIHByZXZpb3VzICYmIHRoaXMudGV4dCAhPT0gcHJldmlvdXMpIHtcbiAgICAgIHJldHVybiBuZXcgRXJyb3IoYFByZXBhcmVkIHN0YXRlbWVudHMgbXVzdCBiZSB1bmlxdWUgLSAnJHt0aGlzLm5hbWV9JyB3YXMgdXNlZCBmb3IgYSBkaWZmZXJlbnQgc3RhdGVtZW50YClcbiAgICB9XG4gICAgaWYgKHRoaXMudmFsdWVzICYmICFBcnJheS5pc0FycmF5KHRoaXMudmFsdWVzKSkge1xuICAgICAgcmV0dXJuIG5ldyBFcnJvcignUXVlcnkgdmFsdWVzIG11c3QgYmUgYW4gYXJyYXknKVxuICAgIH1cbiAgICBpZiAodGhpcy5yZXF1aXJlc1ByZXBhcmF0aW9uKCkpIHtcbiAgICAgIHRoaXMucHJlcGFyZShjb25uZWN0aW9uKVxuICAgIH0gZWxzZSB7XG4gICAgICBjb25uZWN0aW9uLnF1ZXJ5KHRoaXMudGV4dClcbiAgICB9XG4gICAgcmV0dXJuIG51bGxcbiAgfVxuXG4gIGhhc0JlZW5QYXJzZWQoY29ubmVjdGlvbikge1xuICAgIHJldHVybiB0aGlzLm5hbWUgJiYgY29ubmVjdGlvbi5wYXJzZWRTdGF0ZW1lbnRzW3RoaXMubmFtZV1cbiAgfVxuXG4gIGhhbmRsZVBvcnRhbFN1c3BlbmRlZChjb25uZWN0aW9uKSB7XG4gICAgdGhpcy5fZ2V0Um93cyhjb25uZWN0aW9uLCB0aGlzLnJvd3MpXG4gIH1cblxuICBfZ2V0Um93cyhjb25uZWN0aW9uLCByb3dzKSB7XG4gICAgY29ubmVjdGlvbi5leGVjdXRlKHtcbiAgICAgIHBvcnRhbDogdGhpcy5wb3J0YWwsXG4gICAgICByb3dzOiByb3dzLFxuICAgIH0pXG4gICAgLy8gaWYgd2UncmUgbm90IHJlYWRpbmcgcGFnZXMgb2Ygcm93cyBzZW5kIHRoZSBzeW5jIGNvbW1hbmRcbiAgICAvLyB0byBpbmRpY2F0ZSB0aGUgcGlwZWxpbmUgaXMgZmluaXNoZWRcbiAgICBpZiAoIXJvd3MpIHtcbiAgICAgIGNvbm5lY3Rpb24uc3luYygpXG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIG90aGVyd2lzZSBmbHVzaCB0aGUgY2FsbCBvdXQgdG8gcmVhZCBtb3JlIHJvd3NcbiAgICAgIGNvbm5lY3Rpb24uZmx1c2goKVxuICAgIH1cbiAgfVxuXG4gIC8vIGh0dHA6Ly9kZXZlbG9wZXIucG9zdGdyZXNxbC5vcmcvcGdkb2NzL3Bvc3RncmVzL3Byb3RvY29sLWZsb3cuaHRtbCNQUk9UT0NPTC1GTE9XLUVYVC1RVUVSWVxuICBwcmVwYXJlKGNvbm5lY3Rpb24pIHtcbiAgICAvLyBwcmVwYXJlZCBzdGF0ZW1lbnRzIG5lZWQgc3luYyB0byBiZSBjYWxsZWQgYWZ0ZXIgZWFjaCBjb21tYW5kXG4gICAgLy8gY29tcGxldGUgb3Igd2hlbiBhbiBlcnJvciBpcyBlbmNvdW50ZXJlZFxuICAgIHRoaXMuaXNQcmVwYXJlZFN0YXRlbWVudCA9IHRydWVcblxuICAgIC8vIFRPRE8gcmVmYWN0b3IgdGhpcyBwb29yIGVuY2Fwc3VsYXRpb25cbiAgICBpZiAoIXRoaXMuaGFzQmVlblBhcnNlZChjb25uZWN0aW9uKSkge1xuICAgICAgY29ubmVjdGlvbi5wYXJzZSh7XG4gICAgICAgIHRleHQ6IHRoaXMudGV4dCxcbiAgICAgICAgbmFtZTogdGhpcy5uYW1lLFxuICAgICAgICB0eXBlczogdGhpcy50eXBlcyxcbiAgICAgIH0pXG4gICAgfVxuXG4gICAgLy8gYmVjYXVzZSB3ZSdyZSBtYXBwaW5nIHVzZXIgc3VwcGxpZWQgdmFsdWVzIHRvXG4gICAgLy8gcG9zdGdyZXMgd2lyZSBwcm90b2NvbCBjb21wYXRpYmxlIHZhbHVlcyBpdCBjb3VsZFxuICAgIC8vIHRocm93IGFuIGV4Y2VwdGlvbiwgc28gdHJ5L2NhdGNoIHRoaXMgc2VjdGlvblxuICAgIHRyeSB7XG4gICAgICBjb25uZWN0aW9uLmJpbmQoe1xuICAgICAgICBwb3J0YWw6IHRoaXMucG9ydGFsLFxuICAgICAgICBzdGF0ZW1lbnQ6IHRoaXMubmFtZSxcbiAgICAgICAgdmFsdWVzOiB0aGlzLnZhbHVlcyxcbiAgICAgICAgYmluYXJ5OiB0aGlzLmJpbmFyeSxcbiAgICAgICAgdmFsdWVNYXBwZXI6IHV0aWxzLnByZXBhcmVWYWx1ZSxcbiAgICAgIH0pXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aGlzLmhhbmRsZUVycm9yKGVyciwgY29ubmVjdGlvbilcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIGNvbm5lY3Rpb24uZGVzY3JpYmUoe1xuICAgICAgdHlwZTogJ1AnLFxuICAgICAgbmFtZTogdGhpcy5wb3J0YWwgfHwgJycsXG4gICAgfSlcblxuICAgIHRoaXMuX2dldFJvd3MoY29ubmVjdGlvbiwgdGhpcy5yb3dzKVxuICB9XG5cbiAgaGFuZGxlQ29weUluUmVzcG9uc2UoY29ubmVjdGlvbikge1xuICAgIGNvbm5lY3Rpb24uc2VuZENvcHlGYWlsKCdObyBzb3VyY2Ugc3RyZWFtIGRlZmluZWQnKVxuICB9XG5cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVudXNlZC12YXJzXG4gIGhhbmRsZUNvcHlEYXRhKG1zZywgY29ubmVjdGlvbikge1xuICAgIC8vIG5vb3BcbiAgfVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IFF1ZXJ5XG4iLCIndXNlIHN0cmljdCdcblxudmFyIHR5cGVzID0gcmVxdWlyZSgncGctdHlwZXMnKVxuXG52YXIgbWF0Y2hSZWdleHAgPSAvXihbQS1aYS16XSspKD86IChcXGQrKSk/KD86IChcXGQrKSk/L1xuXG4vLyByZXN1bHQgb2JqZWN0IHJldHVybmVkIGZyb20gcXVlcnlcbi8vIGluIHRoZSAnZW5kJyBldmVudCBhbmQgYWxzb1xuLy8gcGFzc2VkIGFzIHNlY29uZCBhcmd1bWVudCB0byBwcm92aWRlZCBjYWxsYmFja1xuY2xhc3MgUmVzdWx0IHtcbiAgY29uc3RydWN0b3Iocm93TW9kZSwgdHlwZXMpIHtcbiAgICB0aGlzLmNvbW1hbmQgPSBudWxsXG4gICAgdGhpcy5yb3dDb3VudCA9IG51bGxcbiAgICB0aGlzLm9pZCA9IG51bGxcbiAgICB0aGlzLnJvd3MgPSBbXVxuICAgIHRoaXMuZmllbGRzID0gW11cbiAgICB0aGlzLl9wYXJzZXJzID0gdW5kZWZpbmVkXG4gICAgdGhpcy5fdHlwZXMgPSB0eXBlc1xuICAgIHRoaXMuUm93Q3RvciA9IG51bGxcbiAgICB0aGlzLnJvd0FzQXJyYXkgPSByb3dNb2RlID09PSAnYXJyYXknXG4gICAgaWYgKHRoaXMucm93QXNBcnJheSkge1xuICAgICAgdGhpcy5wYXJzZVJvdyA9IHRoaXMuX3BhcnNlUm93QXNBcnJheVxuICAgIH1cbiAgfVxuXG4gIC8vIGFkZHMgYSBjb21tYW5kIGNvbXBsZXRlIG1lc3NhZ2VcbiAgYWRkQ29tbWFuZENvbXBsZXRlKG1zZykge1xuICAgIHZhciBtYXRjaFxuICAgIGlmIChtc2cudGV4dCkge1xuICAgICAgLy8gcHVyZSBqYXZhc2NyaXB0XG4gICAgICBtYXRjaCA9IG1hdGNoUmVnZXhwLmV4ZWMobXNnLnRleHQpXG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIG5hdGl2ZSBiaW5kaW5nc1xuICAgICAgbWF0Y2ggPSBtYXRjaFJlZ2V4cC5leGVjKG1zZy5jb21tYW5kKVxuICAgIH1cbiAgICBpZiAobWF0Y2gpIHtcbiAgICAgIHRoaXMuY29tbWFuZCA9IG1hdGNoWzFdXG4gICAgICBpZiAobWF0Y2hbM10pIHtcbiAgICAgICAgLy8gQ09NTU1BTkQgT0lEIFJPV1NcbiAgICAgICAgdGhpcy5vaWQgPSBwYXJzZUludChtYXRjaFsyXSwgMTApXG4gICAgICAgIHRoaXMucm93Q291bnQgPSBwYXJzZUludChtYXRjaFszXSwgMTApXG4gICAgICB9IGVsc2UgaWYgKG1hdGNoWzJdKSB7XG4gICAgICAgIC8vIENPTU1BTkQgUk9XU1xuICAgICAgICB0aGlzLnJvd0NvdW50ID0gcGFyc2VJbnQobWF0Y2hbMl0sIDEwKVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIF9wYXJzZVJvd0FzQXJyYXkocm93RGF0YSkge1xuICAgIHZhciByb3cgPSBuZXcgQXJyYXkocm93RGF0YS5sZW5ndGgpXG4gICAgZm9yICh2YXIgaSA9IDAsIGxlbiA9IHJvd0RhdGEubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgIHZhciByYXdWYWx1ZSA9IHJvd0RhdGFbaV1cbiAgICAgIGlmIChyYXdWYWx1ZSAhPT0gbnVsbCkge1xuICAgICAgICByb3dbaV0gPSB0aGlzLl9wYXJzZXJzW2ldKHJhd1ZhbHVlKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcm93W2ldID0gbnVsbFxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcm93XG4gIH1cblxuICBwYXJzZVJvdyhyb3dEYXRhKSB7XG4gICAgdmFyIHJvdyA9IHt9XG4gICAgZm9yICh2YXIgaSA9IDAsIGxlbiA9IHJvd0RhdGEubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgIHZhciByYXdWYWx1ZSA9IHJvd0RhdGFbaV1cbiAgICAgIHZhciBmaWVsZCA9IHRoaXMuZmllbGRzW2ldLm5hbWVcbiAgICAgIGlmIChyYXdWYWx1ZSAhPT0gbnVsbCkge1xuICAgICAgICByb3dbZmllbGRdID0gdGhpcy5fcGFyc2Vyc1tpXShyYXdWYWx1ZSlcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJvd1tmaWVsZF0gPSBudWxsXG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiByb3dcbiAgfVxuXG4gIGFkZFJvdyhyb3cpIHtcbiAgICB0aGlzLnJvd3MucHVzaChyb3cpXG4gIH1cblxuICBhZGRGaWVsZHMoZmllbGREZXNjcmlwdGlvbnMpIHtcbiAgICAvLyBjbGVhcnMgZmllbGQgZGVmaW5pdGlvbnNcbiAgICAvLyBtdWx0aXBsZSBxdWVyeSBzdGF0ZW1lbnRzIGluIDEgYWN0aW9uIGNhbiByZXN1bHQgaW4gbXVsdGlwbGUgc2V0c1xuICAgIC8vIG9mIHJvd0Rlc2NyaXB0aW9ucy4uLmVnOiAnc2VsZWN0IE5PVygpOyBzZWxlY3QgMTo6aW50OydcbiAgICAvLyB5b3UgbmVlZCB0byByZXNldCB0aGUgZmllbGRzXG4gICAgdGhpcy5maWVsZHMgPSBmaWVsZERlc2NyaXB0aW9uc1xuICAgIGlmICh0aGlzLmZpZWxkcy5sZW5ndGgpIHtcbiAgICAgIHRoaXMuX3BhcnNlcnMgPSBuZXcgQXJyYXkoZmllbGREZXNjcmlwdGlvbnMubGVuZ3RoKVxuICAgIH1cbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGZpZWxkRGVzY3JpcHRpb25zLmxlbmd0aDsgaSsrKSB7XG4gICAgICB2YXIgZGVzYyA9IGZpZWxkRGVzY3JpcHRpb25zW2ldXG4gICAgICBpZiAodGhpcy5fdHlwZXMpIHtcbiAgICAgICAgdGhpcy5fcGFyc2Vyc1tpXSA9IHRoaXMuX3R5cGVzLmdldFR5cGVQYXJzZXIoZGVzYy5kYXRhVHlwZUlELCBkZXNjLmZvcm1hdCB8fCAndGV4dCcpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLl9wYXJzZXJzW2ldID0gdHlwZXMuZ2V0VHlwZVBhcnNlcihkZXNjLmRhdGFUeXBlSUQsIGRlc2MuZm9ybWF0IHx8ICd0ZXh0JylcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSBSZXN1bHRcbiIsIid1c2Ugc3RyaWN0J1xuY29uc3QgY3J5cHRvID0gcmVxdWlyZSgnY3J5cHRvJylcblxuZnVuY3Rpb24gc3RhcnRTZXNzaW9uKG1lY2hhbmlzbXMpIHtcbiAgaWYgKG1lY2hhbmlzbXMuaW5kZXhPZignU0NSQU0tU0hBLTI1NicpID09PSAtMSkge1xuICAgIHRocm93IG5ldyBFcnJvcignU0FTTDogT25seSBtZWNoYW5pc20gU0NSQU0tU0hBLTI1NiBpcyBjdXJyZW50bHkgc3VwcG9ydGVkJylcbiAgfVxuXG4gIGNvbnN0IGNsaWVudE5vbmNlID0gY3J5cHRvLnJhbmRvbUJ5dGVzKDE4KS50b1N0cmluZygnYmFzZTY0JylcblxuICByZXR1cm4ge1xuICAgIG1lY2hhbmlzbTogJ1NDUkFNLVNIQS0yNTYnLFxuICAgIGNsaWVudE5vbmNlLFxuICAgIHJlc3BvbnNlOiAnbiwsbj0qLHI9JyArIGNsaWVudE5vbmNlLFxuICAgIG1lc3NhZ2U6ICdTQVNMSW5pdGlhbFJlc3BvbnNlJyxcbiAgfVxufVxuXG5mdW5jdGlvbiBjb250aW51ZVNlc3Npb24oc2Vzc2lvbiwgcGFzc3dvcmQsIHNlcnZlckRhdGEpIHtcbiAgaWYgKHNlc3Npb24ubWVzc2FnZSAhPT0gJ1NBU0xJbml0aWFsUmVzcG9uc2UnKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdTQVNMOiBMYXN0IG1lc3NhZ2Ugd2FzIG5vdCBTQVNMSW5pdGlhbFJlc3BvbnNlJylcbiAgfVxuICBpZiAodHlwZW9mIHBhc3N3b3JkICE9PSAnc3RyaW5nJykge1xuICAgIHRocm93IG5ldyBFcnJvcignU0FTTDogU0NSQU0tU0VSVkVSLUZJUlNULU1FU1NBR0U6IGNsaWVudCBwYXNzd29yZCBtdXN0IGJlIGEgc3RyaW5nJylcbiAgfVxuICBpZiAodHlwZW9mIHNlcnZlckRhdGEgIT09ICdzdHJpbmcnKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdTQVNMOiBTQ1JBTS1TRVJWRVItRklSU1QtTUVTU0FHRTogc2VydmVyRGF0YSBtdXN0IGJlIGEgc3RyaW5nJylcbiAgfVxuXG4gIGNvbnN0IHN2ID0gcGFyc2VTZXJ2ZXJGaXJzdE1lc3NhZ2Uoc2VydmVyRGF0YSlcblxuICBpZiAoIXN2Lm5vbmNlLnN0YXJ0c1dpdGgoc2Vzc2lvbi5jbGllbnROb25jZSkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1NBU0w6IFNDUkFNLVNFUlZFUi1GSVJTVC1NRVNTQUdFOiBzZXJ2ZXIgbm9uY2UgZG9lcyBub3Qgc3RhcnQgd2l0aCBjbGllbnQgbm9uY2UnKVxuICB9IGVsc2UgaWYgKHN2Lm5vbmNlLmxlbmd0aCA9PT0gc2Vzc2lvbi5jbGllbnROb25jZS5sZW5ndGgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1NBU0w6IFNDUkFNLVNFUlZFUi1GSVJTVC1NRVNTQUdFOiBzZXJ2ZXIgbm9uY2UgaXMgdG9vIHNob3J0JylcbiAgfVxuXG4gIHZhciBzYWx0Qnl0ZXMgPSBCdWZmZXIuZnJvbShzdi5zYWx0LCAnYmFzZTY0JylcblxuICB2YXIgc2FsdGVkUGFzc3dvcmQgPSBIaShwYXNzd29yZCwgc2FsdEJ5dGVzLCBzdi5pdGVyYXRpb24pXG5cbiAgdmFyIGNsaWVudEtleSA9IGhtYWNTaGEyNTYoc2FsdGVkUGFzc3dvcmQsICdDbGllbnQgS2V5JylcbiAgdmFyIHN0b3JlZEtleSA9IHNoYTI1NihjbGllbnRLZXkpXG5cbiAgdmFyIGNsaWVudEZpcnN0TWVzc2FnZUJhcmUgPSAnbj0qLHI9JyArIHNlc3Npb24uY2xpZW50Tm9uY2VcbiAgdmFyIHNlcnZlckZpcnN0TWVzc2FnZSA9ICdyPScgKyBzdi5ub25jZSArICcscz0nICsgc3Yuc2FsdCArICcsaT0nICsgc3YuaXRlcmF0aW9uXG5cbiAgdmFyIGNsaWVudEZpbmFsTWVzc2FnZVdpdGhvdXRQcm9vZiA9ICdjPWJpd3Mscj0nICsgc3Yubm9uY2VcblxuICB2YXIgYXV0aE1lc3NhZ2UgPSBjbGllbnRGaXJzdE1lc3NhZ2VCYXJlICsgJywnICsgc2VydmVyRmlyc3RNZXNzYWdlICsgJywnICsgY2xpZW50RmluYWxNZXNzYWdlV2l0aG91dFByb29mXG5cbiAgdmFyIGNsaWVudFNpZ25hdHVyZSA9IGhtYWNTaGEyNTYoc3RvcmVkS2V5LCBhdXRoTWVzc2FnZSlcbiAgdmFyIGNsaWVudFByb29mQnl0ZXMgPSB4b3JCdWZmZXJzKGNsaWVudEtleSwgY2xpZW50U2lnbmF0dXJlKVxuICB2YXIgY2xpZW50UHJvb2YgPSBjbGllbnRQcm9vZkJ5dGVzLnRvU3RyaW5nKCdiYXNlNjQnKVxuXG4gIHZhciBzZXJ2ZXJLZXkgPSBobWFjU2hhMjU2KHNhbHRlZFBhc3N3b3JkLCAnU2VydmVyIEtleScpXG4gIHZhciBzZXJ2ZXJTaWduYXR1cmVCeXRlcyA9IGhtYWNTaGEyNTYoc2VydmVyS2V5LCBhdXRoTWVzc2FnZSlcblxuICBzZXNzaW9uLm1lc3NhZ2UgPSAnU0FTTFJlc3BvbnNlJ1xuICBzZXNzaW9uLnNlcnZlclNpZ25hdHVyZSA9IHNlcnZlclNpZ25hdHVyZUJ5dGVzLnRvU3RyaW5nKCdiYXNlNjQnKVxuICBzZXNzaW9uLnJlc3BvbnNlID0gY2xpZW50RmluYWxNZXNzYWdlV2l0aG91dFByb29mICsgJyxwPScgKyBjbGllbnRQcm9vZlxufVxuXG5mdW5jdGlvbiBmaW5hbGl6ZVNlc3Npb24oc2Vzc2lvbiwgc2VydmVyRGF0YSkge1xuICBpZiAoc2Vzc2lvbi5tZXNzYWdlICE9PSAnU0FTTFJlc3BvbnNlJykge1xuICAgIHRocm93IG5ldyBFcnJvcignU0FTTDogTGFzdCBtZXNzYWdlIHdhcyBub3QgU0FTTFJlc3BvbnNlJylcbiAgfVxuICBpZiAodHlwZW9mIHNlcnZlckRhdGEgIT09ICdzdHJpbmcnKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdTQVNMOiBTQ1JBTS1TRVJWRVItRklOQUwtTUVTU0FHRTogc2VydmVyRGF0YSBtdXN0IGJlIGEgc3RyaW5nJylcbiAgfVxuXG4gIGNvbnN0IHsgc2VydmVyU2lnbmF0dXJlIH0gPSBwYXJzZVNlcnZlckZpbmFsTWVzc2FnZShzZXJ2ZXJEYXRhKVxuXG4gIGlmIChzZXJ2ZXJTaWduYXR1cmUgIT09IHNlc3Npb24uc2VydmVyU2lnbmF0dXJlKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdTQVNMOiBTQ1JBTS1TRVJWRVItRklOQUwtTUVTU0FHRTogc2VydmVyIHNpZ25hdHVyZSBkb2VzIG5vdCBtYXRjaCcpXG4gIH1cbn1cblxuLyoqXG4gKiBwcmludGFibGUgICAgICAgPSAleDIxLTJCIC8gJXgyRC03RVxuICogICAgICAgICAgICAgICAgICAgOzsgUHJpbnRhYmxlIEFTQ0lJIGV4Y2VwdCBcIixcIi5cbiAqICAgICAgICAgICAgICAgICAgIDs7IE5vdGUgdGhhdCBhbnkgXCJwcmludGFibGVcIiBpcyBhbHNvXG4gKiAgICAgICAgICAgICAgICAgICA7OyBhIHZhbGlkIFwidmFsdWVcIi5cbiAqL1xuZnVuY3Rpb24gaXNQcmludGFibGVDaGFycyh0ZXh0KSB7XG4gIGlmICh0eXBlb2YgdGV4dCAhPT0gJ3N0cmluZycpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdTQVNMOiB0ZXh0IG11c3QgYmUgYSBzdHJpbmcnKVxuICB9XG4gIHJldHVybiB0ZXh0XG4gICAgLnNwbGl0KCcnKVxuICAgIC5tYXAoKF8sIGkpID0+IHRleHQuY2hhckNvZGVBdChpKSlcbiAgICAuZXZlcnkoKGMpID0+IChjID49IDB4MjEgJiYgYyA8PSAweDJiKSB8fCAoYyA+PSAweDJkICYmIGMgPD0gMHg3ZSkpXG59XG5cbi8qKlxuICogYmFzZTY0LWNoYXIgICAgID0gQUxQSEEgLyBESUdJVCAvIFwiL1wiIC8gXCIrXCJcbiAqXG4gKiBiYXNlNjQtNCAgICAgICAgPSA0YmFzZTY0LWNoYXJcbiAqXG4gKiBiYXNlNjQtMyAgICAgICAgPSAzYmFzZTY0LWNoYXIgXCI9XCJcbiAqXG4gKiBiYXNlNjQtMiAgICAgICAgPSAyYmFzZTY0LWNoYXIgXCI9PVwiXG4gKlxuICogYmFzZTY0ICAgICAgICAgID0gKmJhc2U2NC00IFtiYXNlNjQtMyAvIGJhc2U2NC0yXVxuICovXG5mdW5jdGlvbiBpc0Jhc2U2NCh0ZXh0KSB7XG4gIHJldHVybiAvXig/OlthLXpBLVowLTkrL117NH0pKig/OlthLXpBLVowLTkrL117Mn09PXxbYS16QS1aMC05Ky9dezN9PSk/JC8udGVzdCh0ZXh0KVxufVxuXG5mdW5jdGlvbiBwYXJzZUF0dHJpYnV0ZVBhaXJzKHRleHQpIHtcbiAgaWYgKHR5cGVvZiB0ZXh0ICE9PSAnc3RyaW5nJykge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1NBU0w6IGF0dHJpYnV0ZSBwYWlycyB0ZXh0IG11c3QgYmUgYSBzdHJpbmcnKVxuICB9XG5cbiAgcmV0dXJuIG5ldyBNYXAoXG4gICAgdGV4dC5zcGxpdCgnLCcpLm1hcCgoYXR0clZhbHVlKSA9PiB7XG4gICAgICBpZiAoIS9eLj0vLnRlc3QoYXR0clZhbHVlKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1NBU0w6IEludmFsaWQgYXR0cmlidXRlIHBhaXIgZW50cnknKVxuICAgICAgfVxuICAgICAgY29uc3QgbmFtZSA9IGF0dHJWYWx1ZVswXVxuICAgICAgY29uc3QgdmFsdWUgPSBhdHRyVmFsdWUuc3Vic3RyaW5nKDIpXG4gICAgICByZXR1cm4gW25hbWUsIHZhbHVlXVxuICAgIH0pXG4gIClcbn1cblxuZnVuY3Rpb24gcGFyc2VTZXJ2ZXJGaXJzdE1lc3NhZ2UoZGF0YSkge1xuICBjb25zdCBhdHRyUGFpcnMgPSBwYXJzZUF0dHJpYnV0ZVBhaXJzKGRhdGEpXG5cbiAgY29uc3Qgbm9uY2UgPSBhdHRyUGFpcnMuZ2V0KCdyJylcbiAgaWYgKCFub25jZSkge1xuICAgIHRocm93IG5ldyBFcnJvcignU0FTTDogU0NSQU0tU0VSVkVSLUZJUlNULU1FU1NBR0U6IG5vbmNlIG1pc3NpbmcnKVxuICB9IGVsc2UgaWYgKCFpc1ByaW50YWJsZUNoYXJzKG5vbmNlKSkge1xuICAgIHRocm93IG5ldyBFcnJvcignU0FTTDogU0NSQU0tU0VSVkVSLUZJUlNULU1FU1NBR0U6IG5vbmNlIG11c3Qgb25seSBjb250YWluIHByaW50YWJsZSBjaGFyYWN0ZXJzJylcbiAgfVxuICBjb25zdCBzYWx0ID0gYXR0clBhaXJzLmdldCgncycpXG4gIGlmICghc2FsdCkge1xuICAgIHRocm93IG5ldyBFcnJvcignU0FTTDogU0NSQU0tU0VSVkVSLUZJUlNULU1FU1NBR0U6IHNhbHQgbWlzc2luZycpXG4gIH0gZWxzZSBpZiAoIWlzQmFzZTY0KHNhbHQpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdTQVNMOiBTQ1JBTS1TRVJWRVItRklSU1QtTUVTU0FHRTogc2FsdCBtdXN0IGJlIGJhc2U2NCcpXG4gIH1cbiAgY29uc3QgaXRlcmF0aW9uVGV4dCA9IGF0dHJQYWlycy5nZXQoJ2knKVxuICBpZiAoIWl0ZXJhdGlvblRleHQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1NBU0w6IFNDUkFNLVNFUlZFUi1GSVJTVC1NRVNTQUdFOiBpdGVyYXRpb24gbWlzc2luZycpXG4gIH0gZWxzZSBpZiAoIS9eWzEtOV1bMC05XSokLy50ZXN0KGl0ZXJhdGlvblRleHQpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdTQVNMOiBTQ1JBTS1TRVJWRVItRklSU1QtTUVTU0FHRTogaW52YWxpZCBpdGVyYXRpb24gY291bnQnKVxuICB9XG4gIGNvbnN0IGl0ZXJhdGlvbiA9IHBhcnNlSW50KGl0ZXJhdGlvblRleHQsIDEwKVxuXG4gIHJldHVybiB7XG4gICAgbm9uY2UsXG4gICAgc2FsdCxcbiAgICBpdGVyYXRpb24sXG4gIH1cbn1cblxuZnVuY3Rpb24gcGFyc2VTZXJ2ZXJGaW5hbE1lc3NhZ2Uoc2VydmVyRGF0YSkge1xuICBjb25zdCBhdHRyUGFpcnMgPSBwYXJzZUF0dHJpYnV0ZVBhaXJzKHNlcnZlckRhdGEpXG4gIGNvbnN0IHNlcnZlclNpZ25hdHVyZSA9IGF0dHJQYWlycy5nZXQoJ3YnKVxuICBpZiAoIXNlcnZlclNpZ25hdHVyZSkge1xuICAgIHRocm93IG5ldyBFcnJvcignU0FTTDogU0NSQU0tU0VSVkVSLUZJTkFMLU1FU1NBR0U6IHNlcnZlciBzaWduYXR1cmUgaXMgbWlzc2luZycpXG4gIH0gZWxzZSBpZiAoIWlzQmFzZTY0KHNlcnZlclNpZ25hdHVyZSkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1NBU0w6IFNDUkFNLVNFUlZFUi1GSU5BTC1NRVNTQUdFOiBzZXJ2ZXIgc2lnbmF0dXJlIG11c3QgYmUgYmFzZTY0JylcbiAgfVxuICByZXR1cm4ge1xuICAgIHNlcnZlclNpZ25hdHVyZSxcbiAgfVxufVxuXG5mdW5jdGlvbiB4b3JCdWZmZXJzKGEsIGIpIHtcbiAgaWYgKCFCdWZmZXIuaXNCdWZmZXIoYSkpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdmaXJzdCBhcmd1bWVudCBtdXN0IGJlIGEgQnVmZmVyJylcbiAgfVxuICBpZiAoIUJ1ZmZlci5pc0J1ZmZlcihiKSkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ3NlY29uZCBhcmd1bWVudCBtdXN0IGJlIGEgQnVmZmVyJylcbiAgfVxuICBpZiAoYS5sZW5ndGggIT09IGIubGVuZ3RoKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdCdWZmZXIgbGVuZ3RocyBtdXN0IG1hdGNoJylcbiAgfVxuICBpZiAoYS5sZW5ndGggPT09IDApIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ0J1ZmZlcnMgY2Fubm90IGJlIGVtcHR5JylcbiAgfVxuICByZXR1cm4gQnVmZmVyLmZyb20oYS5tYXAoKF8sIGkpID0+IGFbaV0gXiBiW2ldKSlcbn1cblxuZnVuY3Rpb24gc2hhMjU2KHRleHQpIHtcbiAgcmV0dXJuIGNyeXB0by5jcmVhdGVIYXNoKCdzaGEyNTYnKS51cGRhdGUodGV4dCkuZGlnZXN0KClcbn1cblxuZnVuY3Rpb24gaG1hY1NoYTI1NihrZXksIG1zZykge1xuICByZXR1cm4gY3J5cHRvLmNyZWF0ZUhtYWMoJ3NoYTI1NicsIGtleSkudXBkYXRlKG1zZykuZGlnZXN0KClcbn1cblxuZnVuY3Rpb24gSGkocGFzc3dvcmQsIHNhbHRCeXRlcywgaXRlcmF0aW9ucykge1xuICB2YXIgdWkxID0gaG1hY1NoYTI1NihwYXNzd29yZCwgQnVmZmVyLmNvbmNhdChbc2FsdEJ5dGVzLCBCdWZmZXIuZnJvbShbMCwgMCwgMCwgMV0pXSkpXG4gIHZhciB1aSA9IHVpMVxuICBmb3IgKHZhciBpID0gMDsgaSA8IGl0ZXJhdGlvbnMgLSAxOyBpKyspIHtcbiAgICB1aTEgPSBobWFjU2hhMjU2KHBhc3N3b3JkLCB1aTEpXG4gICAgdWkgPSB4b3JCdWZmZXJzKHVpLCB1aTEpXG4gIH1cblxuICByZXR1cm4gdWlcbn1cblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gIHN0YXJ0U2Vzc2lvbixcbiAgY29udGludWVTZXNzaW9uLFxuICBmaW5hbGl6ZVNlc3Npb24sXG59XG4iLCIndXNlIHN0cmljdCdcblxudmFyIHR5cGVzID0gcmVxdWlyZSgncGctdHlwZXMnKVxuXG5mdW5jdGlvbiBUeXBlT3ZlcnJpZGVzKHVzZXJUeXBlcykge1xuICB0aGlzLl90eXBlcyA9IHVzZXJUeXBlcyB8fCB0eXBlc1xuICB0aGlzLnRleHQgPSB7fVxuICB0aGlzLmJpbmFyeSA9IHt9XG59XG5cblR5cGVPdmVycmlkZXMucHJvdG90eXBlLmdldE92ZXJyaWRlcyA9IGZ1bmN0aW9uIChmb3JtYXQpIHtcbiAgc3dpdGNoIChmb3JtYXQpIHtcbiAgICBjYXNlICd0ZXh0JzpcbiAgICAgIHJldHVybiB0aGlzLnRleHRcbiAgICBjYXNlICdiaW5hcnknOlxuICAgICAgcmV0dXJuIHRoaXMuYmluYXJ5XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiB7fVxuICB9XG59XG5cblR5cGVPdmVycmlkZXMucHJvdG90eXBlLnNldFR5cGVQYXJzZXIgPSBmdW5jdGlvbiAob2lkLCBmb3JtYXQsIHBhcnNlRm4pIHtcbiAgaWYgKHR5cGVvZiBmb3JtYXQgPT09ICdmdW5jdGlvbicpIHtcbiAgICBwYXJzZUZuID0gZm9ybWF0XG4gICAgZm9ybWF0ID0gJ3RleHQnXG4gIH1cbiAgdGhpcy5nZXRPdmVycmlkZXMoZm9ybWF0KVtvaWRdID0gcGFyc2VGblxufVxuXG5UeXBlT3ZlcnJpZGVzLnByb3RvdHlwZS5nZXRUeXBlUGFyc2VyID0gZnVuY3Rpb24gKG9pZCwgZm9ybWF0KSB7XG4gIGZvcm1hdCA9IGZvcm1hdCB8fCAndGV4dCdcbiAgcmV0dXJuIHRoaXMuZ2V0T3ZlcnJpZGVzKGZvcm1hdClbb2lkXSB8fCB0aGlzLl90eXBlcy5nZXRUeXBlUGFyc2VyKG9pZCwgZm9ybWF0KVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IFR5cGVPdmVycmlkZXNcbiIsIid1c2Ugc3RyaWN0J1xuXG5jb25zdCBjcnlwdG8gPSByZXF1aXJlKCdjcnlwdG8nKVxuXG5jb25zdCBkZWZhdWx0cyA9IHJlcXVpcmUoJy4vZGVmYXVsdHMnKVxuXG5mdW5jdGlvbiBlc2NhcGVFbGVtZW50KGVsZW1lbnRSZXByZXNlbnRhdGlvbikge1xuICB2YXIgZXNjYXBlZCA9IGVsZW1lbnRSZXByZXNlbnRhdGlvbi5yZXBsYWNlKC9cXFxcL2csICdcXFxcXFxcXCcpLnJlcGxhY2UoL1wiL2csICdcXFxcXCInKVxuXG4gIHJldHVybiAnXCInICsgZXNjYXBlZCArICdcIidcbn1cblxuLy8gY29udmVydCBhIEpTIGFycmF5IHRvIGEgcG9zdGdyZXMgYXJyYXkgbGl0ZXJhbFxuLy8gdXNlcyBjb21tYSBzZXBhcmF0b3Igc28gd29uJ3Qgd29yayBmb3IgdHlwZXMgbGlrZSBib3ggdGhhdCB1c2Vcbi8vIGEgZGlmZmVyZW50IGFycmF5IHNlcGFyYXRvci5cbmZ1bmN0aW9uIGFycmF5U3RyaW5nKHZhbCkge1xuICB2YXIgcmVzdWx0ID0gJ3snXG4gIGZvciAodmFyIGkgPSAwOyBpIDwgdmFsLmxlbmd0aDsgaSsrKSB7XG4gICAgaWYgKGkgPiAwKSB7XG4gICAgICByZXN1bHQgPSByZXN1bHQgKyAnLCdcbiAgICB9XG4gICAgaWYgKHZhbFtpXSA9PT0gbnVsbCB8fCB0eXBlb2YgdmFsW2ldID09PSAndW5kZWZpbmVkJykge1xuICAgICAgcmVzdWx0ID0gcmVzdWx0ICsgJ05VTEwnXG4gICAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KHZhbFtpXSkpIHtcbiAgICAgIHJlc3VsdCA9IHJlc3VsdCArIGFycmF5U3RyaW5nKHZhbFtpXSlcbiAgICB9IGVsc2UgaWYgKHZhbFtpXSBpbnN0YW5jZW9mIEJ1ZmZlcikge1xuICAgICAgcmVzdWx0ICs9ICdcXFxcXFxcXHgnICsgdmFsW2ldLnRvU3RyaW5nKCdoZXgnKVxuICAgIH0gZWxzZSB7XG4gICAgICByZXN1bHQgKz0gZXNjYXBlRWxlbWVudChwcmVwYXJlVmFsdWUodmFsW2ldKSlcbiAgICB9XG4gIH1cbiAgcmVzdWx0ID0gcmVzdWx0ICsgJ30nXG4gIHJldHVybiByZXN1bHRcbn1cblxuLy8gY29udmVydHMgdmFsdWVzIGZyb20gamF2YXNjcmlwdCB0eXBlc1xuLy8gdG8gdGhlaXIgJ3JhdycgY291bnRlcnBhcnRzIGZvciB1c2UgYXMgYSBwb3N0Z3JlcyBwYXJhbWV0ZXJcbi8vIG5vdGU6IHlvdSBjYW4gb3ZlcnJpZGUgdGhpcyBmdW5jdGlvbiB0byBwcm92aWRlIHlvdXIgb3duIGNvbnZlcnNpb24gbWVjaGFuaXNtXG4vLyBmb3IgY29tcGxleCB0eXBlcywgZXRjLi4uXG52YXIgcHJlcGFyZVZhbHVlID0gZnVuY3Rpb24gKHZhbCwgc2Vlbikge1xuICAvLyBudWxsIGFuZCB1bmRlZmluZWQgYXJlIGJvdGggbnVsbCBmb3IgcG9zdGdyZXNcbiAgaWYgKHZhbCA9PSBudWxsKSB7XG4gICAgcmV0dXJuIG51bGxcbiAgfVxuICBpZiAodmFsIGluc3RhbmNlb2YgQnVmZmVyKSB7XG4gICAgcmV0dXJuIHZhbFxuICB9XG4gIGlmIChBcnJheUJ1ZmZlci5pc1ZpZXcodmFsKSkge1xuICAgIHZhciBidWYgPSBCdWZmZXIuZnJvbSh2YWwuYnVmZmVyLCB2YWwuYnl0ZU9mZnNldCwgdmFsLmJ5dGVMZW5ndGgpXG4gICAgaWYgKGJ1Zi5sZW5ndGggPT09IHZhbC5ieXRlTGVuZ3RoKSB7XG4gICAgICByZXR1cm4gYnVmXG4gICAgfVxuICAgIHJldHVybiBidWYuc2xpY2UodmFsLmJ5dGVPZmZzZXQsIHZhbC5ieXRlT2Zmc2V0ICsgdmFsLmJ5dGVMZW5ndGgpIC8vIE5vZGUuanMgdjQgZG9lcyBub3Qgc3VwcG9ydCB0aG9zZSBCdWZmZXIuZnJvbSBwYXJhbXNcbiAgfVxuICBpZiAodmFsIGluc3RhbmNlb2YgRGF0ZSkge1xuICAgIGlmIChkZWZhdWx0cy5wYXJzZUlucHV0RGF0ZXNBc1VUQykge1xuICAgICAgcmV0dXJuIGRhdGVUb1N0cmluZ1VUQyh2YWwpXG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBkYXRlVG9TdHJpbmcodmFsKVxuICAgIH1cbiAgfVxuICBpZiAoQXJyYXkuaXNBcnJheSh2YWwpKSB7XG4gICAgcmV0dXJuIGFycmF5U3RyaW5nKHZhbClcbiAgfVxuICBpZiAodHlwZW9mIHZhbCA9PT0gJ29iamVjdCcpIHtcbiAgICByZXR1cm4gcHJlcGFyZU9iamVjdCh2YWwsIHNlZW4pXG4gIH1cbiAgcmV0dXJuIHZhbC50b1N0cmluZygpXG59XG5cbmZ1bmN0aW9uIHByZXBhcmVPYmplY3QodmFsLCBzZWVuKSB7XG4gIGlmICh2YWwgJiYgdHlwZW9mIHZhbC50b1Bvc3RncmVzID09PSAnZnVuY3Rpb24nKSB7XG4gICAgc2VlbiA9IHNlZW4gfHwgW11cbiAgICBpZiAoc2Vlbi5pbmRleE9mKHZhbCkgIT09IC0xKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ2NpcmN1bGFyIHJlZmVyZW5jZSBkZXRlY3RlZCB3aGlsZSBwcmVwYXJpbmcgXCInICsgdmFsICsgJ1wiIGZvciBxdWVyeScpXG4gICAgfVxuICAgIHNlZW4ucHVzaCh2YWwpXG5cbiAgICByZXR1cm4gcHJlcGFyZVZhbHVlKHZhbC50b1Bvc3RncmVzKHByZXBhcmVWYWx1ZSksIHNlZW4pXG4gIH1cbiAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KHZhbClcbn1cblxuZnVuY3Rpb24gcGFkKG51bWJlciwgZGlnaXRzKSB7XG4gIG51bWJlciA9ICcnICsgbnVtYmVyXG4gIHdoaWxlIChudW1iZXIubGVuZ3RoIDwgZGlnaXRzKSB7XG4gICAgbnVtYmVyID0gJzAnICsgbnVtYmVyXG4gIH1cbiAgcmV0dXJuIG51bWJlclxufVxuXG5mdW5jdGlvbiBkYXRlVG9TdHJpbmcoZGF0ZSkge1xuICB2YXIgb2Zmc2V0ID0gLWRhdGUuZ2V0VGltZXpvbmVPZmZzZXQoKVxuXG4gIHZhciB5ZWFyID0gZGF0ZS5nZXRGdWxsWWVhcigpXG4gIHZhciBpc0JDWWVhciA9IHllYXIgPCAxXG4gIGlmIChpc0JDWWVhcikgeWVhciA9IE1hdGguYWJzKHllYXIpICsgMSAvLyBuZWdhdGl2ZSB5ZWFycyBhcmUgMSBvZmYgdGhlaXIgQkMgcmVwcmVzZW50YXRpb25cblxuICB2YXIgcmV0ID1cbiAgICBwYWQoeWVhciwgNCkgK1xuICAgICctJyArXG4gICAgcGFkKGRhdGUuZ2V0TW9udGgoKSArIDEsIDIpICtcbiAgICAnLScgK1xuICAgIHBhZChkYXRlLmdldERhdGUoKSwgMikgK1xuICAgICdUJyArXG4gICAgcGFkKGRhdGUuZ2V0SG91cnMoKSwgMikgK1xuICAgICc6JyArXG4gICAgcGFkKGRhdGUuZ2V0TWludXRlcygpLCAyKSArXG4gICAgJzonICtcbiAgICBwYWQoZGF0ZS5nZXRTZWNvbmRzKCksIDIpICtcbiAgICAnLicgK1xuICAgIHBhZChkYXRlLmdldE1pbGxpc2Vjb25kcygpLCAzKVxuXG4gIGlmIChvZmZzZXQgPCAwKSB7XG4gICAgcmV0ICs9ICctJ1xuICAgIG9mZnNldCAqPSAtMVxuICB9IGVsc2Uge1xuICAgIHJldCArPSAnKydcbiAgfVxuXG4gIHJldCArPSBwYWQoTWF0aC5mbG9vcihvZmZzZXQgLyA2MCksIDIpICsgJzonICsgcGFkKG9mZnNldCAlIDYwLCAyKVxuICBpZiAoaXNCQ1llYXIpIHJldCArPSAnIEJDJ1xuICByZXR1cm4gcmV0XG59XG5cbmZ1bmN0aW9uIGRhdGVUb1N0cmluZ1VUQyhkYXRlKSB7XG4gIHZhciB5ZWFyID0gZGF0ZS5nZXRVVENGdWxsWWVhcigpXG4gIHZhciBpc0JDWWVhciA9IHllYXIgPCAxXG4gIGlmIChpc0JDWWVhcikgeWVhciA9IE1hdGguYWJzKHllYXIpICsgMSAvLyBuZWdhdGl2ZSB5ZWFycyBhcmUgMSBvZmYgdGhlaXIgQkMgcmVwcmVzZW50YXRpb25cblxuICB2YXIgcmV0ID1cbiAgICBwYWQoeWVhciwgNCkgK1xuICAgICctJyArXG4gICAgcGFkKGRhdGUuZ2V0VVRDTW9udGgoKSArIDEsIDIpICtcbiAgICAnLScgK1xuICAgIHBhZChkYXRlLmdldFVUQ0RhdGUoKSwgMikgK1xuICAgICdUJyArXG4gICAgcGFkKGRhdGUuZ2V0VVRDSG91cnMoKSwgMikgK1xuICAgICc6JyArXG4gICAgcGFkKGRhdGUuZ2V0VVRDTWludXRlcygpLCAyKSArXG4gICAgJzonICtcbiAgICBwYWQoZGF0ZS5nZXRVVENTZWNvbmRzKCksIDIpICtcbiAgICAnLicgK1xuICAgIHBhZChkYXRlLmdldFVUQ01pbGxpc2Vjb25kcygpLCAzKVxuXG4gIHJldCArPSAnKzAwOjAwJ1xuICBpZiAoaXNCQ1llYXIpIHJldCArPSAnIEJDJ1xuICByZXR1cm4gcmV0XG59XG5cbmZ1bmN0aW9uIG5vcm1hbGl6ZVF1ZXJ5Q29uZmlnKGNvbmZpZywgdmFsdWVzLCBjYWxsYmFjaykge1xuICAvLyBjYW4gdGFrZSBpbiBzdHJpbmdzIG9yIGNvbmZpZyBvYmplY3RzXG4gIGNvbmZpZyA9IHR5cGVvZiBjb25maWcgPT09ICdzdHJpbmcnID8geyB0ZXh0OiBjb25maWcgfSA6IGNvbmZpZ1xuICBpZiAodmFsdWVzKSB7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZXMgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIGNvbmZpZy5jYWxsYmFjayA9IHZhbHVlc1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25maWcudmFsdWVzID0gdmFsdWVzXG4gICAgfVxuICB9XG4gIGlmIChjYWxsYmFjaykge1xuICAgIGNvbmZpZy5jYWxsYmFjayA9IGNhbGxiYWNrXG4gIH1cbiAgcmV0dXJuIGNvbmZpZ1xufVxuXG5jb25zdCBtZDUgPSBmdW5jdGlvbiAoc3RyaW5nKSB7XG4gIHJldHVybiBjcnlwdG8uY3JlYXRlSGFzaCgnbWQ1JykudXBkYXRlKHN0cmluZywgJ3V0Zi04JykuZGlnZXN0KCdoZXgnKVxufVxuXG4vLyBTZWUgQXV0aGVudGljYXRpb25NRDVQYXNzd29yZCBhdCBodHRwczovL3d3dy5wb3N0Z3Jlc3FsLm9yZy9kb2NzL2N1cnJlbnQvc3RhdGljL3Byb3RvY29sLWZsb3cuaHRtbFxuY29uc3QgcG9zdGdyZXNNZDVQYXNzd29yZEhhc2ggPSBmdW5jdGlvbiAodXNlciwgcGFzc3dvcmQsIHNhbHQpIHtcbiAgdmFyIGlubmVyID0gbWQ1KHBhc3N3b3JkICsgdXNlcilcbiAgdmFyIG91dGVyID0gbWQ1KEJ1ZmZlci5jb25jYXQoW0J1ZmZlci5mcm9tKGlubmVyKSwgc2FsdF0pKVxuICByZXR1cm4gJ21kNScgKyBvdXRlclxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgcHJlcGFyZVZhbHVlOiBmdW5jdGlvbiBwcmVwYXJlVmFsdWVXcmFwcGVyKHZhbHVlKSB7XG4gICAgLy8gdGhpcyBlbnN1cmVzIHRoYXQgZXh0cmEgYXJndW1lbnRzIGRvIG5vdCBnZXQgcGFzc2VkIGludG8gcHJlcGFyZVZhbHVlXG4gICAgLy8gYnkgYWNjaWRlbnQsIGVnOiBmcm9tIGNhbGxpbmcgdmFsdWVzLm1hcCh1dGlscy5wcmVwYXJlVmFsdWUpXG4gICAgcmV0dXJuIHByZXBhcmVWYWx1ZSh2YWx1ZSlcbiAgfSxcbiAgbm9ybWFsaXplUXVlcnlDb25maWcsXG4gIHBvc3RncmVzTWQ1UGFzc3dvcmRIYXNoLFxuICBtZDUsXG59XG4iLCIndXNlIHN0cmljdCc7XG5cbnZhciBwYXRoID0gcmVxdWlyZSgncGF0aCcpXG4gICwgU3RyZWFtID0gcmVxdWlyZSgnc3RyZWFtJykuU3RyZWFtXG4gICwgc3BsaXQgPSByZXF1aXJlKCdzcGxpdDInKVxuICAsIHV0aWwgPSByZXF1aXJlKCd1dGlsJylcbiAgLCBkZWZhdWx0UG9ydCA9IDU0MzJcbiAgLCBpc1dpbiA9IChwcm9jZXNzLnBsYXRmb3JtID09PSAnd2luMzInKVxuICAsIHdhcm5TdHJlYW0gPSBwcm9jZXNzLnN0ZGVyclxuO1xuXG5cbnZhciBTX0lSV1hHID0gNTYgICAgIC8vICAgIDAwMDcwKDgpXG4gICwgU19JUldYTyA9IDcgICAgICAvLyAgICAwMDAwNyg4KVxuICAsIFNfSUZNVCAgPSA2MTQ0MCAgLy8gMDAxNzAwMDAoOClcbiAgLCBTX0lGUkVHID0gMzI3NjggIC8vICAwMTAwMDAwKDgpXG47XG5mdW5jdGlvbiBpc1JlZ0ZpbGUobW9kZSkge1xuICAgIHJldHVybiAoKG1vZGUgJiBTX0lGTVQpID09IFNfSUZSRUcpO1xufVxuXG52YXIgZmllbGROYW1lcyA9IFsgJ2hvc3QnLCAncG9ydCcsICdkYXRhYmFzZScsICd1c2VyJywgJ3Bhc3N3b3JkJyBdO1xudmFyIG5yT2ZGaWVsZHMgPSBmaWVsZE5hbWVzLmxlbmd0aDtcbnZhciBwYXNzS2V5ID0gZmllbGROYW1lc1sgbnJPZkZpZWxkcyAtMSBdO1xuXG5cbmZ1bmN0aW9uIHdhcm4oKSB7XG4gICAgdmFyIGlzV3JpdGFibGUgPSAoXG4gICAgICAgIHdhcm5TdHJlYW0gaW5zdGFuY2VvZiBTdHJlYW0gJiZcbiAgICAgICAgICB0cnVlID09PSB3YXJuU3RyZWFtLndyaXRhYmxlXG4gICAgKTtcblxuICAgIGlmIChpc1dyaXRhYmxlKSB7XG4gICAgICAgIHZhciBhcmdzID0gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwoYXJndW1lbnRzKS5jb25jYXQoXCJcXG5cIik7XG4gICAgICAgIHdhcm5TdHJlYW0ud3JpdGUoIHV0aWwuZm9ybWF0LmFwcGx5KHV0aWwsIGFyZ3MpICk7XG4gICAgfVxufVxuXG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShtb2R1bGUuZXhwb3J0cywgJ2lzV2luJywge1xuICAgIGdldCA6IGZ1bmN0aW9uKCkge1xuICAgICAgICByZXR1cm4gaXNXaW47XG4gICAgfSAsXG4gICAgc2V0IDogZnVuY3Rpb24odmFsKSB7XG4gICAgICAgIGlzV2luID0gdmFsO1xuICAgIH1cbn0pO1xuXG5cbm1vZHVsZS5leHBvcnRzLndhcm5UbyA9IGZ1bmN0aW9uKHN0cmVhbSkge1xuICAgIHZhciBvbGQgPSB3YXJuU3RyZWFtO1xuICAgIHdhcm5TdHJlYW0gPSBzdHJlYW07XG4gICAgcmV0dXJuIG9sZDtcbn07XG5cbm1vZHVsZS5leHBvcnRzLmdldEZpbGVOYW1lID0gZnVuY3Rpb24ocmF3RW52KXtcbiAgICB2YXIgZW52ID0gcmF3RW52IHx8IHByb2Nlc3MuZW52O1xuICAgIHZhciBmaWxlID0gZW52LlBHUEFTU0ZJTEUgfHwgKFxuICAgICAgICBpc1dpbiA/XG4gICAgICAgICAgcGF0aC5qb2luKCBlbnYuQVBQREFUQSB8fCAnLi8nICwgJ3Bvc3RncmVzcWwnLCAncGdwYXNzLmNvbmYnICkgOlxuICAgICAgICAgIHBhdGguam9pbiggZW52LkhPTUUgfHwgJy4vJywgJy5wZ3Bhc3MnIClcbiAgICApO1xuICAgIHJldHVybiBmaWxlO1xufTtcblxubW9kdWxlLmV4cG9ydHMudXNlUGdQYXNzID0gZnVuY3Rpb24oc3RhdHMsIGZuYW1lKSB7XG4gICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChwcm9jZXNzLmVudiwgJ1BHUEFTU1dPUkQnKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgaWYgKGlzV2luKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cblxuICAgIGZuYW1lID0gZm5hbWUgfHwgJzx1bmtuPic7XG5cbiAgICBpZiAoISBpc1JlZ0ZpbGUoc3RhdHMubW9kZSkpIHtcbiAgICAgICAgd2FybignV0FSTklORzogcGFzc3dvcmQgZmlsZSBcIiVzXCIgaXMgbm90IGEgcGxhaW4gZmlsZScsIGZuYW1lKTtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIGlmIChzdGF0cy5tb2RlICYgKFNfSVJXWEcgfCBTX0lSV1hPKSkge1xuICAgICAgICAvKiBJZiBwYXNzd29yZCBmaWxlIGlzIGluc2VjdXJlLCBhbGVydCB0aGUgdXNlciBhbmQgaWdub3JlIGl0LiAqL1xuICAgICAgICB3YXJuKCdXQVJOSU5HOiBwYXNzd29yZCBmaWxlIFwiJXNcIiBoYXMgZ3JvdXAgb3Igd29ybGQgYWNjZXNzOyBwZXJtaXNzaW9ucyBzaG91bGQgYmUgdT1ydyAoMDYwMCkgb3IgbGVzcycsIGZuYW1lKTtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIHJldHVybiB0cnVlO1xufTtcblxuXG52YXIgbWF0Y2hlciA9IG1vZHVsZS5leHBvcnRzLm1hdGNoID0gZnVuY3Rpb24oY29ubkluZm8sIGVudHJ5KSB7XG4gICAgcmV0dXJuIGZpZWxkTmFtZXMuc2xpY2UoMCwgLTEpLnJlZHVjZShmdW5jdGlvbihwcmV2LCBmaWVsZCwgaWR4KXtcbiAgICAgICAgaWYgKGlkeCA9PSAxKSB7XG4gICAgICAgICAgICAvLyB0aGUgcG9ydFxuICAgICAgICAgICAgaWYgKCBOdW1iZXIoIGNvbm5JbmZvW2ZpZWxkXSB8fCBkZWZhdWx0UG9ydCApID09PSBOdW1iZXIoIGVudHJ5W2ZpZWxkXSApICkge1xuICAgICAgICAgICAgICAgIHJldHVybiBwcmV2ICYmIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHByZXYgJiYgKFxuICAgICAgICAgICAgZW50cnlbZmllbGRdID09PSAnKicgfHxcbiAgICAgICAgICAgICAgZW50cnlbZmllbGRdID09PSBjb25uSW5mb1tmaWVsZF1cbiAgICAgICAgKTtcbiAgICB9LCB0cnVlKTtcbn07XG5cblxubW9kdWxlLmV4cG9ydHMuZ2V0UGFzc3dvcmQgPSBmdW5jdGlvbihjb25uSW5mbywgc3RyZWFtLCBjYikge1xuICAgIHZhciBwYXNzO1xuICAgIHZhciBsaW5lU3RyZWFtID0gc3RyZWFtLnBpcGUoc3BsaXQoKSk7XG5cbiAgICBmdW5jdGlvbiBvbkxpbmUobGluZSkge1xuICAgICAgICB2YXIgZW50cnkgPSBwYXJzZUxpbmUobGluZSk7XG4gICAgICAgIGlmIChlbnRyeSAmJiBpc1ZhbGlkRW50cnkoZW50cnkpICYmIG1hdGNoZXIoY29ubkluZm8sIGVudHJ5KSkge1xuICAgICAgICAgICAgcGFzcyA9IGVudHJ5W3Bhc3NLZXldO1xuICAgICAgICAgICAgbGluZVN0cmVhbS5lbmQoKTsgLy8gLT4gY2FsbHMgb25FbmQoKSwgYnV0IHBhc3MgaXMgc2V0IG5vd1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgdmFyIG9uRW5kID0gZnVuY3Rpb24oKSB7XG4gICAgICAgIHN0cmVhbS5kZXN0cm95KCk7XG4gICAgICAgIGNiKHBhc3MpO1xuICAgIH07XG5cbiAgICB2YXIgb25FcnIgPSBmdW5jdGlvbihlcnIpIHtcbiAgICAgICAgc3RyZWFtLmRlc3Ryb3koKTtcbiAgICAgICAgd2FybignV0FSTklORzogZXJyb3Igb24gcmVhZGluZyBmaWxlOiAlcycsIGVycik7XG4gICAgICAgIGNiKHVuZGVmaW5lZCk7XG4gICAgfTtcblxuICAgIHN0cmVhbS5vbignZXJyb3InLCBvbkVycik7XG4gICAgbGluZVN0cmVhbVxuICAgICAgICAub24oJ2RhdGEnLCBvbkxpbmUpXG4gICAgICAgIC5vbignZW5kJywgb25FbmQpXG4gICAgICAgIC5vbignZXJyb3InLCBvbkVycilcbiAgICA7XG5cbn07XG5cblxudmFyIHBhcnNlTGluZSA9IG1vZHVsZS5leHBvcnRzLnBhcnNlTGluZSA9IGZ1bmN0aW9uKGxpbmUpIHtcbiAgICBpZiAobGluZS5sZW5ndGggPCAxMSB8fCBsaW5lLm1hdGNoKC9eXFxzKyMvKSkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG5cbiAgICB2YXIgY3VyQ2hhciA9ICcnO1xuICAgIHZhciBwcmV2Q2hhciA9ICcnO1xuICAgIHZhciBmaWVsZElkeCA9IDA7XG4gICAgdmFyIHN0YXJ0SWR4ID0gMDtcbiAgICB2YXIgZW5kSWR4ID0gMDtcbiAgICB2YXIgb2JqID0ge307XG4gICAgdmFyIGlzTGFzdEZpZWxkID0gZmFsc2U7XG4gICAgdmFyIGFkZFRvT2JqID0gZnVuY3Rpb24oaWR4LCBpMCwgaTEpIHtcbiAgICAgICAgdmFyIGZpZWxkID0gbGluZS5zdWJzdHJpbmcoaTAsIGkxKTtcblxuICAgICAgICBpZiAoISBPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChwcm9jZXNzLmVudiwgJ1BHUEFTU19OT19ERUVTQ0FQRScpKSB7XG4gICAgICAgICAgICBmaWVsZCA9IGZpZWxkLnJlcGxhY2UoL1xcXFwoWzpcXFxcXSkvZywgJyQxJyk7XG4gICAgICAgIH1cblxuICAgICAgICBvYmpbIGZpZWxkTmFtZXNbaWR4XSBdID0gZmllbGQ7XG4gICAgfTtcblxuICAgIGZvciAodmFyIGkgPSAwIDsgaSA8IGxpbmUubGVuZ3RoLTEgOyBpICs9IDEpIHtcbiAgICAgICAgY3VyQ2hhciA9IGxpbmUuY2hhckF0KGkrMSk7XG4gICAgICAgIHByZXZDaGFyID0gbGluZS5jaGFyQXQoaSk7XG5cbiAgICAgICAgaXNMYXN0RmllbGQgPSAoZmllbGRJZHggPT0gbnJPZkZpZWxkcy0xKTtcblxuICAgICAgICBpZiAoaXNMYXN0RmllbGQpIHtcbiAgICAgICAgICAgIGFkZFRvT2JqKGZpZWxkSWR4LCBzdGFydElkeCk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChpID49IDAgJiYgY3VyQ2hhciA9PSAnOicgJiYgcHJldkNoYXIgIT09ICdcXFxcJykge1xuICAgICAgICAgICAgYWRkVG9PYmooZmllbGRJZHgsIHN0YXJ0SWR4LCBpKzEpO1xuXG4gICAgICAgICAgICBzdGFydElkeCA9IGkrMjtcbiAgICAgICAgICAgIGZpZWxkSWR4ICs9IDE7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBvYmogPSAoIE9iamVjdC5rZXlzKG9iaikubGVuZ3RoID09PSBuck9mRmllbGRzICkgPyBvYmogOiBudWxsO1xuXG4gICAgcmV0dXJuIG9iajtcbn07XG5cblxudmFyIGlzVmFsaWRFbnRyeSA9IG1vZHVsZS5leHBvcnRzLmlzVmFsaWRFbnRyeSA9IGZ1bmN0aW9uKGVudHJ5KXtcbiAgICB2YXIgcnVsZXMgPSB7XG4gICAgICAgIC8vIGhvc3RcbiAgICAgICAgMCA6IGZ1bmN0aW9uKHgpe1xuICAgICAgICAgICAgcmV0dXJuIHgubGVuZ3RoID4gMDtcbiAgICAgICAgfSAsXG4gICAgICAgIC8vIHBvcnRcbiAgICAgICAgMSA6IGZ1bmN0aW9uKHgpe1xuICAgICAgICAgICAgaWYgKHggPT09ICcqJykge1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgeCA9IE51bWJlcih4KTtcbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgaXNGaW5pdGUoeCkgJiZcbiAgICAgICAgICAgICAgICAgIHggPiAwICYmXG4gICAgICAgICAgICAgICAgICB4IDwgOTAwNzE5OTI1NDc0MDk5MiAmJlxuICAgICAgICAgICAgICAgICAgTWF0aC5mbG9vcih4KSA9PT0geFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfSAsXG4gICAgICAgIC8vIGRhdGFiYXNlXG4gICAgICAgIDIgOiBmdW5jdGlvbih4KXtcbiAgICAgICAgICAgIHJldHVybiB4Lmxlbmd0aCA+IDA7XG4gICAgICAgIH0gLFxuICAgICAgICAvLyB1c2VybmFtZVxuICAgICAgICAzIDogZnVuY3Rpb24oeCl7XG4gICAgICAgICAgICByZXR1cm4geC5sZW5ndGggPiAwO1xuICAgICAgICB9ICxcbiAgICAgICAgLy8gcGFzc3dvcmRcbiAgICAgICAgNCA6IGZ1bmN0aW9uKHgpe1xuICAgICAgICAgICAgcmV0dXJuIHgubGVuZ3RoID4gMDtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBmb3IgKHZhciBpZHggPSAwIDsgaWR4IDwgZmllbGROYW1lcy5sZW5ndGggOyBpZHggKz0gMSkge1xuICAgICAgICB2YXIgcnVsZSA9IHJ1bGVzW2lkeF07XG4gICAgICAgIHZhciB2YWx1ZSA9IGVudHJ5WyBmaWVsZE5hbWVzW2lkeF0gXSB8fCAnJztcblxuICAgICAgICB2YXIgcmVzID0gcnVsZSh2YWx1ZSk7XG4gICAgICAgIGlmICghcmVzKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gdHJ1ZTtcbn07XG5cbiIsIid1c2Ugc3RyaWN0JztcblxudmFyIHBhdGggPSByZXF1aXJlKCdwYXRoJylcbiAgLCBmcyA9IHJlcXVpcmUoJ2ZzJylcbiAgLCBoZWxwZXIgPSByZXF1aXJlKCcuL2hlbHBlci5qcycpXG47XG5cblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbihjb25uSW5mbywgY2IpIHtcbiAgICB2YXIgZmlsZSA9IGhlbHBlci5nZXRGaWxlTmFtZSgpO1xuICAgIFxuICAgIGZzLnN0YXQoZmlsZSwgZnVuY3Rpb24oZXJyLCBzdGF0KXtcbiAgICAgICAgaWYgKGVyciB8fCAhaGVscGVyLnVzZVBnUGFzcyhzdGF0LCBmaWxlKSkge1xuICAgICAgICAgICAgcmV0dXJuIGNiKHVuZGVmaW5lZCk7XG4gICAgICAgIH1cblxuICAgICAgICB2YXIgc3QgPSBmcy5jcmVhdGVSZWFkU3RyZWFtKGZpbGUpO1xuXG4gICAgICAgIGhlbHBlci5nZXRQYXNzd29yZChjb25uSW5mbywgc3QsIGNiKTtcbiAgICB9KTtcbn07XG5cbm1vZHVsZS5leHBvcnRzLndhcm5UbyA9IGhlbHBlci53YXJuVG87XG4iLCIndXNlIHN0cmljdCdcblxuZXhwb3J0cy5wYXJzZSA9IGZ1bmN0aW9uIChzb3VyY2UsIHRyYW5zZm9ybSkge1xuICByZXR1cm4gbmV3IEFycmF5UGFyc2VyKHNvdXJjZSwgdHJhbnNmb3JtKS5wYXJzZSgpXG59XG5cbmNsYXNzIEFycmF5UGFyc2VyIHtcbiAgY29uc3RydWN0b3IgKHNvdXJjZSwgdHJhbnNmb3JtKSB7XG4gICAgdGhpcy5zb3VyY2UgPSBzb3VyY2VcbiAgICB0aGlzLnRyYW5zZm9ybSA9IHRyYW5zZm9ybSB8fCBpZGVudGl0eVxuICAgIHRoaXMucG9zaXRpb24gPSAwXG4gICAgdGhpcy5lbnRyaWVzID0gW11cbiAgICB0aGlzLnJlY29yZGVkID0gW11cbiAgICB0aGlzLmRpbWVuc2lvbiA9IDBcbiAgfVxuXG4gIGlzRW9mICgpIHtcbiAgICByZXR1cm4gdGhpcy5wb3NpdGlvbiA+PSB0aGlzLnNvdXJjZS5sZW5ndGhcbiAgfVxuXG4gIG5leHRDaGFyYWN0ZXIgKCkge1xuICAgIHZhciBjaGFyYWN0ZXIgPSB0aGlzLnNvdXJjZVt0aGlzLnBvc2l0aW9uKytdXG4gICAgaWYgKGNoYXJhY3RlciA9PT0gJ1xcXFwnKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB2YWx1ZTogdGhpcy5zb3VyY2VbdGhpcy5wb3NpdGlvbisrXSxcbiAgICAgICAgZXNjYXBlZDogdHJ1ZVxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgdmFsdWU6IGNoYXJhY3RlcixcbiAgICAgIGVzY2FwZWQ6IGZhbHNlXG4gICAgfVxuICB9XG5cbiAgcmVjb3JkIChjaGFyYWN0ZXIpIHtcbiAgICB0aGlzLnJlY29yZGVkLnB1c2goY2hhcmFjdGVyKVxuICB9XG5cbiAgbmV3RW50cnkgKGluY2x1ZGVFbXB0eSkge1xuICAgIHZhciBlbnRyeVxuICAgIGlmICh0aGlzLnJlY29yZGVkLmxlbmd0aCA+IDAgfHwgaW5jbHVkZUVtcHR5KSB7XG4gICAgICBlbnRyeSA9IHRoaXMucmVjb3JkZWQuam9pbignJylcbiAgICAgIGlmIChlbnRyeSA9PT0gJ05VTEwnICYmICFpbmNsdWRlRW1wdHkpIHtcbiAgICAgICAgZW50cnkgPSBudWxsXG4gICAgICB9XG4gICAgICBpZiAoZW50cnkgIT09IG51bGwpIGVudHJ5ID0gdGhpcy50cmFuc2Zvcm0oZW50cnkpXG4gICAgICB0aGlzLmVudHJpZXMucHVzaChlbnRyeSlcbiAgICAgIHRoaXMucmVjb3JkZWQgPSBbXVxuICAgIH1cbiAgfVxuXG4gIGNvbnN1bWVEaW1lbnNpb25zICgpIHtcbiAgICBpZiAodGhpcy5zb3VyY2VbMF0gPT09ICdbJykge1xuICAgICAgd2hpbGUgKCF0aGlzLmlzRW9mKCkpIHtcbiAgICAgICAgdmFyIGNoYXIgPSB0aGlzLm5leHRDaGFyYWN0ZXIoKVxuICAgICAgICBpZiAoY2hhci52YWx1ZSA9PT0gJz0nKSBicmVha1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHBhcnNlIChuZXN0ZWQpIHtcbiAgICB2YXIgY2hhcmFjdGVyLCBwYXJzZXIsIHF1b3RlXG4gICAgdGhpcy5jb25zdW1lRGltZW5zaW9ucygpXG4gICAgd2hpbGUgKCF0aGlzLmlzRW9mKCkpIHtcbiAgICAgIGNoYXJhY3RlciA9IHRoaXMubmV4dENoYXJhY3RlcigpXG4gICAgICBpZiAoY2hhcmFjdGVyLnZhbHVlID09PSAneycgJiYgIXF1b3RlKSB7XG4gICAgICAgIHRoaXMuZGltZW5zaW9uKytcbiAgICAgICAgaWYgKHRoaXMuZGltZW5zaW9uID4gMSkge1xuICAgICAgICAgIHBhcnNlciA9IG5ldyBBcnJheVBhcnNlcih0aGlzLnNvdXJjZS5zdWJzdHIodGhpcy5wb3NpdGlvbiAtIDEpLCB0aGlzLnRyYW5zZm9ybSlcbiAgICAgICAgICB0aGlzLmVudHJpZXMucHVzaChwYXJzZXIucGFyc2UodHJ1ZSkpXG4gICAgICAgICAgdGhpcy5wb3NpdGlvbiArPSBwYXJzZXIucG9zaXRpb24gLSAyXG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoY2hhcmFjdGVyLnZhbHVlID09PSAnfScgJiYgIXF1b3RlKSB7XG4gICAgICAgIHRoaXMuZGltZW5zaW9uLS1cbiAgICAgICAgaWYgKCF0aGlzLmRpbWVuc2lvbikge1xuICAgICAgICAgIHRoaXMubmV3RW50cnkoKVxuICAgICAgICAgIGlmIChuZXN0ZWQpIHJldHVybiB0aGlzLmVudHJpZXNcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChjaGFyYWN0ZXIudmFsdWUgPT09ICdcIicgJiYgIWNoYXJhY3Rlci5lc2NhcGVkKSB7XG4gICAgICAgIGlmIChxdW90ZSkgdGhpcy5uZXdFbnRyeSh0cnVlKVxuICAgICAgICBxdW90ZSA9ICFxdW90ZVxuICAgICAgfSBlbHNlIGlmIChjaGFyYWN0ZXIudmFsdWUgPT09ICcsJyAmJiAhcXVvdGUpIHtcbiAgICAgICAgdGhpcy5uZXdFbnRyeSgpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLnJlY29yZChjaGFyYWN0ZXIudmFsdWUpXG4gICAgICB9XG4gICAgfVxuICAgIGlmICh0aGlzLmRpbWVuc2lvbiAhPT0gMCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdhcnJheSBkaW1lbnNpb24gbm90IGJhbGFuY2VkJylcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuZW50cmllc1xuICB9XG59XG5cbmZ1bmN0aW9uIGlkZW50aXR5ICh2YWx1ZSkge1xuICByZXR1cm4gdmFsdWVcbn1cbiIsIid1c2Ugc3RyaWN0J1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIHBhcnNlQnl0ZWEgKGlucHV0KSB7XG4gIGlmICgvXlxcXFx4Ly50ZXN0KGlucHV0KSkge1xuICAgIC8vIG5ldyAnaGV4JyBzdHlsZSByZXNwb25zZSAocGcgPjkuMClcbiAgICByZXR1cm4gbmV3IEJ1ZmZlcihpbnB1dC5zdWJzdHIoMiksICdoZXgnKVxuICB9XG4gIHZhciBvdXRwdXQgPSAnJ1xuICB2YXIgaSA9IDBcbiAgd2hpbGUgKGkgPCBpbnB1dC5sZW5ndGgpIHtcbiAgICBpZiAoaW5wdXRbaV0gIT09ICdcXFxcJykge1xuICAgICAgb3V0cHV0ICs9IGlucHV0W2ldXG4gICAgICArK2lcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKC9bMC03XXszfS8udGVzdChpbnB1dC5zdWJzdHIoaSArIDEsIDMpKSkge1xuICAgICAgICBvdXRwdXQgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShwYXJzZUludChpbnB1dC5zdWJzdHIoaSArIDEsIDMpLCA4KSlcbiAgICAgICAgaSArPSA0XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB2YXIgYmFja3NsYXNoZXMgPSAxXG4gICAgICAgIHdoaWxlIChpICsgYmFja3NsYXNoZXMgPCBpbnB1dC5sZW5ndGggJiYgaW5wdXRbaSArIGJhY2tzbGFzaGVzXSA9PT0gJ1xcXFwnKSB7XG4gICAgICAgICAgYmFja3NsYXNoZXMrK1xuICAgICAgICB9XG4gICAgICAgIGZvciAodmFyIGsgPSAwOyBrIDwgTWF0aC5mbG9vcihiYWNrc2xhc2hlcyAvIDIpOyArK2spIHtcbiAgICAgICAgICBvdXRwdXQgKz0gJ1xcXFwnXG4gICAgICAgIH1cbiAgICAgICAgaSArPSBNYXRoLmZsb29yKGJhY2tzbGFzaGVzIC8gMikgKiAyXG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBuZXcgQnVmZmVyKG91dHB1dCwgJ2JpbmFyeScpXG59XG4iLCIndXNlIHN0cmljdCdcblxudmFyIERBVEVfVElNRSA9IC8oXFxkezEsfSktKFxcZHsyfSktKFxcZHsyfSkgKFxcZHsyfSk6KFxcZHsyfSk6KFxcZHsyfSkoXFwuXFxkezEsfSk/Lio/KCBCQyk/JC9cbnZhciBEQVRFID0gL14oXFxkezEsfSktKFxcZHsyfSktKFxcZHsyfSkoIEJDKT8kL1xudmFyIFRJTUVfWk9ORSA9IC8oW1orLV0pKFxcZHsyfSk/Oj8oXFxkezJ9KT86PyhcXGR7Mn0pPy9cbnZhciBJTkZJTklUWSA9IC9eLT9pbmZpbml0eSQvXG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gcGFyc2VEYXRlIChpc29EYXRlKSB7XG4gIGlmIChJTkZJTklUWS50ZXN0KGlzb0RhdGUpKSB7XG4gICAgLy8gQ2FwaXRhbGl6ZSB0byBJbmZpbml0eSBiZWZvcmUgcGFzc2luZyB0byBOdW1iZXJcbiAgICByZXR1cm4gTnVtYmVyKGlzb0RhdGUucmVwbGFjZSgnaScsICdJJykpXG4gIH1cbiAgdmFyIG1hdGNoZXMgPSBEQVRFX1RJTUUuZXhlYyhpc29EYXRlKVxuXG4gIGlmICghbWF0Y2hlcykge1xuICAgIC8vIEZvcmNlIFlZWVktTU0tREQgZGF0ZXMgdG8gYmUgcGFyc2VkIGFzIGxvY2FsIHRpbWVcbiAgICByZXR1cm4gZ2V0RGF0ZShpc29EYXRlKSB8fCBudWxsXG4gIH1cblxuICB2YXIgaXNCQyA9ICEhbWF0Y2hlc1s4XVxuICB2YXIgeWVhciA9IHBhcnNlSW50KG1hdGNoZXNbMV0sIDEwKVxuICBpZiAoaXNCQykge1xuICAgIHllYXIgPSBiY1llYXJUb05lZ2F0aXZlWWVhcih5ZWFyKVxuICB9XG5cbiAgdmFyIG1vbnRoID0gcGFyc2VJbnQobWF0Y2hlc1syXSwgMTApIC0gMVxuICB2YXIgZGF5ID0gbWF0Y2hlc1szXVxuICB2YXIgaG91ciA9IHBhcnNlSW50KG1hdGNoZXNbNF0sIDEwKVxuICB2YXIgbWludXRlID0gcGFyc2VJbnQobWF0Y2hlc1s1XSwgMTApXG4gIHZhciBzZWNvbmQgPSBwYXJzZUludChtYXRjaGVzWzZdLCAxMClcblxuICB2YXIgbXMgPSBtYXRjaGVzWzddXG4gIG1zID0gbXMgPyAxMDAwICogcGFyc2VGbG9hdChtcykgOiAwXG5cbiAgdmFyIGRhdGVcbiAgdmFyIG9mZnNldCA9IHRpbWVab25lT2Zmc2V0KGlzb0RhdGUpXG4gIGlmIChvZmZzZXQgIT0gbnVsbCkge1xuICAgIGRhdGUgPSBuZXcgRGF0ZShEYXRlLlVUQyh5ZWFyLCBtb250aCwgZGF5LCBob3VyLCBtaW51dGUsIHNlY29uZCwgbXMpKVxuXG4gICAgLy8gQWNjb3VudCBmb3IgeWVhcnMgZnJvbSAwIHRvIDk5IGJlaW5nIGludGVycHJldGVkIGFzIDE5MDAtMTk5OVxuICAgIC8vIGJ5IERhdGUuVVRDIC8gdGhlIG11bHRpLWFyZ3VtZW50IGZvcm0gb2YgdGhlIERhdGUgY29uc3RydWN0b3JcbiAgICBpZiAoaXMwVG85OSh5ZWFyKSkge1xuICAgICAgZGF0ZS5zZXRVVENGdWxsWWVhcih5ZWFyKVxuICAgIH1cblxuICAgIGlmIChvZmZzZXQgIT09IDApIHtcbiAgICAgIGRhdGUuc2V0VGltZShkYXRlLmdldFRpbWUoKSAtIG9mZnNldClcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgZGF0ZSA9IG5ldyBEYXRlKHllYXIsIG1vbnRoLCBkYXksIGhvdXIsIG1pbnV0ZSwgc2Vjb25kLCBtcylcblxuICAgIGlmIChpczBUbzk5KHllYXIpKSB7XG4gICAgICBkYXRlLnNldEZ1bGxZZWFyKHllYXIpXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGRhdGVcbn1cblxuZnVuY3Rpb24gZ2V0RGF0ZSAoaXNvRGF0ZSkge1xuICB2YXIgbWF0Y2hlcyA9IERBVEUuZXhlYyhpc29EYXRlKVxuICBpZiAoIW1hdGNoZXMpIHtcbiAgICByZXR1cm5cbiAgfVxuXG4gIHZhciB5ZWFyID0gcGFyc2VJbnQobWF0Y2hlc1sxXSwgMTApXG4gIHZhciBpc0JDID0gISFtYXRjaGVzWzRdXG4gIGlmIChpc0JDKSB7XG4gICAgeWVhciA9IGJjWWVhclRvTmVnYXRpdmVZZWFyKHllYXIpXG4gIH1cblxuICB2YXIgbW9udGggPSBwYXJzZUludChtYXRjaGVzWzJdLCAxMCkgLSAxXG4gIHZhciBkYXkgPSBtYXRjaGVzWzNdXG4gIC8vIFlZWVktTU0tREQgd2lsbCBiZSBwYXJzZWQgYXMgbG9jYWwgdGltZVxuICB2YXIgZGF0ZSA9IG5ldyBEYXRlKHllYXIsIG1vbnRoLCBkYXkpXG5cbiAgaWYgKGlzMFRvOTkoeWVhcikpIHtcbiAgICBkYXRlLnNldEZ1bGxZZWFyKHllYXIpXG4gIH1cblxuICByZXR1cm4gZGF0ZVxufVxuXG4vLyBtYXRjaCB0aW1lem9uZXM6XG4vLyBaIChVVEMpXG4vLyAtMDVcbi8vICswNjozMFxuZnVuY3Rpb24gdGltZVpvbmVPZmZzZXQgKGlzb0RhdGUpIHtcbiAgaWYgKGlzb0RhdGUuZW5kc1dpdGgoJyswMCcpKSB7XG4gICAgcmV0dXJuIDBcbiAgfVxuXG4gIHZhciB6b25lID0gVElNRV9aT05FLmV4ZWMoaXNvRGF0ZS5zcGxpdCgnICcpWzFdKVxuICBpZiAoIXpvbmUpIHJldHVyblxuICB2YXIgdHlwZSA9IHpvbmVbMV1cblxuICBpZiAodHlwZSA9PT0gJ1onKSB7XG4gICAgcmV0dXJuIDBcbiAgfVxuICB2YXIgc2lnbiA9IHR5cGUgPT09ICctJyA/IC0xIDogMVxuICB2YXIgb2Zmc2V0ID0gcGFyc2VJbnQoem9uZVsyXSwgMTApICogMzYwMCArXG4gICAgcGFyc2VJbnQoem9uZVszXSB8fCAwLCAxMCkgKiA2MCArXG4gICAgcGFyc2VJbnQoem9uZVs0XSB8fCAwLCAxMClcblxuICByZXR1cm4gb2Zmc2V0ICogc2lnbiAqIDEwMDBcbn1cblxuZnVuY3Rpb24gYmNZZWFyVG9OZWdhdGl2ZVllYXIgKHllYXIpIHtcbiAgLy8gQWNjb3VudCBmb3IgbnVtZXJpY2FsIGRpZmZlcmVuY2UgYmV0d2VlbiByZXByZXNlbnRhdGlvbnMgb2YgQkMgeWVhcnNcbiAgLy8gU2VlOiBodHRwczovL2dpdGh1Yi5jb20vYmVuZHJ1Y2tlci9wb3N0Z3Jlcy1kYXRlL2lzc3Vlcy81XG4gIHJldHVybiAtKHllYXIgLSAxKVxufVxuXG5mdW5jdGlvbiBpczBUbzk5IChudW0pIHtcbiAgcmV0dXJuIG51bSA+PSAwICYmIG51bSA8IDEwMFxufVxuIiwiJ3VzZSBzdHJpY3QnXG5cbnZhciBleHRlbmQgPSByZXF1aXJlKCd4dGVuZC9tdXRhYmxlJylcblxubW9kdWxlLmV4cG9ydHMgPSBQb3N0Z3Jlc0ludGVydmFsXG5cbmZ1bmN0aW9uIFBvc3RncmVzSW50ZXJ2YWwgKHJhdykge1xuICBpZiAoISh0aGlzIGluc3RhbmNlb2YgUG9zdGdyZXNJbnRlcnZhbCkpIHtcbiAgICByZXR1cm4gbmV3IFBvc3RncmVzSW50ZXJ2YWwocmF3KVxuICB9XG4gIGV4dGVuZCh0aGlzLCBwYXJzZShyYXcpKVxufVxudmFyIHByb3BlcnRpZXMgPSBbJ3NlY29uZHMnLCAnbWludXRlcycsICdob3VycycsICdkYXlzJywgJ21vbnRocycsICd5ZWFycyddXG5Qb3N0Z3Jlc0ludGVydmFsLnByb3RvdHlwZS50b1Bvc3RncmVzID0gZnVuY3Rpb24gKCkge1xuICB2YXIgZmlsdGVyZWQgPSBwcm9wZXJ0aWVzLmZpbHRlcih0aGlzLmhhc093blByb3BlcnR5LCB0aGlzKVxuXG4gIC8vIEluIGFkZGl0aW9uIHRvIGBwcm9wZXJ0aWVzYCwgd2UgbmVlZCB0byBhY2NvdW50IGZvciBmcmFjdGlvbnMgb2Ygc2Vjb25kcy5cbiAgaWYgKHRoaXMubWlsbGlzZWNvbmRzICYmIGZpbHRlcmVkLmluZGV4T2YoJ3NlY29uZHMnKSA8IDApIHtcbiAgICBmaWx0ZXJlZC5wdXNoKCdzZWNvbmRzJylcbiAgfVxuXG4gIGlmIChmaWx0ZXJlZC5sZW5ndGggPT09IDApIHJldHVybiAnMCdcbiAgcmV0dXJuIGZpbHRlcmVkXG4gICAgLm1hcChmdW5jdGlvbiAocHJvcGVydHkpIHtcbiAgICAgIHZhciB2YWx1ZSA9IHRoaXNbcHJvcGVydHldIHx8IDBcblxuICAgICAgLy8gQWNjb3VudCBmb3IgZnJhY3Rpb25hbCBwYXJ0IG9mIHNlY29uZHMsXG4gICAgICAvLyByZW1vdmUgdHJhaWxpbmcgemVyb2VzLlxuICAgICAgaWYgKHByb3BlcnR5ID09PSAnc2Vjb25kcycgJiYgdGhpcy5taWxsaXNlY29uZHMpIHtcbiAgICAgICAgdmFsdWUgPSAodmFsdWUgKyB0aGlzLm1pbGxpc2Vjb25kcyAvIDEwMDApLnRvRml4ZWQoNikucmVwbGFjZSgvXFwuPzArJC8sICcnKVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gdmFsdWUgKyAnICcgKyBwcm9wZXJ0eVxuICAgIH0sIHRoaXMpXG4gICAgLmpvaW4oJyAnKVxufVxuXG52YXIgcHJvcGVydGllc0lTT0VxdWl2YWxlbnQgPSB7XG4gIHllYXJzOiAnWScsXG4gIG1vbnRoczogJ00nLFxuICBkYXlzOiAnRCcsXG4gIGhvdXJzOiAnSCcsXG4gIG1pbnV0ZXM6ICdNJyxcbiAgc2Vjb25kczogJ1MnXG59XG52YXIgZGF0ZVByb3BlcnRpZXMgPSBbJ3llYXJzJywgJ21vbnRocycsICdkYXlzJ11cbnZhciB0aW1lUHJvcGVydGllcyA9IFsnaG91cnMnLCAnbWludXRlcycsICdzZWNvbmRzJ11cbi8vIGFjY29yZGluZyB0byBJU08gODYwMVxuUG9zdGdyZXNJbnRlcnZhbC5wcm90b3R5cGUudG9JU09TdHJpbmcgPSBQb3N0Z3Jlc0ludGVydmFsLnByb3RvdHlwZS50b0lTTyA9IGZ1bmN0aW9uICgpIHtcbiAgdmFyIGRhdGVQYXJ0ID0gZGF0ZVByb3BlcnRpZXNcbiAgICAubWFwKGJ1aWxkUHJvcGVydHksIHRoaXMpXG4gICAgLmpvaW4oJycpXG5cbiAgdmFyIHRpbWVQYXJ0ID0gdGltZVByb3BlcnRpZXNcbiAgICAubWFwKGJ1aWxkUHJvcGVydHksIHRoaXMpXG4gICAgLmpvaW4oJycpXG5cbiAgcmV0dXJuICdQJyArIGRhdGVQYXJ0ICsgJ1QnICsgdGltZVBhcnRcblxuICBmdW5jdGlvbiBidWlsZFByb3BlcnR5IChwcm9wZXJ0eSkge1xuICAgIHZhciB2YWx1ZSA9IHRoaXNbcHJvcGVydHldIHx8IDBcblxuICAgIC8vIEFjY291bnQgZm9yIGZyYWN0aW9uYWwgcGFydCBvZiBzZWNvbmRzLFxuICAgIC8vIHJlbW92ZSB0cmFpbGluZyB6ZXJvZXMuXG4gICAgaWYgKHByb3BlcnR5ID09PSAnc2Vjb25kcycgJiYgdGhpcy5taWxsaXNlY29uZHMpIHtcbiAgICAgIHZhbHVlID0gKHZhbHVlICsgdGhpcy5taWxsaXNlY29uZHMgLyAxMDAwKS50b0ZpeGVkKDYpLnJlcGxhY2UoLzArJC8sICcnKVxuICAgIH1cblxuICAgIHJldHVybiB2YWx1ZSArIHByb3BlcnRpZXNJU09FcXVpdmFsZW50W3Byb3BlcnR5XVxuICB9XG59XG5cbnZhciBOVU1CRVIgPSAnKFsrLV0/XFxcXGQrKSdcbnZhciBZRUFSID0gTlVNQkVSICsgJ1xcXFxzK3llYXJzPydcbnZhciBNT05USCA9IE5VTUJFUiArICdcXFxccyttb25zPydcbnZhciBEQVkgPSBOVU1CRVIgKyAnXFxcXHMrZGF5cz8nXG52YXIgVElNRSA9ICcoWystXSk/KFtcXFxcZF0qKTooXFxcXGRcXFxcZCk6KFxcXFxkXFxcXGQpXFxcXC4/KFxcXFxkezEsNn0pPydcbnZhciBJTlRFUlZBTCA9IG5ldyBSZWdFeHAoW1lFQVIsIE1PTlRILCBEQVksIFRJTUVdLm1hcChmdW5jdGlvbiAocmVnZXhTdHJpbmcpIHtcbiAgcmV0dXJuICcoJyArIHJlZ2V4U3RyaW5nICsgJyk/J1xufSlcbiAgLmpvaW4oJ1xcXFxzKicpKVxuXG4vLyBQb3NpdGlvbnMgb2YgdmFsdWVzIGluIHJlZ2V4IG1hdGNoXG52YXIgcG9zaXRpb25zID0ge1xuICB5ZWFyczogMixcbiAgbW9udGhzOiA0LFxuICBkYXlzOiA2LFxuICBob3VyczogOSxcbiAgbWludXRlczogMTAsXG4gIHNlY29uZHM6IDExLFxuICBtaWxsaXNlY29uZHM6IDEyXG59XG4vLyBXZSBjYW4gdXNlIG5lZ2F0aXZlIHRpbWVcbnZhciBuZWdhdGl2ZXMgPSBbJ2hvdXJzJywgJ21pbnV0ZXMnLCAnc2Vjb25kcycsICdtaWxsaXNlY29uZHMnXVxuXG5mdW5jdGlvbiBwYXJzZU1pbGxpc2Vjb25kcyAoZnJhY3Rpb24pIHtcbiAgLy8gYWRkIG9taXR0ZWQgemVyb2VzXG4gIHZhciBtaWNyb3NlY29uZHMgPSBmcmFjdGlvbiArICcwMDAwMDAnLnNsaWNlKGZyYWN0aW9uLmxlbmd0aClcbiAgcmV0dXJuIHBhcnNlSW50KG1pY3Jvc2Vjb25kcywgMTApIC8gMTAwMFxufVxuXG5mdW5jdGlvbiBwYXJzZSAoaW50ZXJ2YWwpIHtcbiAgaWYgKCFpbnRlcnZhbCkgcmV0dXJuIHt9XG4gIHZhciBtYXRjaGVzID0gSU5URVJWQUwuZXhlYyhpbnRlcnZhbClcbiAgdmFyIGlzTmVnYXRpdmUgPSBtYXRjaGVzWzhdID09PSAnLSdcbiAgcmV0dXJuIE9iamVjdC5rZXlzKHBvc2l0aW9ucylcbiAgICAucmVkdWNlKGZ1bmN0aW9uIChwYXJzZWQsIHByb3BlcnR5KSB7XG4gICAgICB2YXIgcG9zaXRpb24gPSBwb3NpdGlvbnNbcHJvcGVydHldXG4gICAgICB2YXIgdmFsdWUgPSBtYXRjaGVzW3Bvc2l0aW9uXVxuICAgICAgLy8gbm8gZW1wdHkgc3RyaW5nXG4gICAgICBpZiAoIXZhbHVlKSByZXR1cm4gcGFyc2VkXG4gICAgICAvLyBtaWxsaXNlY29uZHMgYXJlIGFjdHVhbGx5IG1pY3Jvc2Vjb25kcyAodXAgdG8gNiBkaWdpdHMpXG4gICAgICAvLyB3aXRoIG9taXR0ZWQgdHJhaWxpbmcgemVyb2VzLlxuICAgICAgdmFsdWUgPSBwcm9wZXJ0eSA9PT0gJ21pbGxpc2Vjb25kcydcbiAgICAgICAgPyBwYXJzZU1pbGxpc2Vjb25kcyh2YWx1ZSlcbiAgICAgICAgOiBwYXJzZUludCh2YWx1ZSwgMTApXG4gICAgICAvLyBubyB6ZXJvc1xuICAgICAgaWYgKCF2YWx1ZSkgcmV0dXJuIHBhcnNlZFxuICAgICAgaWYgKGlzTmVnYXRpdmUgJiYgfm5lZ2F0aXZlcy5pbmRleE9mKHByb3BlcnR5KSkge1xuICAgICAgICB2YWx1ZSAqPSAtMVxuICAgICAgfVxuICAgICAgcGFyc2VkW3Byb3BlcnR5XSA9IHZhbHVlXG4gICAgICByZXR1cm4gcGFyc2VkXG4gICAgfSwge30pXG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmNvbnN0IGNvZGVzID0ge307XG5cbmZ1bmN0aW9uIGNyZWF0ZUVycm9yVHlwZShjb2RlLCBtZXNzYWdlLCBCYXNlKSB7XG4gIGlmICghQmFzZSkge1xuICAgIEJhc2UgPSBFcnJvclxuICB9XG5cbiAgZnVuY3Rpb24gZ2V0TWVzc2FnZSAoYXJnMSwgYXJnMiwgYXJnMykge1xuICAgIGlmICh0eXBlb2YgbWVzc2FnZSA9PT0gJ3N0cmluZycpIHtcbiAgICAgIHJldHVybiBtZXNzYWdlXG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBtZXNzYWdlKGFyZzEsIGFyZzIsIGFyZzMpXG4gICAgfVxuICB9XG5cbiAgY2xhc3MgTm9kZUVycm9yIGV4dGVuZHMgQmFzZSB7XG4gICAgY29uc3RydWN0b3IgKGFyZzEsIGFyZzIsIGFyZzMpIHtcbiAgICAgIHN1cGVyKGdldE1lc3NhZ2UoYXJnMSwgYXJnMiwgYXJnMykpO1xuICAgIH1cbiAgfVxuXG4gIE5vZGVFcnJvci5wcm90b3R5cGUubmFtZSA9IEJhc2UubmFtZTtcbiAgTm9kZUVycm9yLnByb3RvdHlwZS5jb2RlID0gY29kZTtcblxuICBjb2Rlc1tjb2RlXSA9IE5vZGVFcnJvcjtcbn1cblxuLy8gaHR0cHM6Ly9naXRodWIuY29tL25vZGVqcy9ub2RlL2Jsb2IvdjEwLjguMC9saWIvaW50ZXJuYWwvZXJyb3JzLmpzXG5mdW5jdGlvbiBvbmVPZihleHBlY3RlZCwgdGhpbmcpIHtcbiAgaWYgKEFycmF5LmlzQXJyYXkoZXhwZWN0ZWQpKSB7XG4gICAgY29uc3QgbGVuID0gZXhwZWN0ZWQubGVuZ3RoO1xuICAgIGV4cGVjdGVkID0gZXhwZWN0ZWQubWFwKChpKSA9PiBTdHJpbmcoaSkpO1xuICAgIGlmIChsZW4gPiAyKSB7XG4gICAgICByZXR1cm4gYG9uZSBvZiAke3RoaW5nfSAke2V4cGVjdGVkLnNsaWNlKDAsIGxlbiAtIDEpLmpvaW4oJywgJyl9LCBvciBgICtcbiAgICAgICAgICAgICBleHBlY3RlZFtsZW4gLSAxXTtcbiAgICB9IGVsc2UgaWYgKGxlbiA9PT0gMikge1xuICAgICAgcmV0dXJuIGBvbmUgb2YgJHt0aGluZ30gJHtleHBlY3RlZFswXX0gb3IgJHtleHBlY3RlZFsxXX1gO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gYG9mICR7dGhpbmd9ICR7ZXhwZWN0ZWRbMF19YDtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIGBvZiAke3RoaW5nfSAke1N0cmluZyhleHBlY3RlZCl9YDtcbiAgfVxufVxuXG4vLyBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9KYXZhU2NyaXB0L1JlZmVyZW5jZS9HbG9iYWxfT2JqZWN0cy9TdHJpbmcvc3RhcnRzV2l0aFxuZnVuY3Rpb24gc3RhcnRzV2l0aChzdHIsIHNlYXJjaCwgcG9zKSB7XG5cdHJldHVybiBzdHIuc3Vic3RyKCFwb3MgfHwgcG9zIDwgMCA/IDAgOiArcG9zLCBzZWFyY2gubGVuZ3RoKSA9PT0gc2VhcmNoO1xufVxuXG4vLyBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9KYXZhU2NyaXB0L1JlZmVyZW5jZS9HbG9iYWxfT2JqZWN0cy9TdHJpbmcvZW5kc1dpdGhcbmZ1bmN0aW9uIGVuZHNXaXRoKHN0ciwgc2VhcmNoLCB0aGlzX2xlbikge1xuXHRpZiAodGhpc19sZW4gPT09IHVuZGVmaW5lZCB8fCB0aGlzX2xlbiA+IHN0ci5sZW5ndGgpIHtcblx0XHR0aGlzX2xlbiA9IHN0ci5sZW5ndGg7XG5cdH1cblx0cmV0dXJuIHN0ci5zdWJzdHJpbmcodGhpc19sZW4gLSBzZWFyY2gubGVuZ3RoLCB0aGlzX2xlbikgPT09IHNlYXJjaDtcbn1cblxuLy8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvSmF2YVNjcmlwdC9SZWZlcmVuY2UvR2xvYmFsX09iamVjdHMvU3RyaW5nL2luY2x1ZGVzXG5mdW5jdGlvbiBpbmNsdWRlcyhzdHIsIHNlYXJjaCwgc3RhcnQpIHtcbiAgaWYgKHR5cGVvZiBzdGFydCAhPT0gJ251bWJlcicpIHtcbiAgICBzdGFydCA9IDA7XG4gIH1cblxuICBpZiAoc3RhcnQgKyBzZWFyY2gubGVuZ3RoID4gc3RyLmxlbmd0aCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gc3RyLmluZGV4T2Yoc2VhcmNoLCBzdGFydCkgIT09IC0xO1xuICB9XG59XG5cbmNyZWF0ZUVycm9yVHlwZSgnRVJSX0lOVkFMSURfT1BUX1ZBTFVFJywgZnVuY3Rpb24gKG5hbWUsIHZhbHVlKSB7XG4gIHJldHVybiAnVGhlIHZhbHVlIFwiJyArIHZhbHVlICsgJ1wiIGlzIGludmFsaWQgZm9yIG9wdGlvbiBcIicgKyBuYW1lICsgJ1wiJ1xufSwgVHlwZUVycm9yKTtcbmNyZWF0ZUVycm9yVHlwZSgnRVJSX0lOVkFMSURfQVJHX1RZUEUnLCBmdW5jdGlvbiAobmFtZSwgZXhwZWN0ZWQsIGFjdHVhbCkge1xuICAvLyBkZXRlcm1pbmVyOiAnbXVzdCBiZScgb3IgJ211c3Qgbm90IGJlJ1xuICBsZXQgZGV0ZXJtaW5lcjtcbiAgaWYgKHR5cGVvZiBleHBlY3RlZCA9PT0gJ3N0cmluZycgJiYgc3RhcnRzV2l0aChleHBlY3RlZCwgJ25vdCAnKSkge1xuICAgIGRldGVybWluZXIgPSAnbXVzdCBub3QgYmUnO1xuICAgIGV4cGVjdGVkID0gZXhwZWN0ZWQucmVwbGFjZSgvXm5vdCAvLCAnJyk7XG4gIH0gZWxzZSB7XG4gICAgZGV0ZXJtaW5lciA9ICdtdXN0IGJlJztcbiAgfVxuXG4gIGxldCBtc2c7XG4gIGlmIChlbmRzV2l0aChuYW1lLCAnIGFyZ3VtZW50JykpIHtcbiAgICAvLyBGb3IgY2FzZXMgbGlrZSAnZmlyc3QgYXJndW1lbnQnXG4gICAgbXNnID0gYFRoZSAke25hbWV9ICR7ZGV0ZXJtaW5lcn0gJHtvbmVPZihleHBlY3RlZCwgJ3R5cGUnKX1gO1xuICB9IGVsc2Uge1xuICAgIGNvbnN0IHR5cGUgPSBpbmNsdWRlcyhuYW1lLCAnLicpID8gJ3Byb3BlcnR5JyA6ICdhcmd1bWVudCc7XG4gICAgbXNnID0gYFRoZSBcIiR7bmFtZX1cIiAke3R5cGV9ICR7ZGV0ZXJtaW5lcn0gJHtvbmVPZihleHBlY3RlZCwgJ3R5cGUnKX1gO1xuICB9XG5cbiAgbXNnICs9IGAuIFJlY2VpdmVkIHR5cGUgJHt0eXBlb2YgYWN0dWFsfWA7XG4gIHJldHVybiBtc2c7XG59LCBUeXBlRXJyb3IpO1xuY3JlYXRlRXJyb3JUeXBlKCdFUlJfU1RSRUFNX1BVU0hfQUZURVJfRU9GJywgJ3N0cmVhbS5wdXNoKCkgYWZ0ZXIgRU9GJyk7XG5jcmVhdGVFcnJvclR5cGUoJ0VSUl9NRVRIT0RfTk9UX0lNUExFTUVOVEVEJywgZnVuY3Rpb24gKG5hbWUpIHtcbiAgcmV0dXJuICdUaGUgJyArIG5hbWUgKyAnIG1ldGhvZCBpcyBub3QgaW1wbGVtZW50ZWQnXG59KTtcbmNyZWF0ZUVycm9yVHlwZSgnRVJSX1NUUkVBTV9QUkVNQVRVUkVfQ0xPU0UnLCAnUHJlbWF0dXJlIGNsb3NlJyk7XG5jcmVhdGVFcnJvclR5cGUoJ0VSUl9TVFJFQU1fREVTVFJPWUVEJywgZnVuY3Rpb24gKG5hbWUpIHtcbiAgcmV0dXJuICdDYW5ub3QgY2FsbCAnICsgbmFtZSArICcgYWZ0ZXIgYSBzdHJlYW0gd2FzIGRlc3Ryb3llZCc7XG59KTtcbmNyZWF0ZUVycm9yVHlwZSgnRVJSX01VTFRJUExFX0NBTExCQUNLJywgJ0NhbGxiYWNrIGNhbGxlZCBtdWx0aXBsZSB0aW1lcycpO1xuY3JlYXRlRXJyb3JUeXBlKCdFUlJfU1RSRUFNX0NBTk5PVF9QSVBFJywgJ0Nhbm5vdCBwaXBlLCBub3QgcmVhZGFibGUnKTtcbmNyZWF0ZUVycm9yVHlwZSgnRVJSX1NUUkVBTV9XUklURV9BRlRFUl9FTkQnLCAnd3JpdGUgYWZ0ZXIgZW5kJyk7XG5jcmVhdGVFcnJvclR5cGUoJ0VSUl9TVFJFQU1fTlVMTF9WQUxVRVMnLCAnTWF5IG5vdCB3cml0ZSBudWxsIHZhbHVlcyB0byBzdHJlYW0nLCBUeXBlRXJyb3IpO1xuY3JlYXRlRXJyb3JUeXBlKCdFUlJfVU5LTk9XTl9FTkNPRElORycsIGZ1bmN0aW9uIChhcmcpIHtcbiAgcmV0dXJuICdVbmtub3duIGVuY29kaW5nOiAnICsgYXJnXG59LCBUeXBlRXJyb3IpO1xuY3JlYXRlRXJyb3JUeXBlKCdFUlJfU1RSRUFNX1VOU0hJRlRfQUZURVJfRU5EX0VWRU5UJywgJ3N0cmVhbS51bnNoaWZ0KCkgYWZ0ZXIgZW5kIGV2ZW50Jyk7XG5cbm1vZHVsZS5leHBvcnRzLmNvZGVzID0gY29kZXM7XG4iLCIvLyBDb3B5cmlnaHQgSm95ZW50LCBJbmMuIGFuZCBvdGhlciBOb2RlIGNvbnRyaWJ1dG9ycy5cbi8vXG4vLyBQZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYVxuLy8gY29weSBvZiB0aGlzIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZVxuLy8gXCJTb2Z0d2FyZVwiKSwgdG8gZGVhbCBpbiB0aGUgU29mdHdhcmUgd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nXG4vLyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsXG4vLyBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0XG4vLyBwZXJzb25zIHRvIHdob20gdGhlIFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0byB0aGVcbi8vIGZvbGxvd2luZyBjb25kaXRpb25zOlxuLy9cbi8vIFRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIHNoYWxsIGJlIGluY2x1ZGVkXG4vLyBpbiBhbGwgY29waWVzIG9yIHN1YnN0YW50aWFsIHBvcnRpb25zIG9mIHRoZSBTb2Z0d2FyZS5cbi8vXG4vLyBUSEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTXG4vLyBPUiBJTVBMSUVELCBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GXG4vLyBNRVJDSEFOVEFCSUxJVFksIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuIElOXG4vLyBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFQgSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSxcbi8vIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSIElOIEFOIEFDVElPTiBPRiBDT05UUkFDVCwgVE9SVCBPUlxuLy8gT1RIRVJXSVNFLCBBUklTSU5HIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFIFNPRlRXQVJFIE9SIFRIRVxuLy8gVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cbi8vIGEgZHVwbGV4IHN0cmVhbSBpcyBqdXN0IGEgc3RyZWFtIHRoYXQgaXMgYm90aCByZWFkYWJsZSBhbmQgd3JpdGFibGUuXG4vLyBTaW5jZSBKUyBkb2Vzbid0IGhhdmUgbXVsdGlwbGUgcHJvdG90eXBhbCBpbmhlcml0YW5jZSwgdGhpcyBjbGFzc1xuLy8gcHJvdG90eXBhbGx5IGluaGVyaXRzIGZyb20gUmVhZGFibGUsIGFuZCB0aGVuIHBhcmFzaXRpY2FsbHkgZnJvbVxuLy8gV3JpdGFibGUuXG4ndXNlIHN0cmljdCc7XG4vKjxyZXBsYWNlbWVudD4qL1xuXG52YXIgb2JqZWN0S2V5cyA9IE9iamVjdC5rZXlzIHx8IGZ1bmN0aW9uIChvYmopIHtcbiAgdmFyIGtleXMgPSBbXTtcblxuICBmb3IgKHZhciBrZXkgaW4gb2JqKSB7XG4gICAga2V5cy5wdXNoKGtleSk7XG4gIH1cblxuICByZXR1cm4ga2V5cztcbn07XG4vKjwvcmVwbGFjZW1lbnQ+Ki9cblxuXG5tb2R1bGUuZXhwb3J0cyA9IER1cGxleDtcblxudmFyIFJlYWRhYmxlID0gcmVxdWlyZSgnLi9fc3RyZWFtX3JlYWRhYmxlJyk7XG5cbnZhciBXcml0YWJsZSA9IHJlcXVpcmUoJy4vX3N0cmVhbV93cml0YWJsZScpO1xuXG5yZXF1aXJlKCdpbmhlcml0cycpKER1cGxleCwgUmVhZGFibGUpO1xuXG57XG4gIC8vIEFsbG93IHRoZSBrZXlzIGFycmF5IHRvIGJlIEdDJ2VkLlxuICB2YXIga2V5cyA9IG9iamVjdEtleXMoV3JpdGFibGUucHJvdG90eXBlKTtcblxuICBmb3IgKHZhciB2ID0gMDsgdiA8IGtleXMubGVuZ3RoOyB2KyspIHtcbiAgICB2YXIgbWV0aG9kID0ga2V5c1t2XTtcbiAgICBpZiAoIUR1cGxleC5wcm90b3R5cGVbbWV0aG9kXSkgRHVwbGV4LnByb3RvdHlwZVttZXRob2RdID0gV3JpdGFibGUucHJvdG90eXBlW21ldGhvZF07XG4gIH1cbn1cblxuZnVuY3Rpb24gRHVwbGV4KG9wdGlvbnMpIHtcbiAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIER1cGxleCkpIHJldHVybiBuZXcgRHVwbGV4KG9wdGlvbnMpO1xuICBSZWFkYWJsZS5jYWxsKHRoaXMsIG9wdGlvbnMpO1xuICBXcml0YWJsZS5jYWxsKHRoaXMsIG9wdGlvbnMpO1xuICB0aGlzLmFsbG93SGFsZk9wZW4gPSB0cnVlO1xuXG4gIGlmIChvcHRpb25zKSB7XG4gICAgaWYgKG9wdGlvbnMucmVhZGFibGUgPT09IGZhbHNlKSB0aGlzLnJlYWRhYmxlID0gZmFsc2U7XG4gICAgaWYgKG9wdGlvbnMud3JpdGFibGUgPT09IGZhbHNlKSB0aGlzLndyaXRhYmxlID0gZmFsc2U7XG5cbiAgICBpZiAob3B0aW9ucy5hbGxvd0hhbGZPcGVuID09PSBmYWxzZSkge1xuICAgICAgdGhpcy5hbGxvd0hhbGZPcGVuID0gZmFsc2U7XG4gICAgICB0aGlzLm9uY2UoJ2VuZCcsIG9uZW5kKTtcbiAgICB9XG4gIH1cbn1cblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KER1cGxleC5wcm90b3R5cGUsICd3cml0YWJsZUhpZ2hXYXRlck1hcmsnLCB7XG4gIC8vIG1ha2luZyBpdCBleHBsaWNpdCB0aGlzIHByb3BlcnR5IGlzIG5vdCBlbnVtZXJhYmxlXG4gIC8vIGJlY2F1c2Ugb3RoZXJ3aXNlIHNvbWUgcHJvdG90eXBlIG1hbmlwdWxhdGlvbiBpblxuICAvLyB1c2VybGFuZCB3aWxsIGZhaWxcbiAgZW51bWVyYWJsZTogZmFsc2UsXG4gIGdldDogZnVuY3Rpb24gZ2V0KCkge1xuICAgIHJldHVybiB0aGlzLl93cml0YWJsZVN0YXRlLmhpZ2hXYXRlck1hcms7XG4gIH1cbn0pO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KER1cGxleC5wcm90b3R5cGUsICd3cml0YWJsZUJ1ZmZlcicsIHtcbiAgLy8gbWFraW5nIGl0IGV4cGxpY2l0IHRoaXMgcHJvcGVydHkgaXMgbm90IGVudW1lcmFibGVcbiAgLy8gYmVjYXVzZSBvdGhlcndpc2Ugc29tZSBwcm90b3R5cGUgbWFuaXB1bGF0aW9uIGluXG4gIC8vIHVzZXJsYW5kIHdpbGwgZmFpbFxuICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgZ2V0OiBmdW5jdGlvbiBnZXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3dyaXRhYmxlU3RhdGUgJiYgdGhpcy5fd3JpdGFibGVTdGF0ZS5nZXRCdWZmZXIoKTtcbiAgfVxufSk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoRHVwbGV4LnByb3RvdHlwZSwgJ3dyaXRhYmxlTGVuZ3RoJywge1xuICAvLyBtYWtpbmcgaXQgZXhwbGljaXQgdGhpcyBwcm9wZXJ0eSBpcyBub3QgZW51bWVyYWJsZVxuICAvLyBiZWNhdXNlIG90aGVyd2lzZSBzb21lIHByb3RvdHlwZSBtYW5pcHVsYXRpb24gaW5cbiAgLy8gdXNlcmxhbmQgd2lsbCBmYWlsXG4gIGVudW1lcmFibGU6IGZhbHNlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICByZXR1cm4gdGhpcy5fd3JpdGFibGVTdGF0ZS5sZW5ndGg7XG4gIH1cbn0pOyAvLyB0aGUgbm8taGFsZi1vcGVuIGVuZm9yY2VyXG5cbmZ1bmN0aW9uIG9uZW5kKCkge1xuICAvLyBJZiB0aGUgd3JpdGFibGUgc2lkZSBlbmRlZCwgdGhlbiB3ZSdyZSBvay5cbiAgaWYgKHRoaXMuX3dyaXRhYmxlU3RhdGUuZW5kZWQpIHJldHVybjsgLy8gbm8gbW9yZSBkYXRhIGNhbiBiZSB3cml0dGVuLlxuICAvLyBCdXQgYWxsb3cgbW9yZSB3cml0ZXMgdG8gaGFwcGVuIGluIHRoaXMgdGljay5cblxuICBwcm9jZXNzLm5leHRUaWNrKG9uRW5kTlQsIHRoaXMpO1xufVxuXG5mdW5jdGlvbiBvbkVuZE5UKHNlbGYpIHtcbiAgc2VsZi5lbmQoKTtcbn1cblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KER1cGxleC5wcm90b3R5cGUsICdkZXN0cm95ZWQnLCB7XG4gIC8vIG1ha2luZyBpdCBleHBsaWNpdCB0aGlzIHByb3BlcnR5IGlzIG5vdCBlbnVtZXJhYmxlXG4gIC8vIGJlY2F1c2Ugb3RoZXJ3aXNlIHNvbWUgcHJvdG90eXBlIG1hbmlwdWxhdGlvbiBpblxuICAvLyB1c2VybGFuZCB3aWxsIGZhaWxcbiAgZW51bWVyYWJsZTogZmFsc2UsXG4gIGdldDogZnVuY3Rpb24gZ2V0KCkge1xuICAgIGlmICh0aGlzLl9yZWFkYWJsZVN0YXRlID09PSB1bmRlZmluZWQgfHwgdGhpcy5fd3JpdGFibGVTdGF0ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuX3JlYWRhYmxlU3RhdGUuZGVzdHJveWVkICYmIHRoaXMuX3dyaXRhYmxlU3RhdGUuZGVzdHJveWVkO1xuICB9LFxuICBzZXQ6IGZ1bmN0aW9uIHNldCh2YWx1ZSkge1xuICAgIC8vIHdlIGlnbm9yZSB0aGUgdmFsdWUgaWYgdGhlIHN0cmVhbVxuICAgIC8vIGhhcyBub3QgYmVlbiBpbml0aWFsaXplZCB5ZXRcbiAgICBpZiAodGhpcy5fcmVhZGFibGVTdGF0ZSA9PT0gdW5kZWZpbmVkIHx8IHRoaXMuX3dyaXRhYmxlU3RhdGUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH0gLy8gYmFja3dhcmQgY29tcGF0aWJpbGl0eSwgdGhlIHVzZXIgaXMgZXhwbGljaXRseVxuICAgIC8vIG1hbmFnaW5nIGRlc3Ryb3llZFxuXG5cbiAgICB0aGlzLl9yZWFkYWJsZVN0YXRlLmRlc3Ryb3llZCA9IHZhbHVlO1xuICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUuZGVzdHJveWVkID0gdmFsdWU7XG4gIH1cbn0pOyIsIi8vIENvcHlyaWdodCBKb3llbnQsIEluYy4gYW5kIG90aGVyIE5vZGUgY29udHJpYnV0b3JzLlxuLy9cbi8vIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhXG4vLyBjb3B5IG9mIHRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlXG4vLyBcIlNvZnR3YXJlXCIpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZSB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmdcbi8vIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBtZXJnZSwgcHVibGlzaCxcbi8vIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0byBwZXJtaXRcbi8vIHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLCBzdWJqZWN0IHRvIHRoZVxuLy8gZm9sbG93aW5nIGNvbmRpdGlvbnM6XG4vL1xuLy8gVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWRcbi8vIGluIGFsbCBjb3BpZXMgb3Igc3Vic3RhbnRpYWwgcG9ydGlvbnMgb2YgdGhlIFNvZnR3YXJlLlxuLy9cbi8vIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIsIFdJVEhPVVQgV0FSUkFOVFkgT0YgQU5ZIEtJTkQsIEVYUFJFU1Ncbi8vIE9SIElNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0Zcbi8vIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EIE5PTklORlJJTkdFTUVOVC4gSU5cbi8vIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1JTIE9SIENPUFlSSUdIVCBIT0xERVJTIEJFIExJQUJMRSBGT1IgQU5ZIENMQUlNLFxuLy8gREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULCBUT1JUIE9SXG4vLyBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT04gV0lUSCBUSEUgU09GVFdBUkUgT1IgVEhFXG4vLyBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuLy8gYSBwYXNzdGhyb3VnaCBzdHJlYW0uXG4vLyBiYXNpY2FsbHkganVzdCB0aGUgbW9zdCBtaW5pbWFsIHNvcnQgb2YgVHJhbnNmb3JtIHN0cmVhbS5cbi8vIEV2ZXJ5IHdyaXR0ZW4gY2h1bmsgZ2V0cyBvdXRwdXQgYXMtaXMuXG4ndXNlIHN0cmljdCc7XG5cbm1vZHVsZS5leHBvcnRzID0gUGFzc1Rocm91Z2g7XG5cbnZhciBUcmFuc2Zvcm0gPSByZXF1aXJlKCcuL19zdHJlYW1fdHJhbnNmb3JtJyk7XG5cbnJlcXVpcmUoJ2luaGVyaXRzJykoUGFzc1Rocm91Z2gsIFRyYW5zZm9ybSk7XG5cbmZ1bmN0aW9uIFBhc3NUaHJvdWdoKG9wdGlvbnMpIHtcbiAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIFBhc3NUaHJvdWdoKSkgcmV0dXJuIG5ldyBQYXNzVGhyb3VnaChvcHRpb25zKTtcbiAgVHJhbnNmb3JtLmNhbGwodGhpcywgb3B0aW9ucyk7XG59XG5cblBhc3NUaHJvdWdoLnByb3RvdHlwZS5fdHJhbnNmb3JtID0gZnVuY3Rpb24gKGNodW5rLCBlbmNvZGluZywgY2IpIHtcbiAgY2IobnVsbCwgY2h1bmspO1xufTsiLCIvLyBDb3B5cmlnaHQgSm95ZW50LCBJbmMuIGFuZCBvdGhlciBOb2RlIGNvbnRyaWJ1dG9ycy5cbi8vXG4vLyBQZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYVxuLy8gY29weSBvZiB0aGlzIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZVxuLy8gXCJTb2Z0d2FyZVwiKSwgdG8gZGVhbCBpbiB0aGUgU29mdHdhcmUgd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nXG4vLyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsXG4vLyBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0XG4vLyBwZXJzb25zIHRvIHdob20gdGhlIFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0byB0aGVcbi8vIGZvbGxvd2luZyBjb25kaXRpb25zOlxuLy9cbi8vIFRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIHNoYWxsIGJlIGluY2x1ZGVkXG4vLyBpbiBhbGwgY29waWVzIG9yIHN1YnN0YW50aWFsIHBvcnRpb25zIG9mIHRoZSBTb2Z0d2FyZS5cbi8vXG4vLyBUSEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTXG4vLyBPUiBJTVBMSUVELCBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GXG4vLyBNRVJDSEFOVEFCSUxJVFksIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuIElOXG4vLyBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFQgSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSxcbi8vIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSIElOIEFOIEFDVElPTiBPRiBDT05UUkFDVCwgVE9SVCBPUlxuLy8gT1RIRVJXSVNFLCBBUklTSU5HIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFIFNPRlRXQVJFIE9SIFRIRVxuLy8gVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cbid1c2Ugc3RyaWN0JztcblxubW9kdWxlLmV4cG9ydHMgPSBSZWFkYWJsZTtcbi8qPHJlcGxhY2VtZW50PiovXG5cbnZhciBEdXBsZXg7XG4vKjwvcmVwbGFjZW1lbnQ+Ki9cblxuUmVhZGFibGUuUmVhZGFibGVTdGF0ZSA9IFJlYWRhYmxlU3RhdGU7XG4vKjxyZXBsYWNlbWVudD4qL1xuXG52YXIgRUUgPSByZXF1aXJlKCdldmVudHMnKS5FdmVudEVtaXR0ZXI7XG5cbnZhciBFRWxpc3RlbmVyQ291bnQgPSBmdW5jdGlvbiBFRWxpc3RlbmVyQ291bnQoZW1pdHRlciwgdHlwZSkge1xuICByZXR1cm4gZW1pdHRlci5saXN0ZW5lcnModHlwZSkubGVuZ3RoO1xufTtcbi8qPC9yZXBsYWNlbWVudD4qL1xuXG4vKjxyZXBsYWNlbWVudD4qL1xuXG5cbnZhciBTdHJlYW0gPSByZXF1aXJlKCcuL2ludGVybmFsL3N0cmVhbXMvc3RyZWFtJyk7XG4vKjwvcmVwbGFjZW1lbnQ+Ki9cblxuXG52YXIgQnVmZmVyID0gcmVxdWlyZSgnYnVmZmVyJykuQnVmZmVyO1xuXG52YXIgT3VyVWludDhBcnJheSA9IGdsb2JhbC5VaW50OEFycmF5IHx8IGZ1bmN0aW9uICgpIHt9O1xuXG5mdW5jdGlvbiBfdWludDhBcnJheVRvQnVmZmVyKGNodW5rKSB7XG4gIHJldHVybiBCdWZmZXIuZnJvbShjaHVuayk7XG59XG5cbmZ1bmN0aW9uIF9pc1VpbnQ4QXJyYXkob2JqKSB7XG4gIHJldHVybiBCdWZmZXIuaXNCdWZmZXIob2JqKSB8fCBvYmogaW5zdGFuY2VvZiBPdXJVaW50OEFycmF5O1xufVxuLyo8cmVwbGFjZW1lbnQ+Ki9cblxuXG52YXIgZGVidWdVdGlsID0gcmVxdWlyZSgndXRpbCcpO1xuXG52YXIgZGVidWc7XG5cbmlmIChkZWJ1Z1V0aWwgJiYgZGVidWdVdGlsLmRlYnVnbG9nKSB7XG4gIGRlYnVnID0gZGVidWdVdGlsLmRlYnVnbG9nKCdzdHJlYW0nKTtcbn0gZWxzZSB7XG4gIGRlYnVnID0gZnVuY3Rpb24gZGVidWcoKSB7fTtcbn1cbi8qPC9yZXBsYWNlbWVudD4qL1xuXG5cbnZhciBCdWZmZXJMaXN0ID0gcmVxdWlyZSgnLi9pbnRlcm5hbC9zdHJlYW1zL2J1ZmZlcl9saXN0Jyk7XG5cbnZhciBkZXN0cm95SW1wbCA9IHJlcXVpcmUoJy4vaW50ZXJuYWwvc3RyZWFtcy9kZXN0cm95Jyk7XG5cbnZhciBfcmVxdWlyZSA9IHJlcXVpcmUoJy4vaW50ZXJuYWwvc3RyZWFtcy9zdGF0ZScpLFxuICAgIGdldEhpZ2hXYXRlck1hcmsgPSBfcmVxdWlyZS5nZXRIaWdoV2F0ZXJNYXJrO1xuXG52YXIgX3JlcXVpcmUkY29kZXMgPSByZXF1aXJlKCcuLi9lcnJvcnMnKS5jb2RlcyxcbiAgICBFUlJfSU5WQUxJRF9BUkdfVFlQRSA9IF9yZXF1aXJlJGNvZGVzLkVSUl9JTlZBTElEX0FSR19UWVBFLFxuICAgIEVSUl9TVFJFQU1fUFVTSF9BRlRFUl9FT0YgPSBfcmVxdWlyZSRjb2Rlcy5FUlJfU1RSRUFNX1BVU0hfQUZURVJfRU9GLFxuICAgIEVSUl9NRVRIT0RfTk9UX0lNUExFTUVOVEVEID0gX3JlcXVpcmUkY29kZXMuRVJSX01FVEhPRF9OT1RfSU1QTEVNRU5URUQsXG4gICAgRVJSX1NUUkVBTV9VTlNISUZUX0FGVEVSX0VORF9FVkVOVCA9IF9yZXF1aXJlJGNvZGVzLkVSUl9TVFJFQU1fVU5TSElGVF9BRlRFUl9FTkRfRVZFTlQ7IC8vIExhenkgbG9hZGVkIHRvIGltcHJvdmUgdGhlIHN0YXJ0dXAgcGVyZm9ybWFuY2UuXG5cblxudmFyIFN0cmluZ0RlY29kZXI7XG52YXIgY3JlYXRlUmVhZGFibGVTdHJlYW1Bc3luY0l0ZXJhdG9yO1xudmFyIGZyb207XG5cbnJlcXVpcmUoJ2luaGVyaXRzJykoUmVhZGFibGUsIFN0cmVhbSk7XG5cbnZhciBlcnJvck9yRGVzdHJveSA9IGRlc3Ryb3lJbXBsLmVycm9yT3JEZXN0cm95O1xudmFyIGtQcm94eUV2ZW50cyA9IFsnZXJyb3InLCAnY2xvc2UnLCAnZGVzdHJveScsICdwYXVzZScsICdyZXN1bWUnXTtcblxuZnVuY3Rpb24gcHJlcGVuZExpc3RlbmVyKGVtaXR0ZXIsIGV2ZW50LCBmbikge1xuICAvLyBTYWRseSB0aGlzIGlzIG5vdCBjYWNoZWFibGUgYXMgc29tZSBsaWJyYXJpZXMgYnVuZGxlIHRoZWlyIG93blxuICAvLyBldmVudCBlbWl0dGVyIGltcGxlbWVudGF0aW9uIHdpdGggdGhlbS5cbiAgaWYgKHR5cGVvZiBlbWl0dGVyLnByZXBlbmRMaXN0ZW5lciA9PT0gJ2Z1bmN0aW9uJykgcmV0dXJuIGVtaXR0ZXIucHJlcGVuZExpc3RlbmVyKGV2ZW50LCBmbik7IC8vIFRoaXMgaXMgYSBoYWNrIHRvIG1ha2Ugc3VyZSB0aGF0IG91ciBlcnJvciBoYW5kbGVyIGlzIGF0dGFjaGVkIGJlZm9yZSBhbnlcbiAgLy8gdXNlcmxhbmQgb25lcy4gIE5FVkVSIERPIFRISVMuIFRoaXMgaXMgaGVyZSBvbmx5IGJlY2F1c2UgdGhpcyBjb2RlIG5lZWRzXG4gIC8vIHRvIGNvbnRpbnVlIHRvIHdvcmsgd2l0aCBvbGRlciB2ZXJzaW9ucyBvZiBOb2RlLmpzIHRoYXQgZG8gbm90IGluY2x1ZGVcbiAgLy8gdGhlIHByZXBlbmRMaXN0ZW5lcigpIG1ldGhvZC4gVGhlIGdvYWwgaXMgdG8gZXZlbnR1YWxseSByZW1vdmUgdGhpcyBoYWNrLlxuXG4gIGlmICghZW1pdHRlci5fZXZlbnRzIHx8ICFlbWl0dGVyLl9ldmVudHNbZXZlbnRdKSBlbWl0dGVyLm9uKGV2ZW50LCBmbik7ZWxzZSBpZiAoQXJyYXkuaXNBcnJheShlbWl0dGVyLl9ldmVudHNbZXZlbnRdKSkgZW1pdHRlci5fZXZlbnRzW2V2ZW50XS51bnNoaWZ0KGZuKTtlbHNlIGVtaXR0ZXIuX2V2ZW50c1tldmVudF0gPSBbZm4sIGVtaXR0ZXIuX2V2ZW50c1tldmVudF1dO1xufVxuXG5mdW5jdGlvbiBSZWFkYWJsZVN0YXRlKG9wdGlvbnMsIHN0cmVhbSwgaXNEdXBsZXgpIHtcbiAgRHVwbGV4ID0gRHVwbGV4IHx8IHJlcXVpcmUoJy4vX3N0cmVhbV9kdXBsZXgnKTtcbiAgb3B0aW9ucyA9IG9wdGlvbnMgfHwge307IC8vIER1cGxleCBzdHJlYW1zIGFyZSBib3RoIHJlYWRhYmxlIGFuZCB3cml0YWJsZSwgYnV0IHNoYXJlXG4gIC8vIHRoZSBzYW1lIG9wdGlvbnMgb2JqZWN0LlxuICAvLyBIb3dldmVyLCBzb21lIGNhc2VzIHJlcXVpcmUgc2V0dGluZyBvcHRpb25zIHRvIGRpZmZlcmVudFxuICAvLyB2YWx1ZXMgZm9yIHRoZSByZWFkYWJsZSBhbmQgdGhlIHdyaXRhYmxlIHNpZGVzIG9mIHRoZSBkdXBsZXggc3RyZWFtLlxuICAvLyBUaGVzZSBvcHRpb25zIGNhbiBiZSBwcm92aWRlZCBzZXBhcmF0ZWx5IGFzIHJlYWRhYmxlWFhYIGFuZCB3cml0YWJsZVhYWC5cblxuICBpZiAodHlwZW9mIGlzRHVwbGV4ICE9PSAnYm9vbGVhbicpIGlzRHVwbGV4ID0gc3RyZWFtIGluc3RhbmNlb2YgRHVwbGV4OyAvLyBvYmplY3Qgc3RyZWFtIGZsYWcuIFVzZWQgdG8gbWFrZSByZWFkKG4pIGlnbm9yZSBuIGFuZCB0b1xuICAvLyBtYWtlIGFsbCB0aGUgYnVmZmVyIG1lcmdpbmcgYW5kIGxlbmd0aCBjaGVja3MgZ28gYXdheVxuXG4gIHRoaXMub2JqZWN0TW9kZSA9ICEhb3B0aW9ucy5vYmplY3RNb2RlO1xuICBpZiAoaXNEdXBsZXgpIHRoaXMub2JqZWN0TW9kZSA9IHRoaXMub2JqZWN0TW9kZSB8fCAhIW9wdGlvbnMucmVhZGFibGVPYmplY3RNb2RlOyAvLyB0aGUgcG9pbnQgYXQgd2hpY2ggaXQgc3RvcHMgY2FsbGluZyBfcmVhZCgpIHRvIGZpbGwgdGhlIGJ1ZmZlclxuICAvLyBOb3RlOiAwIGlzIGEgdmFsaWQgdmFsdWUsIG1lYW5zIFwiZG9uJ3QgY2FsbCBfcmVhZCBwcmVlbXB0aXZlbHkgZXZlclwiXG5cbiAgdGhpcy5oaWdoV2F0ZXJNYXJrID0gZ2V0SGlnaFdhdGVyTWFyayh0aGlzLCBvcHRpb25zLCAncmVhZGFibGVIaWdoV2F0ZXJNYXJrJywgaXNEdXBsZXgpOyAvLyBBIGxpbmtlZCBsaXN0IGlzIHVzZWQgdG8gc3RvcmUgZGF0YSBjaHVua3MgaW5zdGVhZCBvZiBhbiBhcnJheSBiZWNhdXNlIHRoZVxuICAvLyBsaW5rZWQgbGlzdCBjYW4gcmVtb3ZlIGVsZW1lbnRzIGZyb20gdGhlIGJlZ2lubmluZyBmYXN0ZXIgdGhhblxuICAvLyBhcnJheS5zaGlmdCgpXG5cbiAgdGhpcy5idWZmZXIgPSBuZXcgQnVmZmVyTGlzdCgpO1xuICB0aGlzLmxlbmd0aCA9IDA7XG4gIHRoaXMucGlwZXMgPSBudWxsO1xuICB0aGlzLnBpcGVzQ291bnQgPSAwO1xuICB0aGlzLmZsb3dpbmcgPSBudWxsO1xuICB0aGlzLmVuZGVkID0gZmFsc2U7XG4gIHRoaXMuZW5kRW1pdHRlZCA9IGZhbHNlO1xuICB0aGlzLnJlYWRpbmcgPSBmYWxzZTsgLy8gYSBmbGFnIHRvIGJlIGFibGUgdG8gdGVsbCBpZiB0aGUgZXZlbnQgJ3JlYWRhYmxlJy8nZGF0YScgaXMgZW1pdHRlZFxuICAvLyBpbW1lZGlhdGVseSwgb3Igb24gYSBsYXRlciB0aWNrLiAgV2Ugc2V0IHRoaXMgdG8gdHJ1ZSBhdCBmaXJzdCwgYmVjYXVzZVxuICAvLyBhbnkgYWN0aW9ucyB0aGF0IHNob3VsZG4ndCBoYXBwZW4gdW50aWwgXCJsYXRlclwiIHNob3VsZCBnZW5lcmFsbHkgYWxzb1xuICAvLyBub3QgaGFwcGVuIGJlZm9yZSB0aGUgZmlyc3QgcmVhZCBjYWxsLlxuXG4gIHRoaXMuc3luYyA9IHRydWU7IC8vIHdoZW5ldmVyIHdlIHJldHVybiBudWxsLCB0aGVuIHdlIHNldCBhIGZsYWcgdG8gc2F5XG4gIC8vIHRoYXQgd2UncmUgYXdhaXRpbmcgYSAncmVhZGFibGUnIGV2ZW50IGVtaXNzaW9uLlxuXG4gIHRoaXMubmVlZFJlYWRhYmxlID0gZmFsc2U7XG4gIHRoaXMuZW1pdHRlZFJlYWRhYmxlID0gZmFsc2U7XG4gIHRoaXMucmVhZGFibGVMaXN0ZW5pbmcgPSBmYWxzZTtcbiAgdGhpcy5yZXN1bWVTY2hlZHVsZWQgPSBmYWxzZTtcbiAgdGhpcy5wYXVzZWQgPSB0cnVlOyAvLyBTaG91bGQgY2xvc2UgYmUgZW1pdHRlZCBvbiBkZXN0cm95LiBEZWZhdWx0cyB0byB0cnVlLlxuXG4gIHRoaXMuZW1pdENsb3NlID0gb3B0aW9ucy5lbWl0Q2xvc2UgIT09IGZhbHNlOyAvLyBTaG91bGQgLmRlc3Ryb3koKSBiZSBjYWxsZWQgYWZ0ZXIgJ2VuZCcgKGFuZCBwb3RlbnRpYWxseSAnZmluaXNoJylcblxuICB0aGlzLmF1dG9EZXN0cm95ID0gISFvcHRpb25zLmF1dG9EZXN0cm95OyAvLyBoYXMgaXQgYmVlbiBkZXN0cm95ZWRcblxuICB0aGlzLmRlc3Ryb3llZCA9IGZhbHNlOyAvLyBDcnlwdG8gaXMga2luZCBvZiBvbGQgYW5kIGNydXN0eS4gIEhpc3RvcmljYWxseSwgaXRzIGRlZmF1bHQgc3RyaW5nXG4gIC8vIGVuY29kaW5nIGlzICdiaW5hcnknIHNvIHdlIGhhdmUgdG8gbWFrZSB0aGlzIGNvbmZpZ3VyYWJsZS5cbiAgLy8gRXZlcnl0aGluZyBlbHNlIGluIHRoZSB1bml2ZXJzZSB1c2VzICd1dGY4JywgdGhvdWdoLlxuXG4gIHRoaXMuZGVmYXVsdEVuY29kaW5nID0gb3B0aW9ucy5kZWZhdWx0RW5jb2RpbmcgfHwgJ3V0ZjgnOyAvLyB0aGUgbnVtYmVyIG9mIHdyaXRlcnMgdGhhdCBhcmUgYXdhaXRpbmcgYSBkcmFpbiBldmVudCBpbiAucGlwZSgpc1xuXG4gIHRoaXMuYXdhaXREcmFpbiA9IDA7IC8vIGlmIHRydWUsIGEgbWF5YmVSZWFkTW9yZSBoYXMgYmVlbiBzY2hlZHVsZWRcblxuICB0aGlzLnJlYWRpbmdNb3JlID0gZmFsc2U7XG4gIHRoaXMuZGVjb2RlciA9IG51bGw7XG4gIHRoaXMuZW5jb2RpbmcgPSBudWxsO1xuXG4gIGlmIChvcHRpb25zLmVuY29kaW5nKSB7XG4gICAgaWYgKCFTdHJpbmdEZWNvZGVyKSBTdHJpbmdEZWNvZGVyID0gcmVxdWlyZSgnc3RyaW5nX2RlY29kZXIvJykuU3RyaW5nRGVjb2RlcjtcbiAgICB0aGlzLmRlY29kZXIgPSBuZXcgU3RyaW5nRGVjb2RlcihvcHRpb25zLmVuY29kaW5nKTtcbiAgICB0aGlzLmVuY29kaW5nID0gb3B0aW9ucy5lbmNvZGluZztcbiAgfVxufVxuXG5mdW5jdGlvbiBSZWFkYWJsZShvcHRpb25zKSB7XG4gIER1cGxleCA9IER1cGxleCB8fCByZXF1aXJlKCcuL19zdHJlYW1fZHVwbGV4Jyk7XG4gIGlmICghKHRoaXMgaW5zdGFuY2VvZiBSZWFkYWJsZSkpIHJldHVybiBuZXcgUmVhZGFibGUob3B0aW9ucyk7IC8vIENoZWNraW5nIGZvciBhIFN0cmVhbS5EdXBsZXggaW5zdGFuY2UgaXMgZmFzdGVyIGhlcmUgaW5zdGVhZCBvZiBpbnNpZGVcbiAgLy8gdGhlIFJlYWRhYmxlU3RhdGUgY29uc3RydWN0b3IsIGF0IGxlYXN0IHdpdGggVjggNi41XG5cbiAgdmFyIGlzRHVwbGV4ID0gdGhpcyBpbnN0YW5jZW9mIER1cGxleDtcbiAgdGhpcy5fcmVhZGFibGVTdGF0ZSA9IG5ldyBSZWFkYWJsZVN0YXRlKG9wdGlvbnMsIHRoaXMsIGlzRHVwbGV4KTsgLy8gbGVnYWN5XG5cbiAgdGhpcy5yZWFkYWJsZSA9IHRydWU7XG5cbiAgaWYgKG9wdGlvbnMpIHtcbiAgICBpZiAodHlwZW9mIG9wdGlvbnMucmVhZCA9PT0gJ2Z1bmN0aW9uJykgdGhpcy5fcmVhZCA9IG9wdGlvbnMucmVhZDtcbiAgICBpZiAodHlwZW9mIG9wdGlvbnMuZGVzdHJveSA9PT0gJ2Z1bmN0aW9uJykgdGhpcy5fZGVzdHJveSA9IG9wdGlvbnMuZGVzdHJveTtcbiAgfVxuXG4gIFN0cmVhbS5jYWxsKHRoaXMpO1xufVxuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoUmVhZGFibGUucHJvdG90eXBlLCAnZGVzdHJveWVkJywge1xuICAvLyBtYWtpbmcgaXQgZXhwbGljaXQgdGhpcyBwcm9wZXJ0eSBpcyBub3QgZW51bWVyYWJsZVxuICAvLyBiZWNhdXNlIG90aGVyd2lzZSBzb21lIHByb3RvdHlwZSBtYW5pcHVsYXRpb24gaW5cbiAgLy8gdXNlcmxhbmQgd2lsbCBmYWlsXG4gIGVudW1lcmFibGU6IGZhbHNlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICBpZiAodGhpcy5fcmVhZGFibGVTdGF0ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuX3JlYWRhYmxlU3RhdGUuZGVzdHJveWVkO1xuICB9LFxuICBzZXQ6IGZ1bmN0aW9uIHNldCh2YWx1ZSkge1xuICAgIC8vIHdlIGlnbm9yZSB0aGUgdmFsdWUgaWYgdGhlIHN0cmVhbVxuICAgIC8vIGhhcyBub3QgYmVlbiBpbml0aWFsaXplZCB5ZXRcbiAgICBpZiAoIXRoaXMuX3JlYWRhYmxlU3RhdGUpIHtcbiAgICAgIHJldHVybjtcbiAgICB9IC8vIGJhY2t3YXJkIGNvbXBhdGliaWxpdHksIHRoZSB1c2VyIGlzIGV4cGxpY2l0bHlcbiAgICAvLyBtYW5hZ2luZyBkZXN0cm95ZWRcblxuXG4gICAgdGhpcy5fcmVhZGFibGVTdGF0ZS5kZXN0cm95ZWQgPSB2YWx1ZTtcbiAgfVxufSk7XG5SZWFkYWJsZS5wcm90b3R5cGUuZGVzdHJveSA9IGRlc3Ryb3lJbXBsLmRlc3Ryb3k7XG5SZWFkYWJsZS5wcm90b3R5cGUuX3VuZGVzdHJveSA9IGRlc3Ryb3lJbXBsLnVuZGVzdHJveTtcblxuUmVhZGFibGUucHJvdG90eXBlLl9kZXN0cm95ID0gZnVuY3Rpb24gKGVyciwgY2IpIHtcbiAgY2IoZXJyKTtcbn07IC8vIE1hbnVhbGx5IHNob3ZlIHNvbWV0aGluZyBpbnRvIHRoZSByZWFkKCkgYnVmZmVyLlxuLy8gVGhpcyByZXR1cm5zIHRydWUgaWYgdGhlIGhpZ2hXYXRlck1hcmsgaGFzIG5vdCBiZWVuIGhpdCB5ZXQsXG4vLyBzaW1pbGFyIHRvIGhvdyBXcml0YWJsZS53cml0ZSgpIHJldHVybnMgdHJ1ZSBpZiB5b3Ugc2hvdWxkXG4vLyB3cml0ZSgpIHNvbWUgbW9yZS5cblxuXG5SZWFkYWJsZS5wcm90b3R5cGUucHVzaCA9IGZ1bmN0aW9uIChjaHVuaywgZW5jb2RpbmcpIHtcbiAgdmFyIHN0YXRlID0gdGhpcy5fcmVhZGFibGVTdGF0ZTtcbiAgdmFyIHNraXBDaHVua0NoZWNrO1xuXG4gIGlmICghc3RhdGUub2JqZWN0TW9kZSkge1xuICAgIGlmICh0eXBlb2YgY2h1bmsgPT09ICdzdHJpbmcnKSB7XG4gICAgICBlbmNvZGluZyA9IGVuY29kaW5nIHx8IHN0YXRlLmRlZmF1bHRFbmNvZGluZztcblxuICAgICAgaWYgKGVuY29kaW5nICE9PSBzdGF0ZS5lbmNvZGluZykge1xuICAgICAgICBjaHVuayA9IEJ1ZmZlci5mcm9tKGNodW5rLCBlbmNvZGluZyk7XG4gICAgICAgIGVuY29kaW5nID0gJyc7XG4gICAgICB9XG5cbiAgICAgIHNraXBDaHVua0NoZWNrID0gdHJ1ZTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgc2tpcENodW5rQ2hlY2sgPSB0cnVlO1xuICB9XG5cbiAgcmV0dXJuIHJlYWRhYmxlQWRkQ2h1bmsodGhpcywgY2h1bmssIGVuY29kaW5nLCBmYWxzZSwgc2tpcENodW5rQ2hlY2spO1xufTsgLy8gVW5zaGlmdCBzaG91bGQgKmFsd2F5cyogYmUgc29tZXRoaW5nIGRpcmVjdGx5IG91dCBvZiByZWFkKClcblxuXG5SZWFkYWJsZS5wcm90b3R5cGUudW5zaGlmdCA9IGZ1bmN0aW9uIChjaHVuaykge1xuICByZXR1cm4gcmVhZGFibGVBZGRDaHVuayh0aGlzLCBjaHVuaywgbnVsbCwgdHJ1ZSwgZmFsc2UpO1xufTtcblxuZnVuY3Rpb24gcmVhZGFibGVBZGRDaHVuayhzdHJlYW0sIGNodW5rLCBlbmNvZGluZywgYWRkVG9Gcm9udCwgc2tpcENodW5rQ2hlY2spIHtcbiAgZGVidWcoJ3JlYWRhYmxlQWRkQ2h1bmsnLCBjaHVuayk7XG4gIHZhciBzdGF0ZSA9IHN0cmVhbS5fcmVhZGFibGVTdGF0ZTtcblxuICBpZiAoY2h1bmsgPT09IG51bGwpIHtcbiAgICBzdGF0ZS5yZWFkaW5nID0gZmFsc2U7XG4gICAgb25Fb2ZDaHVuayhzdHJlYW0sIHN0YXRlKTtcbiAgfSBlbHNlIHtcbiAgICB2YXIgZXI7XG4gICAgaWYgKCFza2lwQ2h1bmtDaGVjaykgZXIgPSBjaHVua0ludmFsaWQoc3RhdGUsIGNodW5rKTtcblxuICAgIGlmIChlcikge1xuICAgICAgZXJyb3JPckRlc3Ryb3koc3RyZWFtLCBlcik7XG4gICAgfSBlbHNlIGlmIChzdGF0ZS5vYmplY3RNb2RlIHx8IGNodW5rICYmIGNodW5rLmxlbmd0aCA+IDApIHtcbiAgICAgIGlmICh0eXBlb2YgY2h1bmsgIT09ICdzdHJpbmcnICYmICFzdGF0ZS5vYmplY3RNb2RlICYmIE9iamVjdC5nZXRQcm90b3R5cGVPZihjaHVuaykgIT09IEJ1ZmZlci5wcm90b3R5cGUpIHtcbiAgICAgICAgY2h1bmsgPSBfdWludDhBcnJheVRvQnVmZmVyKGNodW5rKTtcbiAgICAgIH1cblxuICAgICAgaWYgKGFkZFRvRnJvbnQpIHtcbiAgICAgICAgaWYgKHN0YXRlLmVuZEVtaXR0ZWQpIGVycm9yT3JEZXN0cm95KHN0cmVhbSwgbmV3IEVSUl9TVFJFQU1fVU5TSElGVF9BRlRFUl9FTkRfRVZFTlQoKSk7ZWxzZSBhZGRDaHVuayhzdHJlYW0sIHN0YXRlLCBjaHVuaywgdHJ1ZSk7XG4gICAgICB9IGVsc2UgaWYgKHN0YXRlLmVuZGVkKSB7XG4gICAgICAgIGVycm9yT3JEZXN0cm95KHN0cmVhbSwgbmV3IEVSUl9TVFJFQU1fUFVTSF9BRlRFUl9FT0YoKSk7XG4gICAgICB9IGVsc2UgaWYgKHN0YXRlLmRlc3Ryb3llZCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzdGF0ZS5yZWFkaW5nID0gZmFsc2U7XG5cbiAgICAgICAgaWYgKHN0YXRlLmRlY29kZXIgJiYgIWVuY29kaW5nKSB7XG4gICAgICAgICAgY2h1bmsgPSBzdGF0ZS5kZWNvZGVyLndyaXRlKGNodW5rKTtcbiAgICAgICAgICBpZiAoc3RhdGUub2JqZWN0TW9kZSB8fCBjaHVuay5sZW5ndGggIT09IDApIGFkZENodW5rKHN0cmVhbSwgc3RhdGUsIGNodW5rLCBmYWxzZSk7ZWxzZSBtYXliZVJlYWRNb3JlKHN0cmVhbSwgc3RhdGUpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGFkZENodW5rKHN0cmVhbSwgc3RhdGUsIGNodW5rLCBmYWxzZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKCFhZGRUb0Zyb250KSB7XG4gICAgICBzdGF0ZS5yZWFkaW5nID0gZmFsc2U7XG4gICAgICBtYXliZVJlYWRNb3JlKHN0cmVhbSwgc3RhdGUpO1xuICAgIH1cbiAgfSAvLyBXZSBjYW4gcHVzaCBtb3JlIGRhdGEgaWYgd2UgYXJlIGJlbG93IHRoZSBoaWdoV2F0ZXJNYXJrLlxuICAvLyBBbHNvLCBpZiB3ZSBoYXZlIG5vIGRhdGEgeWV0LCB3ZSBjYW4gc3RhbmQgc29tZSBtb3JlIGJ5dGVzLlxuICAvLyBUaGlzIGlzIHRvIHdvcmsgYXJvdW5kIGNhc2VzIHdoZXJlIGh3bT0wLCBzdWNoIGFzIHRoZSByZXBsLlxuXG5cbiAgcmV0dXJuICFzdGF0ZS5lbmRlZCAmJiAoc3RhdGUubGVuZ3RoIDwgc3RhdGUuaGlnaFdhdGVyTWFyayB8fCBzdGF0ZS5sZW5ndGggPT09IDApO1xufVxuXG5mdW5jdGlvbiBhZGRDaHVuayhzdHJlYW0sIHN0YXRlLCBjaHVuaywgYWRkVG9Gcm9udCkge1xuICBpZiAoc3RhdGUuZmxvd2luZyAmJiBzdGF0ZS5sZW5ndGggPT09IDAgJiYgIXN0YXRlLnN5bmMpIHtcbiAgICBzdGF0ZS5hd2FpdERyYWluID0gMDtcbiAgICBzdHJlYW0uZW1pdCgnZGF0YScsIGNodW5rKTtcbiAgfSBlbHNlIHtcbiAgICAvLyB1cGRhdGUgdGhlIGJ1ZmZlciBpbmZvLlxuICAgIHN0YXRlLmxlbmd0aCArPSBzdGF0ZS5vYmplY3RNb2RlID8gMSA6IGNodW5rLmxlbmd0aDtcbiAgICBpZiAoYWRkVG9Gcm9udCkgc3RhdGUuYnVmZmVyLnVuc2hpZnQoY2h1bmspO2Vsc2Ugc3RhdGUuYnVmZmVyLnB1c2goY2h1bmspO1xuICAgIGlmIChzdGF0ZS5uZWVkUmVhZGFibGUpIGVtaXRSZWFkYWJsZShzdHJlYW0pO1xuICB9XG5cbiAgbWF5YmVSZWFkTW9yZShzdHJlYW0sIHN0YXRlKTtcbn1cblxuZnVuY3Rpb24gY2h1bmtJbnZhbGlkKHN0YXRlLCBjaHVuaykge1xuICB2YXIgZXI7XG5cbiAgaWYgKCFfaXNVaW50OEFycmF5KGNodW5rKSAmJiB0eXBlb2YgY2h1bmsgIT09ICdzdHJpbmcnICYmIGNodW5rICE9PSB1bmRlZmluZWQgJiYgIXN0YXRlLm9iamVjdE1vZGUpIHtcbiAgICBlciA9IG5ldyBFUlJfSU5WQUxJRF9BUkdfVFlQRSgnY2h1bmsnLCBbJ3N0cmluZycsICdCdWZmZXInLCAnVWludDhBcnJheSddLCBjaHVuayk7XG4gIH1cblxuICByZXR1cm4gZXI7XG59XG5cblJlYWRhYmxlLnByb3RvdHlwZS5pc1BhdXNlZCA9IGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIHRoaXMuX3JlYWRhYmxlU3RhdGUuZmxvd2luZyA9PT0gZmFsc2U7XG59OyAvLyBiYWNrd2FyZHMgY29tcGF0aWJpbGl0eS5cblxuXG5SZWFkYWJsZS5wcm90b3R5cGUuc2V0RW5jb2RpbmcgPSBmdW5jdGlvbiAoZW5jKSB7XG4gIGlmICghU3RyaW5nRGVjb2RlcikgU3RyaW5nRGVjb2RlciA9IHJlcXVpcmUoJ3N0cmluZ19kZWNvZGVyLycpLlN0cmluZ0RlY29kZXI7XG4gIHZhciBkZWNvZGVyID0gbmV3IFN0cmluZ0RlY29kZXIoZW5jKTtcbiAgdGhpcy5fcmVhZGFibGVTdGF0ZS5kZWNvZGVyID0gZGVjb2RlcjsgLy8gSWYgc2V0RW5jb2RpbmcobnVsbCksIGRlY29kZXIuZW5jb2RpbmcgZXF1YWxzIHV0ZjhcblxuICB0aGlzLl9yZWFkYWJsZVN0YXRlLmVuY29kaW5nID0gdGhpcy5fcmVhZGFibGVTdGF0ZS5kZWNvZGVyLmVuY29kaW5nOyAvLyBJdGVyYXRlIG92ZXIgY3VycmVudCBidWZmZXIgdG8gY29udmVydCBhbHJlYWR5IHN0b3JlZCBCdWZmZXJzOlxuXG4gIHZhciBwID0gdGhpcy5fcmVhZGFibGVTdGF0ZS5idWZmZXIuaGVhZDtcbiAgdmFyIGNvbnRlbnQgPSAnJztcblxuICB3aGlsZSAocCAhPT0gbnVsbCkge1xuICAgIGNvbnRlbnQgKz0gZGVjb2Rlci53cml0ZShwLmRhdGEpO1xuICAgIHAgPSBwLm5leHQ7XG4gIH1cblxuICB0aGlzLl9yZWFkYWJsZVN0YXRlLmJ1ZmZlci5jbGVhcigpO1xuXG4gIGlmIChjb250ZW50ICE9PSAnJykgdGhpcy5fcmVhZGFibGVTdGF0ZS5idWZmZXIucHVzaChjb250ZW50KTtcbiAgdGhpcy5fcmVhZGFibGVTdGF0ZS5sZW5ndGggPSBjb250ZW50Lmxlbmd0aDtcbiAgcmV0dXJuIHRoaXM7XG59OyAvLyBEb24ndCByYWlzZSB0aGUgaHdtID4gMUdCXG5cblxudmFyIE1BWF9IV00gPSAweDQwMDAwMDAwO1xuXG5mdW5jdGlvbiBjb21wdXRlTmV3SGlnaFdhdGVyTWFyayhuKSB7XG4gIGlmIChuID49IE1BWF9IV00pIHtcbiAgICAvLyBUT0RPKHJvbmFnKTogVGhyb3cgRVJSX1ZBTFVFX09VVF9PRl9SQU5HRS5cbiAgICBuID0gTUFYX0hXTTtcbiAgfSBlbHNlIHtcbiAgICAvLyBHZXQgdGhlIG5leHQgaGlnaGVzdCBwb3dlciBvZiAyIHRvIHByZXZlbnQgaW5jcmVhc2luZyBod20gZXhjZXNzaXZlbHkgaW5cbiAgICAvLyB0aW55IGFtb3VudHNcbiAgICBuLS07XG4gICAgbiB8PSBuID4+PiAxO1xuICAgIG4gfD0gbiA+Pj4gMjtcbiAgICBuIHw9IG4gPj4+IDQ7XG4gICAgbiB8PSBuID4+PiA4O1xuICAgIG4gfD0gbiA+Pj4gMTY7XG4gICAgbisrO1xuICB9XG5cbiAgcmV0dXJuIG47XG59IC8vIFRoaXMgZnVuY3Rpb24gaXMgZGVzaWduZWQgdG8gYmUgaW5saW5hYmxlLCBzbyBwbGVhc2UgdGFrZSBjYXJlIHdoZW4gbWFraW5nXG4vLyBjaGFuZ2VzIHRvIHRoZSBmdW5jdGlvbiBib2R5LlxuXG5cbmZ1bmN0aW9uIGhvd011Y2hUb1JlYWQobiwgc3RhdGUpIHtcbiAgaWYgKG4gPD0gMCB8fCBzdGF0ZS5sZW5ndGggPT09IDAgJiYgc3RhdGUuZW5kZWQpIHJldHVybiAwO1xuICBpZiAoc3RhdGUub2JqZWN0TW9kZSkgcmV0dXJuIDE7XG5cbiAgaWYgKG4gIT09IG4pIHtcbiAgICAvLyBPbmx5IGZsb3cgb25lIGJ1ZmZlciBhdCBhIHRpbWVcbiAgICBpZiAoc3RhdGUuZmxvd2luZyAmJiBzdGF0ZS5sZW5ndGgpIHJldHVybiBzdGF0ZS5idWZmZXIuaGVhZC5kYXRhLmxlbmd0aDtlbHNlIHJldHVybiBzdGF0ZS5sZW5ndGg7XG4gIH0gLy8gSWYgd2UncmUgYXNraW5nIGZvciBtb3JlIHRoYW4gdGhlIGN1cnJlbnQgaHdtLCB0aGVuIHJhaXNlIHRoZSBod20uXG5cblxuICBpZiAobiA+IHN0YXRlLmhpZ2hXYXRlck1hcmspIHN0YXRlLmhpZ2hXYXRlck1hcmsgPSBjb21wdXRlTmV3SGlnaFdhdGVyTWFyayhuKTtcbiAgaWYgKG4gPD0gc3RhdGUubGVuZ3RoKSByZXR1cm4gbjsgLy8gRG9uJ3QgaGF2ZSBlbm91Z2hcblxuICBpZiAoIXN0YXRlLmVuZGVkKSB7XG4gICAgc3RhdGUubmVlZFJlYWRhYmxlID0gdHJ1ZTtcbiAgICByZXR1cm4gMDtcbiAgfVxuXG4gIHJldHVybiBzdGF0ZS5sZW5ndGg7XG59IC8vIHlvdSBjYW4gb3ZlcnJpZGUgZWl0aGVyIHRoaXMgbWV0aG9kLCBvciB0aGUgYXN5bmMgX3JlYWQobikgYmVsb3cuXG5cblxuUmVhZGFibGUucHJvdG90eXBlLnJlYWQgPSBmdW5jdGlvbiAobikge1xuICBkZWJ1ZygncmVhZCcsIG4pO1xuICBuID0gcGFyc2VJbnQobiwgMTApO1xuICB2YXIgc3RhdGUgPSB0aGlzLl9yZWFkYWJsZVN0YXRlO1xuICB2YXIgbk9yaWcgPSBuO1xuICBpZiAobiAhPT0gMCkgc3RhdGUuZW1pdHRlZFJlYWRhYmxlID0gZmFsc2U7IC8vIGlmIHdlJ3JlIGRvaW5nIHJlYWQoMCkgdG8gdHJpZ2dlciBhIHJlYWRhYmxlIGV2ZW50LCBidXQgd2VcbiAgLy8gYWxyZWFkeSBoYXZlIGEgYnVuY2ggb2YgZGF0YSBpbiB0aGUgYnVmZmVyLCB0aGVuIGp1c3QgdHJpZ2dlclxuICAvLyB0aGUgJ3JlYWRhYmxlJyBldmVudCBhbmQgbW92ZSBvbi5cblxuICBpZiAobiA9PT0gMCAmJiBzdGF0ZS5uZWVkUmVhZGFibGUgJiYgKChzdGF0ZS5oaWdoV2F0ZXJNYXJrICE9PSAwID8gc3RhdGUubGVuZ3RoID49IHN0YXRlLmhpZ2hXYXRlck1hcmsgOiBzdGF0ZS5sZW5ndGggPiAwKSB8fCBzdGF0ZS5lbmRlZCkpIHtcbiAgICBkZWJ1ZygncmVhZDogZW1pdFJlYWRhYmxlJywgc3RhdGUubGVuZ3RoLCBzdGF0ZS5lbmRlZCk7XG4gICAgaWYgKHN0YXRlLmxlbmd0aCA9PT0gMCAmJiBzdGF0ZS5lbmRlZCkgZW5kUmVhZGFibGUodGhpcyk7ZWxzZSBlbWl0UmVhZGFibGUodGhpcyk7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cblxuICBuID0gaG93TXVjaFRvUmVhZChuLCBzdGF0ZSk7IC8vIGlmIHdlJ3ZlIGVuZGVkLCBhbmQgd2UncmUgbm93IGNsZWFyLCB0aGVuIGZpbmlzaCBpdCB1cC5cblxuICBpZiAobiA9PT0gMCAmJiBzdGF0ZS5lbmRlZCkge1xuICAgIGlmIChzdGF0ZS5sZW5ndGggPT09IDApIGVuZFJlYWRhYmxlKHRoaXMpO1xuICAgIHJldHVybiBudWxsO1xuICB9IC8vIEFsbCB0aGUgYWN0dWFsIGNodW5rIGdlbmVyYXRpb24gbG9naWMgbmVlZHMgdG8gYmVcbiAgLy8gKmJlbG93KiB0aGUgY2FsbCB0byBfcmVhZC4gIFRoZSByZWFzb24gaXMgdGhhdCBpbiBjZXJ0YWluXG4gIC8vIHN5bnRoZXRpYyBzdHJlYW0gY2FzZXMsIHN1Y2ggYXMgcGFzc3Rocm91Z2ggc3RyZWFtcywgX3JlYWRcbiAgLy8gbWF5IGJlIGEgY29tcGxldGVseSBzeW5jaHJvbm91cyBvcGVyYXRpb24gd2hpY2ggbWF5IGNoYW5nZVxuICAvLyB0aGUgc3RhdGUgb2YgdGhlIHJlYWQgYnVmZmVyLCBwcm92aWRpbmcgZW5vdWdoIGRhdGEgd2hlblxuICAvLyBiZWZvcmUgdGhlcmUgd2FzICpub3QqIGVub3VnaC5cbiAgLy9cbiAgLy8gU28sIHRoZSBzdGVwcyBhcmU6XG4gIC8vIDEuIEZpZ3VyZSBvdXQgd2hhdCB0aGUgc3RhdGUgb2YgdGhpbmdzIHdpbGwgYmUgYWZ0ZXIgd2UgZG9cbiAgLy8gYSByZWFkIGZyb20gdGhlIGJ1ZmZlci5cbiAgLy9cbiAgLy8gMi4gSWYgdGhhdCByZXN1bHRpbmcgc3RhdGUgd2lsbCB0cmlnZ2VyIGEgX3JlYWQsIHRoZW4gY2FsbCBfcmVhZC5cbiAgLy8gTm90ZSB0aGF0IHRoaXMgbWF5IGJlIGFzeW5jaHJvbm91cywgb3Igc3luY2hyb25vdXMuICBZZXMsIGl0IGlzXG4gIC8vIGRlZXBseSB1Z2x5IHRvIHdyaXRlIEFQSXMgdGhpcyB3YXksIGJ1dCB0aGF0IHN0aWxsIGRvZXNuJ3QgbWVhblxuICAvLyB0aGF0IHRoZSBSZWFkYWJsZSBjbGFzcyBzaG91bGQgYmVoYXZlIGltcHJvcGVybHksIGFzIHN0cmVhbXMgYXJlXG4gIC8vIGRlc2lnbmVkIHRvIGJlIHN5bmMvYXN5bmMgYWdub3N0aWMuXG4gIC8vIFRha2Ugbm90ZSBpZiB0aGUgX3JlYWQgY2FsbCBpcyBzeW5jIG9yIGFzeW5jIChpZSwgaWYgdGhlIHJlYWQgY2FsbFxuICAvLyBoYXMgcmV0dXJuZWQgeWV0KSwgc28gdGhhdCB3ZSBrbm93IHdoZXRoZXIgb3Igbm90IGl0J3Mgc2FmZSB0byBlbWl0XG4gIC8vICdyZWFkYWJsZScgZXRjLlxuICAvL1xuICAvLyAzLiBBY3R1YWxseSBwdWxsIHRoZSByZXF1ZXN0ZWQgY2h1bmtzIG91dCBvZiB0aGUgYnVmZmVyIGFuZCByZXR1cm4uXG4gIC8vIGlmIHdlIG5lZWQgYSByZWFkYWJsZSBldmVudCwgdGhlbiB3ZSBuZWVkIHRvIGRvIHNvbWUgcmVhZGluZy5cblxuXG4gIHZhciBkb1JlYWQgPSBzdGF0ZS5uZWVkUmVhZGFibGU7XG4gIGRlYnVnKCduZWVkIHJlYWRhYmxlJywgZG9SZWFkKTsgLy8gaWYgd2UgY3VycmVudGx5IGhhdmUgbGVzcyB0aGFuIHRoZSBoaWdoV2F0ZXJNYXJrLCB0aGVuIGFsc28gcmVhZCBzb21lXG5cbiAgaWYgKHN0YXRlLmxlbmd0aCA9PT0gMCB8fCBzdGF0ZS5sZW5ndGggLSBuIDwgc3RhdGUuaGlnaFdhdGVyTWFyaykge1xuICAgIGRvUmVhZCA9IHRydWU7XG4gICAgZGVidWcoJ2xlbmd0aCBsZXNzIHRoYW4gd2F0ZXJtYXJrJywgZG9SZWFkKTtcbiAgfSAvLyBob3dldmVyLCBpZiB3ZSd2ZSBlbmRlZCwgdGhlbiB0aGVyZSdzIG5vIHBvaW50LCBhbmQgaWYgd2UncmUgYWxyZWFkeVxuICAvLyByZWFkaW5nLCB0aGVuIGl0J3MgdW5uZWNlc3NhcnkuXG5cblxuICBpZiAoc3RhdGUuZW5kZWQgfHwgc3RhdGUucmVhZGluZykge1xuICAgIGRvUmVhZCA9IGZhbHNlO1xuICAgIGRlYnVnKCdyZWFkaW5nIG9yIGVuZGVkJywgZG9SZWFkKTtcbiAgfSBlbHNlIGlmIChkb1JlYWQpIHtcbiAgICBkZWJ1ZygnZG8gcmVhZCcpO1xuICAgIHN0YXRlLnJlYWRpbmcgPSB0cnVlO1xuICAgIHN0YXRlLnN5bmMgPSB0cnVlOyAvLyBpZiB0aGUgbGVuZ3RoIGlzIGN1cnJlbnRseSB6ZXJvLCB0aGVuIHdlICpuZWVkKiBhIHJlYWRhYmxlIGV2ZW50LlxuXG4gICAgaWYgKHN0YXRlLmxlbmd0aCA9PT0gMCkgc3RhdGUubmVlZFJlYWRhYmxlID0gdHJ1ZTsgLy8gY2FsbCBpbnRlcm5hbCByZWFkIG1ldGhvZFxuXG4gICAgdGhpcy5fcmVhZChzdGF0ZS5oaWdoV2F0ZXJNYXJrKTtcblxuICAgIHN0YXRlLnN5bmMgPSBmYWxzZTsgLy8gSWYgX3JlYWQgcHVzaGVkIGRhdGEgc3luY2hyb25vdXNseSwgdGhlbiBgcmVhZGluZ2Agd2lsbCBiZSBmYWxzZSxcbiAgICAvLyBhbmQgd2UgbmVlZCB0byByZS1ldmFsdWF0ZSBob3cgbXVjaCBkYXRhIHdlIGNhbiByZXR1cm4gdG8gdGhlIHVzZXIuXG5cbiAgICBpZiAoIXN0YXRlLnJlYWRpbmcpIG4gPSBob3dNdWNoVG9SZWFkKG5PcmlnLCBzdGF0ZSk7XG4gIH1cblxuICB2YXIgcmV0O1xuICBpZiAobiA+IDApIHJldCA9IGZyb21MaXN0KG4sIHN0YXRlKTtlbHNlIHJldCA9IG51bGw7XG5cbiAgaWYgKHJldCA9PT0gbnVsbCkge1xuICAgIHN0YXRlLm5lZWRSZWFkYWJsZSA9IHN0YXRlLmxlbmd0aCA8PSBzdGF0ZS5oaWdoV2F0ZXJNYXJrO1xuICAgIG4gPSAwO1xuICB9IGVsc2Uge1xuICAgIHN0YXRlLmxlbmd0aCAtPSBuO1xuICAgIHN0YXRlLmF3YWl0RHJhaW4gPSAwO1xuICB9XG5cbiAgaWYgKHN0YXRlLmxlbmd0aCA9PT0gMCkge1xuICAgIC8vIElmIHdlIGhhdmUgbm90aGluZyBpbiB0aGUgYnVmZmVyLCB0aGVuIHdlIHdhbnQgdG8ga25vd1xuICAgIC8vIGFzIHNvb24gYXMgd2UgKmRvKiBnZXQgc29tZXRoaW5nIGludG8gdGhlIGJ1ZmZlci5cbiAgICBpZiAoIXN0YXRlLmVuZGVkKSBzdGF0ZS5uZWVkUmVhZGFibGUgPSB0cnVlOyAvLyBJZiB3ZSB0cmllZCB0byByZWFkKCkgcGFzdCB0aGUgRU9GLCB0aGVuIGVtaXQgZW5kIG9uIHRoZSBuZXh0IHRpY2suXG5cbiAgICBpZiAobk9yaWcgIT09IG4gJiYgc3RhdGUuZW5kZWQpIGVuZFJlYWRhYmxlKHRoaXMpO1xuICB9XG5cbiAgaWYgKHJldCAhPT0gbnVsbCkgdGhpcy5lbWl0KCdkYXRhJywgcmV0KTtcbiAgcmV0dXJuIHJldDtcbn07XG5cbmZ1bmN0aW9uIG9uRW9mQ2h1bmsoc3RyZWFtLCBzdGF0ZSkge1xuICBkZWJ1Zygnb25Fb2ZDaHVuaycpO1xuICBpZiAoc3RhdGUuZW5kZWQpIHJldHVybjtcblxuICBpZiAoc3RhdGUuZGVjb2Rlcikge1xuICAgIHZhciBjaHVuayA9IHN0YXRlLmRlY29kZXIuZW5kKCk7XG5cbiAgICBpZiAoY2h1bmsgJiYgY2h1bmsubGVuZ3RoKSB7XG4gICAgICBzdGF0ZS5idWZmZXIucHVzaChjaHVuayk7XG4gICAgICBzdGF0ZS5sZW5ndGggKz0gc3RhdGUub2JqZWN0TW9kZSA/IDEgOiBjaHVuay5sZW5ndGg7XG4gICAgfVxuICB9XG5cbiAgc3RhdGUuZW5kZWQgPSB0cnVlO1xuXG4gIGlmIChzdGF0ZS5zeW5jKSB7XG4gICAgLy8gaWYgd2UgYXJlIHN5bmMsIHdhaXQgdW50aWwgbmV4dCB0aWNrIHRvIGVtaXQgdGhlIGRhdGEuXG4gICAgLy8gT3RoZXJ3aXNlIHdlIHJpc2sgZW1pdHRpbmcgZGF0YSBpbiB0aGUgZmxvdygpXG4gICAgLy8gdGhlIHJlYWRhYmxlIGNvZGUgdHJpZ2dlcnMgZHVyaW5nIGEgcmVhZCgpIGNhbGxcbiAgICBlbWl0UmVhZGFibGUoc3RyZWFtKTtcbiAgfSBlbHNlIHtcbiAgICAvLyBlbWl0ICdyZWFkYWJsZScgbm93IHRvIG1ha2Ugc3VyZSBpdCBnZXRzIHBpY2tlZCB1cC5cbiAgICBzdGF0ZS5uZWVkUmVhZGFibGUgPSBmYWxzZTtcblxuICAgIGlmICghc3RhdGUuZW1pdHRlZFJlYWRhYmxlKSB7XG4gICAgICBzdGF0ZS5lbWl0dGVkUmVhZGFibGUgPSB0cnVlO1xuICAgICAgZW1pdFJlYWRhYmxlXyhzdHJlYW0pO1xuICAgIH1cbiAgfVxufSAvLyBEb24ndCBlbWl0IHJlYWRhYmxlIHJpZ2h0IGF3YXkgaW4gc3luYyBtb2RlLCBiZWNhdXNlIHRoaXMgY2FuIHRyaWdnZXJcbi8vIGFub3RoZXIgcmVhZCgpIGNhbGwgPT4gc3RhY2sgb3ZlcmZsb3cuICBUaGlzIHdheSwgaXQgbWlnaHQgdHJpZ2dlclxuLy8gYSBuZXh0VGljayByZWN1cnNpb24gd2FybmluZywgYnV0IHRoYXQncyBub3Qgc28gYmFkLlxuXG5cbmZ1bmN0aW9uIGVtaXRSZWFkYWJsZShzdHJlYW0pIHtcbiAgdmFyIHN0YXRlID0gc3RyZWFtLl9yZWFkYWJsZVN0YXRlO1xuICBkZWJ1ZygnZW1pdFJlYWRhYmxlJywgc3RhdGUubmVlZFJlYWRhYmxlLCBzdGF0ZS5lbWl0dGVkUmVhZGFibGUpO1xuICBzdGF0ZS5uZWVkUmVhZGFibGUgPSBmYWxzZTtcblxuICBpZiAoIXN0YXRlLmVtaXR0ZWRSZWFkYWJsZSkge1xuICAgIGRlYnVnKCdlbWl0UmVhZGFibGUnLCBzdGF0ZS5mbG93aW5nKTtcbiAgICBzdGF0ZS5lbWl0dGVkUmVhZGFibGUgPSB0cnVlO1xuICAgIHByb2Nlc3MubmV4dFRpY2soZW1pdFJlYWRhYmxlXywgc3RyZWFtKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBlbWl0UmVhZGFibGVfKHN0cmVhbSkge1xuICB2YXIgc3RhdGUgPSBzdHJlYW0uX3JlYWRhYmxlU3RhdGU7XG4gIGRlYnVnKCdlbWl0UmVhZGFibGVfJywgc3RhdGUuZGVzdHJveWVkLCBzdGF0ZS5sZW5ndGgsIHN0YXRlLmVuZGVkKTtcblxuICBpZiAoIXN0YXRlLmRlc3Ryb3llZCAmJiAoc3RhdGUubGVuZ3RoIHx8IHN0YXRlLmVuZGVkKSkge1xuICAgIHN0cmVhbS5lbWl0KCdyZWFkYWJsZScpO1xuICAgIHN0YXRlLmVtaXR0ZWRSZWFkYWJsZSA9IGZhbHNlO1xuICB9IC8vIFRoZSBzdHJlYW0gbmVlZHMgYW5vdGhlciByZWFkYWJsZSBldmVudCBpZlxuICAvLyAxLiBJdCBpcyBub3QgZmxvd2luZywgYXMgdGhlIGZsb3cgbWVjaGFuaXNtIHdpbGwgdGFrZVxuICAvLyAgICBjYXJlIG9mIGl0LlxuICAvLyAyLiBJdCBpcyBub3QgZW5kZWQuXG4gIC8vIDMuIEl0IGlzIGJlbG93IHRoZSBoaWdoV2F0ZXJNYXJrLCBzbyB3ZSBjYW4gc2NoZWR1bGVcbiAgLy8gICAgYW5vdGhlciByZWFkYWJsZSBsYXRlci5cblxuXG4gIHN0YXRlLm5lZWRSZWFkYWJsZSA9ICFzdGF0ZS5mbG93aW5nICYmICFzdGF0ZS5lbmRlZCAmJiBzdGF0ZS5sZW5ndGggPD0gc3RhdGUuaGlnaFdhdGVyTWFyaztcbiAgZmxvdyhzdHJlYW0pO1xufSAvLyBhdCB0aGlzIHBvaW50LCB0aGUgdXNlciBoYXMgcHJlc3VtYWJseSBzZWVuIHRoZSAncmVhZGFibGUnIGV2ZW50LFxuLy8gYW5kIGNhbGxlZCByZWFkKCkgdG8gY29uc3VtZSBzb21lIGRhdGEuICB0aGF0IG1heSBoYXZlIHRyaWdnZXJlZFxuLy8gaW4gdHVybiBhbm90aGVyIF9yZWFkKG4pIGNhbGwsIGluIHdoaWNoIGNhc2UgcmVhZGluZyA9IHRydWUgaWZcbi8vIGl0J3MgaW4gcHJvZ3Jlc3MuXG4vLyBIb3dldmVyLCBpZiB3ZSdyZSBub3QgZW5kZWQsIG9yIHJlYWRpbmcsIGFuZCB0aGUgbGVuZ3RoIDwgaHdtLFxuLy8gdGhlbiBnbyBhaGVhZCBhbmQgdHJ5IHRvIHJlYWQgc29tZSBtb3JlIHByZWVtcHRpdmVseS5cblxuXG5mdW5jdGlvbiBtYXliZVJlYWRNb3JlKHN0cmVhbSwgc3RhdGUpIHtcbiAgaWYgKCFzdGF0ZS5yZWFkaW5nTW9yZSkge1xuICAgIHN0YXRlLnJlYWRpbmdNb3JlID0gdHJ1ZTtcbiAgICBwcm9jZXNzLm5leHRUaWNrKG1heWJlUmVhZE1vcmVfLCBzdHJlYW0sIHN0YXRlKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBtYXliZVJlYWRNb3JlXyhzdHJlYW0sIHN0YXRlKSB7XG4gIC8vIEF0dGVtcHQgdG8gcmVhZCBtb3JlIGRhdGEgaWYgd2Ugc2hvdWxkLlxuICAvL1xuICAvLyBUaGUgY29uZGl0aW9ucyBmb3IgcmVhZGluZyBtb3JlIGRhdGEgYXJlIChvbmUgb2YpOlxuICAvLyAtIE5vdCBlbm91Z2ggZGF0YSBidWZmZXJlZCAoc3RhdGUubGVuZ3RoIDwgc3RhdGUuaGlnaFdhdGVyTWFyaykuIFRoZSBsb29wXG4gIC8vICAgaXMgcmVzcG9uc2libGUgZm9yIGZpbGxpbmcgdGhlIGJ1ZmZlciB3aXRoIGVub3VnaCBkYXRhIGlmIHN1Y2ggZGF0YVxuICAvLyAgIGlzIGF2YWlsYWJsZS4gSWYgaGlnaFdhdGVyTWFyayBpcyAwIGFuZCB3ZSBhcmUgbm90IGluIHRoZSBmbG93aW5nIG1vZGVcbiAgLy8gICB3ZSBzaG91bGQgX25vdF8gYXR0ZW1wdCB0byBidWZmZXIgYW55IGV4dHJhIGRhdGEuIFdlJ2xsIGdldCBtb3JlIGRhdGFcbiAgLy8gICB3aGVuIHRoZSBzdHJlYW0gY29uc3VtZXIgY2FsbHMgcmVhZCgpIGluc3RlYWQuXG4gIC8vIC0gTm8gZGF0YSBpbiB0aGUgYnVmZmVyLCBhbmQgdGhlIHN0cmVhbSBpcyBpbiBmbG93aW5nIG1vZGUuIEluIHRoaXMgbW9kZVxuICAvLyAgIHRoZSBsb29wIGJlbG93IGlzIHJlc3BvbnNpYmxlIGZvciBlbnN1cmluZyByZWFkKCkgaXMgY2FsbGVkLiBGYWlsaW5nIHRvXG4gIC8vICAgY2FsbCByZWFkIGhlcmUgd291bGQgYWJvcnQgdGhlIGZsb3cgYW5kIHRoZXJlJ3Mgbm8gb3RoZXIgbWVjaGFuaXNtIGZvclxuICAvLyAgIGNvbnRpbnVpbmcgdGhlIGZsb3cgaWYgdGhlIHN0cmVhbSBjb25zdW1lciBoYXMganVzdCBzdWJzY3JpYmVkIHRvIHRoZVxuICAvLyAgICdkYXRhJyBldmVudC5cbiAgLy9cbiAgLy8gSW4gYWRkaXRpb24gdG8gdGhlIGFib3ZlIGNvbmRpdGlvbnMgdG8ga2VlcCByZWFkaW5nIGRhdGEsIHRoZSBmb2xsb3dpbmdcbiAgLy8gY29uZGl0aW9ucyBwcmV2ZW50IHRoZSBkYXRhIGZyb20gYmVpbmcgcmVhZDpcbiAgLy8gLSBUaGUgc3RyZWFtIGhhcyBlbmRlZCAoc3RhdGUuZW5kZWQpLlxuICAvLyAtIFRoZXJlIGlzIGFscmVhZHkgYSBwZW5kaW5nICdyZWFkJyBvcGVyYXRpb24gKHN0YXRlLnJlYWRpbmcpLiBUaGlzIGlzIGFcbiAgLy8gICBjYXNlIHdoZXJlIHRoZSB0aGUgc3RyZWFtIGhhcyBjYWxsZWQgdGhlIGltcGxlbWVudGF0aW9uIGRlZmluZWQgX3JlYWQoKVxuICAvLyAgIG1ldGhvZCwgYnV0IHRoZXkgYXJlIHByb2Nlc3NpbmcgdGhlIGNhbGwgYXN5bmNocm9ub3VzbHkgYW5kIGhhdmUgX25vdF9cbiAgLy8gICBjYWxsZWQgcHVzaCgpIHdpdGggbmV3IGRhdGEuIEluIHRoaXMgY2FzZSB3ZSBza2lwIHBlcmZvcm1pbmcgbW9yZVxuICAvLyAgIHJlYWQoKXMuIFRoZSBleGVjdXRpb24gZW5kcyBpbiB0aGlzIG1ldGhvZCBhZ2FpbiBhZnRlciB0aGUgX3JlYWQoKSBlbmRzXG4gIC8vICAgdXAgY2FsbGluZyBwdXNoKCkgd2l0aCBtb3JlIGRhdGEuXG4gIHdoaWxlICghc3RhdGUucmVhZGluZyAmJiAhc3RhdGUuZW5kZWQgJiYgKHN0YXRlLmxlbmd0aCA8IHN0YXRlLmhpZ2hXYXRlck1hcmsgfHwgc3RhdGUuZmxvd2luZyAmJiBzdGF0ZS5sZW5ndGggPT09IDApKSB7XG4gICAgdmFyIGxlbiA9IHN0YXRlLmxlbmd0aDtcbiAgICBkZWJ1ZygnbWF5YmVSZWFkTW9yZSByZWFkIDAnKTtcbiAgICBzdHJlYW0ucmVhZCgwKTtcbiAgICBpZiAobGVuID09PSBzdGF0ZS5sZW5ndGgpIC8vIGRpZG4ndCBnZXQgYW55IGRhdGEsIHN0b3Agc3Bpbm5pbmcuXG4gICAgICBicmVhaztcbiAgfVxuXG4gIHN0YXRlLnJlYWRpbmdNb3JlID0gZmFsc2U7XG59IC8vIGFic3RyYWN0IG1ldGhvZC4gIHRvIGJlIG92ZXJyaWRkZW4gaW4gc3BlY2lmaWMgaW1wbGVtZW50YXRpb24gY2xhc3Nlcy5cbi8vIGNhbGwgY2IoZXIsIGRhdGEpIHdoZXJlIGRhdGEgaXMgPD0gbiBpbiBsZW5ndGguXG4vLyBmb3IgdmlydHVhbCAobm9uLXN0cmluZywgbm9uLWJ1ZmZlcikgc3RyZWFtcywgXCJsZW5ndGhcIiBpcyBzb21ld2hhdFxuLy8gYXJiaXRyYXJ5LCBhbmQgcGVyaGFwcyBub3QgdmVyeSBtZWFuaW5nZnVsLlxuXG5cblJlYWRhYmxlLnByb3RvdHlwZS5fcmVhZCA9IGZ1bmN0aW9uIChuKSB7XG4gIGVycm9yT3JEZXN0cm95KHRoaXMsIG5ldyBFUlJfTUVUSE9EX05PVF9JTVBMRU1FTlRFRCgnX3JlYWQoKScpKTtcbn07XG5cblJlYWRhYmxlLnByb3RvdHlwZS5waXBlID0gZnVuY3Rpb24gKGRlc3QsIHBpcGVPcHRzKSB7XG4gIHZhciBzcmMgPSB0aGlzO1xuICB2YXIgc3RhdGUgPSB0aGlzLl9yZWFkYWJsZVN0YXRlO1xuXG4gIHN3aXRjaCAoc3RhdGUucGlwZXNDb3VudCkge1xuICAgIGNhc2UgMDpcbiAgICAgIHN0YXRlLnBpcGVzID0gZGVzdDtcbiAgICAgIGJyZWFrO1xuXG4gICAgY2FzZSAxOlxuICAgICAgc3RhdGUucGlwZXMgPSBbc3RhdGUucGlwZXMsIGRlc3RdO1xuICAgICAgYnJlYWs7XG5cbiAgICBkZWZhdWx0OlxuICAgICAgc3RhdGUucGlwZXMucHVzaChkZXN0KTtcbiAgICAgIGJyZWFrO1xuICB9XG5cbiAgc3RhdGUucGlwZXNDb3VudCArPSAxO1xuICBkZWJ1ZygncGlwZSBjb3VudD0lZCBvcHRzPSVqJywgc3RhdGUucGlwZXNDb3VudCwgcGlwZU9wdHMpO1xuICB2YXIgZG9FbmQgPSAoIXBpcGVPcHRzIHx8IHBpcGVPcHRzLmVuZCAhPT0gZmFsc2UpICYmIGRlc3QgIT09IHByb2Nlc3Muc3Rkb3V0ICYmIGRlc3QgIT09IHByb2Nlc3Muc3RkZXJyO1xuICB2YXIgZW5kRm4gPSBkb0VuZCA/IG9uZW5kIDogdW5waXBlO1xuICBpZiAoc3RhdGUuZW5kRW1pdHRlZCkgcHJvY2Vzcy5uZXh0VGljayhlbmRGbik7ZWxzZSBzcmMub25jZSgnZW5kJywgZW5kRm4pO1xuICBkZXN0Lm9uKCd1bnBpcGUnLCBvbnVucGlwZSk7XG5cbiAgZnVuY3Rpb24gb251bnBpcGUocmVhZGFibGUsIHVucGlwZUluZm8pIHtcbiAgICBkZWJ1Zygnb251bnBpcGUnKTtcblxuICAgIGlmIChyZWFkYWJsZSA9PT0gc3JjKSB7XG4gICAgICBpZiAodW5waXBlSW5mbyAmJiB1bnBpcGVJbmZvLmhhc1VucGlwZWQgPT09IGZhbHNlKSB7XG4gICAgICAgIHVucGlwZUluZm8uaGFzVW5waXBlZCA9IHRydWU7XG4gICAgICAgIGNsZWFudXAoKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBvbmVuZCgpIHtcbiAgICBkZWJ1Zygnb25lbmQnKTtcbiAgICBkZXN0LmVuZCgpO1xuICB9IC8vIHdoZW4gdGhlIGRlc3QgZHJhaW5zLCBpdCByZWR1Y2VzIHRoZSBhd2FpdERyYWluIGNvdW50ZXJcbiAgLy8gb24gdGhlIHNvdXJjZS4gIFRoaXMgd291bGQgYmUgbW9yZSBlbGVnYW50IHdpdGggYSAub25jZSgpXG4gIC8vIGhhbmRsZXIgaW4gZmxvdygpLCBidXQgYWRkaW5nIGFuZCByZW1vdmluZyByZXBlYXRlZGx5IGlzXG4gIC8vIHRvbyBzbG93LlxuXG5cbiAgdmFyIG9uZHJhaW4gPSBwaXBlT25EcmFpbihzcmMpO1xuICBkZXN0Lm9uKCdkcmFpbicsIG9uZHJhaW4pO1xuICB2YXIgY2xlYW5lZFVwID0gZmFsc2U7XG5cbiAgZnVuY3Rpb24gY2xlYW51cCgpIHtcbiAgICBkZWJ1ZygnY2xlYW51cCcpOyAvLyBjbGVhbnVwIGV2ZW50IGhhbmRsZXJzIG9uY2UgdGhlIHBpcGUgaXMgYnJva2VuXG5cbiAgICBkZXN0LnJlbW92ZUxpc3RlbmVyKCdjbG9zZScsIG9uY2xvc2UpO1xuICAgIGRlc3QucmVtb3ZlTGlzdGVuZXIoJ2ZpbmlzaCcsIG9uZmluaXNoKTtcbiAgICBkZXN0LnJlbW92ZUxpc3RlbmVyKCdkcmFpbicsIG9uZHJhaW4pO1xuICAgIGRlc3QucmVtb3ZlTGlzdGVuZXIoJ2Vycm9yJywgb25lcnJvcik7XG4gICAgZGVzdC5yZW1vdmVMaXN0ZW5lcigndW5waXBlJywgb251bnBpcGUpO1xuICAgIHNyYy5yZW1vdmVMaXN0ZW5lcignZW5kJywgb25lbmQpO1xuICAgIHNyYy5yZW1vdmVMaXN0ZW5lcignZW5kJywgdW5waXBlKTtcbiAgICBzcmMucmVtb3ZlTGlzdGVuZXIoJ2RhdGEnLCBvbmRhdGEpO1xuICAgIGNsZWFuZWRVcCA9IHRydWU7IC8vIGlmIHRoZSByZWFkZXIgaXMgd2FpdGluZyBmb3IgYSBkcmFpbiBldmVudCBmcm9tIHRoaXNcbiAgICAvLyBzcGVjaWZpYyB3cml0ZXIsIHRoZW4gaXQgd291bGQgY2F1c2UgaXQgdG8gbmV2ZXIgc3RhcnRcbiAgICAvLyBmbG93aW5nIGFnYWluLlxuICAgIC8vIFNvLCBpZiB0aGlzIGlzIGF3YWl0aW5nIGEgZHJhaW4sIHRoZW4gd2UganVzdCBjYWxsIGl0IG5vdy5cbiAgICAvLyBJZiB3ZSBkb24ndCBrbm93LCB0aGVuIGFzc3VtZSB0aGF0IHdlIGFyZSB3YWl0aW5nIGZvciBvbmUuXG5cbiAgICBpZiAoc3RhdGUuYXdhaXREcmFpbiAmJiAoIWRlc3QuX3dyaXRhYmxlU3RhdGUgfHwgZGVzdC5fd3JpdGFibGVTdGF0ZS5uZWVkRHJhaW4pKSBvbmRyYWluKCk7XG4gIH1cblxuICBzcmMub24oJ2RhdGEnLCBvbmRhdGEpO1xuXG4gIGZ1bmN0aW9uIG9uZGF0YShjaHVuaykge1xuICAgIGRlYnVnKCdvbmRhdGEnKTtcbiAgICB2YXIgcmV0ID0gZGVzdC53cml0ZShjaHVuayk7XG4gICAgZGVidWcoJ2Rlc3Qud3JpdGUnLCByZXQpO1xuXG4gICAgaWYgKHJldCA9PT0gZmFsc2UpIHtcbiAgICAgIC8vIElmIHRoZSB1c2VyIHVucGlwZWQgZHVyaW5nIGBkZXN0LndyaXRlKClgLCBpdCBpcyBwb3NzaWJsZVxuICAgICAgLy8gdG8gZ2V0IHN0dWNrIGluIGEgcGVybWFuZW50bHkgcGF1c2VkIHN0YXRlIGlmIHRoYXQgd3JpdGVcbiAgICAgIC8vIGFsc28gcmV0dXJuZWQgZmFsc2UuXG4gICAgICAvLyA9PiBDaGVjayB3aGV0aGVyIGBkZXN0YCBpcyBzdGlsbCBhIHBpcGluZyBkZXN0aW5hdGlvbi5cbiAgICAgIGlmICgoc3RhdGUucGlwZXNDb3VudCA9PT0gMSAmJiBzdGF0ZS5waXBlcyA9PT0gZGVzdCB8fCBzdGF0ZS5waXBlc0NvdW50ID4gMSAmJiBpbmRleE9mKHN0YXRlLnBpcGVzLCBkZXN0KSAhPT0gLTEpICYmICFjbGVhbmVkVXApIHtcbiAgICAgICAgZGVidWcoJ2ZhbHNlIHdyaXRlIHJlc3BvbnNlLCBwYXVzZScsIHN0YXRlLmF3YWl0RHJhaW4pO1xuICAgICAgICBzdGF0ZS5hd2FpdERyYWluKys7XG4gICAgICB9XG5cbiAgICAgIHNyYy5wYXVzZSgpO1xuICAgIH1cbiAgfSAvLyBpZiB0aGUgZGVzdCBoYXMgYW4gZXJyb3IsIHRoZW4gc3RvcCBwaXBpbmcgaW50byBpdC5cbiAgLy8gaG93ZXZlciwgZG9uJ3Qgc3VwcHJlc3MgdGhlIHRocm93aW5nIGJlaGF2aW9yIGZvciB0aGlzLlxuXG5cbiAgZnVuY3Rpb24gb25lcnJvcihlcikge1xuICAgIGRlYnVnKCdvbmVycm9yJywgZXIpO1xuICAgIHVucGlwZSgpO1xuICAgIGRlc3QucmVtb3ZlTGlzdGVuZXIoJ2Vycm9yJywgb25lcnJvcik7XG4gICAgaWYgKEVFbGlzdGVuZXJDb3VudChkZXN0LCAnZXJyb3InKSA9PT0gMCkgZXJyb3JPckRlc3Ryb3koZGVzdCwgZXIpO1xuICB9IC8vIE1ha2Ugc3VyZSBvdXIgZXJyb3IgaGFuZGxlciBpcyBhdHRhY2hlZCBiZWZvcmUgdXNlcmxhbmQgb25lcy5cblxuXG4gIHByZXBlbmRMaXN0ZW5lcihkZXN0LCAnZXJyb3InLCBvbmVycm9yKTsgLy8gQm90aCBjbG9zZSBhbmQgZmluaXNoIHNob3VsZCB0cmlnZ2VyIHVucGlwZSwgYnV0IG9ubHkgb25jZS5cblxuICBmdW5jdGlvbiBvbmNsb3NlKCkge1xuICAgIGRlc3QucmVtb3ZlTGlzdGVuZXIoJ2ZpbmlzaCcsIG9uZmluaXNoKTtcbiAgICB1bnBpcGUoKTtcbiAgfVxuXG4gIGRlc3Qub25jZSgnY2xvc2UnLCBvbmNsb3NlKTtcblxuICBmdW5jdGlvbiBvbmZpbmlzaCgpIHtcbiAgICBkZWJ1Zygnb25maW5pc2gnKTtcbiAgICBkZXN0LnJlbW92ZUxpc3RlbmVyKCdjbG9zZScsIG9uY2xvc2UpO1xuICAgIHVucGlwZSgpO1xuICB9XG5cbiAgZGVzdC5vbmNlKCdmaW5pc2gnLCBvbmZpbmlzaCk7XG5cbiAgZnVuY3Rpb24gdW5waXBlKCkge1xuICAgIGRlYnVnKCd1bnBpcGUnKTtcbiAgICBzcmMudW5waXBlKGRlc3QpO1xuICB9IC8vIHRlbGwgdGhlIGRlc3QgdGhhdCBpdCdzIGJlaW5nIHBpcGVkIHRvXG5cblxuICBkZXN0LmVtaXQoJ3BpcGUnLCBzcmMpOyAvLyBzdGFydCB0aGUgZmxvdyBpZiBpdCBoYXNuJ3QgYmVlbiBzdGFydGVkIGFscmVhZHkuXG5cbiAgaWYgKCFzdGF0ZS5mbG93aW5nKSB7XG4gICAgZGVidWcoJ3BpcGUgcmVzdW1lJyk7XG4gICAgc3JjLnJlc3VtZSgpO1xuICB9XG5cbiAgcmV0dXJuIGRlc3Q7XG59O1xuXG5mdW5jdGlvbiBwaXBlT25EcmFpbihzcmMpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIHBpcGVPbkRyYWluRnVuY3Rpb25SZXN1bHQoKSB7XG4gICAgdmFyIHN0YXRlID0gc3JjLl9yZWFkYWJsZVN0YXRlO1xuICAgIGRlYnVnKCdwaXBlT25EcmFpbicsIHN0YXRlLmF3YWl0RHJhaW4pO1xuICAgIGlmIChzdGF0ZS5hd2FpdERyYWluKSBzdGF0ZS5hd2FpdERyYWluLS07XG5cbiAgICBpZiAoc3RhdGUuYXdhaXREcmFpbiA9PT0gMCAmJiBFRWxpc3RlbmVyQ291bnQoc3JjLCAnZGF0YScpKSB7XG4gICAgICBzdGF0ZS5mbG93aW5nID0gdHJ1ZTtcbiAgICAgIGZsb3coc3JjKTtcbiAgICB9XG4gIH07XG59XG5cblJlYWRhYmxlLnByb3RvdHlwZS51bnBpcGUgPSBmdW5jdGlvbiAoZGVzdCkge1xuICB2YXIgc3RhdGUgPSB0aGlzLl9yZWFkYWJsZVN0YXRlO1xuICB2YXIgdW5waXBlSW5mbyA9IHtcbiAgICBoYXNVbnBpcGVkOiBmYWxzZVxuICB9OyAvLyBpZiB3ZSdyZSBub3QgcGlwaW5nIGFueXdoZXJlLCB0aGVuIGRvIG5vdGhpbmcuXG5cbiAgaWYgKHN0YXRlLnBpcGVzQ291bnQgPT09IDApIHJldHVybiB0aGlzOyAvLyBqdXN0IG9uZSBkZXN0aW5hdGlvbi4gIG1vc3QgY29tbW9uIGNhc2UuXG5cbiAgaWYgKHN0YXRlLnBpcGVzQ291bnQgPT09IDEpIHtcbiAgICAvLyBwYXNzZWQgaW4gb25lLCBidXQgaXQncyBub3QgdGhlIHJpZ2h0IG9uZS5cbiAgICBpZiAoZGVzdCAmJiBkZXN0ICE9PSBzdGF0ZS5waXBlcykgcmV0dXJuIHRoaXM7XG4gICAgaWYgKCFkZXN0KSBkZXN0ID0gc3RhdGUucGlwZXM7IC8vIGdvdCBhIG1hdGNoLlxuXG4gICAgc3RhdGUucGlwZXMgPSBudWxsO1xuICAgIHN0YXRlLnBpcGVzQ291bnQgPSAwO1xuICAgIHN0YXRlLmZsb3dpbmcgPSBmYWxzZTtcbiAgICBpZiAoZGVzdCkgZGVzdC5lbWl0KCd1bnBpcGUnLCB0aGlzLCB1bnBpcGVJbmZvKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfSAvLyBzbG93IGNhc2UuIG11bHRpcGxlIHBpcGUgZGVzdGluYXRpb25zLlxuXG5cbiAgaWYgKCFkZXN0KSB7XG4gICAgLy8gcmVtb3ZlIGFsbC5cbiAgICB2YXIgZGVzdHMgPSBzdGF0ZS5waXBlcztcbiAgICB2YXIgbGVuID0gc3RhdGUucGlwZXNDb3VudDtcbiAgICBzdGF0ZS5waXBlcyA9IG51bGw7XG4gICAgc3RhdGUucGlwZXNDb3VudCA9IDA7XG4gICAgc3RhdGUuZmxvd2luZyA9IGZhbHNlO1xuXG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW47IGkrKykge1xuICAgICAgZGVzdHNbaV0uZW1pdCgndW5waXBlJywgdGhpcywge1xuICAgICAgICBoYXNVbnBpcGVkOiBmYWxzZVxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXM7XG4gIH0gLy8gdHJ5IHRvIGZpbmQgdGhlIHJpZ2h0IG9uZS5cblxuXG4gIHZhciBpbmRleCA9IGluZGV4T2Yoc3RhdGUucGlwZXMsIGRlc3QpO1xuICBpZiAoaW5kZXggPT09IC0xKSByZXR1cm4gdGhpcztcbiAgc3RhdGUucGlwZXMuc3BsaWNlKGluZGV4LCAxKTtcbiAgc3RhdGUucGlwZXNDb3VudCAtPSAxO1xuICBpZiAoc3RhdGUucGlwZXNDb3VudCA9PT0gMSkgc3RhdGUucGlwZXMgPSBzdGF0ZS5waXBlc1swXTtcbiAgZGVzdC5lbWl0KCd1bnBpcGUnLCB0aGlzLCB1bnBpcGVJbmZvKTtcbiAgcmV0dXJuIHRoaXM7XG59OyAvLyBzZXQgdXAgZGF0YSBldmVudHMgaWYgdGhleSBhcmUgYXNrZWQgZm9yXG4vLyBFbnN1cmUgcmVhZGFibGUgbGlzdGVuZXJzIGV2ZW50dWFsbHkgZ2V0IHNvbWV0aGluZ1xuXG5cblJlYWRhYmxlLnByb3RvdHlwZS5vbiA9IGZ1bmN0aW9uIChldiwgZm4pIHtcbiAgdmFyIHJlcyA9IFN0cmVhbS5wcm90b3R5cGUub24uY2FsbCh0aGlzLCBldiwgZm4pO1xuICB2YXIgc3RhdGUgPSB0aGlzLl9yZWFkYWJsZVN0YXRlO1xuXG4gIGlmIChldiA9PT0gJ2RhdGEnKSB7XG4gICAgLy8gdXBkYXRlIHJlYWRhYmxlTGlzdGVuaW5nIHNvIHRoYXQgcmVzdW1lKCkgbWF5IGJlIGEgbm8tb3BcbiAgICAvLyBhIGZldyBsaW5lcyBkb3duLiBUaGlzIGlzIG5lZWRlZCB0byBzdXBwb3J0IG9uY2UoJ3JlYWRhYmxlJykuXG4gICAgc3RhdGUucmVhZGFibGVMaXN0ZW5pbmcgPSB0aGlzLmxpc3RlbmVyQ291bnQoJ3JlYWRhYmxlJykgPiAwOyAvLyBUcnkgc3RhcnQgZmxvd2luZyBvbiBuZXh0IHRpY2sgaWYgc3RyZWFtIGlzbid0IGV4cGxpY2l0bHkgcGF1c2VkXG5cbiAgICBpZiAoc3RhdGUuZmxvd2luZyAhPT0gZmFsc2UpIHRoaXMucmVzdW1lKCk7XG4gIH0gZWxzZSBpZiAoZXYgPT09ICdyZWFkYWJsZScpIHtcbiAgICBpZiAoIXN0YXRlLmVuZEVtaXR0ZWQgJiYgIXN0YXRlLnJlYWRhYmxlTGlzdGVuaW5nKSB7XG4gICAgICBzdGF0ZS5yZWFkYWJsZUxpc3RlbmluZyA9IHN0YXRlLm5lZWRSZWFkYWJsZSA9IHRydWU7XG4gICAgICBzdGF0ZS5mbG93aW5nID0gZmFsc2U7XG4gICAgICBzdGF0ZS5lbWl0dGVkUmVhZGFibGUgPSBmYWxzZTtcbiAgICAgIGRlYnVnKCdvbiByZWFkYWJsZScsIHN0YXRlLmxlbmd0aCwgc3RhdGUucmVhZGluZyk7XG5cbiAgICAgIGlmIChzdGF0ZS5sZW5ndGgpIHtcbiAgICAgICAgZW1pdFJlYWRhYmxlKHRoaXMpO1xuICAgICAgfSBlbHNlIGlmICghc3RhdGUucmVhZGluZykge1xuICAgICAgICBwcm9jZXNzLm5leHRUaWNrKG5SZWFkaW5nTmV4dFRpY2ssIHRoaXMpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiByZXM7XG59O1xuXG5SZWFkYWJsZS5wcm90b3R5cGUuYWRkTGlzdGVuZXIgPSBSZWFkYWJsZS5wcm90b3R5cGUub247XG5cblJlYWRhYmxlLnByb3RvdHlwZS5yZW1vdmVMaXN0ZW5lciA9IGZ1bmN0aW9uIChldiwgZm4pIHtcbiAgdmFyIHJlcyA9IFN0cmVhbS5wcm90b3R5cGUucmVtb3ZlTGlzdGVuZXIuY2FsbCh0aGlzLCBldiwgZm4pO1xuXG4gIGlmIChldiA9PT0gJ3JlYWRhYmxlJykge1xuICAgIC8vIFdlIG5lZWQgdG8gY2hlY2sgaWYgdGhlcmUgaXMgc29tZW9uZSBzdGlsbCBsaXN0ZW5pbmcgdG9cbiAgICAvLyByZWFkYWJsZSBhbmQgcmVzZXQgdGhlIHN0YXRlLiBIb3dldmVyIHRoaXMgbmVlZHMgdG8gaGFwcGVuXG4gICAgLy8gYWZ0ZXIgcmVhZGFibGUgaGFzIGJlZW4gZW1pdHRlZCBidXQgYmVmb3JlIEkvTyAobmV4dFRpY2spIHRvXG4gICAgLy8gc3VwcG9ydCBvbmNlKCdyZWFkYWJsZScsIGZuKSBjeWNsZXMuIFRoaXMgbWVhbnMgdGhhdCBjYWxsaW5nXG4gICAgLy8gcmVzdW1lIHdpdGhpbiB0aGUgc2FtZSB0aWNrIHdpbGwgaGF2ZSBub1xuICAgIC8vIGVmZmVjdC5cbiAgICBwcm9jZXNzLm5leHRUaWNrKHVwZGF0ZVJlYWRhYmxlTGlzdGVuaW5nLCB0aGlzKTtcbiAgfVxuXG4gIHJldHVybiByZXM7XG59O1xuXG5SZWFkYWJsZS5wcm90b3R5cGUucmVtb3ZlQWxsTGlzdGVuZXJzID0gZnVuY3Rpb24gKGV2KSB7XG4gIHZhciByZXMgPSBTdHJlYW0ucHJvdG90eXBlLnJlbW92ZUFsbExpc3RlbmVycy5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuXG4gIGlmIChldiA9PT0gJ3JlYWRhYmxlJyB8fCBldiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgLy8gV2UgbmVlZCB0byBjaGVjayBpZiB0aGVyZSBpcyBzb21lb25lIHN0aWxsIGxpc3RlbmluZyB0b1xuICAgIC8vIHJlYWRhYmxlIGFuZCByZXNldCB0aGUgc3RhdGUuIEhvd2V2ZXIgdGhpcyBuZWVkcyB0byBoYXBwZW5cbiAgICAvLyBhZnRlciByZWFkYWJsZSBoYXMgYmVlbiBlbWl0dGVkIGJ1dCBiZWZvcmUgSS9PIChuZXh0VGljaykgdG9cbiAgICAvLyBzdXBwb3J0IG9uY2UoJ3JlYWRhYmxlJywgZm4pIGN5Y2xlcy4gVGhpcyBtZWFucyB0aGF0IGNhbGxpbmdcbiAgICAvLyByZXN1bWUgd2l0aGluIHRoZSBzYW1lIHRpY2sgd2lsbCBoYXZlIG5vXG4gICAgLy8gZWZmZWN0LlxuICAgIHByb2Nlc3MubmV4dFRpY2sodXBkYXRlUmVhZGFibGVMaXN0ZW5pbmcsIHRoaXMpO1xuICB9XG5cbiAgcmV0dXJuIHJlcztcbn07XG5cbmZ1bmN0aW9uIHVwZGF0ZVJlYWRhYmxlTGlzdGVuaW5nKHNlbGYpIHtcbiAgdmFyIHN0YXRlID0gc2VsZi5fcmVhZGFibGVTdGF0ZTtcbiAgc3RhdGUucmVhZGFibGVMaXN0ZW5pbmcgPSBzZWxmLmxpc3RlbmVyQ291bnQoJ3JlYWRhYmxlJykgPiAwO1xuXG4gIGlmIChzdGF0ZS5yZXN1bWVTY2hlZHVsZWQgJiYgIXN0YXRlLnBhdXNlZCkge1xuICAgIC8vIGZsb3dpbmcgbmVlZHMgdG8gYmUgc2V0IHRvIHRydWUgbm93LCBvdGhlcndpc2VcbiAgICAvLyB0aGUgdXBjb21pbmcgcmVzdW1lIHdpbGwgbm90IGZsb3cuXG4gICAgc3RhdGUuZmxvd2luZyA9IHRydWU7IC8vIGNydWRlIHdheSB0byBjaGVjayBpZiB3ZSBzaG91bGQgcmVzdW1lXG4gIH0gZWxzZSBpZiAoc2VsZi5saXN0ZW5lckNvdW50KCdkYXRhJykgPiAwKSB7XG4gICAgc2VsZi5yZXN1bWUoKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBuUmVhZGluZ05leHRUaWNrKHNlbGYpIHtcbiAgZGVidWcoJ3JlYWRhYmxlIG5leHR0aWNrIHJlYWQgMCcpO1xuICBzZWxmLnJlYWQoMCk7XG59IC8vIHBhdXNlKCkgYW5kIHJlc3VtZSgpIGFyZSByZW1uYW50cyBvZiB0aGUgbGVnYWN5IHJlYWRhYmxlIHN0cmVhbSBBUElcbi8vIElmIHRoZSB1c2VyIHVzZXMgdGhlbSwgdGhlbiBzd2l0Y2ggaW50byBvbGQgbW9kZS5cblxuXG5SZWFkYWJsZS5wcm90b3R5cGUucmVzdW1lID0gZnVuY3Rpb24gKCkge1xuICB2YXIgc3RhdGUgPSB0aGlzLl9yZWFkYWJsZVN0YXRlO1xuXG4gIGlmICghc3RhdGUuZmxvd2luZykge1xuICAgIGRlYnVnKCdyZXN1bWUnKTsgLy8gd2UgZmxvdyBvbmx5IGlmIHRoZXJlIGlzIG5vIG9uZSBsaXN0ZW5pbmdcbiAgICAvLyBmb3IgcmVhZGFibGUsIGJ1dCB3ZSBzdGlsbCBoYXZlIHRvIGNhbGxcbiAgICAvLyByZXN1bWUoKVxuXG4gICAgc3RhdGUuZmxvd2luZyA9ICFzdGF0ZS5yZWFkYWJsZUxpc3RlbmluZztcbiAgICByZXN1bWUodGhpcywgc3RhdGUpO1xuICB9XG5cbiAgc3RhdGUucGF1c2VkID0gZmFsc2U7XG4gIHJldHVybiB0aGlzO1xufTtcblxuZnVuY3Rpb24gcmVzdW1lKHN0cmVhbSwgc3RhdGUpIHtcbiAgaWYgKCFzdGF0ZS5yZXN1bWVTY2hlZHVsZWQpIHtcbiAgICBzdGF0ZS5yZXN1bWVTY2hlZHVsZWQgPSB0cnVlO1xuICAgIHByb2Nlc3MubmV4dFRpY2socmVzdW1lXywgc3RyZWFtLCBzdGF0ZSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gcmVzdW1lXyhzdHJlYW0sIHN0YXRlKSB7XG4gIGRlYnVnKCdyZXN1bWUnLCBzdGF0ZS5yZWFkaW5nKTtcblxuICBpZiAoIXN0YXRlLnJlYWRpbmcpIHtcbiAgICBzdHJlYW0ucmVhZCgwKTtcbiAgfVxuXG4gIHN0YXRlLnJlc3VtZVNjaGVkdWxlZCA9IGZhbHNlO1xuICBzdHJlYW0uZW1pdCgncmVzdW1lJyk7XG4gIGZsb3coc3RyZWFtKTtcbiAgaWYgKHN0YXRlLmZsb3dpbmcgJiYgIXN0YXRlLnJlYWRpbmcpIHN0cmVhbS5yZWFkKDApO1xufVxuXG5SZWFkYWJsZS5wcm90b3R5cGUucGF1c2UgPSBmdW5jdGlvbiAoKSB7XG4gIGRlYnVnKCdjYWxsIHBhdXNlIGZsb3dpbmc9JWonLCB0aGlzLl9yZWFkYWJsZVN0YXRlLmZsb3dpbmcpO1xuXG4gIGlmICh0aGlzLl9yZWFkYWJsZVN0YXRlLmZsb3dpbmcgIT09IGZhbHNlKSB7XG4gICAgZGVidWcoJ3BhdXNlJyk7XG4gICAgdGhpcy5fcmVhZGFibGVTdGF0ZS5mbG93aW5nID0gZmFsc2U7XG4gICAgdGhpcy5lbWl0KCdwYXVzZScpO1xuICB9XG5cbiAgdGhpcy5fcmVhZGFibGVTdGF0ZS5wYXVzZWQgPSB0cnVlO1xuICByZXR1cm4gdGhpcztcbn07XG5cbmZ1bmN0aW9uIGZsb3coc3RyZWFtKSB7XG4gIHZhciBzdGF0ZSA9IHN0cmVhbS5fcmVhZGFibGVTdGF0ZTtcbiAgZGVidWcoJ2Zsb3cnLCBzdGF0ZS5mbG93aW5nKTtcblxuICB3aGlsZSAoc3RhdGUuZmxvd2luZyAmJiBzdHJlYW0ucmVhZCgpICE9PSBudWxsKSB7XG4gICAgO1xuICB9XG59IC8vIHdyYXAgYW4gb2xkLXN0eWxlIHN0cmVhbSBhcyB0aGUgYXN5bmMgZGF0YSBzb3VyY2UuXG4vLyBUaGlzIGlzICpub3QqIHBhcnQgb2YgdGhlIHJlYWRhYmxlIHN0cmVhbSBpbnRlcmZhY2UuXG4vLyBJdCBpcyBhbiB1Z2x5IHVuZm9ydHVuYXRlIG1lc3Mgb2YgaGlzdG9yeS5cblxuXG5SZWFkYWJsZS5wcm90b3R5cGUud3JhcCA9IGZ1bmN0aW9uIChzdHJlYW0pIHtcbiAgdmFyIF90aGlzID0gdGhpcztcblxuICB2YXIgc3RhdGUgPSB0aGlzLl9yZWFkYWJsZVN0YXRlO1xuICB2YXIgcGF1c2VkID0gZmFsc2U7XG4gIHN0cmVhbS5vbignZW5kJywgZnVuY3Rpb24gKCkge1xuICAgIGRlYnVnKCd3cmFwcGVkIGVuZCcpO1xuXG4gICAgaWYgKHN0YXRlLmRlY29kZXIgJiYgIXN0YXRlLmVuZGVkKSB7XG4gICAgICB2YXIgY2h1bmsgPSBzdGF0ZS5kZWNvZGVyLmVuZCgpO1xuICAgICAgaWYgKGNodW5rICYmIGNodW5rLmxlbmd0aCkgX3RoaXMucHVzaChjaHVuayk7XG4gICAgfVxuXG4gICAgX3RoaXMucHVzaChudWxsKTtcbiAgfSk7XG4gIHN0cmVhbS5vbignZGF0YScsIGZ1bmN0aW9uIChjaHVuaykge1xuICAgIGRlYnVnKCd3cmFwcGVkIGRhdGEnKTtcbiAgICBpZiAoc3RhdGUuZGVjb2RlcikgY2h1bmsgPSBzdGF0ZS5kZWNvZGVyLndyaXRlKGNodW5rKTsgLy8gZG9uJ3Qgc2tpcCBvdmVyIGZhbHN5IHZhbHVlcyBpbiBvYmplY3RNb2RlXG5cbiAgICBpZiAoc3RhdGUub2JqZWN0TW9kZSAmJiAoY2h1bmsgPT09IG51bGwgfHwgY2h1bmsgPT09IHVuZGVmaW5lZCkpIHJldHVybjtlbHNlIGlmICghc3RhdGUub2JqZWN0TW9kZSAmJiAoIWNodW5rIHx8ICFjaHVuay5sZW5ndGgpKSByZXR1cm47XG5cbiAgICB2YXIgcmV0ID0gX3RoaXMucHVzaChjaHVuayk7XG5cbiAgICBpZiAoIXJldCkge1xuICAgICAgcGF1c2VkID0gdHJ1ZTtcbiAgICAgIHN0cmVhbS5wYXVzZSgpO1xuICAgIH1cbiAgfSk7IC8vIHByb3h5IGFsbCB0aGUgb3RoZXIgbWV0aG9kcy5cbiAgLy8gaW1wb3J0YW50IHdoZW4gd3JhcHBpbmcgZmlsdGVycyBhbmQgZHVwbGV4ZXMuXG5cbiAgZm9yICh2YXIgaSBpbiBzdHJlYW0pIHtcbiAgICBpZiAodGhpc1tpXSA9PT0gdW5kZWZpbmVkICYmIHR5cGVvZiBzdHJlYW1baV0gPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIHRoaXNbaV0gPSBmdW5jdGlvbiBtZXRob2RXcmFwKG1ldGhvZCkge1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24gbWV0aG9kV3JhcFJldHVybkZ1bmN0aW9uKCkge1xuICAgICAgICAgIHJldHVybiBzdHJlYW1bbWV0aG9kXS5hcHBseShzdHJlYW0sIGFyZ3VtZW50cyk7XG4gICAgICAgIH07XG4gICAgICB9KGkpO1xuICAgIH1cbiAgfSAvLyBwcm94eSBjZXJ0YWluIGltcG9ydGFudCBldmVudHMuXG5cblxuICBmb3IgKHZhciBuID0gMDsgbiA8IGtQcm94eUV2ZW50cy5sZW5ndGg7IG4rKykge1xuICAgIHN0cmVhbS5vbihrUHJveHlFdmVudHNbbl0sIHRoaXMuZW1pdC5iaW5kKHRoaXMsIGtQcm94eUV2ZW50c1tuXSkpO1xuICB9IC8vIHdoZW4gd2UgdHJ5IHRvIGNvbnN1bWUgc29tZSBtb3JlIGJ5dGVzLCBzaW1wbHkgdW5wYXVzZSB0aGVcbiAgLy8gdW5kZXJseWluZyBzdHJlYW0uXG5cblxuICB0aGlzLl9yZWFkID0gZnVuY3Rpb24gKG4pIHtcbiAgICBkZWJ1Zygnd3JhcHBlZCBfcmVhZCcsIG4pO1xuXG4gICAgaWYgKHBhdXNlZCkge1xuICAgICAgcGF1c2VkID0gZmFsc2U7XG4gICAgICBzdHJlYW0ucmVzdW1lKCk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiB0aGlzO1xufTtcblxuaWYgKHR5cGVvZiBTeW1ib2wgPT09ICdmdW5jdGlvbicpIHtcbiAgUmVhZGFibGUucHJvdG90eXBlW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoY3JlYXRlUmVhZGFibGVTdHJlYW1Bc3luY0l0ZXJhdG9yID09PSB1bmRlZmluZWQpIHtcbiAgICAgIGNyZWF0ZVJlYWRhYmxlU3RyZWFtQXN5bmNJdGVyYXRvciA9IHJlcXVpcmUoJy4vaW50ZXJuYWwvc3RyZWFtcy9hc3luY19pdGVyYXRvcicpO1xuICAgIH1cblxuICAgIHJldHVybiBjcmVhdGVSZWFkYWJsZVN0cmVhbUFzeW5jSXRlcmF0b3IodGhpcyk7XG4gIH07XG59XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShSZWFkYWJsZS5wcm90b3R5cGUsICdyZWFkYWJsZUhpZ2hXYXRlck1hcmsnLCB7XG4gIC8vIG1ha2luZyBpdCBleHBsaWNpdCB0aGlzIHByb3BlcnR5IGlzIG5vdCBlbnVtZXJhYmxlXG4gIC8vIGJlY2F1c2Ugb3RoZXJ3aXNlIHNvbWUgcHJvdG90eXBlIG1hbmlwdWxhdGlvbiBpblxuICAvLyB1c2VybGFuZCB3aWxsIGZhaWxcbiAgZW51bWVyYWJsZTogZmFsc2UsXG4gIGdldDogZnVuY3Rpb24gZ2V0KCkge1xuICAgIHJldHVybiB0aGlzLl9yZWFkYWJsZVN0YXRlLmhpZ2hXYXRlck1hcms7XG4gIH1cbn0pO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KFJlYWRhYmxlLnByb3RvdHlwZSwgJ3JlYWRhYmxlQnVmZmVyJywge1xuICAvLyBtYWtpbmcgaXQgZXhwbGljaXQgdGhpcyBwcm9wZXJ0eSBpcyBub3QgZW51bWVyYWJsZVxuICAvLyBiZWNhdXNlIG90aGVyd2lzZSBzb21lIHByb3RvdHlwZSBtYW5pcHVsYXRpb24gaW5cbiAgLy8gdXNlcmxhbmQgd2lsbCBmYWlsXG4gIGVudW1lcmFibGU6IGZhbHNlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcmVhZGFibGVTdGF0ZSAmJiB0aGlzLl9yZWFkYWJsZVN0YXRlLmJ1ZmZlcjtcbiAgfVxufSk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoUmVhZGFibGUucHJvdG90eXBlLCAncmVhZGFibGVGbG93aW5nJywge1xuICAvLyBtYWtpbmcgaXQgZXhwbGljaXQgdGhpcyBwcm9wZXJ0eSBpcyBub3QgZW51bWVyYWJsZVxuICAvLyBiZWNhdXNlIG90aGVyd2lzZSBzb21lIHByb3RvdHlwZSBtYW5pcHVsYXRpb24gaW5cbiAgLy8gdXNlcmxhbmQgd2lsbCBmYWlsXG4gIGVudW1lcmFibGU6IGZhbHNlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcmVhZGFibGVTdGF0ZS5mbG93aW5nO1xuICB9LFxuICBzZXQ6IGZ1bmN0aW9uIHNldChzdGF0ZSkge1xuICAgIGlmICh0aGlzLl9yZWFkYWJsZVN0YXRlKSB7XG4gICAgICB0aGlzLl9yZWFkYWJsZVN0YXRlLmZsb3dpbmcgPSBzdGF0ZTtcbiAgICB9XG4gIH1cbn0pOyAvLyBleHBvc2VkIGZvciB0ZXN0aW5nIHB1cnBvc2VzIG9ubHkuXG5cblJlYWRhYmxlLl9mcm9tTGlzdCA9IGZyb21MaXN0O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KFJlYWRhYmxlLnByb3RvdHlwZSwgJ3JlYWRhYmxlTGVuZ3RoJywge1xuICAvLyBtYWtpbmcgaXQgZXhwbGljaXQgdGhpcyBwcm9wZXJ0eSBpcyBub3QgZW51bWVyYWJsZVxuICAvLyBiZWNhdXNlIG90aGVyd2lzZSBzb21lIHByb3RvdHlwZSBtYW5pcHVsYXRpb24gaW5cbiAgLy8gdXNlcmxhbmQgd2lsbCBmYWlsXG4gIGVudW1lcmFibGU6IGZhbHNlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcmVhZGFibGVTdGF0ZS5sZW5ndGg7XG4gIH1cbn0pOyAvLyBQbHVjayBvZmYgbiBieXRlcyBmcm9tIGFuIGFycmF5IG9mIGJ1ZmZlcnMuXG4vLyBMZW5ndGggaXMgdGhlIGNvbWJpbmVkIGxlbmd0aHMgb2YgYWxsIHRoZSBidWZmZXJzIGluIHRoZSBsaXN0LlxuLy8gVGhpcyBmdW5jdGlvbiBpcyBkZXNpZ25lZCB0byBiZSBpbmxpbmFibGUsIHNvIHBsZWFzZSB0YWtlIGNhcmUgd2hlbiBtYWtpbmdcbi8vIGNoYW5nZXMgdG8gdGhlIGZ1bmN0aW9uIGJvZHkuXG5cbmZ1bmN0aW9uIGZyb21MaXN0KG4sIHN0YXRlKSB7XG4gIC8vIG5vdGhpbmcgYnVmZmVyZWRcbiAgaWYgKHN0YXRlLmxlbmd0aCA9PT0gMCkgcmV0dXJuIG51bGw7XG4gIHZhciByZXQ7XG4gIGlmIChzdGF0ZS5vYmplY3RNb2RlKSByZXQgPSBzdGF0ZS5idWZmZXIuc2hpZnQoKTtlbHNlIGlmICghbiB8fCBuID49IHN0YXRlLmxlbmd0aCkge1xuICAgIC8vIHJlYWQgaXQgYWxsLCB0cnVuY2F0ZSB0aGUgbGlzdFxuICAgIGlmIChzdGF0ZS5kZWNvZGVyKSByZXQgPSBzdGF0ZS5idWZmZXIuam9pbignJyk7ZWxzZSBpZiAoc3RhdGUuYnVmZmVyLmxlbmd0aCA9PT0gMSkgcmV0ID0gc3RhdGUuYnVmZmVyLmZpcnN0KCk7ZWxzZSByZXQgPSBzdGF0ZS5idWZmZXIuY29uY2F0KHN0YXRlLmxlbmd0aCk7XG4gICAgc3RhdGUuYnVmZmVyLmNsZWFyKCk7XG4gIH0gZWxzZSB7XG4gICAgLy8gcmVhZCBwYXJ0IG9mIGxpc3RcbiAgICByZXQgPSBzdGF0ZS5idWZmZXIuY29uc3VtZShuLCBzdGF0ZS5kZWNvZGVyKTtcbiAgfVxuICByZXR1cm4gcmV0O1xufVxuXG5mdW5jdGlvbiBlbmRSZWFkYWJsZShzdHJlYW0pIHtcbiAgdmFyIHN0YXRlID0gc3RyZWFtLl9yZWFkYWJsZVN0YXRlO1xuICBkZWJ1ZygnZW5kUmVhZGFibGUnLCBzdGF0ZS5lbmRFbWl0dGVkKTtcblxuICBpZiAoIXN0YXRlLmVuZEVtaXR0ZWQpIHtcbiAgICBzdGF0ZS5lbmRlZCA9IHRydWU7XG4gICAgcHJvY2Vzcy5uZXh0VGljayhlbmRSZWFkYWJsZU5ULCBzdGF0ZSwgc3RyZWFtKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBlbmRSZWFkYWJsZU5UKHN0YXRlLCBzdHJlYW0pIHtcbiAgZGVidWcoJ2VuZFJlYWRhYmxlTlQnLCBzdGF0ZS5lbmRFbWl0dGVkLCBzdGF0ZS5sZW5ndGgpOyAvLyBDaGVjayB0aGF0IHdlIGRpZG4ndCBnZXQgb25lIGxhc3QgdW5zaGlmdC5cblxuICBpZiAoIXN0YXRlLmVuZEVtaXR0ZWQgJiYgc3RhdGUubGVuZ3RoID09PSAwKSB7XG4gICAgc3RhdGUuZW5kRW1pdHRlZCA9IHRydWU7XG4gICAgc3RyZWFtLnJlYWRhYmxlID0gZmFsc2U7XG4gICAgc3RyZWFtLmVtaXQoJ2VuZCcpO1xuXG4gICAgaWYgKHN0YXRlLmF1dG9EZXN0cm95KSB7XG4gICAgICAvLyBJbiBjYXNlIG9mIGR1cGxleCBzdHJlYW1zIHdlIG5lZWQgYSB3YXkgdG8gZGV0ZWN0XG4gICAgICAvLyBpZiB0aGUgd3JpdGFibGUgc2lkZSBpcyByZWFkeSBmb3IgYXV0b0Rlc3Ryb3kgYXMgd2VsbFxuICAgICAgdmFyIHdTdGF0ZSA9IHN0cmVhbS5fd3JpdGFibGVTdGF0ZTtcblxuICAgICAgaWYgKCF3U3RhdGUgfHwgd1N0YXRlLmF1dG9EZXN0cm95ICYmIHdTdGF0ZS5maW5pc2hlZCkge1xuICAgICAgICBzdHJlYW0uZGVzdHJveSgpO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG5pZiAodHlwZW9mIFN5bWJvbCA9PT0gJ2Z1bmN0aW9uJykge1xuICBSZWFkYWJsZS5mcm9tID0gZnVuY3Rpb24gKGl0ZXJhYmxlLCBvcHRzKSB7XG4gICAgaWYgKGZyb20gPT09IHVuZGVmaW5lZCkge1xuICAgICAgZnJvbSA9IHJlcXVpcmUoJy4vaW50ZXJuYWwvc3RyZWFtcy9mcm9tJyk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGZyb20oUmVhZGFibGUsIGl0ZXJhYmxlLCBvcHRzKTtcbiAgfTtcbn1cblxuZnVuY3Rpb24gaW5kZXhPZih4cywgeCkge1xuICBmb3IgKHZhciBpID0gMCwgbCA9IHhzLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuICAgIGlmICh4c1tpXSA9PT0geCkgcmV0dXJuIGk7XG4gIH1cblxuICByZXR1cm4gLTE7XG59IiwiLy8gQ29weXJpZ2h0IEpveWVudCwgSW5jLiBhbmQgb3RoZXIgTm9kZSBjb250cmlidXRvcnMuXG4vL1xuLy8gUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb24gb2J0YWluaW5nIGFcbi8vIGNvcHkgb2YgdGhpcyBzb2Z0d2FyZSBhbmQgYXNzb2NpYXRlZCBkb2N1bWVudGF0aW9uIGZpbGVzICh0aGVcbi8vIFwiU29mdHdhcmVcIiksIHRvIGRlYWwgaW4gdGhlIFNvZnR3YXJlIHdpdGhvdXQgcmVzdHJpY3Rpb24sIGluY2x1ZGluZ1xuLy8gd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMgdG8gdXNlLCBjb3B5LCBtb2RpZnksIG1lcmdlLCBwdWJsaXNoLFxuLy8gZGlzdHJpYnV0ZSwgc3VibGljZW5zZSwgYW5kL29yIHNlbGwgY29waWVzIG9mIHRoZSBTb2Z0d2FyZSwgYW5kIHRvIHBlcm1pdFxuLy8gcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpcyBmdXJuaXNoZWQgdG8gZG8gc28sIHN1YmplY3QgdG8gdGhlXG4vLyBmb2xsb3dpbmcgY29uZGl0aW9uczpcbi8vXG4vLyBUaGUgYWJvdmUgY29weXJpZ2h0IG5vdGljZSBhbmQgdGhpcyBwZXJtaXNzaW9uIG5vdGljZSBzaGFsbCBiZSBpbmNsdWRlZFxuLy8gaW4gYWxsIGNvcGllcyBvciBzdWJzdGFudGlhbCBwb3J0aW9ucyBvZiB0aGUgU29mdHdhcmUuXG4vL1xuLy8gVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiwgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCwgRVhQUkVTU1xuLy8gT1IgSU1QTElFRCwgSU5DTFVESU5HIEJVVCBOT1QgTElNSVRFRCBUTyBUSEUgV0FSUkFOVElFUyBPRlxuLy8gTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTlxuLy8gTk8gRVZFTlQgU0hBTEwgVEhFIEFVVEhPUlMgT1IgQ09QWVJJR0hUIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTlkgQ0xBSU0sXG4vLyBEQU1BR0VTIE9SIE9USEVSIExJQUJJTElUWSwgV0hFVEhFUiBJTiBBTiBBQ1RJT04gT0YgQ09OVFJBQ1QsIFRPUlQgT1Jcbi8vIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRSBTT0ZUV0FSRSBPUiBUSEVcbi8vIFVTRSBPUiBPVEhFUiBERUFMSU5HUyBJTiBUSEUgU09GVFdBUkUuXG4vLyBhIHRyYW5zZm9ybSBzdHJlYW0gaXMgYSByZWFkYWJsZS93cml0YWJsZSBzdHJlYW0gd2hlcmUgeW91IGRvXG4vLyBzb21ldGhpbmcgd2l0aCB0aGUgZGF0YS4gIFNvbWV0aW1lcyBpdCdzIGNhbGxlZCBhIFwiZmlsdGVyXCIsXG4vLyBidXQgdGhhdCdzIG5vdCBhIGdyZWF0IG5hbWUgZm9yIGl0LCBzaW5jZSB0aGF0IGltcGxpZXMgYSB0aGluZyB3aGVyZVxuLy8gc29tZSBiaXRzIHBhc3MgdGhyb3VnaCwgYW5kIG90aGVycyBhcmUgc2ltcGx5IGlnbm9yZWQuICAoVGhhdCB3b3VsZFxuLy8gYmUgYSB2YWxpZCBleGFtcGxlIG9mIGEgdHJhbnNmb3JtLCBvZiBjb3Vyc2UuKVxuLy9cbi8vIFdoaWxlIHRoZSBvdXRwdXQgaXMgY2F1c2FsbHkgcmVsYXRlZCB0byB0aGUgaW5wdXQsIGl0J3Mgbm90IGFcbi8vIG5lY2Vzc2FyaWx5IHN5bW1ldHJpYyBvciBzeW5jaHJvbm91cyB0cmFuc2Zvcm1hdGlvbi4gIEZvciBleGFtcGxlLFxuLy8gYSB6bGliIHN0cmVhbSBtaWdodCB0YWtlIG11bHRpcGxlIHBsYWluLXRleHQgd3JpdGVzKCksIGFuZCB0aGVuXG4vLyBlbWl0IGEgc2luZ2xlIGNvbXByZXNzZWQgY2h1bmsgc29tZSB0aW1lIGluIHRoZSBmdXR1cmUuXG4vL1xuLy8gSGVyZSdzIGhvdyB0aGlzIHdvcmtzOlxuLy9cbi8vIFRoZSBUcmFuc2Zvcm0gc3RyZWFtIGhhcyBhbGwgdGhlIGFzcGVjdHMgb2YgdGhlIHJlYWRhYmxlIGFuZCB3cml0YWJsZVxuLy8gc3RyZWFtIGNsYXNzZXMuICBXaGVuIHlvdSB3cml0ZShjaHVuayksIHRoYXQgY2FsbHMgX3dyaXRlKGNodW5rLGNiKVxuLy8gaW50ZXJuYWxseSwgYW5kIHJldHVybnMgZmFsc2UgaWYgdGhlcmUncyBhIGxvdCBvZiBwZW5kaW5nIHdyaXRlc1xuLy8gYnVmZmVyZWQgdXAuICBXaGVuIHlvdSBjYWxsIHJlYWQoKSwgdGhhdCBjYWxscyBfcmVhZChuKSB1bnRpbFxuLy8gdGhlcmUncyBlbm91Z2ggcGVuZGluZyByZWFkYWJsZSBkYXRhIGJ1ZmZlcmVkIHVwLlxuLy9cbi8vIEluIGEgdHJhbnNmb3JtIHN0cmVhbSwgdGhlIHdyaXR0ZW4gZGF0YSBpcyBwbGFjZWQgaW4gYSBidWZmZXIuICBXaGVuXG4vLyBfcmVhZChuKSBpcyBjYWxsZWQsIGl0IHRyYW5zZm9ybXMgdGhlIHF1ZXVlZCB1cCBkYXRhLCBjYWxsaW5nIHRoZVxuLy8gYnVmZmVyZWQgX3dyaXRlIGNiJ3MgYXMgaXQgY29uc3VtZXMgY2h1bmtzLiAgSWYgY29uc3VtaW5nIGEgc2luZ2xlXG4vLyB3cml0dGVuIGNodW5rIHdvdWxkIHJlc3VsdCBpbiBtdWx0aXBsZSBvdXRwdXQgY2h1bmtzLCB0aGVuIHRoZSBmaXJzdFxuLy8gb3V0cHV0dGVkIGJpdCBjYWxscyB0aGUgcmVhZGNiLCBhbmQgc3Vic2VxdWVudCBjaHVua3MganVzdCBnbyBpbnRvXG4vLyB0aGUgcmVhZCBidWZmZXIsIGFuZCB3aWxsIGNhdXNlIGl0IHRvIGVtaXQgJ3JlYWRhYmxlJyBpZiBuZWNlc3NhcnkuXG4vL1xuLy8gVGhpcyB3YXksIGJhY2stcHJlc3N1cmUgaXMgYWN0dWFsbHkgZGV0ZXJtaW5lZCBieSB0aGUgcmVhZGluZyBzaWRlLFxuLy8gc2luY2UgX3JlYWQgaGFzIHRvIGJlIGNhbGxlZCB0byBzdGFydCBwcm9jZXNzaW5nIGEgbmV3IGNodW5rLiAgSG93ZXZlcixcbi8vIGEgcGF0aG9sb2dpY2FsIGluZmxhdGUgdHlwZSBvZiB0cmFuc2Zvcm0gY2FuIGNhdXNlIGV4Y2Vzc2l2ZSBidWZmZXJpbmdcbi8vIGhlcmUuICBGb3IgZXhhbXBsZSwgaW1hZ2luZSBhIHN0cmVhbSB3aGVyZSBldmVyeSBieXRlIG9mIGlucHV0IGlzXG4vLyBpbnRlcnByZXRlZCBhcyBhbiBpbnRlZ2VyIGZyb20gMC0yNTUsIGFuZCB0aGVuIHJlc3VsdHMgaW4gdGhhdCBtYW55XG4vLyBieXRlcyBvZiBvdXRwdXQuICBXcml0aW5nIHRoZSA0IGJ5dGVzIHtmZixmZixmZixmZn0gd291bGQgcmVzdWx0IGluXG4vLyAxa2Igb2YgZGF0YSBiZWluZyBvdXRwdXQuICBJbiB0aGlzIGNhc2UsIHlvdSBjb3VsZCB3cml0ZSBhIHZlcnkgc21hbGxcbi8vIGFtb3VudCBvZiBpbnB1dCwgYW5kIGVuZCB1cCB3aXRoIGEgdmVyeSBsYXJnZSBhbW91bnQgb2Ygb3V0cHV0LiAgSW5cbi8vIHN1Y2ggYSBwYXRob2xvZ2ljYWwgaW5mbGF0aW5nIG1lY2hhbmlzbSwgdGhlcmUnZCBiZSBubyB3YXkgdG8gdGVsbFxuLy8gdGhlIHN5c3RlbSB0byBzdG9wIGRvaW5nIHRoZSB0cmFuc2Zvcm0uICBBIHNpbmdsZSA0TUIgd3JpdGUgY291bGRcbi8vIGNhdXNlIHRoZSBzeXN0ZW0gdG8gcnVuIG91dCBvZiBtZW1vcnkuXG4vL1xuLy8gSG93ZXZlciwgZXZlbiBpbiBzdWNoIGEgcGF0aG9sb2dpY2FsIGNhc2UsIG9ubHkgYSBzaW5nbGUgd3JpdHRlbiBjaHVua1xuLy8gd291bGQgYmUgY29uc3VtZWQsIGFuZCB0aGVuIHRoZSByZXN0IHdvdWxkIHdhaXQgKHVuLXRyYW5zZm9ybWVkKSB1bnRpbFxuLy8gdGhlIHJlc3VsdHMgb2YgdGhlIHByZXZpb3VzIHRyYW5zZm9ybWVkIGNodW5rIHdlcmUgY29uc3VtZWQuXG4ndXNlIHN0cmljdCc7XG5cbm1vZHVsZS5leHBvcnRzID0gVHJhbnNmb3JtO1xuXG52YXIgX3JlcXVpcmUkY29kZXMgPSByZXF1aXJlKCcuLi9lcnJvcnMnKS5jb2RlcyxcbiAgICBFUlJfTUVUSE9EX05PVF9JTVBMRU1FTlRFRCA9IF9yZXF1aXJlJGNvZGVzLkVSUl9NRVRIT0RfTk9UX0lNUExFTUVOVEVELFxuICAgIEVSUl9NVUxUSVBMRV9DQUxMQkFDSyA9IF9yZXF1aXJlJGNvZGVzLkVSUl9NVUxUSVBMRV9DQUxMQkFDSyxcbiAgICBFUlJfVFJBTlNGT1JNX0FMUkVBRFlfVFJBTlNGT1JNSU5HID0gX3JlcXVpcmUkY29kZXMuRVJSX1RSQU5TRk9STV9BTFJFQURZX1RSQU5TRk9STUlORyxcbiAgICBFUlJfVFJBTlNGT1JNX1dJVEhfTEVOR1RIXzAgPSBfcmVxdWlyZSRjb2Rlcy5FUlJfVFJBTlNGT1JNX1dJVEhfTEVOR1RIXzA7XG5cbnZhciBEdXBsZXggPSByZXF1aXJlKCcuL19zdHJlYW1fZHVwbGV4Jyk7XG5cbnJlcXVpcmUoJ2luaGVyaXRzJykoVHJhbnNmb3JtLCBEdXBsZXgpO1xuXG5mdW5jdGlvbiBhZnRlclRyYW5zZm9ybShlciwgZGF0YSkge1xuICB2YXIgdHMgPSB0aGlzLl90cmFuc2Zvcm1TdGF0ZTtcbiAgdHMudHJhbnNmb3JtaW5nID0gZmFsc2U7XG4gIHZhciBjYiA9IHRzLndyaXRlY2I7XG5cbiAgaWYgKGNiID09PSBudWxsKSB7XG4gICAgcmV0dXJuIHRoaXMuZW1pdCgnZXJyb3InLCBuZXcgRVJSX01VTFRJUExFX0NBTExCQUNLKCkpO1xuICB9XG5cbiAgdHMud3JpdGVjaHVuayA9IG51bGw7XG4gIHRzLndyaXRlY2IgPSBudWxsO1xuICBpZiAoZGF0YSAhPSBudWxsKSAvLyBzaW5nbGUgZXF1YWxzIGNoZWNrIGZvciBib3RoIGBudWxsYCBhbmQgYHVuZGVmaW5lZGBcbiAgICB0aGlzLnB1c2goZGF0YSk7XG4gIGNiKGVyKTtcbiAgdmFyIHJzID0gdGhpcy5fcmVhZGFibGVTdGF0ZTtcbiAgcnMucmVhZGluZyA9IGZhbHNlO1xuXG4gIGlmIChycy5uZWVkUmVhZGFibGUgfHwgcnMubGVuZ3RoIDwgcnMuaGlnaFdhdGVyTWFyaykge1xuICAgIHRoaXMuX3JlYWQocnMuaGlnaFdhdGVyTWFyayk7XG4gIH1cbn1cblxuZnVuY3Rpb24gVHJhbnNmb3JtKG9wdGlvbnMpIHtcbiAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIFRyYW5zZm9ybSkpIHJldHVybiBuZXcgVHJhbnNmb3JtKG9wdGlvbnMpO1xuICBEdXBsZXguY2FsbCh0aGlzLCBvcHRpb25zKTtcbiAgdGhpcy5fdHJhbnNmb3JtU3RhdGUgPSB7XG4gICAgYWZ0ZXJUcmFuc2Zvcm06IGFmdGVyVHJhbnNmb3JtLmJpbmQodGhpcyksXG4gICAgbmVlZFRyYW5zZm9ybTogZmFsc2UsXG4gICAgdHJhbnNmb3JtaW5nOiBmYWxzZSxcbiAgICB3cml0ZWNiOiBudWxsLFxuICAgIHdyaXRlY2h1bms6IG51bGwsXG4gICAgd3JpdGVlbmNvZGluZzogbnVsbFxuICB9OyAvLyBzdGFydCBvdXQgYXNraW5nIGZvciBhIHJlYWRhYmxlIGV2ZW50IG9uY2UgZGF0YSBpcyB0cmFuc2Zvcm1lZC5cblxuICB0aGlzLl9yZWFkYWJsZVN0YXRlLm5lZWRSZWFkYWJsZSA9IHRydWU7IC8vIHdlIGhhdmUgaW1wbGVtZW50ZWQgdGhlIF9yZWFkIG1ldGhvZCwgYW5kIGRvbmUgdGhlIG90aGVyIHRoaW5nc1xuICAvLyB0aGF0IFJlYWRhYmxlIHdhbnRzIGJlZm9yZSB0aGUgZmlyc3QgX3JlYWQgY2FsbCwgc28gdW5zZXQgdGhlXG4gIC8vIHN5bmMgZ3VhcmQgZmxhZy5cblxuICB0aGlzLl9yZWFkYWJsZVN0YXRlLnN5bmMgPSBmYWxzZTtcblxuICBpZiAob3B0aW9ucykge1xuICAgIGlmICh0eXBlb2Ygb3B0aW9ucy50cmFuc2Zvcm0gPT09ICdmdW5jdGlvbicpIHRoaXMuX3RyYW5zZm9ybSA9IG9wdGlvbnMudHJhbnNmb3JtO1xuICAgIGlmICh0eXBlb2Ygb3B0aW9ucy5mbHVzaCA9PT0gJ2Z1bmN0aW9uJykgdGhpcy5fZmx1c2ggPSBvcHRpb25zLmZsdXNoO1xuICB9IC8vIFdoZW4gdGhlIHdyaXRhYmxlIHNpZGUgZmluaXNoZXMsIHRoZW4gZmx1c2ggb3V0IGFueXRoaW5nIHJlbWFpbmluZy5cblxuXG4gIHRoaXMub24oJ3ByZWZpbmlzaCcsIHByZWZpbmlzaCk7XG59XG5cbmZ1bmN0aW9uIHByZWZpbmlzaCgpIHtcbiAgdmFyIF90aGlzID0gdGhpcztcblxuICBpZiAodHlwZW9mIHRoaXMuX2ZsdXNoID09PSAnZnVuY3Rpb24nICYmICF0aGlzLl9yZWFkYWJsZVN0YXRlLmRlc3Ryb3llZCkge1xuICAgIHRoaXMuX2ZsdXNoKGZ1bmN0aW9uIChlciwgZGF0YSkge1xuICAgICAgZG9uZShfdGhpcywgZXIsIGRhdGEpO1xuICAgIH0pO1xuICB9IGVsc2Uge1xuICAgIGRvbmUodGhpcywgbnVsbCwgbnVsbCk7XG4gIH1cbn1cblxuVHJhbnNmb3JtLnByb3RvdHlwZS5wdXNoID0gZnVuY3Rpb24gKGNodW5rLCBlbmNvZGluZykge1xuICB0aGlzLl90cmFuc2Zvcm1TdGF0ZS5uZWVkVHJhbnNmb3JtID0gZmFsc2U7XG4gIHJldHVybiBEdXBsZXgucHJvdG90eXBlLnB1c2guY2FsbCh0aGlzLCBjaHVuaywgZW5jb2RpbmcpO1xufTsgLy8gVGhpcyBpcyB0aGUgcGFydCB3aGVyZSB5b3UgZG8gc3R1ZmYhXG4vLyBvdmVycmlkZSB0aGlzIGZ1bmN0aW9uIGluIGltcGxlbWVudGF0aW9uIGNsYXNzZXMuXG4vLyAnY2h1bmsnIGlzIGFuIGlucHV0IGNodW5rLlxuLy9cbi8vIENhbGwgYHB1c2gobmV3Q2h1bmspYCB0byBwYXNzIGFsb25nIHRyYW5zZm9ybWVkIG91dHB1dFxuLy8gdG8gdGhlIHJlYWRhYmxlIHNpZGUuICBZb3UgbWF5IGNhbGwgJ3B1c2gnIHplcm8gb3IgbW9yZSB0aW1lcy5cbi8vXG4vLyBDYWxsIGBjYihlcnIpYCB3aGVuIHlvdSBhcmUgZG9uZSB3aXRoIHRoaXMgY2h1bmsuICBJZiB5b3UgcGFzc1xuLy8gYW4gZXJyb3IsIHRoZW4gdGhhdCdsbCBwdXQgdGhlIGh1cnQgb24gdGhlIHdob2xlIG9wZXJhdGlvbi4gIElmIHlvdVxuLy8gbmV2ZXIgY2FsbCBjYigpLCB0aGVuIHlvdSdsbCBuZXZlciBnZXQgYW5vdGhlciBjaHVuay5cblxuXG5UcmFuc2Zvcm0ucHJvdG90eXBlLl90cmFuc2Zvcm0gPSBmdW5jdGlvbiAoY2h1bmssIGVuY29kaW5nLCBjYikge1xuICBjYihuZXcgRVJSX01FVEhPRF9OT1RfSU1QTEVNRU5URUQoJ190cmFuc2Zvcm0oKScpKTtcbn07XG5cblRyYW5zZm9ybS5wcm90b3R5cGUuX3dyaXRlID0gZnVuY3Rpb24gKGNodW5rLCBlbmNvZGluZywgY2IpIHtcbiAgdmFyIHRzID0gdGhpcy5fdHJhbnNmb3JtU3RhdGU7XG4gIHRzLndyaXRlY2IgPSBjYjtcbiAgdHMud3JpdGVjaHVuayA9IGNodW5rO1xuICB0cy53cml0ZWVuY29kaW5nID0gZW5jb2Rpbmc7XG5cbiAgaWYgKCF0cy50cmFuc2Zvcm1pbmcpIHtcbiAgICB2YXIgcnMgPSB0aGlzLl9yZWFkYWJsZVN0YXRlO1xuICAgIGlmICh0cy5uZWVkVHJhbnNmb3JtIHx8IHJzLm5lZWRSZWFkYWJsZSB8fCBycy5sZW5ndGggPCBycy5oaWdoV2F0ZXJNYXJrKSB0aGlzLl9yZWFkKHJzLmhpZ2hXYXRlck1hcmspO1xuICB9XG59OyAvLyBEb2Vzbid0IG1hdHRlciB3aGF0IHRoZSBhcmdzIGFyZSBoZXJlLlxuLy8gX3RyYW5zZm9ybSBkb2VzIGFsbCB0aGUgd29yay5cbi8vIFRoYXQgd2UgZ290IGhlcmUgbWVhbnMgdGhhdCB0aGUgcmVhZGFibGUgc2lkZSB3YW50cyBtb3JlIGRhdGEuXG5cblxuVHJhbnNmb3JtLnByb3RvdHlwZS5fcmVhZCA9IGZ1bmN0aW9uIChuKSB7XG4gIHZhciB0cyA9IHRoaXMuX3RyYW5zZm9ybVN0YXRlO1xuXG4gIGlmICh0cy53cml0ZWNodW5rICE9PSBudWxsICYmICF0cy50cmFuc2Zvcm1pbmcpIHtcbiAgICB0cy50cmFuc2Zvcm1pbmcgPSB0cnVlO1xuXG4gICAgdGhpcy5fdHJhbnNmb3JtKHRzLndyaXRlY2h1bmssIHRzLndyaXRlZW5jb2RpbmcsIHRzLmFmdGVyVHJhbnNmb3JtKTtcbiAgfSBlbHNlIHtcbiAgICAvLyBtYXJrIHRoYXQgd2UgbmVlZCBhIHRyYW5zZm9ybSwgc28gdGhhdCBhbnkgZGF0YSB0aGF0IGNvbWVzIGluXG4gICAgLy8gd2lsbCBnZXQgcHJvY2Vzc2VkLCBub3cgdGhhdCB3ZSd2ZSBhc2tlZCBmb3IgaXQuXG4gICAgdHMubmVlZFRyYW5zZm9ybSA9IHRydWU7XG4gIH1cbn07XG5cblRyYW5zZm9ybS5wcm90b3R5cGUuX2Rlc3Ryb3kgPSBmdW5jdGlvbiAoZXJyLCBjYikge1xuICBEdXBsZXgucHJvdG90eXBlLl9kZXN0cm95LmNhbGwodGhpcywgZXJyLCBmdW5jdGlvbiAoZXJyMikge1xuICAgIGNiKGVycjIpO1xuICB9KTtcbn07XG5cbmZ1bmN0aW9uIGRvbmUoc3RyZWFtLCBlciwgZGF0YSkge1xuICBpZiAoZXIpIHJldHVybiBzdHJlYW0uZW1pdCgnZXJyb3InLCBlcik7XG4gIGlmIChkYXRhICE9IG51bGwpIC8vIHNpbmdsZSBlcXVhbHMgY2hlY2sgZm9yIGJvdGggYG51bGxgIGFuZCBgdW5kZWZpbmVkYFxuICAgIHN0cmVhbS5wdXNoKGRhdGEpOyAvLyBUT0RPKEJyaWRnZUFSKTogV3JpdGUgYSB0ZXN0IGZvciB0aGVzZSB0d28gZXJyb3IgY2FzZXNcbiAgLy8gaWYgdGhlcmUncyBub3RoaW5nIGluIHRoZSB3cml0ZSBidWZmZXIsIHRoZW4gdGhhdCBtZWFuc1xuICAvLyB0aGF0IG5vdGhpbmcgbW9yZSB3aWxsIGV2ZXIgYmUgcHJvdmlkZWRcblxuICBpZiAoc3RyZWFtLl93cml0YWJsZVN0YXRlLmxlbmd0aCkgdGhyb3cgbmV3IEVSUl9UUkFOU0ZPUk1fV0lUSF9MRU5HVEhfMCgpO1xuICBpZiAoc3RyZWFtLl90cmFuc2Zvcm1TdGF0ZS50cmFuc2Zvcm1pbmcpIHRocm93IG5ldyBFUlJfVFJBTlNGT1JNX0FMUkVBRFlfVFJBTlNGT1JNSU5HKCk7XG4gIHJldHVybiBzdHJlYW0ucHVzaChudWxsKTtcbn0iLCIvLyBDb3B5cmlnaHQgSm95ZW50LCBJbmMuIGFuZCBvdGhlciBOb2RlIGNvbnRyaWJ1dG9ycy5cbi8vXG4vLyBQZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYVxuLy8gY29weSBvZiB0aGlzIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZVxuLy8gXCJTb2Z0d2FyZVwiKSwgdG8gZGVhbCBpbiB0aGUgU29mdHdhcmUgd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nXG4vLyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsXG4vLyBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0XG4vLyBwZXJzb25zIHRvIHdob20gdGhlIFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0byB0aGVcbi8vIGZvbGxvd2luZyBjb25kaXRpb25zOlxuLy9cbi8vIFRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIHNoYWxsIGJlIGluY2x1ZGVkXG4vLyBpbiBhbGwgY29waWVzIG9yIHN1YnN0YW50aWFsIHBvcnRpb25zIG9mIHRoZSBTb2Z0d2FyZS5cbi8vXG4vLyBUSEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTXG4vLyBPUiBJTVBMSUVELCBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GXG4vLyBNRVJDSEFOVEFCSUxJVFksIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuIElOXG4vLyBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFQgSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSxcbi8vIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSIElOIEFOIEFDVElPTiBPRiBDT05UUkFDVCwgVE9SVCBPUlxuLy8gT1RIRVJXSVNFLCBBUklTSU5HIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFIFNPRlRXQVJFIE9SIFRIRVxuLy8gVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cbi8vIEEgYml0IHNpbXBsZXIgdGhhbiByZWFkYWJsZSBzdHJlYW1zLlxuLy8gSW1wbGVtZW50IGFuIGFzeW5jIC5fd3JpdGUoY2h1bmssIGVuY29kaW5nLCBjYiksIGFuZCBpdCdsbCBoYW5kbGUgYWxsXG4vLyB0aGUgZHJhaW4gZXZlbnQgZW1pc3Npb24gYW5kIGJ1ZmZlcmluZy5cbid1c2Ugc3RyaWN0JztcblxubW9kdWxlLmV4cG9ydHMgPSBXcml0YWJsZTtcbi8qIDxyZXBsYWNlbWVudD4gKi9cblxuZnVuY3Rpb24gV3JpdGVSZXEoY2h1bmssIGVuY29kaW5nLCBjYikge1xuICB0aGlzLmNodW5rID0gY2h1bms7XG4gIHRoaXMuZW5jb2RpbmcgPSBlbmNvZGluZztcbiAgdGhpcy5jYWxsYmFjayA9IGNiO1xuICB0aGlzLm5leHQgPSBudWxsO1xufSAvLyBJdCBzZWVtcyBhIGxpbmtlZCBsaXN0IGJ1dCBpdCBpcyBub3Rcbi8vIHRoZXJlIHdpbGwgYmUgb25seSAyIG9mIHRoZXNlIGZvciBlYWNoIHN0cmVhbVxuXG5cbmZ1bmN0aW9uIENvcmtlZFJlcXVlc3Qoc3RhdGUpIHtcbiAgdmFyIF90aGlzID0gdGhpcztcblxuICB0aGlzLm5leHQgPSBudWxsO1xuICB0aGlzLmVudHJ5ID0gbnVsbDtcblxuICB0aGlzLmZpbmlzaCA9IGZ1bmN0aW9uICgpIHtcbiAgICBvbkNvcmtlZEZpbmlzaChfdGhpcywgc3RhdGUpO1xuICB9O1xufVxuLyogPC9yZXBsYWNlbWVudD4gKi9cblxuLyo8cmVwbGFjZW1lbnQ+Ki9cblxuXG52YXIgRHVwbGV4O1xuLyo8L3JlcGxhY2VtZW50PiovXG5cbldyaXRhYmxlLldyaXRhYmxlU3RhdGUgPSBXcml0YWJsZVN0YXRlO1xuLyo8cmVwbGFjZW1lbnQ+Ki9cblxudmFyIGludGVybmFsVXRpbCA9IHtcbiAgZGVwcmVjYXRlOiByZXF1aXJlKCd1dGlsLWRlcHJlY2F0ZScpXG59O1xuLyo8L3JlcGxhY2VtZW50PiovXG5cbi8qPHJlcGxhY2VtZW50PiovXG5cbnZhciBTdHJlYW0gPSByZXF1aXJlKCcuL2ludGVybmFsL3N0cmVhbXMvc3RyZWFtJyk7XG4vKjwvcmVwbGFjZW1lbnQ+Ki9cblxuXG52YXIgQnVmZmVyID0gcmVxdWlyZSgnYnVmZmVyJykuQnVmZmVyO1xuXG52YXIgT3VyVWludDhBcnJheSA9IGdsb2JhbC5VaW50OEFycmF5IHx8IGZ1bmN0aW9uICgpIHt9O1xuXG5mdW5jdGlvbiBfdWludDhBcnJheVRvQnVmZmVyKGNodW5rKSB7XG4gIHJldHVybiBCdWZmZXIuZnJvbShjaHVuayk7XG59XG5cbmZ1bmN0aW9uIF9pc1VpbnQ4QXJyYXkob2JqKSB7XG4gIHJldHVybiBCdWZmZXIuaXNCdWZmZXIob2JqKSB8fCBvYmogaW5zdGFuY2VvZiBPdXJVaW50OEFycmF5O1xufVxuXG52YXIgZGVzdHJveUltcGwgPSByZXF1aXJlKCcuL2ludGVybmFsL3N0cmVhbXMvZGVzdHJveScpO1xuXG52YXIgX3JlcXVpcmUgPSByZXF1aXJlKCcuL2ludGVybmFsL3N0cmVhbXMvc3RhdGUnKSxcbiAgICBnZXRIaWdoV2F0ZXJNYXJrID0gX3JlcXVpcmUuZ2V0SGlnaFdhdGVyTWFyaztcblxudmFyIF9yZXF1aXJlJGNvZGVzID0gcmVxdWlyZSgnLi4vZXJyb3JzJykuY29kZXMsXG4gICAgRVJSX0lOVkFMSURfQVJHX1RZUEUgPSBfcmVxdWlyZSRjb2Rlcy5FUlJfSU5WQUxJRF9BUkdfVFlQRSxcbiAgICBFUlJfTUVUSE9EX05PVF9JTVBMRU1FTlRFRCA9IF9yZXF1aXJlJGNvZGVzLkVSUl9NRVRIT0RfTk9UX0lNUExFTUVOVEVELFxuICAgIEVSUl9NVUxUSVBMRV9DQUxMQkFDSyA9IF9yZXF1aXJlJGNvZGVzLkVSUl9NVUxUSVBMRV9DQUxMQkFDSyxcbiAgICBFUlJfU1RSRUFNX0NBTk5PVF9QSVBFID0gX3JlcXVpcmUkY29kZXMuRVJSX1NUUkVBTV9DQU5OT1RfUElQRSxcbiAgICBFUlJfU1RSRUFNX0RFU1RST1lFRCA9IF9yZXF1aXJlJGNvZGVzLkVSUl9TVFJFQU1fREVTVFJPWUVELFxuICAgIEVSUl9TVFJFQU1fTlVMTF9WQUxVRVMgPSBfcmVxdWlyZSRjb2Rlcy5FUlJfU1RSRUFNX05VTExfVkFMVUVTLFxuICAgIEVSUl9TVFJFQU1fV1JJVEVfQUZURVJfRU5EID0gX3JlcXVpcmUkY29kZXMuRVJSX1NUUkVBTV9XUklURV9BRlRFUl9FTkQsXG4gICAgRVJSX1VOS05PV05fRU5DT0RJTkcgPSBfcmVxdWlyZSRjb2Rlcy5FUlJfVU5LTk9XTl9FTkNPRElORztcblxudmFyIGVycm9yT3JEZXN0cm95ID0gZGVzdHJveUltcGwuZXJyb3JPckRlc3Ryb3k7XG5cbnJlcXVpcmUoJ2luaGVyaXRzJykoV3JpdGFibGUsIFN0cmVhbSk7XG5cbmZ1bmN0aW9uIG5vcCgpIHt9XG5cbmZ1bmN0aW9uIFdyaXRhYmxlU3RhdGUob3B0aW9ucywgc3RyZWFtLCBpc0R1cGxleCkge1xuICBEdXBsZXggPSBEdXBsZXggfHwgcmVxdWlyZSgnLi9fc3RyZWFtX2R1cGxleCcpO1xuICBvcHRpb25zID0gb3B0aW9ucyB8fCB7fTsgLy8gRHVwbGV4IHN0cmVhbXMgYXJlIGJvdGggcmVhZGFibGUgYW5kIHdyaXRhYmxlLCBidXQgc2hhcmVcbiAgLy8gdGhlIHNhbWUgb3B0aW9ucyBvYmplY3QuXG4gIC8vIEhvd2V2ZXIsIHNvbWUgY2FzZXMgcmVxdWlyZSBzZXR0aW5nIG9wdGlvbnMgdG8gZGlmZmVyZW50XG4gIC8vIHZhbHVlcyBmb3IgdGhlIHJlYWRhYmxlIGFuZCB0aGUgd3JpdGFibGUgc2lkZXMgb2YgdGhlIGR1cGxleCBzdHJlYW0sXG4gIC8vIGUuZy4gb3B0aW9ucy5yZWFkYWJsZU9iamVjdE1vZGUgdnMuIG9wdGlvbnMud3JpdGFibGVPYmplY3RNb2RlLCBldGMuXG5cbiAgaWYgKHR5cGVvZiBpc0R1cGxleCAhPT0gJ2Jvb2xlYW4nKSBpc0R1cGxleCA9IHN0cmVhbSBpbnN0YW5jZW9mIER1cGxleDsgLy8gb2JqZWN0IHN0cmVhbSBmbGFnIHRvIGluZGljYXRlIHdoZXRoZXIgb3Igbm90IHRoaXMgc3RyZWFtXG4gIC8vIGNvbnRhaW5zIGJ1ZmZlcnMgb3Igb2JqZWN0cy5cblxuICB0aGlzLm9iamVjdE1vZGUgPSAhIW9wdGlvbnMub2JqZWN0TW9kZTtcbiAgaWYgKGlzRHVwbGV4KSB0aGlzLm9iamVjdE1vZGUgPSB0aGlzLm9iamVjdE1vZGUgfHwgISFvcHRpb25zLndyaXRhYmxlT2JqZWN0TW9kZTsgLy8gdGhlIHBvaW50IGF0IHdoaWNoIHdyaXRlKCkgc3RhcnRzIHJldHVybmluZyBmYWxzZVxuICAvLyBOb3RlOiAwIGlzIGEgdmFsaWQgdmFsdWUsIG1lYW5zIHRoYXQgd2UgYWx3YXlzIHJldHVybiBmYWxzZSBpZlxuICAvLyB0aGUgZW50aXJlIGJ1ZmZlciBpcyBub3QgZmx1c2hlZCBpbW1lZGlhdGVseSBvbiB3cml0ZSgpXG5cbiAgdGhpcy5oaWdoV2F0ZXJNYXJrID0gZ2V0SGlnaFdhdGVyTWFyayh0aGlzLCBvcHRpb25zLCAnd3JpdGFibGVIaWdoV2F0ZXJNYXJrJywgaXNEdXBsZXgpOyAvLyBpZiBfZmluYWwgaGFzIGJlZW4gY2FsbGVkXG5cbiAgdGhpcy5maW5hbENhbGxlZCA9IGZhbHNlOyAvLyBkcmFpbiBldmVudCBmbGFnLlxuXG4gIHRoaXMubmVlZERyYWluID0gZmFsc2U7IC8vIGF0IHRoZSBzdGFydCBvZiBjYWxsaW5nIGVuZCgpXG5cbiAgdGhpcy5lbmRpbmcgPSBmYWxzZTsgLy8gd2hlbiBlbmQoKSBoYXMgYmVlbiBjYWxsZWQsIGFuZCByZXR1cm5lZFxuXG4gIHRoaXMuZW5kZWQgPSBmYWxzZTsgLy8gd2hlbiAnZmluaXNoJyBpcyBlbWl0dGVkXG5cbiAgdGhpcy5maW5pc2hlZCA9IGZhbHNlOyAvLyBoYXMgaXQgYmVlbiBkZXN0cm95ZWRcblxuICB0aGlzLmRlc3Ryb3llZCA9IGZhbHNlOyAvLyBzaG91bGQgd2UgZGVjb2RlIHN0cmluZ3MgaW50byBidWZmZXJzIGJlZm9yZSBwYXNzaW5nIHRvIF93cml0ZT9cbiAgLy8gdGhpcyBpcyBoZXJlIHNvIHRoYXQgc29tZSBub2RlLWNvcmUgc3RyZWFtcyBjYW4gb3B0aW1pemUgc3RyaW5nXG4gIC8vIGhhbmRsaW5nIGF0IGEgbG93ZXIgbGV2ZWwuXG5cbiAgdmFyIG5vRGVjb2RlID0gb3B0aW9ucy5kZWNvZGVTdHJpbmdzID09PSBmYWxzZTtcbiAgdGhpcy5kZWNvZGVTdHJpbmdzID0gIW5vRGVjb2RlOyAvLyBDcnlwdG8gaXMga2luZCBvZiBvbGQgYW5kIGNydXN0eS4gIEhpc3RvcmljYWxseSwgaXRzIGRlZmF1bHQgc3RyaW5nXG4gIC8vIGVuY29kaW5nIGlzICdiaW5hcnknIHNvIHdlIGhhdmUgdG8gbWFrZSB0aGlzIGNvbmZpZ3VyYWJsZS5cbiAgLy8gRXZlcnl0aGluZyBlbHNlIGluIHRoZSB1bml2ZXJzZSB1c2VzICd1dGY4JywgdGhvdWdoLlxuXG4gIHRoaXMuZGVmYXVsdEVuY29kaW5nID0gb3B0aW9ucy5kZWZhdWx0RW5jb2RpbmcgfHwgJ3V0ZjgnOyAvLyBub3QgYW4gYWN0dWFsIGJ1ZmZlciB3ZSBrZWVwIHRyYWNrIG9mLCBidXQgYSBtZWFzdXJlbWVudFxuICAvLyBvZiBob3cgbXVjaCB3ZSdyZSB3YWl0aW5nIHRvIGdldCBwdXNoZWQgdG8gc29tZSB1bmRlcmx5aW5nXG4gIC8vIHNvY2tldCBvciBmaWxlLlxuXG4gIHRoaXMubGVuZ3RoID0gMDsgLy8gYSBmbGFnIHRvIHNlZSB3aGVuIHdlJ3JlIGluIHRoZSBtaWRkbGUgb2YgYSB3cml0ZS5cblxuICB0aGlzLndyaXRpbmcgPSBmYWxzZTsgLy8gd2hlbiB0cnVlIGFsbCB3cml0ZXMgd2lsbCBiZSBidWZmZXJlZCB1bnRpbCAudW5jb3JrKCkgY2FsbFxuXG4gIHRoaXMuY29ya2VkID0gMDsgLy8gYSBmbGFnIHRvIGJlIGFibGUgdG8gdGVsbCBpZiB0aGUgb253cml0ZSBjYiBpcyBjYWxsZWQgaW1tZWRpYXRlbHksXG4gIC8vIG9yIG9uIGEgbGF0ZXIgdGljay4gIFdlIHNldCB0aGlzIHRvIHRydWUgYXQgZmlyc3QsIGJlY2F1c2UgYW55XG4gIC8vIGFjdGlvbnMgdGhhdCBzaG91bGRuJ3QgaGFwcGVuIHVudGlsIFwibGF0ZXJcIiBzaG91bGQgZ2VuZXJhbGx5IGFsc29cbiAgLy8gbm90IGhhcHBlbiBiZWZvcmUgdGhlIGZpcnN0IHdyaXRlIGNhbGwuXG5cbiAgdGhpcy5zeW5jID0gdHJ1ZTsgLy8gYSBmbGFnIHRvIGtub3cgaWYgd2UncmUgcHJvY2Vzc2luZyBwcmV2aW91c2x5IGJ1ZmZlcmVkIGl0ZW1zLCB3aGljaFxuICAvLyBtYXkgY2FsbCB0aGUgX3dyaXRlKCkgY2FsbGJhY2sgaW4gdGhlIHNhbWUgdGljaywgc28gdGhhdCB3ZSBkb24ndFxuICAvLyBlbmQgdXAgaW4gYW4gb3ZlcmxhcHBlZCBvbndyaXRlIHNpdHVhdGlvbi5cblxuICB0aGlzLmJ1ZmZlclByb2Nlc3NpbmcgPSBmYWxzZTsgLy8gdGhlIGNhbGxiYWNrIHRoYXQncyBwYXNzZWQgdG8gX3dyaXRlKGNodW5rLGNiKVxuXG4gIHRoaXMub253cml0ZSA9IGZ1bmN0aW9uIChlcikge1xuICAgIG9ud3JpdGUoc3RyZWFtLCBlcik7XG4gIH07IC8vIHRoZSBjYWxsYmFjayB0aGF0IHRoZSB1c2VyIHN1cHBsaWVzIHRvIHdyaXRlKGNodW5rLGVuY29kaW5nLGNiKVxuXG5cbiAgdGhpcy53cml0ZWNiID0gbnVsbDsgLy8gdGhlIGFtb3VudCB0aGF0IGlzIGJlaW5nIHdyaXR0ZW4gd2hlbiBfd3JpdGUgaXMgY2FsbGVkLlxuXG4gIHRoaXMud3JpdGVsZW4gPSAwO1xuICB0aGlzLmJ1ZmZlcmVkUmVxdWVzdCA9IG51bGw7XG4gIHRoaXMubGFzdEJ1ZmZlcmVkUmVxdWVzdCA9IG51bGw7IC8vIG51bWJlciBvZiBwZW5kaW5nIHVzZXItc3VwcGxpZWQgd3JpdGUgY2FsbGJhY2tzXG4gIC8vIHRoaXMgbXVzdCBiZSAwIGJlZm9yZSAnZmluaXNoJyBjYW4gYmUgZW1pdHRlZFxuXG4gIHRoaXMucGVuZGluZ2NiID0gMDsgLy8gZW1pdCBwcmVmaW5pc2ggaWYgdGhlIG9ubHkgdGhpbmcgd2UncmUgd2FpdGluZyBmb3IgaXMgX3dyaXRlIGNic1xuICAvLyBUaGlzIGlzIHJlbGV2YW50IGZvciBzeW5jaHJvbm91cyBUcmFuc2Zvcm0gc3RyZWFtc1xuXG4gIHRoaXMucHJlZmluaXNoZWQgPSBmYWxzZTsgLy8gVHJ1ZSBpZiB0aGUgZXJyb3Igd2FzIGFscmVhZHkgZW1pdHRlZCBhbmQgc2hvdWxkIG5vdCBiZSB0aHJvd24gYWdhaW5cblxuICB0aGlzLmVycm9yRW1pdHRlZCA9IGZhbHNlOyAvLyBTaG91bGQgY2xvc2UgYmUgZW1pdHRlZCBvbiBkZXN0cm95LiBEZWZhdWx0cyB0byB0cnVlLlxuXG4gIHRoaXMuZW1pdENsb3NlID0gb3B0aW9ucy5lbWl0Q2xvc2UgIT09IGZhbHNlOyAvLyBTaG91bGQgLmRlc3Ryb3koKSBiZSBjYWxsZWQgYWZ0ZXIgJ2ZpbmlzaCcgKGFuZCBwb3RlbnRpYWxseSAnZW5kJylcblxuICB0aGlzLmF1dG9EZXN0cm95ID0gISFvcHRpb25zLmF1dG9EZXN0cm95OyAvLyBjb3VudCBidWZmZXJlZCByZXF1ZXN0c1xuXG4gIHRoaXMuYnVmZmVyZWRSZXF1ZXN0Q291bnQgPSAwOyAvLyBhbGxvY2F0ZSB0aGUgZmlyc3QgQ29ya2VkUmVxdWVzdCwgdGhlcmUgaXMgYWx3YXlzXG4gIC8vIG9uZSBhbGxvY2F0ZWQgYW5kIGZyZWUgdG8gdXNlLCBhbmQgd2UgbWFpbnRhaW4gYXQgbW9zdCB0d29cblxuICB0aGlzLmNvcmtlZFJlcXVlc3RzRnJlZSA9IG5ldyBDb3JrZWRSZXF1ZXN0KHRoaXMpO1xufVxuXG5Xcml0YWJsZVN0YXRlLnByb3RvdHlwZS5nZXRCdWZmZXIgPSBmdW5jdGlvbiBnZXRCdWZmZXIoKSB7XG4gIHZhciBjdXJyZW50ID0gdGhpcy5idWZmZXJlZFJlcXVlc3Q7XG4gIHZhciBvdXQgPSBbXTtcblxuICB3aGlsZSAoY3VycmVudCkge1xuICAgIG91dC5wdXNoKGN1cnJlbnQpO1xuICAgIGN1cnJlbnQgPSBjdXJyZW50Lm5leHQ7XG4gIH1cblxuICByZXR1cm4gb3V0O1xufTtcblxuKGZ1bmN0aW9uICgpIHtcbiAgdHJ5IHtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoV3JpdGFibGVTdGF0ZS5wcm90b3R5cGUsICdidWZmZXInLCB7XG4gICAgICBnZXQ6IGludGVybmFsVXRpbC5kZXByZWNhdGUoZnVuY3Rpb24gd3JpdGFibGVTdGF0ZUJ1ZmZlckdldHRlcigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0QnVmZmVyKCk7XG4gICAgICB9LCAnX3dyaXRhYmxlU3RhdGUuYnVmZmVyIGlzIGRlcHJlY2F0ZWQuIFVzZSBfd3JpdGFibGVTdGF0ZS5nZXRCdWZmZXIgJyArICdpbnN0ZWFkLicsICdERVAwMDAzJylcbiAgICB9KTtcbiAgfSBjYXRjaCAoXykge31cbn0pKCk7IC8vIFRlc3QgX3dyaXRhYmxlU3RhdGUgZm9yIGluaGVyaXRhbmNlIHRvIGFjY291bnQgZm9yIER1cGxleCBzdHJlYW1zLFxuLy8gd2hvc2UgcHJvdG90eXBlIGNoYWluIG9ubHkgcG9pbnRzIHRvIFJlYWRhYmxlLlxuXG5cbnZhciByZWFsSGFzSW5zdGFuY2U7XG5cbmlmICh0eXBlb2YgU3ltYm9sID09PSAnZnVuY3Rpb24nICYmIFN5bWJvbC5oYXNJbnN0YW5jZSAmJiB0eXBlb2YgRnVuY3Rpb24ucHJvdG90eXBlW1N5bWJvbC5oYXNJbnN0YW5jZV0gPT09ICdmdW5jdGlvbicpIHtcbiAgcmVhbEhhc0luc3RhbmNlID0gRnVuY3Rpb24ucHJvdG90eXBlW1N5bWJvbC5oYXNJbnN0YW5jZV07XG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShXcml0YWJsZSwgU3ltYm9sLmhhc0luc3RhbmNlLCB7XG4gICAgdmFsdWU6IGZ1bmN0aW9uIHZhbHVlKG9iamVjdCkge1xuICAgICAgaWYgKHJlYWxIYXNJbnN0YW5jZS5jYWxsKHRoaXMsIG9iamVjdCkpIHJldHVybiB0cnVlO1xuICAgICAgaWYgKHRoaXMgIT09IFdyaXRhYmxlKSByZXR1cm4gZmFsc2U7XG4gICAgICByZXR1cm4gb2JqZWN0ICYmIG9iamVjdC5fd3JpdGFibGVTdGF0ZSBpbnN0YW5jZW9mIFdyaXRhYmxlU3RhdGU7XG4gICAgfVxuICB9KTtcbn0gZWxzZSB7XG4gIHJlYWxIYXNJbnN0YW5jZSA9IGZ1bmN0aW9uIHJlYWxIYXNJbnN0YW5jZShvYmplY3QpIHtcbiAgICByZXR1cm4gb2JqZWN0IGluc3RhbmNlb2YgdGhpcztcbiAgfTtcbn1cblxuZnVuY3Rpb24gV3JpdGFibGUob3B0aW9ucykge1xuICBEdXBsZXggPSBEdXBsZXggfHwgcmVxdWlyZSgnLi9fc3RyZWFtX2R1cGxleCcpOyAvLyBXcml0YWJsZSBjdG9yIGlzIGFwcGxpZWQgdG8gRHVwbGV4ZXMsIHRvby5cbiAgLy8gYHJlYWxIYXNJbnN0YW5jZWAgaXMgbmVjZXNzYXJ5IGJlY2F1c2UgdXNpbmcgcGxhaW4gYGluc3RhbmNlb2ZgXG4gIC8vIHdvdWxkIHJldHVybiBmYWxzZSwgYXMgbm8gYF93cml0YWJsZVN0YXRlYCBwcm9wZXJ0eSBpcyBhdHRhY2hlZC5cbiAgLy8gVHJ5aW5nIHRvIHVzZSB0aGUgY3VzdG9tIGBpbnN0YW5jZW9mYCBmb3IgV3JpdGFibGUgaGVyZSB3aWxsIGFsc28gYnJlYWsgdGhlXG4gIC8vIE5vZGUuanMgTGF6eVRyYW5zZm9ybSBpbXBsZW1lbnRhdGlvbiwgd2hpY2ggaGFzIGEgbm9uLXRyaXZpYWwgZ2V0dGVyIGZvclxuICAvLyBgX3dyaXRhYmxlU3RhdGVgIHRoYXQgd291bGQgbGVhZCB0byBpbmZpbml0ZSByZWN1cnNpb24uXG4gIC8vIENoZWNraW5nIGZvciBhIFN0cmVhbS5EdXBsZXggaW5zdGFuY2UgaXMgZmFzdGVyIGhlcmUgaW5zdGVhZCBvZiBpbnNpZGVcbiAgLy8gdGhlIFdyaXRhYmxlU3RhdGUgY29uc3RydWN0b3IsIGF0IGxlYXN0IHdpdGggVjggNi41XG5cbiAgdmFyIGlzRHVwbGV4ID0gdGhpcyBpbnN0YW5jZW9mIER1cGxleDtcbiAgaWYgKCFpc0R1cGxleCAmJiAhcmVhbEhhc0luc3RhbmNlLmNhbGwoV3JpdGFibGUsIHRoaXMpKSByZXR1cm4gbmV3IFdyaXRhYmxlKG9wdGlvbnMpO1xuICB0aGlzLl93cml0YWJsZVN0YXRlID0gbmV3IFdyaXRhYmxlU3RhdGUob3B0aW9ucywgdGhpcywgaXNEdXBsZXgpOyAvLyBsZWdhY3kuXG5cbiAgdGhpcy53cml0YWJsZSA9IHRydWU7XG5cbiAgaWYgKG9wdGlvbnMpIHtcbiAgICBpZiAodHlwZW9mIG9wdGlvbnMud3JpdGUgPT09ICdmdW5jdGlvbicpIHRoaXMuX3dyaXRlID0gb3B0aW9ucy53cml0ZTtcbiAgICBpZiAodHlwZW9mIG9wdGlvbnMud3JpdGV2ID09PSAnZnVuY3Rpb24nKSB0aGlzLl93cml0ZXYgPSBvcHRpb25zLndyaXRldjtcbiAgICBpZiAodHlwZW9mIG9wdGlvbnMuZGVzdHJveSA9PT0gJ2Z1bmN0aW9uJykgdGhpcy5fZGVzdHJveSA9IG9wdGlvbnMuZGVzdHJveTtcbiAgICBpZiAodHlwZW9mIG9wdGlvbnMuZmluYWwgPT09ICdmdW5jdGlvbicpIHRoaXMuX2ZpbmFsID0gb3B0aW9ucy5maW5hbDtcbiAgfVxuXG4gIFN0cmVhbS5jYWxsKHRoaXMpO1xufSAvLyBPdGhlcndpc2UgcGVvcGxlIGNhbiBwaXBlIFdyaXRhYmxlIHN0cmVhbXMsIHdoaWNoIGlzIGp1c3Qgd3JvbmcuXG5cblxuV3JpdGFibGUucHJvdG90eXBlLnBpcGUgPSBmdW5jdGlvbiAoKSB7XG4gIGVycm9yT3JEZXN0cm95KHRoaXMsIG5ldyBFUlJfU1RSRUFNX0NBTk5PVF9QSVBFKCkpO1xufTtcblxuZnVuY3Rpb24gd3JpdGVBZnRlckVuZChzdHJlYW0sIGNiKSB7XG4gIHZhciBlciA9IG5ldyBFUlJfU1RSRUFNX1dSSVRFX0FGVEVSX0VORCgpOyAvLyBUT0RPOiBkZWZlciBlcnJvciBldmVudHMgY29uc2lzdGVudGx5IGV2ZXJ5d2hlcmUsIG5vdCBqdXN0IHRoZSBjYlxuXG4gIGVycm9yT3JEZXN0cm95KHN0cmVhbSwgZXIpO1xuICBwcm9jZXNzLm5leHRUaWNrKGNiLCBlcik7XG59IC8vIENoZWNrcyB0aGF0IGEgdXNlci1zdXBwbGllZCBjaHVuayBpcyB2YWxpZCwgZXNwZWNpYWxseSBmb3IgdGhlIHBhcnRpY3VsYXJcbi8vIG1vZGUgdGhlIHN0cmVhbSBpcyBpbi4gQ3VycmVudGx5IHRoaXMgbWVhbnMgdGhhdCBgbnVsbGAgaXMgbmV2ZXIgYWNjZXB0ZWRcbi8vIGFuZCB1bmRlZmluZWQvbm9uLXN0cmluZyB2YWx1ZXMgYXJlIG9ubHkgYWxsb3dlZCBpbiBvYmplY3QgbW9kZS5cblxuXG5mdW5jdGlvbiB2YWxpZENodW5rKHN0cmVhbSwgc3RhdGUsIGNodW5rLCBjYikge1xuICB2YXIgZXI7XG5cbiAgaWYgKGNodW5rID09PSBudWxsKSB7XG4gICAgZXIgPSBuZXcgRVJSX1NUUkVBTV9OVUxMX1ZBTFVFUygpO1xuICB9IGVsc2UgaWYgKHR5cGVvZiBjaHVuayAhPT0gJ3N0cmluZycgJiYgIXN0YXRlLm9iamVjdE1vZGUpIHtcbiAgICBlciA9IG5ldyBFUlJfSU5WQUxJRF9BUkdfVFlQRSgnY2h1bmsnLCBbJ3N0cmluZycsICdCdWZmZXInXSwgY2h1bmspO1xuICB9XG5cbiAgaWYgKGVyKSB7XG4gICAgZXJyb3JPckRlc3Ryb3koc3RyZWFtLCBlcik7XG4gICAgcHJvY2Vzcy5uZXh0VGljayhjYiwgZXIpO1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIHJldHVybiB0cnVlO1xufVxuXG5Xcml0YWJsZS5wcm90b3R5cGUud3JpdGUgPSBmdW5jdGlvbiAoY2h1bmssIGVuY29kaW5nLCBjYikge1xuICB2YXIgc3RhdGUgPSB0aGlzLl93cml0YWJsZVN0YXRlO1xuICB2YXIgcmV0ID0gZmFsc2U7XG5cbiAgdmFyIGlzQnVmID0gIXN0YXRlLm9iamVjdE1vZGUgJiYgX2lzVWludDhBcnJheShjaHVuayk7XG5cbiAgaWYgKGlzQnVmICYmICFCdWZmZXIuaXNCdWZmZXIoY2h1bmspKSB7XG4gICAgY2h1bmsgPSBfdWludDhBcnJheVRvQnVmZmVyKGNodW5rKTtcbiAgfVxuXG4gIGlmICh0eXBlb2YgZW5jb2RpbmcgPT09ICdmdW5jdGlvbicpIHtcbiAgICBjYiA9IGVuY29kaW5nO1xuICAgIGVuY29kaW5nID0gbnVsbDtcbiAgfVxuXG4gIGlmIChpc0J1ZikgZW5jb2RpbmcgPSAnYnVmZmVyJztlbHNlIGlmICghZW5jb2RpbmcpIGVuY29kaW5nID0gc3RhdGUuZGVmYXVsdEVuY29kaW5nO1xuICBpZiAodHlwZW9mIGNiICE9PSAnZnVuY3Rpb24nKSBjYiA9IG5vcDtcbiAgaWYgKHN0YXRlLmVuZGluZykgd3JpdGVBZnRlckVuZCh0aGlzLCBjYik7ZWxzZSBpZiAoaXNCdWYgfHwgdmFsaWRDaHVuayh0aGlzLCBzdGF0ZSwgY2h1bmssIGNiKSkge1xuICAgIHN0YXRlLnBlbmRpbmdjYisrO1xuICAgIHJldCA9IHdyaXRlT3JCdWZmZXIodGhpcywgc3RhdGUsIGlzQnVmLCBjaHVuaywgZW5jb2RpbmcsIGNiKTtcbiAgfVxuICByZXR1cm4gcmV0O1xufTtcblxuV3JpdGFibGUucHJvdG90eXBlLmNvcmsgPSBmdW5jdGlvbiAoKSB7XG4gIHRoaXMuX3dyaXRhYmxlU3RhdGUuY29ya2VkKys7XG59O1xuXG5Xcml0YWJsZS5wcm90b3R5cGUudW5jb3JrID0gZnVuY3Rpb24gKCkge1xuICB2YXIgc3RhdGUgPSB0aGlzLl93cml0YWJsZVN0YXRlO1xuXG4gIGlmIChzdGF0ZS5jb3JrZWQpIHtcbiAgICBzdGF0ZS5jb3JrZWQtLTtcbiAgICBpZiAoIXN0YXRlLndyaXRpbmcgJiYgIXN0YXRlLmNvcmtlZCAmJiAhc3RhdGUuYnVmZmVyUHJvY2Vzc2luZyAmJiBzdGF0ZS5idWZmZXJlZFJlcXVlc3QpIGNsZWFyQnVmZmVyKHRoaXMsIHN0YXRlKTtcbiAgfVxufTtcblxuV3JpdGFibGUucHJvdG90eXBlLnNldERlZmF1bHRFbmNvZGluZyA9IGZ1bmN0aW9uIHNldERlZmF1bHRFbmNvZGluZyhlbmNvZGluZykge1xuICAvLyBub2RlOjpQYXJzZUVuY29kaW5nKCkgcmVxdWlyZXMgbG93ZXIgY2FzZS5cbiAgaWYgKHR5cGVvZiBlbmNvZGluZyA9PT0gJ3N0cmluZycpIGVuY29kaW5nID0gZW5jb2RpbmcudG9Mb3dlckNhc2UoKTtcbiAgaWYgKCEoWydoZXgnLCAndXRmOCcsICd1dGYtOCcsICdhc2NpaScsICdiaW5hcnknLCAnYmFzZTY0JywgJ3VjczInLCAndWNzLTInLCAndXRmMTZsZScsICd1dGYtMTZsZScsICdyYXcnXS5pbmRleE9mKChlbmNvZGluZyArICcnKS50b0xvd2VyQ2FzZSgpKSA+IC0xKSkgdGhyb3cgbmV3IEVSUl9VTktOT1dOX0VOQ09ESU5HKGVuY29kaW5nKTtcbiAgdGhpcy5fd3JpdGFibGVTdGF0ZS5kZWZhdWx0RW5jb2RpbmcgPSBlbmNvZGluZztcbiAgcmV0dXJuIHRoaXM7XG59O1xuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoV3JpdGFibGUucHJvdG90eXBlLCAnd3JpdGFibGVCdWZmZXInLCB7XG4gIC8vIG1ha2luZyBpdCBleHBsaWNpdCB0aGlzIHByb3BlcnR5IGlzIG5vdCBlbnVtZXJhYmxlXG4gIC8vIGJlY2F1c2Ugb3RoZXJ3aXNlIHNvbWUgcHJvdG90eXBlIG1hbmlwdWxhdGlvbiBpblxuICAvLyB1c2VybGFuZCB3aWxsIGZhaWxcbiAgZW51bWVyYWJsZTogZmFsc2UsXG4gIGdldDogZnVuY3Rpb24gZ2V0KCkge1xuICAgIHJldHVybiB0aGlzLl93cml0YWJsZVN0YXRlICYmIHRoaXMuX3dyaXRhYmxlU3RhdGUuZ2V0QnVmZmVyKCk7XG4gIH1cbn0pO1xuXG5mdW5jdGlvbiBkZWNvZGVDaHVuayhzdGF0ZSwgY2h1bmssIGVuY29kaW5nKSB7XG4gIGlmICghc3RhdGUub2JqZWN0TW9kZSAmJiBzdGF0ZS5kZWNvZGVTdHJpbmdzICE9PSBmYWxzZSAmJiB0eXBlb2YgY2h1bmsgPT09ICdzdHJpbmcnKSB7XG4gICAgY2h1bmsgPSBCdWZmZXIuZnJvbShjaHVuaywgZW5jb2RpbmcpO1xuICB9XG5cbiAgcmV0dXJuIGNodW5rO1xufVxuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoV3JpdGFibGUucHJvdG90eXBlLCAnd3JpdGFibGVIaWdoV2F0ZXJNYXJrJywge1xuICAvLyBtYWtpbmcgaXQgZXhwbGljaXQgdGhpcyBwcm9wZXJ0eSBpcyBub3QgZW51bWVyYWJsZVxuICAvLyBiZWNhdXNlIG90aGVyd2lzZSBzb21lIHByb3RvdHlwZSBtYW5pcHVsYXRpb24gaW5cbiAgLy8gdXNlcmxhbmQgd2lsbCBmYWlsXG4gIGVudW1lcmFibGU6IGZhbHNlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICByZXR1cm4gdGhpcy5fd3JpdGFibGVTdGF0ZS5oaWdoV2F0ZXJNYXJrO1xuICB9XG59KTsgLy8gaWYgd2UncmUgYWxyZWFkeSB3cml0aW5nIHNvbWV0aGluZywgdGhlbiBqdXN0IHB1dCB0aGlzXG4vLyBpbiB0aGUgcXVldWUsIGFuZCB3YWl0IG91ciB0dXJuLiAgT3RoZXJ3aXNlLCBjYWxsIF93cml0ZVxuLy8gSWYgd2UgcmV0dXJuIGZhbHNlLCB0aGVuIHdlIG5lZWQgYSBkcmFpbiBldmVudCwgc28gc2V0IHRoYXQgZmxhZy5cblxuZnVuY3Rpb24gd3JpdGVPckJ1ZmZlcihzdHJlYW0sIHN0YXRlLCBpc0J1ZiwgY2h1bmssIGVuY29kaW5nLCBjYikge1xuICBpZiAoIWlzQnVmKSB7XG4gICAgdmFyIG5ld0NodW5rID0gZGVjb2RlQ2h1bmsoc3RhdGUsIGNodW5rLCBlbmNvZGluZyk7XG5cbiAgICBpZiAoY2h1bmsgIT09IG5ld0NodW5rKSB7XG4gICAgICBpc0J1ZiA9IHRydWU7XG4gICAgICBlbmNvZGluZyA9ICdidWZmZXInO1xuICAgICAgY2h1bmsgPSBuZXdDaHVuaztcbiAgICB9XG4gIH1cblxuICB2YXIgbGVuID0gc3RhdGUub2JqZWN0TW9kZSA/IDEgOiBjaHVuay5sZW5ndGg7XG4gIHN0YXRlLmxlbmd0aCArPSBsZW47XG4gIHZhciByZXQgPSBzdGF0ZS5sZW5ndGggPCBzdGF0ZS5oaWdoV2F0ZXJNYXJrOyAvLyB3ZSBtdXN0IGVuc3VyZSB0aGF0IHByZXZpb3VzIG5lZWREcmFpbiB3aWxsIG5vdCBiZSByZXNldCB0byBmYWxzZS5cblxuICBpZiAoIXJldCkgc3RhdGUubmVlZERyYWluID0gdHJ1ZTtcblxuICBpZiAoc3RhdGUud3JpdGluZyB8fCBzdGF0ZS5jb3JrZWQpIHtcbiAgICB2YXIgbGFzdCA9IHN0YXRlLmxhc3RCdWZmZXJlZFJlcXVlc3Q7XG4gICAgc3RhdGUubGFzdEJ1ZmZlcmVkUmVxdWVzdCA9IHtcbiAgICAgIGNodW5rOiBjaHVuayxcbiAgICAgIGVuY29kaW5nOiBlbmNvZGluZyxcbiAgICAgIGlzQnVmOiBpc0J1ZixcbiAgICAgIGNhbGxiYWNrOiBjYixcbiAgICAgIG5leHQ6IG51bGxcbiAgICB9O1xuXG4gICAgaWYgKGxhc3QpIHtcbiAgICAgIGxhc3QubmV4dCA9IHN0YXRlLmxhc3RCdWZmZXJlZFJlcXVlc3Q7XG4gICAgfSBlbHNlIHtcbiAgICAgIHN0YXRlLmJ1ZmZlcmVkUmVxdWVzdCA9IHN0YXRlLmxhc3RCdWZmZXJlZFJlcXVlc3Q7XG4gICAgfVxuXG4gICAgc3RhdGUuYnVmZmVyZWRSZXF1ZXN0Q291bnQgKz0gMTtcbiAgfSBlbHNlIHtcbiAgICBkb1dyaXRlKHN0cmVhbSwgc3RhdGUsIGZhbHNlLCBsZW4sIGNodW5rLCBlbmNvZGluZywgY2IpO1xuICB9XG5cbiAgcmV0dXJuIHJldDtcbn1cblxuZnVuY3Rpb24gZG9Xcml0ZShzdHJlYW0sIHN0YXRlLCB3cml0ZXYsIGxlbiwgY2h1bmssIGVuY29kaW5nLCBjYikge1xuICBzdGF0ZS53cml0ZWxlbiA9IGxlbjtcbiAgc3RhdGUud3JpdGVjYiA9IGNiO1xuICBzdGF0ZS53cml0aW5nID0gdHJ1ZTtcbiAgc3RhdGUuc3luYyA9IHRydWU7XG4gIGlmIChzdGF0ZS5kZXN0cm95ZWQpIHN0YXRlLm9ud3JpdGUobmV3IEVSUl9TVFJFQU1fREVTVFJPWUVEKCd3cml0ZScpKTtlbHNlIGlmICh3cml0ZXYpIHN0cmVhbS5fd3JpdGV2KGNodW5rLCBzdGF0ZS5vbndyaXRlKTtlbHNlIHN0cmVhbS5fd3JpdGUoY2h1bmssIGVuY29kaW5nLCBzdGF0ZS5vbndyaXRlKTtcbiAgc3RhdGUuc3luYyA9IGZhbHNlO1xufVxuXG5mdW5jdGlvbiBvbndyaXRlRXJyb3Ioc3RyZWFtLCBzdGF0ZSwgc3luYywgZXIsIGNiKSB7XG4gIC0tc3RhdGUucGVuZGluZ2NiO1xuXG4gIGlmIChzeW5jKSB7XG4gICAgLy8gZGVmZXIgdGhlIGNhbGxiYWNrIGlmIHdlIGFyZSBiZWluZyBjYWxsZWQgc3luY2hyb25vdXNseVxuICAgIC8vIHRvIGF2b2lkIHBpbGluZyB1cCB0aGluZ3Mgb24gdGhlIHN0YWNrXG4gICAgcHJvY2Vzcy5uZXh0VGljayhjYiwgZXIpOyAvLyB0aGlzIGNhbiBlbWl0IGZpbmlzaCwgYW5kIGl0IHdpbGwgYWx3YXlzIGhhcHBlblxuICAgIC8vIGFmdGVyIGVycm9yXG5cbiAgICBwcm9jZXNzLm5leHRUaWNrKGZpbmlzaE1heWJlLCBzdHJlYW0sIHN0YXRlKTtcbiAgICBzdHJlYW0uX3dyaXRhYmxlU3RhdGUuZXJyb3JFbWl0dGVkID0gdHJ1ZTtcbiAgICBlcnJvck9yRGVzdHJveShzdHJlYW0sIGVyKTtcbiAgfSBlbHNlIHtcbiAgICAvLyB0aGUgY2FsbGVyIGV4cGVjdCB0aGlzIHRvIGhhcHBlbiBiZWZvcmUgaWZcbiAgICAvLyBpdCBpcyBhc3luY1xuICAgIGNiKGVyKTtcbiAgICBzdHJlYW0uX3dyaXRhYmxlU3RhdGUuZXJyb3JFbWl0dGVkID0gdHJ1ZTtcbiAgICBlcnJvck9yRGVzdHJveShzdHJlYW0sIGVyKTsgLy8gdGhpcyBjYW4gZW1pdCBmaW5pc2gsIGJ1dCBmaW5pc2ggbXVzdFxuICAgIC8vIGFsd2F5cyBmb2xsb3cgZXJyb3JcblxuICAgIGZpbmlzaE1heWJlKHN0cmVhbSwgc3RhdGUpO1xuICB9XG59XG5cbmZ1bmN0aW9uIG9ud3JpdGVTdGF0ZVVwZGF0ZShzdGF0ZSkge1xuICBzdGF0ZS53cml0aW5nID0gZmFsc2U7XG4gIHN0YXRlLndyaXRlY2IgPSBudWxsO1xuICBzdGF0ZS5sZW5ndGggLT0gc3RhdGUud3JpdGVsZW47XG4gIHN0YXRlLndyaXRlbGVuID0gMDtcbn1cblxuZnVuY3Rpb24gb253cml0ZShzdHJlYW0sIGVyKSB7XG4gIHZhciBzdGF0ZSA9IHN0cmVhbS5fd3JpdGFibGVTdGF0ZTtcbiAgdmFyIHN5bmMgPSBzdGF0ZS5zeW5jO1xuICB2YXIgY2IgPSBzdGF0ZS53cml0ZWNiO1xuICBpZiAodHlwZW9mIGNiICE9PSAnZnVuY3Rpb24nKSB0aHJvdyBuZXcgRVJSX01VTFRJUExFX0NBTExCQUNLKCk7XG4gIG9ud3JpdGVTdGF0ZVVwZGF0ZShzdGF0ZSk7XG4gIGlmIChlcikgb253cml0ZUVycm9yKHN0cmVhbSwgc3RhdGUsIHN5bmMsIGVyLCBjYik7ZWxzZSB7XG4gICAgLy8gQ2hlY2sgaWYgd2UncmUgYWN0dWFsbHkgcmVhZHkgdG8gZmluaXNoLCBidXQgZG9uJ3QgZW1pdCB5ZXRcbiAgICB2YXIgZmluaXNoZWQgPSBuZWVkRmluaXNoKHN0YXRlKSB8fCBzdHJlYW0uZGVzdHJveWVkO1xuXG4gICAgaWYgKCFmaW5pc2hlZCAmJiAhc3RhdGUuY29ya2VkICYmICFzdGF0ZS5idWZmZXJQcm9jZXNzaW5nICYmIHN0YXRlLmJ1ZmZlcmVkUmVxdWVzdCkge1xuICAgICAgY2xlYXJCdWZmZXIoc3RyZWFtLCBzdGF0ZSk7XG4gICAgfVxuXG4gICAgaWYgKHN5bmMpIHtcbiAgICAgIHByb2Nlc3MubmV4dFRpY2soYWZ0ZXJXcml0ZSwgc3RyZWFtLCBzdGF0ZSwgZmluaXNoZWQsIGNiKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYWZ0ZXJXcml0ZShzdHJlYW0sIHN0YXRlLCBmaW5pc2hlZCwgY2IpO1xuICAgIH1cbiAgfVxufVxuXG5mdW5jdGlvbiBhZnRlcldyaXRlKHN0cmVhbSwgc3RhdGUsIGZpbmlzaGVkLCBjYikge1xuICBpZiAoIWZpbmlzaGVkKSBvbndyaXRlRHJhaW4oc3RyZWFtLCBzdGF0ZSk7XG4gIHN0YXRlLnBlbmRpbmdjYi0tO1xuICBjYigpO1xuICBmaW5pc2hNYXliZShzdHJlYW0sIHN0YXRlKTtcbn0gLy8gTXVzdCBmb3JjZSBjYWxsYmFjayB0byBiZSBjYWxsZWQgb24gbmV4dFRpY2ssIHNvIHRoYXQgd2UgZG9uJ3Rcbi8vIGVtaXQgJ2RyYWluJyBiZWZvcmUgdGhlIHdyaXRlKCkgY29uc3VtZXIgZ2V0cyB0aGUgJ2ZhbHNlJyByZXR1cm5cbi8vIHZhbHVlLCBhbmQgaGFzIGEgY2hhbmNlIHRvIGF0dGFjaCBhICdkcmFpbicgbGlzdGVuZXIuXG5cblxuZnVuY3Rpb24gb253cml0ZURyYWluKHN0cmVhbSwgc3RhdGUpIHtcbiAgaWYgKHN0YXRlLmxlbmd0aCA9PT0gMCAmJiBzdGF0ZS5uZWVkRHJhaW4pIHtcbiAgICBzdGF0ZS5uZWVkRHJhaW4gPSBmYWxzZTtcbiAgICBzdHJlYW0uZW1pdCgnZHJhaW4nKTtcbiAgfVxufSAvLyBpZiB0aGVyZSdzIHNvbWV0aGluZyBpbiB0aGUgYnVmZmVyIHdhaXRpbmcsIHRoZW4gcHJvY2VzcyBpdFxuXG5cbmZ1bmN0aW9uIGNsZWFyQnVmZmVyKHN0cmVhbSwgc3RhdGUpIHtcbiAgc3RhdGUuYnVmZmVyUHJvY2Vzc2luZyA9IHRydWU7XG4gIHZhciBlbnRyeSA9IHN0YXRlLmJ1ZmZlcmVkUmVxdWVzdDtcblxuICBpZiAoc3RyZWFtLl93cml0ZXYgJiYgZW50cnkgJiYgZW50cnkubmV4dCkge1xuICAgIC8vIEZhc3QgY2FzZSwgd3JpdGUgZXZlcnl0aGluZyB1c2luZyBfd3JpdGV2KClcbiAgICB2YXIgbCA9IHN0YXRlLmJ1ZmZlcmVkUmVxdWVzdENvdW50O1xuICAgIHZhciBidWZmZXIgPSBuZXcgQXJyYXkobCk7XG4gICAgdmFyIGhvbGRlciA9IHN0YXRlLmNvcmtlZFJlcXVlc3RzRnJlZTtcbiAgICBob2xkZXIuZW50cnkgPSBlbnRyeTtcbiAgICB2YXIgY291bnQgPSAwO1xuICAgIHZhciBhbGxCdWZmZXJzID0gdHJ1ZTtcblxuICAgIHdoaWxlIChlbnRyeSkge1xuICAgICAgYnVmZmVyW2NvdW50XSA9IGVudHJ5O1xuICAgICAgaWYgKCFlbnRyeS5pc0J1ZikgYWxsQnVmZmVycyA9IGZhbHNlO1xuICAgICAgZW50cnkgPSBlbnRyeS5uZXh0O1xuICAgICAgY291bnQgKz0gMTtcbiAgICB9XG5cbiAgICBidWZmZXIuYWxsQnVmZmVycyA9IGFsbEJ1ZmZlcnM7XG4gICAgZG9Xcml0ZShzdHJlYW0sIHN0YXRlLCB0cnVlLCBzdGF0ZS5sZW5ndGgsIGJ1ZmZlciwgJycsIGhvbGRlci5maW5pc2gpOyAvLyBkb1dyaXRlIGlzIGFsbW9zdCBhbHdheXMgYXN5bmMsIGRlZmVyIHRoZXNlIHRvIHNhdmUgYSBiaXQgb2YgdGltZVxuICAgIC8vIGFzIHRoZSBob3QgcGF0aCBlbmRzIHdpdGggZG9Xcml0ZVxuXG4gICAgc3RhdGUucGVuZGluZ2NiKys7XG4gICAgc3RhdGUubGFzdEJ1ZmZlcmVkUmVxdWVzdCA9IG51bGw7XG5cbiAgICBpZiAoaG9sZGVyLm5leHQpIHtcbiAgICAgIHN0YXRlLmNvcmtlZFJlcXVlc3RzRnJlZSA9IGhvbGRlci5uZXh0O1xuICAgICAgaG9sZGVyLm5leHQgPSBudWxsO1xuICAgIH0gZWxzZSB7XG4gICAgICBzdGF0ZS5jb3JrZWRSZXF1ZXN0c0ZyZWUgPSBuZXcgQ29ya2VkUmVxdWVzdChzdGF0ZSk7XG4gICAgfVxuXG4gICAgc3RhdGUuYnVmZmVyZWRSZXF1ZXN0Q291bnQgPSAwO1xuICB9IGVsc2Uge1xuICAgIC8vIFNsb3cgY2FzZSwgd3JpdGUgY2h1bmtzIG9uZS1ieS1vbmVcbiAgICB3aGlsZSAoZW50cnkpIHtcbiAgICAgIHZhciBjaHVuayA9IGVudHJ5LmNodW5rO1xuICAgICAgdmFyIGVuY29kaW5nID0gZW50cnkuZW5jb2Rpbmc7XG4gICAgICB2YXIgY2IgPSBlbnRyeS5jYWxsYmFjaztcbiAgICAgIHZhciBsZW4gPSBzdGF0ZS5vYmplY3RNb2RlID8gMSA6IGNodW5rLmxlbmd0aDtcbiAgICAgIGRvV3JpdGUoc3RyZWFtLCBzdGF0ZSwgZmFsc2UsIGxlbiwgY2h1bmssIGVuY29kaW5nLCBjYik7XG4gICAgICBlbnRyeSA9IGVudHJ5Lm5leHQ7XG4gICAgICBzdGF0ZS5idWZmZXJlZFJlcXVlc3RDb3VudC0tOyAvLyBpZiB3ZSBkaWRuJ3QgY2FsbCB0aGUgb253cml0ZSBpbW1lZGlhdGVseSwgdGhlblxuICAgICAgLy8gaXQgbWVhbnMgdGhhdCB3ZSBuZWVkIHRvIHdhaXQgdW50aWwgaXQgZG9lcy5cbiAgICAgIC8vIGFsc28sIHRoYXQgbWVhbnMgdGhhdCB0aGUgY2h1bmsgYW5kIGNiIGFyZSBjdXJyZW50bHlcbiAgICAgIC8vIGJlaW5nIHByb2Nlc3NlZCwgc28gbW92ZSB0aGUgYnVmZmVyIGNvdW50ZXIgcGFzdCB0aGVtLlxuXG4gICAgICBpZiAoc3RhdGUud3JpdGluZykge1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoZW50cnkgPT09IG51bGwpIHN0YXRlLmxhc3RCdWZmZXJlZFJlcXVlc3QgPSBudWxsO1xuICB9XG5cbiAgc3RhdGUuYnVmZmVyZWRSZXF1ZXN0ID0gZW50cnk7XG4gIHN0YXRlLmJ1ZmZlclByb2Nlc3NpbmcgPSBmYWxzZTtcbn1cblxuV3JpdGFibGUucHJvdG90eXBlLl93cml0ZSA9IGZ1bmN0aW9uIChjaHVuaywgZW5jb2RpbmcsIGNiKSB7XG4gIGNiKG5ldyBFUlJfTUVUSE9EX05PVF9JTVBMRU1FTlRFRCgnX3dyaXRlKCknKSk7XG59O1xuXG5Xcml0YWJsZS5wcm90b3R5cGUuX3dyaXRldiA9IG51bGw7XG5cbldyaXRhYmxlLnByb3RvdHlwZS5lbmQgPSBmdW5jdGlvbiAoY2h1bmssIGVuY29kaW5nLCBjYikge1xuICB2YXIgc3RhdGUgPSB0aGlzLl93cml0YWJsZVN0YXRlO1xuXG4gIGlmICh0eXBlb2YgY2h1bmsgPT09ICdmdW5jdGlvbicpIHtcbiAgICBjYiA9IGNodW5rO1xuICAgIGNodW5rID0gbnVsbDtcbiAgICBlbmNvZGluZyA9IG51bGw7XG4gIH0gZWxzZSBpZiAodHlwZW9mIGVuY29kaW5nID09PSAnZnVuY3Rpb24nKSB7XG4gICAgY2IgPSBlbmNvZGluZztcbiAgICBlbmNvZGluZyA9IG51bGw7XG4gIH1cblxuICBpZiAoY2h1bmsgIT09IG51bGwgJiYgY2h1bmsgIT09IHVuZGVmaW5lZCkgdGhpcy53cml0ZShjaHVuaywgZW5jb2RpbmcpOyAvLyAuZW5kKCkgZnVsbHkgdW5jb3Jrc1xuXG4gIGlmIChzdGF0ZS5jb3JrZWQpIHtcbiAgICBzdGF0ZS5jb3JrZWQgPSAxO1xuICAgIHRoaXMudW5jb3JrKCk7XG4gIH0gLy8gaWdub3JlIHVubmVjZXNzYXJ5IGVuZCgpIGNhbGxzLlxuXG5cbiAgaWYgKCFzdGF0ZS5lbmRpbmcpIGVuZFdyaXRhYmxlKHRoaXMsIHN0YXRlLCBjYik7XG4gIHJldHVybiB0aGlzO1xufTtcblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KFdyaXRhYmxlLnByb3RvdHlwZSwgJ3dyaXRhYmxlTGVuZ3RoJywge1xuICAvLyBtYWtpbmcgaXQgZXhwbGljaXQgdGhpcyBwcm9wZXJ0eSBpcyBub3QgZW51bWVyYWJsZVxuICAvLyBiZWNhdXNlIG90aGVyd2lzZSBzb21lIHByb3RvdHlwZSBtYW5pcHVsYXRpb24gaW5cbiAgLy8gdXNlcmxhbmQgd2lsbCBmYWlsXG4gIGVudW1lcmFibGU6IGZhbHNlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICByZXR1cm4gdGhpcy5fd3JpdGFibGVTdGF0ZS5sZW5ndGg7XG4gIH1cbn0pO1xuXG5mdW5jdGlvbiBuZWVkRmluaXNoKHN0YXRlKSB7XG4gIHJldHVybiBzdGF0ZS5lbmRpbmcgJiYgc3RhdGUubGVuZ3RoID09PSAwICYmIHN0YXRlLmJ1ZmZlcmVkUmVxdWVzdCA9PT0gbnVsbCAmJiAhc3RhdGUuZmluaXNoZWQgJiYgIXN0YXRlLndyaXRpbmc7XG59XG5cbmZ1bmN0aW9uIGNhbGxGaW5hbChzdHJlYW0sIHN0YXRlKSB7XG4gIHN0cmVhbS5fZmluYWwoZnVuY3Rpb24gKGVycikge1xuICAgIHN0YXRlLnBlbmRpbmdjYi0tO1xuXG4gICAgaWYgKGVycikge1xuICAgICAgZXJyb3JPckRlc3Ryb3koc3RyZWFtLCBlcnIpO1xuICAgIH1cblxuICAgIHN0YXRlLnByZWZpbmlzaGVkID0gdHJ1ZTtcbiAgICBzdHJlYW0uZW1pdCgncHJlZmluaXNoJyk7XG4gICAgZmluaXNoTWF5YmUoc3RyZWFtLCBzdGF0ZSk7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiBwcmVmaW5pc2goc3RyZWFtLCBzdGF0ZSkge1xuICBpZiAoIXN0YXRlLnByZWZpbmlzaGVkICYmICFzdGF0ZS5maW5hbENhbGxlZCkge1xuICAgIGlmICh0eXBlb2Ygc3RyZWFtLl9maW5hbCA9PT0gJ2Z1bmN0aW9uJyAmJiAhc3RhdGUuZGVzdHJveWVkKSB7XG4gICAgICBzdGF0ZS5wZW5kaW5nY2IrKztcbiAgICAgIHN0YXRlLmZpbmFsQ2FsbGVkID0gdHJ1ZTtcbiAgICAgIHByb2Nlc3MubmV4dFRpY2soY2FsbEZpbmFsLCBzdHJlYW0sIHN0YXRlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc3RhdGUucHJlZmluaXNoZWQgPSB0cnVlO1xuICAgICAgc3RyZWFtLmVtaXQoJ3ByZWZpbmlzaCcpO1xuICAgIH1cbiAgfVxufVxuXG5mdW5jdGlvbiBmaW5pc2hNYXliZShzdHJlYW0sIHN0YXRlKSB7XG4gIHZhciBuZWVkID0gbmVlZEZpbmlzaChzdGF0ZSk7XG5cbiAgaWYgKG5lZWQpIHtcbiAgICBwcmVmaW5pc2goc3RyZWFtLCBzdGF0ZSk7XG5cbiAgICBpZiAoc3RhdGUucGVuZGluZ2NiID09PSAwKSB7XG4gICAgICBzdGF0ZS5maW5pc2hlZCA9IHRydWU7XG4gICAgICBzdHJlYW0uZW1pdCgnZmluaXNoJyk7XG5cbiAgICAgIGlmIChzdGF0ZS5hdXRvRGVzdHJveSkge1xuICAgICAgICAvLyBJbiBjYXNlIG9mIGR1cGxleCBzdHJlYW1zIHdlIG5lZWQgYSB3YXkgdG8gZGV0ZWN0XG4gICAgICAgIC8vIGlmIHRoZSByZWFkYWJsZSBzaWRlIGlzIHJlYWR5IGZvciBhdXRvRGVzdHJveSBhcyB3ZWxsXG4gICAgICAgIHZhciByU3RhdGUgPSBzdHJlYW0uX3JlYWRhYmxlU3RhdGU7XG5cbiAgICAgICAgaWYgKCFyU3RhdGUgfHwgclN0YXRlLmF1dG9EZXN0cm95ICYmIHJTdGF0ZS5lbmRFbWl0dGVkKSB7XG4gICAgICAgICAgc3RyZWFtLmRlc3Ryb3koKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiBuZWVkO1xufVxuXG5mdW5jdGlvbiBlbmRXcml0YWJsZShzdHJlYW0sIHN0YXRlLCBjYikge1xuICBzdGF0ZS5lbmRpbmcgPSB0cnVlO1xuICBmaW5pc2hNYXliZShzdHJlYW0sIHN0YXRlKTtcblxuICBpZiAoY2IpIHtcbiAgICBpZiAoc3RhdGUuZmluaXNoZWQpIHByb2Nlc3MubmV4dFRpY2soY2IpO2Vsc2Ugc3RyZWFtLm9uY2UoJ2ZpbmlzaCcsIGNiKTtcbiAgfVxuXG4gIHN0YXRlLmVuZGVkID0gdHJ1ZTtcbiAgc3RyZWFtLndyaXRhYmxlID0gZmFsc2U7XG59XG5cbmZ1bmN0aW9uIG9uQ29ya2VkRmluaXNoKGNvcmtSZXEsIHN0YXRlLCBlcnIpIHtcbiAgdmFyIGVudHJ5ID0gY29ya1JlcS5lbnRyeTtcbiAgY29ya1JlcS5lbnRyeSA9IG51bGw7XG5cbiAgd2hpbGUgKGVudHJ5KSB7XG4gICAgdmFyIGNiID0gZW50cnkuY2FsbGJhY2s7XG4gICAgc3RhdGUucGVuZGluZ2NiLS07XG4gICAgY2IoZXJyKTtcbiAgICBlbnRyeSA9IGVudHJ5Lm5leHQ7XG4gIH0gLy8gcmV1c2UgdGhlIGZyZWUgY29ya1JlcS5cblxuXG4gIHN0YXRlLmNvcmtlZFJlcXVlc3RzRnJlZS5uZXh0ID0gY29ya1JlcTtcbn1cblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KFdyaXRhYmxlLnByb3RvdHlwZSwgJ2Rlc3Ryb3llZCcsIHtcbiAgLy8gbWFraW5nIGl0IGV4cGxpY2l0IHRoaXMgcHJvcGVydHkgaXMgbm90IGVudW1lcmFibGVcbiAgLy8gYmVjYXVzZSBvdGhlcndpc2Ugc29tZSBwcm90b3R5cGUgbWFuaXB1bGF0aW9uIGluXG4gIC8vIHVzZXJsYW5kIHdpbGwgZmFpbFxuICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgZ2V0OiBmdW5jdGlvbiBnZXQoKSB7XG4gICAgaWYgKHRoaXMuX3dyaXRhYmxlU3RhdGUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIHJldHVybiB0aGlzLl93cml0YWJsZVN0YXRlLmRlc3Ryb3llZDtcbiAgfSxcbiAgc2V0OiBmdW5jdGlvbiBzZXQodmFsdWUpIHtcbiAgICAvLyB3ZSBpZ25vcmUgdGhlIHZhbHVlIGlmIHRoZSBzdHJlYW1cbiAgICAvLyBoYXMgbm90IGJlZW4gaW5pdGlhbGl6ZWQgeWV0XG4gICAgaWYgKCF0aGlzLl93cml0YWJsZVN0YXRlKSB7XG4gICAgICByZXR1cm47XG4gICAgfSAvLyBiYWNrd2FyZCBjb21wYXRpYmlsaXR5LCB0aGUgdXNlciBpcyBleHBsaWNpdGx5XG4gICAgLy8gbWFuYWdpbmcgZGVzdHJveWVkXG5cblxuICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUuZGVzdHJveWVkID0gdmFsdWU7XG4gIH1cbn0pO1xuV3JpdGFibGUucHJvdG90eXBlLmRlc3Ryb3kgPSBkZXN0cm95SW1wbC5kZXN0cm95O1xuV3JpdGFibGUucHJvdG90eXBlLl91bmRlc3Ryb3kgPSBkZXN0cm95SW1wbC51bmRlc3Ryb3k7XG5cbldyaXRhYmxlLnByb3RvdHlwZS5fZGVzdHJveSA9IGZ1bmN0aW9uIChlcnIsIGNiKSB7XG4gIGNiKGVycik7XG59OyIsIid1c2Ugc3RyaWN0JztcblxudmFyIF9PYmplY3Qkc2V0UHJvdG90eXBlTztcblxuZnVuY3Rpb24gX2RlZmluZVByb3BlcnR5KG9iaiwga2V5LCB2YWx1ZSkgeyBpZiAoa2V5IGluIG9iaikgeyBPYmplY3QuZGVmaW5lUHJvcGVydHkob2JqLCBrZXksIHsgdmFsdWU6IHZhbHVlLCBlbnVtZXJhYmxlOiB0cnVlLCBjb25maWd1cmFibGU6IHRydWUsIHdyaXRhYmxlOiB0cnVlIH0pOyB9IGVsc2UgeyBvYmpba2V5XSA9IHZhbHVlOyB9IHJldHVybiBvYmo7IH1cblxudmFyIGZpbmlzaGVkID0gcmVxdWlyZSgnLi9lbmQtb2Ytc3RyZWFtJyk7XG5cbnZhciBrTGFzdFJlc29sdmUgPSBTeW1ib2woJ2xhc3RSZXNvbHZlJyk7XG52YXIga0xhc3RSZWplY3QgPSBTeW1ib2woJ2xhc3RSZWplY3QnKTtcbnZhciBrRXJyb3IgPSBTeW1ib2woJ2Vycm9yJyk7XG52YXIga0VuZGVkID0gU3ltYm9sKCdlbmRlZCcpO1xudmFyIGtMYXN0UHJvbWlzZSA9IFN5bWJvbCgnbGFzdFByb21pc2UnKTtcbnZhciBrSGFuZGxlUHJvbWlzZSA9IFN5bWJvbCgnaGFuZGxlUHJvbWlzZScpO1xudmFyIGtTdHJlYW0gPSBTeW1ib2woJ3N0cmVhbScpO1xuXG5mdW5jdGlvbiBjcmVhdGVJdGVyUmVzdWx0KHZhbHVlLCBkb25lKSB7XG4gIHJldHVybiB7XG4gICAgdmFsdWU6IHZhbHVlLFxuICAgIGRvbmU6IGRvbmVcbiAgfTtcbn1cblxuZnVuY3Rpb24gcmVhZEFuZFJlc29sdmUoaXRlcikge1xuICB2YXIgcmVzb2x2ZSA9IGl0ZXJba0xhc3RSZXNvbHZlXTtcblxuICBpZiAocmVzb2x2ZSAhPT0gbnVsbCkge1xuICAgIHZhciBkYXRhID0gaXRlcltrU3RyZWFtXS5yZWFkKCk7IC8vIHdlIGRlZmVyIGlmIGRhdGEgaXMgbnVsbFxuICAgIC8vIHdlIGNhbiBiZSBleHBlY3RpbmcgZWl0aGVyICdlbmQnIG9yXG4gICAgLy8gJ2Vycm9yJ1xuXG4gICAgaWYgKGRhdGEgIT09IG51bGwpIHtcbiAgICAgIGl0ZXJba0xhc3RQcm9taXNlXSA9IG51bGw7XG4gICAgICBpdGVyW2tMYXN0UmVzb2x2ZV0gPSBudWxsO1xuICAgICAgaXRlcltrTGFzdFJlamVjdF0gPSBudWxsO1xuICAgICAgcmVzb2x2ZShjcmVhdGVJdGVyUmVzdWx0KGRhdGEsIGZhbHNlKSk7XG4gICAgfVxuICB9XG59XG5cbmZ1bmN0aW9uIG9uUmVhZGFibGUoaXRlcikge1xuICAvLyB3ZSB3YWl0IGZvciB0aGUgbmV4dCB0aWNrLCBiZWNhdXNlIGl0IG1pZ2h0XG4gIC8vIGVtaXQgYW4gZXJyb3Igd2l0aCBwcm9jZXNzLm5leHRUaWNrXG4gIHByb2Nlc3MubmV4dFRpY2socmVhZEFuZFJlc29sdmUsIGl0ZXIpO1xufVxuXG5mdW5jdGlvbiB3cmFwRm9yTmV4dChsYXN0UHJvbWlzZSwgaXRlcikge1xuICByZXR1cm4gZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgIGxhc3RQcm9taXNlLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgaWYgKGl0ZXJba0VuZGVkXSkge1xuICAgICAgICByZXNvbHZlKGNyZWF0ZUl0ZXJSZXN1bHQodW5kZWZpbmVkLCB0cnVlKSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgaXRlcltrSGFuZGxlUHJvbWlzZV0ocmVzb2x2ZSwgcmVqZWN0KTtcbiAgICB9LCByZWplY3QpO1xuICB9O1xufVxuXG52YXIgQXN5bmNJdGVyYXRvclByb3RvdHlwZSA9IE9iamVjdC5nZXRQcm90b3R5cGVPZihmdW5jdGlvbiAoKSB7fSk7XG52YXIgUmVhZGFibGVTdHJlYW1Bc3luY0l0ZXJhdG9yUHJvdG90eXBlID0gT2JqZWN0LnNldFByb3RvdHlwZU9mKChfT2JqZWN0JHNldFByb3RvdHlwZU8gPSB7XG4gIGdldCBzdHJlYW0oKSB7XG4gICAgcmV0dXJuIHRoaXNba1N0cmVhbV07XG4gIH0sXG5cbiAgbmV4dDogZnVuY3Rpb24gbmV4dCgpIHtcbiAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgLy8gaWYgd2UgaGF2ZSBkZXRlY3RlZCBhbiBlcnJvciBpbiB0aGUgbWVhbndoaWxlXG4gICAgLy8gcmVqZWN0IHN0cmFpZ2h0IGF3YXlcbiAgICB2YXIgZXJyb3IgPSB0aGlzW2tFcnJvcl07XG5cbiAgICBpZiAoZXJyb3IgIT09IG51bGwpIHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gICAgfVxuXG4gICAgaWYgKHRoaXNba0VuZGVkXSkge1xuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShjcmVhdGVJdGVyUmVzdWx0KHVuZGVmaW5lZCwgdHJ1ZSkpO1xuICAgIH1cblxuICAgIGlmICh0aGlzW2tTdHJlYW1dLmRlc3Ryb3llZCkge1xuICAgICAgLy8gV2UgbmVlZCB0byBkZWZlciB2aWEgbmV4dFRpY2sgYmVjYXVzZSBpZiAuZGVzdHJveShlcnIpIGlzXG4gICAgICAvLyBjYWxsZWQsIHRoZSBlcnJvciB3aWxsIGJlIGVtaXR0ZWQgdmlhIG5leHRUaWNrLCBhbmRcbiAgICAgIC8vIHdlIGNhbm5vdCBndWFyYW50ZWUgdGhhdCB0aGVyZSBpcyBubyBlcnJvciBsaW5nZXJpbmcgYXJvdW5kXG4gICAgICAvLyB3YWl0aW5nIHRvIGJlIGVtaXR0ZWQuXG4gICAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICBwcm9jZXNzLm5leHRUaWNrKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBpZiAoX3RoaXNba0Vycm9yXSkge1xuICAgICAgICAgICAgcmVqZWN0KF90aGlzW2tFcnJvcl0pO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXNvbHZlKGNyZWF0ZUl0ZXJSZXN1bHQodW5kZWZpbmVkLCB0cnVlKSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH0gLy8gaWYgd2UgaGF2ZSBtdWx0aXBsZSBuZXh0KCkgY2FsbHNcbiAgICAvLyB3ZSB3aWxsIHdhaXQgZm9yIHRoZSBwcmV2aW91cyBQcm9taXNlIHRvIGZpbmlzaFxuICAgIC8vIHRoaXMgbG9naWMgaXMgb3B0aW1pemVkIHRvIHN1cHBvcnQgZm9yIGF3YWl0IGxvb3BzLFxuICAgIC8vIHdoZXJlIG5leHQoKSBpcyBvbmx5IGNhbGxlZCBvbmNlIGF0IGEgdGltZVxuXG5cbiAgICB2YXIgbGFzdFByb21pc2UgPSB0aGlzW2tMYXN0UHJvbWlzZV07XG4gICAgdmFyIHByb21pc2U7XG5cbiAgICBpZiAobGFzdFByb21pc2UpIHtcbiAgICAgIHByb21pc2UgPSBuZXcgUHJvbWlzZSh3cmFwRm9yTmV4dChsYXN0UHJvbWlzZSwgdGhpcykpO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBmYXN0IHBhdGggbmVlZGVkIHRvIHN1cHBvcnQgbXVsdGlwbGUgdGhpcy5wdXNoKClcbiAgICAgIC8vIHdpdGhvdXQgdHJpZ2dlcmluZyB0aGUgbmV4dCgpIHF1ZXVlXG4gICAgICB2YXIgZGF0YSA9IHRoaXNba1N0cmVhbV0ucmVhZCgpO1xuXG4gICAgICBpZiAoZGF0YSAhPT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGNyZWF0ZUl0ZXJSZXN1bHQoZGF0YSwgZmFsc2UpKTtcbiAgICAgIH1cblxuICAgICAgcHJvbWlzZSA9IG5ldyBQcm9taXNlKHRoaXNba0hhbmRsZVByb21pc2VdKTtcbiAgICB9XG5cbiAgICB0aGlzW2tMYXN0UHJvbWlzZV0gPSBwcm9taXNlO1xuICAgIHJldHVybiBwcm9taXNlO1xuICB9XG59LCBfZGVmaW5lUHJvcGVydHkoX09iamVjdCRzZXRQcm90b3R5cGVPLCBTeW1ib2wuYXN5bmNJdGVyYXRvciwgZnVuY3Rpb24gKCkge1xuICByZXR1cm4gdGhpcztcbn0pLCBfZGVmaW5lUHJvcGVydHkoX09iamVjdCRzZXRQcm90b3R5cGVPLCBcInJldHVyblwiLCBmdW5jdGlvbiBfcmV0dXJuKCkge1xuICB2YXIgX3RoaXMyID0gdGhpcztcblxuICAvLyBkZXN0cm95KGVyciwgY2IpIGlzIGEgcHJpdmF0ZSBBUElcbiAgLy8gd2UgY2FuIGd1YXJhbnRlZSB3ZSBoYXZlIHRoYXQgaGVyZSwgYmVjYXVzZSB3ZSBjb250cm9sIHRoZVxuICAvLyBSZWFkYWJsZSBjbGFzcyB0aGlzIGlzIGF0dGFjaGVkIHRvXG4gIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgX3RoaXMyW2tTdHJlYW1dLmRlc3Ryb3kobnVsbCwgZnVuY3Rpb24gKGVycikge1xuICAgICAgaWYgKGVycikge1xuICAgICAgICByZWplY3QoZXJyKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICByZXNvbHZlKGNyZWF0ZUl0ZXJSZXN1bHQodW5kZWZpbmVkLCB0cnVlKSk7XG4gICAgfSk7XG4gIH0pO1xufSksIF9PYmplY3Qkc2V0UHJvdG90eXBlTyksIEFzeW5jSXRlcmF0b3JQcm90b3R5cGUpO1xuXG52YXIgY3JlYXRlUmVhZGFibGVTdHJlYW1Bc3luY0l0ZXJhdG9yID0gZnVuY3Rpb24gY3JlYXRlUmVhZGFibGVTdHJlYW1Bc3luY0l0ZXJhdG9yKHN0cmVhbSkge1xuICB2YXIgX09iamVjdCRjcmVhdGU7XG5cbiAgdmFyIGl0ZXJhdG9yID0gT2JqZWN0LmNyZWF0ZShSZWFkYWJsZVN0cmVhbUFzeW5jSXRlcmF0b3JQcm90b3R5cGUsIChfT2JqZWN0JGNyZWF0ZSA9IHt9LCBfZGVmaW5lUHJvcGVydHkoX09iamVjdCRjcmVhdGUsIGtTdHJlYW0sIHtcbiAgICB2YWx1ZTogc3RyZWFtLFxuICAgIHdyaXRhYmxlOiB0cnVlXG4gIH0pLCBfZGVmaW5lUHJvcGVydHkoX09iamVjdCRjcmVhdGUsIGtMYXN0UmVzb2x2ZSwge1xuICAgIHZhbHVlOiBudWxsLFxuICAgIHdyaXRhYmxlOiB0cnVlXG4gIH0pLCBfZGVmaW5lUHJvcGVydHkoX09iamVjdCRjcmVhdGUsIGtMYXN0UmVqZWN0LCB7XG4gICAgdmFsdWU6IG51bGwsXG4gICAgd3JpdGFibGU6IHRydWVcbiAgfSksIF9kZWZpbmVQcm9wZXJ0eShfT2JqZWN0JGNyZWF0ZSwga0Vycm9yLCB7XG4gICAgdmFsdWU6IG51bGwsXG4gICAgd3JpdGFibGU6IHRydWVcbiAgfSksIF9kZWZpbmVQcm9wZXJ0eShfT2JqZWN0JGNyZWF0ZSwga0VuZGVkLCB7XG4gICAgdmFsdWU6IHN0cmVhbS5fcmVhZGFibGVTdGF0ZS5lbmRFbWl0dGVkLFxuICAgIHdyaXRhYmxlOiB0cnVlXG4gIH0pLCBfZGVmaW5lUHJvcGVydHkoX09iamVjdCRjcmVhdGUsIGtIYW5kbGVQcm9taXNlLCB7XG4gICAgdmFsdWU6IGZ1bmN0aW9uIHZhbHVlKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgdmFyIGRhdGEgPSBpdGVyYXRvcltrU3RyZWFtXS5yZWFkKCk7XG5cbiAgICAgIGlmIChkYXRhKSB7XG4gICAgICAgIGl0ZXJhdG9yW2tMYXN0UHJvbWlzZV0gPSBudWxsO1xuICAgICAgICBpdGVyYXRvcltrTGFzdFJlc29sdmVdID0gbnVsbDtcbiAgICAgICAgaXRlcmF0b3Jba0xhc3RSZWplY3RdID0gbnVsbDtcbiAgICAgICAgcmVzb2x2ZShjcmVhdGVJdGVyUmVzdWx0KGRhdGEsIGZhbHNlKSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpdGVyYXRvcltrTGFzdFJlc29sdmVdID0gcmVzb2x2ZTtcbiAgICAgICAgaXRlcmF0b3Jba0xhc3RSZWplY3RdID0gcmVqZWN0O1xuICAgICAgfVxuICAgIH0sXG4gICAgd3JpdGFibGU6IHRydWVcbiAgfSksIF9PYmplY3QkY3JlYXRlKSk7XG4gIGl0ZXJhdG9yW2tMYXN0UHJvbWlzZV0gPSBudWxsO1xuICBmaW5pc2hlZChzdHJlYW0sIGZ1bmN0aW9uIChlcnIpIHtcbiAgICBpZiAoZXJyICYmIGVyci5jb2RlICE9PSAnRVJSX1NUUkVBTV9QUkVNQVRVUkVfQ0xPU0UnKSB7XG4gICAgICB2YXIgcmVqZWN0ID0gaXRlcmF0b3Jba0xhc3RSZWplY3RdOyAvLyByZWplY3QgaWYgd2UgYXJlIHdhaXRpbmcgZm9yIGRhdGEgaW4gdGhlIFByb21pc2VcbiAgICAgIC8vIHJldHVybmVkIGJ5IG5leHQoKSBhbmQgc3RvcmUgdGhlIGVycm9yXG5cbiAgICAgIGlmIChyZWplY3QgIT09IG51bGwpIHtcbiAgICAgICAgaXRlcmF0b3Jba0xhc3RQcm9taXNlXSA9IG51bGw7XG4gICAgICAgIGl0ZXJhdG9yW2tMYXN0UmVzb2x2ZV0gPSBudWxsO1xuICAgICAgICBpdGVyYXRvcltrTGFzdFJlamVjdF0gPSBudWxsO1xuICAgICAgICByZWplY3QoZXJyKTtcbiAgICAgIH1cblxuICAgICAgaXRlcmF0b3Jba0Vycm9yXSA9IGVycjtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB2YXIgcmVzb2x2ZSA9IGl0ZXJhdG9yW2tMYXN0UmVzb2x2ZV07XG5cbiAgICBpZiAocmVzb2x2ZSAhPT0gbnVsbCkge1xuICAgICAgaXRlcmF0b3Jba0xhc3RQcm9taXNlXSA9IG51bGw7XG4gICAgICBpdGVyYXRvcltrTGFzdFJlc29sdmVdID0gbnVsbDtcbiAgICAgIGl0ZXJhdG9yW2tMYXN0UmVqZWN0XSA9IG51bGw7XG4gICAgICByZXNvbHZlKGNyZWF0ZUl0ZXJSZXN1bHQodW5kZWZpbmVkLCB0cnVlKSk7XG4gICAgfVxuXG4gICAgaXRlcmF0b3Jba0VuZGVkXSA9IHRydWU7XG4gIH0pO1xuICBzdHJlYW0ub24oJ3JlYWRhYmxlJywgb25SZWFkYWJsZS5iaW5kKG51bGwsIGl0ZXJhdG9yKSk7XG4gIHJldHVybiBpdGVyYXRvcjtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0gY3JlYXRlUmVhZGFibGVTdHJlYW1Bc3luY0l0ZXJhdG9yOyIsIid1c2Ugc3RyaWN0JztcblxuZnVuY3Rpb24gb3duS2V5cyhvYmplY3QsIGVudW1lcmFibGVPbmx5KSB7IHZhciBrZXlzID0gT2JqZWN0LmtleXMob2JqZWN0KTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHsgdmFyIHN5bWJvbHMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKG9iamVjdCk7IGlmIChlbnVtZXJhYmxlT25seSkgc3ltYm9scyA9IHN5bWJvbHMuZmlsdGVyKGZ1bmN0aW9uIChzeW0pIHsgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3Iob2JqZWN0LCBzeW0pLmVudW1lcmFibGU7IH0pOyBrZXlzLnB1c2guYXBwbHkoa2V5cywgc3ltYm9scyk7IH0gcmV0dXJuIGtleXM7IH1cblxuZnVuY3Rpb24gX29iamVjdFNwcmVhZCh0YXJnZXQpIHsgZm9yICh2YXIgaSA9IDE7IGkgPCBhcmd1bWVudHMubGVuZ3RoOyBpKyspIHsgdmFyIHNvdXJjZSA9IGFyZ3VtZW50c1tpXSAhPSBudWxsID8gYXJndW1lbnRzW2ldIDoge307IGlmIChpICUgMikgeyBvd25LZXlzKE9iamVjdChzb3VyY2UpLCB0cnVlKS5mb3JFYWNoKGZ1bmN0aW9uIChrZXkpIHsgX2RlZmluZVByb3BlcnR5KHRhcmdldCwga2V5LCBzb3VyY2Vba2V5XSk7IH0pOyB9IGVsc2UgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKHRhcmdldCwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMoc291cmNlKSk7IH0gZWxzZSB7IG93bktleXMoT2JqZWN0KHNvdXJjZSkpLmZvckVhY2goZnVuY3Rpb24gKGtleSkgeyBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBrZXksIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3Ioc291cmNlLCBrZXkpKTsgfSk7IH0gfSByZXR1cm4gdGFyZ2V0OyB9XG5cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShvYmosIGtleSwgdmFsdWUpIHsgaWYgKGtleSBpbiBvYmopIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KG9iaiwga2V5LCB7IHZhbHVlOiB2YWx1ZSwgZW51bWVyYWJsZTogdHJ1ZSwgY29uZmlndXJhYmxlOiB0cnVlLCB3cml0YWJsZTogdHJ1ZSB9KTsgfSBlbHNlIHsgb2JqW2tleV0gPSB2YWx1ZTsgfSByZXR1cm4gb2JqOyB9XG5cbmZ1bmN0aW9uIF9jbGFzc0NhbGxDaGVjayhpbnN0YW5jZSwgQ29uc3RydWN0b3IpIHsgaWYgKCEoaW5zdGFuY2UgaW5zdGFuY2VvZiBDb25zdHJ1Y3RvcikpIHsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCBjYWxsIGEgY2xhc3MgYXMgYSBmdW5jdGlvblwiKTsgfSB9XG5cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0aWVzKHRhcmdldCwgcHJvcHMpIHsgZm9yICh2YXIgaSA9IDA7IGkgPCBwcm9wcy5sZW5ndGg7IGkrKykgeyB2YXIgZGVzY3JpcHRvciA9IHByb3BzW2ldOyBkZXNjcmlwdG9yLmVudW1lcmFibGUgPSBkZXNjcmlwdG9yLmVudW1lcmFibGUgfHwgZmFsc2U7IGRlc2NyaXB0b3IuY29uZmlndXJhYmxlID0gdHJ1ZTsgaWYgKFwidmFsdWVcIiBpbiBkZXNjcmlwdG9yKSBkZXNjcmlwdG9yLndyaXRhYmxlID0gdHJ1ZTsgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwgZGVzY3JpcHRvci5rZXksIGRlc2NyaXB0b3IpOyB9IH1cblxuZnVuY3Rpb24gX2NyZWF0ZUNsYXNzKENvbnN0cnVjdG9yLCBwcm90b1Byb3BzLCBzdGF0aWNQcm9wcykgeyBpZiAocHJvdG9Qcm9wcykgX2RlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IucHJvdG90eXBlLCBwcm90b1Byb3BzKTsgaWYgKHN0YXRpY1Byb3BzKSBfZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvciwgc3RhdGljUHJvcHMpOyByZXR1cm4gQ29uc3RydWN0b3I7IH1cblxudmFyIF9yZXF1aXJlID0gcmVxdWlyZSgnYnVmZmVyJyksXG4gICAgQnVmZmVyID0gX3JlcXVpcmUuQnVmZmVyO1xuXG52YXIgX3JlcXVpcmUyID0gcmVxdWlyZSgndXRpbCcpLFxuICAgIGluc3BlY3QgPSBfcmVxdWlyZTIuaW5zcGVjdDtcblxudmFyIGN1c3RvbSA9IGluc3BlY3QgJiYgaW5zcGVjdC5jdXN0b20gfHwgJ2luc3BlY3QnO1xuXG5mdW5jdGlvbiBjb3B5QnVmZmVyKHNyYywgdGFyZ2V0LCBvZmZzZXQpIHtcbiAgQnVmZmVyLnByb3RvdHlwZS5jb3B5LmNhbGwoc3JjLCB0YXJnZXQsIG9mZnNldCk7XG59XG5cbm1vZHVsZS5leHBvcnRzID1cbi8qI19fUFVSRV9fKi9cbmZ1bmN0aW9uICgpIHtcbiAgZnVuY3Rpb24gQnVmZmVyTGlzdCgpIHtcbiAgICBfY2xhc3NDYWxsQ2hlY2sodGhpcywgQnVmZmVyTGlzdCk7XG5cbiAgICB0aGlzLmhlYWQgPSBudWxsO1xuICAgIHRoaXMudGFpbCA9IG51bGw7XG4gICAgdGhpcy5sZW5ndGggPSAwO1xuICB9XG5cbiAgX2NyZWF0ZUNsYXNzKEJ1ZmZlckxpc3QsIFt7XG4gICAga2V5OiBcInB1c2hcIixcbiAgICB2YWx1ZTogZnVuY3Rpb24gcHVzaCh2KSB7XG4gICAgICB2YXIgZW50cnkgPSB7XG4gICAgICAgIGRhdGE6IHYsXG4gICAgICAgIG5leHQ6IG51bGxcbiAgICAgIH07XG4gICAgICBpZiAodGhpcy5sZW5ndGggPiAwKSB0aGlzLnRhaWwubmV4dCA9IGVudHJ5O2Vsc2UgdGhpcy5oZWFkID0gZW50cnk7XG4gICAgICB0aGlzLnRhaWwgPSBlbnRyeTtcbiAgICAgICsrdGhpcy5sZW5ndGg7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiBcInVuc2hpZnRcIixcbiAgICB2YWx1ZTogZnVuY3Rpb24gdW5zaGlmdCh2KSB7XG4gICAgICB2YXIgZW50cnkgPSB7XG4gICAgICAgIGRhdGE6IHYsXG4gICAgICAgIG5leHQ6IHRoaXMuaGVhZFxuICAgICAgfTtcbiAgICAgIGlmICh0aGlzLmxlbmd0aCA9PT0gMCkgdGhpcy50YWlsID0gZW50cnk7XG4gICAgICB0aGlzLmhlYWQgPSBlbnRyeTtcbiAgICAgICsrdGhpcy5sZW5ndGg7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiBcInNoaWZ0XCIsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHNoaWZ0KCkge1xuICAgICAgaWYgKHRoaXMubGVuZ3RoID09PSAwKSByZXR1cm47XG4gICAgICB2YXIgcmV0ID0gdGhpcy5oZWFkLmRhdGE7XG4gICAgICBpZiAodGhpcy5sZW5ndGggPT09IDEpIHRoaXMuaGVhZCA9IHRoaXMudGFpbCA9IG51bGw7ZWxzZSB0aGlzLmhlYWQgPSB0aGlzLmhlYWQubmV4dDtcbiAgICAgIC0tdGhpcy5sZW5ndGg7XG4gICAgICByZXR1cm4gcmV0O1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogXCJjbGVhclwiLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBjbGVhcigpIHtcbiAgICAgIHRoaXMuaGVhZCA9IHRoaXMudGFpbCA9IG51bGw7XG4gICAgICB0aGlzLmxlbmd0aCA9IDA7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiBcImpvaW5cIixcbiAgICB2YWx1ZTogZnVuY3Rpb24gam9pbihzKSB7XG4gICAgICBpZiAodGhpcy5sZW5ndGggPT09IDApIHJldHVybiAnJztcbiAgICAgIHZhciBwID0gdGhpcy5oZWFkO1xuICAgICAgdmFyIHJldCA9ICcnICsgcC5kYXRhO1xuXG4gICAgICB3aGlsZSAocCA9IHAubmV4dCkge1xuICAgICAgICByZXQgKz0gcyArIHAuZGF0YTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHJldDtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6IFwiY29uY2F0XCIsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGNvbmNhdChuKSB7XG4gICAgICBpZiAodGhpcy5sZW5ndGggPT09IDApIHJldHVybiBCdWZmZXIuYWxsb2MoMCk7XG4gICAgICB2YXIgcmV0ID0gQnVmZmVyLmFsbG9jVW5zYWZlKG4gPj4+IDApO1xuICAgICAgdmFyIHAgPSB0aGlzLmhlYWQ7XG4gICAgICB2YXIgaSA9IDA7XG5cbiAgICAgIHdoaWxlIChwKSB7XG4gICAgICAgIGNvcHlCdWZmZXIocC5kYXRhLCByZXQsIGkpO1xuICAgICAgICBpICs9IHAuZGF0YS5sZW5ndGg7XG4gICAgICAgIHAgPSBwLm5leHQ7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiByZXQ7XG4gICAgfSAvLyBDb25zdW1lcyBhIHNwZWNpZmllZCBhbW91bnQgb2YgYnl0ZXMgb3IgY2hhcmFjdGVycyBmcm9tIHRoZSBidWZmZXJlZCBkYXRhLlxuXG4gIH0sIHtcbiAgICBrZXk6IFwiY29uc3VtZVwiLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBjb25zdW1lKG4sIGhhc1N0cmluZ3MpIHtcbiAgICAgIHZhciByZXQ7XG5cbiAgICAgIGlmIChuIDwgdGhpcy5oZWFkLmRhdGEubGVuZ3RoKSB7XG4gICAgICAgIC8vIGBzbGljZWAgaXMgdGhlIHNhbWUgZm9yIGJ1ZmZlcnMgYW5kIHN0cmluZ3MuXG4gICAgICAgIHJldCA9IHRoaXMuaGVhZC5kYXRhLnNsaWNlKDAsIG4pO1xuICAgICAgICB0aGlzLmhlYWQuZGF0YSA9IHRoaXMuaGVhZC5kYXRhLnNsaWNlKG4pO1xuICAgICAgfSBlbHNlIGlmIChuID09PSB0aGlzLmhlYWQuZGF0YS5sZW5ndGgpIHtcbiAgICAgICAgLy8gRmlyc3QgY2h1bmsgaXMgYSBwZXJmZWN0IG1hdGNoLlxuICAgICAgICByZXQgPSB0aGlzLnNoaWZ0KCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBSZXN1bHQgc3BhbnMgbW9yZSB0aGFuIG9uZSBidWZmZXIuXG4gICAgICAgIHJldCA9IGhhc1N0cmluZ3MgPyB0aGlzLl9nZXRTdHJpbmcobikgOiB0aGlzLl9nZXRCdWZmZXIobik7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiByZXQ7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiBcImZpcnN0XCIsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGZpcnN0KCkge1xuICAgICAgcmV0dXJuIHRoaXMuaGVhZC5kYXRhO1xuICAgIH0gLy8gQ29uc3VtZXMgYSBzcGVjaWZpZWQgYW1vdW50IG9mIGNoYXJhY3RlcnMgZnJvbSB0aGUgYnVmZmVyZWQgZGF0YS5cblxuICB9LCB7XG4gICAga2V5OiBcIl9nZXRTdHJpbmdcIixcbiAgICB2YWx1ZTogZnVuY3Rpb24gX2dldFN0cmluZyhuKSB7XG4gICAgICB2YXIgcCA9IHRoaXMuaGVhZDtcbiAgICAgIHZhciBjID0gMTtcbiAgICAgIHZhciByZXQgPSBwLmRhdGE7XG4gICAgICBuIC09IHJldC5sZW5ndGg7XG5cbiAgICAgIHdoaWxlIChwID0gcC5uZXh0KSB7XG4gICAgICAgIHZhciBzdHIgPSBwLmRhdGE7XG4gICAgICAgIHZhciBuYiA9IG4gPiBzdHIubGVuZ3RoID8gc3RyLmxlbmd0aCA6IG47XG4gICAgICAgIGlmIChuYiA9PT0gc3RyLmxlbmd0aCkgcmV0ICs9IHN0cjtlbHNlIHJldCArPSBzdHIuc2xpY2UoMCwgbik7XG4gICAgICAgIG4gLT0gbmI7XG5cbiAgICAgICAgaWYgKG4gPT09IDApIHtcbiAgICAgICAgICBpZiAobmIgPT09IHN0ci5sZW5ndGgpIHtcbiAgICAgICAgICAgICsrYztcbiAgICAgICAgICAgIGlmIChwLm5leHQpIHRoaXMuaGVhZCA9IHAubmV4dDtlbHNlIHRoaXMuaGVhZCA9IHRoaXMudGFpbCA9IG51bGw7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuaGVhZCA9IHA7XG4gICAgICAgICAgICBwLmRhdGEgPSBzdHIuc2xpY2UobmIpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG5cbiAgICAgICAgKytjO1xuICAgICAgfVxuXG4gICAgICB0aGlzLmxlbmd0aCAtPSBjO1xuICAgICAgcmV0dXJuIHJldDtcbiAgICB9IC8vIENvbnN1bWVzIGEgc3BlY2lmaWVkIGFtb3VudCBvZiBieXRlcyBmcm9tIHRoZSBidWZmZXJlZCBkYXRhLlxuXG4gIH0sIHtcbiAgICBrZXk6IFwiX2dldEJ1ZmZlclwiLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBfZ2V0QnVmZmVyKG4pIHtcbiAgICAgIHZhciByZXQgPSBCdWZmZXIuYWxsb2NVbnNhZmUobik7XG4gICAgICB2YXIgcCA9IHRoaXMuaGVhZDtcbiAgICAgIHZhciBjID0gMTtcbiAgICAgIHAuZGF0YS5jb3B5KHJldCk7XG4gICAgICBuIC09IHAuZGF0YS5sZW5ndGg7XG5cbiAgICAgIHdoaWxlIChwID0gcC5uZXh0KSB7XG4gICAgICAgIHZhciBidWYgPSBwLmRhdGE7XG4gICAgICAgIHZhciBuYiA9IG4gPiBidWYubGVuZ3RoID8gYnVmLmxlbmd0aCA6IG47XG4gICAgICAgIGJ1Zi5jb3B5KHJldCwgcmV0Lmxlbmd0aCAtIG4sIDAsIG5iKTtcbiAgICAgICAgbiAtPSBuYjtcblxuICAgICAgICBpZiAobiA9PT0gMCkge1xuICAgICAgICAgIGlmIChuYiA9PT0gYnVmLmxlbmd0aCkge1xuICAgICAgICAgICAgKytjO1xuICAgICAgICAgICAgaWYgKHAubmV4dCkgdGhpcy5oZWFkID0gcC5uZXh0O2Vsc2UgdGhpcy5oZWFkID0gdGhpcy50YWlsID0gbnVsbDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5oZWFkID0gcDtcbiAgICAgICAgICAgIHAuZGF0YSA9IGJ1Zi5zbGljZShuYik7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cblxuICAgICAgICArK2M7XG4gICAgICB9XG5cbiAgICAgIHRoaXMubGVuZ3RoIC09IGM7XG4gICAgICByZXR1cm4gcmV0O1xuICAgIH0gLy8gTWFrZSBzdXJlIHRoZSBsaW5rZWQgbGlzdCBvbmx5IHNob3dzIHRoZSBtaW5pbWFsIG5lY2Vzc2FyeSBpbmZvcm1hdGlvbi5cblxuICB9LCB7XG4gICAga2V5OiBjdXN0b20sXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHZhbHVlKF8sIG9wdGlvbnMpIHtcbiAgICAgIHJldHVybiBpbnNwZWN0KHRoaXMsIF9vYmplY3RTcHJlYWQoe30sIG9wdGlvbnMsIHtcbiAgICAgICAgLy8gT25seSBpbnNwZWN0IG9uZSBsZXZlbC5cbiAgICAgICAgZGVwdGg6IDAsXG4gICAgICAgIC8vIEl0IHNob3VsZCBub3QgcmVjdXJzZS5cbiAgICAgICAgY3VzdG9tSW5zcGVjdDogZmFsc2VcbiAgICAgIH0pKTtcbiAgICB9XG4gIH1dKTtcblxuICByZXR1cm4gQnVmZmVyTGlzdDtcbn0oKTsiLCIndXNlIHN0cmljdCc7IC8vIHVuZG9jdW1lbnRlZCBjYigpIEFQSSwgbmVlZGVkIGZvciBjb3JlLCBub3QgZm9yIHB1YmxpYyBBUElcblxuZnVuY3Rpb24gZGVzdHJveShlcnIsIGNiKSB7XG4gIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgdmFyIHJlYWRhYmxlRGVzdHJveWVkID0gdGhpcy5fcmVhZGFibGVTdGF0ZSAmJiB0aGlzLl9yZWFkYWJsZVN0YXRlLmRlc3Ryb3llZDtcbiAgdmFyIHdyaXRhYmxlRGVzdHJveWVkID0gdGhpcy5fd3JpdGFibGVTdGF0ZSAmJiB0aGlzLl93cml0YWJsZVN0YXRlLmRlc3Ryb3llZDtcblxuICBpZiAocmVhZGFibGVEZXN0cm95ZWQgfHwgd3JpdGFibGVEZXN0cm95ZWQpIHtcbiAgICBpZiAoY2IpIHtcbiAgICAgIGNiKGVycik7XG4gICAgfSBlbHNlIGlmIChlcnIpIHtcbiAgICAgIGlmICghdGhpcy5fd3JpdGFibGVTdGF0ZSkge1xuICAgICAgICBwcm9jZXNzLm5leHRUaWNrKGVtaXRFcnJvck5ULCB0aGlzLCBlcnIpO1xuICAgICAgfSBlbHNlIGlmICghdGhpcy5fd3JpdGFibGVTdGF0ZS5lcnJvckVtaXR0ZWQpIHtcbiAgICAgICAgdGhpcy5fd3JpdGFibGVTdGF0ZS5lcnJvckVtaXR0ZWQgPSB0cnVlO1xuICAgICAgICBwcm9jZXNzLm5leHRUaWNrKGVtaXRFcnJvck5ULCB0aGlzLCBlcnIpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiB0aGlzO1xuICB9IC8vIHdlIHNldCBkZXN0cm95ZWQgdG8gdHJ1ZSBiZWZvcmUgZmlyaW5nIGVycm9yIGNhbGxiYWNrcyBpbiBvcmRlclxuICAvLyB0byBtYWtlIGl0IHJlLWVudHJhbmNlIHNhZmUgaW4gY2FzZSBkZXN0cm95KCkgaXMgY2FsbGVkIHdpdGhpbiBjYWxsYmFja3NcblxuXG4gIGlmICh0aGlzLl9yZWFkYWJsZVN0YXRlKSB7XG4gICAgdGhpcy5fcmVhZGFibGVTdGF0ZS5kZXN0cm95ZWQgPSB0cnVlO1xuICB9IC8vIGlmIHRoaXMgaXMgYSBkdXBsZXggc3RyZWFtIG1hcmsgdGhlIHdyaXRhYmxlIHBhcnQgYXMgZGVzdHJveWVkIGFzIHdlbGxcblxuXG4gIGlmICh0aGlzLl93cml0YWJsZVN0YXRlKSB7XG4gICAgdGhpcy5fd3JpdGFibGVTdGF0ZS5kZXN0cm95ZWQgPSB0cnVlO1xuICB9XG5cbiAgdGhpcy5fZGVzdHJveShlcnIgfHwgbnVsbCwgZnVuY3Rpb24gKGVycikge1xuICAgIGlmICghY2IgJiYgZXJyKSB7XG4gICAgICBpZiAoIV90aGlzLl93cml0YWJsZVN0YXRlKSB7XG4gICAgICAgIHByb2Nlc3MubmV4dFRpY2soZW1pdEVycm9yQW5kQ2xvc2VOVCwgX3RoaXMsIGVycik7XG4gICAgICB9IGVsc2UgaWYgKCFfdGhpcy5fd3JpdGFibGVTdGF0ZS5lcnJvckVtaXR0ZWQpIHtcbiAgICAgICAgX3RoaXMuX3dyaXRhYmxlU3RhdGUuZXJyb3JFbWl0dGVkID0gdHJ1ZTtcbiAgICAgICAgcHJvY2Vzcy5uZXh0VGljayhlbWl0RXJyb3JBbmRDbG9zZU5ULCBfdGhpcywgZXJyKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHByb2Nlc3MubmV4dFRpY2soZW1pdENsb3NlTlQsIF90aGlzKTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGNiKSB7XG4gICAgICBwcm9jZXNzLm5leHRUaWNrKGVtaXRDbG9zZU5ULCBfdGhpcyk7XG4gICAgICBjYihlcnIpO1xuICAgIH0gZWxzZSB7XG4gICAgICBwcm9jZXNzLm5leHRUaWNrKGVtaXRDbG9zZU5ULCBfdGhpcyk7XG4gICAgfVxuICB9KTtcblxuICByZXR1cm4gdGhpcztcbn1cblxuZnVuY3Rpb24gZW1pdEVycm9yQW5kQ2xvc2VOVChzZWxmLCBlcnIpIHtcbiAgZW1pdEVycm9yTlQoc2VsZiwgZXJyKTtcbiAgZW1pdENsb3NlTlQoc2VsZik7XG59XG5cbmZ1bmN0aW9uIGVtaXRDbG9zZU5UKHNlbGYpIHtcbiAgaWYgKHNlbGYuX3dyaXRhYmxlU3RhdGUgJiYgIXNlbGYuX3dyaXRhYmxlU3RhdGUuZW1pdENsb3NlKSByZXR1cm47XG4gIGlmIChzZWxmLl9yZWFkYWJsZVN0YXRlICYmICFzZWxmLl9yZWFkYWJsZVN0YXRlLmVtaXRDbG9zZSkgcmV0dXJuO1xuICBzZWxmLmVtaXQoJ2Nsb3NlJyk7XG59XG5cbmZ1bmN0aW9uIHVuZGVzdHJveSgpIHtcbiAgaWYgKHRoaXMuX3JlYWRhYmxlU3RhdGUpIHtcbiAgICB0aGlzLl9yZWFkYWJsZVN0YXRlLmRlc3Ryb3llZCA9IGZhbHNlO1xuICAgIHRoaXMuX3JlYWRhYmxlU3RhdGUucmVhZGluZyA9IGZhbHNlO1xuICAgIHRoaXMuX3JlYWRhYmxlU3RhdGUuZW5kZWQgPSBmYWxzZTtcbiAgICB0aGlzLl9yZWFkYWJsZVN0YXRlLmVuZEVtaXR0ZWQgPSBmYWxzZTtcbiAgfVxuXG4gIGlmICh0aGlzLl93cml0YWJsZVN0YXRlKSB7XG4gICAgdGhpcy5fd3JpdGFibGVTdGF0ZS5kZXN0cm95ZWQgPSBmYWxzZTtcbiAgICB0aGlzLl93cml0YWJsZVN0YXRlLmVuZGVkID0gZmFsc2U7XG4gICAgdGhpcy5fd3JpdGFibGVTdGF0ZS5lbmRpbmcgPSBmYWxzZTtcbiAgICB0aGlzLl93cml0YWJsZVN0YXRlLmZpbmFsQ2FsbGVkID0gZmFsc2U7XG4gICAgdGhpcy5fd3JpdGFibGVTdGF0ZS5wcmVmaW5pc2hlZCA9IGZhbHNlO1xuICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUuZmluaXNoZWQgPSBmYWxzZTtcbiAgICB0aGlzLl93cml0YWJsZVN0YXRlLmVycm9yRW1pdHRlZCA9IGZhbHNlO1xuICB9XG59XG5cbmZ1bmN0aW9uIGVtaXRFcnJvck5UKHNlbGYsIGVycikge1xuICBzZWxmLmVtaXQoJ2Vycm9yJywgZXJyKTtcbn1cblxuZnVuY3Rpb24gZXJyb3JPckRlc3Ryb3koc3RyZWFtLCBlcnIpIHtcbiAgLy8gV2UgaGF2ZSB0ZXN0cyB0aGF0IHJlbHkgb24gZXJyb3JzIGJlaW5nIGVtaXR0ZWRcbiAgLy8gaW4gdGhlIHNhbWUgdGljaywgc28gY2hhbmdpbmcgdGhpcyBpcyBzZW12ZXIgbWFqb3IuXG4gIC8vIEZvciBub3cgd2hlbiB5b3Ugb3B0LWluIHRvIGF1dG9EZXN0cm95IHdlIGFsbG93XG4gIC8vIHRoZSBlcnJvciB0byBiZSBlbWl0dGVkIG5leHRUaWNrLiBJbiBhIGZ1dHVyZVxuICAvLyBzZW12ZXIgbWFqb3IgdXBkYXRlIHdlIHNob3VsZCBjaGFuZ2UgdGhlIGRlZmF1bHQgdG8gdGhpcy5cbiAgdmFyIHJTdGF0ZSA9IHN0cmVhbS5fcmVhZGFibGVTdGF0ZTtcbiAgdmFyIHdTdGF0ZSA9IHN0cmVhbS5fd3JpdGFibGVTdGF0ZTtcbiAgaWYgKHJTdGF0ZSAmJiByU3RhdGUuYXV0b0Rlc3Ryb3kgfHwgd1N0YXRlICYmIHdTdGF0ZS5hdXRvRGVzdHJveSkgc3RyZWFtLmRlc3Ryb3koZXJyKTtlbHNlIHN0cmVhbS5lbWl0KCdlcnJvcicsIGVycik7XG59XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICBkZXN0cm95OiBkZXN0cm95LFxuICB1bmRlc3Ryb3k6IHVuZGVzdHJveSxcbiAgZXJyb3JPckRlc3Ryb3k6IGVycm9yT3JEZXN0cm95XG59OyIsIi8vIFBvcnRlZCBmcm9tIGh0dHBzOi8vZ2l0aHViLmNvbS9tYWZpbnRvc2gvZW5kLW9mLXN0cmVhbSB3aXRoXG4vLyBwZXJtaXNzaW9uIGZyb20gdGhlIGF1dGhvciwgTWF0aGlhcyBCdXVzIChAbWFmaW50b3NoKS5cbid1c2Ugc3RyaWN0JztcblxudmFyIEVSUl9TVFJFQU1fUFJFTUFUVVJFX0NMT1NFID0gcmVxdWlyZSgnLi4vLi4vLi4vZXJyb3JzJykuY29kZXMuRVJSX1NUUkVBTV9QUkVNQVRVUkVfQ0xPU0U7XG5cbmZ1bmN0aW9uIG9uY2UoY2FsbGJhY2spIHtcbiAgdmFyIGNhbGxlZCA9IGZhbHNlO1xuICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgIGlmIChjYWxsZWQpIHJldHVybjtcbiAgICBjYWxsZWQgPSB0cnVlO1xuXG4gICAgZm9yICh2YXIgX2xlbiA9IGFyZ3VtZW50cy5sZW5ndGgsIGFyZ3MgPSBuZXcgQXJyYXkoX2xlbiksIF9rZXkgPSAwOyBfa2V5IDwgX2xlbjsgX2tleSsrKSB7XG4gICAgICBhcmdzW19rZXldID0gYXJndW1lbnRzW19rZXldO1xuICAgIH1cblxuICAgIGNhbGxiYWNrLmFwcGx5KHRoaXMsIGFyZ3MpO1xuICB9O1xufVxuXG5mdW5jdGlvbiBub29wKCkge31cblxuZnVuY3Rpb24gaXNSZXF1ZXN0KHN0cmVhbSkge1xuICByZXR1cm4gc3RyZWFtLnNldEhlYWRlciAmJiB0eXBlb2Ygc3RyZWFtLmFib3J0ID09PSAnZnVuY3Rpb24nO1xufVxuXG5mdW5jdGlvbiBlb3Moc3RyZWFtLCBvcHRzLCBjYWxsYmFjaykge1xuICBpZiAodHlwZW9mIG9wdHMgPT09ICdmdW5jdGlvbicpIHJldHVybiBlb3Moc3RyZWFtLCBudWxsLCBvcHRzKTtcbiAgaWYgKCFvcHRzKSBvcHRzID0ge307XG4gIGNhbGxiYWNrID0gb25jZShjYWxsYmFjayB8fCBub29wKTtcbiAgdmFyIHJlYWRhYmxlID0gb3B0cy5yZWFkYWJsZSB8fCBvcHRzLnJlYWRhYmxlICE9PSBmYWxzZSAmJiBzdHJlYW0ucmVhZGFibGU7XG4gIHZhciB3cml0YWJsZSA9IG9wdHMud3JpdGFibGUgfHwgb3B0cy53cml0YWJsZSAhPT0gZmFsc2UgJiYgc3RyZWFtLndyaXRhYmxlO1xuXG4gIHZhciBvbmxlZ2FjeWZpbmlzaCA9IGZ1bmN0aW9uIG9ubGVnYWN5ZmluaXNoKCkge1xuICAgIGlmICghc3RyZWFtLndyaXRhYmxlKSBvbmZpbmlzaCgpO1xuICB9O1xuXG4gIHZhciB3cml0YWJsZUVuZGVkID0gc3RyZWFtLl93cml0YWJsZVN0YXRlICYmIHN0cmVhbS5fd3JpdGFibGVTdGF0ZS5maW5pc2hlZDtcblxuICB2YXIgb25maW5pc2ggPSBmdW5jdGlvbiBvbmZpbmlzaCgpIHtcbiAgICB3cml0YWJsZSA9IGZhbHNlO1xuICAgIHdyaXRhYmxlRW5kZWQgPSB0cnVlO1xuICAgIGlmICghcmVhZGFibGUpIGNhbGxiYWNrLmNhbGwoc3RyZWFtKTtcbiAgfTtcblxuICB2YXIgcmVhZGFibGVFbmRlZCA9IHN0cmVhbS5fcmVhZGFibGVTdGF0ZSAmJiBzdHJlYW0uX3JlYWRhYmxlU3RhdGUuZW5kRW1pdHRlZDtcblxuICB2YXIgb25lbmQgPSBmdW5jdGlvbiBvbmVuZCgpIHtcbiAgICByZWFkYWJsZSA9IGZhbHNlO1xuICAgIHJlYWRhYmxlRW5kZWQgPSB0cnVlO1xuICAgIGlmICghd3JpdGFibGUpIGNhbGxiYWNrLmNhbGwoc3RyZWFtKTtcbiAgfTtcblxuICB2YXIgb25lcnJvciA9IGZ1bmN0aW9uIG9uZXJyb3IoZXJyKSB7XG4gICAgY2FsbGJhY2suY2FsbChzdHJlYW0sIGVycik7XG4gIH07XG5cbiAgdmFyIG9uY2xvc2UgPSBmdW5jdGlvbiBvbmNsb3NlKCkge1xuICAgIHZhciBlcnI7XG5cbiAgICBpZiAocmVhZGFibGUgJiYgIXJlYWRhYmxlRW5kZWQpIHtcbiAgICAgIGlmICghc3RyZWFtLl9yZWFkYWJsZVN0YXRlIHx8ICFzdHJlYW0uX3JlYWRhYmxlU3RhdGUuZW5kZWQpIGVyciA9IG5ldyBFUlJfU1RSRUFNX1BSRU1BVFVSRV9DTE9TRSgpO1xuICAgICAgcmV0dXJuIGNhbGxiYWNrLmNhbGwoc3RyZWFtLCBlcnIpO1xuICAgIH1cblxuICAgIGlmICh3cml0YWJsZSAmJiAhd3JpdGFibGVFbmRlZCkge1xuICAgICAgaWYgKCFzdHJlYW0uX3dyaXRhYmxlU3RhdGUgfHwgIXN0cmVhbS5fd3JpdGFibGVTdGF0ZS5lbmRlZCkgZXJyID0gbmV3IEVSUl9TVFJFQU1fUFJFTUFUVVJFX0NMT1NFKCk7XG4gICAgICByZXR1cm4gY2FsbGJhY2suY2FsbChzdHJlYW0sIGVycik7XG4gICAgfVxuICB9O1xuXG4gIHZhciBvbnJlcXVlc3QgPSBmdW5jdGlvbiBvbnJlcXVlc3QoKSB7XG4gICAgc3RyZWFtLnJlcS5vbignZmluaXNoJywgb25maW5pc2gpO1xuICB9O1xuXG4gIGlmIChpc1JlcXVlc3Qoc3RyZWFtKSkge1xuICAgIHN0cmVhbS5vbignY29tcGxldGUnLCBvbmZpbmlzaCk7XG4gICAgc3RyZWFtLm9uKCdhYm9ydCcsIG9uY2xvc2UpO1xuICAgIGlmIChzdHJlYW0ucmVxKSBvbnJlcXVlc3QoKTtlbHNlIHN0cmVhbS5vbigncmVxdWVzdCcsIG9ucmVxdWVzdCk7XG4gIH0gZWxzZSBpZiAod3JpdGFibGUgJiYgIXN0cmVhbS5fd3JpdGFibGVTdGF0ZSkge1xuICAgIC8vIGxlZ2FjeSBzdHJlYW1zXG4gICAgc3RyZWFtLm9uKCdlbmQnLCBvbmxlZ2FjeWZpbmlzaCk7XG4gICAgc3RyZWFtLm9uKCdjbG9zZScsIG9ubGVnYWN5ZmluaXNoKTtcbiAgfVxuXG4gIHN0cmVhbS5vbignZW5kJywgb25lbmQpO1xuICBzdHJlYW0ub24oJ2ZpbmlzaCcsIG9uZmluaXNoKTtcbiAgaWYgKG9wdHMuZXJyb3IgIT09IGZhbHNlKSBzdHJlYW0ub24oJ2Vycm9yJywgb25lcnJvcik7XG4gIHN0cmVhbS5vbignY2xvc2UnLCBvbmNsb3NlKTtcbiAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICBzdHJlYW0ucmVtb3ZlTGlzdGVuZXIoJ2NvbXBsZXRlJywgb25maW5pc2gpO1xuICAgIHN0cmVhbS5yZW1vdmVMaXN0ZW5lcignYWJvcnQnLCBvbmNsb3NlKTtcbiAgICBzdHJlYW0ucmVtb3ZlTGlzdGVuZXIoJ3JlcXVlc3QnLCBvbnJlcXVlc3QpO1xuICAgIGlmIChzdHJlYW0ucmVxKSBzdHJlYW0ucmVxLnJlbW92ZUxpc3RlbmVyKCdmaW5pc2gnLCBvbmZpbmlzaCk7XG4gICAgc3RyZWFtLnJlbW92ZUxpc3RlbmVyKCdlbmQnLCBvbmxlZ2FjeWZpbmlzaCk7XG4gICAgc3RyZWFtLnJlbW92ZUxpc3RlbmVyKCdjbG9zZScsIG9ubGVnYWN5ZmluaXNoKTtcbiAgICBzdHJlYW0ucmVtb3ZlTGlzdGVuZXIoJ2ZpbmlzaCcsIG9uZmluaXNoKTtcbiAgICBzdHJlYW0ucmVtb3ZlTGlzdGVuZXIoJ2VuZCcsIG9uZW5kKTtcbiAgICBzdHJlYW0ucmVtb3ZlTGlzdGVuZXIoJ2Vycm9yJywgb25lcnJvcik7XG4gICAgc3RyZWFtLnJlbW92ZUxpc3RlbmVyKCdjbG9zZScsIG9uY2xvc2UpO1xuICB9O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGVvczsiLCIndXNlIHN0cmljdCc7XG5cbmZ1bmN0aW9uIGFzeW5jR2VuZXJhdG9yU3RlcChnZW4sIHJlc29sdmUsIHJlamVjdCwgX25leHQsIF90aHJvdywga2V5LCBhcmcpIHsgdHJ5IHsgdmFyIGluZm8gPSBnZW5ba2V5XShhcmcpOyB2YXIgdmFsdWUgPSBpbmZvLnZhbHVlOyB9IGNhdGNoIChlcnJvcikgeyByZWplY3QoZXJyb3IpOyByZXR1cm47IH0gaWYgKGluZm8uZG9uZSkgeyByZXNvbHZlKHZhbHVlKTsgfSBlbHNlIHsgUHJvbWlzZS5yZXNvbHZlKHZhbHVlKS50aGVuKF9uZXh0LCBfdGhyb3cpOyB9IH1cblxuZnVuY3Rpb24gX2FzeW5jVG9HZW5lcmF0b3IoZm4pIHsgcmV0dXJuIGZ1bmN0aW9uICgpIHsgdmFyIHNlbGYgPSB0aGlzLCBhcmdzID0gYXJndW1lbnRzOyByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkgeyB2YXIgZ2VuID0gZm4uYXBwbHkoc2VsZiwgYXJncyk7IGZ1bmN0aW9uIF9uZXh0KHZhbHVlKSB7IGFzeW5jR2VuZXJhdG9yU3RlcChnZW4sIHJlc29sdmUsIHJlamVjdCwgX25leHQsIF90aHJvdywgXCJuZXh0XCIsIHZhbHVlKTsgfSBmdW5jdGlvbiBfdGhyb3coZXJyKSB7IGFzeW5jR2VuZXJhdG9yU3RlcChnZW4sIHJlc29sdmUsIHJlamVjdCwgX25leHQsIF90aHJvdywgXCJ0aHJvd1wiLCBlcnIpOyB9IF9uZXh0KHVuZGVmaW5lZCk7IH0pOyB9OyB9XG5cbmZ1bmN0aW9uIG93bktleXMob2JqZWN0LCBlbnVtZXJhYmxlT25seSkgeyB2YXIga2V5cyA9IE9iamVjdC5rZXlzKG9iamVjdCk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBzeW1ib2xzID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhvYmplY3QpOyBpZiAoZW51bWVyYWJsZU9ubHkpIHN5bWJvbHMgPSBzeW1ib2xzLmZpbHRlcihmdW5jdGlvbiAoc3ltKSB7IHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG9iamVjdCwgc3ltKS5lbnVtZXJhYmxlOyB9KTsga2V5cy5wdXNoLmFwcGx5KGtleXMsIHN5bWJvbHMpOyB9IHJldHVybiBrZXlzOyB9XG5cbmZ1bmN0aW9uIF9vYmplY3RTcHJlYWQodGFyZ2V0KSB7IGZvciAodmFyIGkgPSAxOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKSB7IHZhciBzb3VyY2UgPSBhcmd1bWVudHNbaV0gIT0gbnVsbCA/IGFyZ3VtZW50c1tpXSA6IHt9OyBpZiAoaSAlIDIpIHsgb3duS2V5cyhPYmplY3Qoc291cmNlKSwgdHJ1ZSkuZm9yRWFjaChmdW5jdGlvbiAoa2V5KSB7IF9kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGtleSwgc291cmNlW2tleV0pOyB9KTsgfSBlbHNlIGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycykgeyBPYmplY3QuZGVmaW5lUHJvcGVydGllcyh0YXJnZXQsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHNvdXJjZSkpOyB9IGVsc2UgeyBvd25LZXlzKE9iamVjdChzb3VyY2UpKS5mb3JFYWNoKGZ1bmN0aW9uIChrZXkpIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwga2V5LCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHNvdXJjZSwga2V5KSk7IH0pOyB9IH0gcmV0dXJuIHRhcmdldDsgfVxuXG5mdW5jdGlvbiBfZGVmaW5lUHJvcGVydHkob2JqLCBrZXksIHZhbHVlKSB7IGlmIChrZXkgaW4gb2JqKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmosIGtleSwgeyB2YWx1ZTogdmFsdWUsIGVudW1lcmFibGU6IHRydWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSwgd3JpdGFibGU6IHRydWUgfSk7IH0gZWxzZSB7IG9ialtrZXldID0gdmFsdWU7IH0gcmV0dXJuIG9iajsgfVxuXG52YXIgRVJSX0lOVkFMSURfQVJHX1RZUEUgPSByZXF1aXJlKCcuLi8uLi8uLi9lcnJvcnMnKS5jb2Rlcy5FUlJfSU5WQUxJRF9BUkdfVFlQRTtcblxuZnVuY3Rpb24gZnJvbShSZWFkYWJsZSwgaXRlcmFibGUsIG9wdHMpIHtcbiAgdmFyIGl0ZXJhdG9yO1xuXG4gIGlmIChpdGVyYWJsZSAmJiB0eXBlb2YgaXRlcmFibGUubmV4dCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIGl0ZXJhdG9yID0gaXRlcmFibGU7XG4gIH0gZWxzZSBpZiAoaXRlcmFibGUgJiYgaXRlcmFibGVbU3ltYm9sLmFzeW5jSXRlcmF0b3JdKSBpdGVyYXRvciA9IGl0ZXJhYmxlW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSgpO2Vsc2UgaWYgKGl0ZXJhYmxlICYmIGl0ZXJhYmxlW1N5bWJvbC5pdGVyYXRvcl0pIGl0ZXJhdG9yID0gaXRlcmFibGVbU3ltYm9sLml0ZXJhdG9yXSgpO2Vsc2UgdGhyb3cgbmV3IEVSUl9JTlZBTElEX0FSR19UWVBFKCdpdGVyYWJsZScsIFsnSXRlcmFibGUnXSwgaXRlcmFibGUpO1xuXG4gIHZhciByZWFkYWJsZSA9IG5ldyBSZWFkYWJsZShfb2JqZWN0U3ByZWFkKHtcbiAgICBvYmplY3RNb2RlOiB0cnVlXG4gIH0sIG9wdHMpKTsgLy8gUmVhZGluZyBib29sZWFuIHRvIHByb3RlY3QgYWdhaW5zdCBfcmVhZFxuICAvLyBiZWluZyBjYWxsZWQgYmVmb3JlIGxhc3QgaXRlcmF0aW9uIGNvbXBsZXRpb24uXG5cbiAgdmFyIHJlYWRpbmcgPSBmYWxzZTtcblxuICByZWFkYWJsZS5fcmVhZCA9IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoIXJlYWRpbmcpIHtcbiAgICAgIHJlYWRpbmcgPSB0cnVlO1xuICAgICAgbmV4dCgpO1xuICAgIH1cbiAgfTtcblxuICBmdW5jdGlvbiBuZXh0KCkge1xuICAgIHJldHVybiBfbmV4dDIuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIF9uZXh0MigpIHtcbiAgICBfbmV4dDIgPSBfYXN5bmNUb0dlbmVyYXRvcihmdW5jdGlvbiogKCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgdmFyIF9yZWYgPSB5aWVsZCBpdGVyYXRvci5uZXh0KCksXG4gICAgICAgICAgICB2YWx1ZSA9IF9yZWYudmFsdWUsXG4gICAgICAgICAgICBkb25lID0gX3JlZi5kb25lO1xuXG4gICAgICAgIGlmIChkb25lKSB7XG4gICAgICAgICAgcmVhZGFibGUucHVzaChudWxsKTtcbiAgICAgICAgfSBlbHNlIGlmIChyZWFkYWJsZS5wdXNoKCh5aWVsZCB2YWx1ZSkpKSB7XG4gICAgICAgICAgbmV4dCgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlYWRpbmcgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIHJlYWRhYmxlLmRlc3Ryb3koZXJyKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gX25leHQyLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gIH1cblxuICByZXR1cm4gcmVhZGFibGU7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gZnJvbTsiLCIvLyBQb3J0ZWQgZnJvbSBodHRwczovL2dpdGh1Yi5jb20vbWFmaW50b3NoL3B1bXAgd2l0aFxuLy8gcGVybWlzc2lvbiBmcm9tIHRoZSBhdXRob3IsIE1hdGhpYXMgQnV1cyAoQG1hZmludG9zaCkuXG4ndXNlIHN0cmljdCc7XG5cbnZhciBlb3M7XG5cbmZ1bmN0aW9uIG9uY2UoY2FsbGJhY2spIHtcbiAgdmFyIGNhbGxlZCA9IGZhbHNlO1xuICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgIGlmIChjYWxsZWQpIHJldHVybjtcbiAgICBjYWxsZWQgPSB0cnVlO1xuICAgIGNhbGxiYWNrLmFwcGx5KHZvaWQgMCwgYXJndW1lbnRzKTtcbiAgfTtcbn1cblxudmFyIF9yZXF1aXJlJGNvZGVzID0gcmVxdWlyZSgnLi4vLi4vLi4vZXJyb3JzJykuY29kZXMsXG4gICAgRVJSX01JU1NJTkdfQVJHUyA9IF9yZXF1aXJlJGNvZGVzLkVSUl9NSVNTSU5HX0FSR1MsXG4gICAgRVJSX1NUUkVBTV9ERVNUUk9ZRUQgPSBfcmVxdWlyZSRjb2Rlcy5FUlJfU1RSRUFNX0RFU1RST1lFRDtcblxuZnVuY3Rpb24gbm9vcChlcnIpIHtcbiAgLy8gUmV0aHJvdyB0aGUgZXJyb3IgaWYgaXQgZXhpc3RzIHRvIGF2b2lkIHN3YWxsb3dpbmcgaXRcbiAgaWYgKGVycikgdGhyb3cgZXJyO1xufVxuXG5mdW5jdGlvbiBpc1JlcXVlc3Qoc3RyZWFtKSB7XG4gIHJldHVybiBzdHJlYW0uc2V0SGVhZGVyICYmIHR5cGVvZiBzdHJlYW0uYWJvcnQgPT09ICdmdW5jdGlvbic7XG59XG5cbmZ1bmN0aW9uIGRlc3Ryb3llcihzdHJlYW0sIHJlYWRpbmcsIHdyaXRpbmcsIGNhbGxiYWNrKSB7XG4gIGNhbGxiYWNrID0gb25jZShjYWxsYmFjayk7XG4gIHZhciBjbG9zZWQgPSBmYWxzZTtcbiAgc3RyZWFtLm9uKCdjbG9zZScsIGZ1bmN0aW9uICgpIHtcbiAgICBjbG9zZWQgPSB0cnVlO1xuICB9KTtcbiAgaWYgKGVvcyA9PT0gdW5kZWZpbmVkKSBlb3MgPSByZXF1aXJlKCcuL2VuZC1vZi1zdHJlYW0nKTtcbiAgZW9zKHN0cmVhbSwge1xuICAgIHJlYWRhYmxlOiByZWFkaW5nLFxuICAgIHdyaXRhYmxlOiB3cml0aW5nXG4gIH0sIGZ1bmN0aW9uIChlcnIpIHtcbiAgICBpZiAoZXJyKSByZXR1cm4gY2FsbGJhY2soZXJyKTtcbiAgICBjbG9zZWQgPSB0cnVlO1xuICAgIGNhbGxiYWNrKCk7XG4gIH0pO1xuICB2YXIgZGVzdHJveWVkID0gZmFsc2U7XG4gIHJldHVybiBmdW5jdGlvbiAoZXJyKSB7XG4gICAgaWYgKGNsb3NlZCkgcmV0dXJuO1xuICAgIGlmIChkZXN0cm95ZWQpIHJldHVybjtcbiAgICBkZXN0cm95ZWQgPSB0cnVlOyAvLyByZXF1ZXN0LmRlc3Ryb3kganVzdCBkbyAuZW5kIC0gLmFib3J0IGlzIHdoYXQgd2Ugd2FudFxuXG4gICAgaWYgKGlzUmVxdWVzdChzdHJlYW0pKSByZXR1cm4gc3RyZWFtLmFib3J0KCk7XG4gICAgaWYgKHR5cGVvZiBzdHJlYW0uZGVzdHJveSA9PT0gJ2Z1bmN0aW9uJykgcmV0dXJuIHN0cmVhbS5kZXN0cm95KCk7XG4gICAgY2FsbGJhY2soZXJyIHx8IG5ldyBFUlJfU1RSRUFNX0RFU1RST1lFRCgncGlwZScpKTtcbiAgfTtcbn1cblxuZnVuY3Rpb24gY2FsbChmbikge1xuICBmbigpO1xufVxuXG5mdW5jdGlvbiBwaXBlKGZyb20sIHRvKSB7XG4gIHJldHVybiBmcm9tLnBpcGUodG8pO1xufVxuXG5mdW5jdGlvbiBwb3BDYWxsYmFjayhzdHJlYW1zKSB7XG4gIGlmICghc3RyZWFtcy5sZW5ndGgpIHJldHVybiBub29wO1xuICBpZiAodHlwZW9mIHN0cmVhbXNbc3RyZWFtcy5sZW5ndGggLSAxXSAhPT0gJ2Z1bmN0aW9uJykgcmV0dXJuIG5vb3A7XG4gIHJldHVybiBzdHJlYW1zLnBvcCgpO1xufVxuXG5mdW5jdGlvbiBwaXBlbGluZSgpIHtcbiAgZm9yICh2YXIgX2xlbiA9IGFyZ3VtZW50cy5sZW5ndGgsIHN0cmVhbXMgPSBuZXcgQXJyYXkoX2xlbiksIF9rZXkgPSAwOyBfa2V5IDwgX2xlbjsgX2tleSsrKSB7XG4gICAgc3RyZWFtc1tfa2V5XSA9IGFyZ3VtZW50c1tfa2V5XTtcbiAgfVxuXG4gIHZhciBjYWxsYmFjayA9IHBvcENhbGxiYWNrKHN0cmVhbXMpO1xuICBpZiAoQXJyYXkuaXNBcnJheShzdHJlYW1zWzBdKSkgc3RyZWFtcyA9IHN0cmVhbXNbMF07XG5cbiAgaWYgKHN0cmVhbXMubGVuZ3RoIDwgMikge1xuICAgIHRocm93IG5ldyBFUlJfTUlTU0lOR19BUkdTKCdzdHJlYW1zJyk7XG4gIH1cblxuICB2YXIgZXJyb3I7XG4gIHZhciBkZXN0cm95cyA9IHN0cmVhbXMubWFwKGZ1bmN0aW9uIChzdHJlYW0sIGkpIHtcbiAgICB2YXIgcmVhZGluZyA9IGkgPCBzdHJlYW1zLmxlbmd0aCAtIDE7XG4gICAgdmFyIHdyaXRpbmcgPSBpID4gMDtcbiAgICByZXR1cm4gZGVzdHJveWVyKHN0cmVhbSwgcmVhZGluZywgd3JpdGluZywgZnVuY3Rpb24gKGVycikge1xuICAgICAgaWYgKCFlcnJvcikgZXJyb3IgPSBlcnI7XG4gICAgICBpZiAoZXJyKSBkZXN0cm95cy5mb3JFYWNoKGNhbGwpO1xuICAgICAgaWYgKHJlYWRpbmcpIHJldHVybjtcbiAgICAgIGRlc3Ryb3lzLmZvckVhY2goY2FsbCk7XG4gICAgICBjYWxsYmFjayhlcnJvcik7XG4gICAgfSk7XG4gIH0pO1xuICByZXR1cm4gc3RyZWFtcy5yZWR1Y2UocGlwZSk7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gcGlwZWxpbmU7IiwiJ3VzZSBzdHJpY3QnO1xuXG52YXIgRVJSX0lOVkFMSURfT1BUX1ZBTFVFID0gcmVxdWlyZSgnLi4vLi4vLi4vZXJyb3JzJykuY29kZXMuRVJSX0lOVkFMSURfT1BUX1ZBTFVFO1xuXG5mdW5jdGlvbiBoaWdoV2F0ZXJNYXJrRnJvbShvcHRpb25zLCBpc0R1cGxleCwgZHVwbGV4S2V5KSB7XG4gIHJldHVybiBvcHRpb25zLmhpZ2hXYXRlck1hcmsgIT0gbnVsbCA/IG9wdGlvbnMuaGlnaFdhdGVyTWFyayA6IGlzRHVwbGV4ID8gb3B0aW9uc1tkdXBsZXhLZXldIDogbnVsbDtcbn1cblxuZnVuY3Rpb24gZ2V0SGlnaFdhdGVyTWFyayhzdGF0ZSwgb3B0aW9ucywgZHVwbGV4S2V5LCBpc0R1cGxleCkge1xuICB2YXIgaHdtID0gaGlnaFdhdGVyTWFya0Zyb20ob3B0aW9ucywgaXNEdXBsZXgsIGR1cGxleEtleSk7XG5cbiAgaWYgKGh3bSAhPSBudWxsKSB7XG4gICAgaWYgKCEoaXNGaW5pdGUoaHdtKSAmJiBNYXRoLmZsb29yKGh3bSkgPT09IGh3bSkgfHwgaHdtIDwgMCkge1xuICAgICAgdmFyIG5hbWUgPSBpc0R1cGxleCA/IGR1cGxleEtleSA6ICdoaWdoV2F0ZXJNYXJrJztcbiAgICAgIHRocm93IG5ldyBFUlJfSU5WQUxJRF9PUFRfVkFMVUUobmFtZSwgaHdtKTtcbiAgICB9XG5cbiAgICByZXR1cm4gTWF0aC5mbG9vcihod20pO1xuICB9IC8vIERlZmF1bHQgdmFsdWVcblxuXG4gIHJldHVybiBzdGF0ZS5vYmplY3RNb2RlID8gMTYgOiAxNiAqIDEwMjQ7XG59XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICBnZXRIaWdoV2F0ZXJNYXJrOiBnZXRIaWdoV2F0ZXJNYXJrXG59OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnc3RyZWFtJyk7XG4iLCJ2YXIgU3RyZWFtID0gcmVxdWlyZSgnc3RyZWFtJyk7XG5pZiAocHJvY2Vzcy5lbnYuUkVBREFCTEVfU1RSRUFNID09PSAnZGlzYWJsZScgJiYgU3RyZWFtKSB7XG4gIG1vZHVsZS5leHBvcnRzID0gU3RyZWFtLlJlYWRhYmxlO1xuICBPYmplY3QuYXNzaWduKG1vZHVsZS5leHBvcnRzLCBTdHJlYW0pO1xuICBtb2R1bGUuZXhwb3J0cy5TdHJlYW0gPSBTdHJlYW07XG59IGVsc2Uge1xuICBleHBvcnRzID0gbW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuL2xpYi9fc3RyZWFtX3JlYWRhYmxlLmpzJyk7XG4gIGV4cG9ydHMuU3RyZWFtID0gU3RyZWFtIHx8IGV4cG9ydHM7XG4gIGV4cG9ydHMuUmVhZGFibGUgPSBleHBvcnRzO1xuICBleHBvcnRzLldyaXRhYmxlID0gcmVxdWlyZSgnLi9saWIvX3N0cmVhbV93cml0YWJsZS5qcycpO1xuICBleHBvcnRzLkR1cGxleCA9IHJlcXVpcmUoJy4vbGliL19zdHJlYW1fZHVwbGV4LmpzJyk7XG4gIGV4cG9ydHMuVHJhbnNmb3JtID0gcmVxdWlyZSgnLi9saWIvX3N0cmVhbV90cmFuc2Zvcm0uanMnKTtcbiAgZXhwb3J0cy5QYXNzVGhyb3VnaCA9IHJlcXVpcmUoJy4vbGliL19zdHJlYW1fcGFzc3Rocm91Z2guanMnKTtcbiAgZXhwb3J0cy5maW5pc2hlZCA9IHJlcXVpcmUoJy4vbGliL2ludGVybmFsL3N0cmVhbXMvZW5kLW9mLXN0cmVhbS5qcycpO1xuICBleHBvcnRzLnBpcGVsaW5lID0gcmVxdWlyZSgnLi9saWIvaW50ZXJuYWwvc3RyZWFtcy9waXBlbGluZS5qcycpO1xufVxuIiwiLyohIHNhZmUtYnVmZmVyLiBNSVQgTGljZW5zZS4gRmVyb3NzIEFib3VraGFkaWplaCA8aHR0cHM6Ly9mZXJvc3Mub3JnL29wZW5zb3VyY2U+ICovXG4vKiBlc2xpbnQtZGlzYWJsZSBub2RlL25vLWRlcHJlY2F0ZWQtYXBpICovXG52YXIgYnVmZmVyID0gcmVxdWlyZSgnYnVmZmVyJylcbnZhciBCdWZmZXIgPSBidWZmZXIuQnVmZmVyXG5cbi8vIGFsdGVybmF0aXZlIHRvIHVzaW5nIE9iamVjdC5rZXlzIGZvciBvbGQgYnJvd3NlcnNcbmZ1bmN0aW9uIGNvcHlQcm9wcyAoc3JjLCBkc3QpIHtcbiAgZm9yICh2YXIga2V5IGluIHNyYykge1xuICAgIGRzdFtrZXldID0gc3JjW2tleV1cbiAgfVxufVxuaWYgKEJ1ZmZlci5mcm9tICYmIEJ1ZmZlci5hbGxvYyAmJiBCdWZmZXIuYWxsb2NVbnNhZmUgJiYgQnVmZmVyLmFsbG9jVW5zYWZlU2xvdykge1xuICBtb2R1bGUuZXhwb3J0cyA9IGJ1ZmZlclxufSBlbHNlIHtcbiAgLy8gQ29weSBwcm9wZXJ0aWVzIGZyb20gcmVxdWlyZSgnYnVmZmVyJylcbiAgY29weVByb3BzKGJ1ZmZlciwgZXhwb3J0cylcbiAgZXhwb3J0cy5CdWZmZXIgPSBTYWZlQnVmZmVyXG59XG5cbmZ1bmN0aW9uIFNhZmVCdWZmZXIgKGFyZywgZW5jb2RpbmdPck9mZnNldCwgbGVuZ3RoKSB7XG4gIHJldHVybiBCdWZmZXIoYXJnLCBlbmNvZGluZ09yT2Zmc2V0LCBsZW5ndGgpXG59XG5cblNhZmVCdWZmZXIucHJvdG90eXBlID0gT2JqZWN0LmNyZWF0ZShCdWZmZXIucHJvdG90eXBlKVxuXG4vLyBDb3B5IHN0YXRpYyBtZXRob2RzIGZyb20gQnVmZmVyXG5jb3B5UHJvcHMoQnVmZmVyLCBTYWZlQnVmZmVyKVxuXG5TYWZlQnVmZmVyLmZyb20gPSBmdW5jdGlvbiAoYXJnLCBlbmNvZGluZ09yT2Zmc2V0LCBsZW5ndGgpIHtcbiAgaWYgKHR5cGVvZiBhcmcgPT09ICdudW1iZXInKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignQXJndW1lbnQgbXVzdCBub3QgYmUgYSBudW1iZXInKVxuICB9XG4gIHJldHVybiBCdWZmZXIoYXJnLCBlbmNvZGluZ09yT2Zmc2V0LCBsZW5ndGgpXG59XG5cblNhZmVCdWZmZXIuYWxsb2MgPSBmdW5jdGlvbiAoc2l6ZSwgZmlsbCwgZW5jb2RpbmcpIHtcbiAgaWYgKHR5cGVvZiBzaXplICE9PSAnbnVtYmVyJykge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ0FyZ3VtZW50IG11c3QgYmUgYSBudW1iZXInKVxuICB9XG4gIHZhciBidWYgPSBCdWZmZXIoc2l6ZSlcbiAgaWYgKGZpbGwgIT09IHVuZGVmaW5lZCkge1xuICAgIGlmICh0eXBlb2YgZW5jb2RpbmcgPT09ICdzdHJpbmcnKSB7XG4gICAgICBidWYuZmlsbChmaWxsLCBlbmNvZGluZylcbiAgICB9IGVsc2Uge1xuICAgICAgYnVmLmZpbGwoZmlsbClcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgYnVmLmZpbGwoMClcbiAgfVxuICByZXR1cm4gYnVmXG59XG5cblNhZmVCdWZmZXIuYWxsb2NVbnNhZmUgPSBmdW5jdGlvbiAoc2l6ZSkge1xuICBpZiAodHlwZW9mIHNpemUgIT09ICdudW1iZXInKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignQXJndW1lbnQgbXVzdCBiZSBhIG51bWJlcicpXG4gIH1cbiAgcmV0dXJuIEJ1ZmZlcihzaXplKVxufVxuXG5TYWZlQnVmZmVyLmFsbG9jVW5zYWZlU2xvdyA9IGZ1bmN0aW9uIChzaXplKSB7XG4gIGlmICh0eXBlb2Ygc2l6ZSAhPT0gJ251bWJlcicpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdBcmd1bWVudCBtdXN0IGJlIGEgbnVtYmVyJylcbiAgfVxuICByZXR1cm4gYnVmZmVyLlNsb3dCdWZmZXIoc2l6ZSlcbn1cbiIsIi8qXG5Db3B5cmlnaHQgKGMpIDIwMTQtMjAxOCwgTWF0dGVvIENvbGxpbmEgPGhlbGxvQG1hdHRlb2NvbGxpbmEuY29tPlxuXG5QZXJtaXNzaW9uIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBhbmQvb3IgZGlzdHJpYnV0ZSB0aGlzIHNvZnR3YXJlIGZvciBhbnlcbnB1cnBvc2Ugd2l0aCBvciB3aXRob3V0IGZlZSBpcyBoZXJlYnkgZ3JhbnRlZCwgcHJvdmlkZWQgdGhhdCB0aGUgYWJvdmVcbmNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2UgYXBwZWFyIGluIGFsbCBjb3BpZXMuXG5cblRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIgQU5EIFRIRSBBVVRIT1IgRElTQ0xBSU1TIEFMTCBXQVJSQU5USUVTXG5XSVRIIFJFR0FSRCBUTyBUSElTIFNPRlRXQVJFIElOQ0xVRElORyBBTEwgSU1QTElFRCBXQVJSQU5USUVTIE9GXG5NRVJDSEFOVEFCSUxJVFkgQU5EIEZJVE5FU1MuIElOIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1IgQkUgTElBQkxFIEZPUlxuQU5ZIFNQRUNJQUwsIERJUkVDVCwgSU5ESVJFQ1QsIE9SIENPTlNFUVVFTlRJQUwgREFNQUdFUyBPUiBBTlkgREFNQUdFU1xuV0hBVFNPRVZFUiBSRVNVTFRJTkcgRlJPTSBMT1NTIE9GIFVTRSwgREFUQSBPUiBQUk9GSVRTLCBXSEVUSEVSIElOIEFOXG5BQ1RJT04gT0YgQ09OVFJBQ1QsIE5FR0xJR0VOQ0UgT1IgT1RIRVIgVE9SVElPVVMgQUNUSU9OLCBBUklTSU5HIE9VVCBPRiBPUlxuSU4gQ09OTkVDVElPTiBXSVRIIFRIRSBVU0UgT1IgUEVSRk9STUFOQ0UgT0YgVEhJUyBTT0ZUV0FSRS5cbiovXG5cbid1c2Ugc3RyaWN0J1xuXG5jb25zdCB7IFRyYW5zZm9ybSB9ID0gcmVxdWlyZSgncmVhZGFibGUtc3RyZWFtJylcbmNvbnN0IHsgU3RyaW5nRGVjb2RlciB9ID0gcmVxdWlyZSgnc3RyaW5nX2RlY29kZXInKVxuY29uc3Qga0xhc3QgPSBTeW1ib2woJ2xhc3QnKVxuY29uc3Qga0RlY29kZXIgPSBTeW1ib2woJ2RlY29kZXInKVxuXG5mdW5jdGlvbiB0cmFuc2Zvcm0gKGNodW5rLCBlbmMsIGNiKSB7XG4gIHZhciBsaXN0XG4gIGlmICh0aGlzLm92ZXJmbG93KSB7IC8vIExpbmUgYnVmZmVyIGlzIGZ1bGwuIFNraXAgdG8gc3RhcnQgb2YgbmV4dCBsaW5lLlxuICAgIHZhciBidWYgPSB0aGlzW2tEZWNvZGVyXS53cml0ZShjaHVuaylcbiAgICBsaXN0ID0gYnVmLnNwbGl0KHRoaXMubWF0Y2hlcilcblxuICAgIGlmIChsaXN0Lmxlbmd0aCA9PT0gMSkgcmV0dXJuIGNiKCkgLy8gTGluZSBlbmRpbmcgbm90IGZvdW5kLiBEaXNjYXJkIGVudGlyZSBjaHVuay5cblxuICAgIC8vIExpbmUgZW5kaW5nIGZvdW5kLiBEaXNjYXJkIHRyYWlsaW5nIGZyYWdtZW50IG9mIHByZXZpb3VzIGxpbmUgYW5kIHJlc2V0IG92ZXJmbG93IHN0YXRlLlxuICAgIGxpc3Quc2hpZnQoKVxuICAgIHRoaXMub3ZlcmZsb3cgPSBmYWxzZVxuICB9IGVsc2Uge1xuICAgIHRoaXNba0xhc3RdICs9IHRoaXNba0RlY29kZXJdLndyaXRlKGNodW5rKVxuICAgIGxpc3QgPSB0aGlzW2tMYXN0XS5zcGxpdCh0aGlzLm1hdGNoZXIpXG4gIH1cblxuICB0aGlzW2tMYXN0XSA9IGxpc3QucG9wKClcblxuICBmb3IgKHZhciBpID0gMDsgaSA8IGxpc3QubGVuZ3RoOyBpKyspIHtcbiAgICB0cnkge1xuICAgICAgcHVzaCh0aGlzLCB0aGlzLm1hcHBlcihsaXN0W2ldKSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgcmV0dXJuIGNiKGVycm9yKVxuICAgIH1cbiAgfVxuXG4gIHRoaXMub3ZlcmZsb3cgPSB0aGlzW2tMYXN0XS5sZW5ndGggPiB0aGlzLm1heExlbmd0aFxuICBpZiAodGhpcy5vdmVyZmxvdyAmJiAhdGhpcy5za2lwT3ZlcmZsb3cpIHJldHVybiBjYihuZXcgRXJyb3IoJ21heGltdW0gYnVmZmVyIHJlYWNoZWQnKSlcblxuICBjYigpXG59XG5cbmZ1bmN0aW9uIGZsdXNoIChjYikge1xuICAvLyBmb3J3YXJkIGFueSBnaWJiZXJpc2ggbGVmdCBpbiB0aGVyZVxuICB0aGlzW2tMYXN0XSArPSB0aGlzW2tEZWNvZGVyXS5lbmQoKVxuXG4gIGlmICh0aGlzW2tMYXN0XSkge1xuICAgIHRyeSB7XG4gICAgICBwdXNoKHRoaXMsIHRoaXMubWFwcGVyKHRoaXNba0xhc3RdKSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgcmV0dXJuIGNiKGVycm9yKVxuICAgIH1cbiAgfVxuXG4gIGNiKClcbn1cblxuZnVuY3Rpb24gcHVzaCAoc2VsZiwgdmFsKSB7XG4gIGlmICh2YWwgIT09IHVuZGVmaW5lZCkge1xuICAgIHNlbGYucHVzaCh2YWwpXG4gIH1cbn1cblxuZnVuY3Rpb24gbm9vcCAoaW5jb21pbmcpIHtcbiAgcmV0dXJuIGluY29taW5nXG59XG5cbmZ1bmN0aW9uIHNwbGl0IChtYXRjaGVyLCBtYXBwZXIsIG9wdGlvbnMpIHtcbiAgLy8gU2V0IGRlZmF1bHRzIGZvciBhbnkgYXJndW1lbnRzIG5vdCBzdXBwbGllZC5cbiAgbWF0Y2hlciA9IG1hdGNoZXIgfHwgL1xccj9cXG4vXG4gIG1hcHBlciA9IG1hcHBlciB8fCBub29wXG4gIG9wdGlvbnMgPSBvcHRpb25zIHx8IHt9XG5cbiAgLy8gVGVzdCBhcmd1bWVudHMgZXhwbGljaXRseS5cbiAgc3dpdGNoIChhcmd1bWVudHMubGVuZ3RoKSB7XG4gICAgY2FzZSAxOlxuICAgICAgLy8gSWYgbWFwcGVyIGlzIG9ubHkgYXJndW1lbnQuXG4gICAgICBpZiAodHlwZW9mIG1hdGNoZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgbWFwcGVyID0gbWF0Y2hlclxuICAgICAgICBtYXRjaGVyID0gL1xccj9cXG4vXG4gICAgICAvLyBJZiBvcHRpb25zIGlzIG9ubHkgYXJndW1lbnQuXG4gICAgICB9IGVsc2UgaWYgKHR5cGVvZiBtYXRjaGVyID09PSAnb2JqZWN0JyAmJiAhKG1hdGNoZXIgaW5zdGFuY2VvZiBSZWdFeHApKSB7XG4gICAgICAgIG9wdGlvbnMgPSBtYXRjaGVyXG4gICAgICAgIG1hdGNoZXIgPSAvXFxyP1xcbi9cbiAgICAgIH1cbiAgICAgIGJyZWFrXG5cbiAgICBjYXNlIDI6XG4gICAgICAvLyBJZiBtYXBwZXIgYW5kIG9wdGlvbnMgYXJlIGFyZ3VtZW50cy5cbiAgICAgIGlmICh0eXBlb2YgbWF0Y2hlciA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBvcHRpb25zID0gbWFwcGVyXG4gICAgICAgIG1hcHBlciA9IG1hdGNoZXJcbiAgICAgICAgbWF0Y2hlciA9IC9cXHI/XFxuL1xuICAgICAgLy8gSWYgbWF0Y2hlciBhbmQgb3B0aW9ucyBhcmUgYXJndW1lbnRzLlxuICAgICAgfSBlbHNlIGlmICh0eXBlb2YgbWFwcGVyID09PSAnb2JqZWN0Jykge1xuICAgICAgICBvcHRpb25zID0gbWFwcGVyXG4gICAgICAgIG1hcHBlciA9IG5vb3BcbiAgICAgIH1cbiAgfVxuXG4gIG9wdGlvbnMgPSBPYmplY3QuYXNzaWduKHt9LCBvcHRpb25zKVxuICBvcHRpb25zLnRyYW5zZm9ybSA9IHRyYW5zZm9ybVxuICBvcHRpb25zLmZsdXNoID0gZmx1c2hcbiAgb3B0aW9ucy5yZWFkYWJsZU9iamVjdE1vZGUgPSB0cnVlXG5cbiAgY29uc3Qgc3RyZWFtID0gbmV3IFRyYW5zZm9ybShvcHRpb25zKVxuXG4gIHN0cmVhbVtrTGFzdF0gPSAnJ1xuICBzdHJlYW1ba0RlY29kZXJdID0gbmV3IFN0cmluZ0RlY29kZXIoJ3V0ZjgnKVxuICBzdHJlYW0ubWF0Y2hlciA9IG1hdGNoZXJcbiAgc3RyZWFtLm1hcHBlciA9IG1hcHBlclxuICBzdHJlYW0ubWF4TGVuZ3RoID0gb3B0aW9ucy5tYXhMZW5ndGhcbiAgc3RyZWFtLnNraXBPdmVyZmxvdyA9IG9wdGlvbnMuc2tpcE92ZXJmbG93XG4gIHN0cmVhbS5vdmVyZmxvdyA9IGZhbHNlXG5cbiAgcmV0dXJuIHN0cmVhbVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHNwbGl0XG4iLCIvLyBDb3B5cmlnaHQgSm95ZW50LCBJbmMuIGFuZCBvdGhlciBOb2RlIGNvbnRyaWJ1dG9ycy5cbi8vXG4vLyBQZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYVxuLy8gY29weSBvZiB0aGlzIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZVxuLy8gXCJTb2Z0d2FyZVwiKSwgdG8gZGVhbCBpbiB0aGUgU29mdHdhcmUgd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nXG4vLyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsXG4vLyBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0XG4vLyBwZXJzb25zIHRvIHdob20gdGhlIFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0byB0aGVcbi8vIGZvbGxvd2luZyBjb25kaXRpb25zOlxuLy9cbi8vIFRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIHNoYWxsIGJlIGluY2x1ZGVkXG4vLyBpbiBhbGwgY29waWVzIG9yIHN1YnN0YW50aWFsIHBvcnRpb25zIG9mIHRoZSBTb2Z0d2FyZS5cbi8vXG4vLyBUSEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTXG4vLyBPUiBJTVBMSUVELCBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GXG4vLyBNRVJDSEFOVEFCSUxJVFksIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuIElOXG4vLyBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFQgSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSxcbi8vIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSIElOIEFOIEFDVElPTiBPRiBDT05UUkFDVCwgVE9SVCBPUlxuLy8gT1RIRVJXSVNFLCBBUklTSU5HIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFIFNPRlRXQVJFIE9SIFRIRVxuLy8gVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cblxuJ3VzZSBzdHJpY3QnO1xuXG4vKjxyZXBsYWNlbWVudD4qL1xuXG52YXIgQnVmZmVyID0gcmVxdWlyZSgnc2FmZS1idWZmZXInKS5CdWZmZXI7XG4vKjwvcmVwbGFjZW1lbnQ+Ki9cblxudmFyIGlzRW5jb2RpbmcgPSBCdWZmZXIuaXNFbmNvZGluZyB8fCBmdW5jdGlvbiAoZW5jb2RpbmcpIHtcbiAgZW5jb2RpbmcgPSAnJyArIGVuY29kaW5nO1xuICBzd2l0Y2ggKGVuY29kaW5nICYmIGVuY29kaW5nLnRvTG93ZXJDYXNlKCkpIHtcbiAgICBjYXNlICdoZXgnOmNhc2UgJ3V0ZjgnOmNhc2UgJ3V0Zi04JzpjYXNlICdhc2NpaSc6Y2FzZSAnYmluYXJ5JzpjYXNlICdiYXNlNjQnOmNhc2UgJ3VjczInOmNhc2UgJ3Vjcy0yJzpjYXNlICd1dGYxNmxlJzpjYXNlICd1dGYtMTZsZSc6Y2FzZSAncmF3JzpcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn07XG5cbmZ1bmN0aW9uIF9ub3JtYWxpemVFbmNvZGluZyhlbmMpIHtcbiAgaWYgKCFlbmMpIHJldHVybiAndXRmOCc7XG4gIHZhciByZXRyaWVkO1xuICB3aGlsZSAodHJ1ZSkge1xuICAgIHN3aXRjaCAoZW5jKSB7XG4gICAgICBjYXNlICd1dGY4JzpcbiAgICAgIGNhc2UgJ3V0Zi04JzpcbiAgICAgICAgcmV0dXJuICd1dGY4JztcbiAgICAgIGNhc2UgJ3VjczInOlxuICAgICAgY2FzZSAndWNzLTInOlxuICAgICAgY2FzZSAndXRmMTZsZSc6XG4gICAgICBjYXNlICd1dGYtMTZsZSc6XG4gICAgICAgIHJldHVybiAndXRmMTZsZSc7XG4gICAgICBjYXNlICdsYXRpbjEnOlxuICAgICAgY2FzZSAnYmluYXJ5JzpcbiAgICAgICAgcmV0dXJuICdsYXRpbjEnO1xuICAgICAgY2FzZSAnYmFzZTY0JzpcbiAgICAgIGNhc2UgJ2FzY2lpJzpcbiAgICAgIGNhc2UgJ2hleCc6XG4gICAgICAgIHJldHVybiBlbmM7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICBpZiAocmV0cmllZCkgcmV0dXJuOyAvLyB1bmRlZmluZWRcbiAgICAgICAgZW5jID0gKCcnICsgZW5jKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICByZXRyaWVkID0gdHJ1ZTtcbiAgICB9XG4gIH1cbn07XG5cbi8vIERvIG5vdCBjYWNoZSBgQnVmZmVyLmlzRW5jb2RpbmdgIHdoZW4gY2hlY2tpbmcgZW5jb2RpbmcgbmFtZXMgYXMgc29tZVxuLy8gbW9kdWxlcyBtb25rZXktcGF0Y2ggaXQgdG8gc3VwcG9ydCBhZGRpdGlvbmFsIGVuY29kaW5nc1xuZnVuY3Rpb24gbm9ybWFsaXplRW5jb2RpbmcoZW5jKSB7XG4gIHZhciBuZW5jID0gX25vcm1hbGl6ZUVuY29kaW5nKGVuYyk7XG4gIGlmICh0eXBlb2YgbmVuYyAhPT0gJ3N0cmluZycgJiYgKEJ1ZmZlci5pc0VuY29kaW5nID09PSBpc0VuY29kaW5nIHx8ICFpc0VuY29kaW5nKGVuYykpKSB0aHJvdyBuZXcgRXJyb3IoJ1Vua25vd24gZW5jb2Rpbmc6ICcgKyBlbmMpO1xuICByZXR1cm4gbmVuYyB8fCBlbmM7XG59XG5cbi8vIFN0cmluZ0RlY29kZXIgcHJvdmlkZXMgYW4gaW50ZXJmYWNlIGZvciBlZmZpY2llbnRseSBzcGxpdHRpbmcgYSBzZXJpZXMgb2Zcbi8vIGJ1ZmZlcnMgaW50byBhIHNlcmllcyBvZiBKUyBzdHJpbmdzIHdpdGhvdXQgYnJlYWtpbmcgYXBhcnQgbXVsdGktYnl0ZVxuLy8gY2hhcmFjdGVycy5cbmV4cG9ydHMuU3RyaW5nRGVjb2RlciA9IFN0cmluZ0RlY29kZXI7XG5mdW5jdGlvbiBTdHJpbmdEZWNvZGVyKGVuY29kaW5nKSB7XG4gIHRoaXMuZW5jb2RpbmcgPSBub3JtYWxpemVFbmNvZGluZyhlbmNvZGluZyk7XG4gIHZhciBuYjtcbiAgc3dpdGNoICh0aGlzLmVuY29kaW5nKSB7XG4gICAgY2FzZSAndXRmMTZsZSc6XG4gICAgICB0aGlzLnRleHQgPSB1dGYxNlRleHQ7XG4gICAgICB0aGlzLmVuZCA9IHV0ZjE2RW5kO1xuICAgICAgbmIgPSA0O1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAndXRmOCc6XG4gICAgICB0aGlzLmZpbGxMYXN0ID0gdXRmOEZpbGxMYXN0O1xuICAgICAgbmIgPSA0O1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnYmFzZTY0JzpcbiAgICAgIHRoaXMudGV4dCA9IGJhc2U2NFRleHQ7XG4gICAgICB0aGlzLmVuZCA9IGJhc2U2NEVuZDtcbiAgICAgIG5iID0gMztcbiAgICAgIGJyZWFrO1xuICAgIGRlZmF1bHQ6XG4gICAgICB0aGlzLndyaXRlID0gc2ltcGxlV3JpdGU7XG4gICAgICB0aGlzLmVuZCA9IHNpbXBsZUVuZDtcbiAgICAgIHJldHVybjtcbiAgfVxuICB0aGlzLmxhc3ROZWVkID0gMDtcbiAgdGhpcy5sYXN0VG90YWwgPSAwO1xuICB0aGlzLmxhc3RDaGFyID0gQnVmZmVyLmFsbG9jVW5zYWZlKG5iKTtcbn1cblxuU3RyaW5nRGVjb2Rlci5wcm90b3R5cGUud3JpdGUgPSBmdW5jdGlvbiAoYnVmKSB7XG4gIGlmIChidWYubGVuZ3RoID09PSAwKSByZXR1cm4gJyc7XG4gIHZhciByO1xuICB2YXIgaTtcbiAgaWYgKHRoaXMubGFzdE5lZWQpIHtcbiAgICByID0gdGhpcy5maWxsTGFzdChidWYpO1xuICAgIGlmIChyID09PSB1bmRlZmluZWQpIHJldHVybiAnJztcbiAgICBpID0gdGhpcy5sYXN0TmVlZDtcbiAgICB0aGlzLmxhc3ROZWVkID0gMDtcbiAgfSBlbHNlIHtcbiAgICBpID0gMDtcbiAgfVxuICBpZiAoaSA8IGJ1Zi5sZW5ndGgpIHJldHVybiByID8gciArIHRoaXMudGV4dChidWYsIGkpIDogdGhpcy50ZXh0KGJ1ZiwgaSk7XG4gIHJldHVybiByIHx8ICcnO1xufTtcblxuU3RyaW5nRGVjb2Rlci5wcm90b3R5cGUuZW5kID0gdXRmOEVuZDtcblxuLy8gUmV0dXJucyBvbmx5IGNvbXBsZXRlIGNoYXJhY3RlcnMgaW4gYSBCdWZmZXJcblN0cmluZ0RlY29kZXIucHJvdG90eXBlLnRleHQgPSB1dGY4VGV4dDtcblxuLy8gQXR0ZW1wdHMgdG8gY29tcGxldGUgYSBwYXJ0aWFsIG5vbi1VVEYtOCBjaGFyYWN0ZXIgdXNpbmcgYnl0ZXMgZnJvbSBhIEJ1ZmZlclxuU3RyaW5nRGVjb2Rlci5wcm90b3R5cGUuZmlsbExhc3QgPSBmdW5jdGlvbiAoYnVmKSB7XG4gIGlmICh0aGlzLmxhc3ROZWVkIDw9IGJ1Zi5sZW5ndGgpIHtcbiAgICBidWYuY29weSh0aGlzLmxhc3RDaGFyLCB0aGlzLmxhc3RUb3RhbCAtIHRoaXMubGFzdE5lZWQsIDAsIHRoaXMubGFzdE5lZWQpO1xuICAgIHJldHVybiB0aGlzLmxhc3RDaGFyLnRvU3RyaW5nKHRoaXMuZW5jb2RpbmcsIDAsIHRoaXMubGFzdFRvdGFsKTtcbiAgfVxuICBidWYuY29weSh0aGlzLmxhc3RDaGFyLCB0aGlzLmxhc3RUb3RhbCAtIHRoaXMubGFzdE5lZWQsIDAsIGJ1Zi5sZW5ndGgpO1xuICB0aGlzLmxhc3ROZWVkIC09IGJ1Zi5sZW5ndGg7XG59O1xuXG4vLyBDaGVja3MgdGhlIHR5cGUgb2YgYSBVVEYtOCBieXRlLCB3aGV0aGVyIGl0J3MgQVNDSUksIGEgbGVhZGluZyBieXRlLCBvciBhXG4vLyBjb250aW51YXRpb24gYnl0ZS4gSWYgYW4gaW52YWxpZCBieXRlIGlzIGRldGVjdGVkLCAtMiBpcyByZXR1cm5lZC5cbmZ1bmN0aW9uIHV0ZjhDaGVja0J5dGUoYnl0ZSkge1xuICBpZiAoYnl0ZSA8PSAweDdGKSByZXR1cm4gMDtlbHNlIGlmIChieXRlID4+IDUgPT09IDB4MDYpIHJldHVybiAyO2Vsc2UgaWYgKGJ5dGUgPj4gNCA9PT0gMHgwRSkgcmV0dXJuIDM7ZWxzZSBpZiAoYnl0ZSA+PiAzID09PSAweDFFKSByZXR1cm4gNDtcbiAgcmV0dXJuIGJ5dGUgPj4gNiA9PT0gMHgwMiA/IC0xIDogLTI7XG59XG5cbi8vIENoZWNrcyBhdCBtb3N0IDMgYnl0ZXMgYXQgdGhlIGVuZCBvZiBhIEJ1ZmZlciBpbiBvcmRlciB0byBkZXRlY3QgYW5cbi8vIGluY29tcGxldGUgbXVsdGktYnl0ZSBVVEYtOCBjaGFyYWN0ZXIuIFRoZSB0b3RhbCBudW1iZXIgb2YgYnl0ZXMgKDIsIDMsIG9yIDQpXG4vLyBuZWVkZWQgdG8gY29tcGxldGUgdGhlIFVURi04IGNoYXJhY3RlciAoaWYgYXBwbGljYWJsZSkgYXJlIHJldHVybmVkLlxuZnVuY3Rpb24gdXRmOENoZWNrSW5jb21wbGV0ZShzZWxmLCBidWYsIGkpIHtcbiAgdmFyIGogPSBidWYubGVuZ3RoIC0gMTtcbiAgaWYgKGogPCBpKSByZXR1cm4gMDtcbiAgdmFyIG5iID0gdXRmOENoZWNrQnl0ZShidWZbal0pO1xuICBpZiAobmIgPj0gMCkge1xuICAgIGlmIChuYiA+IDApIHNlbGYubGFzdE5lZWQgPSBuYiAtIDE7XG4gICAgcmV0dXJuIG5iO1xuICB9XG4gIGlmICgtLWogPCBpIHx8IG5iID09PSAtMikgcmV0dXJuIDA7XG4gIG5iID0gdXRmOENoZWNrQnl0ZShidWZbal0pO1xuICBpZiAobmIgPj0gMCkge1xuICAgIGlmIChuYiA+IDApIHNlbGYubGFzdE5lZWQgPSBuYiAtIDI7XG4gICAgcmV0dXJuIG5iO1xuICB9XG4gIGlmICgtLWogPCBpIHx8IG5iID09PSAtMikgcmV0dXJuIDA7XG4gIG5iID0gdXRmOENoZWNrQnl0ZShidWZbal0pO1xuICBpZiAobmIgPj0gMCkge1xuICAgIGlmIChuYiA+IDApIHtcbiAgICAgIGlmIChuYiA9PT0gMikgbmIgPSAwO2Vsc2Ugc2VsZi5sYXN0TmVlZCA9IG5iIC0gMztcbiAgICB9XG4gICAgcmV0dXJuIG5iO1xuICB9XG4gIHJldHVybiAwO1xufVxuXG4vLyBWYWxpZGF0ZXMgYXMgbWFueSBjb250aW51YXRpb24gYnl0ZXMgZm9yIGEgbXVsdGktYnl0ZSBVVEYtOCBjaGFyYWN0ZXIgYXNcbi8vIG5lZWRlZCBvciBhcmUgYXZhaWxhYmxlLiBJZiB3ZSBzZWUgYSBub24tY29udGludWF0aW9uIGJ5dGUgd2hlcmUgd2UgZXhwZWN0XG4vLyBvbmUsIHdlIFwicmVwbGFjZVwiIHRoZSB2YWxpZGF0ZWQgY29udGludWF0aW9uIGJ5dGVzIHdlJ3ZlIHNlZW4gc28gZmFyIHdpdGhcbi8vIGEgc2luZ2xlIFVURi04IHJlcGxhY2VtZW50IGNoYXJhY3RlciAoJ1xcdWZmZmQnKSwgdG8gbWF0Y2ggdjgncyBVVEYtOCBkZWNvZGluZ1xuLy8gYmVoYXZpb3IuIFRoZSBjb250aW51YXRpb24gYnl0ZSBjaGVjayBpcyBpbmNsdWRlZCB0aHJlZSB0aW1lcyBpbiB0aGUgY2FzZVxuLy8gd2hlcmUgYWxsIG9mIHRoZSBjb250aW51YXRpb24gYnl0ZXMgZm9yIGEgY2hhcmFjdGVyIGV4aXN0IGluIHRoZSBzYW1lIGJ1ZmZlci5cbi8vIEl0IGlzIGFsc28gZG9uZSB0aGlzIHdheSBhcyBhIHNsaWdodCBwZXJmb3JtYW5jZSBpbmNyZWFzZSBpbnN0ZWFkIG9mIHVzaW5nIGFcbi8vIGxvb3AuXG5mdW5jdGlvbiB1dGY4Q2hlY2tFeHRyYUJ5dGVzKHNlbGYsIGJ1ZiwgcCkge1xuICBpZiAoKGJ1ZlswXSAmIDB4QzApICE9PSAweDgwKSB7XG4gICAgc2VsZi5sYXN0TmVlZCA9IDA7XG4gICAgcmV0dXJuICdcXHVmZmZkJztcbiAgfVxuICBpZiAoc2VsZi5sYXN0TmVlZCA+IDEgJiYgYnVmLmxlbmd0aCA+IDEpIHtcbiAgICBpZiAoKGJ1ZlsxXSAmIDB4QzApICE9PSAweDgwKSB7XG4gICAgICBzZWxmLmxhc3ROZWVkID0gMTtcbiAgICAgIHJldHVybiAnXFx1ZmZmZCc7XG4gICAgfVxuICAgIGlmIChzZWxmLmxhc3ROZWVkID4gMiAmJiBidWYubGVuZ3RoID4gMikge1xuICAgICAgaWYgKChidWZbMl0gJiAweEMwKSAhPT0gMHg4MCkge1xuICAgICAgICBzZWxmLmxhc3ROZWVkID0gMjtcbiAgICAgICAgcmV0dXJuICdcXHVmZmZkJztcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuLy8gQXR0ZW1wdHMgdG8gY29tcGxldGUgYSBtdWx0aS1ieXRlIFVURi04IGNoYXJhY3RlciB1c2luZyBieXRlcyBmcm9tIGEgQnVmZmVyLlxuZnVuY3Rpb24gdXRmOEZpbGxMYXN0KGJ1Zikge1xuICB2YXIgcCA9IHRoaXMubGFzdFRvdGFsIC0gdGhpcy5sYXN0TmVlZDtcbiAgdmFyIHIgPSB1dGY4Q2hlY2tFeHRyYUJ5dGVzKHRoaXMsIGJ1ZiwgcCk7XG4gIGlmIChyICE9PSB1bmRlZmluZWQpIHJldHVybiByO1xuICBpZiAodGhpcy5sYXN0TmVlZCA8PSBidWYubGVuZ3RoKSB7XG4gICAgYnVmLmNvcHkodGhpcy5sYXN0Q2hhciwgcCwgMCwgdGhpcy5sYXN0TmVlZCk7XG4gICAgcmV0dXJuIHRoaXMubGFzdENoYXIudG9TdHJpbmcodGhpcy5lbmNvZGluZywgMCwgdGhpcy5sYXN0VG90YWwpO1xuICB9XG4gIGJ1Zi5jb3B5KHRoaXMubGFzdENoYXIsIHAsIDAsIGJ1Zi5sZW5ndGgpO1xuICB0aGlzLmxhc3ROZWVkIC09IGJ1Zi5sZW5ndGg7XG59XG5cbi8vIFJldHVybnMgYWxsIGNvbXBsZXRlIFVURi04IGNoYXJhY3RlcnMgaW4gYSBCdWZmZXIuIElmIHRoZSBCdWZmZXIgZW5kZWQgb24gYVxuLy8gcGFydGlhbCBjaGFyYWN0ZXIsIHRoZSBjaGFyYWN0ZXIncyBieXRlcyBhcmUgYnVmZmVyZWQgdW50aWwgdGhlIHJlcXVpcmVkXG4vLyBudW1iZXIgb2YgYnl0ZXMgYXJlIGF2YWlsYWJsZS5cbmZ1bmN0aW9uIHV0ZjhUZXh0KGJ1ZiwgaSkge1xuICB2YXIgdG90YWwgPSB1dGY4Q2hlY2tJbmNvbXBsZXRlKHRoaXMsIGJ1ZiwgaSk7XG4gIGlmICghdGhpcy5sYXN0TmVlZCkgcmV0dXJuIGJ1Zi50b1N0cmluZygndXRmOCcsIGkpO1xuICB0aGlzLmxhc3RUb3RhbCA9IHRvdGFsO1xuICB2YXIgZW5kID0gYnVmLmxlbmd0aCAtICh0b3RhbCAtIHRoaXMubGFzdE5lZWQpO1xuICBidWYuY29weSh0aGlzLmxhc3RDaGFyLCAwLCBlbmQpO1xuICByZXR1cm4gYnVmLnRvU3RyaW5nKCd1dGY4JywgaSwgZW5kKTtcbn1cblxuLy8gRm9yIFVURi04LCBhIHJlcGxhY2VtZW50IGNoYXJhY3RlciBpcyBhZGRlZCB3aGVuIGVuZGluZyBvbiBhIHBhcnRpYWxcbi8vIGNoYXJhY3Rlci5cbmZ1bmN0aW9uIHV0ZjhFbmQoYnVmKSB7XG4gIHZhciByID0gYnVmICYmIGJ1Zi5sZW5ndGggPyB0aGlzLndyaXRlKGJ1ZikgOiAnJztcbiAgaWYgKHRoaXMubGFzdE5lZWQpIHJldHVybiByICsgJ1xcdWZmZmQnO1xuICByZXR1cm4gcjtcbn1cblxuLy8gVVRGLTE2TEUgdHlwaWNhbGx5IG5lZWRzIHR3byBieXRlcyBwZXIgY2hhcmFjdGVyLCBidXQgZXZlbiBpZiB3ZSBoYXZlIGFuIGV2ZW5cbi8vIG51bWJlciBvZiBieXRlcyBhdmFpbGFibGUsIHdlIG5lZWQgdG8gY2hlY2sgaWYgd2UgZW5kIG9uIGEgbGVhZGluZy9oaWdoXG4vLyBzdXJyb2dhdGUuIEluIHRoYXQgY2FzZSwgd2UgbmVlZCB0byB3YWl0IGZvciB0aGUgbmV4dCB0d28gYnl0ZXMgaW4gb3JkZXIgdG9cbi8vIGRlY29kZSB0aGUgbGFzdCBjaGFyYWN0ZXIgcHJvcGVybHkuXG5mdW5jdGlvbiB1dGYxNlRleHQoYnVmLCBpKSB7XG4gIGlmICgoYnVmLmxlbmd0aCAtIGkpICUgMiA9PT0gMCkge1xuICAgIHZhciByID0gYnVmLnRvU3RyaW5nKCd1dGYxNmxlJywgaSk7XG4gICAgaWYgKHIpIHtcbiAgICAgIHZhciBjID0gci5jaGFyQ29kZUF0KHIubGVuZ3RoIC0gMSk7XG4gICAgICBpZiAoYyA+PSAweEQ4MDAgJiYgYyA8PSAweERCRkYpIHtcbiAgICAgICAgdGhpcy5sYXN0TmVlZCA9IDI7XG4gICAgICAgIHRoaXMubGFzdFRvdGFsID0gNDtcbiAgICAgICAgdGhpcy5sYXN0Q2hhclswXSA9IGJ1ZltidWYubGVuZ3RoIC0gMl07XG4gICAgICAgIHRoaXMubGFzdENoYXJbMV0gPSBidWZbYnVmLmxlbmd0aCAtIDFdO1xuICAgICAgICByZXR1cm4gci5zbGljZSgwLCAtMSk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiByO1xuICB9XG4gIHRoaXMubGFzdE5lZWQgPSAxO1xuICB0aGlzLmxhc3RUb3RhbCA9IDI7XG4gIHRoaXMubGFzdENoYXJbMF0gPSBidWZbYnVmLmxlbmd0aCAtIDFdO1xuICByZXR1cm4gYnVmLnRvU3RyaW5nKCd1dGYxNmxlJywgaSwgYnVmLmxlbmd0aCAtIDEpO1xufVxuXG4vLyBGb3IgVVRGLTE2TEUgd2UgZG8gbm90IGV4cGxpY2l0bHkgYXBwZW5kIHNwZWNpYWwgcmVwbGFjZW1lbnQgY2hhcmFjdGVycyBpZiB3ZVxuLy8gZW5kIG9uIGEgcGFydGlhbCBjaGFyYWN0ZXIsIHdlIHNpbXBseSBsZXQgdjggaGFuZGxlIHRoYXQuXG5mdW5jdGlvbiB1dGYxNkVuZChidWYpIHtcbiAgdmFyIHIgPSBidWYgJiYgYnVmLmxlbmd0aCA/IHRoaXMud3JpdGUoYnVmKSA6ICcnO1xuICBpZiAodGhpcy5sYXN0TmVlZCkge1xuICAgIHZhciBlbmQgPSB0aGlzLmxhc3RUb3RhbCAtIHRoaXMubGFzdE5lZWQ7XG4gICAgcmV0dXJuIHIgKyB0aGlzLmxhc3RDaGFyLnRvU3RyaW5nKCd1dGYxNmxlJywgMCwgZW5kKTtcbiAgfVxuICByZXR1cm4gcjtcbn1cblxuZnVuY3Rpb24gYmFzZTY0VGV4dChidWYsIGkpIHtcbiAgdmFyIG4gPSAoYnVmLmxlbmd0aCAtIGkpICUgMztcbiAgaWYgKG4gPT09IDApIHJldHVybiBidWYudG9TdHJpbmcoJ2Jhc2U2NCcsIGkpO1xuICB0aGlzLmxhc3ROZWVkID0gMyAtIG47XG4gIHRoaXMubGFzdFRvdGFsID0gMztcbiAgaWYgKG4gPT09IDEpIHtcbiAgICB0aGlzLmxhc3RDaGFyWzBdID0gYnVmW2J1Zi5sZW5ndGggLSAxXTtcbiAgfSBlbHNlIHtcbiAgICB0aGlzLmxhc3RDaGFyWzBdID0gYnVmW2J1Zi5sZW5ndGggLSAyXTtcbiAgICB0aGlzLmxhc3RDaGFyWzFdID0gYnVmW2J1Zi5sZW5ndGggLSAxXTtcbiAgfVxuICByZXR1cm4gYnVmLnRvU3RyaW5nKCdiYXNlNjQnLCBpLCBidWYubGVuZ3RoIC0gbik7XG59XG5cbmZ1bmN0aW9uIGJhc2U2NEVuZChidWYpIHtcbiAgdmFyIHIgPSBidWYgJiYgYnVmLmxlbmd0aCA/IHRoaXMud3JpdGUoYnVmKSA6ICcnO1xuICBpZiAodGhpcy5sYXN0TmVlZCkgcmV0dXJuIHIgKyB0aGlzLmxhc3RDaGFyLnRvU3RyaW5nKCdiYXNlNjQnLCAwLCAzIC0gdGhpcy5sYXN0TmVlZCk7XG4gIHJldHVybiByO1xufVxuXG4vLyBQYXNzIGJ5dGVzIG9uIHRocm91Z2ggZm9yIHNpbmdsZS1ieXRlIGVuY29kaW5ncyAoZS5nLiBhc2NpaSwgbGF0aW4xLCBoZXgpXG5mdW5jdGlvbiBzaW1wbGVXcml0ZShidWYpIHtcbiAgcmV0dXJuIGJ1Zi50b1N0cmluZyh0aGlzLmVuY29kaW5nKTtcbn1cblxuZnVuY3Rpb24gc2ltcGxlRW5kKGJ1Zikge1xuICByZXR1cm4gYnVmICYmIGJ1Zi5sZW5ndGggPyB0aGlzLndyaXRlKGJ1ZikgOiAnJztcbn0iLCJcbi8qKlxuICogRm9yIE5vZGUuanMsIHNpbXBseSByZS1leHBvcnQgdGhlIGNvcmUgYHV0aWwuZGVwcmVjYXRlYCBmdW5jdGlvbi5cbiAqL1xuXG5tb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJ3V0aWwnKS5kZXByZWNhdGU7XG4iLCJtb2R1bGUuZXhwb3J0cyA9IGV4dGVuZFxuXG52YXIgaGFzT3duUHJvcGVydHkgPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5O1xuXG5mdW5jdGlvbiBleHRlbmQodGFyZ2V0KSB7XG4gICAgZm9yICh2YXIgaSA9IDE7IGkgPCBhcmd1bWVudHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgdmFyIHNvdXJjZSA9IGFyZ3VtZW50c1tpXVxuXG4gICAgICAgIGZvciAodmFyIGtleSBpbiBzb3VyY2UpIHtcbiAgICAgICAgICAgIGlmIChoYXNPd25Qcm9wZXJ0eS5jYWxsKHNvdXJjZSwga2V5KSkge1xuICAgICAgICAgICAgICAgIHRhcmdldFtrZXldID0gc291cmNlW2tleV1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiB0YXJnZXRcbn1cbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImFzc2VydFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJidWZmZXJcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiY3J5cHRvXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImRuc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJldmVudHNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiZnNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInBhdGhcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwic3RyZWFtXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInN0cmluZ19kZWNvZGVyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInRsc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJ1cmxcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwidXRpbFwiKTsiLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuIiwiLy8gZGVmaW5lIGdldHRlciBmdW5jdGlvbnMgZm9yIGhhcm1vbnkgZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5kID0gKGV4cG9ydHMsIGRlZmluaXRpb24pID0+IHtcblx0Zm9yKHZhciBrZXkgaW4gZGVmaW5pdGlvbikge1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhkZWZpbml0aW9uLCBrZXkpICYmICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywga2V5KSkge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGRlZmluaXRpb25ba2V5XSB9KTtcblx0XHR9XG5cdH1cbn07IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5vID0gKG9iaiwgcHJvcCkgPT4gKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHByb3ApKSIsIi8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uciA9IChleHBvcnRzKSA9PiB7XG5cdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuXHR9XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG59OyIsIiIsIi8vIHN0YXJ0dXBcbi8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuLy8gVGhpcyBlbnRyeSBtb2R1bGUgZG9lc24ndCB0ZWxsIGFib3V0IGl0J3MgdG9wLWxldmVsIGRlY2xhcmF0aW9ucyBzbyBpdCBjYW4ndCBiZSBpbmxpbmVkXG52YXIgX193ZWJwYWNrX2V4cG9ydHNfXyA9IF9fd2VicGFja19yZXF1aXJlX18oNTAzNSk7XG4iLCIiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=