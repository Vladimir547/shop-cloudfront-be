/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 5035:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "handler": () => (/* binding */ handler)
});

;// CONCATENATED MODULE: ./lambdas/db/products.json
const products_namespaceObject = JSON.parse('[{"count":1,"description":"desc 1","id":"7567ec4b-b10c-48c5-9345-fc73c48a80aa","price":2.4,"title":"guitar 1"},{"count":2,"description":"desc 2","id":"7567ec4b-b10c-48c5-9345-fc73c48a80a0","price":10,"title":"guitar 2"},{"count":3,"description":"desc 3","id":"7567ec4b-b10c-48c5-9345-fc73c48a80a2","price":23,"title":"guitar 3"},{"count":4,"description":"desc 4","id":"7567ec4b-b10c-48c5-9345-fc73c48a80a1","price":15,"title":"guitar 4"},{"count":5,"description":"desc 5","id":"7567ec4b-b10c-48c5-9345-fc73c48a80a3","price":23,"title":"guitar 5"},{"count":6,"description":"desc 6","id":"7567ec4b-b10c-48c5-9345-fc73348a80a1","price":15,"title":"guitar 6"},{"count":7,"description":"desc 7","id":"7567ec4b-b10c-48c5-9445-fc73c48a80a2","price":23,"title":"guitar 7"},{"count":8,"description":"desc 8","id":"7567ec4b-b10c-45c5-9345-fc73c48a80a1","price":15,"title":"guitar 8"}]');
// EXTERNAL MODULE: ./node_modules/pg/lib/index.js
var lib = __webpack_require__(8955);
;// CONCATENATED MODULE: ./conection.js



const { PG_HOST, PG_PORT, PG_DATABASE, PG_USERNAME, PG_PASSWORD } = process.env;
const dbOptions = {
    host: PG_HOST,
    port: PG_PORT,
    database: PG_DATABASE,
    user: PG_USERNAME,
    password: PG_PASSWORD,
    ssl: {
        rejectUnauthorized: false,
    },
    connectionTimeoutMillis: 5000,
};
class ConnectDB {
    constructor() {
        this.client = new lib.Client(dbOptions);
    }

    async connect() {
        await this.client.connect();
        return this.client;
    }

    async disconnect() {
        await this.client.end();
    }

    async createTable(tableName, config) {
        await this.client.query(`
  create table if not exist ${tableName} (
    ${config}
  )`);
    }


    async getList(tableName) {
        const { rows } = await this.client.query(select * from `${tableName}`);
        return rows;
    }
}
;// CONCATENATED MODULE: ./lambdas/getProductsById.js




const handler = async (event) => {
    console.log(event);
    const { productId } = event.pathParameters || {};
    const getProduct = products_namespaceObject.find((item, id) => {
        return item.id == productId;
    });
    const db = new ConnectDB();

    try {
        const client = await db.connect();

        const { rows } = await client.query(`select products.*, stock.count from products left join stock on products.id = stock.product_id where products.id='${productId}'`);
        return {
            headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Methods': '*',
                    'Access-Control-Allow-Origin': '*',
                  },
                statusCode: 200,
                body: JSON.stringify(rows)
            };
    } catch (error) {

    return {
        headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Origin': '*',
              },
            statusCode: 500,
            body: JSON.stringify({ message: error.message })
        };
    } finally {
        db.disconnect();
    }
    // const response = {
    //     headers: {
    //         'Content-Type': 'application/json',
    //         'Access-Control-Allow-Methods': '*',
    //         'Access-Control-Allow-Origin': '*',
    //       },
    //     statusCode: 200,
    // }
    // if (!getProduct)   { 
    //     response.body =  JSON.stringify({ message: 'Error: Product not found!' });

    //     response.statusCode = 404;
    // } else {
    //     response.body = JSON.stringify(getProduct); 
    // }
    // return response;
}

/***/ }),

/***/ 4378:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

try {
  var util = __webpack_require__(1669);
  /* istanbul ignore next */
  if (typeof util.inherits !== 'function') throw '';
  module.exports = util.inherits;
} catch (e) {
  /* istanbul ignore next */
  module.exports = __webpack_require__(5717);
}


/***/ }),

/***/ 5717:
/***/ ((module) => {

if (typeof Object.create === 'function') {
  // implementation from standard node.js 'util' module
  module.exports = function inherits(ctor, superCtor) {
    if (superCtor) {
      ctor.super_ = superCtor
      ctor.prototype = Object.create(superCtor.prototype, {
        constructor: {
          value: ctor,
          enumerable: false,
          writable: true,
          configurable: true
        }
      })
    }
  };
} else {
  // old school shim for old browsers
  module.exports = function inherits(ctor, superCtor) {
    if (superCtor) {
      ctor.super_ = superCtor
      var TempCtor = function () {}
      TempCtor.prototype = superCtor.prototype
      ctor.prototype = new TempCtor()
      ctor.prototype.constructor = ctor
    }
  }
}


/***/ }),

/***/ 5697:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var url = __webpack_require__(8835)
var fs = __webpack_require__(5747)

//Parse method copied from https://github.com/brianc/node-postgres
//Copyright (c) 2010-2014 Brian Carlson (brian.m.carlson@gmail.com)
//MIT License

//parses a connection string
function parse(str) {
  //unix socket
  if (str.charAt(0) === '/') {
    var config = str.split(' ')
    return { host: config[0], database: config[1] }
  }

  // url parse expects spaces encoded as %20
  var result = url.parse(
    / |%[^a-f0-9]|%[a-f0-9][^a-f0-9]/i.test(str) ? encodeURI(str).replace(/\%25(\d\d)/g, '%$1') : str,
    true
  )
  var config = result.query
  for (var k in config) {
    if (Array.isArray(config[k])) {
      config[k] = config[k][config[k].length - 1]
    }
  }

  var auth = (result.auth || ':').split(':')
  config.user = auth[0]
  config.password = auth.splice(1).join(':')

  config.port = result.port
  if (result.protocol == 'socket:') {
    config.host = decodeURI(result.pathname)
    config.database = result.query.db
    config.client_encoding = result.query.encoding
    return config
  }
  if (!config.host) {
    // Only set the host if there is no equivalent query param.
    config.host = result.hostname
  }

  // If the host is missing it might be a URL-encoded path to a socket.
  var pathname = result.pathname
  if (!config.host && pathname && /^%2f/i.test(pathname)) {
    var pathnameSplit = pathname.split('/')
    config.host = decodeURIComponent(pathnameSplit[0])
    pathname = pathnameSplit.splice(1).join('/')
  }
  // result.pathname is not always guaranteed to have a '/' prefix (e.g. relative urls)
  // only strip the slash if it is present.
  if (pathname && pathname.charAt(0) === '/') {
    pathname = pathname.slice(1) || null
  }
  config.database = pathname && decodeURI(pathname)

  if (config.ssl === 'true' || config.ssl === '1') {
    config.ssl = true
  }

  if (config.ssl === '0') {
    config.ssl = false
  }

  if (config.sslcert || config.sslkey || config.sslrootcert || config.sslmode) {
    config.ssl = {}
  }

  if (config.sslcert) {
    config.ssl.cert = fs.readFileSync(config.sslcert).toString()
  }

  if (config.sslkey) {
    config.ssl.key = fs.readFileSync(config.sslkey).toString()
  }

  if (config.sslrootcert) {
    config.ssl.ca = fs.readFileSync(config.sslrootcert).toString()
  }

  switch (config.sslmode) {
    case 'disable': {
      config.ssl = false
      break
    }
    case 'prefer':
    case 'require':
    case 'verify-ca':
    case 'verify-full': {
      break
    }
    case 'no-verify': {
      config.ssl.rejectUnauthorized = false
      break
    }
  }

  return config
}

module.exports = parse

parse.parse = parse


/***/ }),

/***/ 6064:
/***/ ((module) => {

"use strict";


// selected so (BASE - 1) * 0x100000000 + 0xffffffff is a safe integer
var BASE = 1000000;

function readInt8(buffer) {
	var high = buffer.readInt32BE(0);
	var low = buffer.readUInt32BE(4);
	var sign = '';

	if (high < 0) {
		high = ~high + (low === 0);
		low = (~low + 1) >>> 0;
		sign = '-';
	}

	var result = '';
	var carry;
	var t;
	var digits;
	var pad;
	var l;
	var i;

	{
		carry = high % BASE;
		high = high / BASE >>> 0;

		t = 0x100000000 * carry + low;
		low = t / BASE >>> 0;
		digits = '' + (t - BASE * low);

		if (low === 0 && high === 0) {
			return sign + digits + result;
		}

		pad = '';
		l = 6 - digits.length;

		for (i = 0; i < l; i++) {
			pad += '0';
		}

		result = pad + digits + result;
	}

	{
		carry = high % BASE;
		high = high / BASE >>> 0;

		t = 0x100000000 * carry + low;
		low = t / BASE >>> 0;
		digits = '' + (t - BASE * low);

		if (low === 0 && high === 0) {
			return sign + digits + result;
		}

		pad = '';
		l = 6 - digits.length;

		for (i = 0; i < l; i++) {
			pad += '0';
		}

		result = pad + digits + result;
	}

	{
		carry = high % BASE;
		high = high / BASE >>> 0;

		t = 0x100000000 * carry + low;
		low = t / BASE >>> 0;
		digits = '' + (t - BASE * low);

		if (low === 0 && high === 0) {
			return sign + digits + result;
		}

		pad = '';
		l = 6 - digits.length;

		for (i = 0; i < l; i++) {
			pad += '0';
		}

		result = pad + digits + result;
	}

	{
		carry = high % BASE;
		t = 0x100000000 * carry + low;
		digits = '' + t % BASE;

		return sign + digits + result;
	}
}

module.exports = readInt8;


/***/ }),

/***/ 5546:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

const EventEmitter = __webpack_require__(8614).EventEmitter

const NOOP = function () {}

const removeWhere = (list, predicate) => {
  const i = list.findIndex(predicate)

  return i === -1 ? undefined : list.splice(i, 1)[0]
}

class IdleItem {
  constructor(client, idleListener, timeoutId) {
    this.client = client
    this.idleListener = idleListener
    this.timeoutId = timeoutId
  }
}

class PendingItem {
  constructor(callback) {
    this.callback = callback
  }
}

function throwOnDoubleRelease() {
  throw new Error('Release called on client which has already been released to the pool.')
}

function promisify(Promise, callback) {
  if (callback) {
    return { callback: callback, result: undefined }
  }
  let rej
  let res
  const cb = function (err, client) {
    err ? rej(err) : res(client)
  }
  const result = new Promise(function (resolve, reject) {
    res = resolve
    rej = reject
  })
  return { callback: cb, result: result }
}

function makeIdleListener(pool, client) {
  return function idleListener(err) {
    err.client = client

    client.removeListener('error', idleListener)
    client.on('error', () => {
      pool.log('additional client error after disconnection due to error', err)
    })
    pool._remove(client)
    // TODO - document that once the pool emits an error
    // the client has already been closed & purged and is unusable
    pool.emit('error', err, client)
  }
}

class Pool extends EventEmitter {
  constructor(options, Client) {
    super()
    this.options = Object.assign({}, options)

    if (options != null && 'password' in options) {
      // "hiding" the password so it doesn't show up in stack traces
      // or if the client is console.logged
      Object.defineProperty(this.options, 'password', {
        configurable: true,
        enumerable: false,
        writable: true,
        value: options.password,
      })
    }
    if (options != null && options.ssl && options.ssl.key) {
      // "hiding" the ssl->key so it doesn't show up in stack traces
      // or if the client is console.logged
      Object.defineProperty(this.options.ssl, 'key', {
        enumerable: false,
      })
    }

    this.options.max = this.options.max || this.options.poolSize || 10
    this.options.maxUses = this.options.maxUses || Infinity
    this.options.allowExitOnIdle = this.options.allowExitOnIdle || false
    this.log = this.options.log || function () {}
    this.Client = this.options.Client || Client || __webpack_require__(8955).Client
    this.Promise = this.options.Promise || global.Promise

    if (typeof this.options.idleTimeoutMillis === 'undefined') {
      this.options.idleTimeoutMillis = 10000
    }

    this._clients = []
    this._idle = []
    this._pendingQueue = []
    this._endCallback = undefined
    this.ending = false
    this.ended = false
  }

  _isFull() {
    return this._clients.length >= this.options.max
  }

  _pulseQueue() {
    this.log('pulse queue')
    if (this.ended) {
      this.log('pulse queue ended')
      return
    }
    if (this.ending) {
      this.log('pulse queue on ending')
      if (this._idle.length) {
        this._idle.slice().map((item) => {
          this._remove(item.client)
        })
      }
      if (!this._clients.length) {
        this.ended = true
        this._endCallback()
      }
      return
    }
    // if we don't have any waiting, do nothing
    if (!this._pendingQueue.length) {
      this.log('no queued requests')
      return
    }
    // if we don't have any idle clients and we have no more room do nothing
    if (!this._idle.length && this._isFull()) {
      return
    }
    const pendingItem = this._pendingQueue.shift()
    if (this._idle.length) {
      const idleItem = this._idle.pop()
      clearTimeout(idleItem.timeoutId)
      const client = idleItem.client
      client.ref && client.ref()
      const idleListener = idleItem.idleListener

      return this._acquireClient(client, pendingItem, idleListener, false)
    }
    if (!this._isFull()) {
      return this.newClient(pendingItem)
    }
    throw new Error('unexpected condition')
  }

  _remove(client) {
    const removed = removeWhere(this._idle, (item) => item.client === client)

    if (removed !== undefined) {
      clearTimeout(removed.timeoutId)
    }

    this._clients = this._clients.filter((c) => c !== client)
    client.end()
    this.emit('remove', client)
  }

  connect(cb) {
    if (this.ending) {
      const err = new Error('Cannot use a pool after calling end on the pool')
      return cb ? cb(err) : this.Promise.reject(err)
    }

    const response = promisify(this.Promise, cb)
    const result = response.result

    // if we don't have to connect a new client, don't do so
    if (this._isFull() || this._idle.length) {
      // if we have idle clients schedule a pulse immediately
      if (this._idle.length) {
        process.nextTick(() => this._pulseQueue())
      }

      if (!this.options.connectionTimeoutMillis) {
        this._pendingQueue.push(new PendingItem(response.callback))
        return result
      }

      const queueCallback = (err, res, done) => {
        clearTimeout(tid)
        response.callback(err, res, done)
      }

      const pendingItem = new PendingItem(queueCallback)

      // set connection timeout on checking out an existing client
      const tid = setTimeout(() => {
        // remove the callback from pending waiters because
        // we're going to call it with a timeout error
        removeWhere(this._pendingQueue, (i) => i.callback === queueCallback)
        pendingItem.timedOut = true
        response.callback(new Error('timeout exceeded when trying to connect'))
      }, this.options.connectionTimeoutMillis)

      this._pendingQueue.push(pendingItem)
      return result
    }

    this.newClient(new PendingItem(response.callback))

    return result
  }

  newClient(pendingItem) {
    const client = new this.Client(this.options)
    this._clients.push(client)
    const idleListener = makeIdleListener(this, client)

    this.log('checking client timeout')

    // connection timeout logic
    let tid
    let timeoutHit = false
    if (this.options.connectionTimeoutMillis) {
      tid = setTimeout(() => {
        this.log('ending client due to timeout')
        timeoutHit = true
        // force kill the node driver, and let libpq do its teardown
        client.connection ? client.connection.stream.destroy() : client.end()
      }, this.options.connectionTimeoutMillis)
    }

    this.log('connecting new client')
    client.connect((err) => {
      if (tid) {
        clearTimeout(tid)
      }
      client.on('error', idleListener)
      if (err) {
        this.log('client failed to connect', err)
        // remove the dead client from our list of clients
        this._clients = this._clients.filter((c) => c !== client)
        if (timeoutHit) {
          err.message = 'Connection terminated due to connection timeout'
        }

        // this client won’t be released, so move on immediately
        this._pulseQueue()

        if (!pendingItem.timedOut) {
          pendingItem.callback(err, undefined, NOOP)
        }
      } else {
        this.log('new client connected')

        return this._acquireClient(client, pendingItem, idleListener, true)
      }
    })
  }

  // acquire a client for a pending work item
  _acquireClient(client, pendingItem, idleListener, isNew) {
    if (isNew) {
      this.emit('connect', client)
    }

    this.emit('acquire', client)

    client.release = this._releaseOnce(client, idleListener)

    client.removeListener('error', idleListener)

    if (!pendingItem.timedOut) {
      if (isNew && this.options.verify) {
        this.options.verify(client, (err) => {
          if (err) {
            client.release(err)
            return pendingItem.callback(err, undefined, NOOP)
          }

          pendingItem.callback(undefined, client, client.release)
        })
      } else {
        pendingItem.callback(undefined, client, client.release)
      }
    } else {
      if (isNew && this.options.verify) {
        this.options.verify(client, client.release)
      } else {
        client.release()
      }
    }
  }

  // returns a function that wraps _release and throws if called more than once
  _releaseOnce(client, idleListener) {
    let released = false

    return (err) => {
      if (released) {
        throwOnDoubleRelease()
      }

      released = true
      this._release(client, idleListener, err)
    }
  }

  // release a client back to the poll, include an error
  // to remove it from the pool
  _release(client, idleListener, err) {
    client.on('error', idleListener)

    client._poolUseCount = (client._poolUseCount || 0) + 1

    // TODO(bmc): expose a proper, public interface _queryable and _ending
    if (err || this.ending || !client._queryable || client._ending || client._poolUseCount >= this.options.maxUses) {
      if (client._poolUseCount >= this.options.maxUses) {
        this.log('remove expended client')
      }
      this._remove(client)
      this._pulseQueue()
      return
    }

    // idle timeout
    let tid
    if (this.options.idleTimeoutMillis) {
      tid = setTimeout(() => {
        this.log('remove idle client')
        this._remove(client)
      }, this.options.idleTimeoutMillis)

      if (this.options.allowExitOnIdle) {
        // allow Node to exit if this is all that's left
        tid.unref()
      }
    }

    if (this.options.allowExitOnIdle) {
      client.unref()
    }

    this._idle.push(new IdleItem(client, idleListener, tid))
    this._pulseQueue()
  }

  query(text, values, cb) {
    // guard clause against passing a function as the first parameter
    if (typeof text === 'function') {
      const response = promisify(this.Promise, text)
      setImmediate(function () {
        return response.callback(new Error('Passing a function as the first parameter to pool.query is not supported'))
      })
      return response.result
    }

    // allow plain text query without values
    if (typeof values === 'function') {
      cb = values
      values = undefined
    }
    const response = promisify(this.Promise, cb)
    cb = response.callback

    this.connect((err, client) => {
      if (err) {
        return cb(err)
      }

      let clientReleased = false
      const onError = (err) => {
        if (clientReleased) {
          return
        }
        clientReleased = true
        client.release(err)
        cb(err)
      }

      client.once('error', onError)
      this.log('dispatching query')
      client.query(text, values, (err, res) => {
        this.log('query dispatched')
        client.removeListener('error', onError)
        if (clientReleased) {
          return
        }
        clientReleased = true
        client.release(err)
        if (err) {
          return cb(err)
        } else {
          return cb(undefined, res)
        }
      })
    })
    return response.result
  }

  end(cb) {
    this.log('ending')
    if (this.ending) {
      const err = new Error('Called end on pool more than once')
      return cb ? cb(err) : this.Promise.reject(err)
    }
    this.ending = true
    const promised = promisify(this.Promise, cb)
    this._endCallback = promised.callback
    this._pulseQueue()
    return promised.result
  }

  get waitingCount() {
    return this._pendingQueue.length
  }

  get idleCount() {
    return this._idle.length
  }

  get totalCount() {
    return this._clients.length
  }
}
module.exports = Pool


/***/ }),

/***/ 1144:
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BufferReader = void 0;
const emptyBuffer = Buffer.allocUnsafe(0);
class BufferReader {
    constructor(offset = 0) {
        this.offset = offset;
        this.buffer = emptyBuffer;
        // TODO(bmc): support non-utf8 encoding?
        this.encoding = 'utf-8';
    }
    setBuffer(offset, buffer) {
        this.offset = offset;
        this.buffer = buffer;
    }
    int16() {
        const result = this.buffer.readInt16BE(this.offset);
        this.offset += 2;
        return result;
    }
    byte() {
        const result = this.buffer[this.offset];
        this.offset++;
        return result;
    }
    int32() {
        const result = this.buffer.readInt32BE(this.offset);
        this.offset += 4;
        return result;
    }
    string(length) {
        const result = this.buffer.toString(this.encoding, this.offset, this.offset + length);
        this.offset += length;
        return result;
    }
    cstring() {
        const start = this.offset;
        let end = start;
        while (this.buffer[end++] !== 0) { }
        this.offset = end;
        return this.buffer.toString(this.encoding, start, end - 1);
    }
    bytes(length) {
        const result = this.buffer.slice(this.offset, this.offset + length);
        this.offset += length;
        return result;
    }
}
exports.BufferReader = BufferReader;
//# sourceMappingURL=buffer-reader.js.map

/***/ }),

/***/ 246:
/***/ ((__unused_webpack_module, exports) => {

"use strict";

//binary data writer tuned for encoding binary specific to the postgres binary protocol
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Writer = void 0;
class Writer {
    constructor(size = 256) {
        this.size = size;
        this.offset = 5;
        this.headerPosition = 0;
        this.buffer = Buffer.allocUnsafe(size);
    }
    ensure(size) {
        var remaining = this.buffer.length - this.offset;
        if (remaining < size) {
            var oldBuffer = this.buffer;
            // exponential growth factor of around ~ 1.5
            // https://stackoverflow.com/questions/2269063/buffer-growth-strategy
            var newSize = oldBuffer.length + (oldBuffer.length >> 1) + size;
            this.buffer = Buffer.allocUnsafe(newSize);
            oldBuffer.copy(this.buffer);
        }
    }
    addInt32(num) {
        this.ensure(4);
        this.buffer[this.offset++] = (num >>> 24) & 0xff;
        this.buffer[this.offset++] = (num >>> 16) & 0xff;
        this.buffer[this.offset++] = (num >>> 8) & 0xff;
        this.buffer[this.offset++] = (num >>> 0) & 0xff;
        return this;
    }
    addInt16(num) {
        this.ensure(2);
        this.buffer[this.offset++] = (num >>> 8) & 0xff;
        this.buffer[this.offset++] = (num >>> 0) & 0xff;
        return this;
    }
    addCString(string) {
        if (!string) {
            this.ensure(1);
        }
        else {
            var len = Buffer.byteLength(string);
            this.ensure(len + 1); // +1 for null terminator
            this.buffer.write(string, this.offset, 'utf-8');
            this.offset += len;
        }
        this.buffer[this.offset++] = 0; // null terminator
        return this;
    }
    addString(string = '') {
        var len = Buffer.byteLength(string);
        this.ensure(len);
        this.buffer.write(string, this.offset);
        this.offset += len;
        return this;
    }
    add(otherBuffer) {
        this.ensure(otherBuffer.length);
        otherBuffer.copy(this.buffer, this.offset);
        this.offset += otherBuffer.length;
        return this;
    }
    join(code) {
        if (code) {
            this.buffer[this.headerPosition] = code;
            //length is everything in this packet minus the code
            const length = this.offset - (this.headerPosition + 1);
            this.buffer.writeInt32BE(length, this.headerPosition + 1);
        }
        return this.buffer.slice(code ? 0 : 5, this.offset);
    }
    flush(code) {
        var result = this.join(code);
        this.offset = 5;
        this.headerPosition = 0;
        this.buffer = Buffer.allocUnsafe(this.size);
        return result;
    }
}
exports.Writer = Writer;
//# sourceMappingURL=buffer-writer.js.map

/***/ }),

/***/ 8152:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DatabaseError = exports.serialize = exports.parse = void 0;
const messages_1 = __webpack_require__(2510);
Object.defineProperty(exports, "DatabaseError", ({ enumerable: true, get: function () { return messages_1.DatabaseError; } }));
const serializer_1 = __webpack_require__(9209);
Object.defineProperty(exports, "serialize", ({ enumerable: true, get: function () { return serializer_1.serialize; } }));
const parser_1 = __webpack_require__(946);
function parse(stream, callback) {
    const parser = new parser_1.Parser();
    stream.on('data', (buffer) => parser.parse(buffer, callback));
    return new Promise((resolve) => stream.on('end', () => resolve()));
}
exports.parse = parse;
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 2510:
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.NoticeMessage = exports.DataRowMessage = exports.CommandCompleteMessage = exports.ReadyForQueryMessage = exports.NotificationResponseMessage = exports.BackendKeyDataMessage = exports.AuthenticationMD5Password = exports.ParameterStatusMessage = exports.ParameterDescriptionMessage = exports.RowDescriptionMessage = exports.Field = exports.CopyResponse = exports.CopyDataMessage = exports.DatabaseError = exports.copyDone = exports.emptyQuery = exports.replicationStart = exports.portalSuspended = exports.noData = exports.closeComplete = exports.bindComplete = exports.parseComplete = void 0;
exports.parseComplete = {
    name: 'parseComplete',
    length: 5,
};
exports.bindComplete = {
    name: 'bindComplete',
    length: 5,
};
exports.closeComplete = {
    name: 'closeComplete',
    length: 5,
};
exports.noData = {
    name: 'noData',
    length: 5,
};
exports.portalSuspended = {
    name: 'portalSuspended',
    length: 5,
};
exports.replicationStart = {
    name: 'replicationStart',
    length: 4,
};
exports.emptyQuery = {
    name: 'emptyQuery',
    length: 4,
};
exports.copyDone = {
    name: 'copyDone',
    length: 4,
};
class DatabaseError extends Error {
    constructor(message, length, name) {
        super(message);
        this.length = length;
        this.name = name;
    }
}
exports.DatabaseError = DatabaseError;
class CopyDataMessage {
    constructor(length, chunk) {
        this.length = length;
        this.chunk = chunk;
        this.name = 'copyData';
    }
}
exports.CopyDataMessage = CopyDataMessage;
class CopyResponse {
    constructor(length, name, binary, columnCount) {
        this.length = length;
        this.name = name;
        this.binary = binary;
        this.columnTypes = new Array(columnCount);
    }
}
exports.CopyResponse = CopyResponse;
class Field {
    constructor(name, tableID, columnID, dataTypeID, dataTypeSize, dataTypeModifier, format) {
        this.name = name;
        this.tableID = tableID;
        this.columnID = columnID;
        this.dataTypeID = dataTypeID;
        this.dataTypeSize = dataTypeSize;
        this.dataTypeModifier = dataTypeModifier;
        this.format = format;
    }
}
exports.Field = Field;
class RowDescriptionMessage {
    constructor(length, fieldCount) {
        this.length = length;
        this.fieldCount = fieldCount;
        this.name = 'rowDescription';
        this.fields = new Array(this.fieldCount);
    }
}
exports.RowDescriptionMessage = RowDescriptionMessage;
class ParameterDescriptionMessage {
    constructor(length, parameterCount) {
        this.length = length;
        this.parameterCount = parameterCount;
        this.name = 'parameterDescription';
        this.dataTypeIDs = new Array(this.parameterCount);
    }
}
exports.ParameterDescriptionMessage = ParameterDescriptionMessage;
class ParameterStatusMessage {
    constructor(length, parameterName, parameterValue) {
        this.length = length;
        this.parameterName = parameterName;
        this.parameterValue = parameterValue;
        this.name = 'parameterStatus';
    }
}
exports.ParameterStatusMessage = ParameterStatusMessage;
class AuthenticationMD5Password {
    constructor(length, salt) {
        this.length = length;
        this.salt = salt;
        this.name = 'authenticationMD5Password';
    }
}
exports.AuthenticationMD5Password = AuthenticationMD5Password;
class BackendKeyDataMessage {
    constructor(length, processID, secretKey) {
        this.length = length;
        this.processID = processID;
        this.secretKey = secretKey;
        this.name = 'backendKeyData';
    }
}
exports.BackendKeyDataMessage = BackendKeyDataMessage;
class NotificationResponseMessage {
    constructor(length, processId, channel, payload) {
        this.length = length;
        this.processId = processId;
        this.channel = channel;
        this.payload = payload;
        this.name = 'notification';
    }
}
exports.NotificationResponseMessage = NotificationResponseMessage;
class ReadyForQueryMessage {
    constructor(length, status) {
        this.length = length;
        this.status = status;
        this.name = 'readyForQuery';
    }
}
exports.ReadyForQueryMessage = ReadyForQueryMessage;
class CommandCompleteMessage {
    constructor(length, text) {
        this.length = length;
        this.text = text;
        this.name = 'commandComplete';
    }
}
exports.CommandCompleteMessage = CommandCompleteMessage;
class DataRowMessage {
    constructor(length, fields) {
        this.length = length;
        this.fields = fields;
        this.name = 'dataRow';
        this.fieldCount = fields.length;
    }
}
exports.DataRowMessage = DataRowMessage;
class NoticeMessage {
    constructor(length, message) {
        this.length = length;
        this.message = message;
        this.name = 'notice';
    }
}
exports.NoticeMessage = NoticeMessage;
//# sourceMappingURL=messages.js.map

/***/ }),

/***/ 946:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Parser = void 0;
const messages_1 = __webpack_require__(2510);
const buffer_reader_1 = __webpack_require__(1144);
const assert_1 = __importDefault(__webpack_require__(2357));
// every message is prefixed with a single bye
const CODE_LENGTH = 1;
// every message has an int32 length which includes itself but does
// NOT include the code in the length
const LEN_LENGTH = 4;
const HEADER_LENGTH = CODE_LENGTH + LEN_LENGTH;
const emptyBuffer = Buffer.allocUnsafe(0);
class Parser {
    constructor(opts) {
        this.buffer = emptyBuffer;
        this.bufferLength = 0;
        this.bufferOffset = 0;
        this.reader = new buffer_reader_1.BufferReader();
        if ((opts === null || opts === void 0 ? void 0 : opts.mode) === 'binary') {
            throw new Error('Binary mode not supported yet');
        }
        this.mode = (opts === null || opts === void 0 ? void 0 : opts.mode) || 'text';
    }
    parse(buffer, callback) {
        this.mergeBuffer(buffer);
        const bufferFullLength = this.bufferOffset + this.bufferLength;
        let offset = this.bufferOffset;
        while (offset + HEADER_LENGTH <= bufferFullLength) {
            // code is 1 byte long - it identifies the message type
            const code = this.buffer[offset];
            // length is 1 Uint32BE - it is the length of the message EXCLUDING the code
            const length = this.buffer.readUInt32BE(offset + CODE_LENGTH);
            const fullMessageLength = CODE_LENGTH + length;
            if (fullMessageLength + offset <= bufferFullLength) {
                const message = this.handlePacket(offset + HEADER_LENGTH, code, length, this.buffer);
                callback(message);
                offset += fullMessageLength;
            }
            else {
                break;
            }
        }
        if (offset === bufferFullLength) {
            // No more use for the buffer
            this.buffer = emptyBuffer;
            this.bufferLength = 0;
            this.bufferOffset = 0;
        }
        else {
            // Adjust the cursors of remainingBuffer
            this.bufferLength = bufferFullLength - offset;
            this.bufferOffset = offset;
        }
    }
    mergeBuffer(buffer) {
        if (this.bufferLength > 0) {
            const newLength = this.bufferLength + buffer.byteLength;
            const newFullLength = newLength + this.bufferOffset;
            if (newFullLength > this.buffer.byteLength) {
                // We can't concat the new buffer with the remaining one
                let newBuffer;
                if (newLength <= this.buffer.byteLength && this.bufferOffset >= this.bufferLength) {
                    // We can move the relevant part to the beginning of the buffer instead of allocating a new buffer
                    newBuffer = this.buffer;
                }
                else {
                    // Allocate a new larger buffer
                    let newBufferLength = this.buffer.byteLength * 2;
                    while (newLength >= newBufferLength) {
                        newBufferLength *= 2;
                    }
                    newBuffer = Buffer.allocUnsafe(newBufferLength);
                }
                // Move the remaining buffer to the new one
                this.buffer.copy(newBuffer, 0, this.bufferOffset, this.bufferOffset + this.bufferLength);
                this.buffer = newBuffer;
                this.bufferOffset = 0;
            }
            // Concat the new buffer with the remaining one
            buffer.copy(this.buffer, this.bufferOffset + this.bufferLength);
            this.bufferLength = newLength;
        }
        else {
            this.buffer = buffer;
            this.bufferOffset = 0;
            this.bufferLength = buffer.byteLength;
        }
    }
    handlePacket(offset, code, length, bytes) {
        switch (code) {
            case 50 /* BindComplete */:
                return messages_1.bindComplete;
            case 49 /* ParseComplete */:
                return messages_1.parseComplete;
            case 51 /* CloseComplete */:
                return messages_1.closeComplete;
            case 110 /* NoData */:
                return messages_1.noData;
            case 115 /* PortalSuspended */:
                return messages_1.portalSuspended;
            case 99 /* CopyDone */:
                return messages_1.copyDone;
            case 87 /* ReplicationStart */:
                return messages_1.replicationStart;
            case 73 /* EmptyQuery */:
                return messages_1.emptyQuery;
            case 68 /* DataRow */:
                return this.parseDataRowMessage(offset, length, bytes);
            case 67 /* CommandComplete */:
                return this.parseCommandCompleteMessage(offset, length, bytes);
            case 90 /* ReadyForQuery */:
                return this.parseReadyForQueryMessage(offset, length, bytes);
            case 65 /* NotificationResponse */:
                return this.parseNotificationMessage(offset, length, bytes);
            case 82 /* AuthenticationResponse */:
                return this.parseAuthenticationResponse(offset, length, bytes);
            case 83 /* ParameterStatus */:
                return this.parseParameterStatusMessage(offset, length, bytes);
            case 75 /* BackendKeyData */:
                return this.parseBackendKeyData(offset, length, bytes);
            case 69 /* ErrorMessage */:
                return this.parseErrorMessage(offset, length, bytes, 'error');
            case 78 /* NoticeMessage */:
                return this.parseErrorMessage(offset, length, bytes, 'notice');
            case 84 /* RowDescriptionMessage */:
                return this.parseRowDescriptionMessage(offset, length, bytes);
            case 116 /* ParameterDescriptionMessage */:
                return this.parseParameterDescriptionMessage(offset, length, bytes);
            case 71 /* CopyIn */:
                return this.parseCopyInMessage(offset, length, bytes);
            case 72 /* CopyOut */:
                return this.parseCopyOutMessage(offset, length, bytes);
            case 100 /* CopyData */:
                return this.parseCopyData(offset, length, bytes);
            default:
                assert_1.default.fail(`unknown message code: ${code.toString(16)}`);
        }
    }
    parseReadyForQueryMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const status = this.reader.string(1);
        return new messages_1.ReadyForQueryMessage(length, status);
    }
    parseCommandCompleteMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const text = this.reader.cstring();
        return new messages_1.CommandCompleteMessage(length, text);
    }
    parseCopyData(offset, length, bytes) {
        const chunk = bytes.slice(offset, offset + (length - 4));
        return new messages_1.CopyDataMessage(length, chunk);
    }
    parseCopyInMessage(offset, length, bytes) {
        return this.parseCopyMessage(offset, length, bytes, 'copyInResponse');
    }
    parseCopyOutMessage(offset, length, bytes) {
        return this.parseCopyMessage(offset, length, bytes, 'copyOutResponse');
    }
    parseCopyMessage(offset, length, bytes, messageName) {
        this.reader.setBuffer(offset, bytes);
        const isBinary = this.reader.byte() !== 0;
        const columnCount = this.reader.int16();
        const message = new messages_1.CopyResponse(length, messageName, isBinary, columnCount);
        for (let i = 0; i < columnCount; i++) {
            message.columnTypes[i] = this.reader.int16();
        }
        return message;
    }
    parseNotificationMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const processId = this.reader.int32();
        const channel = this.reader.cstring();
        const payload = this.reader.cstring();
        return new messages_1.NotificationResponseMessage(length, processId, channel, payload);
    }
    parseRowDescriptionMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const fieldCount = this.reader.int16();
        const message = new messages_1.RowDescriptionMessage(length, fieldCount);
        for (let i = 0; i < fieldCount; i++) {
            message.fields[i] = this.parseField();
        }
        return message;
    }
    parseField() {
        const name = this.reader.cstring();
        const tableID = this.reader.int32();
        const columnID = this.reader.int16();
        const dataTypeID = this.reader.int32();
        const dataTypeSize = this.reader.int16();
        const dataTypeModifier = this.reader.int32();
        const mode = this.reader.int16() === 0 ? 'text' : 'binary';
        return new messages_1.Field(name, tableID, columnID, dataTypeID, dataTypeSize, dataTypeModifier, mode);
    }
    parseParameterDescriptionMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const parameterCount = this.reader.int16();
        const message = new messages_1.ParameterDescriptionMessage(length, parameterCount);
        for (let i = 0; i < parameterCount; i++) {
            message.dataTypeIDs[i] = this.reader.int32();
        }
        return message;
    }
    parseDataRowMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const fieldCount = this.reader.int16();
        const fields = new Array(fieldCount);
        for (let i = 0; i < fieldCount; i++) {
            const len = this.reader.int32();
            // a -1 for length means the value of the field is null
            fields[i] = len === -1 ? null : this.reader.string(len);
        }
        return new messages_1.DataRowMessage(length, fields);
    }
    parseParameterStatusMessage(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const name = this.reader.cstring();
        const value = this.reader.cstring();
        return new messages_1.ParameterStatusMessage(length, name, value);
    }
    parseBackendKeyData(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const processID = this.reader.int32();
        const secretKey = this.reader.int32();
        return new messages_1.BackendKeyDataMessage(length, processID, secretKey);
    }
    parseAuthenticationResponse(offset, length, bytes) {
        this.reader.setBuffer(offset, bytes);
        const code = this.reader.int32();
        // TODO(bmc): maybe better types here
        const message = {
            name: 'authenticationOk',
            length,
        };
        switch (code) {
            case 0: // AuthenticationOk
                break;
            case 3: // AuthenticationCleartextPassword
                if (message.length === 8) {
                    message.name = 'authenticationCleartextPassword';
                }
                break;
            case 5: // AuthenticationMD5Password
                if (message.length === 12) {
                    message.name = 'authenticationMD5Password';
                    const salt = this.reader.bytes(4);
                    return new messages_1.AuthenticationMD5Password(length, salt);
                }
                break;
            case 10: // AuthenticationSASL
                message.name = 'authenticationSASL';
                message.mechanisms = [];
                let mechanism;
                do {
                    mechanism = this.reader.cstring();
                    if (mechanism) {
                        message.mechanisms.push(mechanism);
                    }
                } while (mechanism);
                break;
            case 11: // AuthenticationSASLContinue
                message.name = 'authenticationSASLContinue';
                message.data = this.reader.string(length - 8);
                break;
            case 12: // AuthenticationSASLFinal
                message.name = 'authenticationSASLFinal';
                message.data = this.reader.string(length - 8);
                break;
            default:
                throw new Error('Unknown authenticationOk message type ' + code);
        }
        return message;
    }
    parseErrorMessage(offset, length, bytes, name) {
        this.reader.setBuffer(offset, bytes);
        const fields = {};
        let fieldType = this.reader.string(1);
        while (fieldType !== '\0') {
            fields[fieldType] = this.reader.cstring();
            fieldType = this.reader.string(1);
        }
        const messageValue = fields.M;
        const message = name === 'notice' ? new messages_1.NoticeMessage(length, messageValue) : new messages_1.DatabaseError(messageValue, length, name);
        message.severity = fields.S;
        message.code = fields.C;
        message.detail = fields.D;
        message.hint = fields.H;
        message.position = fields.P;
        message.internalPosition = fields.p;
        message.internalQuery = fields.q;
        message.where = fields.W;
        message.schema = fields.s;
        message.table = fields.t;
        message.column = fields.c;
        message.dataType = fields.d;
        message.constraint = fields.n;
        message.file = fields.F;
        message.line = fields.L;
        message.routine = fields.R;
        return message;
    }
}
exports.Parser = Parser;
//# sourceMappingURL=parser.js.map

/***/ }),

/***/ 9209:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.serialize = void 0;
const buffer_writer_1 = __webpack_require__(246);
const writer = new buffer_writer_1.Writer();
const startup = (opts) => {
    // protocol version
    writer.addInt16(3).addInt16(0);
    for (const key of Object.keys(opts)) {
        writer.addCString(key).addCString(opts[key]);
    }
    writer.addCString('client_encoding').addCString('UTF8');
    var bodyBuffer = writer.addCString('').flush();
    // this message is sent without a code
    var length = bodyBuffer.length + 4;
    return new buffer_writer_1.Writer().addInt32(length).add(bodyBuffer).flush();
};
const requestSsl = () => {
    const response = Buffer.allocUnsafe(8);
    response.writeInt32BE(8, 0);
    response.writeInt32BE(80877103, 4);
    return response;
};
const password = (password) => {
    return writer.addCString(password).flush(112 /* startup */);
};
const sendSASLInitialResponseMessage = function (mechanism, initialResponse) {
    // 0x70 = 'p'
    writer.addCString(mechanism).addInt32(Buffer.byteLength(initialResponse)).addString(initialResponse);
    return writer.flush(112 /* startup */);
};
const sendSCRAMClientFinalMessage = function (additionalData) {
    return writer.addString(additionalData).flush(112 /* startup */);
};
const query = (text) => {
    return writer.addCString(text).flush(81 /* query */);
};
const emptyArray = [];
const parse = (query) => {
    // expect something like this:
    // { name: 'queryName',
    //   text: 'select * from blah',
    //   types: ['int8', 'bool'] }
    // normalize missing query names to allow for null
    const name = query.name || '';
    if (name.length > 63) {
        /* eslint-disable no-console */
        console.error('Warning! Postgres only supports 63 characters for query names.');
        console.error('You supplied %s (%s)', name, name.length);
        console.error('This can cause conflicts and silent errors executing queries');
        /* eslint-enable no-console */
    }
    const types = query.types || emptyArray;
    var len = types.length;
    var buffer = writer
        .addCString(name) // name of query
        .addCString(query.text) // actual query text
        .addInt16(len);
    for (var i = 0; i < len; i++) {
        buffer.addInt32(types[i]);
    }
    return writer.flush(80 /* parse */);
};
const paramWriter = new buffer_writer_1.Writer();
const writeValues = function (values, valueMapper) {
    for (let i = 0; i < values.length; i++) {
        const mappedVal = valueMapper ? valueMapper(values[i], i) : values[i];
        if (mappedVal == null) {
            // add the param type (string) to the writer
            writer.addInt16(0 /* STRING */);
            // write -1 to the param writer to indicate null
            paramWriter.addInt32(-1);
        }
        else if (mappedVal instanceof Buffer) {
            // add the param type (binary) to the writer
            writer.addInt16(1 /* BINARY */);
            // add the buffer to the param writer
            paramWriter.addInt32(mappedVal.length);
            paramWriter.add(mappedVal);
        }
        else {
            // add the param type (string) to the writer
            writer.addInt16(0 /* STRING */);
            paramWriter.addInt32(Buffer.byteLength(mappedVal));
            paramWriter.addString(mappedVal);
        }
    }
};
const bind = (config = {}) => {
    // normalize config
    const portal = config.portal || '';
    const statement = config.statement || '';
    const binary = config.binary || false;
    const values = config.values || emptyArray;
    const len = values.length;
    writer.addCString(portal).addCString(statement);
    writer.addInt16(len);
    writeValues(values, config.valueMapper);
    writer.addInt16(len);
    writer.add(paramWriter.flush());
    // format code
    writer.addInt16(binary ? 1 /* BINARY */ : 0 /* STRING */);
    return writer.flush(66 /* bind */);
};
const emptyExecute = Buffer.from([69 /* execute */, 0x00, 0x00, 0x00, 0x09, 0x00, 0x00, 0x00, 0x00, 0x00]);
const execute = (config) => {
    // this is the happy path for most queries
    if (!config || (!config.portal && !config.rows)) {
        return emptyExecute;
    }
    const portal = config.portal || '';
    const rows = config.rows || 0;
    const portalLength = Buffer.byteLength(portal);
    const len = 4 + portalLength + 1 + 4;
    // one extra bit for code
    const buff = Buffer.allocUnsafe(1 + len);
    buff[0] = 69 /* execute */;
    buff.writeInt32BE(len, 1);
    buff.write(portal, 5, 'utf-8');
    buff[portalLength + 5] = 0; // null terminate portal cString
    buff.writeUInt32BE(rows, buff.length - 4);
    return buff;
};
const cancel = (processID, secretKey) => {
    const buffer = Buffer.allocUnsafe(16);
    buffer.writeInt32BE(16, 0);
    buffer.writeInt16BE(1234, 4);
    buffer.writeInt16BE(5678, 6);
    buffer.writeInt32BE(processID, 8);
    buffer.writeInt32BE(secretKey, 12);
    return buffer;
};
const cstringMessage = (code, string) => {
    const stringLen = Buffer.byteLength(string);
    const len = 4 + stringLen + 1;
    // one extra bit for code
    const buffer = Buffer.allocUnsafe(1 + len);
    buffer[0] = code;
    buffer.writeInt32BE(len, 1);
    buffer.write(string, 5, 'utf-8');
    buffer[len] = 0; // null terminate cString
    return buffer;
};
const emptyDescribePortal = writer.addCString('P').flush(68 /* describe */);
const emptyDescribeStatement = writer.addCString('S').flush(68 /* describe */);
const describe = (msg) => {
    return msg.name
        ? cstringMessage(68 /* describe */, `${msg.type}${msg.name || ''}`)
        : msg.type === 'P'
            ? emptyDescribePortal
            : emptyDescribeStatement;
};
const close = (msg) => {
    const text = `${msg.type}${msg.name || ''}`;
    return cstringMessage(67 /* close */, text);
};
const copyData = (chunk) => {
    return writer.add(chunk).flush(100 /* copyFromChunk */);
};
const copyFail = (message) => {
    return cstringMessage(102 /* copyFail */, message);
};
const codeOnlyBuffer = (code) => Buffer.from([code, 0x00, 0x00, 0x00, 0x04]);
const flushBuffer = codeOnlyBuffer(72 /* flush */);
const syncBuffer = codeOnlyBuffer(83 /* sync */);
const endBuffer = codeOnlyBuffer(88 /* end */);
const copyDoneBuffer = codeOnlyBuffer(99 /* copyDone */);
const serialize = {
    startup,
    password,
    requestSsl,
    sendSASLInitialResponseMessage,
    sendSCRAMClientFinalMessage,
    query,
    parse,
    bind,
    execute,
    describe,
    close,
    flush: () => flushBuffer,
    sync: () => syncBuffer,
    end: () => endBuffer,
    copyData,
    copyDone: () => copyDoneBuffer,
    copyFail,
    cancel,
};
exports.serialize = serialize;
//# sourceMappingURL=serializer.js.map

/***/ }),

/***/ 3619:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var textParsers = __webpack_require__(2980);
var binaryParsers = __webpack_require__(1931);
var arrayParser = __webpack_require__(6169);
var builtinTypes = __webpack_require__(8078);

exports.getTypeParser = getTypeParser;
exports.setTypeParser = setTypeParser;
exports.arrayParser = arrayParser;
exports.builtins = builtinTypes;

var typeParsers = {
  text: {},
  binary: {}
};

//the empty parse function
function noParse (val) {
  return String(val);
};

//returns a function used to convert a specific type (specified by
//oid) into a result javascript type
//note: the oid can be obtained via the following sql query:
//SELECT oid FROM pg_type WHERE typname = 'TYPE_NAME_HERE';
function getTypeParser (oid, format) {
  format = format || 'text';
  if (!typeParsers[format]) {
    return noParse;
  }
  return typeParsers[format][oid] || noParse;
};

function setTypeParser (oid, format, parseFn) {
  if(typeof format == 'function') {
    parseFn = format;
    format = 'text';
  }
  typeParsers[format][oid] = parseFn;
};

textParsers.init(function(oid, converter) {
  typeParsers.text[oid] = converter;
});

binaryParsers.init(function(oid, converter) {
  typeParsers.binary[oid] = converter;
});


/***/ }),

/***/ 6169:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var array = __webpack_require__(7315);

module.exports = {
  create: function (source, transform) {
    return {
      parse: function() {
        return array.parse(source, transform);
      }
    };
  }
};


/***/ }),

/***/ 1931:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var parseInt64 = __webpack_require__(6064);

var parseBits = function(data, bits, offset, invert, callback) {
  offset = offset || 0;
  invert = invert || false;
  callback = callback || function(lastValue, newValue, bits) { return (lastValue * Math.pow(2, bits)) + newValue; };
  var offsetBytes = offset >> 3;

  var inv = function(value) {
    if (invert) {
      return ~value & 0xff;
    }

    return value;
  };

  // read first (maybe partial) byte
  var mask = 0xff;
  var firstBits = 8 - (offset % 8);
  if (bits < firstBits) {
    mask = (0xff << (8 - bits)) & 0xff;
    firstBits = bits;
  }

  if (offset) {
    mask = mask >> (offset % 8);
  }

  var result = 0;
  if ((offset % 8) + bits >= 8) {
    result = callback(0, inv(data[offsetBytes]) & mask, firstBits);
  }

  // read bytes
  var bytes = (bits + offset) >> 3;
  for (var i = offsetBytes + 1; i < bytes; i++) {
    result = callback(result, inv(data[i]), 8);
  }

  // bits to read, that are not a complete byte
  var lastBits = (bits + offset) % 8;
  if (lastBits > 0) {
    result = callback(result, inv(data[bytes]) >> (8 - lastBits), lastBits);
  }

  return result;
};

var parseFloatFromBits = function(data, precisionBits, exponentBits) {
  var bias = Math.pow(2, exponentBits - 1) - 1;
  var sign = parseBits(data, 1);
  var exponent = parseBits(data, exponentBits, 1);

  if (exponent === 0) {
    return 0;
  }

  // parse mantissa
  var precisionBitsCounter = 1;
  var parsePrecisionBits = function(lastValue, newValue, bits) {
    if (lastValue === 0) {
      lastValue = 1;
    }

    for (var i = 1; i <= bits; i++) {
      precisionBitsCounter /= 2;
      if ((newValue & (0x1 << (bits - i))) > 0) {
        lastValue += precisionBitsCounter;
      }
    }

    return lastValue;
  };

  var mantissa = parseBits(data, precisionBits, exponentBits + 1, false, parsePrecisionBits);

  // special cases
  if (exponent == (Math.pow(2, exponentBits + 1) - 1)) {
    if (mantissa === 0) {
      return (sign === 0) ? Infinity : -Infinity;
    }

    return NaN;
  }

  // normale number
  return ((sign === 0) ? 1 : -1) * Math.pow(2, exponent - bias) * mantissa;
};

var parseInt16 = function(value) {
  if (parseBits(value, 1) == 1) {
    return -1 * (parseBits(value, 15, 1, true) + 1);
  }

  return parseBits(value, 15, 1);
};

var parseInt32 = function(value) {
  if (parseBits(value, 1) == 1) {
    return -1 * (parseBits(value, 31, 1, true) + 1);
  }

  return parseBits(value, 31, 1);
};

var parseFloat32 = function(value) {
  return parseFloatFromBits(value, 23, 8);
};

var parseFloat64 = function(value) {
  return parseFloatFromBits(value, 52, 11);
};

var parseNumeric = function(value) {
  var sign = parseBits(value, 16, 32);
  if (sign == 0xc000) {
    return NaN;
  }

  var weight = Math.pow(10000, parseBits(value, 16, 16));
  var result = 0;

  var digits = [];
  var ndigits = parseBits(value, 16);
  for (var i = 0; i < ndigits; i++) {
    result += parseBits(value, 16, 64 + (16 * i)) * weight;
    weight /= 10000;
  }

  var scale = Math.pow(10, parseBits(value, 16, 48));
  return ((sign === 0) ? 1 : -1) * Math.round(result * scale) / scale;
};

var parseDate = function(isUTC, value) {
  var sign = parseBits(value, 1);
  var rawValue = parseBits(value, 63, 1);

  // discard usecs and shift from 2000 to 1970
  var result = new Date((((sign === 0) ? 1 : -1) * rawValue / 1000) + 946684800000);

  if (!isUTC) {
    result.setTime(result.getTime() + result.getTimezoneOffset() * 60000);
  }

  // add microseconds to the date
  result.usec = rawValue % 1000;
  result.getMicroSeconds = function() {
    return this.usec;
  };
  result.setMicroSeconds = function(value) {
    this.usec = value;
  };
  result.getUTCMicroSeconds = function() {
    return this.usec;
  };

  return result;
};

var parseArray = function(value) {
  var dim = parseBits(value, 32);

  var flags = parseBits(value, 32, 32);
  var elementType = parseBits(value, 32, 64);

  var offset = 96;
  var dims = [];
  for (var i = 0; i < dim; i++) {
    // parse dimension
    dims[i] = parseBits(value, 32, offset);
    offset += 32;

    // ignore lower bounds
    offset += 32;
  }

  var parseElement = function(elementType) {
    // parse content length
    var length = parseBits(value, 32, offset);
    offset += 32;

    // parse null values
    if (length == 0xffffffff) {
      return null;
    }

    var result;
    if ((elementType == 0x17) || (elementType == 0x14)) {
      // int/bigint
      result = parseBits(value, length * 8, offset);
      offset += length * 8;
      return result;
    }
    else if (elementType == 0x19) {
      // string
      result = value.toString(this.encoding, offset >> 3, (offset += (length << 3)) >> 3);
      return result;
    }
    else {
      console.log("ERROR: ElementType not implemented: " + elementType);
    }
  };

  var parse = function(dimension, elementType) {
    var array = [];
    var i;

    if (dimension.length > 1) {
      var count = dimension.shift();
      for (i = 0; i < count; i++) {
        array[i] = parse(dimension, elementType);
      }
      dimension.unshift(count);
    }
    else {
      for (i = 0; i < dimension[0]; i++) {
        array[i] = parseElement(elementType);
      }
    }

    return array;
  };

  return parse(dims, elementType);
};

var parseText = function(value) {
  return value.toString('utf8');
};

var parseBool = function(value) {
  if(value === null) return null;
  return (parseBits(value, 8) > 0);
};

var init = function(register) {
  register(20, parseInt64);
  register(21, parseInt16);
  register(23, parseInt32);
  register(26, parseInt32);
  register(1700, parseNumeric);
  register(700, parseFloat32);
  register(701, parseFloat64);
  register(16, parseBool);
  register(1114, parseDate.bind(null, false));
  register(1184, parseDate.bind(null, true));
  register(1000, parseArray);
  register(1007, parseArray);
  register(1016, parseArray);
  register(1008, parseArray);
  register(1009, parseArray);
  register(25, parseText);
};

module.exports = {
  init: init
};


/***/ }),

/***/ 8078:
/***/ ((module) => {

/**
 * Following query was used to generate this file:

 SELECT json_object_agg(UPPER(PT.typname), PT.oid::int4 ORDER BY pt.oid)
 FROM pg_type PT
 WHERE typnamespace = (SELECT pgn.oid FROM pg_namespace pgn WHERE nspname = 'pg_catalog') -- Take only builting Postgres types with stable OID (extension types are not guaranted to be stable)
 AND typtype = 'b' -- Only basic types
 AND typelem = 0 -- Ignore aliases
 AND typisdefined -- Ignore undefined types
 */

module.exports = {
    BOOL: 16,
    BYTEA: 17,
    CHAR: 18,
    INT8: 20,
    INT2: 21,
    INT4: 23,
    REGPROC: 24,
    TEXT: 25,
    OID: 26,
    TID: 27,
    XID: 28,
    CID: 29,
    JSON: 114,
    XML: 142,
    PG_NODE_TREE: 194,
    SMGR: 210,
    PATH: 602,
    POLYGON: 604,
    CIDR: 650,
    FLOAT4: 700,
    FLOAT8: 701,
    ABSTIME: 702,
    RELTIME: 703,
    TINTERVAL: 704,
    CIRCLE: 718,
    MACADDR8: 774,
    MONEY: 790,
    MACADDR: 829,
    INET: 869,
    ACLITEM: 1033,
    BPCHAR: 1042,
    VARCHAR: 1043,
    DATE: 1082,
    TIME: 1083,
    TIMESTAMP: 1114,
    TIMESTAMPTZ: 1184,
    INTERVAL: 1186,
    TIMETZ: 1266,
    BIT: 1560,
    VARBIT: 1562,
    NUMERIC: 1700,
    REFCURSOR: 1790,
    REGPROCEDURE: 2202,
    REGOPER: 2203,
    REGOPERATOR: 2204,
    REGCLASS: 2205,
    REGTYPE: 2206,
    UUID: 2950,
    TXID_SNAPSHOT: 2970,
    PG_LSN: 3220,
    PG_NDISTINCT: 3361,
    PG_DEPENDENCIES: 3402,
    TSVECTOR: 3614,
    TSQUERY: 3615,
    GTSVECTOR: 3642,
    REGCONFIG: 3734,
    REGDICTIONARY: 3769,
    JSONB: 3802,
    REGNAMESPACE: 4089,
    REGROLE: 4096
};


/***/ }),

/***/ 2980:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var array = __webpack_require__(7315)
var arrayParser = __webpack_require__(6169);
var parseDate = __webpack_require__(3765);
var parseInterval = __webpack_require__(1055);
var parseByteA = __webpack_require__(3712);

function allowNull (fn) {
  return function nullAllowed (value) {
    if (value === null) return value
    return fn(value)
  }
}

function parseBool (value) {
  if (value === null) return value
  return value === 'TRUE' ||
    value === 't' ||
    value === 'true' ||
    value === 'y' ||
    value === 'yes' ||
    value === 'on' ||
    value === '1';
}

function parseBoolArray (value) {
  if (!value) return null
  return array.parse(value, parseBool)
}

function parseBaseTenInt (string) {
  return parseInt(string, 10)
}

function parseIntegerArray (value) {
  if (!value) return null
  return array.parse(value, allowNull(parseBaseTenInt))
}

function parseBigIntegerArray (value) {
  if (!value) return null
  return array.parse(value, allowNull(function (entry) {
    return parseBigInteger(entry).trim()
  }))
}

var parsePointArray = function(value) {
  if(!value) { return null; }
  var p = arrayParser.create(value, function(entry) {
    if(entry !== null) {
      entry = parsePoint(entry);
    }
    return entry;
  });

  return p.parse();
};

var parseFloatArray = function(value) {
  if(!value) { return null; }
  var p = arrayParser.create(value, function(entry) {
    if(entry !== null) {
      entry = parseFloat(entry);
    }
    return entry;
  });

  return p.parse();
};

var parseStringArray = function(value) {
  if(!value) { return null; }

  var p = arrayParser.create(value);
  return p.parse();
};

var parseDateArray = function(value) {
  if (!value) { return null; }

  var p = arrayParser.create(value, function(entry) {
    if (entry !== null) {
      entry = parseDate(entry);
    }
    return entry;
  });

  return p.parse();
};

var parseIntervalArray = function(value) {
  if (!value) { return null; }

  var p = arrayParser.create(value, function(entry) {
    if (entry !== null) {
      entry = parseInterval(entry);
    }
    return entry;
  });

  return p.parse();
};

var parseByteAArray = function(value) {
  if (!value) { return null; }

  return array.parse(value, allowNull(parseByteA));
};

var parseInteger = function(value) {
  return parseInt(value, 10);
};

var parseBigInteger = function(value) {
  var valStr = String(value);
  if (/^\d+$/.test(valStr)) { return valStr; }
  return value;
};

var parseJsonArray = function(value) {
  if (!value) { return null; }

  return array.parse(value, allowNull(JSON.parse));
};

var parsePoint = function(value) {
  if (value[0] !== '(') { return null; }

  value = value.substring( 1, value.length - 1 ).split(',');

  return {
    x: parseFloat(value[0])
  , y: parseFloat(value[1])
  };
};

var parseCircle = function(value) {
  if (value[0] !== '<' && value[1] !== '(') { return null; }

  var point = '(';
  var radius = '';
  var pointParsed = false;
  for (var i = 2; i < value.length - 1; i++){
    if (!pointParsed) {
      point += value[i];
    }

    if (value[i] === ')') {
      pointParsed = true;
      continue;
    } else if (!pointParsed) {
      continue;
    }

    if (value[i] === ','){
      continue;
    }

    radius += value[i];
  }
  var result = parsePoint(point);
  result.radius = parseFloat(radius);

  return result;
};

var init = function(register) {
  register(20, parseBigInteger); // int8
  register(21, parseInteger); // int2
  register(23, parseInteger); // int4
  register(26, parseInteger); // oid
  register(700, parseFloat); // float4/real
  register(701, parseFloat); // float8/double
  register(16, parseBool);
  register(1082, parseDate); // date
  register(1114, parseDate); // timestamp without timezone
  register(1184, parseDate); // timestamp
  register(600, parsePoint); // point
  register(651, parseStringArray); // cidr[]
  register(718, parseCircle); // circle
  register(1000, parseBoolArray);
  register(1001, parseByteAArray);
  register(1005, parseIntegerArray); // _int2
  register(1007, parseIntegerArray); // _int4
  register(1028, parseIntegerArray); // oid[]
  register(1016, parseBigIntegerArray); // _int8
  register(1017, parsePointArray); // point[]
  register(1021, parseFloatArray); // _float4
  register(1022, parseFloatArray); // _float8
  register(1231, parseFloatArray); // _numeric
  register(1014, parseStringArray); //char
  register(1015, parseStringArray); //varchar
  register(1008, parseStringArray);
  register(1009, parseStringArray);
  register(1040, parseStringArray); // macaddr[]
  register(1041, parseStringArray); // inet[]
  register(1115, parseDateArray); // timestamp without time zone[]
  register(1182, parseDateArray); // _date
  register(1185, parseDateArray); // timestamp with time zone[]
  register(1186, parseInterval);
  register(1187, parseIntervalArray);
  register(17, parseByteA);
  register(114, JSON.parse.bind(JSON)); // json
  register(3802, JSON.parse.bind(JSON)); // jsonb
  register(199, parseJsonArray); // json[]
  register(3807, parseJsonArray); // jsonb[]
  register(3907, parseStringArray); // numrange[]
  register(2951, parseStringArray); // uuid[]
  register(791, parseStringArray); // money[]
  register(1183, parseStringArray); // time[]
  register(1270, parseStringArray); // timetz[]
};

module.exports = {
  init: init
};


/***/ }),

/***/ 7442:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var EventEmitter = __webpack_require__(8614).EventEmitter
var util = __webpack_require__(1669)
var utils = __webpack_require__(1262)
var sasl = __webpack_require__(4615)
var pgPass = __webpack_require__(8812)
var TypeOverrides = __webpack_require__(5701)

var ConnectionParameters = __webpack_require__(8048)
var Query = __webpack_require__(1134)
var defaults = __webpack_require__(7433)
var Connection = __webpack_require__(1964)

class Client extends EventEmitter {
  constructor(config) {
    super()

    this.connectionParameters = new ConnectionParameters(config)
    this.user = this.connectionParameters.user
    this.database = this.connectionParameters.database
    this.port = this.connectionParameters.port
    this.host = this.connectionParameters.host

    // "hiding" the password so it doesn't show up in stack traces
    // or if the client is console.logged
    Object.defineProperty(this, 'password', {
      configurable: true,
      enumerable: false,
      writable: true,
      value: this.connectionParameters.password,
    })

    this.replication = this.connectionParameters.replication

    var c = config || {}

    this._Promise = c.Promise || global.Promise
    this._types = new TypeOverrides(c.types)
    this._ending = false
    this._connecting = false
    this._connected = false
    this._connectionError = false
    this._queryable = true

    this.connection =
      c.connection ||
      new Connection({
        stream: c.stream,
        ssl: this.connectionParameters.ssl,
        keepAlive: c.keepAlive || false,
        keepAliveInitialDelayMillis: c.keepAliveInitialDelayMillis || 0,
        encoding: this.connectionParameters.client_encoding || 'utf8',
      })
    this.queryQueue = []
    this.binary = c.binary || defaults.binary
    this.processID = null
    this.secretKey = null
    this.ssl = this.connectionParameters.ssl || false
    // As with Password, make SSL->Key (the private key) non-enumerable.
    // It won't show up in stack traces
    // or if the client is console.logged
    if (this.ssl && this.ssl.key) {
      Object.defineProperty(this.ssl, 'key', {
        enumerable: false,
      })
    }

    this._connectionTimeoutMillis = c.connectionTimeoutMillis || 0
  }

  _errorAllQueries(err) {
    const enqueueError = (query) => {
      process.nextTick(() => {
        query.handleError(err, this.connection)
      })
    }

    if (this.activeQuery) {
      enqueueError(this.activeQuery)
      this.activeQuery = null
    }

    this.queryQueue.forEach(enqueueError)
    this.queryQueue.length = 0
  }

  _connect(callback) {
    var self = this
    var con = this.connection
    this._connectionCallback = callback

    if (this._connecting || this._connected) {
      const err = new Error('Client has already been connected. You cannot reuse a client.')
      process.nextTick(() => {
        callback(err)
      })
      return
    }
    this._connecting = true

    this.connectionTimeoutHandle
    if (this._connectionTimeoutMillis > 0) {
      this.connectionTimeoutHandle = setTimeout(() => {
        con._ending = true
        con.stream.destroy(new Error('timeout expired'))
      }, this._connectionTimeoutMillis)
    }

    if (this.host && this.host.indexOf('/') === 0) {
      con.connect(this.host + '/.s.PGSQL.' + this.port)
    } else {
      con.connect(this.port, this.host)
    }

    // once connection is established send startup message
    con.on('connect', function () {
      if (self.ssl) {
        con.requestSsl()
      } else {
        con.startup(self.getStartupConf())
      }
    })

    con.on('sslconnect', function () {
      con.startup(self.getStartupConf())
    })

    this._attachListeners(con)

    con.once('end', () => {
      const error = this._ending ? new Error('Connection terminated') : new Error('Connection terminated unexpectedly')

      clearTimeout(this.connectionTimeoutHandle)
      this._errorAllQueries(error)

      if (!this._ending) {
        // if the connection is ended without us calling .end()
        // on this client then we have an unexpected disconnection
        // treat this as an error unless we've already emitted an error
        // during connection.
        if (this._connecting && !this._connectionError) {
          if (this._connectionCallback) {
            this._connectionCallback(error)
          } else {
            this._handleErrorEvent(error)
          }
        } else if (!this._connectionError) {
          this._handleErrorEvent(error)
        }
      }

      process.nextTick(() => {
        this.emit('end')
      })
    })
  }

  connect(callback) {
    if (callback) {
      this._connect(callback)
      return
    }

    return new this._Promise((resolve, reject) => {
      this._connect((error) => {
        if (error) {
          reject(error)
        } else {
          resolve()
        }
      })
    })
  }

  _attachListeners(con) {
    // password request handling
    con.on('authenticationCleartextPassword', this._handleAuthCleartextPassword.bind(this))
    // password request handling
    con.on('authenticationMD5Password', this._handleAuthMD5Password.bind(this))
    // password request handling (SASL)
    con.on('authenticationSASL', this._handleAuthSASL.bind(this))
    con.on('authenticationSASLContinue', this._handleAuthSASLContinue.bind(this))
    con.on('authenticationSASLFinal', this._handleAuthSASLFinal.bind(this))
    con.on('backendKeyData', this._handleBackendKeyData.bind(this))
    con.on('error', this._handleErrorEvent.bind(this))
    con.on('errorMessage', this._handleErrorMessage.bind(this))
    con.on('readyForQuery', this._handleReadyForQuery.bind(this))
    con.on('notice', this._handleNotice.bind(this))
    con.on('rowDescription', this._handleRowDescription.bind(this))
    con.on('dataRow', this._handleDataRow.bind(this))
    con.on('portalSuspended', this._handlePortalSuspended.bind(this))
    con.on('emptyQuery', this._handleEmptyQuery.bind(this))
    con.on('commandComplete', this._handleCommandComplete.bind(this))
    con.on('parseComplete', this._handleParseComplete.bind(this))
    con.on('copyInResponse', this._handleCopyInResponse.bind(this))
    con.on('copyData', this._handleCopyData.bind(this))
    con.on('notification', this._handleNotification.bind(this))
  }

  // TODO(bmc): deprecate pgpass "built in" integration since this.password can be a function
  // it can be supplied by the user if required - this is a breaking change!
  _checkPgPass(cb) {
    const con = this.connection
    if (typeof this.password === 'function') {
      this._Promise
        .resolve()
        .then(() => this.password())
        .then((pass) => {
          if (pass !== undefined) {
            if (typeof pass !== 'string') {
              con.emit('error', new TypeError('Password must be a string'))
              return
            }
            this.connectionParameters.password = this.password = pass
          } else {
            this.connectionParameters.password = this.password = null
          }
          cb()
        })
        .catch((err) => {
          con.emit('error', err)
        })
    } else if (this.password !== null) {
      cb()
    } else {
      pgPass(this.connectionParameters, (pass) => {
        if (undefined !== pass) {
          this.connectionParameters.password = this.password = pass
        }
        cb()
      })
    }
  }

  _handleAuthCleartextPassword(msg) {
    this._checkPgPass(() => {
      this.connection.password(this.password)
    })
  }

  _handleAuthMD5Password(msg) {
    this._checkPgPass(() => {
      const hashedPassword = utils.postgresMd5PasswordHash(this.user, this.password, msg.salt)
      this.connection.password(hashedPassword)
    })
  }

  _handleAuthSASL(msg) {
    this._checkPgPass(() => {
      this.saslSession = sasl.startSession(msg.mechanisms)
      this.connection.sendSASLInitialResponseMessage(this.saslSession.mechanism, this.saslSession.response)
    })
  }

  _handleAuthSASLContinue(msg) {
    sasl.continueSession(this.saslSession, this.password, msg.data)
    this.connection.sendSCRAMClientFinalMessage(this.saslSession.response)
  }

  _handleAuthSASLFinal(msg) {
    sasl.finalizeSession(this.saslSession, msg.data)
    this.saslSession = null
  }

  _handleBackendKeyData(msg) {
    this.processID = msg.processID
    this.secretKey = msg.secretKey
  }

  _handleReadyForQuery(msg) {
    if (this._connecting) {
      this._connecting = false
      this._connected = true
      clearTimeout(this.connectionTimeoutHandle)

      // process possible callback argument to Client#connect
      if (this._connectionCallback) {
        this._connectionCallback(null, this)
        // remove callback for proper error handling
        // after the connect event
        this._connectionCallback = null
      }
      this.emit('connect')
    }
    const { activeQuery } = this
    this.activeQuery = null
    this.readyForQuery = true
    if (activeQuery) {
      activeQuery.handleReadyForQuery(this.connection)
    }
    this._pulseQueryQueue()
  }

  // if we receieve an error event or error message
  // during the connection process we handle it here
  _handleErrorWhileConnecting(err) {
    if (this._connectionError) {
      // TODO(bmc): this is swallowing errors - we shouldn't do this
      return
    }
    this._connectionError = true
    clearTimeout(this.connectionTimeoutHandle)
    if (this._connectionCallback) {
      return this._connectionCallback(err)
    }
    this.emit('error', err)
  }

  // if we're connected and we receive an error event from the connection
  // this means the socket is dead - do a hard abort of all queries and emit
  // the socket error on the client as well
  _handleErrorEvent(err) {
    if (this._connecting) {
      return this._handleErrorWhileConnecting(err)
    }
    this._queryable = false
    this._errorAllQueries(err)
    this.emit('error', err)
  }

  // handle error messages from the postgres backend
  _handleErrorMessage(msg) {
    if (this._connecting) {
      return this._handleErrorWhileConnecting(msg)
    }
    const activeQuery = this.activeQuery

    if (!activeQuery) {
      this._handleErrorEvent(msg)
      return
    }

    this.activeQuery = null
    activeQuery.handleError(msg, this.connection)
  }

  _handleRowDescription(msg) {
    // delegate rowDescription to active query
    this.activeQuery.handleRowDescription(msg)
  }

  _handleDataRow(msg) {
    // delegate dataRow to active query
    this.activeQuery.handleDataRow(msg)
  }

  _handlePortalSuspended(msg) {
    // delegate portalSuspended to active query
    this.activeQuery.handlePortalSuspended(this.connection)
  }

  _handleEmptyQuery(msg) {
    // delegate emptyQuery to active query
    this.activeQuery.handleEmptyQuery(this.connection)
  }

  _handleCommandComplete(msg) {
    // delegate commandComplete to active query
    this.activeQuery.handleCommandComplete(msg, this.connection)
  }

  _handleParseComplete(msg) {
    // if a prepared statement has a name and properly parses
    // we track that its already been executed so we don't parse
    // it again on the same client
    if (this.activeQuery.name) {
      this.connection.parsedStatements[this.activeQuery.name] = this.activeQuery.text
    }
  }

  _handleCopyInResponse(msg) {
    this.activeQuery.handleCopyInResponse(this.connection)
  }

  _handleCopyData(msg) {
    this.activeQuery.handleCopyData(msg, this.connection)
  }

  _handleNotification(msg) {
    this.emit('notification', msg)
  }

  _handleNotice(msg) {
    this.emit('notice', msg)
  }

  getStartupConf() {
    var params = this.connectionParameters

    var data = {
      user: params.user,
      database: params.database,
    }

    var appName = params.application_name || params.fallback_application_name
    if (appName) {
      data.application_name = appName
    }
    if (params.replication) {
      data.replication = '' + params.replication
    }
    if (params.statement_timeout) {
      data.statement_timeout = String(parseInt(params.statement_timeout, 10))
    }
    if (params.idle_in_transaction_session_timeout) {
      data.idle_in_transaction_session_timeout = String(parseInt(params.idle_in_transaction_session_timeout, 10))
    }
    if (params.options) {
      data.options = params.options
    }

    return data
  }

  cancel(client, query) {
    if (client.activeQuery === query) {
      var con = this.connection

      if (this.host && this.host.indexOf('/') === 0) {
        con.connect(this.host + '/.s.PGSQL.' + this.port)
      } else {
        con.connect(this.port, this.host)
      }

      // once connection is established send cancel message
      con.on('connect', function () {
        con.cancel(client.processID, client.secretKey)
      })
    } else if (client.queryQueue.indexOf(query) !== -1) {
      client.queryQueue.splice(client.queryQueue.indexOf(query), 1)
    }
  }

  setTypeParser(oid, format, parseFn) {
    return this._types.setTypeParser(oid, format, parseFn)
  }

  getTypeParser(oid, format) {
    return this._types.getTypeParser(oid, format)
  }

  // Ported from PostgreSQL 9.2.4 source code in src/interfaces/libpq/fe-exec.c
  escapeIdentifier(str) {
    return '"' + str.replace(/"/g, '""') + '"'
  }

  // Ported from PostgreSQL 9.2.4 source code in src/interfaces/libpq/fe-exec.c
  escapeLiteral(str) {
    var hasBackslash = false
    var escaped = "'"

    for (var i = 0; i < str.length; i++) {
      var c = str[i]
      if (c === "'") {
        escaped += c + c
      } else if (c === '\\') {
        escaped += c + c
        hasBackslash = true
      } else {
        escaped += c
      }
    }

    escaped += "'"

    if (hasBackslash === true) {
      escaped = ' E' + escaped
    }

    return escaped
  }

  _pulseQueryQueue() {
    if (this.readyForQuery === true) {
      this.activeQuery = this.queryQueue.shift()
      if (this.activeQuery) {
        this.readyForQuery = false
        this.hasExecuted = true

        const queryError = this.activeQuery.submit(this.connection)
        if (queryError) {
          process.nextTick(() => {
            this.activeQuery.handleError(queryError, this.connection)
            this.readyForQuery = true
            this._pulseQueryQueue()
          })
        }
      } else if (this.hasExecuted) {
        this.activeQuery = null
        this.emit('drain')
      }
    }
  }

  query(config, values, callback) {
    // can take in strings, config object or query object
    var query
    var result
    var readTimeout
    var readTimeoutTimer
    var queryCallback

    if (config === null || config === undefined) {
      throw new TypeError('Client was passed a null or undefined query')
    } else if (typeof config.submit === 'function') {
      readTimeout = config.query_timeout || this.connectionParameters.query_timeout
      result = query = config
      if (typeof values === 'function') {
        query.callback = query.callback || values
      }
    } else {
      readTimeout = this.connectionParameters.query_timeout
      query = new Query(config, values, callback)
      if (!query.callback) {
        result = new this._Promise((resolve, reject) => {
          query.callback = (err, res) => (err ? reject(err) : resolve(res))
        })
      }
    }

    if (readTimeout) {
      queryCallback = query.callback

      readTimeoutTimer = setTimeout(() => {
        var error = new Error('Query read timeout')

        process.nextTick(() => {
          query.handleError(error, this.connection)
        })

        queryCallback(error)

        // we already returned an error,
        // just do nothing if query completes
        query.callback = () => {}

        // Remove from queue
        var index = this.queryQueue.indexOf(query)
        if (index > -1) {
          this.queryQueue.splice(index, 1)
        }

        this._pulseQueryQueue()
      }, readTimeout)

      query.callback = (err, res) => {
        clearTimeout(readTimeoutTimer)
        queryCallback(err, res)
      }
    }

    if (this.binary && !query.binary) {
      query.binary = true
    }

    if (query._result && !query._result._types) {
      query._result._types = this._types
    }

    if (!this._queryable) {
      process.nextTick(() => {
        query.handleError(new Error('Client has encountered a connection error and is not queryable'), this.connection)
      })
      return result
    }

    if (this._ending) {
      process.nextTick(() => {
        query.handleError(new Error('Client was closed and is not queryable'), this.connection)
      })
      return result
    }

    this.queryQueue.push(query)
    this._pulseQueryQueue()
    return result
  }

  ref() {
    this.connection.ref()
  }

  unref() {
    this.connection.unref()
  }

  end(cb) {
    this._ending = true

    // if we have never connected, then end is a noop, callback immediately
    if (!this.connection._connecting) {
      if (cb) {
        cb()
      } else {
        return this._Promise.resolve()
      }
    }

    if (this.activeQuery || !this._queryable) {
      // if we have an active query we need to force a disconnect
      // on the socket - otherwise a hung query could block end forever
      this.connection.stream.destroy()
    } else {
      this.connection.end()
    }

    if (cb) {
      this.connection.once('end', cb)
    } else {
      return new this._Promise((resolve) => {
        this.connection.once('end', resolve)
      })
    }
  }
}

// expose a Query constructor
Client.Query = Query

module.exports = Client


/***/ }),

/***/ 8048:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var dns = __webpack_require__(881)

var defaults = __webpack_require__(7433)

var parse = __webpack_require__(5697).parse // parses a connection string

var val = function (key, config, envVar) {
  if (envVar === undefined) {
    envVar = process.env['PG' + key.toUpperCase()]
  } else if (envVar === false) {
    // do nothing ... use false
  } else {
    envVar = process.env[envVar]
  }

  return config[key] || envVar || defaults[key]
}

var readSSLConfigFromEnvironment = function () {
  switch (process.env.PGSSLMODE) {
    case 'disable':
      return false
    case 'prefer':
    case 'require':
    case 'verify-ca':
    case 'verify-full':
      return true
    case 'no-verify':
      return { rejectUnauthorized: false }
  }
  return defaults.ssl
}

// Convert arg to a string, surround in single quotes, and escape single quotes and backslashes
var quoteParamValue = function (value) {
  return "'" + ('' + value).replace(/\\/g, '\\\\').replace(/'/g, "\\'") + "'"
}

var add = function (params, config, paramName) {
  var value = config[paramName]
  if (value !== undefined && value !== null) {
    params.push(paramName + '=' + quoteParamValue(value))
  }
}

class ConnectionParameters {
  constructor(config) {
    // if a string is passed, it is a raw connection string so we parse it into a config
    config = typeof config === 'string' ? parse(config) : config || {}

    // if the config has a connectionString defined, parse IT into the config we use
    // this will override other default values with what is stored in connectionString
    if (config.connectionString) {
      config = Object.assign({}, config, parse(config.connectionString))
    }

    this.user = val('user', config)
    this.database = val('database', config)

    if (this.database === undefined) {
      this.database = this.user
    }

    this.port = parseInt(val('port', config), 10)
    this.host = val('host', config)

    // "hiding" the password so it doesn't show up in stack traces
    // or if the client is console.logged
    Object.defineProperty(this, 'password', {
      configurable: true,
      enumerable: false,
      writable: true,
      value: val('password', config),
    })

    this.binary = val('binary', config)
    this.options = val('options', config)

    this.ssl = typeof config.ssl === 'undefined' ? readSSLConfigFromEnvironment() : config.ssl

    if (typeof this.ssl === 'string') {
      if (this.ssl === 'true') {
        this.ssl = true
      }
    }
    // support passing in ssl=no-verify via connection string
    if (this.ssl === 'no-verify') {
      this.ssl = { rejectUnauthorized: false }
    }
    if (this.ssl && this.ssl.key) {
      Object.defineProperty(this.ssl, 'key', {
        enumerable: false,
      })
    }

    this.client_encoding = val('client_encoding', config)
    this.replication = val('replication', config)
    // a domain socket begins with '/'
    this.isDomainSocket = !(this.host || '').indexOf('/')

    this.application_name = val('application_name', config, 'PGAPPNAME')
    this.fallback_application_name = val('fallback_application_name', config, false)
    this.statement_timeout = val('statement_timeout', config, false)
    this.idle_in_transaction_session_timeout = val('idle_in_transaction_session_timeout', config, false)
    this.query_timeout = val('query_timeout', config, false)

    if (config.connectionTimeoutMillis === undefined) {
      this.connect_timeout = process.env.PGCONNECT_TIMEOUT || 0
    } else {
      this.connect_timeout = Math.floor(config.connectionTimeoutMillis / 1000)
    }

    if (config.keepAlive === false) {
      this.keepalives = 0
    } else if (config.keepAlive === true) {
      this.keepalives = 1
    }

    if (typeof config.keepAliveInitialDelayMillis === 'number') {
      this.keepalives_idle = Math.floor(config.keepAliveInitialDelayMillis / 1000)
    }
  }

  getLibpqConnectionString(cb) {
    var params = []
    add(params, this, 'user')
    add(params, this, 'password')
    add(params, this, 'port')
    add(params, this, 'application_name')
    add(params, this, 'fallback_application_name')
    add(params, this, 'connect_timeout')
    add(params, this, 'options')

    var ssl = typeof this.ssl === 'object' ? this.ssl : this.ssl ? { sslmode: this.ssl } : {}
    add(params, ssl, 'sslmode')
    add(params, ssl, 'sslca')
    add(params, ssl, 'sslkey')
    add(params, ssl, 'sslcert')
    add(params, ssl, 'sslrootcert')

    if (this.database) {
      params.push('dbname=' + quoteParamValue(this.database))
    }
    if (this.replication) {
      params.push('replication=' + quoteParamValue(this.replication))
    }
    if (this.host) {
      params.push('host=' + quoteParamValue(this.host))
    }
    if (this.isDomainSocket) {
      return cb(null, params.join(' '))
    }
    if (this.client_encoding) {
      params.push('client_encoding=' + quoteParamValue(this.client_encoding))
    }
    dns.lookup(this.host, function (err, address) {
      if (err) return cb(err, null)
      params.push('hostaddr=' + quoteParamValue(address))
      return cb(null, params.join(' '))
    })
  }
}

module.exports = ConnectionParameters


/***/ }),

/***/ 1964:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var net = __webpack_require__(1631)
var EventEmitter = __webpack_require__(8614).EventEmitter

const { parse, serialize } = __webpack_require__(8152)

const flushBuffer = serialize.flush()
const syncBuffer = serialize.sync()
const endBuffer = serialize.end()

// TODO(bmc) support binary mode at some point
class Connection extends EventEmitter {
  constructor(config) {
    super()
    config = config || {}
    this.stream = config.stream || new net.Socket()
    this._keepAlive = config.keepAlive
    this._keepAliveInitialDelayMillis = config.keepAliveInitialDelayMillis
    this.lastBuffer = false
    this.parsedStatements = {}
    this.ssl = config.ssl || false
    this._ending = false
    this._emitMessage = false
    var self = this
    this.on('newListener', function (eventName) {
      if (eventName === 'message') {
        self._emitMessage = true
      }
    })
  }

  connect(port, host) {
    var self = this

    this._connecting = true
    this.stream.setNoDelay(true)
    this.stream.connect(port, host)

    this.stream.once('connect', function () {
      if (self._keepAlive) {
        self.stream.setKeepAlive(true, self._keepAliveInitialDelayMillis)
      }
      self.emit('connect')
    })

    const reportStreamError = function (error) {
      // errors about disconnections should be ignored during disconnect
      if (self._ending && (error.code === 'ECONNRESET' || error.code === 'EPIPE')) {
        return
      }
      self.emit('error', error)
    }
    this.stream.on('error', reportStreamError)

    this.stream.on('close', function () {
      self.emit('end')
    })

    if (!this.ssl) {
      return this.attachListeners(this.stream)
    }

    this.stream.once('data', function (buffer) {
      var responseCode = buffer.toString('utf8')
      switch (responseCode) {
        case 'S': // Server supports SSL connections, continue with a secure connection
          break
        case 'N': // Server does not support SSL connections
          self.stream.end()
          return self.emit('error', new Error('The server does not support SSL connections'))
        default:
          // Any other response byte, including 'E' (ErrorResponse) indicating a server error
          self.stream.end()
          return self.emit('error', new Error('There was an error establishing an SSL connection'))
      }
      var tls = __webpack_require__(4016)
      const options = {
        socket: self.stream,
      }

      if (self.ssl !== true) {
        Object.assign(options, self.ssl)

        if ('key' in self.ssl) {
          options.key = self.ssl.key
        }
      }

      if (net.isIP(host) === 0) {
        options.servername = host
      }
      try {
        self.stream = tls.connect(options)
      } catch (err) {
        return self.emit('error', err)
      }
      self.attachListeners(self.stream)
      self.stream.on('error', reportStreamError)

      self.emit('sslconnect')
    })
  }

  attachListeners(stream) {
    stream.on('end', () => {
      this.emit('end')
    })
    parse(stream, (msg) => {
      var eventName = msg.name === 'error' ? 'errorMessage' : msg.name
      if (this._emitMessage) {
        this.emit('message', msg)
      }
      this.emit(eventName, msg)
    })
  }

  requestSsl() {
    this.stream.write(serialize.requestSsl())
  }

  startup(config) {
    this.stream.write(serialize.startup(config))
  }

  cancel(processID, secretKey) {
    this._send(serialize.cancel(processID, secretKey))
  }

  password(password) {
    this._send(serialize.password(password))
  }

  sendSASLInitialResponseMessage(mechanism, initialResponse) {
    this._send(serialize.sendSASLInitialResponseMessage(mechanism, initialResponse))
  }

  sendSCRAMClientFinalMessage(additionalData) {
    this._send(serialize.sendSCRAMClientFinalMessage(additionalData))
  }

  _send(buffer) {
    if (!this.stream.writable) {
      return false
    }
    return this.stream.write(buffer)
  }

  query(text) {
    this._send(serialize.query(text))
  }

  // send parse message
  parse(query) {
    this._send(serialize.parse(query))
  }

  // send bind message
  bind(config) {
    this._send(serialize.bind(config))
  }

  // send execute message
  execute(config) {
    this._send(serialize.execute(config))
  }

  flush() {
    if (this.stream.writable) {
      this.stream.write(flushBuffer)
    }
  }

  sync() {
    this._ending = true
    this._send(flushBuffer)
    this._send(syncBuffer)
  }

  ref() {
    this.stream.ref()
  }

  unref() {
    this.stream.unref()
  }

  end() {
    // 0x58 = 'X'
    this._ending = true
    if (!this._connecting || !this.stream.writable) {
      this.stream.end()
      return
    }
    return this.stream.write(endBuffer, () => {
      this.stream.end()
    })
  }

  close(msg) {
    this._send(serialize.close(msg))
  }

  describe(msg) {
    this._send(serialize.describe(msg))
  }

  sendCopyFromChunk(chunk) {
    this._send(serialize.copyData(chunk))
  }

  endCopyFrom() {
    this._send(serialize.copyDone())
  }

  sendCopyFail(msg) {
    this._send(serialize.copyFail(msg))
  }
}

module.exports = Connection


/***/ }),

/***/ 7433:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


module.exports = {
  // database host. defaults to localhost
  host: 'localhost',

  // database user's name
  user: process.platform === 'win32' ? process.env.USERNAME : process.env.USER,

  // name of database to connect
  database: undefined,

  // database user's password
  password: null,

  // a Postgres connection string to be used instead of setting individual connection items
  // NOTE:  Setting this value will cause it to override any other value (such as database or user) defined
  // in the defaults object.
  connectionString: undefined,

  // database port
  port: 5432,

  // number of rows to return at a time from a prepared statement's
  // portal. 0 will return all rows at once
  rows: 0,

  // binary result mode
  binary: false,

  // Connection pool options - see https://github.com/brianc/node-pg-pool

  // number of connections to use in connection pool
  // 0 will disable connection pooling
  max: 10,

  // max milliseconds a client can go unused before it is removed
  // from the pool and destroyed
  idleTimeoutMillis: 30000,

  client_encoding: '',

  ssl: false,

  application_name: undefined,

  fallback_application_name: undefined,

  options: undefined,

  parseInputDatesAsUTC: false,

  // max milliseconds any query using this connection will execute for before timing out in error.
  // false=unlimited
  statement_timeout: false,

  // Terminate any session with an open transaction that has been idle for longer than the specified duration in milliseconds
  // false=unlimited
  idle_in_transaction_session_timeout: false,

  // max milliseconds to wait for query to complete (client side)
  query_timeout: false,

  connect_timeout: 0,

  keepalives: 1,

  keepalives_idle: 0,
}

var pgTypes = __webpack_require__(3619)
// save default parsers
var parseBigInteger = pgTypes.getTypeParser(20, 'text')
var parseBigIntegerArray = pgTypes.getTypeParser(1016, 'text')

// parse int8 so you can get your count values as actual numbers
module.exports.__defineSetter__('parseInt8', function (val) {
  pgTypes.setTypeParser(20, 'text', val ? pgTypes.getTypeParser(23, 'text') : parseBigInteger)
  pgTypes.setTypeParser(1016, 'text', val ? pgTypes.getTypeParser(1007, 'text') : parseBigIntegerArray)
})


/***/ }),

/***/ 8955:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var Client = __webpack_require__(7442)
var defaults = __webpack_require__(7433)
var Connection = __webpack_require__(1964)
var Pool = __webpack_require__(5546)
const { DatabaseError } = __webpack_require__(8152)

const poolFactory = (Client) => {
  return class BoundPool extends Pool {
    constructor(options) {
      super(options, Client)
    }
  }
}

var PG = function (clientConstructor) {
  this.defaults = defaults
  this.Client = clientConstructor
  this.Query = this.Client.Query
  this.Pool = poolFactory(this.Client)
  this._pools = []
  this.Connection = Connection
  this.types = __webpack_require__(3619)
  this.DatabaseError = DatabaseError
}

if (typeof process.env.NODE_PG_FORCE_NATIVE !== 'undefined') {
  module.exports = new PG(__webpack_require__(6221))
} else {
  module.exports = new PG(Client)

  // lazy require native module...the native module may not have installed
  Object.defineProperty(module.exports, "native", ({
    configurable: true,
    enumerable: false,
    get() {
      var native = null
      try {
        native = new PG(__webpack_require__(6221))
      } catch (err) {
        if (err.code !== 'MODULE_NOT_FOUND') {
          throw err
        }
      }

      // overwrite module.exports.native so that getter is never called again
      Object.defineProperty(module.exports, "native", ({
        value: native,
      }))

      return native
    },
  }))
}


/***/ }),

/***/ 6033:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// eslint-disable-next-line
var Native = __webpack_require__(Object(function webpackMissingModule() { var e = new Error("Cannot find module 'pg-native'"); e.code = 'MODULE_NOT_FOUND'; throw e; }()))
var TypeOverrides = __webpack_require__(5701)
var pkg = __webpack_require__(2466)
var EventEmitter = __webpack_require__(8614).EventEmitter
var util = __webpack_require__(1669)
var ConnectionParameters = __webpack_require__(8048)

var NativeQuery = __webpack_require__(7839)

var Client = (module.exports = function (config) {
  EventEmitter.call(this)
  config = config || {}

  this._Promise = config.Promise || global.Promise
  this._types = new TypeOverrides(config.types)

  this.native = new Native({
    types: this._types,
  })

  this._queryQueue = []
  this._ending = false
  this._connecting = false
  this._connected = false
  this._queryable = true

  // keep these on the object for legacy reasons
  // for the time being. TODO: deprecate all this jazz
  var cp = (this.connectionParameters = new ConnectionParameters(config))
  this.user = cp.user

  // "hiding" the password so it doesn't show up in stack traces
  // or if the client is console.logged
  Object.defineProperty(this, 'password', {
    configurable: true,
    enumerable: false,
    writable: true,
    value: cp.password,
  })
  this.database = cp.database
  this.host = cp.host
  this.port = cp.port

  // a hash to hold named queries
  this.namedQueries = {}
})

Client.Query = NativeQuery

util.inherits(Client, EventEmitter)

Client.prototype._errorAllQueries = function (err) {
  const enqueueError = (query) => {
    process.nextTick(() => {
      query.native = this.native
      query.handleError(err)
    })
  }

  if (this._hasActiveQuery()) {
    enqueueError(this._activeQuery)
    this._activeQuery = null
  }

  this._queryQueue.forEach(enqueueError)
  this._queryQueue.length = 0
}

// connect to the backend
// pass an optional callback to be called once connected
// or with an error if there was a connection error
Client.prototype._connect = function (cb) {
  var self = this

  if (this._connecting) {
    process.nextTick(() => cb(new Error('Client has already been connected. You cannot reuse a client.')))
    return
  }

  this._connecting = true

  this.connectionParameters.getLibpqConnectionString(function (err, conString) {
    if (err) return cb(err)
    self.native.connect(conString, function (err) {
      if (err) {
        self.native.end()
        return cb(err)
      }

      // set internal states to connected
      self._connected = true

      // handle connection errors from the native layer
      self.native.on('error', function (err) {
        self._queryable = false
        self._errorAllQueries(err)
        self.emit('error', err)
      })

      self.native.on('notification', function (msg) {
        self.emit('notification', {
          channel: msg.relname,
          payload: msg.extra,
        })
      })

      // signal we are connected now
      self.emit('connect')
      self._pulseQueryQueue(true)

      cb()
    })
  })
}

Client.prototype.connect = function (callback) {
  if (callback) {
    this._connect(callback)
    return
  }

  return new this._Promise((resolve, reject) => {
    this._connect((error) => {
      if (error) {
        reject(error)
      } else {
        resolve()
      }
    })
  })
}

// send a query to the server
// this method is highly overloaded to take
// 1) string query, optional array of parameters, optional function callback
// 2) object query with {
//    string query
//    optional array values,
//    optional function callback instead of as a separate parameter
//    optional string name to name & cache the query plan
//    optional string rowMode = 'array' for an array of results
//  }
Client.prototype.query = function (config, values, callback) {
  var query
  var result
  var readTimeout
  var readTimeoutTimer
  var queryCallback

  if (config === null || config === undefined) {
    throw new TypeError('Client was passed a null or undefined query')
  } else if (typeof config.submit === 'function') {
    readTimeout = config.query_timeout || this.connectionParameters.query_timeout
    result = query = config
    // accept query(new Query(...), (err, res) => { }) style
    if (typeof values === 'function') {
      config.callback = values
    }
  } else {
    readTimeout = this.connectionParameters.query_timeout
    query = new NativeQuery(config, values, callback)
    if (!query.callback) {
      let resolveOut, rejectOut
      result = new this._Promise((resolve, reject) => {
        resolveOut = resolve
        rejectOut = reject
      })
      query.callback = (err, res) => (err ? rejectOut(err) : resolveOut(res))
    }
  }

  if (readTimeout) {
    queryCallback = query.callback

    readTimeoutTimer = setTimeout(() => {
      var error = new Error('Query read timeout')

      process.nextTick(() => {
        query.handleError(error, this.connection)
      })

      queryCallback(error)

      // we already returned an error,
      // just do nothing if query completes
      query.callback = () => {}

      // Remove from queue
      var index = this._queryQueue.indexOf(query)
      if (index > -1) {
        this._queryQueue.splice(index, 1)
      }

      this._pulseQueryQueue()
    }, readTimeout)

    query.callback = (err, res) => {
      clearTimeout(readTimeoutTimer)
      queryCallback(err, res)
    }
  }

  if (!this._queryable) {
    query.native = this.native
    process.nextTick(() => {
      query.handleError(new Error('Client has encountered a connection error and is not queryable'))
    })
    return result
  }

  if (this._ending) {
    query.native = this.native
    process.nextTick(() => {
      query.handleError(new Error('Client was closed and is not queryable'))
    })
    return result
  }

  this._queryQueue.push(query)
  this._pulseQueryQueue()
  return result
}

// disconnect from the backend server
Client.prototype.end = function (cb) {
  var self = this

  this._ending = true

  if (!this._connected) {
    this.once('connect', this.end.bind(this, cb))
  }
  var result
  if (!cb) {
    result = new this._Promise(function (resolve, reject) {
      cb = (err) => (err ? reject(err) : resolve())
    })
  }
  this.native.end(function () {
    self._errorAllQueries(new Error('Connection terminated'))

    process.nextTick(() => {
      self.emit('end')
      if (cb) cb()
    })
  })
  return result
}

Client.prototype._hasActiveQuery = function () {
  return this._activeQuery && this._activeQuery.state !== 'error' && this._activeQuery.state !== 'end'
}

Client.prototype._pulseQueryQueue = function (initialConnection) {
  if (!this._connected) {
    return
  }
  if (this._hasActiveQuery()) {
    return
  }
  var query = this._queryQueue.shift()
  if (!query) {
    if (!initialConnection) {
      this.emit('drain')
    }
    return
  }
  this._activeQuery = query
  query.submit(this)
  var self = this
  query.once('_done', function () {
    self._pulseQueryQueue()
  })
}

// attempt to cancel an in-progress query
Client.prototype.cancel = function (query) {
  if (this._activeQuery === query) {
    this.native.cancel(function () {})
  } else if (this._queryQueue.indexOf(query) !== -1) {
    this._queryQueue.splice(this._queryQueue.indexOf(query), 1)
  }
}

Client.prototype.ref = function () {}
Client.prototype.unref = function () {}

Client.prototype.setTypeParser = function (oid, format, parseFn) {
  return this._types.setTypeParser(oid, format, parseFn)
}

Client.prototype.getTypeParser = function (oid, format) {
  return this._types.getTypeParser(oid, format)
}


/***/ }),

/***/ 6221:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

module.exports = __webpack_require__(6033)


/***/ }),

/***/ 7839:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var EventEmitter = __webpack_require__(8614).EventEmitter
var util = __webpack_require__(1669)
var utils = __webpack_require__(1262)

var NativeQuery = (module.exports = function (config, values, callback) {
  EventEmitter.call(this)
  config = utils.normalizeQueryConfig(config, values, callback)
  this.text = config.text
  this.values = config.values
  this.name = config.name
  this.callback = config.callback
  this.state = 'new'
  this._arrayMode = config.rowMode === 'array'

  // if the 'row' event is listened for
  // then emit them as they come in
  // without setting singleRowMode to true
  // this has almost no meaning because libpq
  // reads all rows into memory befor returning any
  this._emitRowEvents = false
  this.on(
    'newListener',
    function (event) {
      if (event === 'row') this._emitRowEvents = true
    }.bind(this)
  )
})

util.inherits(NativeQuery, EventEmitter)

var errorFieldMap = {
  /* eslint-disable quote-props */
  sqlState: 'code',
  statementPosition: 'position',
  messagePrimary: 'message',
  context: 'where',
  schemaName: 'schema',
  tableName: 'table',
  columnName: 'column',
  dataTypeName: 'dataType',
  constraintName: 'constraint',
  sourceFile: 'file',
  sourceLine: 'line',
  sourceFunction: 'routine',
}

NativeQuery.prototype.handleError = function (err) {
  // copy pq error fields into the error object
  var fields = this.native.pq.resultErrorFields()
  if (fields) {
    for (var key in fields) {
      var normalizedFieldName = errorFieldMap[key] || key
      err[normalizedFieldName] = fields[key]
    }
  }
  if (this.callback) {
    this.callback(err)
  } else {
    this.emit('error', err)
  }
  this.state = 'error'
}

NativeQuery.prototype.then = function (onSuccess, onFailure) {
  return this._getPromise().then(onSuccess, onFailure)
}

NativeQuery.prototype.catch = function (callback) {
  return this._getPromise().catch(callback)
}

NativeQuery.prototype._getPromise = function () {
  if (this._promise) return this._promise
  this._promise = new Promise(
    function (resolve, reject) {
      this._once('end', resolve)
      this._once('error', reject)
    }.bind(this)
  )
  return this._promise
}

NativeQuery.prototype.submit = function (client) {
  this.state = 'running'
  var self = this
  this.native = client.native
  client.native.arrayMode = this._arrayMode

  var after = function (err, rows, results) {
    client.native.arrayMode = false
    setImmediate(function () {
      self.emit('_done')
    })

    // handle possible query error
    if (err) {
      return self.handleError(err)
    }

    // emit row events for each row in the result
    if (self._emitRowEvents) {
      if (results.length > 1) {
        rows.forEach((rowOfRows, i) => {
          rowOfRows.forEach((row) => {
            self.emit('row', row, results[i])
          })
        })
      } else {
        rows.forEach(function (row) {
          self.emit('row', row, results)
        })
      }
    }

    // handle successful result
    self.state = 'end'
    self.emit('end', results)
    if (self.callback) {
      self.callback(null, results)
    }
  }

  if (process.domain) {
    after = process.domain.bind(after)
  }

  // named query
  if (this.name) {
    if (this.name.length > 63) {
      /* eslint-disable no-console */
      console.error('Warning! Postgres only supports 63 characters for query names.')
      console.error('You supplied %s (%s)', this.name, this.name.length)
      console.error('This can cause conflicts and silent errors executing queries')
      /* eslint-enable no-console */
    }
    var values = (this.values || []).map(utils.prepareValue)

    // check if the client has already executed this named query
    // if so...just execute it again - skip the planning phase
    if (client.namedQueries[this.name]) {
      if (this.text && client.namedQueries[this.name] !== this.text) {
        const err = new Error(`Prepared statements must be unique - '${this.name}' was used for a different statement`)
        return after(err)
      }
      return client.native.execute(this.name, values, after)
    }
    // plan the named query the first time, then execute it
    return client.native.prepare(this.name, this.text, values.length, function (err) {
      if (err) return after(err)
      client.namedQueries[self.name] = self.text
      return self.native.execute(self.name, values, after)
    })
  } else if (this.values) {
    if (!Array.isArray(this.values)) {
      const err = new Error('Query values must be an array')
      return after(err)
    }
    var vals = this.values.map(utils.prepareValue)
    client.native.query(this.text, vals, after)
  } else {
    client.native.query(this.text, after)
  }
}


/***/ }),

/***/ 1134:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


const { EventEmitter } = __webpack_require__(8614)

const Result = __webpack_require__(3758)
const utils = __webpack_require__(1262)

class Query extends EventEmitter {
  constructor(config, values, callback) {
    super()

    config = utils.normalizeQueryConfig(config, values, callback)

    this.text = config.text
    this.values = config.values
    this.rows = config.rows
    this.types = config.types
    this.name = config.name
    this.binary = config.binary
    // use unique portal name each time
    this.portal = config.portal || ''
    this.callback = config.callback
    this._rowMode = config.rowMode
    if (process.domain && config.callback) {
      this.callback = process.domain.bind(config.callback)
    }
    this._result = new Result(this._rowMode, this.types)

    // potential for multiple results
    this._results = this._result
    this.isPreparedStatement = false
    this._canceledDueToError = false
    this._promise = null
  }

  requiresPreparation() {
    // named queries must always be prepared
    if (this.name) {
      return true
    }
    // always prepare if there are max number of rows expected per
    // portal execution
    if (this.rows) {
      return true
    }
    // don't prepare empty text queries
    if (!this.text) {
      return false
    }
    // prepare if there are values
    if (!this.values) {
      return false
    }
    return this.values.length > 0
  }

  _checkForMultirow() {
    // if we already have a result with a command property
    // then we've already executed one query in a multi-statement simple query
    // turn our results into an array of results
    if (this._result.command) {
      if (!Array.isArray(this._results)) {
        this._results = [this._result]
      }
      this._result = new Result(this._rowMode, this.types)
      this._results.push(this._result)
    }
  }

  // associates row metadata from the supplied
  // message with this query object
  // metadata used when parsing row results
  handleRowDescription(msg) {
    this._checkForMultirow()
    this._result.addFields(msg.fields)
    this._accumulateRows = this.callback || !this.listeners('row').length
  }

  handleDataRow(msg) {
    let row

    if (this._canceledDueToError) {
      return
    }

    try {
      row = this._result.parseRow(msg.fields)
    } catch (err) {
      this._canceledDueToError = err
      return
    }

    this.emit('row', row, this._result)
    if (this._accumulateRows) {
      this._result.addRow(row)
    }
  }

  handleCommandComplete(msg, connection) {
    this._checkForMultirow()
    this._result.addCommandComplete(msg)
    // need to sync after each command complete of a prepared statement
    // if we were using a row count which results in multiple calls to _getRows
    if (this.rows) {
      connection.sync()
    }
  }

  // if a named prepared statement is created with empty query text
  // the backend will send an emptyQuery message but *not* a command complete message
  // since we pipeline sync immediately after execute we don't need to do anything here
  // unless we have rows specified, in which case we did not pipeline the intial sync call
  handleEmptyQuery(connection) {
    if (this.rows) {
      connection.sync()
    }
  }

  handleError(err, connection) {
    // need to sync after error during a prepared statement
    if (this._canceledDueToError) {
      err = this._canceledDueToError
      this._canceledDueToError = false
    }
    // if callback supplied do not emit error event as uncaught error
    // events will bubble up to node process
    if (this.callback) {
      return this.callback(err)
    }
    this.emit('error', err)
  }

  handleReadyForQuery(con) {
    if (this._canceledDueToError) {
      return this.handleError(this._canceledDueToError, con)
    }
    if (this.callback) {
      this.callback(null, this._results)
    }
    this.emit('end', this._results)
  }

  submit(connection) {
    if (typeof this.text !== 'string' && typeof this.name !== 'string') {
      return new Error('A query must have either text or a name. Supplying neither is unsupported.')
    }
    const previous = connection.parsedStatements[this.name]
    if (this.text && previous && this.text !== previous) {
      return new Error(`Prepared statements must be unique - '${this.name}' was used for a different statement`)
    }
    if (this.values && !Array.isArray(this.values)) {
      return new Error('Query values must be an array')
    }
    if (this.requiresPreparation()) {
      this.prepare(connection)
    } else {
      connection.query(this.text)
    }
    return null
  }

  hasBeenParsed(connection) {
    return this.name && connection.parsedStatements[this.name]
  }

  handlePortalSuspended(connection) {
    this._getRows(connection, this.rows)
  }

  _getRows(connection, rows) {
    connection.execute({
      portal: this.portal,
      rows: rows,
    })
    // if we're not reading pages of rows send the sync command
    // to indicate the pipeline is finished
    if (!rows) {
      connection.sync()
    } else {
      // otherwise flush the call out to read more rows
      connection.flush()
    }
  }

  // http://developer.postgresql.org/pgdocs/postgres/protocol-flow.html#PROTOCOL-FLOW-EXT-QUERY
  prepare(connection) {
    // prepared statements need sync to be called after each command
    // complete or when an error is encountered
    this.isPreparedStatement = true

    // TODO refactor this poor encapsulation
    if (!this.hasBeenParsed(connection)) {
      connection.parse({
        text: this.text,
        name: this.name,
        types: this.types,
      })
    }

    // because we're mapping user supplied values to
    // postgres wire protocol compatible values it could
    // throw an exception, so try/catch this section
    try {
      connection.bind({
        portal: this.portal,
        statement: this.name,
        values: this.values,
        binary: this.binary,
        valueMapper: utils.prepareValue,
      })
    } catch (err) {
      this.handleError(err, connection)
      return
    }

    connection.describe({
      type: 'P',
      name: this.portal || '',
    })

    this._getRows(connection, this.rows)
  }

  handleCopyInResponse(connection) {
    connection.sendCopyFail('No source stream defined')
  }

  // eslint-disable-next-line no-unused-vars
  handleCopyData(msg, connection) {
    // noop
  }
}

module.exports = Query


/***/ }),

/***/ 3758:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var types = __webpack_require__(3619)

var matchRegexp = /^([A-Za-z]+)(?: (\d+))?(?: (\d+))?/

// result object returned from query
// in the 'end' event and also
// passed as second argument to provided callback
class Result {
  constructor(rowMode, types) {
    this.command = null
    this.rowCount = null
    this.oid = null
    this.rows = []
    this.fields = []
    this._parsers = undefined
    this._types = types
    this.RowCtor = null
    this.rowAsArray = rowMode === 'array'
    if (this.rowAsArray) {
      this.parseRow = this._parseRowAsArray
    }
  }

  // adds a command complete message
  addCommandComplete(msg) {
    var match
    if (msg.text) {
      // pure javascript
      match = matchRegexp.exec(msg.text)
    } else {
      // native bindings
      match = matchRegexp.exec(msg.command)
    }
    if (match) {
      this.command = match[1]
      if (match[3]) {
        // COMMMAND OID ROWS
        this.oid = parseInt(match[2], 10)
        this.rowCount = parseInt(match[3], 10)
      } else if (match[2]) {
        // COMMAND ROWS
        this.rowCount = parseInt(match[2], 10)
      }
    }
  }

  _parseRowAsArray(rowData) {
    var row = new Array(rowData.length)
    for (var i = 0, len = rowData.length; i < len; i++) {
      var rawValue = rowData[i]
      if (rawValue !== null) {
        row[i] = this._parsers[i](rawValue)
      } else {
        row[i] = null
      }
    }
    return row
  }

  parseRow(rowData) {
    var row = {}
    for (var i = 0, len = rowData.length; i < len; i++) {
      var rawValue = rowData[i]
      var field = this.fields[i].name
      if (rawValue !== null) {
        row[field] = this._parsers[i](rawValue)
      } else {
        row[field] = null
      }
    }
    return row
  }

  addRow(row) {
    this.rows.push(row)
  }

  addFields(fieldDescriptions) {
    // clears field definitions
    // multiple query statements in 1 action can result in multiple sets
    // of rowDescriptions...eg: 'select NOW(); select 1::int;'
    // you need to reset the fields
    this.fields = fieldDescriptions
    if (this.fields.length) {
      this._parsers = new Array(fieldDescriptions.length)
    }
    for (var i = 0; i < fieldDescriptions.length; i++) {
      var desc = fieldDescriptions[i]
      if (this._types) {
        this._parsers[i] = this._types.getTypeParser(desc.dataTypeID, desc.format || 'text')
      } else {
        this._parsers[i] = types.getTypeParser(desc.dataTypeID, desc.format || 'text')
      }
    }
  }
}

module.exports = Result


/***/ }),

/***/ 4615:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

const crypto = __webpack_require__(6417)

function startSession(mechanisms) {
  if (mechanisms.indexOf('SCRAM-SHA-256') === -1) {
    throw new Error('SASL: Only mechanism SCRAM-SHA-256 is currently supported')
  }

  const clientNonce = crypto.randomBytes(18).toString('base64')

  return {
    mechanism: 'SCRAM-SHA-256',
    clientNonce,
    response: 'n,,n=*,r=' + clientNonce,
    message: 'SASLInitialResponse',
  }
}

function continueSession(session, password, serverData) {
  if (session.message !== 'SASLInitialResponse') {
    throw new Error('SASL: Last message was not SASLInitialResponse')
  }
  if (typeof password !== 'string') {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: client password must be a string')
  }
  if (typeof serverData !== 'string') {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: serverData must be a string')
  }

  const sv = parseServerFirstMessage(serverData)

  if (!sv.nonce.startsWith(session.clientNonce)) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: server nonce does not start with client nonce')
  } else if (sv.nonce.length === session.clientNonce.length) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: server nonce is too short')
  }

  var saltBytes = Buffer.from(sv.salt, 'base64')

  var saltedPassword = Hi(password, saltBytes, sv.iteration)

  var clientKey = hmacSha256(saltedPassword, 'Client Key')
  var storedKey = sha256(clientKey)

  var clientFirstMessageBare = 'n=*,r=' + session.clientNonce
  var serverFirstMessage = 'r=' + sv.nonce + ',s=' + sv.salt + ',i=' + sv.iteration

  var clientFinalMessageWithoutProof = 'c=biws,r=' + sv.nonce

  var authMessage = clientFirstMessageBare + ',' + serverFirstMessage + ',' + clientFinalMessageWithoutProof

  var clientSignature = hmacSha256(storedKey, authMessage)
  var clientProofBytes = xorBuffers(clientKey, clientSignature)
  var clientProof = clientProofBytes.toString('base64')

  var serverKey = hmacSha256(saltedPassword, 'Server Key')
  var serverSignatureBytes = hmacSha256(serverKey, authMessage)

  session.message = 'SASLResponse'
  session.serverSignature = serverSignatureBytes.toString('base64')
  session.response = clientFinalMessageWithoutProof + ',p=' + clientProof
}

function finalizeSession(session, serverData) {
  if (session.message !== 'SASLResponse') {
    throw new Error('SASL: Last message was not SASLResponse')
  }
  if (typeof serverData !== 'string') {
    throw new Error('SASL: SCRAM-SERVER-FINAL-MESSAGE: serverData must be a string')
  }

  const { serverSignature } = parseServerFinalMessage(serverData)

  if (serverSignature !== session.serverSignature) {
    throw new Error('SASL: SCRAM-SERVER-FINAL-MESSAGE: server signature does not match')
  }
}

/**
 * printable       = %x21-2B / %x2D-7E
 *                   ;; Printable ASCII except ",".
 *                   ;; Note that any "printable" is also
 *                   ;; a valid "value".
 */
function isPrintableChars(text) {
  if (typeof text !== 'string') {
    throw new TypeError('SASL: text must be a string')
  }
  return text
    .split('')
    .map((_, i) => text.charCodeAt(i))
    .every((c) => (c >= 0x21 && c <= 0x2b) || (c >= 0x2d && c <= 0x7e))
}

/**
 * base64-char     = ALPHA / DIGIT / "/" / "+"
 *
 * base64-4        = 4base64-char
 *
 * base64-3        = 3base64-char "="
 *
 * base64-2        = 2base64-char "=="
 *
 * base64          = *base64-4 [base64-3 / base64-2]
 */
function isBase64(text) {
  return /^(?:[a-zA-Z0-9+/]{4})*(?:[a-zA-Z0-9+/]{2}==|[a-zA-Z0-9+/]{3}=)?$/.test(text)
}

function parseAttributePairs(text) {
  if (typeof text !== 'string') {
    throw new TypeError('SASL: attribute pairs text must be a string')
  }

  return new Map(
    text.split(',').map((attrValue) => {
      if (!/^.=/.test(attrValue)) {
        throw new Error('SASL: Invalid attribute pair entry')
      }
      const name = attrValue[0]
      const value = attrValue.substring(2)
      return [name, value]
    })
  )
}

function parseServerFirstMessage(data) {
  const attrPairs = parseAttributePairs(data)

  const nonce = attrPairs.get('r')
  if (!nonce) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: nonce missing')
  } else if (!isPrintableChars(nonce)) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: nonce must only contain printable characters')
  }
  const salt = attrPairs.get('s')
  if (!salt) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: salt missing')
  } else if (!isBase64(salt)) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: salt must be base64')
  }
  const iterationText = attrPairs.get('i')
  if (!iterationText) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: iteration missing')
  } else if (!/^[1-9][0-9]*$/.test(iterationText)) {
    throw new Error('SASL: SCRAM-SERVER-FIRST-MESSAGE: invalid iteration count')
  }
  const iteration = parseInt(iterationText, 10)

  return {
    nonce,
    salt,
    iteration,
  }
}

function parseServerFinalMessage(serverData) {
  const attrPairs = parseAttributePairs(serverData)
  const serverSignature = attrPairs.get('v')
  if (!serverSignature) {
    throw new Error('SASL: SCRAM-SERVER-FINAL-MESSAGE: server signature is missing')
  } else if (!isBase64(serverSignature)) {
    throw new Error('SASL: SCRAM-SERVER-FINAL-MESSAGE: server signature must be base64')
  }
  return {
    serverSignature,
  }
}

function xorBuffers(a, b) {
  if (!Buffer.isBuffer(a)) {
    throw new TypeError('first argument must be a Buffer')
  }
  if (!Buffer.isBuffer(b)) {
    throw new TypeError('second argument must be a Buffer')
  }
  if (a.length !== b.length) {
    throw new Error('Buffer lengths must match')
  }
  if (a.length === 0) {
    throw new Error('Buffers cannot be empty')
  }
  return Buffer.from(a.map((_, i) => a[i] ^ b[i]))
}

function sha256(text) {
  return crypto.createHash('sha256').update(text).digest()
}

function hmacSha256(key, msg) {
  return crypto.createHmac('sha256', key).update(msg).digest()
}

function Hi(password, saltBytes, iterations) {
  var ui1 = hmacSha256(password, Buffer.concat([saltBytes, Buffer.from([0, 0, 0, 1])]))
  var ui = ui1
  for (var i = 0; i < iterations - 1; i++) {
    ui1 = hmacSha256(password, ui1)
    ui = xorBuffers(ui, ui1)
  }

  return ui
}

module.exports = {
  startSession,
  continueSession,
  finalizeSession,
}


/***/ }),

/***/ 5701:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var types = __webpack_require__(3619)

function TypeOverrides(userTypes) {
  this._types = userTypes || types
  this.text = {}
  this.binary = {}
}

TypeOverrides.prototype.getOverrides = function (format) {
  switch (format) {
    case 'text':
      return this.text
    case 'binary':
      return this.binary
    default:
      return {}
  }
}

TypeOverrides.prototype.setTypeParser = function (oid, format, parseFn) {
  if (typeof format === 'function') {
    parseFn = format
    format = 'text'
  }
  this.getOverrides(format)[oid] = parseFn
}

TypeOverrides.prototype.getTypeParser = function (oid, format) {
  format = format || 'text'
  return this.getOverrides(format)[oid] || this._types.getTypeParser(oid, format)
}

module.exports = TypeOverrides


/***/ }),

/***/ 1262:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


const crypto = __webpack_require__(6417)

const defaults = __webpack_require__(7433)

function escapeElement(elementRepresentation) {
  var escaped = elementRepresentation.replace(/\\/g, '\\\\').replace(/"/g, '\\"')

  return '"' + escaped + '"'
}

// convert a JS array to a postgres array literal
// uses comma separator so won't work for types like box that use
// a different array separator.
function arrayString(val) {
  var result = '{'
  for (var i = 0; i < val.length; i++) {
    if (i > 0) {
      result = result + ','
    }
    if (val[i] === null || typeof val[i] === 'undefined') {
      result = result + 'NULL'
    } else if (Array.isArray(val[i])) {
      result = result + arrayString(val[i])
    } else if (val[i] instanceof Buffer) {
      result += '\\\\x' + val[i].toString('hex')
    } else {
      result += escapeElement(prepareValue(val[i]))
    }
  }
  result = result + '}'
  return result
}

// converts values from javascript types
// to their 'raw' counterparts for use as a postgres parameter
// note: you can override this function to provide your own conversion mechanism
// for complex types, etc...
var prepareValue = function (val, seen) {
  // null and undefined are both null for postgres
  if (val == null) {
    return null
  }
  if (val instanceof Buffer) {
    return val
  }
  if (ArrayBuffer.isView(val)) {
    var buf = Buffer.from(val.buffer, val.byteOffset, val.byteLength)
    if (buf.length === val.byteLength) {
      return buf
    }
    return buf.slice(val.byteOffset, val.byteOffset + val.byteLength) // Node.js v4 does not support those Buffer.from params
  }
  if (val instanceof Date) {
    if (defaults.parseInputDatesAsUTC) {
      return dateToStringUTC(val)
    } else {
      return dateToString(val)
    }
  }
  if (Array.isArray(val)) {
    return arrayString(val)
  }
  if (typeof val === 'object') {
    return prepareObject(val, seen)
  }
  return val.toString()
}

function prepareObject(val, seen) {
  if (val && typeof val.toPostgres === 'function') {
    seen = seen || []
    if (seen.indexOf(val) !== -1) {
      throw new Error('circular reference detected while preparing "' + val + '" for query')
    }
    seen.push(val)

    return prepareValue(val.toPostgres(prepareValue), seen)
  }
  return JSON.stringify(val)
}

function pad(number, digits) {
  number = '' + number
  while (number.length < digits) {
    number = '0' + number
  }
  return number
}

function dateToString(date) {
  var offset = -date.getTimezoneOffset()

  var year = date.getFullYear()
  var isBCYear = year < 1
  if (isBCYear) year = Math.abs(year) + 1 // negative years are 1 off their BC representation

  var ret =
    pad(year, 4) +
    '-' +
    pad(date.getMonth() + 1, 2) +
    '-' +
    pad(date.getDate(), 2) +
    'T' +
    pad(date.getHours(), 2) +
    ':' +
    pad(date.getMinutes(), 2) +
    ':' +
    pad(date.getSeconds(), 2) +
    '.' +
    pad(date.getMilliseconds(), 3)

  if (offset < 0) {
    ret += '-'
    offset *= -1
  } else {
    ret += '+'
  }

  ret += pad(Math.floor(offset / 60), 2) + ':' + pad(offset % 60, 2)
  if (isBCYear) ret += ' BC'
  return ret
}

function dateToStringUTC(date) {
  var year = date.getUTCFullYear()
  var isBCYear = year < 1
  if (isBCYear) year = Math.abs(year) + 1 // negative years are 1 off their BC representation

  var ret =
    pad(year, 4) +
    '-' +
    pad(date.getUTCMonth() + 1, 2) +
    '-' +
    pad(date.getUTCDate(), 2) +
    'T' +
    pad(date.getUTCHours(), 2) +
    ':' +
    pad(date.getUTCMinutes(), 2) +
    ':' +
    pad(date.getUTCSeconds(), 2) +
    '.' +
    pad(date.getUTCMilliseconds(), 3)

  ret += '+00:00'
  if (isBCYear) ret += ' BC'
  return ret
}

function normalizeQueryConfig(config, values, callback) {
  // can take in strings or config objects
  config = typeof config === 'string' ? { text: config } : config
  if (values) {
    if (typeof values === 'function') {
      config.callback = values
    } else {
      config.values = values
    }
  }
  if (callback) {
    config.callback = callback
  }
  return config
}

const md5 = function (string) {
  return crypto.createHash('md5').update(string, 'utf-8').digest('hex')
}

// See AuthenticationMD5Password at https://www.postgresql.org/docs/current/static/protocol-flow.html
const postgresMd5PasswordHash = function (user, password, salt) {
  var inner = md5(password + user)
  var outer = md5(Buffer.concat([Buffer.from(inner), salt]))
  return 'md5' + outer
}

module.exports = {
  prepareValue: function prepareValueWrapper(value) {
    // this ensures that extra arguments do not get passed into prepareValue
    // by accident, eg: from calling values.map(utils.prepareValue)
    return prepareValue(value)
  },
  normalizeQueryConfig,
  postgresMd5PasswordHash,
  md5,
}


/***/ }),

/***/ 8242:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var path = __webpack_require__(5622)
  , Stream = __webpack_require__(2413).Stream
  , split = __webpack_require__(861)
  , util = __webpack_require__(1669)
  , defaultPort = 5432
  , isWin = (process.platform === 'win32')
  , warnStream = process.stderr
;


var S_IRWXG = 56     //    00070(8)
  , S_IRWXO = 7      //    00007(8)
  , S_IFMT  = 61440  // 00170000(8)
  , S_IFREG = 32768  //  0100000(8)
;
function isRegFile(mode) {
    return ((mode & S_IFMT) == S_IFREG);
}

var fieldNames = [ 'host', 'port', 'database', 'user', 'password' ];
var nrOfFields = fieldNames.length;
var passKey = fieldNames[ nrOfFields -1 ];


function warn() {
    var isWritable = (
        warnStream instanceof Stream &&
          true === warnStream.writable
    );

    if (isWritable) {
        var args = Array.prototype.slice.call(arguments).concat("\n");
        warnStream.write( util.format.apply(util, args) );
    }
}


Object.defineProperty(module.exports, "isWin", ({
    get : function() {
        return isWin;
    } ,
    set : function(val) {
        isWin = val;
    }
}));


module.exports.warnTo = function(stream) {
    var old = warnStream;
    warnStream = stream;
    return old;
};

module.exports.getFileName = function(rawEnv){
    var env = rawEnv || process.env;
    var file = env.PGPASSFILE || (
        isWin ?
          path.join( env.APPDATA || './' , 'postgresql', 'pgpass.conf' ) :
          path.join( env.HOME || './', '.pgpass' )
    );
    return file;
};

module.exports.usePgPass = function(stats, fname) {
    if (Object.prototype.hasOwnProperty.call(process.env, 'PGPASSWORD')) {
        return false;
    }

    if (isWin) {
        return true;
    }

    fname = fname || '<unkn>';

    if (! isRegFile(stats.mode)) {
        warn('WARNING: password file "%s" is not a plain file', fname);
        return false;
    }

    if (stats.mode & (S_IRWXG | S_IRWXO)) {
        /* If password file is insecure, alert the user and ignore it. */
        warn('WARNING: password file "%s" has group or world access; permissions should be u=rw (0600) or less', fname);
        return false;
    }

    return true;
};


var matcher = module.exports.match = function(connInfo, entry) {
    return fieldNames.slice(0, -1).reduce(function(prev, field, idx){
        if (idx == 1) {
            // the port
            if ( Number( connInfo[field] || defaultPort ) === Number( entry[field] ) ) {
                return prev && true;
            }
        }
        return prev && (
            entry[field] === '*' ||
              entry[field] === connInfo[field]
        );
    }, true);
};


module.exports.getPassword = function(connInfo, stream, cb) {
    var pass;
    var lineStream = stream.pipe(split());

    function onLine(line) {
        var entry = parseLine(line);
        if (entry && isValidEntry(entry) && matcher(connInfo, entry)) {
            pass = entry[passKey];
            lineStream.end(); // -> calls onEnd(), but pass is set now
        }
    }

    var onEnd = function() {
        stream.destroy();
        cb(pass);
    };

    var onErr = function(err) {
        stream.destroy();
        warn('WARNING: error on reading file: %s', err);
        cb(undefined);
    };

    stream.on('error', onErr);
    lineStream
        .on('data', onLine)
        .on('end', onEnd)
        .on('error', onErr)
    ;

};


var parseLine = module.exports.parseLine = function(line) {
    if (line.length < 11 || line.match(/^\s+#/)) {
        return null;
    }

    var curChar = '';
    var prevChar = '';
    var fieldIdx = 0;
    var startIdx = 0;
    var endIdx = 0;
    var obj = {};
    var isLastField = false;
    var addToObj = function(idx, i0, i1) {
        var field = line.substring(i0, i1);

        if (! Object.hasOwnProperty.call(process.env, 'PGPASS_NO_DEESCAPE')) {
            field = field.replace(/\\([:\\])/g, '$1');
        }

        obj[ fieldNames[idx] ] = field;
    };

    for (var i = 0 ; i < line.length-1 ; i += 1) {
        curChar = line.charAt(i+1);
        prevChar = line.charAt(i);

        isLastField = (fieldIdx == nrOfFields-1);

        if (isLastField) {
            addToObj(fieldIdx, startIdx);
            break;
        }

        if (i >= 0 && curChar == ':' && prevChar !== '\\') {
            addToObj(fieldIdx, startIdx, i+1);

            startIdx = i+2;
            fieldIdx += 1;
        }
    }

    obj = ( Object.keys(obj).length === nrOfFields ) ? obj : null;

    return obj;
};


var isValidEntry = module.exports.isValidEntry = function(entry){
    var rules = {
        // host
        0 : function(x){
            return x.length > 0;
        } ,
        // port
        1 : function(x){
            if (x === '*') {
                return true;
            }
            x = Number(x);
            return (
                isFinite(x) &&
                  x > 0 &&
                  x < 9007199254740992 &&
                  Math.floor(x) === x
            );
        } ,
        // database
        2 : function(x){
            return x.length > 0;
        } ,
        // username
        3 : function(x){
            return x.length > 0;
        } ,
        // password
        4 : function(x){
            return x.length > 0;
        }
    };

    for (var idx = 0 ; idx < fieldNames.length ; idx += 1) {
        var rule = rules[idx];
        var value = entry[ fieldNames[idx] ] || '';

        var res = rule(value);
        if (!res) {
            return false;
        }
    }

    return true;
};



/***/ }),

/***/ 8812:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var path = __webpack_require__(5622)
  , fs = __webpack_require__(5747)
  , helper = __webpack_require__(8242)
;


module.exports = function(connInfo, cb) {
    var file = helper.getFileName();
    
    fs.stat(file, function(err, stat){
        if (err || !helper.usePgPass(stat, file)) {
            return cb(undefined);
        }

        var st = fs.createReadStream(file);

        helper.getPassword(connInfo, st, cb);
    });
};

module.exports.warnTo = helper.warnTo;


/***/ }),

/***/ 7315:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


exports.parse = function (source, transform) {
  return new ArrayParser(source, transform).parse()
}

class ArrayParser {
  constructor (source, transform) {
    this.source = source
    this.transform = transform || identity
    this.position = 0
    this.entries = []
    this.recorded = []
    this.dimension = 0
  }

  isEof () {
    return this.position >= this.source.length
  }

  nextCharacter () {
    var character = this.source[this.position++]
    if (character === '\\') {
      return {
        value: this.source[this.position++],
        escaped: true
      }
    }
    return {
      value: character,
      escaped: false
    }
  }

  record (character) {
    this.recorded.push(character)
  }

  newEntry (includeEmpty) {
    var entry
    if (this.recorded.length > 0 || includeEmpty) {
      entry = this.recorded.join('')
      if (entry === 'NULL' && !includeEmpty) {
        entry = null
      }
      if (entry !== null) entry = this.transform(entry)
      this.entries.push(entry)
      this.recorded = []
    }
  }

  consumeDimensions () {
    if (this.source[0] === '[') {
      while (!this.isEof()) {
        var char = this.nextCharacter()
        if (char.value === '=') break
      }
    }
  }

  parse (nested) {
    var character, parser, quote
    this.consumeDimensions()
    while (!this.isEof()) {
      character = this.nextCharacter()
      if (character.value === '{' && !quote) {
        this.dimension++
        if (this.dimension > 1) {
          parser = new ArrayParser(this.source.substr(this.position - 1), this.transform)
          this.entries.push(parser.parse(true))
          this.position += parser.position - 2
        }
      } else if (character.value === '}' && !quote) {
        this.dimension--
        if (!this.dimension) {
          this.newEntry()
          if (nested) return this.entries
        }
      } else if (character.value === '"' && !character.escaped) {
        if (quote) this.newEntry(true)
        quote = !quote
      } else if (character.value === ',' && !quote) {
        this.newEntry()
      } else {
        this.record(character.value)
      }
    }
    if (this.dimension !== 0) {
      throw new Error('array dimension not balanced')
    }
    return this.entries
  }
}

function identity (value) {
  return value
}


/***/ }),

/***/ 3712:
/***/ ((module) => {

"use strict";


module.exports = function parseBytea (input) {
  if (/^\\x/.test(input)) {
    // new 'hex' style response (pg >9.0)
    return new Buffer(input.substr(2), 'hex')
  }
  var output = ''
  var i = 0
  while (i < input.length) {
    if (input[i] !== '\\') {
      output += input[i]
      ++i
    } else {
      if (/[0-7]{3}/.test(input.substr(i + 1, 3))) {
        output += String.fromCharCode(parseInt(input.substr(i + 1, 3), 8))
        i += 4
      } else {
        var backslashes = 1
        while (i + backslashes < input.length && input[i + backslashes] === '\\') {
          backslashes++
        }
        for (var k = 0; k < Math.floor(backslashes / 2); ++k) {
          output += '\\'
        }
        i += Math.floor(backslashes / 2) * 2
      }
    }
  }
  return new Buffer(output, 'binary')
}


/***/ }),

/***/ 3765:
/***/ ((module) => {

"use strict";


var DATE_TIME = /(\d{1,})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})(\.\d{1,})?.*?( BC)?$/
var DATE = /^(\d{1,})-(\d{2})-(\d{2})( BC)?$/
var TIME_ZONE = /([Z+-])(\d{2})?:?(\d{2})?:?(\d{2})?/
var INFINITY = /^-?infinity$/

module.exports = function parseDate (isoDate) {
  if (INFINITY.test(isoDate)) {
    // Capitalize to Infinity before passing to Number
    return Number(isoDate.replace('i', 'I'))
  }
  var matches = DATE_TIME.exec(isoDate)

  if (!matches) {
    // Force YYYY-MM-DD dates to be parsed as local time
    return getDate(isoDate) || null
  }

  var isBC = !!matches[8]
  var year = parseInt(matches[1], 10)
  if (isBC) {
    year = bcYearToNegativeYear(year)
  }

  var month = parseInt(matches[2], 10) - 1
  var day = matches[3]
  var hour = parseInt(matches[4], 10)
  var minute = parseInt(matches[5], 10)
  var second = parseInt(matches[6], 10)

  var ms = matches[7]
  ms = ms ? 1000 * parseFloat(ms) : 0

  var date
  var offset = timeZoneOffset(isoDate)
  if (offset != null) {
    date = new Date(Date.UTC(year, month, day, hour, minute, second, ms))

    // Account for years from 0 to 99 being interpreted as 1900-1999
    // by Date.UTC / the multi-argument form of the Date constructor
    if (is0To99(year)) {
      date.setUTCFullYear(year)
    }

    if (offset !== 0) {
      date.setTime(date.getTime() - offset)
    }
  } else {
    date = new Date(year, month, day, hour, minute, second, ms)

    if (is0To99(year)) {
      date.setFullYear(year)
    }
  }

  return date
}

function getDate (isoDate) {
  var matches = DATE.exec(isoDate)
  if (!matches) {
    return
  }

  var year = parseInt(matches[1], 10)
  var isBC = !!matches[4]
  if (isBC) {
    year = bcYearToNegativeYear(year)
  }

  var month = parseInt(matches[2], 10) - 1
  var day = matches[3]
  // YYYY-MM-DD will be parsed as local time
  var date = new Date(year, month, day)

  if (is0To99(year)) {
    date.setFullYear(year)
  }

  return date
}

// match timezones:
// Z (UTC)
// -05
// +06:30
function timeZoneOffset (isoDate) {
  if (isoDate.endsWith('+00')) {
    return 0
  }

  var zone = TIME_ZONE.exec(isoDate.split(' ')[1])
  if (!zone) return
  var type = zone[1]

  if (type === 'Z') {
    return 0
  }
  var sign = type === '-' ? -1 : 1
  var offset = parseInt(zone[2], 10) * 3600 +
    parseInt(zone[3] || 0, 10) * 60 +
    parseInt(zone[4] || 0, 10)

  return offset * sign * 1000
}

function bcYearToNegativeYear (year) {
  // Account for numerical difference between representations of BC years
  // See: https://github.com/bendrucker/postgres-date/issues/5
  return -(year - 1)
}

function is0To99 (num) {
  return num >= 0 && num < 100
}


/***/ }),

/***/ 1055:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var extend = __webpack_require__(9820)

module.exports = PostgresInterval

function PostgresInterval (raw) {
  if (!(this instanceof PostgresInterval)) {
    return new PostgresInterval(raw)
  }
  extend(this, parse(raw))
}
var properties = ['seconds', 'minutes', 'hours', 'days', 'months', 'years']
PostgresInterval.prototype.toPostgres = function () {
  var filtered = properties.filter(this.hasOwnProperty, this)

  // In addition to `properties`, we need to account for fractions of seconds.
  if (this.milliseconds && filtered.indexOf('seconds') < 0) {
    filtered.push('seconds')
  }

  if (filtered.length === 0) return '0'
  return filtered
    .map(function (property) {
      var value = this[property] || 0

      // Account for fractional part of seconds,
      // remove trailing zeroes.
      if (property === 'seconds' && this.milliseconds) {
        value = (value + this.milliseconds / 1000).toFixed(6).replace(/\.?0+$/, '')
      }

      return value + ' ' + property
    }, this)
    .join(' ')
}

var propertiesISOEquivalent = {
  years: 'Y',
  months: 'M',
  days: 'D',
  hours: 'H',
  minutes: 'M',
  seconds: 'S'
}
var dateProperties = ['years', 'months', 'days']
var timeProperties = ['hours', 'minutes', 'seconds']
// according to ISO 8601
PostgresInterval.prototype.toISOString = PostgresInterval.prototype.toISO = function () {
  var datePart = dateProperties
    .map(buildProperty, this)
    .join('')

  var timePart = timeProperties
    .map(buildProperty, this)
    .join('')

  return 'P' + datePart + 'T' + timePart

  function buildProperty (property) {
    var value = this[property] || 0

    // Account for fractional part of seconds,
    // remove trailing zeroes.
    if (property === 'seconds' && this.milliseconds) {
      value = (value + this.milliseconds / 1000).toFixed(6).replace(/0+$/, '')
    }

    return value + propertiesISOEquivalent[property]
  }
}

var NUMBER = '([+-]?\\d+)'
var YEAR = NUMBER + '\\s+years?'
var MONTH = NUMBER + '\\s+mons?'
var DAY = NUMBER + '\\s+days?'
var TIME = '([+-])?([\\d]*):(\\d\\d):(\\d\\d)\\.?(\\d{1,6})?'
var INTERVAL = new RegExp([YEAR, MONTH, DAY, TIME].map(function (regexString) {
  return '(' + regexString + ')?'
})
  .join('\\s*'))

// Positions of values in regex match
var positions = {
  years: 2,
  months: 4,
  days: 6,
  hours: 9,
  minutes: 10,
  seconds: 11,
  milliseconds: 12
}
// We can use negative time
var negatives = ['hours', 'minutes', 'seconds', 'milliseconds']

function parseMilliseconds (fraction) {
  // add omitted zeroes
  var microseconds = fraction + '000000'.slice(fraction.length)
  return parseInt(microseconds, 10) / 1000
}

function parse (interval) {
  if (!interval) return {}
  var matches = INTERVAL.exec(interval)
  var isNegative = matches[8] === '-'
  return Object.keys(positions)
    .reduce(function (parsed, property) {
      var position = positions[property]
      var value = matches[position]
      // no empty string
      if (!value) return parsed
      // milliseconds are actually microseconds (up to 6 digits)
      // with omitted trailing zeroes.
      value = property === 'milliseconds'
        ? parseMilliseconds(value)
        : parseInt(value, 10)
      // no zeros
      if (!value) return parsed
      if (isNegative && ~negatives.indexOf(property)) {
        value *= -1
      }
      parsed[property] = value
      return parsed
    }, {})
}


/***/ }),

/***/ 4012:
/***/ ((module) => {

"use strict";


const codes = {};

function createErrorType(code, message, Base) {
  if (!Base) {
    Base = Error
  }

  function getMessage (arg1, arg2, arg3) {
    if (typeof message === 'string') {
      return message
    } else {
      return message(arg1, arg2, arg3)
    }
  }

  class NodeError extends Base {
    constructor (arg1, arg2, arg3) {
      super(getMessage(arg1, arg2, arg3));
    }
  }

  NodeError.prototype.name = Base.name;
  NodeError.prototype.code = code;

  codes[code] = NodeError;
}

// https://github.com/nodejs/node/blob/v10.8.0/lib/internal/errors.js
function oneOf(expected, thing) {
  if (Array.isArray(expected)) {
    const len = expected.length;
    expected = expected.map((i) => String(i));
    if (len > 2) {
      return `one of ${thing} ${expected.slice(0, len - 1).join(', ')}, or ` +
             expected[len - 1];
    } else if (len === 2) {
      return `one of ${thing} ${expected[0]} or ${expected[1]}`;
    } else {
      return `of ${thing} ${expected[0]}`;
    }
  } else {
    return `of ${thing} ${String(expected)}`;
  }
}

// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/startsWith
function startsWith(str, search, pos) {
	return str.substr(!pos || pos < 0 ? 0 : +pos, search.length) === search;
}

// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/endsWith
function endsWith(str, search, this_len) {
	if (this_len === undefined || this_len > str.length) {
		this_len = str.length;
	}
	return str.substring(this_len - search.length, this_len) === search;
}

// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/includes
function includes(str, search, start) {
  if (typeof start !== 'number') {
    start = 0;
  }

  if (start + search.length > str.length) {
    return false;
  } else {
    return str.indexOf(search, start) !== -1;
  }
}

createErrorType('ERR_INVALID_OPT_VALUE', function (name, value) {
  return 'The value "' + value + '" is invalid for option "' + name + '"'
}, TypeError);
createErrorType('ERR_INVALID_ARG_TYPE', function (name, expected, actual) {
  // determiner: 'must be' or 'must not be'
  let determiner;
  if (typeof expected === 'string' && startsWith(expected, 'not ')) {
    determiner = 'must not be';
    expected = expected.replace(/^not /, '');
  } else {
    determiner = 'must be';
  }

  let msg;
  if (endsWith(name, ' argument')) {
    // For cases like 'first argument'
    msg = `The ${name} ${determiner} ${oneOf(expected, 'type')}`;
  } else {
    const type = includes(name, '.') ? 'property' : 'argument';
    msg = `The "${name}" ${type} ${determiner} ${oneOf(expected, 'type')}`;
  }

  msg += `. Received type ${typeof actual}`;
  return msg;
}, TypeError);
createErrorType('ERR_STREAM_PUSH_AFTER_EOF', 'stream.push() after EOF');
createErrorType('ERR_METHOD_NOT_IMPLEMENTED', function (name) {
  return 'The ' + name + ' method is not implemented'
});
createErrorType('ERR_STREAM_PREMATURE_CLOSE', 'Premature close');
createErrorType('ERR_STREAM_DESTROYED', function (name) {
  return 'Cannot call ' + name + ' after a stream was destroyed';
});
createErrorType('ERR_MULTIPLE_CALLBACK', 'Callback called multiple times');
createErrorType('ERR_STREAM_CANNOT_PIPE', 'Cannot pipe, not readable');
createErrorType('ERR_STREAM_WRITE_AFTER_END', 'write after end');
createErrorType('ERR_STREAM_NULL_VALUES', 'May not write null values to stream', TypeError);
createErrorType('ERR_UNKNOWN_ENCODING', function (arg) {
  return 'Unknown encoding: ' + arg
}, TypeError);
createErrorType('ERR_STREAM_UNSHIFT_AFTER_END_EVENT', 'stream.unshift() after end event');

module.exports.q = codes;


/***/ }),

/***/ 6753:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.
// a duplex stream is just a stream that is both readable and writable.
// Since JS doesn't have multiple prototypal inheritance, this class
// prototypally inherits from Readable, and then parasitically from
// Writable.

/*<replacement>*/

var objectKeys = Object.keys || function (obj) {
  var keys = [];

  for (var key in obj) {
    keys.push(key);
  }

  return keys;
};
/*</replacement>*/


module.exports = Duplex;

var Readable = __webpack_require__(9481);

var Writable = __webpack_require__(4229);

__webpack_require__(4378)(Duplex, Readable);

{
  // Allow the keys array to be GC'ed.
  var keys = objectKeys(Writable.prototype);

  for (var v = 0; v < keys.length; v++) {
    var method = keys[v];
    if (!Duplex.prototype[method]) Duplex.prototype[method] = Writable.prototype[method];
  }
}

function Duplex(options) {
  if (!(this instanceof Duplex)) return new Duplex(options);
  Readable.call(this, options);
  Writable.call(this, options);
  this.allowHalfOpen = true;

  if (options) {
    if (options.readable === false) this.readable = false;
    if (options.writable === false) this.writable = false;

    if (options.allowHalfOpen === false) {
      this.allowHalfOpen = false;
      this.once('end', onend);
    }
  }
}

Object.defineProperty(Duplex.prototype, 'writableHighWaterMark', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._writableState.highWaterMark;
  }
});
Object.defineProperty(Duplex.prototype, 'writableBuffer', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._writableState && this._writableState.getBuffer();
  }
});
Object.defineProperty(Duplex.prototype, 'writableLength', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._writableState.length;
  }
}); // the no-half-open enforcer

function onend() {
  // If the writable side ended, then we're ok.
  if (this._writableState.ended) return; // no more data can be written.
  // But allow more writes to happen in this tick.

  process.nextTick(onEndNT, this);
}

function onEndNT(self) {
  self.end();
}

Object.defineProperty(Duplex.prototype, 'destroyed', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    if (this._readableState === undefined || this._writableState === undefined) {
      return false;
    }

    return this._readableState.destroyed && this._writableState.destroyed;
  },
  set: function set(value) {
    // we ignore the value if the stream
    // has not been initialized yet
    if (this._readableState === undefined || this._writableState === undefined) {
      return;
    } // backward compatibility, the user is explicitly
    // managing destroyed


    this._readableState.destroyed = value;
    this._writableState.destroyed = value;
  }
});

/***/ }),

/***/ 2725:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.
// a passthrough stream.
// basically just the most minimal sort of Transform stream.
// Every written chunk gets output as-is.


module.exports = PassThrough;

var Transform = __webpack_require__(4605);

__webpack_require__(4378)(PassThrough, Transform);

function PassThrough(options) {
  if (!(this instanceof PassThrough)) return new PassThrough(options);
  Transform.call(this, options);
}

PassThrough.prototype._transform = function (chunk, encoding, cb) {
  cb(null, chunk);
};

/***/ }),

/***/ 9481:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.


module.exports = Readable;
/*<replacement>*/

var Duplex;
/*</replacement>*/

Readable.ReadableState = ReadableState;
/*<replacement>*/

var EE = __webpack_require__(8614).EventEmitter;

var EElistenerCount = function EElistenerCount(emitter, type) {
  return emitter.listeners(type).length;
};
/*</replacement>*/

/*<replacement>*/


var Stream = __webpack_require__(9740);
/*</replacement>*/


var Buffer = __webpack_require__(4293).Buffer;

var OurUint8Array = global.Uint8Array || function () {};

function _uint8ArrayToBuffer(chunk) {
  return Buffer.from(chunk);
}

function _isUint8Array(obj) {
  return Buffer.isBuffer(obj) || obj instanceof OurUint8Array;
}
/*<replacement>*/


var debugUtil = __webpack_require__(1669);

var debug;

if (debugUtil && debugUtil.debuglog) {
  debug = debugUtil.debuglog('stream');
} else {
  debug = function debug() {};
}
/*</replacement>*/


var BufferList = __webpack_require__(7327);

var destroyImpl = __webpack_require__(1195);

var _require = __webpack_require__(2457),
    getHighWaterMark = _require.getHighWaterMark;

var _require$codes = __webpack_require__(4012)/* .codes */ .q,
    ERR_INVALID_ARG_TYPE = _require$codes.ERR_INVALID_ARG_TYPE,
    ERR_STREAM_PUSH_AFTER_EOF = _require$codes.ERR_STREAM_PUSH_AFTER_EOF,
    ERR_METHOD_NOT_IMPLEMENTED = _require$codes.ERR_METHOD_NOT_IMPLEMENTED,
    ERR_STREAM_UNSHIFT_AFTER_END_EVENT = _require$codes.ERR_STREAM_UNSHIFT_AFTER_END_EVENT; // Lazy loaded to improve the startup performance.


var StringDecoder;
var createReadableStreamAsyncIterator;
var from;

__webpack_require__(4378)(Readable, Stream);

var errorOrDestroy = destroyImpl.errorOrDestroy;
var kProxyEvents = ['error', 'close', 'destroy', 'pause', 'resume'];

function prependListener(emitter, event, fn) {
  // Sadly this is not cacheable as some libraries bundle their own
  // event emitter implementation with them.
  if (typeof emitter.prependListener === 'function') return emitter.prependListener(event, fn); // This is a hack to make sure that our error handler is attached before any
  // userland ones.  NEVER DO THIS. This is here only because this code needs
  // to continue to work with older versions of Node.js that do not include
  // the prependListener() method. The goal is to eventually remove this hack.

  if (!emitter._events || !emitter._events[event]) emitter.on(event, fn);else if (Array.isArray(emitter._events[event])) emitter._events[event].unshift(fn);else emitter._events[event] = [fn, emitter._events[event]];
}

function ReadableState(options, stream, isDuplex) {
  Duplex = Duplex || __webpack_require__(6753);
  options = options || {}; // Duplex streams are both readable and writable, but share
  // the same options object.
  // However, some cases require setting options to different
  // values for the readable and the writable sides of the duplex stream.
  // These options can be provided separately as readableXXX and writableXXX.

  if (typeof isDuplex !== 'boolean') isDuplex = stream instanceof Duplex; // object stream flag. Used to make read(n) ignore n and to
  // make all the buffer merging and length checks go away

  this.objectMode = !!options.objectMode;
  if (isDuplex) this.objectMode = this.objectMode || !!options.readableObjectMode; // the point at which it stops calling _read() to fill the buffer
  // Note: 0 is a valid value, means "don't call _read preemptively ever"

  this.highWaterMark = getHighWaterMark(this, options, 'readableHighWaterMark', isDuplex); // A linked list is used to store data chunks instead of an array because the
  // linked list can remove elements from the beginning faster than
  // array.shift()

  this.buffer = new BufferList();
  this.length = 0;
  this.pipes = null;
  this.pipesCount = 0;
  this.flowing = null;
  this.ended = false;
  this.endEmitted = false;
  this.reading = false; // a flag to be able to tell if the event 'readable'/'data' is emitted
  // immediately, or on a later tick.  We set this to true at first, because
  // any actions that shouldn't happen until "later" should generally also
  // not happen before the first read call.

  this.sync = true; // whenever we return null, then we set a flag to say
  // that we're awaiting a 'readable' event emission.

  this.needReadable = false;
  this.emittedReadable = false;
  this.readableListening = false;
  this.resumeScheduled = false;
  this.paused = true; // Should close be emitted on destroy. Defaults to true.

  this.emitClose = options.emitClose !== false; // Should .destroy() be called after 'end' (and potentially 'finish')

  this.autoDestroy = !!options.autoDestroy; // has it been destroyed

  this.destroyed = false; // Crypto is kind of old and crusty.  Historically, its default string
  // encoding is 'binary' so we have to make this configurable.
  // Everything else in the universe uses 'utf8', though.

  this.defaultEncoding = options.defaultEncoding || 'utf8'; // the number of writers that are awaiting a drain event in .pipe()s

  this.awaitDrain = 0; // if true, a maybeReadMore has been scheduled

  this.readingMore = false;
  this.decoder = null;
  this.encoding = null;

  if (options.encoding) {
    if (!StringDecoder) StringDecoder = __webpack_require__(2553)/* .StringDecoder */ .s;
    this.decoder = new StringDecoder(options.encoding);
    this.encoding = options.encoding;
  }
}

function Readable(options) {
  Duplex = Duplex || __webpack_require__(6753);
  if (!(this instanceof Readable)) return new Readable(options); // Checking for a Stream.Duplex instance is faster here instead of inside
  // the ReadableState constructor, at least with V8 6.5

  var isDuplex = this instanceof Duplex;
  this._readableState = new ReadableState(options, this, isDuplex); // legacy

  this.readable = true;

  if (options) {
    if (typeof options.read === 'function') this._read = options.read;
    if (typeof options.destroy === 'function') this._destroy = options.destroy;
  }

  Stream.call(this);
}

Object.defineProperty(Readable.prototype, 'destroyed', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    if (this._readableState === undefined) {
      return false;
    }

    return this._readableState.destroyed;
  },
  set: function set(value) {
    // we ignore the value if the stream
    // has not been initialized yet
    if (!this._readableState) {
      return;
    } // backward compatibility, the user is explicitly
    // managing destroyed


    this._readableState.destroyed = value;
  }
});
Readable.prototype.destroy = destroyImpl.destroy;
Readable.prototype._undestroy = destroyImpl.undestroy;

Readable.prototype._destroy = function (err, cb) {
  cb(err);
}; // Manually shove something into the read() buffer.
// This returns true if the highWaterMark has not been hit yet,
// similar to how Writable.write() returns true if you should
// write() some more.


Readable.prototype.push = function (chunk, encoding) {
  var state = this._readableState;
  var skipChunkCheck;

  if (!state.objectMode) {
    if (typeof chunk === 'string') {
      encoding = encoding || state.defaultEncoding;

      if (encoding !== state.encoding) {
        chunk = Buffer.from(chunk, encoding);
        encoding = '';
      }

      skipChunkCheck = true;
    }
  } else {
    skipChunkCheck = true;
  }

  return readableAddChunk(this, chunk, encoding, false, skipChunkCheck);
}; // Unshift should *always* be something directly out of read()


Readable.prototype.unshift = function (chunk) {
  return readableAddChunk(this, chunk, null, true, false);
};

function readableAddChunk(stream, chunk, encoding, addToFront, skipChunkCheck) {
  debug('readableAddChunk', chunk);
  var state = stream._readableState;

  if (chunk === null) {
    state.reading = false;
    onEofChunk(stream, state);
  } else {
    var er;
    if (!skipChunkCheck) er = chunkInvalid(state, chunk);

    if (er) {
      errorOrDestroy(stream, er);
    } else if (state.objectMode || chunk && chunk.length > 0) {
      if (typeof chunk !== 'string' && !state.objectMode && Object.getPrototypeOf(chunk) !== Buffer.prototype) {
        chunk = _uint8ArrayToBuffer(chunk);
      }

      if (addToFront) {
        if (state.endEmitted) errorOrDestroy(stream, new ERR_STREAM_UNSHIFT_AFTER_END_EVENT());else addChunk(stream, state, chunk, true);
      } else if (state.ended) {
        errorOrDestroy(stream, new ERR_STREAM_PUSH_AFTER_EOF());
      } else if (state.destroyed) {
        return false;
      } else {
        state.reading = false;

        if (state.decoder && !encoding) {
          chunk = state.decoder.write(chunk);
          if (state.objectMode || chunk.length !== 0) addChunk(stream, state, chunk, false);else maybeReadMore(stream, state);
        } else {
          addChunk(stream, state, chunk, false);
        }
      }
    } else if (!addToFront) {
      state.reading = false;
      maybeReadMore(stream, state);
    }
  } // We can push more data if we are below the highWaterMark.
  // Also, if we have no data yet, we can stand some more bytes.
  // This is to work around cases where hwm=0, such as the repl.


  return !state.ended && (state.length < state.highWaterMark || state.length === 0);
}

function addChunk(stream, state, chunk, addToFront) {
  if (state.flowing && state.length === 0 && !state.sync) {
    state.awaitDrain = 0;
    stream.emit('data', chunk);
  } else {
    // update the buffer info.
    state.length += state.objectMode ? 1 : chunk.length;
    if (addToFront) state.buffer.unshift(chunk);else state.buffer.push(chunk);
    if (state.needReadable) emitReadable(stream);
  }

  maybeReadMore(stream, state);
}

function chunkInvalid(state, chunk) {
  var er;

  if (!_isUint8Array(chunk) && typeof chunk !== 'string' && chunk !== undefined && !state.objectMode) {
    er = new ERR_INVALID_ARG_TYPE('chunk', ['string', 'Buffer', 'Uint8Array'], chunk);
  }

  return er;
}

Readable.prototype.isPaused = function () {
  return this._readableState.flowing === false;
}; // backwards compatibility.


Readable.prototype.setEncoding = function (enc) {
  if (!StringDecoder) StringDecoder = __webpack_require__(2553)/* .StringDecoder */ .s;
  var decoder = new StringDecoder(enc);
  this._readableState.decoder = decoder; // If setEncoding(null), decoder.encoding equals utf8

  this._readableState.encoding = this._readableState.decoder.encoding; // Iterate over current buffer to convert already stored Buffers:

  var p = this._readableState.buffer.head;
  var content = '';

  while (p !== null) {
    content += decoder.write(p.data);
    p = p.next;
  }

  this._readableState.buffer.clear();

  if (content !== '') this._readableState.buffer.push(content);
  this._readableState.length = content.length;
  return this;
}; // Don't raise the hwm > 1GB


var MAX_HWM = 0x40000000;

function computeNewHighWaterMark(n) {
  if (n >= MAX_HWM) {
    // TODO(ronag): Throw ERR_VALUE_OUT_OF_RANGE.
    n = MAX_HWM;
  } else {
    // Get the next highest power of 2 to prevent increasing hwm excessively in
    // tiny amounts
    n--;
    n |= n >>> 1;
    n |= n >>> 2;
    n |= n >>> 4;
    n |= n >>> 8;
    n |= n >>> 16;
    n++;
  }

  return n;
} // This function is designed to be inlinable, so please take care when making
// changes to the function body.


function howMuchToRead(n, state) {
  if (n <= 0 || state.length === 0 && state.ended) return 0;
  if (state.objectMode) return 1;

  if (n !== n) {
    // Only flow one buffer at a time
    if (state.flowing && state.length) return state.buffer.head.data.length;else return state.length;
  } // If we're asking for more than the current hwm, then raise the hwm.


  if (n > state.highWaterMark) state.highWaterMark = computeNewHighWaterMark(n);
  if (n <= state.length) return n; // Don't have enough

  if (!state.ended) {
    state.needReadable = true;
    return 0;
  }

  return state.length;
} // you can override either this method, or the async _read(n) below.


Readable.prototype.read = function (n) {
  debug('read', n);
  n = parseInt(n, 10);
  var state = this._readableState;
  var nOrig = n;
  if (n !== 0) state.emittedReadable = false; // if we're doing read(0) to trigger a readable event, but we
  // already have a bunch of data in the buffer, then just trigger
  // the 'readable' event and move on.

  if (n === 0 && state.needReadable && ((state.highWaterMark !== 0 ? state.length >= state.highWaterMark : state.length > 0) || state.ended)) {
    debug('read: emitReadable', state.length, state.ended);
    if (state.length === 0 && state.ended) endReadable(this);else emitReadable(this);
    return null;
  }

  n = howMuchToRead(n, state); // if we've ended, and we're now clear, then finish it up.

  if (n === 0 && state.ended) {
    if (state.length === 0) endReadable(this);
    return null;
  } // All the actual chunk generation logic needs to be
  // *below* the call to _read.  The reason is that in certain
  // synthetic stream cases, such as passthrough streams, _read
  // may be a completely synchronous operation which may change
  // the state of the read buffer, providing enough data when
  // before there was *not* enough.
  //
  // So, the steps are:
  // 1. Figure out what the state of things will be after we do
  // a read from the buffer.
  //
  // 2. If that resulting state will trigger a _read, then call _read.
  // Note that this may be asynchronous, or synchronous.  Yes, it is
  // deeply ugly to write APIs this way, but that still doesn't mean
  // that the Readable class should behave improperly, as streams are
  // designed to be sync/async agnostic.
  // Take note if the _read call is sync or async (ie, if the read call
  // has returned yet), so that we know whether or not it's safe to emit
  // 'readable' etc.
  //
  // 3. Actually pull the requested chunks out of the buffer and return.
  // if we need a readable event, then we need to do some reading.


  var doRead = state.needReadable;
  debug('need readable', doRead); // if we currently have less than the highWaterMark, then also read some

  if (state.length === 0 || state.length - n < state.highWaterMark) {
    doRead = true;
    debug('length less than watermark', doRead);
  } // however, if we've ended, then there's no point, and if we're already
  // reading, then it's unnecessary.


  if (state.ended || state.reading) {
    doRead = false;
    debug('reading or ended', doRead);
  } else if (doRead) {
    debug('do read');
    state.reading = true;
    state.sync = true; // if the length is currently zero, then we *need* a readable event.

    if (state.length === 0) state.needReadable = true; // call internal read method

    this._read(state.highWaterMark);

    state.sync = false; // If _read pushed data synchronously, then `reading` will be false,
    // and we need to re-evaluate how much data we can return to the user.

    if (!state.reading) n = howMuchToRead(nOrig, state);
  }

  var ret;
  if (n > 0) ret = fromList(n, state);else ret = null;

  if (ret === null) {
    state.needReadable = state.length <= state.highWaterMark;
    n = 0;
  } else {
    state.length -= n;
    state.awaitDrain = 0;
  }

  if (state.length === 0) {
    // If we have nothing in the buffer, then we want to know
    // as soon as we *do* get something into the buffer.
    if (!state.ended) state.needReadable = true; // If we tried to read() past the EOF, then emit end on the next tick.

    if (nOrig !== n && state.ended) endReadable(this);
  }

  if (ret !== null) this.emit('data', ret);
  return ret;
};

function onEofChunk(stream, state) {
  debug('onEofChunk');
  if (state.ended) return;

  if (state.decoder) {
    var chunk = state.decoder.end();

    if (chunk && chunk.length) {
      state.buffer.push(chunk);
      state.length += state.objectMode ? 1 : chunk.length;
    }
  }

  state.ended = true;

  if (state.sync) {
    // if we are sync, wait until next tick to emit the data.
    // Otherwise we risk emitting data in the flow()
    // the readable code triggers during a read() call
    emitReadable(stream);
  } else {
    // emit 'readable' now to make sure it gets picked up.
    state.needReadable = false;

    if (!state.emittedReadable) {
      state.emittedReadable = true;
      emitReadable_(stream);
    }
  }
} // Don't emit readable right away in sync mode, because this can trigger
// another read() call => stack overflow.  This way, it might trigger
// a nextTick recursion warning, but that's not so bad.


function emitReadable(stream) {
  var state = stream._readableState;
  debug('emitReadable', state.needReadable, state.emittedReadable);
  state.needReadable = false;

  if (!state.emittedReadable) {
    debug('emitReadable', state.flowing);
    state.emittedReadable = true;
    process.nextTick(emitReadable_, stream);
  }
}

function emitReadable_(stream) {
  var state = stream._readableState;
  debug('emitReadable_', state.destroyed, state.length, state.ended);

  if (!state.destroyed && (state.length || state.ended)) {
    stream.emit('readable');
    state.emittedReadable = false;
  } // The stream needs another readable event if
  // 1. It is not flowing, as the flow mechanism will take
  //    care of it.
  // 2. It is not ended.
  // 3. It is below the highWaterMark, so we can schedule
  //    another readable later.


  state.needReadable = !state.flowing && !state.ended && state.length <= state.highWaterMark;
  flow(stream);
} // at this point, the user has presumably seen the 'readable' event,
// and called read() to consume some data.  that may have triggered
// in turn another _read(n) call, in which case reading = true if
// it's in progress.
// However, if we're not ended, or reading, and the length < hwm,
// then go ahead and try to read some more preemptively.


function maybeReadMore(stream, state) {
  if (!state.readingMore) {
    state.readingMore = true;
    process.nextTick(maybeReadMore_, stream, state);
  }
}

function maybeReadMore_(stream, state) {
  // Attempt to read more data if we should.
  //
  // The conditions for reading more data are (one of):
  // - Not enough data buffered (state.length < state.highWaterMark). The loop
  //   is responsible for filling the buffer with enough data if such data
  //   is available. If highWaterMark is 0 and we are not in the flowing mode
  //   we should _not_ attempt to buffer any extra data. We'll get more data
  //   when the stream consumer calls read() instead.
  // - No data in the buffer, and the stream is in flowing mode. In this mode
  //   the loop below is responsible for ensuring read() is called. Failing to
  //   call read here would abort the flow and there's no other mechanism for
  //   continuing the flow if the stream consumer has just subscribed to the
  //   'data' event.
  //
  // In addition to the above conditions to keep reading data, the following
  // conditions prevent the data from being read:
  // - The stream has ended (state.ended).
  // - There is already a pending 'read' operation (state.reading). This is a
  //   case where the the stream has called the implementation defined _read()
  //   method, but they are processing the call asynchronously and have _not_
  //   called push() with new data. In this case we skip performing more
  //   read()s. The execution ends in this method again after the _read() ends
  //   up calling push() with more data.
  while (!state.reading && !state.ended && (state.length < state.highWaterMark || state.flowing && state.length === 0)) {
    var len = state.length;
    debug('maybeReadMore read 0');
    stream.read(0);
    if (len === state.length) // didn't get any data, stop spinning.
      break;
  }

  state.readingMore = false;
} // abstract method.  to be overridden in specific implementation classes.
// call cb(er, data) where data is <= n in length.
// for virtual (non-string, non-buffer) streams, "length" is somewhat
// arbitrary, and perhaps not very meaningful.


Readable.prototype._read = function (n) {
  errorOrDestroy(this, new ERR_METHOD_NOT_IMPLEMENTED('_read()'));
};

Readable.prototype.pipe = function (dest, pipeOpts) {
  var src = this;
  var state = this._readableState;

  switch (state.pipesCount) {
    case 0:
      state.pipes = dest;
      break;

    case 1:
      state.pipes = [state.pipes, dest];
      break;

    default:
      state.pipes.push(dest);
      break;
  }

  state.pipesCount += 1;
  debug('pipe count=%d opts=%j', state.pipesCount, pipeOpts);
  var doEnd = (!pipeOpts || pipeOpts.end !== false) && dest !== process.stdout && dest !== process.stderr;
  var endFn = doEnd ? onend : unpipe;
  if (state.endEmitted) process.nextTick(endFn);else src.once('end', endFn);
  dest.on('unpipe', onunpipe);

  function onunpipe(readable, unpipeInfo) {
    debug('onunpipe');

    if (readable === src) {
      if (unpipeInfo && unpipeInfo.hasUnpiped === false) {
        unpipeInfo.hasUnpiped = true;
        cleanup();
      }
    }
  }

  function onend() {
    debug('onend');
    dest.end();
  } // when the dest drains, it reduces the awaitDrain counter
  // on the source.  This would be more elegant with a .once()
  // handler in flow(), but adding and removing repeatedly is
  // too slow.


  var ondrain = pipeOnDrain(src);
  dest.on('drain', ondrain);
  var cleanedUp = false;

  function cleanup() {
    debug('cleanup'); // cleanup event handlers once the pipe is broken

    dest.removeListener('close', onclose);
    dest.removeListener('finish', onfinish);
    dest.removeListener('drain', ondrain);
    dest.removeListener('error', onerror);
    dest.removeListener('unpipe', onunpipe);
    src.removeListener('end', onend);
    src.removeListener('end', unpipe);
    src.removeListener('data', ondata);
    cleanedUp = true; // if the reader is waiting for a drain event from this
    // specific writer, then it would cause it to never start
    // flowing again.
    // So, if this is awaiting a drain, then we just call it now.
    // If we don't know, then assume that we are waiting for one.

    if (state.awaitDrain && (!dest._writableState || dest._writableState.needDrain)) ondrain();
  }

  src.on('data', ondata);

  function ondata(chunk) {
    debug('ondata');
    var ret = dest.write(chunk);
    debug('dest.write', ret);

    if (ret === false) {
      // If the user unpiped during `dest.write()`, it is possible
      // to get stuck in a permanently paused state if that write
      // also returned false.
      // => Check whether `dest` is still a piping destination.
      if ((state.pipesCount === 1 && state.pipes === dest || state.pipesCount > 1 && indexOf(state.pipes, dest) !== -1) && !cleanedUp) {
        debug('false write response, pause', state.awaitDrain);
        state.awaitDrain++;
      }

      src.pause();
    }
  } // if the dest has an error, then stop piping into it.
  // however, don't suppress the throwing behavior for this.


  function onerror(er) {
    debug('onerror', er);
    unpipe();
    dest.removeListener('error', onerror);
    if (EElistenerCount(dest, 'error') === 0) errorOrDestroy(dest, er);
  } // Make sure our error handler is attached before userland ones.


  prependListener(dest, 'error', onerror); // Both close and finish should trigger unpipe, but only once.

  function onclose() {
    dest.removeListener('finish', onfinish);
    unpipe();
  }

  dest.once('close', onclose);

  function onfinish() {
    debug('onfinish');
    dest.removeListener('close', onclose);
    unpipe();
  }

  dest.once('finish', onfinish);

  function unpipe() {
    debug('unpipe');
    src.unpipe(dest);
  } // tell the dest that it's being piped to


  dest.emit('pipe', src); // start the flow if it hasn't been started already.

  if (!state.flowing) {
    debug('pipe resume');
    src.resume();
  }

  return dest;
};

function pipeOnDrain(src) {
  return function pipeOnDrainFunctionResult() {
    var state = src._readableState;
    debug('pipeOnDrain', state.awaitDrain);
    if (state.awaitDrain) state.awaitDrain--;

    if (state.awaitDrain === 0 && EElistenerCount(src, 'data')) {
      state.flowing = true;
      flow(src);
    }
  };
}

Readable.prototype.unpipe = function (dest) {
  var state = this._readableState;
  var unpipeInfo = {
    hasUnpiped: false
  }; // if we're not piping anywhere, then do nothing.

  if (state.pipesCount === 0) return this; // just one destination.  most common case.

  if (state.pipesCount === 1) {
    // passed in one, but it's not the right one.
    if (dest && dest !== state.pipes) return this;
    if (!dest) dest = state.pipes; // got a match.

    state.pipes = null;
    state.pipesCount = 0;
    state.flowing = false;
    if (dest) dest.emit('unpipe', this, unpipeInfo);
    return this;
  } // slow case. multiple pipe destinations.


  if (!dest) {
    // remove all.
    var dests = state.pipes;
    var len = state.pipesCount;
    state.pipes = null;
    state.pipesCount = 0;
    state.flowing = false;

    for (var i = 0; i < len; i++) {
      dests[i].emit('unpipe', this, {
        hasUnpiped: false
      });
    }

    return this;
  } // try to find the right one.


  var index = indexOf(state.pipes, dest);
  if (index === -1) return this;
  state.pipes.splice(index, 1);
  state.pipesCount -= 1;
  if (state.pipesCount === 1) state.pipes = state.pipes[0];
  dest.emit('unpipe', this, unpipeInfo);
  return this;
}; // set up data events if they are asked for
// Ensure readable listeners eventually get something


Readable.prototype.on = function (ev, fn) {
  var res = Stream.prototype.on.call(this, ev, fn);
  var state = this._readableState;

  if (ev === 'data') {
    // update readableListening so that resume() may be a no-op
    // a few lines down. This is needed to support once('readable').
    state.readableListening = this.listenerCount('readable') > 0; // Try start flowing on next tick if stream isn't explicitly paused

    if (state.flowing !== false) this.resume();
  } else if (ev === 'readable') {
    if (!state.endEmitted && !state.readableListening) {
      state.readableListening = state.needReadable = true;
      state.flowing = false;
      state.emittedReadable = false;
      debug('on readable', state.length, state.reading);

      if (state.length) {
        emitReadable(this);
      } else if (!state.reading) {
        process.nextTick(nReadingNextTick, this);
      }
    }
  }

  return res;
};

Readable.prototype.addListener = Readable.prototype.on;

Readable.prototype.removeListener = function (ev, fn) {
  var res = Stream.prototype.removeListener.call(this, ev, fn);

  if (ev === 'readable') {
    // We need to check if there is someone still listening to
    // readable and reset the state. However this needs to happen
    // after readable has been emitted but before I/O (nextTick) to
    // support once('readable', fn) cycles. This means that calling
    // resume within the same tick will have no
    // effect.
    process.nextTick(updateReadableListening, this);
  }

  return res;
};

Readable.prototype.removeAllListeners = function (ev) {
  var res = Stream.prototype.removeAllListeners.apply(this, arguments);

  if (ev === 'readable' || ev === undefined) {
    // We need to check if there is someone still listening to
    // readable and reset the state. However this needs to happen
    // after readable has been emitted but before I/O (nextTick) to
    // support once('readable', fn) cycles. This means that calling
    // resume within the same tick will have no
    // effect.
    process.nextTick(updateReadableListening, this);
  }

  return res;
};

function updateReadableListening(self) {
  var state = self._readableState;
  state.readableListening = self.listenerCount('readable') > 0;

  if (state.resumeScheduled && !state.paused) {
    // flowing needs to be set to true now, otherwise
    // the upcoming resume will not flow.
    state.flowing = true; // crude way to check if we should resume
  } else if (self.listenerCount('data') > 0) {
    self.resume();
  }
}

function nReadingNextTick(self) {
  debug('readable nexttick read 0');
  self.read(0);
} // pause() and resume() are remnants of the legacy readable stream API
// If the user uses them, then switch into old mode.


Readable.prototype.resume = function () {
  var state = this._readableState;

  if (!state.flowing) {
    debug('resume'); // we flow only if there is no one listening
    // for readable, but we still have to call
    // resume()

    state.flowing = !state.readableListening;
    resume(this, state);
  }

  state.paused = false;
  return this;
};

function resume(stream, state) {
  if (!state.resumeScheduled) {
    state.resumeScheduled = true;
    process.nextTick(resume_, stream, state);
  }
}

function resume_(stream, state) {
  debug('resume', state.reading);

  if (!state.reading) {
    stream.read(0);
  }

  state.resumeScheduled = false;
  stream.emit('resume');
  flow(stream);
  if (state.flowing && !state.reading) stream.read(0);
}

Readable.prototype.pause = function () {
  debug('call pause flowing=%j', this._readableState.flowing);

  if (this._readableState.flowing !== false) {
    debug('pause');
    this._readableState.flowing = false;
    this.emit('pause');
  }

  this._readableState.paused = true;
  return this;
};

function flow(stream) {
  var state = stream._readableState;
  debug('flow', state.flowing);

  while (state.flowing && stream.read() !== null) {
    ;
  }
} // wrap an old-style stream as the async data source.
// This is *not* part of the readable stream interface.
// It is an ugly unfortunate mess of history.


Readable.prototype.wrap = function (stream) {
  var _this = this;

  var state = this._readableState;
  var paused = false;
  stream.on('end', function () {
    debug('wrapped end');

    if (state.decoder && !state.ended) {
      var chunk = state.decoder.end();
      if (chunk && chunk.length) _this.push(chunk);
    }

    _this.push(null);
  });
  stream.on('data', function (chunk) {
    debug('wrapped data');
    if (state.decoder) chunk = state.decoder.write(chunk); // don't skip over falsy values in objectMode

    if (state.objectMode && (chunk === null || chunk === undefined)) return;else if (!state.objectMode && (!chunk || !chunk.length)) return;

    var ret = _this.push(chunk);

    if (!ret) {
      paused = true;
      stream.pause();
    }
  }); // proxy all the other methods.
  // important when wrapping filters and duplexes.

  for (var i in stream) {
    if (this[i] === undefined && typeof stream[i] === 'function') {
      this[i] = function methodWrap(method) {
        return function methodWrapReturnFunction() {
          return stream[method].apply(stream, arguments);
        };
      }(i);
    }
  } // proxy certain important events.


  for (var n = 0; n < kProxyEvents.length; n++) {
    stream.on(kProxyEvents[n], this.emit.bind(this, kProxyEvents[n]));
  } // when we try to consume some more bytes, simply unpause the
  // underlying stream.


  this._read = function (n) {
    debug('wrapped _read', n);

    if (paused) {
      paused = false;
      stream.resume();
    }
  };

  return this;
};

if (typeof Symbol === 'function') {
  Readable.prototype[Symbol.asyncIterator] = function () {
    if (createReadableStreamAsyncIterator === undefined) {
      createReadableStreamAsyncIterator = __webpack_require__(5850);
    }

    return createReadableStreamAsyncIterator(this);
  };
}

Object.defineProperty(Readable.prototype, 'readableHighWaterMark', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._readableState.highWaterMark;
  }
});
Object.defineProperty(Readable.prototype, 'readableBuffer', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._readableState && this._readableState.buffer;
  }
});
Object.defineProperty(Readable.prototype, 'readableFlowing', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._readableState.flowing;
  },
  set: function set(state) {
    if (this._readableState) {
      this._readableState.flowing = state;
    }
  }
}); // exposed for testing purposes only.

Readable._fromList = fromList;
Object.defineProperty(Readable.prototype, 'readableLength', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._readableState.length;
  }
}); // Pluck off n bytes from an array of buffers.
// Length is the combined lengths of all the buffers in the list.
// This function is designed to be inlinable, so please take care when making
// changes to the function body.

function fromList(n, state) {
  // nothing buffered
  if (state.length === 0) return null;
  var ret;
  if (state.objectMode) ret = state.buffer.shift();else if (!n || n >= state.length) {
    // read it all, truncate the list
    if (state.decoder) ret = state.buffer.join('');else if (state.buffer.length === 1) ret = state.buffer.first();else ret = state.buffer.concat(state.length);
    state.buffer.clear();
  } else {
    // read part of list
    ret = state.buffer.consume(n, state.decoder);
  }
  return ret;
}

function endReadable(stream) {
  var state = stream._readableState;
  debug('endReadable', state.endEmitted);

  if (!state.endEmitted) {
    state.ended = true;
    process.nextTick(endReadableNT, state, stream);
  }
}

function endReadableNT(state, stream) {
  debug('endReadableNT', state.endEmitted, state.length); // Check that we didn't get one last unshift.

  if (!state.endEmitted && state.length === 0) {
    state.endEmitted = true;
    stream.readable = false;
    stream.emit('end');

    if (state.autoDestroy) {
      // In case of duplex streams we need a way to detect
      // if the writable side is ready for autoDestroy as well
      var wState = stream._writableState;

      if (!wState || wState.autoDestroy && wState.finished) {
        stream.destroy();
      }
    }
  }
}

if (typeof Symbol === 'function') {
  Readable.from = function (iterable, opts) {
    if (from === undefined) {
      from = __webpack_require__(6307);
    }

    return from(Readable, iterable, opts);
  };
}

function indexOf(xs, x) {
  for (var i = 0, l = xs.length; i < l; i++) {
    if (xs[i] === x) return i;
  }

  return -1;
}

/***/ }),

/***/ 4605:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.
// a transform stream is a readable/writable stream where you do
// something with the data.  Sometimes it's called a "filter",
// but that's not a great name for it, since that implies a thing where
// some bits pass through, and others are simply ignored.  (That would
// be a valid example of a transform, of course.)
//
// While the output is causally related to the input, it's not a
// necessarily symmetric or synchronous transformation.  For example,
// a zlib stream might take multiple plain-text writes(), and then
// emit a single compressed chunk some time in the future.
//
// Here's how this works:
//
// The Transform stream has all the aspects of the readable and writable
// stream classes.  When you write(chunk), that calls _write(chunk,cb)
// internally, and returns false if there's a lot of pending writes
// buffered up.  When you call read(), that calls _read(n) until
// there's enough pending readable data buffered up.
//
// In a transform stream, the written data is placed in a buffer.  When
// _read(n) is called, it transforms the queued up data, calling the
// buffered _write cb's as it consumes chunks.  If consuming a single
// written chunk would result in multiple output chunks, then the first
// outputted bit calls the readcb, and subsequent chunks just go into
// the read buffer, and will cause it to emit 'readable' if necessary.
//
// This way, back-pressure is actually determined by the reading side,
// since _read has to be called to start processing a new chunk.  However,
// a pathological inflate type of transform can cause excessive buffering
// here.  For example, imagine a stream where every byte of input is
// interpreted as an integer from 0-255, and then results in that many
// bytes of output.  Writing the 4 bytes {ff,ff,ff,ff} would result in
// 1kb of data being output.  In this case, you could write a very small
// amount of input, and end up with a very large amount of output.  In
// such a pathological inflating mechanism, there'd be no way to tell
// the system to stop doing the transform.  A single 4MB write could
// cause the system to run out of memory.
//
// However, even in such a pathological case, only a single written chunk
// would be consumed, and then the rest would wait (un-transformed) until
// the results of the previous transformed chunk were consumed.


module.exports = Transform;

var _require$codes = __webpack_require__(4012)/* .codes */ .q,
    ERR_METHOD_NOT_IMPLEMENTED = _require$codes.ERR_METHOD_NOT_IMPLEMENTED,
    ERR_MULTIPLE_CALLBACK = _require$codes.ERR_MULTIPLE_CALLBACK,
    ERR_TRANSFORM_ALREADY_TRANSFORMING = _require$codes.ERR_TRANSFORM_ALREADY_TRANSFORMING,
    ERR_TRANSFORM_WITH_LENGTH_0 = _require$codes.ERR_TRANSFORM_WITH_LENGTH_0;

var Duplex = __webpack_require__(6753);

__webpack_require__(4378)(Transform, Duplex);

function afterTransform(er, data) {
  var ts = this._transformState;
  ts.transforming = false;
  var cb = ts.writecb;

  if (cb === null) {
    return this.emit('error', new ERR_MULTIPLE_CALLBACK());
  }

  ts.writechunk = null;
  ts.writecb = null;
  if (data != null) // single equals check for both `null` and `undefined`
    this.push(data);
  cb(er);
  var rs = this._readableState;
  rs.reading = false;

  if (rs.needReadable || rs.length < rs.highWaterMark) {
    this._read(rs.highWaterMark);
  }
}

function Transform(options) {
  if (!(this instanceof Transform)) return new Transform(options);
  Duplex.call(this, options);
  this._transformState = {
    afterTransform: afterTransform.bind(this),
    needTransform: false,
    transforming: false,
    writecb: null,
    writechunk: null,
    writeencoding: null
  }; // start out asking for a readable event once data is transformed.

  this._readableState.needReadable = true; // we have implemented the _read method, and done the other things
  // that Readable wants before the first _read call, so unset the
  // sync guard flag.

  this._readableState.sync = false;

  if (options) {
    if (typeof options.transform === 'function') this._transform = options.transform;
    if (typeof options.flush === 'function') this._flush = options.flush;
  } // When the writable side finishes, then flush out anything remaining.


  this.on('prefinish', prefinish);
}

function prefinish() {
  var _this = this;

  if (typeof this._flush === 'function' && !this._readableState.destroyed) {
    this._flush(function (er, data) {
      done(_this, er, data);
    });
  } else {
    done(this, null, null);
  }
}

Transform.prototype.push = function (chunk, encoding) {
  this._transformState.needTransform = false;
  return Duplex.prototype.push.call(this, chunk, encoding);
}; // This is the part where you do stuff!
// override this function in implementation classes.
// 'chunk' is an input chunk.
//
// Call `push(newChunk)` to pass along transformed output
// to the readable side.  You may call 'push' zero or more times.
//
// Call `cb(err)` when you are done with this chunk.  If you pass
// an error, then that'll put the hurt on the whole operation.  If you
// never call cb(), then you'll never get another chunk.


Transform.prototype._transform = function (chunk, encoding, cb) {
  cb(new ERR_METHOD_NOT_IMPLEMENTED('_transform()'));
};

Transform.prototype._write = function (chunk, encoding, cb) {
  var ts = this._transformState;
  ts.writecb = cb;
  ts.writechunk = chunk;
  ts.writeencoding = encoding;

  if (!ts.transforming) {
    var rs = this._readableState;
    if (ts.needTransform || rs.needReadable || rs.length < rs.highWaterMark) this._read(rs.highWaterMark);
  }
}; // Doesn't matter what the args are here.
// _transform does all the work.
// That we got here means that the readable side wants more data.


Transform.prototype._read = function (n) {
  var ts = this._transformState;

  if (ts.writechunk !== null && !ts.transforming) {
    ts.transforming = true;

    this._transform(ts.writechunk, ts.writeencoding, ts.afterTransform);
  } else {
    // mark that we need a transform, so that any data that comes in
    // will get processed, now that we've asked for it.
    ts.needTransform = true;
  }
};

Transform.prototype._destroy = function (err, cb) {
  Duplex.prototype._destroy.call(this, err, function (err2) {
    cb(err2);
  });
};

function done(stream, er, data) {
  if (er) return stream.emit('error', er);
  if (data != null) // single equals check for both `null` and `undefined`
    stream.push(data); // TODO(BridgeAR): Write a test for these two error cases
  // if there's nothing in the write buffer, then that means
  // that nothing more will ever be provided

  if (stream._writableState.length) throw new ERR_TRANSFORM_WITH_LENGTH_0();
  if (stream._transformState.transforming) throw new ERR_TRANSFORM_ALREADY_TRANSFORMING();
  return stream.push(null);
}

/***/ }),

/***/ 4229:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.
// A bit simpler than readable streams.
// Implement an async ._write(chunk, encoding, cb), and it'll handle all
// the drain event emission and buffering.


module.exports = Writable;
/* <replacement> */

function WriteReq(chunk, encoding, cb) {
  this.chunk = chunk;
  this.encoding = encoding;
  this.callback = cb;
  this.next = null;
} // It seems a linked list but it is not
// there will be only 2 of these for each stream


function CorkedRequest(state) {
  var _this = this;

  this.next = null;
  this.entry = null;

  this.finish = function () {
    onCorkedFinish(_this, state);
  };
}
/* </replacement> */

/*<replacement>*/


var Duplex;
/*</replacement>*/

Writable.WritableState = WritableState;
/*<replacement>*/

var internalUtil = {
  deprecate: __webpack_require__(1159)
};
/*</replacement>*/

/*<replacement>*/

var Stream = __webpack_require__(9740);
/*</replacement>*/


var Buffer = __webpack_require__(4293).Buffer;

var OurUint8Array = global.Uint8Array || function () {};

function _uint8ArrayToBuffer(chunk) {
  return Buffer.from(chunk);
}

function _isUint8Array(obj) {
  return Buffer.isBuffer(obj) || obj instanceof OurUint8Array;
}

var destroyImpl = __webpack_require__(1195);

var _require = __webpack_require__(2457),
    getHighWaterMark = _require.getHighWaterMark;

var _require$codes = __webpack_require__(4012)/* .codes */ .q,
    ERR_INVALID_ARG_TYPE = _require$codes.ERR_INVALID_ARG_TYPE,
    ERR_METHOD_NOT_IMPLEMENTED = _require$codes.ERR_METHOD_NOT_IMPLEMENTED,
    ERR_MULTIPLE_CALLBACK = _require$codes.ERR_MULTIPLE_CALLBACK,
    ERR_STREAM_CANNOT_PIPE = _require$codes.ERR_STREAM_CANNOT_PIPE,
    ERR_STREAM_DESTROYED = _require$codes.ERR_STREAM_DESTROYED,
    ERR_STREAM_NULL_VALUES = _require$codes.ERR_STREAM_NULL_VALUES,
    ERR_STREAM_WRITE_AFTER_END = _require$codes.ERR_STREAM_WRITE_AFTER_END,
    ERR_UNKNOWN_ENCODING = _require$codes.ERR_UNKNOWN_ENCODING;

var errorOrDestroy = destroyImpl.errorOrDestroy;

__webpack_require__(4378)(Writable, Stream);

function nop() {}

function WritableState(options, stream, isDuplex) {
  Duplex = Duplex || __webpack_require__(6753);
  options = options || {}; // Duplex streams are both readable and writable, but share
  // the same options object.
  // However, some cases require setting options to different
  // values for the readable and the writable sides of the duplex stream,
  // e.g. options.readableObjectMode vs. options.writableObjectMode, etc.

  if (typeof isDuplex !== 'boolean') isDuplex = stream instanceof Duplex; // object stream flag to indicate whether or not this stream
  // contains buffers or objects.

  this.objectMode = !!options.objectMode;
  if (isDuplex) this.objectMode = this.objectMode || !!options.writableObjectMode; // the point at which write() starts returning false
  // Note: 0 is a valid value, means that we always return false if
  // the entire buffer is not flushed immediately on write()

  this.highWaterMark = getHighWaterMark(this, options, 'writableHighWaterMark', isDuplex); // if _final has been called

  this.finalCalled = false; // drain event flag.

  this.needDrain = false; // at the start of calling end()

  this.ending = false; // when end() has been called, and returned

  this.ended = false; // when 'finish' is emitted

  this.finished = false; // has it been destroyed

  this.destroyed = false; // should we decode strings into buffers before passing to _write?
  // this is here so that some node-core streams can optimize string
  // handling at a lower level.

  var noDecode = options.decodeStrings === false;
  this.decodeStrings = !noDecode; // Crypto is kind of old and crusty.  Historically, its default string
  // encoding is 'binary' so we have to make this configurable.
  // Everything else in the universe uses 'utf8', though.

  this.defaultEncoding = options.defaultEncoding || 'utf8'; // not an actual buffer we keep track of, but a measurement
  // of how much we're waiting to get pushed to some underlying
  // socket or file.

  this.length = 0; // a flag to see when we're in the middle of a write.

  this.writing = false; // when true all writes will be buffered until .uncork() call

  this.corked = 0; // a flag to be able to tell if the onwrite cb is called immediately,
  // or on a later tick.  We set this to true at first, because any
  // actions that shouldn't happen until "later" should generally also
  // not happen before the first write call.

  this.sync = true; // a flag to know if we're processing previously buffered items, which
  // may call the _write() callback in the same tick, so that we don't
  // end up in an overlapped onwrite situation.

  this.bufferProcessing = false; // the callback that's passed to _write(chunk,cb)

  this.onwrite = function (er) {
    onwrite(stream, er);
  }; // the callback that the user supplies to write(chunk,encoding,cb)


  this.writecb = null; // the amount that is being written when _write is called.

  this.writelen = 0;
  this.bufferedRequest = null;
  this.lastBufferedRequest = null; // number of pending user-supplied write callbacks
  // this must be 0 before 'finish' can be emitted

  this.pendingcb = 0; // emit prefinish if the only thing we're waiting for is _write cbs
  // This is relevant for synchronous Transform streams

  this.prefinished = false; // True if the error was already emitted and should not be thrown again

  this.errorEmitted = false; // Should close be emitted on destroy. Defaults to true.

  this.emitClose = options.emitClose !== false; // Should .destroy() be called after 'finish' (and potentially 'end')

  this.autoDestroy = !!options.autoDestroy; // count buffered requests

  this.bufferedRequestCount = 0; // allocate the first CorkedRequest, there is always
  // one allocated and free to use, and we maintain at most two

  this.corkedRequestsFree = new CorkedRequest(this);
}

WritableState.prototype.getBuffer = function getBuffer() {
  var current = this.bufferedRequest;
  var out = [];

  while (current) {
    out.push(current);
    current = current.next;
  }

  return out;
};

(function () {
  try {
    Object.defineProperty(WritableState.prototype, 'buffer', {
      get: internalUtil.deprecate(function writableStateBufferGetter() {
        return this.getBuffer();
      }, '_writableState.buffer is deprecated. Use _writableState.getBuffer ' + 'instead.', 'DEP0003')
    });
  } catch (_) {}
})(); // Test _writableState for inheritance to account for Duplex streams,
// whose prototype chain only points to Readable.


var realHasInstance;

if (typeof Symbol === 'function' && Symbol.hasInstance && typeof Function.prototype[Symbol.hasInstance] === 'function') {
  realHasInstance = Function.prototype[Symbol.hasInstance];
  Object.defineProperty(Writable, Symbol.hasInstance, {
    value: function value(object) {
      if (realHasInstance.call(this, object)) return true;
      if (this !== Writable) return false;
      return object && object._writableState instanceof WritableState;
    }
  });
} else {
  realHasInstance = function realHasInstance(object) {
    return object instanceof this;
  };
}

function Writable(options) {
  Duplex = Duplex || __webpack_require__(6753); // Writable ctor is applied to Duplexes, too.
  // `realHasInstance` is necessary because using plain `instanceof`
  // would return false, as no `_writableState` property is attached.
  // Trying to use the custom `instanceof` for Writable here will also break the
  // Node.js LazyTransform implementation, which has a non-trivial getter for
  // `_writableState` that would lead to infinite recursion.
  // Checking for a Stream.Duplex instance is faster here instead of inside
  // the WritableState constructor, at least with V8 6.5

  var isDuplex = this instanceof Duplex;
  if (!isDuplex && !realHasInstance.call(Writable, this)) return new Writable(options);
  this._writableState = new WritableState(options, this, isDuplex); // legacy.

  this.writable = true;

  if (options) {
    if (typeof options.write === 'function') this._write = options.write;
    if (typeof options.writev === 'function') this._writev = options.writev;
    if (typeof options.destroy === 'function') this._destroy = options.destroy;
    if (typeof options.final === 'function') this._final = options.final;
  }

  Stream.call(this);
} // Otherwise people can pipe Writable streams, which is just wrong.


Writable.prototype.pipe = function () {
  errorOrDestroy(this, new ERR_STREAM_CANNOT_PIPE());
};

function writeAfterEnd(stream, cb) {
  var er = new ERR_STREAM_WRITE_AFTER_END(); // TODO: defer error events consistently everywhere, not just the cb

  errorOrDestroy(stream, er);
  process.nextTick(cb, er);
} // Checks that a user-supplied chunk is valid, especially for the particular
// mode the stream is in. Currently this means that `null` is never accepted
// and undefined/non-string values are only allowed in object mode.


function validChunk(stream, state, chunk, cb) {
  var er;

  if (chunk === null) {
    er = new ERR_STREAM_NULL_VALUES();
  } else if (typeof chunk !== 'string' && !state.objectMode) {
    er = new ERR_INVALID_ARG_TYPE('chunk', ['string', 'Buffer'], chunk);
  }

  if (er) {
    errorOrDestroy(stream, er);
    process.nextTick(cb, er);
    return false;
  }

  return true;
}

Writable.prototype.write = function (chunk, encoding, cb) {
  var state = this._writableState;
  var ret = false;

  var isBuf = !state.objectMode && _isUint8Array(chunk);

  if (isBuf && !Buffer.isBuffer(chunk)) {
    chunk = _uint8ArrayToBuffer(chunk);
  }

  if (typeof encoding === 'function') {
    cb = encoding;
    encoding = null;
  }

  if (isBuf) encoding = 'buffer';else if (!encoding) encoding = state.defaultEncoding;
  if (typeof cb !== 'function') cb = nop;
  if (state.ending) writeAfterEnd(this, cb);else if (isBuf || validChunk(this, state, chunk, cb)) {
    state.pendingcb++;
    ret = writeOrBuffer(this, state, isBuf, chunk, encoding, cb);
  }
  return ret;
};

Writable.prototype.cork = function () {
  this._writableState.corked++;
};

Writable.prototype.uncork = function () {
  var state = this._writableState;

  if (state.corked) {
    state.corked--;
    if (!state.writing && !state.corked && !state.bufferProcessing && state.bufferedRequest) clearBuffer(this, state);
  }
};

Writable.prototype.setDefaultEncoding = function setDefaultEncoding(encoding) {
  // node::ParseEncoding() requires lower case.
  if (typeof encoding === 'string') encoding = encoding.toLowerCase();
  if (!(['hex', 'utf8', 'utf-8', 'ascii', 'binary', 'base64', 'ucs2', 'ucs-2', 'utf16le', 'utf-16le', 'raw'].indexOf((encoding + '').toLowerCase()) > -1)) throw new ERR_UNKNOWN_ENCODING(encoding);
  this._writableState.defaultEncoding = encoding;
  return this;
};

Object.defineProperty(Writable.prototype, 'writableBuffer', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._writableState && this._writableState.getBuffer();
  }
});

function decodeChunk(state, chunk, encoding) {
  if (!state.objectMode && state.decodeStrings !== false && typeof chunk === 'string') {
    chunk = Buffer.from(chunk, encoding);
  }

  return chunk;
}

Object.defineProperty(Writable.prototype, 'writableHighWaterMark', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._writableState.highWaterMark;
  }
}); // if we're already writing something, then just put this
// in the queue, and wait our turn.  Otherwise, call _write
// If we return false, then we need a drain event, so set that flag.

function writeOrBuffer(stream, state, isBuf, chunk, encoding, cb) {
  if (!isBuf) {
    var newChunk = decodeChunk(state, chunk, encoding);

    if (chunk !== newChunk) {
      isBuf = true;
      encoding = 'buffer';
      chunk = newChunk;
    }
  }

  var len = state.objectMode ? 1 : chunk.length;
  state.length += len;
  var ret = state.length < state.highWaterMark; // we must ensure that previous needDrain will not be reset to false.

  if (!ret) state.needDrain = true;

  if (state.writing || state.corked) {
    var last = state.lastBufferedRequest;
    state.lastBufferedRequest = {
      chunk: chunk,
      encoding: encoding,
      isBuf: isBuf,
      callback: cb,
      next: null
    };

    if (last) {
      last.next = state.lastBufferedRequest;
    } else {
      state.bufferedRequest = state.lastBufferedRequest;
    }

    state.bufferedRequestCount += 1;
  } else {
    doWrite(stream, state, false, len, chunk, encoding, cb);
  }

  return ret;
}

function doWrite(stream, state, writev, len, chunk, encoding, cb) {
  state.writelen = len;
  state.writecb = cb;
  state.writing = true;
  state.sync = true;
  if (state.destroyed) state.onwrite(new ERR_STREAM_DESTROYED('write'));else if (writev) stream._writev(chunk, state.onwrite);else stream._write(chunk, encoding, state.onwrite);
  state.sync = false;
}

function onwriteError(stream, state, sync, er, cb) {
  --state.pendingcb;

  if (sync) {
    // defer the callback if we are being called synchronously
    // to avoid piling up things on the stack
    process.nextTick(cb, er); // this can emit finish, and it will always happen
    // after error

    process.nextTick(finishMaybe, stream, state);
    stream._writableState.errorEmitted = true;
    errorOrDestroy(stream, er);
  } else {
    // the caller expect this to happen before if
    // it is async
    cb(er);
    stream._writableState.errorEmitted = true;
    errorOrDestroy(stream, er); // this can emit finish, but finish must
    // always follow error

    finishMaybe(stream, state);
  }
}

function onwriteStateUpdate(state) {
  state.writing = false;
  state.writecb = null;
  state.length -= state.writelen;
  state.writelen = 0;
}

function onwrite(stream, er) {
  var state = stream._writableState;
  var sync = state.sync;
  var cb = state.writecb;
  if (typeof cb !== 'function') throw new ERR_MULTIPLE_CALLBACK();
  onwriteStateUpdate(state);
  if (er) onwriteError(stream, state, sync, er, cb);else {
    // Check if we're actually ready to finish, but don't emit yet
    var finished = needFinish(state) || stream.destroyed;

    if (!finished && !state.corked && !state.bufferProcessing && state.bufferedRequest) {
      clearBuffer(stream, state);
    }

    if (sync) {
      process.nextTick(afterWrite, stream, state, finished, cb);
    } else {
      afterWrite(stream, state, finished, cb);
    }
  }
}

function afterWrite(stream, state, finished, cb) {
  if (!finished) onwriteDrain(stream, state);
  state.pendingcb--;
  cb();
  finishMaybe(stream, state);
} // Must force callback to be called on nextTick, so that we don't
// emit 'drain' before the write() consumer gets the 'false' return
// value, and has a chance to attach a 'drain' listener.


function onwriteDrain(stream, state) {
  if (state.length === 0 && state.needDrain) {
    state.needDrain = false;
    stream.emit('drain');
  }
} // if there's something in the buffer waiting, then process it


function clearBuffer(stream, state) {
  state.bufferProcessing = true;
  var entry = state.bufferedRequest;

  if (stream._writev && entry && entry.next) {
    // Fast case, write everything using _writev()
    var l = state.bufferedRequestCount;
    var buffer = new Array(l);
    var holder = state.corkedRequestsFree;
    holder.entry = entry;
    var count = 0;
    var allBuffers = true;

    while (entry) {
      buffer[count] = entry;
      if (!entry.isBuf) allBuffers = false;
      entry = entry.next;
      count += 1;
    }

    buffer.allBuffers = allBuffers;
    doWrite(stream, state, true, state.length, buffer, '', holder.finish); // doWrite is almost always async, defer these to save a bit of time
    // as the hot path ends with doWrite

    state.pendingcb++;
    state.lastBufferedRequest = null;

    if (holder.next) {
      state.corkedRequestsFree = holder.next;
      holder.next = null;
    } else {
      state.corkedRequestsFree = new CorkedRequest(state);
    }

    state.bufferedRequestCount = 0;
  } else {
    // Slow case, write chunks one-by-one
    while (entry) {
      var chunk = entry.chunk;
      var encoding = entry.encoding;
      var cb = entry.callback;
      var len = state.objectMode ? 1 : chunk.length;
      doWrite(stream, state, false, len, chunk, encoding, cb);
      entry = entry.next;
      state.bufferedRequestCount--; // if we didn't call the onwrite immediately, then
      // it means that we need to wait until it does.
      // also, that means that the chunk and cb are currently
      // being processed, so move the buffer counter past them.

      if (state.writing) {
        break;
      }
    }

    if (entry === null) state.lastBufferedRequest = null;
  }

  state.bufferedRequest = entry;
  state.bufferProcessing = false;
}

Writable.prototype._write = function (chunk, encoding, cb) {
  cb(new ERR_METHOD_NOT_IMPLEMENTED('_write()'));
};

Writable.prototype._writev = null;

Writable.prototype.end = function (chunk, encoding, cb) {
  var state = this._writableState;

  if (typeof chunk === 'function') {
    cb = chunk;
    chunk = null;
    encoding = null;
  } else if (typeof encoding === 'function') {
    cb = encoding;
    encoding = null;
  }

  if (chunk !== null && chunk !== undefined) this.write(chunk, encoding); // .end() fully uncorks

  if (state.corked) {
    state.corked = 1;
    this.uncork();
  } // ignore unnecessary end() calls.


  if (!state.ending) endWritable(this, state, cb);
  return this;
};

Object.defineProperty(Writable.prototype, 'writableLength', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    return this._writableState.length;
  }
});

function needFinish(state) {
  return state.ending && state.length === 0 && state.bufferedRequest === null && !state.finished && !state.writing;
}

function callFinal(stream, state) {
  stream._final(function (err) {
    state.pendingcb--;

    if (err) {
      errorOrDestroy(stream, err);
    }

    state.prefinished = true;
    stream.emit('prefinish');
    finishMaybe(stream, state);
  });
}

function prefinish(stream, state) {
  if (!state.prefinished && !state.finalCalled) {
    if (typeof stream._final === 'function' && !state.destroyed) {
      state.pendingcb++;
      state.finalCalled = true;
      process.nextTick(callFinal, stream, state);
    } else {
      state.prefinished = true;
      stream.emit('prefinish');
    }
  }
}

function finishMaybe(stream, state) {
  var need = needFinish(state);

  if (need) {
    prefinish(stream, state);

    if (state.pendingcb === 0) {
      state.finished = true;
      stream.emit('finish');

      if (state.autoDestroy) {
        // In case of duplex streams we need a way to detect
        // if the readable side is ready for autoDestroy as well
        var rState = stream._readableState;

        if (!rState || rState.autoDestroy && rState.endEmitted) {
          stream.destroy();
        }
      }
    }
  }

  return need;
}

function endWritable(stream, state, cb) {
  state.ending = true;
  finishMaybe(stream, state);

  if (cb) {
    if (state.finished) process.nextTick(cb);else stream.once('finish', cb);
  }

  state.ended = true;
  stream.writable = false;
}

function onCorkedFinish(corkReq, state, err) {
  var entry = corkReq.entry;
  corkReq.entry = null;

  while (entry) {
    var cb = entry.callback;
    state.pendingcb--;
    cb(err);
    entry = entry.next;
  } // reuse the free corkReq.


  state.corkedRequestsFree.next = corkReq;
}

Object.defineProperty(Writable.prototype, 'destroyed', {
  // making it explicit this property is not enumerable
  // because otherwise some prototype manipulation in
  // userland will fail
  enumerable: false,
  get: function get() {
    if (this._writableState === undefined) {
      return false;
    }

    return this._writableState.destroyed;
  },
  set: function set(value) {
    // we ignore the value if the stream
    // has not been initialized yet
    if (!this._writableState) {
      return;
    } // backward compatibility, the user is explicitly
    // managing destroyed


    this._writableState.destroyed = value;
  }
});
Writable.prototype.destroy = destroyImpl.destroy;
Writable.prototype._undestroy = destroyImpl.undestroy;

Writable.prototype._destroy = function (err, cb) {
  cb(err);
};

/***/ }),

/***/ 5850:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var _Object$setPrototypeO;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var finished = __webpack_require__(8610);

var kLastResolve = Symbol('lastResolve');
var kLastReject = Symbol('lastReject');
var kError = Symbol('error');
var kEnded = Symbol('ended');
var kLastPromise = Symbol('lastPromise');
var kHandlePromise = Symbol('handlePromise');
var kStream = Symbol('stream');

function createIterResult(value, done) {
  return {
    value: value,
    done: done
  };
}

function readAndResolve(iter) {
  var resolve = iter[kLastResolve];

  if (resolve !== null) {
    var data = iter[kStream].read(); // we defer if data is null
    // we can be expecting either 'end' or
    // 'error'

    if (data !== null) {
      iter[kLastPromise] = null;
      iter[kLastResolve] = null;
      iter[kLastReject] = null;
      resolve(createIterResult(data, false));
    }
  }
}

function onReadable(iter) {
  // we wait for the next tick, because it might
  // emit an error with process.nextTick
  process.nextTick(readAndResolve, iter);
}

function wrapForNext(lastPromise, iter) {
  return function (resolve, reject) {
    lastPromise.then(function () {
      if (iter[kEnded]) {
        resolve(createIterResult(undefined, true));
        return;
      }

      iter[kHandlePromise](resolve, reject);
    }, reject);
  };
}

var AsyncIteratorPrototype = Object.getPrototypeOf(function () {});
var ReadableStreamAsyncIteratorPrototype = Object.setPrototypeOf((_Object$setPrototypeO = {
  get stream() {
    return this[kStream];
  },

  next: function next() {
    var _this = this;

    // if we have detected an error in the meanwhile
    // reject straight away
    var error = this[kError];

    if (error !== null) {
      return Promise.reject(error);
    }

    if (this[kEnded]) {
      return Promise.resolve(createIterResult(undefined, true));
    }

    if (this[kStream].destroyed) {
      // We need to defer via nextTick because if .destroy(err) is
      // called, the error will be emitted via nextTick, and
      // we cannot guarantee that there is no error lingering around
      // waiting to be emitted.
      return new Promise(function (resolve, reject) {
        process.nextTick(function () {
          if (_this[kError]) {
            reject(_this[kError]);
          } else {
            resolve(createIterResult(undefined, true));
          }
        });
      });
    } // if we have multiple next() calls
    // we will wait for the previous Promise to finish
    // this logic is optimized to support for await loops,
    // where next() is only called once at a time


    var lastPromise = this[kLastPromise];
    var promise;

    if (lastPromise) {
      promise = new Promise(wrapForNext(lastPromise, this));
    } else {
      // fast path needed to support multiple this.push()
      // without triggering the next() queue
      var data = this[kStream].read();

      if (data !== null) {
        return Promise.resolve(createIterResult(data, false));
      }

      promise = new Promise(this[kHandlePromise]);
    }

    this[kLastPromise] = promise;
    return promise;
  }
}, _defineProperty(_Object$setPrototypeO, Symbol.asyncIterator, function () {
  return this;
}), _defineProperty(_Object$setPrototypeO, "return", function _return() {
  var _this2 = this;

  // destroy(err, cb) is a private API
  // we can guarantee we have that here, because we control the
  // Readable class this is attached to
  return new Promise(function (resolve, reject) {
    _this2[kStream].destroy(null, function (err) {
      if (err) {
        reject(err);
        return;
      }

      resolve(createIterResult(undefined, true));
    });
  });
}), _Object$setPrototypeO), AsyncIteratorPrototype);

var createReadableStreamAsyncIterator = function createReadableStreamAsyncIterator(stream) {
  var _Object$create;

  var iterator = Object.create(ReadableStreamAsyncIteratorPrototype, (_Object$create = {}, _defineProperty(_Object$create, kStream, {
    value: stream,
    writable: true
  }), _defineProperty(_Object$create, kLastResolve, {
    value: null,
    writable: true
  }), _defineProperty(_Object$create, kLastReject, {
    value: null,
    writable: true
  }), _defineProperty(_Object$create, kError, {
    value: null,
    writable: true
  }), _defineProperty(_Object$create, kEnded, {
    value: stream._readableState.endEmitted,
    writable: true
  }), _defineProperty(_Object$create, kHandlePromise, {
    value: function value(resolve, reject) {
      var data = iterator[kStream].read();

      if (data) {
        iterator[kLastPromise] = null;
        iterator[kLastResolve] = null;
        iterator[kLastReject] = null;
        resolve(createIterResult(data, false));
      } else {
        iterator[kLastResolve] = resolve;
        iterator[kLastReject] = reject;
      }
    },
    writable: true
  }), _Object$create));
  iterator[kLastPromise] = null;
  finished(stream, function (err) {
    if (err && err.code !== 'ERR_STREAM_PREMATURE_CLOSE') {
      var reject = iterator[kLastReject]; // reject if we are waiting for data in the Promise
      // returned by next() and store the error

      if (reject !== null) {
        iterator[kLastPromise] = null;
        iterator[kLastResolve] = null;
        iterator[kLastReject] = null;
        reject(err);
      }

      iterator[kError] = err;
      return;
    }

    var resolve = iterator[kLastResolve];

    if (resolve !== null) {
      iterator[kLastPromise] = null;
      iterator[kLastResolve] = null;
      iterator[kLastReject] = null;
      resolve(createIterResult(undefined, true));
    }

    iterator[kEnded] = true;
  });
  stream.on('readable', onReadable.bind(null, iterator));
  return iterator;
};

module.exports = createReadableStreamAsyncIterator;

/***/ }),

/***/ 7327:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var _require = __webpack_require__(4293),
    Buffer = _require.Buffer;

var _require2 = __webpack_require__(1669),
    inspect = _require2.inspect;

var custom = inspect && inspect.custom || 'inspect';

function copyBuffer(src, target, offset) {
  Buffer.prototype.copy.call(src, target, offset);
}

module.exports =
/*#__PURE__*/
function () {
  function BufferList() {
    _classCallCheck(this, BufferList);

    this.head = null;
    this.tail = null;
    this.length = 0;
  }

  _createClass(BufferList, [{
    key: "push",
    value: function push(v) {
      var entry = {
        data: v,
        next: null
      };
      if (this.length > 0) this.tail.next = entry;else this.head = entry;
      this.tail = entry;
      ++this.length;
    }
  }, {
    key: "unshift",
    value: function unshift(v) {
      var entry = {
        data: v,
        next: this.head
      };
      if (this.length === 0) this.tail = entry;
      this.head = entry;
      ++this.length;
    }
  }, {
    key: "shift",
    value: function shift() {
      if (this.length === 0) return;
      var ret = this.head.data;
      if (this.length === 1) this.head = this.tail = null;else this.head = this.head.next;
      --this.length;
      return ret;
    }
  }, {
    key: "clear",
    value: function clear() {
      this.head = this.tail = null;
      this.length = 0;
    }
  }, {
    key: "join",
    value: function join(s) {
      if (this.length === 0) return '';
      var p = this.head;
      var ret = '' + p.data;

      while (p = p.next) {
        ret += s + p.data;
      }

      return ret;
    }
  }, {
    key: "concat",
    value: function concat(n) {
      if (this.length === 0) return Buffer.alloc(0);
      var ret = Buffer.allocUnsafe(n >>> 0);
      var p = this.head;
      var i = 0;

      while (p) {
        copyBuffer(p.data, ret, i);
        i += p.data.length;
        p = p.next;
      }

      return ret;
    } // Consumes a specified amount of bytes or characters from the buffered data.

  }, {
    key: "consume",
    value: function consume(n, hasStrings) {
      var ret;

      if (n < this.head.data.length) {
        // `slice` is the same for buffers and strings.
        ret = this.head.data.slice(0, n);
        this.head.data = this.head.data.slice(n);
      } else if (n === this.head.data.length) {
        // First chunk is a perfect match.
        ret = this.shift();
      } else {
        // Result spans more than one buffer.
        ret = hasStrings ? this._getString(n) : this._getBuffer(n);
      }

      return ret;
    }
  }, {
    key: "first",
    value: function first() {
      return this.head.data;
    } // Consumes a specified amount of characters from the buffered data.

  }, {
    key: "_getString",
    value: function _getString(n) {
      var p = this.head;
      var c = 1;
      var ret = p.data;
      n -= ret.length;

      while (p = p.next) {
        var str = p.data;
        var nb = n > str.length ? str.length : n;
        if (nb === str.length) ret += str;else ret += str.slice(0, n);
        n -= nb;

        if (n === 0) {
          if (nb === str.length) {
            ++c;
            if (p.next) this.head = p.next;else this.head = this.tail = null;
          } else {
            this.head = p;
            p.data = str.slice(nb);
          }

          break;
        }

        ++c;
      }

      this.length -= c;
      return ret;
    } // Consumes a specified amount of bytes from the buffered data.

  }, {
    key: "_getBuffer",
    value: function _getBuffer(n) {
      var ret = Buffer.allocUnsafe(n);
      var p = this.head;
      var c = 1;
      p.data.copy(ret);
      n -= p.data.length;

      while (p = p.next) {
        var buf = p.data;
        var nb = n > buf.length ? buf.length : n;
        buf.copy(ret, ret.length - n, 0, nb);
        n -= nb;

        if (n === 0) {
          if (nb === buf.length) {
            ++c;
            if (p.next) this.head = p.next;else this.head = this.tail = null;
          } else {
            this.head = p;
            p.data = buf.slice(nb);
          }

          break;
        }

        ++c;
      }

      this.length -= c;
      return ret;
    } // Make sure the linked list only shows the minimal necessary information.

  }, {
    key: custom,
    value: function value(_, options) {
      return inspect(this, _objectSpread({}, options, {
        // Only inspect one level.
        depth: 0,
        // It should not recurse.
        customInspect: false
      }));
    }
  }]);

  return BufferList;
}();

/***/ }),

/***/ 1195:
/***/ ((module) => {

"use strict";
 // undocumented cb() API, needed for core, not for public API

function destroy(err, cb) {
  var _this = this;

  var readableDestroyed = this._readableState && this._readableState.destroyed;
  var writableDestroyed = this._writableState && this._writableState.destroyed;

  if (readableDestroyed || writableDestroyed) {
    if (cb) {
      cb(err);
    } else if (err) {
      if (!this._writableState) {
        process.nextTick(emitErrorNT, this, err);
      } else if (!this._writableState.errorEmitted) {
        this._writableState.errorEmitted = true;
        process.nextTick(emitErrorNT, this, err);
      }
    }

    return this;
  } // we set destroyed to true before firing error callbacks in order
  // to make it re-entrance safe in case destroy() is called within callbacks


  if (this._readableState) {
    this._readableState.destroyed = true;
  } // if this is a duplex stream mark the writable part as destroyed as well


  if (this._writableState) {
    this._writableState.destroyed = true;
  }

  this._destroy(err || null, function (err) {
    if (!cb && err) {
      if (!_this._writableState) {
        process.nextTick(emitErrorAndCloseNT, _this, err);
      } else if (!_this._writableState.errorEmitted) {
        _this._writableState.errorEmitted = true;
        process.nextTick(emitErrorAndCloseNT, _this, err);
      } else {
        process.nextTick(emitCloseNT, _this);
      }
    } else if (cb) {
      process.nextTick(emitCloseNT, _this);
      cb(err);
    } else {
      process.nextTick(emitCloseNT, _this);
    }
  });

  return this;
}

function emitErrorAndCloseNT(self, err) {
  emitErrorNT(self, err);
  emitCloseNT(self);
}

function emitCloseNT(self) {
  if (self._writableState && !self._writableState.emitClose) return;
  if (self._readableState && !self._readableState.emitClose) return;
  self.emit('close');
}

function undestroy() {
  if (this._readableState) {
    this._readableState.destroyed = false;
    this._readableState.reading = false;
    this._readableState.ended = false;
    this._readableState.endEmitted = false;
  }

  if (this._writableState) {
    this._writableState.destroyed = false;
    this._writableState.ended = false;
    this._writableState.ending = false;
    this._writableState.finalCalled = false;
    this._writableState.prefinished = false;
    this._writableState.finished = false;
    this._writableState.errorEmitted = false;
  }
}

function emitErrorNT(self, err) {
  self.emit('error', err);
}

function errorOrDestroy(stream, err) {
  // We have tests that rely on errors being emitted
  // in the same tick, so changing this is semver major.
  // For now when you opt-in to autoDestroy we allow
  // the error to be emitted nextTick. In a future
  // semver major update we should change the default to this.
  var rState = stream._readableState;
  var wState = stream._writableState;
  if (rState && rState.autoDestroy || wState && wState.autoDestroy) stream.destroy(err);else stream.emit('error', err);
}

module.exports = {
  destroy: destroy,
  undestroy: undestroy,
  errorOrDestroy: errorOrDestroy
};

/***/ }),

/***/ 8610:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Ported from https://github.com/mafintosh/end-of-stream with
// permission from the author, Mathias Buus (@mafintosh).


var ERR_STREAM_PREMATURE_CLOSE = __webpack_require__(4012)/* .codes.ERR_STREAM_PREMATURE_CLOSE */ .q.ERR_STREAM_PREMATURE_CLOSE;

function once(callback) {
  var called = false;
  return function () {
    if (called) return;
    called = true;

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    callback.apply(this, args);
  };
}

function noop() {}

function isRequest(stream) {
  return stream.setHeader && typeof stream.abort === 'function';
}

function eos(stream, opts, callback) {
  if (typeof opts === 'function') return eos(stream, null, opts);
  if (!opts) opts = {};
  callback = once(callback || noop);
  var readable = opts.readable || opts.readable !== false && stream.readable;
  var writable = opts.writable || opts.writable !== false && stream.writable;

  var onlegacyfinish = function onlegacyfinish() {
    if (!stream.writable) onfinish();
  };

  var writableEnded = stream._writableState && stream._writableState.finished;

  var onfinish = function onfinish() {
    writable = false;
    writableEnded = true;
    if (!readable) callback.call(stream);
  };

  var readableEnded = stream._readableState && stream._readableState.endEmitted;

  var onend = function onend() {
    readable = false;
    readableEnded = true;
    if (!writable) callback.call(stream);
  };

  var onerror = function onerror(err) {
    callback.call(stream, err);
  };

  var onclose = function onclose() {
    var err;

    if (readable && !readableEnded) {
      if (!stream._readableState || !stream._readableState.ended) err = new ERR_STREAM_PREMATURE_CLOSE();
      return callback.call(stream, err);
    }

    if (writable && !writableEnded) {
      if (!stream._writableState || !stream._writableState.ended) err = new ERR_STREAM_PREMATURE_CLOSE();
      return callback.call(stream, err);
    }
  };

  var onrequest = function onrequest() {
    stream.req.on('finish', onfinish);
  };

  if (isRequest(stream)) {
    stream.on('complete', onfinish);
    stream.on('abort', onclose);
    if (stream.req) onrequest();else stream.on('request', onrequest);
  } else if (writable && !stream._writableState) {
    // legacy streams
    stream.on('end', onlegacyfinish);
    stream.on('close', onlegacyfinish);
  }

  stream.on('end', onend);
  stream.on('finish', onfinish);
  if (opts.error !== false) stream.on('error', onerror);
  stream.on('close', onclose);
  return function () {
    stream.removeListener('complete', onfinish);
    stream.removeListener('abort', onclose);
    stream.removeListener('request', onrequest);
    if (stream.req) stream.req.removeListener('finish', onfinish);
    stream.removeListener('end', onlegacyfinish);
    stream.removeListener('close', onlegacyfinish);
    stream.removeListener('finish', onfinish);
    stream.removeListener('end', onend);
    stream.removeListener('error', onerror);
    stream.removeListener('close', onclose);
  };
}

module.exports = eos;

/***/ }),

/***/ 6307:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var ERR_INVALID_ARG_TYPE = __webpack_require__(4012)/* .codes.ERR_INVALID_ARG_TYPE */ .q.ERR_INVALID_ARG_TYPE;

function from(Readable, iterable, opts) {
  var iterator;

  if (iterable && typeof iterable.next === 'function') {
    iterator = iterable;
  } else if (iterable && iterable[Symbol.asyncIterator]) iterator = iterable[Symbol.asyncIterator]();else if (iterable && iterable[Symbol.iterator]) iterator = iterable[Symbol.iterator]();else throw new ERR_INVALID_ARG_TYPE('iterable', ['Iterable'], iterable);

  var readable = new Readable(_objectSpread({
    objectMode: true
  }, opts)); // Reading boolean to protect against _read
  // being called before last iteration completion.

  var reading = false;

  readable._read = function () {
    if (!reading) {
      reading = true;
      next();
    }
  };

  function next() {
    return _next2.apply(this, arguments);
  }

  function _next2() {
    _next2 = _asyncToGenerator(function* () {
      try {
        var _ref = yield iterator.next(),
            value = _ref.value,
            done = _ref.done;

        if (done) {
          readable.push(null);
        } else if (readable.push((yield value))) {
          next();
        } else {
          reading = false;
        }
      } catch (err) {
        readable.destroy(err);
      }
    });
    return _next2.apply(this, arguments);
  }

  return readable;
}

module.exports = from;

/***/ }),

/***/ 9946:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// Ported from https://github.com/mafintosh/pump with
// permission from the author, Mathias Buus (@mafintosh).


var eos;

function once(callback) {
  var called = false;
  return function () {
    if (called) return;
    called = true;
    callback.apply(void 0, arguments);
  };
}

var _require$codes = __webpack_require__(4012)/* .codes */ .q,
    ERR_MISSING_ARGS = _require$codes.ERR_MISSING_ARGS,
    ERR_STREAM_DESTROYED = _require$codes.ERR_STREAM_DESTROYED;

function noop(err) {
  // Rethrow the error if it exists to avoid swallowing it
  if (err) throw err;
}

function isRequest(stream) {
  return stream.setHeader && typeof stream.abort === 'function';
}

function destroyer(stream, reading, writing, callback) {
  callback = once(callback);
  var closed = false;
  stream.on('close', function () {
    closed = true;
  });
  if (eos === undefined) eos = __webpack_require__(8610);
  eos(stream, {
    readable: reading,
    writable: writing
  }, function (err) {
    if (err) return callback(err);
    closed = true;
    callback();
  });
  var destroyed = false;
  return function (err) {
    if (closed) return;
    if (destroyed) return;
    destroyed = true; // request.destroy just do .end - .abort is what we want

    if (isRequest(stream)) return stream.abort();
    if (typeof stream.destroy === 'function') return stream.destroy();
    callback(err || new ERR_STREAM_DESTROYED('pipe'));
  };
}

function call(fn) {
  fn();
}

function pipe(from, to) {
  return from.pipe(to);
}

function popCallback(streams) {
  if (!streams.length) return noop;
  if (typeof streams[streams.length - 1] !== 'function') return noop;
  return streams.pop();
}

function pipeline() {
  for (var _len = arguments.length, streams = new Array(_len), _key = 0; _key < _len; _key++) {
    streams[_key] = arguments[_key];
  }

  var callback = popCallback(streams);
  if (Array.isArray(streams[0])) streams = streams[0];

  if (streams.length < 2) {
    throw new ERR_MISSING_ARGS('streams');
  }

  var error;
  var destroys = streams.map(function (stream, i) {
    var reading = i < streams.length - 1;
    var writing = i > 0;
    return destroyer(stream, reading, writing, function (err) {
      if (!error) error = err;
      if (err) destroys.forEach(call);
      if (reading) return;
      destroys.forEach(call);
      callback(error);
    });
  });
  return streams.reduce(pipe);
}

module.exports = pipeline;

/***/ }),

/***/ 2457:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var ERR_INVALID_OPT_VALUE = __webpack_require__(4012)/* .codes.ERR_INVALID_OPT_VALUE */ .q.ERR_INVALID_OPT_VALUE;

function highWaterMarkFrom(options, isDuplex, duplexKey) {
  return options.highWaterMark != null ? options.highWaterMark : isDuplex ? options[duplexKey] : null;
}

function getHighWaterMark(state, options, duplexKey, isDuplex) {
  var hwm = highWaterMarkFrom(options, isDuplex, duplexKey);

  if (hwm != null) {
    if (!(isFinite(hwm) && Math.floor(hwm) === hwm) || hwm < 0) {
      var name = isDuplex ? duplexKey : 'highWaterMark';
      throw new ERR_INVALID_OPT_VALUE(name, hwm);
    }

    return Math.floor(hwm);
  } // Default value


  return state.objectMode ? 16 : 16 * 1024;
}

module.exports = {
  getHighWaterMark: getHighWaterMark
};

/***/ }),

/***/ 9740:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(2413);


/***/ }),

/***/ 1451:
/***/ ((module, exports, __webpack_require__) => {

var Stream = __webpack_require__(2413);
if (process.env.READABLE_STREAM === 'disable' && Stream) {
  module.exports = Stream.Readable;
  Object.assign(module.exports, Stream);
  module.exports.Stream = Stream;
} else {
  exports = module.exports = __webpack_require__(9481);
  exports.Stream = Stream || exports;
  exports.Readable = exports;
  exports.Writable = __webpack_require__(4229);
  exports.Duplex = __webpack_require__(6753);
  exports.Transform = __webpack_require__(4605);
  exports.PassThrough = __webpack_require__(2725);
  exports.finished = __webpack_require__(8610);
  exports.pipeline = __webpack_require__(9946);
}


/***/ }),

/***/ 9509:
/***/ ((module, exports, __webpack_require__) => {

/*! safe-buffer. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
/* eslint-disable node/no-deprecated-api */
var buffer = __webpack_require__(4293)
var Buffer = buffer.Buffer

// alternative to using Object.keys for old browsers
function copyProps (src, dst) {
  for (var key in src) {
    dst[key] = src[key]
  }
}
if (Buffer.from && Buffer.alloc && Buffer.allocUnsafe && Buffer.allocUnsafeSlow) {
  module.exports = buffer
} else {
  // Copy properties from require('buffer')
  copyProps(buffer, exports)
  exports.Buffer = SafeBuffer
}

function SafeBuffer (arg, encodingOrOffset, length) {
  return Buffer(arg, encodingOrOffset, length)
}

SafeBuffer.prototype = Object.create(Buffer.prototype)

// Copy static methods from Buffer
copyProps(Buffer, SafeBuffer)

SafeBuffer.from = function (arg, encodingOrOffset, length) {
  if (typeof arg === 'number') {
    throw new TypeError('Argument must not be a number')
  }
  return Buffer(arg, encodingOrOffset, length)
}

SafeBuffer.alloc = function (size, fill, encoding) {
  if (typeof size !== 'number') {
    throw new TypeError('Argument must be a number')
  }
  var buf = Buffer(size)
  if (fill !== undefined) {
    if (typeof encoding === 'string') {
      buf.fill(fill, encoding)
    } else {
      buf.fill(fill)
    }
  } else {
    buf.fill(0)
  }
  return buf
}

SafeBuffer.allocUnsafe = function (size) {
  if (typeof size !== 'number') {
    throw new TypeError('Argument must be a number')
  }
  return Buffer(size)
}

SafeBuffer.allocUnsafeSlow = function (size) {
  if (typeof size !== 'number') {
    throw new TypeError('Argument must be a number')
  }
  return buffer.SlowBuffer(size)
}


/***/ }),

/***/ 861:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
/*
Copyright (c) 2014-2018, Matteo Collina <hello@matteocollina.com>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/



const { Transform } = __webpack_require__(1451)
const { StringDecoder } = __webpack_require__(4304)
const kLast = Symbol('last')
const kDecoder = Symbol('decoder')

function transform (chunk, enc, cb) {
  var list
  if (this.overflow) { // Line buffer is full. Skip to start of next line.
    var buf = this[kDecoder].write(chunk)
    list = buf.split(this.matcher)

    if (list.length === 1) return cb() // Line ending not found. Discard entire chunk.

    // Line ending found. Discard trailing fragment of previous line and reset overflow state.
    list.shift()
    this.overflow = false
  } else {
    this[kLast] += this[kDecoder].write(chunk)
    list = this[kLast].split(this.matcher)
  }

  this[kLast] = list.pop()

  for (var i = 0; i < list.length; i++) {
    try {
      push(this, this.mapper(list[i]))
    } catch (error) {
      return cb(error)
    }
  }

  this.overflow = this[kLast].length > this.maxLength
  if (this.overflow && !this.skipOverflow) return cb(new Error('maximum buffer reached'))

  cb()
}

function flush (cb) {
  // forward any gibberish left in there
  this[kLast] += this[kDecoder].end()

  if (this[kLast]) {
    try {
      push(this, this.mapper(this[kLast]))
    } catch (error) {
      return cb(error)
    }
  }

  cb()
}

function push (self, val) {
  if (val !== undefined) {
    self.push(val)
  }
}

function noop (incoming) {
  return incoming
}

function split (matcher, mapper, options) {
  // Set defaults for any arguments not supplied.
  matcher = matcher || /\r?\n/
  mapper = mapper || noop
  options = options || {}

  // Test arguments explicitly.
  switch (arguments.length) {
    case 1:
      // If mapper is only argument.
      if (typeof matcher === 'function') {
        mapper = matcher
        matcher = /\r?\n/
      // If options is only argument.
      } else if (typeof matcher === 'object' && !(matcher instanceof RegExp)) {
        options = matcher
        matcher = /\r?\n/
      }
      break

    case 2:
      // If mapper and options are arguments.
      if (typeof matcher === 'function') {
        options = mapper
        mapper = matcher
        matcher = /\r?\n/
      // If matcher and options are arguments.
      } else if (typeof mapper === 'object') {
        options = mapper
        mapper = noop
      }
  }

  options = Object.assign({}, options)
  options.transform = transform
  options.flush = flush
  options.readableObjectMode = true

  const stream = new Transform(options)

  stream[kLast] = ''
  stream[kDecoder] = new StringDecoder('utf8')
  stream.matcher = matcher
  stream.mapper = mapper
  stream.maxLength = options.maxLength
  stream.skipOverflow = options.skipOverflow
  stream.overflow = false

  return stream
}

module.exports = split


/***/ }),

/***/ 2553:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.



/*<replacement>*/

var Buffer = __webpack_require__(9509).Buffer;
/*</replacement>*/

var isEncoding = Buffer.isEncoding || function (encoding) {
  encoding = '' + encoding;
  switch (encoding && encoding.toLowerCase()) {
    case 'hex':case 'utf8':case 'utf-8':case 'ascii':case 'binary':case 'base64':case 'ucs2':case 'ucs-2':case 'utf16le':case 'utf-16le':case 'raw':
      return true;
    default:
      return false;
  }
};

function _normalizeEncoding(enc) {
  if (!enc) return 'utf8';
  var retried;
  while (true) {
    switch (enc) {
      case 'utf8':
      case 'utf-8':
        return 'utf8';
      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return 'utf16le';
      case 'latin1':
      case 'binary':
        return 'latin1';
      case 'base64':
      case 'ascii':
      case 'hex':
        return enc;
      default:
        if (retried) return; // undefined
        enc = ('' + enc).toLowerCase();
        retried = true;
    }
  }
};

// Do not cache `Buffer.isEncoding` when checking encoding names as some
// modules monkey-patch it to support additional encodings
function normalizeEncoding(enc) {
  var nenc = _normalizeEncoding(enc);
  if (typeof nenc !== 'string' && (Buffer.isEncoding === isEncoding || !isEncoding(enc))) throw new Error('Unknown encoding: ' + enc);
  return nenc || enc;
}

// StringDecoder provides an interface for efficiently splitting a series of
// buffers into a series of JS strings without breaking apart multi-byte
// characters.
exports.s = StringDecoder;
function StringDecoder(encoding) {
  this.encoding = normalizeEncoding(encoding);
  var nb;
  switch (this.encoding) {
    case 'utf16le':
      this.text = utf16Text;
      this.end = utf16End;
      nb = 4;
      break;
    case 'utf8':
      this.fillLast = utf8FillLast;
      nb = 4;
      break;
    case 'base64':
      this.text = base64Text;
      this.end = base64End;
      nb = 3;
      break;
    default:
      this.write = simpleWrite;
      this.end = simpleEnd;
      return;
  }
  this.lastNeed = 0;
  this.lastTotal = 0;
  this.lastChar = Buffer.allocUnsafe(nb);
}

StringDecoder.prototype.write = function (buf) {
  if (buf.length === 0) return '';
  var r;
  var i;
  if (this.lastNeed) {
    r = this.fillLast(buf);
    if (r === undefined) return '';
    i = this.lastNeed;
    this.lastNeed = 0;
  } else {
    i = 0;
  }
  if (i < buf.length) return r ? r + this.text(buf, i) : this.text(buf, i);
  return r || '';
};

StringDecoder.prototype.end = utf8End;

// Returns only complete characters in a Buffer
StringDecoder.prototype.text = utf8Text;

// Attempts to complete a partial non-UTF-8 character using bytes from a Buffer
StringDecoder.prototype.fillLast = function (buf) {
  if (this.lastNeed <= buf.length) {
    buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, this.lastNeed);
    return this.lastChar.toString(this.encoding, 0, this.lastTotal);
  }
  buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, buf.length);
  this.lastNeed -= buf.length;
};

// Checks the type of a UTF-8 byte, whether it's ASCII, a leading byte, or a
// continuation byte. If an invalid byte is detected, -2 is returned.
function utf8CheckByte(byte) {
  if (byte <= 0x7F) return 0;else if (byte >> 5 === 0x06) return 2;else if (byte >> 4 === 0x0E) return 3;else if (byte >> 3 === 0x1E) return 4;
  return byte >> 6 === 0x02 ? -1 : -2;
}

// Checks at most 3 bytes at the end of a Buffer in order to detect an
// incomplete multi-byte UTF-8 character. The total number of bytes (2, 3, or 4)
// needed to complete the UTF-8 character (if applicable) are returned.
function utf8CheckIncomplete(self, buf, i) {
  var j = buf.length - 1;
  if (j < i) return 0;
  var nb = utf8CheckByte(buf[j]);
  if (nb >= 0) {
    if (nb > 0) self.lastNeed = nb - 1;
    return nb;
  }
  if (--j < i || nb === -2) return 0;
  nb = utf8CheckByte(buf[j]);
  if (nb >= 0) {
    if (nb > 0) self.lastNeed = nb - 2;
    return nb;
  }
  if (--j < i || nb === -2) return 0;
  nb = utf8CheckByte(buf[j]);
  if (nb >= 0) {
    if (nb > 0) {
      if (nb === 2) nb = 0;else self.lastNeed = nb - 3;
    }
    return nb;
  }
  return 0;
}

// Validates as many continuation bytes for a multi-byte UTF-8 character as
// needed or are available. If we see a non-continuation byte where we expect
// one, we "replace" the validated continuation bytes we've seen so far with
// a single UTF-8 replacement character ('\ufffd'), to match v8's UTF-8 decoding
// behavior. The continuation byte check is included three times in the case
// where all of the continuation bytes for a character exist in the same buffer.
// It is also done this way as a slight performance increase instead of using a
// loop.
function utf8CheckExtraBytes(self, buf, p) {
  if ((buf[0] & 0xC0) !== 0x80) {
    self.lastNeed = 0;
    return '\ufffd';
  }
  if (self.lastNeed > 1 && buf.length > 1) {
    if ((buf[1] & 0xC0) !== 0x80) {
      self.lastNeed = 1;
      return '\ufffd';
    }
    if (self.lastNeed > 2 && buf.length > 2) {
      if ((buf[2] & 0xC0) !== 0x80) {
        self.lastNeed = 2;
        return '\ufffd';
      }
    }
  }
}

// Attempts to complete a multi-byte UTF-8 character using bytes from a Buffer.
function utf8FillLast(buf) {
  var p = this.lastTotal - this.lastNeed;
  var r = utf8CheckExtraBytes(this, buf, p);
  if (r !== undefined) return r;
  if (this.lastNeed <= buf.length) {
    buf.copy(this.lastChar, p, 0, this.lastNeed);
    return this.lastChar.toString(this.encoding, 0, this.lastTotal);
  }
  buf.copy(this.lastChar, p, 0, buf.length);
  this.lastNeed -= buf.length;
}

// Returns all complete UTF-8 characters in a Buffer. If the Buffer ended on a
// partial character, the character's bytes are buffered until the required
// number of bytes are available.
function utf8Text(buf, i) {
  var total = utf8CheckIncomplete(this, buf, i);
  if (!this.lastNeed) return buf.toString('utf8', i);
  this.lastTotal = total;
  var end = buf.length - (total - this.lastNeed);
  buf.copy(this.lastChar, 0, end);
  return buf.toString('utf8', i, end);
}

// For UTF-8, a replacement character is added when ending on a partial
// character.
function utf8End(buf) {
  var r = buf && buf.length ? this.write(buf) : '';
  if (this.lastNeed) return r + '\ufffd';
  return r;
}

// UTF-16LE typically needs two bytes per character, but even if we have an even
// number of bytes available, we need to check if we end on a leading/high
// surrogate. In that case, we need to wait for the next two bytes in order to
// decode the last character properly.
function utf16Text(buf, i) {
  if ((buf.length - i) % 2 === 0) {
    var r = buf.toString('utf16le', i);
    if (r) {
      var c = r.charCodeAt(r.length - 1);
      if (c >= 0xD800 && c <= 0xDBFF) {
        this.lastNeed = 2;
        this.lastTotal = 4;
        this.lastChar[0] = buf[buf.length - 2];
        this.lastChar[1] = buf[buf.length - 1];
        return r.slice(0, -1);
      }
    }
    return r;
  }
  this.lastNeed = 1;
  this.lastTotal = 2;
  this.lastChar[0] = buf[buf.length - 1];
  return buf.toString('utf16le', i, buf.length - 1);
}

// For UTF-16LE we do not explicitly append special replacement characters if we
// end on a partial character, we simply let v8 handle that.
function utf16End(buf) {
  var r = buf && buf.length ? this.write(buf) : '';
  if (this.lastNeed) {
    var end = this.lastTotal - this.lastNeed;
    return r + this.lastChar.toString('utf16le', 0, end);
  }
  return r;
}

function base64Text(buf, i) {
  var n = (buf.length - i) % 3;
  if (n === 0) return buf.toString('base64', i);
  this.lastNeed = 3 - n;
  this.lastTotal = 3;
  if (n === 1) {
    this.lastChar[0] = buf[buf.length - 1];
  } else {
    this.lastChar[0] = buf[buf.length - 2];
    this.lastChar[1] = buf[buf.length - 1];
  }
  return buf.toString('base64', i, buf.length - n);
}

function base64End(buf) {
  var r = buf && buf.length ? this.write(buf) : '';
  if (this.lastNeed) return r + this.lastChar.toString('base64', 0, 3 - this.lastNeed);
  return r;
}

// Pass bytes on through for single-byte encodings (e.g. ascii, latin1, hex)
function simpleWrite(buf) {
  return buf.toString(this.encoding);
}

function simpleEnd(buf) {
  return buf && buf.length ? this.write(buf) : '';
}

/***/ }),

/***/ 1159:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


/**
 * For Node.js, simply re-export the core `util.deprecate` function.
 */

module.exports = __webpack_require__(1669).deprecate;


/***/ }),

/***/ 9820:
/***/ ((module) => {

module.exports = extend

var hasOwnProperty = Object.prototype.hasOwnProperty;

function extend(target) {
    for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i]

        for (var key in source) {
            if (hasOwnProperty.call(source, key)) {
                target[key] = source[key]
            }
        }
    }

    return target
}


/***/ }),

/***/ 2357:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 4293:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6417:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 881:
/***/ ((module) => {

"use strict";
module.exports = require("dns");

/***/ }),

/***/ 8614:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 5747:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 1631:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 5622:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 2413:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 4304:
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ 4016:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 8835:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 1669:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 2466:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"name":"pg","version":"8.7.1","description":"PostgreSQL client - pure javascript & libpq with the same API","keywords":["database","libpq","pg","postgre","postgres","postgresql","rdbms"],"homepage":"https://github.com/brianc/node-postgres","repository":{"type":"git","url":"git://github.com/brianc/node-postgres.git","directory":"packages/pg"},"author":"Brian Carlson <brian.m.carlson@gmail.com>","main":"./lib","dependencies":{"buffer-writer":"2.0.0","packet-reader":"1.0.0","pg-connection-string":"^2.5.0","pg-pool":"^3.4.1","pg-protocol":"^1.5.0","pg-types":"^2.1.0","pgpass":"1.x"},"devDependencies":{"async":"0.9.0","bluebird":"3.5.2","co":"4.6.0","pg-copy-streams":"0.3.0"},"peerDependencies":{"pg-native":">=2.0.0"},"peerDependenciesMeta":{"pg-native":{"optional":true}},"scripts":{"test":"make test-all"},"files":["lib","SPONSORS.md"],"license":"MIT","engines":{"node":">= 8.0.0"},"gitHead":"92b4d37926c276d343bfe56447ff6f526af757cf"}');

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module doesn't tell about it's top-level declarations so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(5035);
/******/ 	var __webpack_export_target__ = exports;
/******/ 	for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
/******/ 	if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGFtYmRhcy9nZXRQcm9kdWN0c0J5SWQuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDekNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7QUN2REE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ1JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDMUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUN6R0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ25HQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDcGFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDakRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUNoRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ2RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQy9KQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ25UQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7QUM1TEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUM5Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUNWQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ2hRQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUN4RUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDdE5BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDNW1CQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDcktBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQzVOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUMvRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ3REQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ3hTQTtBQUNBOzs7Ozs7Ozs7QUNEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ3BLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ3pPQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDbkdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ2hOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUNsQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQzFMQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUN4T0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDdEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUNoR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQzlCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUNuSEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDNUhBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ25IQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUMxSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ3RDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ25tQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ3hNQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUN4ckJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUM5TUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ2pOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDeEdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDdkdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQy9EQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUNoR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7O0FDMUJBOzs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ2ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ2hFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ25JQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7O0FDdlNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUNMQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUNoQkE7Ozs7Ozs7O0FDQUE7Ozs7Ozs7O0FDQUE7Ozs7Ozs7O0FDQUE7Ozs7Ozs7O0FDQUE7Ozs7Ozs7O0FDQUE7Ozs7Ozs7O0FDQUE7Ozs7Ozs7O0FDQUE7Ozs7Ozs7O0FDQUE7Ozs7Ozs7O0FDQUE7Ozs7Ozs7O0FDQUE7Ozs7Ozs7O0FDQUE7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7O0FDdkJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7O0FDUEE7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7O0FFTkE7QUFDQTtBQUNBO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9jb25lY3Rpb24uanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbGFtYmRhcy9nZXRQcm9kdWN0c0J5SWQuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL2luaGVyaXRzL2luaGVyaXRzLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9pbmhlcml0cy9pbmhlcml0c19icm93c2VyLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy1jb25uZWN0aW9uLXN0cmluZy9pbmRleC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGctaW50OC9pbmRleC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGctcG9vbC9pbmRleC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGctcHJvdG9jb2wvZGlzdC9idWZmZXItcmVhZGVyLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy1wcm90b2NvbC9kaXN0L2J1ZmZlci13cml0ZXIuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnLXByb3RvY29sL2Rpc3QvaW5kZXguanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnLXByb3RvY29sL2Rpc3QvbWVzc2FnZXMuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnLXByb3RvY29sL2Rpc3QvcGFyc2VyLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy1wcm90b2NvbC9kaXN0L3NlcmlhbGl6ZXIuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnLXR5cGVzL2luZGV4LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy10eXBlcy9saWIvYXJyYXlQYXJzZXIuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnLXR5cGVzL2xpYi9iaW5hcnlQYXJzZXJzLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy10eXBlcy9saWIvYnVpbHRpbnMuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnLXR5cGVzL2xpYi90ZXh0UGFyc2Vycy5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGcvbGliL2NsaWVudC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGcvbGliL2Nvbm5lY3Rpb24tcGFyYW1ldGVycy5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGcvbGliL2Nvbm5lY3Rpb24uanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BnL2xpYi9kZWZhdWx0cy5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGcvbGliL2luZGV4LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy9saWIvbmF0aXZlL2NsaWVudC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGcvbGliL25hdGl2ZS9pbmRleC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGcvbGliL25hdGl2ZS9xdWVyeS5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGcvbGliL3F1ZXJ5LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy9saWIvcmVzdWx0LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy9saWIvc2FzbC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcGcvbGliL3R5cGUtb3ZlcnJpZGVzLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZy9saWIvdXRpbHMuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3BncGFzcy9saWIvaGVscGVyLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wZ3Bhc3MvbGliL2luZGV4LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9wb3N0Z3Jlcy1hcnJheS9pbmRleC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcG9zdGdyZXMtYnl0ZWEvaW5kZXguanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3Bvc3RncmVzLWRhdGUvaW5kZXguanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3Bvc3RncmVzLWludGVydmFsL2luZGV4LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9yZWFkYWJsZS1zdHJlYW0vZXJyb3JzLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9yZWFkYWJsZS1zdHJlYW0vbGliL19zdHJlYW1fZHVwbGV4LmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9yZWFkYWJsZS1zdHJlYW0vbGliL19zdHJlYW1fcGFzc3Rocm91Z2guanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3JlYWRhYmxlLXN0cmVhbS9saWIvX3N0cmVhbV9yZWFkYWJsZS5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcmVhZGFibGUtc3RyZWFtL2xpYi9fc3RyZWFtX3RyYW5zZm9ybS5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcmVhZGFibGUtc3RyZWFtL2xpYi9fc3RyZWFtX3dyaXRhYmxlLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9yZWFkYWJsZS1zdHJlYW0vbGliL2ludGVybmFsL3N0cmVhbXMvYXN5bmNfaXRlcmF0b3IuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3JlYWRhYmxlLXN0cmVhbS9saWIvaW50ZXJuYWwvc3RyZWFtcy9idWZmZXJfbGlzdC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcmVhZGFibGUtc3RyZWFtL2xpYi9pbnRlcm5hbC9zdHJlYW1zL2Rlc3Ryb3kuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3JlYWRhYmxlLXN0cmVhbS9saWIvaW50ZXJuYWwvc3RyZWFtcy9lbmQtb2Ytc3RyZWFtLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9yZWFkYWJsZS1zdHJlYW0vbGliL2ludGVybmFsL3N0cmVhbXMvZnJvbS5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvcmVhZGFibGUtc3RyZWFtL2xpYi9pbnRlcm5hbC9zdHJlYW1zL3BpcGVsaW5lLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy9yZWFkYWJsZS1zdHJlYW0vbGliL2ludGVybmFsL3N0cmVhbXMvc3RhdGUuanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3JlYWRhYmxlLXN0cmVhbS9saWIvaW50ZXJuYWwvc3RyZWFtcy9zdHJlYW0uanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3JlYWRhYmxlLXN0cmVhbS9yZWFkYWJsZS5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvc2FmZS1idWZmZXIvaW5kZXguanMiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlLy4vbm9kZV9tb2R1bGVzL3NwbGl0Mi9pbmRleC5qcyIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2UvLi9ub2RlX21vZHVsZXMvc3RyaW5nX2RlY29kZXIvbGliL3N0cmluZ19kZWNvZGVyLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy91dGlsLWRlcHJlY2F0ZS9ub2RlLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS8uL25vZGVfbW9kdWxlcy94dGVuZC9tdXRhYmxlLmpzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS9leHRlcm5hbCBcImFzc2VydFwiIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS9leHRlcm5hbCBcImJ1ZmZlclwiIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS9leHRlcm5hbCBcImNyeXB0b1wiIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS9leHRlcm5hbCBcImRuc1wiIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS9leHRlcm5hbCBcImV2ZW50c1wiIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS9leHRlcm5hbCBcImZzXCIiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL2V4dGVybmFsIFwibmV0XCIiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL2V4dGVybmFsIFwicGF0aFwiIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS9leHRlcm5hbCBcInN0cmVhbVwiIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS9leHRlcm5hbCBcInN0cmluZ19kZWNvZGVyXCIiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL2V4dGVybmFsIFwidGxzXCIiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL2V4dGVybmFsIFwidXJsXCIiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL2V4dGVybmFsIFwidXRpbFwiIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS93ZWJwYWNrL2Jvb3RzdHJhcCIsIndlYnBhY2s6Ly9wcm9kdWN0LXNlcnZpY2Uvd2VicGFjay9ydW50aW1lL2RlZmluZSBwcm9wZXJ0eSBnZXR0ZXJzIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS93ZWJwYWNrL3J1bnRpbWUvbWFrZSBuYW1lc3BhY2Ugb2JqZWN0Iiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS93ZWJwYWNrL2JlZm9yZS1zdGFydHVwIiwid2VicGFjazovL3Byb2R1Y3Qtc2VydmljZS93ZWJwYWNrL3N0YXJ0dXAiLCJ3ZWJwYWNrOi8vcHJvZHVjdC1zZXJ2aWNlL3dlYnBhY2svYWZ0ZXItc3RhcnR1cCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDbGllbnQgfSBmcm9tICdwZyc7XHJcblxyXG5cclxuY29uc3QgeyBQR19IT1NULCBQR19QT1JULCBQR19EQVRBQkFTRSwgUEdfVVNFUk5BTUUsIFBHX1BBU1NXT1JEIH0gPSBwcm9jZXNzLmVudjtcclxuZXhwb3J0IGNvbnN0IGRiT3B0aW9ucyA9IHtcclxuICAgIGhvc3Q6IFBHX0hPU1QsXHJcbiAgICBwb3J0OiBQR19QT1JULFxyXG4gICAgZGF0YWJhc2U6IFBHX0RBVEFCQVNFLFxyXG4gICAgdXNlcjogUEdfVVNFUk5BTUUsXHJcbiAgICBwYXNzd29yZDogUEdfUEFTU1dPUkQsXHJcbiAgICBzc2w6IHtcclxuICAgICAgICByZWplY3RVbmF1dGhvcml6ZWQ6IGZhbHNlLFxyXG4gICAgfSxcclxuICAgIGNvbm5lY3Rpb25UaW1lb3V0TWlsbGlzOiA1MDAwLFxyXG59O1xyXG5leHBvcnQgY2xhc3MgQ29ubmVjdERCIHtcclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgICAgIHRoaXMuY2xpZW50ID0gbmV3IENsaWVudChkYk9wdGlvbnMpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGNvbm5lY3QoKSB7XHJcbiAgICAgICAgYXdhaXQgdGhpcy5jbGllbnQuY29ubmVjdCgpO1xyXG4gICAgICAgIHJldHVybiB0aGlzLmNsaWVudDtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBkaXNjb25uZWN0KCkge1xyXG4gICAgICAgIGF3YWl0IHRoaXMuY2xpZW50LmVuZCgpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGNyZWF0ZVRhYmxlKHRhYmxlTmFtZSwgY29uZmlnKSB7XHJcbiAgICAgICAgYXdhaXQgdGhpcy5jbGllbnQucXVlcnkoYFxyXG4gIGNyZWF0ZSB0YWJsZSBpZiBub3QgZXhpc3QgJHt0YWJsZU5hbWV9IChcclxuICAgICR7Y29uZmlnfVxyXG4gIClgKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgYXN5bmMgZ2V0TGlzdCh0YWJsZU5hbWUpIHtcclxuICAgICAgICBjb25zdCB7IHJvd3MgfSA9IGF3YWl0IHRoaXMuY2xpZW50LnF1ZXJ5KHNlbGVjdCAqIGZyb20gYCR7dGFibGVOYW1lfWApO1xyXG4gICAgICAgIHJldHVybiByb3dzO1xyXG4gICAgfVxyXG59IiwiaW1wb3J0IHByb2R1Y3RzIGZyb20gJy4vZGIvcHJvZHVjdHMuanNvbic7XHJcbmltcG9ydCB7IENsaWVudCB9IGZyb20gJ3BnJztcclxuaW1wb3J0IHsgQ29ubmVjdERCLCBkYk9wdGlvbnMgfSBmcm9tICcuLi9jb25lY3Rpb24nXHJcblxyXG5leHBvcnQgY29uc3QgaGFuZGxlciA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coZXZlbnQpO1xyXG4gICAgY29uc3QgeyBwcm9kdWN0SWQgfSA9IGV2ZW50LnBhdGhQYXJhbWV0ZXJzIHx8IHt9O1xyXG4gICAgY29uc3QgZ2V0UHJvZHVjdCA9IHByb2R1Y3RzLmZpbmQoKGl0ZW0sIGlkKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIGl0ZW0uaWQgPT0gcHJvZHVjdElkO1xyXG4gICAgfSk7XHJcbiAgICBjb25zdCBkYiA9IG5ldyBDb25uZWN0REIoKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGF3YWl0IGRiLmNvbm5lY3QoKTtcclxuXHJcbiAgICAgICAgY29uc3QgeyByb3dzIH0gPSBhd2FpdCBjbGllbnQucXVlcnkoYHNlbGVjdCBwcm9kdWN0cy4qLCBzdG9jay5jb3VudCBmcm9tIHByb2R1Y3RzIGxlZnQgam9pbiBzdG9jayBvbiBwcm9kdWN0cy5pZCA9IHN0b2NrLnByb2R1Y3RfaWQgd2hlcmUgcHJvZHVjdHMuaWQ9JyR7cHJvZHVjdElkfSdgKTtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICAgICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctTWV0aG9kcyc6ICcqJyxcclxuICAgICAgICAgICAgICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxyXG4gICAgICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkocm93cylcclxuICAgICAgICAgICAgfTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU1ldGhvZHMnOiAnKicsXHJcbiAgICAgICAgICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDUwMCxcclxuICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBtZXNzYWdlOiBlcnJvci5tZXNzYWdlIH0pXHJcbiAgICAgICAgfTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgZGIuZGlzY29ubmVjdCgpO1xyXG4gICAgfVxyXG4gICAgLy8gY29uc3QgcmVzcG9uc2UgPSB7XHJcbiAgICAvLyAgICAgaGVhZGVyczoge1xyXG4gICAgLy8gICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgLy8gICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctTWV0aG9kcyc6ICcqJyxcclxuICAgIC8vICAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICcqJyxcclxuICAgIC8vICAgICAgIH0sXHJcbiAgICAvLyAgICAgc3RhdHVzQ29kZTogMjAwLFxyXG4gICAgLy8gfVxyXG4gICAgLy8gaWYgKCFnZXRQcm9kdWN0KSAgIHsgXHJcbiAgICAvLyAgICAgcmVzcG9uc2UuYm9keSA9ICBKU09OLnN0cmluZ2lmeSh7IG1lc3NhZ2U6ICdFcnJvcjogUHJvZHVjdCBub3QgZm91bmQhJyB9KTtcclxuXHJcbiAgICAvLyAgICAgcmVzcG9uc2Uuc3RhdHVzQ29kZSA9IDQwNDtcclxuICAgIC8vIH0gZWxzZSB7XHJcbiAgICAvLyAgICAgcmVzcG9uc2UuYm9keSA9IEpTT04uc3RyaW5naWZ5KGdldFByb2R1Y3QpOyBcclxuICAgIC8vIH1cclxuICAgIC8vIHJldHVybiByZXNwb25zZTtcclxufSIsInRyeSB7XG4gIHZhciB1dGlsID0gcmVxdWlyZSgndXRpbCcpO1xuICAvKiBpc3RhbmJ1bCBpZ25vcmUgbmV4dCAqL1xuICBpZiAodHlwZW9mIHV0aWwuaW5oZXJpdHMgIT09ICdmdW5jdGlvbicpIHRocm93ICcnO1xuICBtb2R1bGUuZXhwb3J0cyA9IHV0aWwuaW5oZXJpdHM7XG59IGNhdGNoIChlKSB7XG4gIC8qIGlzdGFuYnVsIGlnbm9yZSBuZXh0ICovXG4gIG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9pbmhlcml0c19icm93c2VyLmpzJyk7XG59XG4iLCJpZiAodHlwZW9mIE9iamVjdC5jcmVhdGUgPT09ICdmdW5jdGlvbicpIHtcbiAgLy8gaW1wbGVtZW50YXRpb24gZnJvbSBzdGFuZGFyZCBub2RlLmpzICd1dGlsJyBtb2R1bGVcbiAgbW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBpbmhlcml0cyhjdG9yLCBzdXBlckN0b3IpIHtcbiAgICBpZiAoc3VwZXJDdG9yKSB7XG4gICAgICBjdG9yLnN1cGVyXyA9IHN1cGVyQ3RvclxuICAgICAgY3Rvci5wcm90b3R5cGUgPSBPYmplY3QuY3JlYXRlKHN1cGVyQ3Rvci5wcm90b3R5cGUsIHtcbiAgICAgICAgY29uc3RydWN0b3I6IHtcbiAgICAgICAgICB2YWx1ZTogY3RvcixcbiAgICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9XG4gIH07XG59IGVsc2Uge1xuICAvLyBvbGQgc2Nob29sIHNoaW0gZm9yIG9sZCBicm93c2Vyc1xuICBtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGluaGVyaXRzKGN0b3IsIHN1cGVyQ3Rvcikge1xuICAgIGlmIChzdXBlckN0b3IpIHtcbiAgICAgIGN0b3Iuc3VwZXJfID0gc3VwZXJDdG9yXG4gICAgICB2YXIgVGVtcEN0b3IgPSBmdW5jdGlvbiAoKSB7fVxuICAgICAgVGVtcEN0b3IucHJvdG90eXBlID0gc3VwZXJDdG9yLnByb3RvdHlwZVxuICAgICAgY3Rvci5wcm90b3R5cGUgPSBuZXcgVGVtcEN0b3IoKVxuICAgICAgY3Rvci5wcm90b3R5cGUuY29uc3RydWN0b3IgPSBjdG9yXG4gICAgfVxuICB9XG59XG4iLCIndXNlIHN0cmljdCdcblxudmFyIHVybCA9IHJlcXVpcmUoJ3VybCcpXG52YXIgZnMgPSByZXF1aXJlKCdmcycpXG5cbi8vUGFyc2UgbWV0aG9kIGNvcGllZCBmcm9tIGh0dHBzOi8vZ2l0aHViLmNvbS9icmlhbmMvbm9kZS1wb3N0Z3Jlc1xuLy9Db3B5cmlnaHQgKGMpIDIwMTAtMjAxNCBCcmlhbiBDYXJsc29uIChicmlhbi5tLmNhcmxzb25AZ21haWwuY29tKVxuLy9NSVQgTGljZW5zZVxuXG4vL3BhcnNlcyBhIGNvbm5lY3Rpb24gc3RyaW5nXG5mdW5jdGlvbiBwYXJzZShzdHIpIHtcbiAgLy91bml4IHNvY2tldFxuICBpZiAoc3RyLmNoYXJBdCgwKSA9PT0gJy8nKSB7XG4gICAgdmFyIGNvbmZpZyA9IHN0ci5zcGxpdCgnICcpXG4gICAgcmV0dXJuIHsgaG9zdDogY29uZmlnWzBdLCBkYXRhYmFzZTogY29uZmlnWzFdIH1cbiAgfVxuXG4gIC8vIHVybCBwYXJzZSBleHBlY3RzIHNwYWNlcyBlbmNvZGVkIGFzICUyMFxuICB2YXIgcmVzdWx0ID0gdXJsLnBhcnNlKFxuICAgIC8gfCVbXmEtZjAtOV18JVthLWYwLTldW15hLWYwLTldL2kudGVzdChzdHIpID8gZW5jb2RlVVJJKHN0cikucmVwbGFjZSgvXFwlMjUoXFxkXFxkKS9nLCAnJSQxJykgOiBzdHIsXG4gICAgdHJ1ZVxuICApXG4gIHZhciBjb25maWcgPSByZXN1bHQucXVlcnlcbiAgZm9yICh2YXIgayBpbiBjb25maWcpIHtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShjb25maWdba10pKSB7XG4gICAgICBjb25maWdba10gPSBjb25maWdba11bY29uZmlnW2tdLmxlbmd0aCAtIDFdXG4gICAgfVxuICB9XG5cbiAgdmFyIGF1dGggPSAocmVzdWx0LmF1dGggfHwgJzonKS5zcGxpdCgnOicpXG4gIGNvbmZpZy51c2VyID0gYXV0aFswXVxuICBjb25maWcucGFzc3dvcmQgPSBhdXRoLnNwbGljZSgxKS5qb2luKCc6JylcblxuICBjb25maWcucG9ydCA9IHJlc3VsdC5wb3J0XG4gIGlmIChyZXN1bHQucHJvdG9jb2wgPT0gJ3NvY2tldDonKSB7XG4gICAgY29uZmlnLmhvc3QgPSBkZWNvZGVVUkkocmVzdWx0LnBhdGhuYW1lKVxuICAgIGNvbmZpZy5kYXRhYmFzZSA9IHJlc3VsdC5xdWVyeS5kYlxuICAgIGNvbmZpZy5jbGllbnRfZW5jb2RpbmcgPSByZXN1bHQucXVlcnkuZW5jb2RpbmdcbiAgICByZXR1cm4gY29uZmlnXG4gIH1cbiAgaWYgKCFjb25maWcuaG9zdCkge1xuICAgIC8vIE9ubHkgc2V0IHRoZSBob3N0IGlmIHRoZXJlIGlzIG5vIGVxdWl2YWxlbnQgcXVlcnkgcGFyYW0uXG4gICAgY29uZmlnLmhvc3QgPSByZXN1bHQuaG9zdG5hbWVcbiAgfVxuXG4gIC8vIElmIHRoZSBob3N0IGlzIG1pc3NpbmcgaXQgbWlnaHQgYmUgYSBVUkwtZW5jb2RlZCBwYXRoIHRvIGEgc29ja2V0LlxuICB2YXIgcGF0aG5hbWUgPSByZXN1bHQucGF0aG5hbWVcbiAgaWYgKCFjb25maWcuaG9zdCAmJiBwYXRobmFtZSAmJiAvXiUyZi9pLnRlc3QocGF0aG5hbWUpKSB7XG4gICAgdmFyIHBhdGhuYW1lU3BsaXQgPSBwYXRobmFtZS5zcGxpdCgnLycpXG4gICAgY29uZmlnLmhvc3QgPSBkZWNvZGVVUklDb21wb25lbnQocGF0aG5hbWVTcGxpdFswXSlcbiAgICBwYXRobmFtZSA9IHBhdGhuYW1lU3BsaXQuc3BsaWNlKDEpLmpvaW4oJy8nKVxuICB9XG4gIC8vIHJlc3VsdC5wYXRobmFtZSBpcyBub3QgYWx3YXlzIGd1YXJhbnRlZWQgdG8gaGF2ZSBhICcvJyBwcmVmaXggKGUuZy4gcmVsYXRpdmUgdXJscylcbiAgLy8gb25seSBzdHJpcCB0aGUgc2xhc2ggaWYgaXQgaXMgcHJlc2VudC5cbiAgaWYgKHBhdGhuYW1lICYmIHBhdGhuYW1lLmNoYXJBdCgwKSA9PT0gJy8nKSB7XG4gICAgcGF0aG5hbWUgPSBwYXRobmFtZS5zbGljZSgxKSB8fCBudWxsXG4gIH1cbiAgY29uZmlnLmRhdGFiYXNlID0gcGF0aG5hbWUgJiYgZGVjb2RlVVJJKHBhdGhuYW1lKVxuXG4gIGlmIChjb25maWcuc3NsID09PSAndHJ1ZScgfHwgY29uZmlnLnNzbCA9PT0gJzEnKSB7XG4gICAgY29uZmlnLnNzbCA9IHRydWVcbiAgfVxuXG4gIGlmIChjb25maWcuc3NsID09PSAnMCcpIHtcbiAgICBjb25maWcuc3NsID0gZmFsc2VcbiAgfVxuXG4gIGlmIChjb25maWcuc3NsY2VydCB8fCBjb25maWcuc3Nsa2V5IHx8IGNvbmZpZy5zc2xyb290Y2VydCB8fCBjb25maWcuc3NsbW9kZSkge1xuICAgIGNvbmZpZy5zc2wgPSB7fVxuICB9XG5cbiAgaWYgKGNvbmZpZy5zc2xjZXJ0KSB7XG4gICAgY29uZmlnLnNzbC5jZXJ0ID0gZnMucmVhZEZpbGVTeW5jKGNvbmZpZy5zc2xjZXJ0KS50b1N0cmluZygpXG4gIH1cblxuICBpZiAoY29uZmlnLnNzbGtleSkge1xuICAgIGNvbmZpZy5zc2wua2V5ID0gZnMucmVhZEZpbGVTeW5jKGNvbmZpZy5zc2xrZXkpLnRvU3RyaW5nKClcbiAgfVxuXG4gIGlmIChjb25maWcuc3Nscm9vdGNlcnQpIHtcbiAgICBjb25maWcuc3NsLmNhID0gZnMucmVhZEZpbGVTeW5jKGNvbmZpZy5zc2xyb290Y2VydCkudG9TdHJpbmcoKVxuICB9XG5cbiAgc3dpdGNoIChjb25maWcuc3NsbW9kZSkge1xuICAgIGNhc2UgJ2Rpc2FibGUnOiB7XG4gICAgICBjb25maWcuc3NsID0gZmFsc2VcbiAgICAgIGJyZWFrXG4gICAgfVxuICAgIGNhc2UgJ3ByZWZlcic6XG4gICAgY2FzZSAncmVxdWlyZSc6XG4gICAgY2FzZSAndmVyaWZ5LWNhJzpcbiAgICBjYXNlICd2ZXJpZnktZnVsbCc6IHtcbiAgICAgIGJyZWFrXG4gICAgfVxuICAgIGNhc2UgJ25vLXZlcmlmeSc6IHtcbiAgICAgIGNvbmZpZy5zc2wucmVqZWN0VW5hdXRob3JpemVkID0gZmFsc2VcbiAgICAgIGJyZWFrXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGNvbmZpZ1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHBhcnNlXG5cbnBhcnNlLnBhcnNlID0gcGFyc2VcbiIsIid1c2Ugc3RyaWN0JztcblxuLy8gc2VsZWN0ZWQgc28gKEJBU0UgLSAxKSAqIDB4MTAwMDAwMDAwICsgMHhmZmZmZmZmZiBpcyBhIHNhZmUgaW50ZWdlclxudmFyIEJBU0UgPSAxMDAwMDAwO1xuXG5mdW5jdGlvbiByZWFkSW50OChidWZmZXIpIHtcblx0dmFyIGhpZ2ggPSBidWZmZXIucmVhZEludDMyQkUoMCk7XG5cdHZhciBsb3cgPSBidWZmZXIucmVhZFVJbnQzMkJFKDQpO1xuXHR2YXIgc2lnbiA9ICcnO1xuXG5cdGlmIChoaWdoIDwgMCkge1xuXHRcdGhpZ2ggPSB+aGlnaCArIChsb3cgPT09IDApO1xuXHRcdGxvdyA9ICh+bG93ICsgMSkgPj4+IDA7XG5cdFx0c2lnbiA9ICctJztcblx0fVxuXG5cdHZhciByZXN1bHQgPSAnJztcblx0dmFyIGNhcnJ5O1xuXHR2YXIgdDtcblx0dmFyIGRpZ2l0cztcblx0dmFyIHBhZDtcblx0dmFyIGw7XG5cdHZhciBpO1xuXG5cdHtcblx0XHRjYXJyeSA9IGhpZ2ggJSBCQVNFO1xuXHRcdGhpZ2ggPSBoaWdoIC8gQkFTRSA+Pj4gMDtcblxuXHRcdHQgPSAweDEwMDAwMDAwMCAqIGNhcnJ5ICsgbG93O1xuXHRcdGxvdyA9IHQgLyBCQVNFID4+PiAwO1xuXHRcdGRpZ2l0cyA9ICcnICsgKHQgLSBCQVNFICogbG93KTtcblxuXHRcdGlmIChsb3cgPT09IDAgJiYgaGlnaCA9PT0gMCkge1xuXHRcdFx0cmV0dXJuIHNpZ24gKyBkaWdpdHMgKyByZXN1bHQ7XG5cdFx0fVxuXG5cdFx0cGFkID0gJyc7XG5cdFx0bCA9IDYgLSBkaWdpdHMubGVuZ3RoO1xuXG5cdFx0Zm9yIChpID0gMDsgaSA8IGw7IGkrKykge1xuXHRcdFx0cGFkICs9ICcwJztcblx0XHR9XG5cblx0XHRyZXN1bHQgPSBwYWQgKyBkaWdpdHMgKyByZXN1bHQ7XG5cdH1cblxuXHR7XG5cdFx0Y2FycnkgPSBoaWdoICUgQkFTRTtcblx0XHRoaWdoID0gaGlnaCAvIEJBU0UgPj4+IDA7XG5cblx0XHR0ID0gMHgxMDAwMDAwMDAgKiBjYXJyeSArIGxvdztcblx0XHRsb3cgPSB0IC8gQkFTRSA+Pj4gMDtcblx0XHRkaWdpdHMgPSAnJyArICh0IC0gQkFTRSAqIGxvdyk7XG5cblx0XHRpZiAobG93ID09PSAwICYmIGhpZ2ggPT09IDApIHtcblx0XHRcdHJldHVybiBzaWduICsgZGlnaXRzICsgcmVzdWx0O1xuXHRcdH1cblxuXHRcdHBhZCA9ICcnO1xuXHRcdGwgPSA2IC0gZGlnaXRzLmxlbmd0aDtcblxuXHRcdGZvciAoaSA9IDA7IGkgPCBsOyBpKyspIHtcblx0XHRcdHBhZCArPSAnMCc7XG5cdFx0fVxuXG5cdFx0cmVzdWx0ID0gcGFkICsgZGlnaXRzICsgcmVzdWx0O1xuXHR9XG5cblx0e1xuXHRcdGNhcnJ5ID0gaGlnaCAlIEJBU0U7XG5cdFx0aGlnaCA9IGhpZ2ggLyBCQVNFID4+PiAwO1xuXG5cdFx0dCA9IDB4MTAwMDAwMDAwICogY2FycnkgKyBsb3c7XG5cdFx0bG93ID0gdCAvIEJBU0UgPj4+IDA7XG5cdFx0ZGlnaXRzID0gJycgKyAodCAtIEJBU0UgKiBsb3cpO1xuXG5cdFx0aWYgKGxvdyA9PT0gMCAmJiBoaWdoID09PSAwKSB7XG5cdFx0XHRyZXR1cm4gc2lnbiArIGRpZ2l0cyArIHJlc3VsdDtcblx0XHR9XG5cblx0XHRwYWQgPSAnJztcblx0XHRsID0gNiAtIGRpZ2l0cy5sZW5ndGg7XG5cblx0XHRmb3IgKGkgPSAwOyBpIDwgbDsgaSsrKSB7XG5cdFx0XHRwYWQgKz0gJzAnO1xuXHRcdH1cblxuXHRcdHJlc3VsdCA9IHBhZCArIGRpZ2l0cyArIHJlc3VsdDtcblx0fVxuXG5cdHtcblx0XHRjYXJyeSA9IGhpZ2ggJSBCQVNFO1xuXHRcdHQgPSAweDEwMDAwMDAwMCAqIGNhcnJ5ICsgbG93O1xuXHRcdGRpZ2l0cyA9ICcnICsgdCAlIEJBU0U7XG5cblx0XHRyZXR1cm4gc2lnbiArIGRpZ2l0cyArIHJlc3VsdDtcblx0fVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHJlYWRJbnQ4O1xuIiwiJ3VzZSBzdHJpY3QnXG5jb25zdCBFdmVudEVtaXR0ZXIgPSByZXF1aXJlKCdldmVudHMnKS5FdmVudEVtaXR0ZXJcblxuY29uc3QgTk9PUCA9IGZ1bmN0aW9uICgpIHt9XG5cbmNvbnN0IHJlbW92ZVdoZXJlID0gKGxpc3QsIHByZWRpY2F0ZSkgPT4ge1xuICBjb25zdCBpID0gbGlzdC5maW5kSW5kZXgocHJlZGljYXRlKVxuXG4gIHJldHVybiBpID09PSAtMSA/IHVuZGVmaW5lZCA6IGxpc3Quc3BsaWNlKGksIDEpWzBdXG59XG5cbmNsYXNzIElkbGVJdGVtIHtcbiAgY29uc3RydWN0b3IoY2xpZW50LCBpZGxlTGlzdGVuZXIsIHRpbWVvdXRJZCkge1xuICAgIHRoaXMuY2xpZW50ID0gY2xpZW50XG4gICAgdGhpcy5pZGxlTGlzdGVuZXIgPSBpZGxlTGlzdGVuZXJcbiAgICB0aGlzLnRpbWVvdXRJZCA9IHRpbWVvdXRJZFxuICB9XG59XG5cbmNsYXNzIFBlbmRpbmdJdGVtIHtcbiAgY29uc3RydWN0b3IoY2FsbGJhY2spIHtcbiAgICB0aGlzLmNhbGxiYWNrID0gY2FsbGJhY2tcbiAgfVxufVxuXG5mdW5jdGlvbiB0aHJvd09uRG91YmxlUmVsZWFzZSgpIHtcbiAgdGhyb3cgbmV3IEVycm9yKCdSZWxlYXNlIGNhbGxlZCBvbiBjbGllbnQgd2hpY2ggaGFzIGFscmVhZHkgYmVlbiByZWxlYXNlZCB0byB0aGUgcG9vbC4nKVxufVxuXG5mdW5jdGlvbiBwcm9taXNpZnkoUHJvbWlzZSwgY2FsbGJhY2spIHtcbiAgaWYgKGNhbGxiYWNrKSB7XG4gICAgcmV0dXJuIHsgY2FsbGJhY2s6IGNhbGxiYWNrLCByZXN1bHQ6IHVuZGVmaW5lZCB9XG4gIH1cbiAgbGV0IHJlalxuICBsZXQgcmVzXG4gIGNvbnN0IGNiID0gZnVuY3Rpb24gKGVyciwgY2xpZW50KSB7XG4gICAgZXJyID8gcmVqKGVycikgOiByZXMoY2xpZW50KVxuICB9XG4gIGNvbnN0IHJlc3VsdCA9IG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICByZXMgPSByZXNvbHZlXG4gICAgcmVqID0gcmVqZWN0XG4gIH0pXG4gIHJldHVybiB7IGNhbGxiYWNrOiBjYiwgcmVzdWx0OiByZXN1bHQgfVxufVxuXG5mdW5jdGlvbiBtYWtlSWRsZUxpc3RlbmVyKHBvb2wsIGNsaWVudCkge1xuICByZXR1cm4gZnVuY3Rpb24gaWRsZUxpc3RlbmVyKGVycikge1xuICAgIGVyci5jbGllbnQgPSBjbGllbnRcblxuICAgIGNsaWVudC5yZW1vdmVMaXN0ZW5lcignZXJyb3InLCBpZGxlTGlzdGVuZXIpXG4gICAgY2xpZW50Lm9uKCdlcnJvcicsICgpID0+IHtcbiAgICAgIHBvb2wubG9nKCdhZGRpdGlvbmFsIGNsaWVudCBlcnJvciBhZnRlciBkaXNjb25uZWN0aW9uIGR1ZSB0byBlcnJvcicsIGVycilcbiAgICB9KVxuICAgIHBvb2wuX3JlbW92ZShjbGllbnQpXG4gICAgLy8gVE9ETyAtIGRvY3VtZW50IHRoYXQgb25jZSB0aGUgcG9vbCBlbWl0cyBhbiBlcnJvclxuICAgIC8vIHRoZSBjbGllbnQgaGFzIGFscmVhZHkgYmVlbiBjbG9zZWQgJiBwdXJnZWQgYW5kIGlzIHVudXNhYmxlXG4gICAgcG9vbC5lbWl0KCdlcnJvcicsIGVyciwgY2xpZW50KVxuICB9XG59XG5cbmNsYXNzIFBvb2wgZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBjb25zdHJ1Y3RvcihvcHRpb25zLCBDbGllbnQpIHtcbiAgICBzdXBlcigpXG4gICAgdGhpcy5vcHRpb25zID0gT2JqZWN0LmFzc2lnbih7fSwgb3B0aW9ucylcblxuICAgIGlmIChvcHRpb25zICE9IG51bGwgJiYgJ3Bhc3N3b3JkJyBpbiBvcHRpb25zKSB7XG4gICAgICAvLyBcImhpZGluZ1wiIHRoZSBwYXNzd29yZCBzbyBpdCBkb2Vzbid0IHNob3cgdXAgaW4gc3RhY2sgdHJhY2VzXG4gICAgICAvLyBvciBpZiB0aGUgY2xpZW50IGlzIGNvbnNvbGUubG9nZ2VkXG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcy5vcHRpb25zLCAncGFzc3dvcmQnLCB7XG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgICB2YWx1ZTogb3B0aW9ucy5wYXNzd29yZCxcbiAgICAgIH0pXG4gICAgfVxuICAgIGlmIChvcHRpb25zICE9IG51bGwgJiYgb3B0aW9ucy5zc2wgJiYgb3B0aW9ucy5zc2wua2V5KSB7XG4gICAgICAvLyBcImhpZGluZ1wiIHRoZSBzc2wtPmtleSBzbyBpdCBkb2Vzbid0IHNob3cgdXAgaW4gc3RhY2sgdHJhY2VzXG4gICAgICAvLyBvciBpZiB0aGUgY2xpZW50IGlzIGNvbnNvbGUubG9nZ2VkXG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcy5vcHRpb25zLnNzbCwgJ2tleScsIHtcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICB9KVxuICAgIH1cblxuICAgIHRoaXMub3B0aW9ucy5tYXggPSB0aGlzLm9wdGlvbnMubWF4IHx8IHRoaXMub3B0aW9ucy5wb29sU2l6ZSB8fCAxMFxuICAgIHRoaXMub3B0aW9ucy5tYXhVc2VzID0gdGhpcy5vcHRpb25zLm1heFVzZXMgfHwgSW5maW5pdHlcbiAgICB0aGlzLm9wdGlvbnMuYWxsb3dFeGl0T25JZGxlID0gdGhpcy5vcHRpb25zLmFsbG93RXhpdE9uSWRsZSB8fCBmYWxzZVxuICAgIHRoaXMubG9nID0gdGhpcy5vcHRpb25zLmxvZyB8fCBmdW5jdGlvbiAoKSB7fVxuICAgIHRoaXMuQ2xpZW50ID0gdGhpcy5vcHRpb25zLkNsaWVudCB8fCBDbGllbnQgfHwgcmVxdWlyZSgncGcnKS5DbGllbnRcbiAgICB0aGlzLlByb21pc2UgPSB0aGlzLm9wdGlvbnMuUHJvbWlzZSB8fCBnbG9iYWwuUHJvbWlzZVxuXG4gICAgaWYgKHR5cGVvZiB0aGlzLm9wdGlvbnMuaWRsZVRpbWVvdXRNaWxsaXMgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICB0aGlzLm9wdGlvbnMuaWRsZVRpbWVvdXRNaWxsaXMgPSAxMDAwMFxuICAgIH1cblxuICAgIHRoaXMuX2NsaWVudHMgPSBbXVxuICAgIHRoaXMuX2lkbGUgPSBbXVxuICAgIHRoaXMuX3BlbmRpbmdRdWV1ZSA9IFtdXG4gICAgdGhpcy5fZW5kQ2FsbGJhY2sgPSB1bmRlZmluZWRcbiAgICB0aGlzLmVuZGluZyA9IGZhbHNlXG4gICAgdGhpcy5lbmRlZCA9IGZhbHNlXG4gIH1cblxuICBfaXNGdWxsKCkge1xuICAgIHJldHVybiB0aGlzLl9jbGllbnRzLmxlbmd0aCA+PSB0aGlzLm9wdGlvbnMubWF4XG4gIH1cblxuICBfcHVsc2VRdWV1ZSgpIHtcbiAgICB0aGlzLmxvZygncHVsc2UgcXVldWUnKVxuICAgIGlmICh0aGlzLmVuZGVkKSB7XG4gICAgICB0aGlzLmxvZygncHVsc2UgcXVldWUgZW5kZWQnKVxuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIGlmICh0aGlzLmVuZGluZykge1xuICAgICAgdGhpcy5sb2coJ3B1bHNlIHF1ZXVlIG9uIGVuZGluZycpXG4gICAgICBpZiAodGhpcy5faWRsZS5sZW5ndGgpIHtcbiAgICAgICAgdGhpcy5faWRsZS5zbGljZSgpLm1hcCgoaXRlbSkgPT4ge1xuICAgICAgICAgIHRoaXMuX3JlbW92ZShpdGVtLmNsaWVudClcbiAgICAgICAgfSlcbiAgICAgIH1cbiAgICAgIGlmICghdGhpcy5fY2xpZW50cy5sZW5ndGgpIHtcbiAgICAgICAgdGhpcy5lbmRlZCA9IHRydWVcbiAgICAgICAgdGhpcy5fZW5kQ2FsbGJhY2soKVxuICAgICAgfVxuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIC8vIGlmIHdlIGRvbid0IGhhdmUgYW55IHdhaXRpbmcsIGRvIG5vdGhpbmdcbiAgICBpZiAoIXRoaXMuX3BlbmRpbmdRdWV1ZS5sZW5ndGgpIHtcbiAgICAgIHRoaXMubG9nKCdubyBxdWV1ZWQgcmVxdWVzdHMnKVxuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIC8vIGlmIHdlIGRvbid0IGhhdmUgYW55IGlkbGUgY2xpZW50cyBhbmQgd2UgaGF2ZSBubyBtb3JlIHJvb20gZG8gbm90aGluZ1xuICAgIGlmICghdGhpcy5faWRsZS5sZW5ndGggJiYgdGhpcy5faXNGdWxsKCkpIHtcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICBjb25zdCBwZW5kaW5nSXRlbSA9IHRoaXMuX3BlbmRpbmdRdWV1ZS5zaGlmdCgpXG4gICAgaWYgKHRoaXMuX2lkbGUubGVuZ3RoKSB7XG4gICAgICBjb25zdCBpZGxlSXRlbSA9IHRoaXMuX2lkbGUucG9wKClcbiAgICAgIGNsZWFyVGltZW91dChpZGxlSXRlbS50aW1lb3V0SWQpXG4gICAgICBjb25zdCBjbGllbnQgPSBpZGxlSXRlbS5jbGllbnRcbiAgICAgIGNsaWVudC5yZWYgJiYgY2xpZW50LnJlZigpXG4gICAgICBjb25zdCBpZGxlTGlzdGVuZXIgPSBpZGxlSXRlbS5pZGxlTGlzdGVuZXJcblxuICAgICAgcmV0dXJuIHRoaXMuX2FjcXVpcmVDbGllbnQoY2xpZW50LCBwZW5kaW5nSXRlbSwgaWRsZUxpc3RlbmVyLCBmYWxzZSlcbiAgICB9XG4gICAgaWYgKCF0aGlzLl9pc0Z1bGwoKSkge1xuICAgICAgcmV0dXJuIHRoaXMubmV3Q2xpZW50KHBlbmRpbmdJdGVtKVxuICAgIH1cbiAgICB0aHJvdyBuZXcgRXJyb3IoJ3VuZXhwZWN0ZWQgY29uZGl0aW9uJylcbiAgfVxuXG4gIF9yZW1vdmUoY2xpZW50KSB7XG4gICAgY29uc3QgcmVtb3ZlZCA9IHJlbW92ZVdoZXJlKHRoaXMuX2lkbGUsIChpdGVtKSA9PiBpdGVtLmNsaWVudCA9PT0gY2xpZW50KVxuXG4gICAgaWYgKHJlbW92ZWQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgY2xlYXJUaW1lb3V0KHJlbW92ZWQudGltZW91dElkKVxuICAgIH1cblxuICAgIHRoaXMuX2NsaWVudHMgPSB0aGlzLl9jbGllbnRzLmZpbHRlcigoYykgPT4gYyAhPT0gY2xpZW50KVxuICAgIGNsaWVudC5lbmQoKVxuICAgIHRoaXMuZW1pdCgncmVtb3ZlJywgY2xpZW50KVxuICB9XG5cbiAgY29ubmVjdChjYikge1xuICAgIGlmICh0aGlzLmVuZGluZykge1xuICAgICAgY29uc3QgZXJyID0gbmV3IEVycm9yKCdDYW5ub3QgdXNlIGEgcG9vbCBhZnRlciBjYWxsaW5nIGVuZCBvbiB0aGUgcG9vbCcpXG4gICAgICByZXR1cm4gY2IgPyBjYihlcnIpIDogdGhpcy5Qcm9taXNlLnJlamVjdChlcnIpXG4gICAgfVxuXG4gICAgY29uc3QgcmVzcG9uc2UgPSBwcm9taXNpZnkodGhpcy5Qcm9taXNlLCBjYilcbiAgICBjb25zdCByZXN1bHQgPSByZXNwb25zZS5yZXN1bHRcblxuICAgIC8vIGlmIHdlIGRvbid0IGhhdmUgdG8gY29ubmVjdCBhIG5ldyBjbGllbnQsIGRvbid0IGRvIHNvXG4gICAgaWYgKHRoaXMuX2lzRnVsbCgpIHx8IHRoaXMuX2lkbGUubGVuZ3RoKSB7XG4gICAgICAvLyBpZiB3ZSBoYXZlIGlkbGUgY2xpZW50cyBzY2hlZHVsZSBhIHB1bHNlIGltbWVkaWF0ZWx5XG4gICAgICBpZiAodGhpcy5faWRsZS5sZW5ndGgpIHtcbiAgICAgICAgcHJvY2Vzcy5uZXh0VGljaygoKSA9PiB0aGlzLl9wdWxzZVF1ZXVlKCkpXG4gICAgICB9XG5cbiAgICAgIGlmICghdGhpcy5vcHRpb25zLmNvbm5lY3Rpb25UaW1lb3V0TWlsbGlzKSB7XG4gICAgICAgIHRoaXMuX3BlbmRpbmdRdWV1ZS5wdXNoKG5ldyBQZW5kaW5nSXRlbShyZXNwb25zZS5jYWxsYmFjaykpXG4gICAgICAgIHJldHVybiByZXN1bHRcbiAgICAgIH1cblxuICAgICAgY29uc3QgcXVldWVDYWxsYmFjayA9IChlcnIsIHJlcywgZG9uZSkgPT4ge1xuICAgICAgICBjbGVhclRpbWVvdXQodGlkKVxuICAgICAgICByZXNwb25zZS5jYWxsYmFjayhlcnIsIHJlcywgZG9uZSlcbiAgICAgIH1cblxuICAgICAgY29uc3QgcGVuZGluZ0l0ZW0gPSBuZXcgUGVuZGluZ0l0ZW0ocXVldWVDYWxsYmFjaylcblxuICAgICAgLy8gc2V0IGNvbm5lY3Rpb24gdGltZW91dCBvbiBjaGVja2luZyBvdXQgYW4gZXhpc3RpbmcgY2xpZW50XG4gICAgICBjb25zdCB0aWQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgLy8gcmVtb3ZlIHRoZSBjYWxsYmFjayBmcm9tIHBlbmRpbmcgd2FpdGVycyBiZWNhdXNlXG4gICAgICAgIC8vIHdlJ3JlIGdvaW5nIHRvIGNhbGwgaXQgd2l0aCBhIHRpbWVvdXQgZXJyb3JcbiAgICAgICAgcmVtb3ZlV2hlcmUodGhpcy5fcGVuZGluZ1F1ZXVlLCAoaSkgPT4gaS5jYWxsYmFjayA9PT0gcXVldWVDYWxsYmFjaylcbiAgICAgICAgcGVuZGluZ0l0ZW0udGltZWRPdXQgPSB0cnVlXG4gICAgICAgIHJlc3BvbnNlLmNhbGxiYWNrKG5ldyBFcnJvcigndGltZW91dCBleGNlZWRlZCB3aGVuIHRyeWluZyB0byBjb25uZWN0JykpXG4gICAgICB9LCB0aGlzLm9wdGlvbnMuY29ubmVjdGlvblRpbWVvdXRNaWxsaXMpXG5cbiAgICAgIHRoaXMuX3BlbmRpbmdRdWV1ZS5wdXNoKHBlbmRpbmdJdGVtKVxuICAgICAgcmV0dXJuIHJlc3VsdFxuICAgIH1cblxuICAgIHRoaXMubmV3Q2xpZW50KG5ldyBQZW5kaW5nSXRlbShyZXNwb25zZS5jYWxsYmFjaykpXG5cbiAgICByZXR1cm4gcmVzdWx0XG4gIH1cblxuICBuZXdDbGllbnQocGVuZGluZ0l0ZW0pIHtcbiAgICBjb25zdCBjbGllbnQgPSBuZXcgdGhpcy5DbGllbnQodGhpcy5vcHRpb25zKVxuICAgIHRoaXMuX2NsaWVudHMucHVzaChjbGllbnQpXG4gICAgY29uc3QgaWRsZUxpc3RlbmVyID0gbWFrZUlkbGVMaXN0ZW5lcih0aGlzLCBjbGllbnQpXG5cbiAgICB0aGlzLmxvZygnY2hlY2tpbmcgY2xpZW50IHRpbWVvdXQnKVxuXG4gICAgLy8gY29ubmVjdGlvbiB0aW1lb3V0IGxvZ2ljXG4gICAgbGV0IHRpZFxuICAgIGxldCB0aW1lb3V0SGl0ID0gZmFsc2VcbiAgICBpZiAodGhpcy5vcHRpb25zLmNvbm5lY3Rpb25UaW1lb3V0TWlsbGlzKSB7XG4gICAgICB0aWQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgdGhpcy5sb2coJ2VuZGluZyBjbGllbnQgZHVlIHRvIHRpbWVvdXQnKVxuICAgICAgICB0aW1lb3V0SGl0ID0gdHJ1ZVxuICAgICAgICAvLyBmb3JjZSBraWxsIHRoZSBub2RlIGRyaXZlciwgYW5kIGxldCBsaWJwcSBkbyBpdHMgdGVhcmRvd25cbiAgICAgICAgY2xpZW50LmNvbm5lY3Rpb24gPyBjbGllbnQuY29ubmVjdGlvbi5zdHJlYW0uZGVzdHJveSgpIDogY2xpZW50LmVuZCgpXG4gICAgICB9LCB0aGlzLm9wdGlvbnMuY29ubmVjdGlvblRpbWVvdXRNaWxsaXMpXG4gICAgfVxuXG4gICAgdGhpcy5sb2coJ2Nvbm5lY3RpbmcgbmV3IGNsaWVudCcpXG4gICAgY2xpZW50LmNvbm5lY3QoKGVycikgPT4ge1xuICAgICAgaWYgKHRpZCkge1xuICAgICAgICBjbGVhclRpbWVvdXQodGlkKVxuICAgICAgfVxuICAgICAgY2xpZW50Lm9uKCdlcnJvcicsIGlkbGVMaXN0ZW5lcilcbiAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgdGhpcy5sb2coJ2NsaWVudCBmYWlsZWQgdG8gY29ubmVjdCcsIGVycilcbiAgICAgICAgLy8gcmVtb3ZlIHRoZSBkZWFkIGNsaWVudCBmcm9tIG91ciBsaXN0IG9mIGNsaWVudHNcbiAgICAgICAgdGhpcy5fY2xpZW50cyA9IHRoaXMuX2NsaWVudHMuZmlsdGVyKChjKSA9PiBjICE9PSBjbGllbnQpXG4gICAgICAgIGlmICh0aW1lb3V0SGl0KSB7XG4gICAgICAgICAgZXJyLm1lc3NhZ2UgPSAnQ29ubmVjdGlvbiB0ZXJtaW5hdGVkIGR1ZSB0byBjb25uZWN0aW9uIHRpbWVvdXQnXG4gICAgICAgIH1cblxuICAgICAgICAvLyB0aGlzIGNsaWVudCB3b27igJl0IGJlIHJlbGVhc2VkLCBzbyBtb3ZlIG9uIGltbWVkaWF0ZWx5XG4gICAgICAgIHRoaXMuX3B1bHNlUXVldWUoKVxuXG4gICAgICAgIGlmICghcGVuZGluZ0l0ZW0udGltZWRPdXQpIHtcbiAgICAgICAgICBwZW5kaW5nSXRlbS5jYWxsYmFjayhlcnIsIHVuZGVmaW5lZCwgTk9PUClcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5sb2coJ25ldyBjbGllbnQgY29ubmVjdGVkJylcblxuICAgICAgICByZXR1cm4gdGhpcy5fYWNxdWlyZUNsaWVudChjbGllbnQsIHBlbmRpbmdJdGVtLCBpZGxlTGlzdGVuZXIsIHRydWUpXG4gICAgICB9XG4gICAgfSlcbiAgfVxuXG4gIC8vIGFjcXVpcmUgYSBjbGllbnQgZm9yIGEgcGVuZGluZyB3b3JrIGl0ZW1cbiAgX2FjcXVpcmVDbGllbnQoY2xpZW50LCBwZW5kaW5nSXRlbSwgaWRsZUxpc3RlbmVyLCBpc05ldykge1xuICAgIGlmIChpc05ldykge1xuICAgICAgdGhpcy5lbWl0KCdjb25uZWN0JywgY2xpZW50KVxuICAgIH1cblxuICAgIHRoaXMuZW1pdCgnYWNxdWlyZScsIGNsaWVudClcblxuICAgIGNsaWVudC5yZWxlYXNlID0gdGhpcy5fcmVsZWFzZU9uY2UoY2xpZW50LCBpZGxlTGlzdGVuZXIpXG5cbiAgICBjbGllbnQucmVtb3ZlTGlzdGVuZXIoJ2Vycm9yJywgaWRsZUxpc3RlbmVyKVxuXG4gICAgaWYgKCFwZW5kaW5nSXRlbS50aW1lZE91dCkge1xuICAgICAgaWYgKGlzTmV3ICYmIHRoaXMub3B0aW9ucy52ZXJpZnkpIHtcbiAgICAgICAgdGhpcy5vcHRpb25zLnZlcmlmeShjbGllbnQsIChlcnIpID0+IHtcbiAgICAgICAgICBpZiAoZXJyKSB7XG4gICAgICAgICAgICBjbGllbnQucmVsZWFzZShlcnIpXG4gICAgICAgICAgICByZXR1cm4gcGVuZGluZ0l0ZW0uY2FsbGJhY2soZXJyLCB1bmRlZmluZWQsIE5PT1ApXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgcGVuZGluZ0l0ZW0uY2FsbGJhY2sodW5kZWZpbmVkLCBjbGllbnQsIGNsaWVudC5yZWxlYXNlKVxuICAgICAgICB9KVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcGVuZGluZ0l0ZW0uY2FsbGJhY2sodW5kZWZpbmVkLCBjbGllbnQsIGNsaWVudC5yZWxlYXNlKVxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoaXNOZXcgJiYgdGhpcy5vcHRpb25zLnZlcmlmeSkge1xuICAgICAgICB0aGlzLm9wdGlvbnMudmVyaWZ5KGNsaWVudCwgY2xpZW50LnJlbGVhc2UpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjbGllbnQucmVsZWFzZSgpXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLy8gcmV0dXJucyBhIGZ1bmN0aW9uIHRoYXQgd3JhcHMgX3JlbGVhc2UgYW5kIHRocm93cyBpZiBjYWxsZWQgbW9yZSB0aGFuIG9uY2VcbiAgX3JlbGVhc2VPbmNlKGNsaWVudCwgaWRsZUxpc3RlbmVyKSB7XG4gICAgbGV0IHJlbGVhc2VkID0gZmFsc2VcblxuICAgIHJldHVybiAoZXJyKSA9PiB7XG4gICAgICBpZiAocmVsZWFzZWQpIHtcbiAgICAgICAgdGhyb3dPbkRvdWJsZVJlbGVhc2UoKVxuICAgICAgfVxuXG4gICAgICByZWxlYXNlZCA9IHRydWVcbiAgICAgIHRoaXMuX3JlbGVhc2UoY2xpZW50LCBpZGxlTGlzdGVuZXIsIGVycilcbiAgICB9XG4gIH1cblxuICAvLyByZWxlYXNlIGEgY2xpZW50IGJhY2sgdG8gdGhlIHBvbGwsIGluY2x1ZGUgYW4gZXJyb3JcbiAgLy8gdG8gcmVtb3ZlIGl0IGZyb20gdGhlIHBvb2xcbiAgX3JlbGVhc2UoY2xpZW50LCBpZGxlTGlzdGVuZXIsIGVycikge1xuICAgIGNsaWVudC5vbignZXJyb3InLCBpZGxlTGlzdGVuZXIpXG5cbiAgICBjbGllbnQuX3Bvb2xVc2VDb3VudCA9IChjbGllbnQuX3Bvb2xVc2VDb3VudCB8fCAwKSArIDFcblxuICAgIC8vIFRPRE8oYm1jKTogZXhwb3NlIGEgcHJvcGVyLCBwdWJsaWMgaW50ZXJmYWNlIF9xdWVyeWFibGUgYW5kIF9lbmRpbmdcbiAgICBpZiAoZXJyIHx8IHRoaXMuZW5kaW5nIHx8ICFjbGllbnQuX3F1ZXJ5YWJsZSB8fCBjbGllbnQuX2VuZGluZyB8fCBjbGllbnQuX3Bvb2xVc2VDb3VudCA+PSB0aGlzLm9wdGlvbnMubWF4VXNlcykge1xuICAgICAgaWYgKGNsaWVudC5fcG9vbFVzZUNvdW50ID49IHRoaXMub3B0aW9ucy5tYXhVc2VzKSB7XG4gICAgICAgIHRoaXMubG9nKCdyZW1vdmUgZXhwZW5kZWQgY2xpZW50JylcbiAgICAgIH1cbiAgICAgIHRoaXMuX3JlbW92ZShjbGllbnQpXG4gICAgICB0aGlzLl9wdWxzZVF1ZXVlKClcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIC8vIGlkbGUgdGltZW91dFxuICAgIGxldCB0aWRcbiAgICBpZiAodGhpcy5vcHRpb25zLmlkbGVUaW1lb3V0TWlsbGlzKSB7XG4gICAgICB0aWQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgdGhpcy5sb2coJ3JlbW92ZSBpZGxlIGNsaWVudCcpXG4gICAgICAgIHRoaXMuX3JlbW92ZShjbGllbnQpXG4gICAgICB9LCB0aGlzLm9wdGlvbnMuaWRsZVRpbWVvdXRNaWxsaXMpXG5cbiAgICAgIGlmICh0aGlzLm9wdGlvbnMuYWxsb3dFeGl0T25JZGxlKSB7XG4gICAgICAgIC8vIGFsbG93IE5vZGUgdG8gZXhpdCBpZiB0aGlzIGlzIGFsbCB0aGF0J3MgbGVmdFxuICAgICAgICB0aWQudW5yZWYoKVxuICAgICAgfVxuICAgIH1cblxuICAgIGlmICh0aGlzLm9wdGlvbnMuYWxsb3dFeGl0T25JZGxlKSB7XG4gICAgICBjbGllbnQudW5yZWYoKVxuICAgIH1cblxuICAgIHRoaXMuX2lkbGUucHVzaChuZXcgSWRsZUl0ZW0oY2xpZW50LCBpZGxlTGlzdGVuZXIsIHRpZCkpXG4gICAgdGhpcy5fcHVsc2VRdWV1ZSgpXG4gIH1cblxuICBxdWVyeSh0ZXh0LCB2YWx1ZXMsIGNiKSB7XG4gICAgLy8gZ3VhcmQgY2xhdXNlIGFnYWluc3QgcGFzc2luZyBhIGZ1bmN0aW9uIGFzIHRoZSBmaXJzdCBwYXJhbWV0ZXJcbiAgICBpZiAodHlwZW9mIHRleHQgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gcHJvbWlzaWZ5KHRoaXMuUHJvbWlzZSwgdGV4dClcbiAgICAgIHNldEltbWVkaWF0ZShmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5jYWxsYmFjayhuZXcgRXJyb3IoJ1Bhc3NpbmcgYSBmdW5jdGlvbiBhcyB0aGUgZmlyc3QgcGFyYW1ldGVyIHRvIHBvb2wucXVlcnkgaXMgbm90IHN1cHBvcnRlZCcpKVxuICAgICAgfSlcbiAgICAgIHJldHVybiByZXNwb25zZS5yZXN1bHRcbiAgICB9XG5cbiAgICAvLyBhbGxvdyBwbGFpbiB0ZXh0IHF1ZXJ5IHdpdGhvdXQgdmFsdWVzXG4gICAgaWYgKHR5cGVvZiB2YWx1ZXMgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIGNiID0gdmFsdWVzXG4gICAgICB2YWx1ZXMgPSB1bmRlZmluZWRcbiAgICB9XG4gICAgY29uc3QgcmVzcG9uc2UgPSBwcm9taXNpZnkodGhpcy5Qcm9taXNlLCBjYilcbiAgICBjYiA9IHJlc3BvbnNlLmNhbGxiYWNrXG5cbiAgICB0aGlzLmNvbm5lY3QoKGVyciwgY2xpZW50KSA9PiB7XG4gICAgICBpZiAoZXJyKSB7XG4gICAgICAgIHJldHVybiBjYihlcnIpXG4gICAgICB9XG5cbiAgICAgIGxldCBjbGllbnRSZWxlYXNlZCA9IGZhbHNlXG4gICAgICBjb25zdCBvbkVycm9yID0gKGVycikgPT4ge1xuICAgICAgICBpZiAoY2xpZW50UmVsZWFzZWQpIHtcbiAgICAgICAgICByZXR1cm5cbiAgICAgICAgfVxuICAgICAgICBjbGllbnRSZWxlYXNlZCA9IHRydWVcbiAgICAgICAgY2xpZW50LnJlbGVhc2UoZXJyKVxuICAgICAgICBjYihlcnIpXG4gICAgICB9XG5cbiAgICAgIGNsaWVudC5vbmNlKCdlcnJvcicsIG9uRXJyb3IpXG4gICAgICB0aGlzLmxvZygnZGlzcGF0Y2hpbmcgcXVlcnknKVxuICAgICAgY2xpZW50LnF1ZXJ5KHRleHQsIHZhbHVlcywgKGVyciwgcmVzKSA9PiB7XG4gICAgICAgIHRoaXMubG9nKCdxdWVyeSBkaXNwYXRjaGVkJylcbiAgICAgICAgY2xpZW50LnJlbW92ZUxpc3RlbmVyKCdlcnJvcicsIG9uRXJyb3IpXG4gICAgICAgIGlmIChjbGllbnRSZWxlYXNlZCkge1xuICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG4gICAgICAgIGNsaWVudFJlbGVhc2VkID0gdHJ1ZVxuICAgICAgICBjbGllbnQucmVsZWFzZShlcnIpXG4gICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICByZXR1cm4gY2IoZXJyKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiBjYih1bmRlZmluZWQsIHJlcylcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9KVxuICAgIHJldHVybiByZXNwb25zZS5yZXN1bHRcbiAgfVxuXG4gIGVuZChjYikge1xuICAgIHRoaXMubG9nKCdlbmRpbmcnKVxuICAgIGlmICh0aGlzLmVuZGluZykge1xuICAgICAgY29uc3QgZXJyID0gbmV3IEVycm9yKCdDYWxsZWQgZW5kIG9uIHBvb2wgbW9yZSB0aGFuIG9uY2UnKVxuICAgICAgcmV0dXJuIGNiID8gY2IoZXJyKSA6IHRoaXMuUHJvbWlzZS5yZWplY3QoZXJyKVxuICAgIH1cbiAgICB0aGlzLmVuZGluZyA9IHRydWVcbiAgICBjb25zdCBwcm9taXNlZCA9IHByb21pc2lmeSh0aGlzLlByb21pc2UsIGNiKVxuICAgIHRoaXMuX2VuZENhbGxiYWNrID0gcHJvbWlzZWQuY2FsbGJhY2tcbiAgICB0aGlzLl9wdWxzZVF1ZXVlKClcbiAgICByZXR1cm4gcHJvbWlzZWQucmVzdWx0XG4gIH1cblxuICBnZXQgd2FpdGluZ0NvdW50KCkge1xuICAgIHJldHVybiB0aGlzLl9wZW5kaW5nUXVldWUubGVuZ3RoXG4gIH1cblxuICBnZXQgaWRsZUNvdW50KCkge1xuICAgIHJldHVybiB0aGlzLl9pZGxlLmxlbmd0aFxuICB9XG5cbiAgZ2V0IHRvdGFsQ291bnQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NsaWVudHMubGVuZ3RoXG4gIH1cbn1cbm1vZHVsZS5leHBvcnRzID0gUG9vbFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLkJ1ZmZlclJlYWRlciA9IHZvaWQgMDtcbmNvbnN0IGVtcHR5QnVmZmVyID0gQnVmZmVyLmFsbG9jVW5zYWZlKDApO1xuY2xhc3MgQnVmZmVyUmVhZGVyIHtcbiAgICBjb25zdHJ1Y3RvcihvZmZzZXQgPSAwKSB7XG4gICAgICAgIHRoaXMub2Zmc2V0ID0gb2Zmc2V0O1xuICAgICAgICB0aGlzLmJ1ZmZlciA9IGVtcHR5QnVmZmVyO1xuICAgICAgICAvLyBUT0RPKGJtYyk6IHN1cHBvcnQgbm9uLXV0ZjggZW5jb2Rpbmc/XG4gICAgICAgIHRoaXMuZW5jb2RpbmcgPSAndXRmLTgnO1xuICAgIH1cbiAgICBzZXRCdWZmZXIob2Zmc2V0LCBidWZmZXIpIHtcbiAgICAgICAgdGhpcy5vZmZzZXQgPSBvZmZzZXQ7XG4gICAgICAgIHRoaXMuYnVmZmVyID0gYnVmZmVyO1xuICAgIH1cbiAgICBpbnQxNigpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gdGhpcy5idWZmZXIucmVhZEludDE2QkUodGhpcy5vZmZzZXQpO1xuICAgICAgICB0aGlzLm9mZnNldCArPSAyO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBieXRlKCkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSB0aGlzLmJ1ZmZlclt0aGlzLm9mZnNldF07XG4gICAgICAgIHRoaXMub2Zmc2V0Kys7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIGludDMyKCkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSB0aGlzLmJ1ZmZlci5yZWFkSW50MzJCRSh0aGlzLm9mZnNldCk7XG4gICAgICAgIHRoaXMub2Zmc2V0ICs9IDQ7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIHN0cmluZyhsZW5ndGgpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gdGhpcy5idWZmZXIudG9TdHJpbmcodGhpcy5lbmNvZGluZywgdGhpcy5vZmZzZXQsIHRoaXMub2Zmc2V0ICsgbGVuZ3RoKTtcbiAgICAgICAgdGhpcy5vZmZzZXQgKz0gbGVuZ3RoO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBjc3RyaW5nKCkge1xuICAgICAgICBjb25zdCBzdGFydCA9IHRoaXMub2Zmc2V0O1xuICAgICAgICBsZXQgZW5kID0gc3RhcnQ7XG4gICAgICAgIHdoaWxlICh0aGlzLmJ1ZmZlcltlbmQrK10gIT09IDApIHsgfVxuICAgICAgICB0aGlzLm9mZnNldCA9IGVuZDtcbiAgICAgICAgcmV0dXJuIHRoaXMuYnVmZmVyLnRvU3RyaW5nKHRoaXMuZW5jb2RpbmcsIHN0YXJ0LCBlbmQgLSAxKTtcbiAgICB9XG4gICAgYnl0ZXMobGVuZ3RoKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMuYnVmZmVyLnNsaWNlKHRoaXMub2Zmc2V0LCB0aGlzLm9mZnNldCArIGxlbmd0aCk7XG4gICAgICAgIHRoaXMub2Zmc2V0ICs9IGxlbmd0aDtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG59XG5leHBvcnRzLkJ1ZmZlclJlYWRlciA9IEJ1ZmZlclJlYWRlcjtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWJ1ZmZlci1yZWFkZXIuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG4vL2JpbmFyeSBkYXRhIHdyaXRlciB0dW5lZCBmb3IgZW5jb2RpbmcgYmluYXJ5IHNwZWNpZmljIHRvIHRoZSBwb3N0Z3JlcyBiaW5hcnkgcHJvdG9jb2xcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuV3JpdGVyID0gdm9pZCAwO1xuY2xhc3MgV3JpdGVyIHtcbiAgICBjb25zdHJ1Y3RvcihzaXplID0gMjU2KSB7XG4gICAgICAgIHRoaXMuc2l6ZSA9IHNpemU7XG4gICAgICAgIHRoaXMub2Zmc2V0ID0gNTtcbiAgICAgICAgdGhpcy5oZWFkZXJQb3NpdGlvbiA9IDA7XG4gICAgICAgIHRoaXMuYnVmZmVyID0gQnVmZmVyLmFsbG9jVW5zYWZlKHNpemUpO1xuICAgIH1cbiAgICBlbnN1cmUoc2l6ZSkge1xuICAgICAgICB2YXIgcmVtYWluaW5nID0gdGhpcy5idWZmZXIubGVuZ3RoIC0gdGhpcy5vZmZzZXQ7XG4gICAgICAgIGlmIChyZW1haW5pbmcgPCBzaXplKSB7XG4gICAgICAgICAgICB2YXIgb2xkQnVmZmVyID0gdGhpcy5idWZmZXI7XG4gICAgICAgICAgICAvLyBleHBvbmVudGlhbCBncm93dGggZmFjdG9yIG9mIGFyb3VuZCB+IDEuNVxuICAgICAgICAgICAgLy8gaHR0cHM6Ly9zdGFja292ZXJmbG93LmNvbS9xdWVzdGlvbnMvMjI2OTA2My9idWZmZXItZ3Jvd3RoLXN0cmF0ZWd5XG4gICAgICAgICAgICB2YXIgbmV3U2l6ZSA9IG9sZEJ1ZmZlci5sZW5ndGggKyAob2xkQnVmZmVyLmxlbmd0aCA+PiAxKSArIHNpemU7XG4gICAgICAgICAgICB0aGlzLmJ1ZmZlciA9IEJ1ZmZlci5hbGxvY1Vuc2FmZShuZXdTaXplKTtcbiAgICAgICAgICAgIG9sZEJ1ZmZlci5jb3B5KHRoaXMuYnVmZmVyKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBhZGRJbnQzMihudW0pIHtcbiAgICAgICAgdGhpcy5lbnN1cmUoNCk7XG4gICAgICAgIHRoaXMuYnVmZmVyW3RoaXMub2Zmc2V0KytdID0gKG51bSA+Pj4gMjQpICYgMHhmZjtcbiAgICAgICAgdGhpcy5idWZmZXJbdGhpcy5vZmZzZXQrK10gPSAobnVtID4+PiAxNikgJiAweGZmO1xuICAgICAgICB0aGlzLmJ1ZmZlclt0aGlzLm9mZnNldCsrXSA9IChudW0gPj4+IDgpICYgMHhmZjtcbiAgICAgICAgdGhpcy5idWZmZXJbdGhpcy5vZmZzZXQrK10gPSAobnVtID4+PiAwKSAmIDB4ZmY7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBhZGRJbnQxNihudW0pIHtcbiAgICAgICAgdGhpcy5lbnN1cmUoMik7XG4gICAgICAgIHRoaXMuYnVmZmVyW3RoaXMub2Zmc2V0KytdID0gKG51bSA+Pj4gOCkgJiAweGZmO1xuICAgICAgICB0aGlzLmJ1ZmZlclt0aGlzLm9mZnNldCsrXSA9IChudW0gPj4+IDApICYgMHhmZjtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGFkZENTdHJpbmcoc3RyaW5nKSB7XG4gICAgICAgIGlmICghc3RyaW5nKSB7XG4gICAgICAgICAgICB0aGlzLmVuc3VyZSgxKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHZhciBsZW4gPSBCdWZmZXIuYnl0ZUxlbmd0aChzdHJpbmcpO1xuICAgICAgICAgICAgdGhpcy5lbnN1cmUobGVuICsgMSk7IC8vICsxIGZvciBudWxsIHRlcm1pbmF0b3JcbiAgICAgICAgICAgIHRoaXMuYnVmZmVyLndyaXRlKHN0cmluZywgdGhpcy5vZmZzZXQsICd1dGYtOCcpO1xuICAgICAgICAgICAgdGhpcy5vZmZzZXQgKz0gbGVuO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuYnVmZmVyW3RoaXMub2Zmc2V0KytdID0gMDsgLy8gbnVsbCB0ZXJtaW5hdG9yXG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBhZGRTdHJpbmcoc3RyaW5nID0gJycpIHtcbiAgICAgICAgdmFyIGxlbiA9IEJ1ZmZlci5ieXRlTGVuZ3RoKHN0cmluZyk7XG4gICAgICAgIHRoaXMuZW5zdXJlKGxlbik7XG4gICAgICAgIHRoaXMuYnVmZmVyLndyaXRlKHN0cmluZywgdGhpcy5vZmZzZXQpO1xuICAgICAgICB0aGlzLm9mZnNldCArPSBsZW47XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBhZGQob3RoZXJCdWZmZXIpIHtcbiAgICAgICAgdGhpcy5lbnN1cmUob3RoZXJCdWZmZXIubGVuZ3RoKTtcbiAgICAgICAgb3RoZXJCdWZmZXIuY29weSh0aGlzLmJ1ZmZlciwgdGhpcy5vZmZzZXQpO1xuICAgICAgICB0aGlzLm9mZnNldCArPSBvdGhlckJ1ZmZlci5sZW5ndGg7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBqb2luKGNvZGUpIHtcbiAgICAgICAgaWYgKGNvZGUpIHtcbiAgICAgICAgICAgIHRoaXMuYnVmZmVyW3RoaXMuaGVhZGVyUG9zaXRpb25dID0gY29kZTtcbiAgICAgICAgICAgIC8vbGVuZ3RoIGlzIGV2ZXJ5dGhpbmcgaW4gdGhpcyBwYWNrZXQgbWludXMgdGhlIGNvZGVcbiAgICAgICAgICAgIGNvbnN0IGxlbmd0aCA9IHRoaXMub2Zmc2V0IC0gKHRoaXMuaGVhZGVyUG9zaXRpb24gKyAxKTtcbiAgICAgICAgICAgIHRoaXMuYnVmZmVyLndyaXRlSW50MzJCRShsZW5ndGgsIHRoaXMuaGVhZGVyUG9zaXRpb24gKyAxKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5idWZmZXIuc2xpY2UoY29kZSA/IDAgOiA1LCB0aGlzLm9mZnNldCk7XG4gICAgfVxuICAgIGZsdXNoKGNvZGUpIHtcbiAgICAgICAgdmFyIHJlc3VsdCA9IHRoaXMuam9pbihjb2RlKTtcbiAgICAgICAgdGhpcy5vZmZzZXQgPSA1O1xuICAgICAgICB0aGlzLmhlYWRlclBvc2l0aW9uID0gMDtcbiAgICAgICAgdGhpcy5idWZmZXIgPSBCdWZmZXIuYWxsb2NVbnNhZmUodGhpcy5zaXplKTtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG59XG5leHBvcnRzLldyaXRlciA9IFdyaXRlcjtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWJ1ZmZlci13cml0ZXIuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLkRhdGFiYXNlRXJyb3IgPSBleHBvcnRzLnNlcmlhbGl6ZSA9IGV4cG9ydHMucGFyc2UgPSB2b2lkIDA7XG5jb25zdCBtZXNzYWdlc18xID0gcmVxdWlyZShcIi4vbWVzc2FnZXNcIik7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJEYXRhYmFzZUVycm9yXCIsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBmdW5jdGlvbiAoKSB7IHJldHVybiBtZXNzYWdlc18xLkRhdGFiYXNlRXJyb3I7IH0gfSk7XG5jb25zdCBzZXJpYWxpemVyXzEgPSByZXF1aXJlKFwiLi9zZXJpYWxpemVyXCIpO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwic2VyaWFsaXplXCIsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBmdW5jdGlvbiAoKSB7IHJldHVybiBzZXJpYWxpemVyXzEuc2VyaWFsaXplOyB9IH0pO1xuY29uc3QgcGFyc2VyXzEgPSByZXF1aXJlKFwiLi9wYXJzZXJcIik7XG5mdW5jdGlvbiBwYXJzZShzdHJlYW0sIGNhbGxiYWNrKSB7XG4gICAgY29uc3QgcGFyc2VyID0gbmV3IHBhcnNlcl8xLlBhcnNlcigpO1xuICAgIHN0cmVhbS5vbignZGF0YScsIChidWZmZXIpID0+IHBhcnNlci5wYXJzZShidWZmZXIsIGNhbGxiYWNrKSk7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiBzdHJlYW0ub24oJ2VuZCcsICgpID0+IHJlc29sdmUoKSkpO1xufVxuZXhwb3J0cy5wYXJzZSA9IHBhcnNlO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLk5vdGljZU1lc3NhZ2UgPSBleHBvcnRzLkRhdGFSb3dNZXNzYWdlID0gZXhwb3J0cy5Db21tYW5kQ29tcGxldGVNZXNzYWdlID0gZXhwb3J0cy5SZWFkeUZvclF1ZXJ5TWVzc2FnZSA9IGV4cG9ydHMuTm90aWZpY2F0aW9uUmVzcG9uc2VNZXNzYWdlID0gZXhwb3J0cy5CYWNrZW5kS2V5RGF0YU1lc3NhZ2UgPSBleHBvcnRzLkF1dGhlbnRpY2F0aW9uTUQ1UGFzc3dvcmQgPSBleHBvcnRzLlBhcmFtZXRlclN0YXR1c01lc3NhZ2UgPSBleHBvcnRzLlBhcmFtZXRlckRlc2NyaXB0aW9uTWVzc2FnZSA9IGV4cG9ydHMuUm93RGVzY3JpcHRpb25NZXNzYWdlID0gZXhwb3J0cy5GaWVsZCA9IGV4cG9ydHMuQ29weVJlc3BvbnNlID0gZXhwb3J0cy5Db3B5RGF0YU1lc3NhZ2UgPSBleHBvcnRzLkRhdGFiYXNlRXJyb3IgPSBleHBvcnRzLmNvcHlEb25lID0gZXhwb3J0cy5lbXB0eVF1ZXJ5ID0gZXhwb3J0cy5yZXBsaWNhdGlvblN0YXJ0ID0gZXhwb3J0cy5wb3J0YWxTdXNwZW5kZWQgPSBleHBvcnRzLm5vRGF0YSA9IGV4cG9ydHMuY2xvc2VDb21wbGV0ZSA9IGV4cG9ydHMuYmluZENvbXBsZXRlID0gZXhwb3J0cy5wYXJzZUNvbXBsZXRlID0gdm9pZCAwO1xuZXhwb3J0cy5wYXJzZUNvbXBsZXRlID0ge1xuICAgIG5hbWU6ICdwYXJzZUNvbXBsZXRlJyxcbiAgICBsZW5ndGg6IDUsXG59O1xuZXhwb3J0cy5iaW5kQ29tcGxldGUgPSB7XG4gICAgbmFtZTogJ2JpbmRDb21wbGV0ZScsXG4gICAgbGVuZ3RoOiA1LFxufTtcbmV4cG9ydHMuY2xvc2VDb21wbGV0ZSA9IHtcbiAgICBuYW1lOiAnY2xvc2VDb21wbGV0ZScsXG4gICAgbGVuZ3RoOiA1LFxufTtcbmV4cG9ydHMubm9EYXRhID0ge1xuICAgIG5hbWU6ICdub0RhdGEnLFxuICAgIGxlbmd0aDogNSxcbn07XG5leHBvcnRzLnBvcnRhbFN1c3BlbmRlZCA9IHtcbiAgICBuYW1lOiAncG9ydGFsU3VzcGVuZGVkJyxcbiAgICBsZW5ndGg6IDUsXG59O1xuZXhwb3J0cy5yZXBsaWNhdGlvblN0YXJ0ID0ge1xuICAgIG5hbWU6ICdyZXBsaWNhdGlvblN0YXJ0JyxcbiAgICBsZW5ndGg6IDQsXG59O1xuZXhwb3J0cy5lbXB0eVF1ZXJ5ID0ge1xuICAgIG5hbWU6ICdlbXB0eVF1ZXJ5JyxcbiAgICBsZW5ndGg6IDQsXG59O1xuZXhwb3J0cy5jb3B5RG9uZSA9IHtcbiAgICBuYW1lOiAnY29weURvbmUnLFxuICAgIGxlbmd0aDogNCxcbn07XG5jbGFzcyBEYXRhYmFzZUVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKG1lc3NhZ2UsIGxlbmd0aCwgbmFtZSkge1xuICAgICAgICBzdXBlcihtZXNzYWdlKTtcbiAgICAgICAgdGhpcy5sZW5ndGggPSBsZW5ndGg7XG4gICAgICAgIHRoaXMubmFtZSA9IG5hbWU7XG4gICAgfVxufVxuZXhwb3J0cy5EYXRhYmFzZUVycm9yID0gRGF0YWJhc2VFcnJvcjtcbmNsYXNzIENvcHlEYXRhTWVzc2FnZSB7XG4gICAgY29uc3RydWN0b3IobGVuZ3RoLCBjaHVuaykge1xuICAgICAgICB0aGlzLmxlbmd0aCA9IGxlbmd0aDtcbiAgICAgICAgdGhpcy5jaHVuayA9IGNodW5rO1xuICAgICAgICB0aGlzLm5hbWUgPSAnY29weURhdGEnO1xuICAgIH1cbn1cbmV4cG9ydHMuQ29weURhdGFNZXNzYWdlID0gQ29weURhdGFNZXNzYWdlO1xuY2xhc3MgQ29weVJlc3BvbnNlIHtcbiAgICBjb25zdHJ1Y3RvcihsZW5ndGgsIG5hbWUsIGJpbmFyeSwgY29sdW1uQ291bnQpIHtcbiAgICAgICAgdGhpcy5sZW5ndGggPSBsZW5ndGg7XG4gICAgICAgIHRoaXMubmFtZSA9IG5hbWU7XG4gICAgICAgIHRoaXMuYmluYXJ5ID0gYmluYXJ5O1xuICAgICAgICB0aGlzLmNvbHVtblR5cGVzID0gbmV3IEFycmF5KGNvbHVtbkNvdW50KTtcbiAgICB9XG59XG5leHBvcnRzLkNvcHlSZXNwb25zZSA9IENvcHlSZXNwb25zZTtcbmNsYXNzIEZpZWxkIHtcbiAgICBjb25zdHJ1Y3RvcihuYW1lLCB0YWJsZUlELCBjb2x1bW5JRCwgZGF0YVR5cGVJRCwgZGF0YVR5cGVTaXplLCBkYXRhVHlwZU1vZGlmaWVyLCBmb3JtYXQpIHtcbiAgICAgICAgdGhpcy5uYW1lID0gbmFtZTtcbiAgICAgICAgdGhpcy50YWJsZUlEID0gdGFibGVJRDtcbiAgICAgICAgdGhpcy5jb2x1bW5JRCA9IGNvbHVtbklEO1xuICAgICAgICB0aGlzLmRhdGFUeXBlSUQgPSBkYXRhVHlwZUlEO1xuICAgICAgICB0aGlzLmRhdGFUeXBlU2l6ZSA9IGRhdGFUeXBlU2l6ZTtcbiAgICAgICAgdGhpcy5kYXRhVHlwZU1vZGlmaWVyID0gZGF0YVR5cGVNb2RpZmllcjtcbiAgICAgICAgdGhpcy5mb3JtYXQgPSBmb3JtYXQ7XG4gICAgfVxufVxuZXhwb3J0cy5GaWVsZCA9IEZpZWxkO1xuY2xhc3MgUm93RGVzY3JpcHRpb25NZXNzYWdlIHtcbiAgICBjb25zdHJ1Y3RvcihsZW5ndGgsIGZpZWxkQ291bnQpIHtcbiAgICAgICAgdGhpcy5sZW5ndGggPSBsZW5ndGg7XG4gICAgICAgIHRoaXMuZmllbGRDb3VudCA9IGZpZWxkQ291bnQ7XG4gICAgICAgIHRoaXMubmFtZSA9ICdyb3dEZXNjcmlwdGlvbic7XG4gICAgICAgIHRoaXMuZmllbGRzID0gbmV3IEFycmF5KHRoaXMuZmllbGRDb3VudCk7XG4gICAgfVxufVxuZXhwb3J0cy5Sb3dEZXNjcmlwdGlvbk1lc3NhZ2UgPSBSb3dEZXNjcmlwdGlvbk1lc3NhZ2U7XG5jbGFzcyBQYXJhbWV0ZXJEZXNjcmlwdGlvbk1lc3NhZ2Uge1xuICAgIGNvbnN0cnVjdG9yKGxlbmd0aCwgcGFyYW1ldGVyQ291bnQpIHtcbiAgICAgICAgdGhpcy5sZW5ndGggPSBsZW5ndGg7XG4gICAgICAgIHRoaXMucGFyYW1ldGVyQ291bnQgPSBwYXJhbWV0ZXJDb3VudDtcbiAgICAgICAgdGhpcy5uYW1lID0gJ3BhcmFtZXRlckRlc2NyaXB0aW9uJztcbiAgICAgICAgdGhpcy5kYXRhVHlwZUlEcyA9IG5ldyBBcnJheSh0aGlzLnBhcmFtZXRlckNvdW50KTtcbiAgICB9XG59XG5leHBvcnRzLlBhcmFtZXRlckRlc2NyaXB0aW9uTWVzc2FnZSA9IFBhcmFtZXRlckRlc2NyaXB0aW9uTWVzc2FnZTtcbmNsYXNzIFBhcmFtZXRlclN0YXR1c01lc3NhZ2Uge1xuICAgIGNvbnN0cnVjdG9yKGxlbmd0aCwgcGFyYW1ldGVyTmFtZSwgcGFyYW1ldGVyVmFsdWUpIHtcbiAgICAgICAgdGhpcy5sZW5ndGggPSBsZW5ndGg7XG4gICAgICAgIHRoaXMucGFyYW1ldGVyTmFtZSA9IHBhcmFtZXRlck5hbWU7XG4gICAgICAgIHRoaXMucGFyYW1ldGVyVmFsdWUgPSBwYXJhbWV0ZXJWYWx1ZTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ3BhcmFtZXRlclN0YXR1cyc7XG4gICAgfVxufVxuZXhwb3J0cy5QYXJhbWV0ZXJTdGF0dXNNZXNzYWdlID0gUGFyYW1ldGVyU3RhdHVzTWVzc2FnZTtcbmNsYXNzIEF1dGhlbnRpY2F0aW9uTUQ1UGFzc3dvcmQge1xuICAgIGNvbnN0cnVjdG9yKGxlbmd0aCwgc2FsdCkge1xuICAgICAgICB0aGlzLmxlbmd0aCA9IGxlbmd0aDtcbiAgICAgICAgdGhpcy5zYWx0ID0gc2FsdDtcbiAgICAgICAgdGhpcy5uYW1lID0gJ2F1dGhlbnRpY2F0aW9uTUQ1UGFzc3dvcmQnO1xuICAgIH1cbn1cbmV4cG9ydHMuQXV0aGVudGljYXRpb25NRDVQYXNzd29yZCA9IEF1dGhlbnRpY2F0aW9uTUQ1UGFzc3dvcmQ7XG5jbGFzcyBCYWNrZW5kS2V5RGF0YU1lc3NhZ2Uge1xuICAgIGNvbnN0cnVjdG9yKGxlbmd0aCwgcHJvY2Vzc0lELCBzZWNyZXRLZXkpIHtcbiAgICAgICAgdGhpcy5sZW5ndGggPSBsZW5ndGg7XG4gICAgICAgIHRoaXMucHJvY2Vzc0lEID0gcHJvY2Vzc0lEO1xuICAgICAgICB0aGlzLnNlY3JldEtleSA9IHNlY3JldEtleTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ2JhY2tlbmRLZXlEYXRhJztcbiAgICB9XG59XG5leHBvcnRzLkJhY2tlbmRLZXlEYXRhTWVzc2FnZSA9IEJhY2tlbmRLZXlEYXRhTWVzc2FnZTtcbmNsYXNzIE5vdGlmaWNhdGlvblJlc3BvbnNlTWVzc2FnZSB7XG4gICAgY29uc3RydWN0b3IobGVuZ3RoLCBwcm9jZXNzSWQsIGNoYW5uZWwsIHBheWxvYWQpIHtcbiAgICAgICAgdGhpcy5sZW5ndGggPSBsZW5ndGg7XG4gICAgICAgIHRoaXMucHJvY2Vzc0lkID0gcHJvY2Vzc0lkO1xuICAgICAgICB0aGlzLmNoYW5uZWwgPSBjaGFubmVsO1xuICAgICAgICB0aGlzLnBheWxvYWQgPSBwYXlsb2FkO1xuICAgICAgICB0aGlzLm5hbWUgPSAnbm90aWZpY2F0aW9uJztcbiAgICB9XG59XG5leHBvcnRzLk5vdGlmaWNhdGlvblJlc3BvbnNlTWVzc2FnZSA9IE5vdGlmaWNhdGlvblJlc3BvbnNlTWVzc2FnZTtcbmNsYXNzIFJlYWR5Rm9yUXVlcnlNZXNzYWdlIHtcbiAgICBjb25zdHJ1Y3RvcihsZW5ndGgsIHN0YXR1cykge1xuICAgICAgICB0aGlzLmxlbmd0aCA9IGxlbmd0aDtcbiAgICAgICAgdGhpcy5zdGF0dXMgPSBzdGF0dXM7XG4gICAgICAgIHRoaXMubmFtZSA9ICdyZWFkeUZvclF1ZXJ5JztcbiAgICB9XG59XG5leHBvcnRzLlJlYWR5Rm9yUXVlcnlNZXNzYWdlID0gUmVhZHlGb3JRdWVyeU1lc3NhZ2U7XG5jbGFzcyBDb21tYW5kQ29tcGxldGVNZXNzYWdlIHtcbiAgICBjb25zdHJ1Y3RvcihsZW5ndGgsIHRleHQpIHtcbiAgICAgICAgdGhpcy5sZW5ndGggPSBsZW5ndGg7XG4gICAgICAgIHRoaXMudGV4dCA9IHRleHQ7XG4gICAgICAgIHRoaXMubmFtZSA9ICdjb21tYW5kQ29tcGxldGUnO1xuICAgIH1cbn1cbmV4cG9ydHMuQ29tbWFuZENvbXBsZXRlTWVzc2FnZSA9IENvbW1hbmRDb21wbGV0ZU1lc3NhZ2U7XG5jbGFzcyBEYXRhUm93TWVzc2FnZSB7XG4gICAgY29uc3RydWN0b3IobGVuZ3RoLCBmaWVsZHMpIHtcbiAgICAgICAgdGhpcy5sZW5ndGggPSBsZW5ndGg7XG4gICAgICAgIHRoaXMuZmllbGRzID0gZmllbGRzO1xuICAgICAgICB0aGlzLm5hbWUgPSAnZGF0YVJvdyc7XG4gICAgICAgIHRoaXMuZmllbGRDb3VudCA9IGZpZWxkcy5sZW5ndGg7XG4gICAgfVxufVxuZXhwb3J0cy5EYXRhUm93TWVzc2FnZSA9IERhdGFSb3dNZXNzYWdlO1xuY2xhc3MgTm90aWNlTWVzc2FnZSB7XG4gICAgY29uc3RydWN0b3IobGVuZ3RoLCBtZXNzYWdlKSB7XG4gICAgICAgIHRoaXMubGVuZ3RoID0gbGVuZ3RoO1xuICAgICAgICB0aGlzLm1lc3NhZ2UgPSBtZXNzYWdlO1xuICAgICAgICB0aGlzLm5hbWUgPSAnbm90aWNlJztcbiAgICB9XG59XG5leHBvcnRzLk5vdGljZU1lc3NhZ2UgPSBOb3RpY2VNZXNzYWdlO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bWVzc2FnZXMuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG52YXIgX19pbXBvcnREZWZhdWx0ID0gKHRoaXMgJiYgdGhpcy5fX2ltcG9ydERlZmF1bHQpIHx8IGZ1bmN0aW9uIChtb2QpIHtcbiAgICByZXR1cm4gKG1vZCAmJiBtb2QuX19lc01vZHVsZSkgPyBtb2QgOiB7IFwiZGVmYXVsdFwiOiBtb2QgfTtcbn07XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLlBhcnNlciA9IHZvaWQgMDtcbmNvbnN0IG1lc3NhZ2VzXzEgPSByZXF1aXJlKFwiLi9tZXNzYWdlc1wiKTtcbmNvbnN0IGJ1ZmZlcl9yZWFkZXJfMSA9IHJlcXVpcmUoXCIuL2J1ZmZlci1yZWFkZXJcIik7XG5jb25zdCBhc3NlcnRfMSA9IF9faW1wb3J0RGVmYXVsdChyZXF1aXJlKFwiYXNzZXJ0XCIpKTtcbi8vIGV2ZXJ5IG1lc3NhZ2UgaXMgcHJlZml4ZWQgd2l0aCBhIHNpbmdsZSBieWVcbmNvbnN0IENPREVfTEVOR1RIID0gMTtcbi8vIGV2ZXJ5IG1lc3NhZ2UgaGFzIGFuIGludDMyIGxlbmd0aCB3aGljaCBpbmNsdWRlcyBpdHNlbGYgYnV0IGRvZXNcbi8vIE5PVCBpbmNsdWRlIHRoZSBjb2RlIGluIHRoZSBsZW5ndGhcbmNvbnN0IExFTl9MRU5HVEggPSA0O1xuY29uc3QgSEVBREVSX0xFTkdUSCA9IENPREVfTEVOR1RIICsgTEVOX0xFTkdUSDtcbmNvbnN0IGVtcHR5QnVmZmVyID0gQnVmZmVyLmFsbG9jVW5zYWZlKDApO1xuY2xhc3MgUGFyc2VyIHtcbiAgICBjb25zdHJ1Y3RvcihvcHRzKSB7XG4gICAgICAgIHRoaXMuYnVmZmVyID0gZW1wdHlCdWZmZXI7XG4gICAgICAgIHRoaXMuYnVmZmVyTGVuZ3RoID0gMDtcbiAgICAgICAgdGhpcy5idWZmZXJPZmZzZXQgPSAwO1xuICAgICAgICB0aGlzLnJlYWRlciA9IG5ldyBidWZmZXJfcmVhZGVyXzEuQnVmZmVyUmVhZGVyKCk7XG4gICAgICAgIGlmICgob3B0cyA9PT0gbnVsbCB8fCBvcHRzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBvcHRzLm1vZGUpID09PSAnYmluYXJ5Jykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdCaW5hcnkgbW9kZSBub3Qgc3VwcG9ydGVkIHlldCcpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMubW9kZSA9IChvcHRzID09PSBudWxsIHx8IG9wdHMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG9wdHMubW9kZSkgfHwgJ3RleHQnO1xuICAgIH1cbiAgICBwYXJzZShidWZmZXIsIGNhbGxiYWNrKSB7XG4gICAgICAgIHRoaXMubWVyZ2VCdWZmZXIoYnVmZmVyKTtcbiAgICAgICAgY29uc3QgYnVmZmVyRnVsbExlbmd0aCA9IHRoaXMuYnVmZmVyT2Zmc2V0ICsgdGhpcy5idWZmZXJMZW5ndGg7XG4gICAgICAgIGxldCBvZmZzZXQgPSB0aGlzLmJ1ZmZlck9mZnNldDtcbiAgICAgICAgd2hpbGUgKG9mZnNldCArIEhFQURFUl9MRU5HVEggPD0gYnVmZmVyRnVsbExlbmd0aCkge1xuICAgICAgICAgICAgLy8gY29kZSBpcyAxIGJ5dGUgbG9uZyAtIGl0IGlkZW50aWZpZXMgdGhlIG1lc3NhZ2UgdHlwZVxuICAgICAgICAgICAgY29uc3QgY29kZSA9IHRoaXMuYnVmZmVyW29mZnNldF07XG4gICAgICAgICAgICAvLyBsZW5ndGggaXMgMSBVaW50MzJCRSAtIGl0IGlzIHRoZSBsZW5ndGggb2YgdGhlIG1lc3NhZ2UgRVhDTFVESU5HIHRoZSBjb2RlXG4gICAgICAgICAgICBjb25zdCBsZW5ndGggPSB0aGlzLmJ1ZmZlci5yZWFkVUludDMyQkUob2Zmc2V0ICsgQ09ERV9MRU5HVEgpO1xuICAgICAgICAgICAgY29uc3QgZnVsbE1lc3NhZ2VMZW5ndGggPSBDT0RFX0xFTkdUSCArIGxlbmd0aDtcbiAgICAgICAgICAgIGlmIChmdWxsTWVzc2FnZUxlbmd0aCArIG9mZnNldCA8PSBidWZmZXJGdWxsTGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbWVzc2FnZSA9IHRoaXMuaGFuZGxlUGFja2V0KG9mZnNldCArIEhFQURFUl9MRU5HVEgsIGNvZGUsIGxlbmd0aCwgdGhpcy5idWZmZXIpO1xuICAgICAgICAgICAgICAgIGNhbGxiYWNrKG1lc3NhZ2UpO1xuICAgICAgICAgICAgICAgIG9mZnNldCArPSBmdWxsTWVzc2FnZUxlbmd0aDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChvZmZzZXQgPT09IGJ1ZmZlckZ1bGxMZW5ndGgpIHtcbiAgICAgICAgICAgIC8vIE5vIG1vcmUgdXNlIGZvciB0aGUgYnVmZmVyXG4gICAgICAgICAgICB0aGlzLmJ1ZmZlciA9IGVtcHR5QnVmZmVyO1xuICAgICAgICAgICAgdGhpcy5idWZmZXJMZW5ndGggPSAwO1xuICAgICAgICAgICAgdGhpcy5idWZmZXJPZmZzZXQgPSAwO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgLy8gQWRqdXN0IHRoZSBjdXJzb3JzIG9mIHJlbWFpbmluZ0J1ZmZlclxuICAgICAgICAgICAgdGhpcy5idWZmZXJMZW5ndGggPSBidWZmZXJGdWxsTGVuZ3RoIC0gb2Zmc2V0O1xuICAgICAgICAgICAgdGhpcy5idWZmZXJPZmZzZXQgPSBvZmZzZXQ7XG4gICAgICAgIH1cbiAgICB9XG4gICAgbWVyZ2VCdWZmZXIoYnVmZmVyKSB7XG4gICAgICAgIGlmICh0aGlzLmJ1ZmZlckxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIGNvbnN0IG5ld0xlbmd0aCA9IHRoaXMuYnVmZmVyTGVuZ3RoICsgYnVmZmVyLmJ5dGVMZW5ndGg7XG4gICAgICAgICAgICBjb25zdCBuZXdGdWxsTGVuZ3RoID0gbmV3TGVuZ3RoICsgdGhpcy5idWZmZXJPZmZzZXQ7XG4gICAgICAgICAgICBpZiAobmV3RnVsbExlbmd0aCA+IHRoaXMuYnVmZmVyLmJ5dGVMZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAvLyBXZSBjYW4ndCBjb25jYXQgdGhlIG5ldyBidWZmZXIgd2l0aCB0aGUgcmVtYWluaW5nIG9uZVxuICAgICAgICAgICAgICAgIGxldCBuZXdCdWZmZXI7XG4gICAgICAgICAgICAgICAgaWYgKG5ld0xlbmd0aCA8PSB0aGlzLmJ1ZmZlci5ieXRlTGVuZ3RoICYmIHRoaXMuYnVmZmVyT2Zmc2V0ID49IHRoaXMuYnVmZmVyTGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIFdlIGNhbiBtb3ZlIHRoZSByZWxldmFudCBwYXJ0IHRvIHRoZSBiZWdpbm5pbmcgb2YgdGhlIGJ1ZmZlciBpbnN0ZWFkIG9mIGFsbG9jYXRpbmcgYSBuZXcgYnVmZmVyXG4gICAgICAgICAgICAgICAgICAgIG5ld0J1ZmZlciA9IHRoaXMuYnVmZmVyO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gQWxsb2NhdGUgYSBuZXcgbGFyZ2VyIGJ1ZmZlclxuICAgICAgICAgICAgICAgICAgICBsZXQgbmV3QnVmZmVyTGVuZ3RoID0gdGhpcy5idWZmZXIuYnl0ZUxlbmd0aCAqIDI7XG4gICAgICAgICAgICAgICAgICAgIHdoaWxlIChuZXdMZW5ndGggPj0gbmV3QnVmZmVyTGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuZXdCdWZmZXJMZW5ndGggKj0gMjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBuZXdCdWZmZXIgPSBCdWZmZXIuYWxsb2NVbnNhZmUobmV3QnVmZmVyTGVuZ3RoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gTW92ZSB0aGUgcmVtYWluaW5nIGJ1ZmZlciB0byB0aGUgbmV3IG9uZVxuICAgICAgICAgICAgICAgIHRoaXMuYnVmZmVyLmNvcHkobmV3QnVmZmVyLCAwLCB0aGlzLmJ1ZmZlck9mZnNldCwgdGhpcy5idWZmZXJPZmZzZXQgKyB0aGlzLmJ1ZmZlckxlbmd0aCk7XG4gICAgICAgICAgICAgICAgdGhpcy5idWZmZXIgPSBuZXdCdWZmZXI7XG4gICAgICAgICAgICAgICAgdGhpcy5idWZmZXJPZmZzZXQgPSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gQ29uY2F0IHRoZSBuZXcgYnVmZmVyIHdpdGggdGhlIHJlbWFpbmluZyBvbmVcbiAgICAgICAgICAgIGJ1ZmZlci5jb3B5KHRoaXMuYnVmZmVyLCB0aGlzLmJ1ZmZlck9mZnNldCArIHRoaXMuYnVmZmVyTGVuZ3RoKTtcbiAgICAgICAgICAgIHRoaXMuYnVmZmVyTGVuZ3RoID0gbmV3TGVuZ3RoO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5idWZmZXIgPSBidWZmZXI7XG4gICAgICAgICAgICB0aGlzLmJ1ZmZlck9mZnNldCA9IDA7XG4gICAgICAgICAgICB0aGlzLmJ1ZmZlckxlbmd0aCA9IGJ1ZmZlci5ieXRlTGVuZ3RoO1xuICAgICAgICB9XG4gICAgfVxuICAgIGhhbmRsZVBhY2tldChvZmZzZXQsIGNvZGUsIGxlbmd0aCwgYnl0ZXMpIHtcbiAgICAgICAgc3dpdGNoIChjb2RlKSB7XG4gICAgICAgICAgICBjYXNlIDUwIC8qIEJpbmRDb21wbGV0ZSAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gbWVzc2FnZXNfMS5iaW5kQ29tcGxldGU7XG4gICAgICAgICAgICBjYXNlIDQ5IC8qIFBhcnNlQ29tcGxldGUgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2VzXzEucGFyc2VDb21wbGV0ZTtcbiAgICAgICAgICAgIGNhc2UgNTEgLyogQ2xvc2VDb21wbGV0ZSAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gbWVzc2FnZXNfMS5jbG9zZUNvbXBsZXRlO1xuICAgICAgICAgICAgY2FzZSAxMTAgLyogTm9EYXRhICovOlxuICAgICAgICAgICAgICAgIHJldHVybiBtZXNzYWdlc18xLm5vRGF0YTtcbiAgICAgICAgICAgIGNhc2UgMTE1IC8qIFBvcnRhbFN1c3BlbmRlZCAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gbWVzc2FnZXNfMS5wb3J0YWxTdXNwZW5kZWQ7XG4gICAgICAgICAgICBjYXNlIDk5IC8qIENvcHlEb25lICovOlxuICAgICAgICAgICAgICAgIHJldHVybiBtZXNzYWdlc18xLmNvcHlEb25lO1xuICAgICAgICAgICAgY2FzZSA4NyAvKiBSZXBsaWNhdGlvblN0YXJ0ICovOlxuICAgICAgICAgICAgICAgIHJldHVybiBtZXNzYWdlc18xLnJlcGxpY2F0aW9uU3RhcnQ7XG4gICAgICAgICAgICBjYXNlIDczIC8qIEVtcHR5UXVlcnkgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2VzXzEuZW1wdHlRdWVyeTtcbiAgICAgICAgICAgIGNhc2UgNjggLyogRGF0YVJvdyAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZURhdGFSb3dNZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcyk7XG4gICAgICAgICAgICBjYXNlIDY3IC8qIENvbW1hbmRDb21wbGV0ZSAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZUNvbW1hbmRDb21wbGV0ZU1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKTtcbiAgICAgICAgICAgIGNhc2UgOTAgLyogUmVhZHlGb3JRdWVyeSAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZVJlYWR5Rm9yUXVlcnlNZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcyk7XG4gICAgICAgICAgICBjYXNlIDY1IC8qIE5vdGlmaWNhdGlvblJlc3BvbnNlICovOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlTm90aWZpY2F0aW9uTWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpO1xuICAgICAgICAgICAgY2FzZSA4MiAvKiBBdXRoZW50aWNhdGlvblJlc3BvbnNlICovOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlQXV0aGVudGljYXRpb25SZXNwb25zZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpO1xuICAgICAgICAgICAgY2FzZSA4MyAvKiBQYXJhbWV0ZXJTdGF0dXMgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VQYXJhbWV0ZXJTdGF0dXNNZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcyk7XG4gICAgICAgICAgICBjYXNlIDc1IC8qIEJhY2tlbmRLZXlEYXRhICovOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlQmFja2VuZEtleURhdGEob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKTtcbiAgICAgICAgICAgIGNhc2UgNjkgLyogRXJyb3JNZXNzYWdlICovOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlRXJyb3JNZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcywgJ2Vycm9yJyk7XG4gICAgICAgICAgICBjYXNlIDc4IC8qIE5vdGljZU1lc3NhZ2UgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VFcnJvck1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzLCAnbm90aWNlJyk7XG4gICAgICAgICAgICBjYXNlIDg0IC8qIFJvd0Rlc2NyaXB0aW9uTWVzc2FnZSAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZVJvd0Rlc2NyaXB0aW9uTWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpO1xuICAgICAgICAgICAgY2FzZSAxMTYgLyogUGFyYW1ldGVyRGVzY3JpcHRpb25NZXNzYWdlICovOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlUGFyYW1ldGVyRGVzY3JpcHRpb25NZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcyk7XG4gICAgICAgICAgICBjYXNlIDcxIC8qIENvcHlJbiAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZUNvcHlJbk1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKTtcbiAgICAgICAgICAgIGNhc2UgNzIgLyogQ29weU91dCAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZUNvcHlPdXRNZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcyk7XG4gICAgICAgICAgICBjYXNlIDEwMCAvKiBDb3B5RGF0YSAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZUNvcHlEYXRhKG9mZnNldCwgbGVuZ3RoLCBieXRlcyk7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIGFzc2VydF8xLmRlZmF1bHQuZmFpbChgdW5rbm93biBtZXNzYWdlIGNvZGU6ICR7Y29kZS50b1N0cmluZygxNil9YCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcGFyc2VSZWFkeUZvclF1ZXJ5TWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpIHtcbiAgICAgICAgdGhpcy5yZWFkZXIuc2V0QnVmZmVyKG9mZnNldCwgYnl0ZXMpO1xuICAgICAgICBjb25zdCBzdGF0dXMgPSB0aGlzLnJlYWRlci5zdHJpbmcoMSk7XG4gICAgICAgIHJldHVybiBuZXcgbWVzc2FnZXNfMS5SZWFkeUZvclF1ZXJ5TWVzc2FnZShsZW5ndGgsIHN0YXR1cyk7XG4gICAgfVxuICAgIHBhcnNlQ29tbWFuZENvbXBsZXRlTWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpIHtcbiAgICAgICAgdGhpcy5yZWFkZXIuc2V0QnVmZmVyKG9mZnNldCwgYnl0ZXMpO1xuICAgICAgICBjb25zdCB0ZXh0ID0gdGhpcy5yZWFkZXIuY3N0cmluZygpO1xuICAgICAgICByZXR1cm4gbmV3IG1lc3NhZ2VzXzEuQ29tbWFuZENvbXBsZXRlTWVzc2FnZShsZW5ndGgsIHRleHQpO1xuICAgIH1cbiAgICBwYXJzZUNvcHlEYXRhKG9mZnNldCwgbGVuZ3RoLCBieXRlcykge1xuICAgICAgICBjb25zdCBjaHVuayA9IGJ5dGVzLnNsaWNlKG9mZnNldCwgb2Zmc2V0ICsgKGxlbmd0aCAtIDQpKTtcbiAgICAgICAgcmV0dXJuIG5ldyBtZXNzYWdlc18xLkNvcHlEYXRhTWVzc2FnZShsZW5ndGgsIGNodW5rKTtcbiAgICB9XG4gICAgcGFyc2VDb3B5SW5NZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcykge1xuICAgICAgICByZXR1cm4gdGhpcy5wYXJzZUNvcHlNZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcywgJ2NvcHlJblJlc3BvbnNlJyk7XG4gICAgfVxuICAgIHBhcnNlQ29weU91dE1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnBhcnNlQ29weU1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzLCAnY29weU91dFJlc3BvbnNlJyk7XG4gICAgfVxuICAgIHBhcnNlQ29weU1lc3NhZ2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzLCBtZXNzYWdlTmFtZSkge1xuICAgICAgICB0aGlzLnJlYWRlci5zZXRCdWZmZXIob2Zmc2V0LCBieXRlcyk7XG4gICAgICAgIGNvbnN0IGlzQmluYXJ5ID0gdGhpcy5yZWFkZXIuYnl0ZSgpICE9PSAwO1xuICAgICAgICBjb25zdCBjb2x1bW5Db3VudCA9IHRoaXMucmVhZGVyLmludDE2KCk7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBuZXcgbWVzc2FnZXNfMS5Db3B5UmVzcG9uc2UobGVuZ3RoLCBtZXNzYWdlTmFtZSwgaXNCaW5hcnksIGNvbHVtbkNvdW50KTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb2x1bW5Db3VudDsgaSsrKSB7XG4gICAgICAgICAgICBtZXNzYWdlLmNvbHVtblR5cGVzW2ldID0gdGhpcy5yZWFkZXIuaW50MTYoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbWVzc2FnZTtcbiAgICB9XG4gICAgcGFyc2VOb3RpZmljYXRpb25NZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcykge1xuICAgICAgICB0aGlzLnJlYWRlci5zZXRCdWZmZXIob2Zmc2V0LCBieXRlcyk7XG4gICAgICAgIGNvbnN0IHByb2Nlc3NJZCA9IHRoaXMucmVhZGVyLmludDMyKCk7XG4gICAgICAgIGNvbnN0IGNoYW5uZWwgPSB0aGlzLnJlYWRlci5jc3RyaW5nKCk7XG4gICAgICAgIGNvbnN0IHBheWxvYWQgPSB0aGlzLnJlYWRlci5jc3RyaW5nKCk7XG4gICAgICAgIHJldHVybiBuZXcgbWVzc2FnZXNfMS5Ob3RpZmljYXRpb25SZXNwb25zZU1lc3NhZ2UobGVuZ3RoLCBwcm9jZXNzSWQsIGNoYW5uZWwsIHBheWxvYWQpO1xuICAgIH1cbiAgICBwYXJzZVJvd0Rlc2NyaXB0aW9uTWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpIHtcbiAgICAgICAgdGhpcy5yZWFkZXIuc2V0QnVmZmVyKG9mZnNldCwgYnl0ZXMpO1xuICAgICAgICBjb25zdCBmaWVsZENvdW50ID0gdGhpcy5yZWFkZXIuaW50MTYoKTtcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IG5ldyBtZXNzYWdlc18xLlJvd0Rlc2NyaXB0aW9uTWVzc2FnZShsZW5ndGgsIGZpZWxkQ291bnQpO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGZpZWxkQ291bnQ7IGkrKykge1xuICAgICAgICAgICAgbWVzc2FnZS5maWVsZHNbaV0gPSB0aGlzLnBhcnNlRmllbGQoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbWVzc2FnZTtcbiAgICB9XG4gICAgcGFyc2VGaWVsZCgpIHtcbiAgICAgICAgY29uc3QgbmFtZSA9IHRoaXMucmVhZGVyLmNzdHJpbmcoKTtcbiAgICAgICAgY29uc3QgdGFibGVJRCA9IHRoaXMucmVhZGVyLmludDMyKCk7XG4gICAgICAgIGNvbnN0IGNvbHVtbklEID0gdGhpcy5yZWFkZXIuaW50MTYoKTtcbiAgICAgICAgY29uc3QgZGF0YVR5cGVJRCA9IHRoaXMucmVhZGVyLmludDMyKCk7XG4gICAgICAgIGNvbnN0IGRhdGFUeXBlU2l6ZSA9IHRoaXMucmVhZGVyLmludDE2KCk7XG4gICAgICAgIGNvbnN0IGRhdGFUeXBlTW9kaWZpZXIgPSB0aGlzLnJlYWRlci5pbnQzMigpO1xuICAgICAgICBjb25zdCBtb2RlID0gdGhpcy5yZWFkZXIuaW50MTYoKSA9PT0gMCA/ICd0ZXh0JyA6ICdiaW5hcnknO1xuICAgICAgICByZXR1cm4gbmV3IG1lc3NhZ2VzXzEuRmllbGQobmFtZSwgdGFibGVJRCwgY29sdW1uSUQsIGRhdGFUeXBlSUQsIGRhdGFUeXBlU2l6ZSwgZGF0YVR5cGVNb2RpZmllciwgbW9kZSk7XG4gICAgfVxuICAgIHBhcnNlUGFyYW1ldGVyRGVzY3JpcHRpb25NZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcykge1xuICAgICAgICB0aGlzLnJlYWRlci5zZXRCdWZmZXIob2Zmc2V0LCBieXRlcyk7XG4gICAgICAgIGNvbnN0IHBhcmFtZXRlckNvdW50ID0gdGhpcy5yZWFkZXIuaW50MTYoKTtcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IG5ldyBtZXNzYWdlc18xLlBhcmFtZXRlckRlc2NyaXB0aW9uTWVzc2FnZShsZW5ndGgsIHBhcmFtZXRlckNvdW50KTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwYXJhbWV0ZXJDb3VudDsgaSsrKSB7XG4gICAgICAgICAgICBtZXNzYWdlLmRhdGFUeXBlSURzW2ldID0gdGhpcy5yZWFkZXIuaW50MzIoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbWVzc2FnZTtcbiAgICB9XG4gICAgcGFyc2VEYXRhUm93TWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpIHtcbiAgICAgICAgdGhpcy5yZWFkZXIuc2V0QnVmZmVyKG9mZnNldCwgYnl0ZXMpO1xuICAgICAgICBjb25zdCBmaWVsZENvdW50ID0gdGhpcy5yZWFkZXIuaW50MTYoKTtcbiAgICAgICAgY29uc3QgZmllbGRzID0gbmV3IEFycmF5KGZpZWxkQ291bnQpO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGZpZWxkQ291bnQ7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgbGVuID0gdGhpcy5yZWFkZXIuaW50MzIoKTtcbiAgICAgICAgICAgIC8vIGEgLTEgZm9yIGxlbmd0aCBtZWFucyB0aGUgdmFsdWUgb2YgdGhlIGZpZWxkIGlzIG51bGxcbiAgICAgICAgICAgIGZpZWxkc1tpXSA9IGxlbiA9PT0gLTEgPyBudWxsIDogdGhpcy5yZWFkZXIuc3RyaW5nKGxlbik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG5ldyBtZXNzYWdlc18xLkRhdGFSb3dNZXNzYWdlKGxlbmd0aCwgZmllbGRzKTtcbiAgICB9XG4gICAgcGFyc2VQYXJhbWV0ZXJTdGF0dXNNZXNzYWdlKG9mZnNldCwgbGVuZ3RoLCBieXRlcykge1xuICAgICAgICB0aGlzLnJlYWRlci5zZXRCdWZmZXIob2Zmc2V0LCBieXRlcyk7XG4gICAgICAgIGNvbnN0IG5hbWUgPSB0aGlzLnJlYWRlci5jc3RyaW5nKCk7XG4gICAgICAgIGNvbnN0IHZhbHVlID0gdGhpcy5yZWFkZXIuY3N0cmluZygpO1xuICAgICAgICByZXR1cm4gbmV3IG1lc3NhZ2VzXzEuUGFyYW1ldGVyU3RhdHVzTWVzc2FnZShsZW5ndGgsIG5hbWUsIHZhbHVlKTtcbiAgICB9XG4gICAgcGFyc2VCYWNrZW5kS2V5RGF0YShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMpIHtcbiAgICAgICAgdGhpcy5yZWFkZXIuc2V0QnVmZmVyKG9mZnNldCwgYnl0ZXMpO1xuICAgICAgICBjb25zdCBwcm9jZXNzSUQgPSB0aGlzLnJlYWRlci5pbnQzMigpO1xuICAgICAgICBjb25zdCBzZWNyZXRLZXkgPSB0aGlzLnJlYWRlci5pbnQzMigpO1xuICAgICAgICByZXR1cm4gbmV3IG1lc3NhZ2VzXzEuQmFja2VuZEtleURhdGFNZXNzYWdlKGxlbmd0aCwgcHJvY2Vzc0lELCBzZWNyZXRLZXkpO1xuICAgIH1cbiAgICBwYXJzZUF1dGhlbnRpY2F0aW9uUmVzcG9uc2Uob2Zmc2V0LCBsZW5ndGgsIGJ5dGVzKSB7XG4gICAgICAgIHRoaXMucmVhZGVyLnNldEJ1ZmZlcihvZmZzZXQsIGJ5dGVzKTtcbiAgICAgICAgY29uc3QgY29kZSA9IHRoaXMucmVhZGVyLmludDMyKCk7XG4gICAgICAgIC8vIFRPRE8oYm1jKTogbWF5YmUgYmV0dGVyIHR5cGVzIGhlcmVcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IHtcbiAgICAgICAgICAgIG5hbWU6ICdhdXRoZW50aWNhdGlvbk9rJyxcbiAgICAgICAgICAgIGxlbmd0aCxcbiAgICAgICAgfTtcbiAgICAgICAgc3dpdGNoIChjb2RlKSB7XG4gICAgICAgICAgICBjYXNlIDA6IC8vIEF1dGhlbnRpY2F0aW9uT2tcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgMzogLy8gQXV0aGVudGljYXRpb25DbGVhcnRleHRQYXNzd29yZFxuICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLmxlbmd0aCA9PT0gOCkge1xuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLm5hbWUgPSAnYXV0aGVudGljYXRpb25DbGVhcnRleHRQYXNzd29yZCc7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSA1OiAvLyBBdXRoZW50aWNhdGlvbk1ENVBhc3N3b3JkXG4gICAgICAgICAgICAgICAgaWYgKG1lc3NhZ2UubGVuZ3RoID09PSAxMikge1xuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLm5hbWUgPSAnYXV0aGVudGljYXRpb25NRDVQYXNzd29yZCc7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHNhbHQgPSB0aGlzLnJlYWRlci5ieXRlcyg0KTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBtZXNzYWdlc18xLkF1dGhlbnRpY2F0aW9uTUQ1UGFzc3dvcmQobGVuZ3RoLCBzYWx0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIDEwOiAvLyBBdXRoZW50aWNhdGlvblNBU0xcbiAgICAgICAgICAgICAgICBtZXNzYWdlLm5hbWUgPSAnYXV0aGVudGljYXRpb25TQVNMJztcbiAgICAgICAgICAgICAgICBtZXNzYWdlLm1lY2hhbmlzbXMgPSBbXTtcbiAgICAgICAgICAgICAgICBsZXQgbWVjaGFuaXNtO1xuICAgICAgICAgICAgICAgIGRvIHtcbiAgICAgICAgICAgICAgICAgICAgbWVjaGFuaXNtID0gdGhpcy5yZWFkZXIuY3N0cmluZygpO1xuICAgICAgICAgICAgICAgICAgICBpZiAobWVjaGFuaXNtKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLm1lY2hhbmlzbXMucHVzaChtZWNoYW5pc20pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSB3aGlsZSAobWVjaGFuaXNtKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgMTE6IC8vIEF1dGhlbnRpY2F0aW9uU0FTTENvbnRpbnVlXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5uYW1lID0gJ2F1dGhlbnRpY2F0aW9uU0FTTENvbnRpbnVlJztcbiAgICAgICAgICAgICAgICBtZXNzYWdlLmRhdGEgPSB0aGlzLnJlYWRlci5zdHJpbmcobGVuZ3RoIC0gOCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIDEyOiAvLyBBdXRoZW50aWNhdGlvblNBU0xGaW5hbFxuICAgICAgICAgICAgICAgIG1lc3NhZ2UubmFtZSA9ICdhdXRoZW50aWNhdGlvblNBU0xGaW5hbCc7XG4gICAgICAgICAgICAgICAgbWVzc2FnZS5kYXRhID0gdGhpcy5yZWFkZXIuc3RyaW5nKGxlbmd0aCAtIDgpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1Vua25vd24gYXV0aGVudGljYXRpb25PayBtZXNzYWdlIHR5cGUgJyArIGNvZGUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgIH1cbiAgICBwYXJzZUVycm9yTWVzc2FnZShvZmZzZXQsIGxlbmd0aCwgYnl0ZXMsIG5hbWUpIHtcbiAgICAgICAgdGhpcy5yZWFkZXIuc2V0QnVmZmVyKG9mZnNldCwgYnl0ZXMpO1xuICAgICAgICBjb25zdCBmaWVsZHMgPSB7fTtcbiAgICAgICAgbGV0IGZpZWxkVHlwZSA9IHRoaXMucmVhZGVyLnN0cmluZygxKTtcbiAgICAgICAgd2hpbGUgKGZpZWxkVHlwZSAhPT0gJ1xcMCcpIHtcbiAgICAgICAgICAgIGZpZWxkc1tmaWVsZFR5cGVdID0gdGhpcy5yZWFkZXIuY3N0cmluZygpO1xuICAgICAgICAgICAgZmllbGRUeXBlID0gdGhpcy5yZWFkZXIuc3RyaW5nKDEpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG1lc3NhZ2VWYWx1ZSA9IGZpZWxkcy5NO1xuICAgICAgICBjb25zdCBtZXNzYWdlID0gbmFtZSA9PT0gJ25vdGljZScgPyBuZXcgbWVzc2FnZXNfMS5Ob3RpY2VNZXNzYWdlKGxlbmd0aCwgbWVzc2FnZVZhbHVlKSA6IG5ldyBtZXNzYWdlc18xLkRhdGFiYXNlRXJyb3IobWVzc2FnZVZhbHVlLCBsZW5ndGgsIG5hbWUpO1xuICAgICAgICBtZXNzYWdlLnNldmVyaXR5ID0gZmllbGRzLlM7XG4gICAgICAgIG1lc3NhZ2UuY29kZSA9IGZpZWxkcy5DO1xuICAgICAgICBtZXNzYWdlLmRldGFpbCA9IGZpZWxkcy5EO1xuICAgICAgICBtZXNzYWdlLmhpbnQgPSBmaWVsZHMuSDtcbiAgICAgICAgbWVzc2FnZS5wb3NpdGlvbiA9IGZpZWxkcy5QO1xuICAgICAgICBtZXNzYWdlLmludGVybmFsUG9zaXRpb24gPSBmaWVsZHMucDtcbiAgICAgICAgbWVzc2FnZS5pbnRlcm5hbFF1ZXJ5ID0gZmllbGRzLnE7XG4gICAgICAgIG1lc3NhZ2Uud2hlcmUgPSBmaWVsZHMuVztcbiAgICAgICAgbWVzc2FnZS5zY2hlbWEgPSBmaWVsZHMucztcbiAgICAgICAgbWVzc2FnZS50YWJsZSA9IGZpZWxkcy50O1xuICAgICAgICBtZXNzYWdlLmNvbHVtbiA9IGZpZWxkcy5jO1xuICAgICAgICBtZXNzYWdlLmRhdGFUeXBlID0gZmllbGRzLmQ7XG4gICAgICAgIG1lc3NhZ2UuY29uc3RyYWludCA9IGZpZWxkcy5uO1xuICAgICAgICBtZXNzYWdlLmZpbGUgPSBmaWVsZHMuRjtcbiAgICAgICAgbWVzc2FnZS5saW5lID0gZmllbGRzLkw7XG4gICAgICAgIG1lc3NhZ2Uucm91dGluZSA9IGZpZWxkcy5SO1xuICAgICAgICByZXR1cm4gbWVzc2FnZTtcbiAgICB9XG59XG5leHBvcnRzLlBhcnNlciA9IFBhcnNlcjtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBhcnNlci5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuc2VyaWFsaXplID0gdm9pZCAwO1xuY29uc3QgYnVmZmVyX3dyaXRlcl8xID0gcmVxdWlyZShcIi4vYnVmZmVyLXdyaXRlclwiKTtcbmNvbnN0IHdyaXRlciA9IG5ldyBidWZmZXJfd3JpdGVyXzEuV3JpdGVyKCk7XG5jb25zdCBzdGFydHVwID0gKG9wdHMpID0+IHtcbiAgICAvLyBwcm90b2NvbCB2ZXJzaW9uXG4gICAgd3JpdGVyLmFkZEludDE2KDMpLmFkZEludDE2KDApO1xuICAgIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKG9wdHMpKSB7XG4gICAgICAgIHdyaXRlci5hZGRDU3RyaW5nKGtleSkuYWRkQ1N0cmluZyhvcHRzW2tleV0pO1xuICAgIH1cbiAgICB3cml0ZXIuYWRkQ1N0cmluZygnY2xpZW50X2VuY29kaW5nJykuYWRkQ1N0cmluZygnVVRGOCcpO1xuICAgIHZhciBib2R5QnVmZmVyID0gd3JpdGVyLmFkZENTdHJpbmcoJycpLmZsdXNoKCk7XG4gICAgLy8gdGhpcyBtZXNzYWdlIGlzIHNlbnQgd2l0aG91dCBhIGNvZGVcbiAgICB2YXIgbGVuZ3RoID0gYm9keUJ1ZmZlci5sZW5ndGggKyA0O1xuICAgIHJldHVybiBuZXcgYnVmZmVyX3dyaXRlcl8xLldyaXRlcigpLmFkZEludDMyKGxlbmd0aCkuYWRkKGJvZHlCdWZmZXIpLmZsdXNoKCk7XG59O1xuY29uc3QgcmVxdWVzdFNzbCA9ICgpID0+IHtcbiAgICBjb25zdCByZXNwb25zZSA9IEJ1ZmZlci5hbGxvY1Vuc2FmZSg4KTtcbiAgICByZXNwb25zZS53cml0ZUludDMyQkUoOCwgMCk7XG4gICAgcmVzcG9uc2Uud3JpdGVJbnQzMkJFKDgwODc3MTAzLCA0KTtcbiAgICByZXR1cm4gcmVzcG9uc2U7XG59O1xuY29uc3QgcGFzc3dvcmQgPSAocGFzc3dvcmQpID0+IHtcbiAgICByZXR1cm4gd3JpdGVyLmFkZENTdHJpbmcocGFzc3dvcmQpLmZsdXNoKDExMiAvKiBzdGFydHVwICovKTtcbn07XG5jb25zdCBzZW5kU0FTTEluaXRpYWxSZXNwb25zZU1lc3NhZ2UgPSBmdW5jdGlvbiAobWVjaGFuaXNtLCBpbml0aWFsUmVzcG9uc2UpIHtcbiAgICAvLyAweDcwID0gJ3AnXG4gICAgd3JpdGVyLmFkZENTdHJpbmcobWVjaGFuaXNtKS5hZGRJbnQzMihCdWZmZXIuYnl0ZUxlbmd0aChpbml0aWFsUmVzcG9uc2UpKS5hZGRTdHJpbmcoaW5pdGlhbFJlc3BvbnNlKTtcbiAgICByZXR1cm4gd3JpdGVyLmZsdXNoKDExMiAvKiBzdGFydHVwICovKTtcbn07XG5jb25zdCBzZW5kU0NSQU1DbGllbnRGaW5hbE1lc3NhZ2UgPSBmdW5jdGlvbiAoYWRkaXRpb25hbERhdGEpIHtcbiAgICByZXR1cm4gd3JpdGVyLmFkZFN0cmluZyhhZGRpdGlvbmFsRGF0YSkuZmx1c2goMTEyIC8qIHN0YXJ0dXAgKi8pO1xufTtcbmNvbnN0IHF1ZXJ5ID0gKHRleHQpID0+IHtcbiAgICByZXR1cm4gd3JpdGVyLmFkZENTdHJpbmcodGV4dCkuZmx1c2goODEgLyogcXVlcnkgKi8pO1xufTtcbmNvbnN0IGVtcHR5QXJyYXkgPSBbXTtcbmNvbnN0IHBhcnNlID0gKHF1ZXJ5KSA9PiB7XG4gICAgLy8gZXhwZWN0IHNvbWV0aGluZyBsaWtlIHRoaXM6XG4gICAgLy8geyBuYW1lOiAncXVlcnlOYW1lJyxcbiAgICAvLyAgIHRleHQ6ICdzZWxlY3QgKiBmcm9tIGJsYWgnLFxuICAgIC8vICAgdHlwZXM6IFsnaW50OCcsICdib29sJ10gfVxuICAgIC8vIG5vcm1hbGl6ZSBtaXNzaW5nIHF1ZXJ5IG5hbWVzIHRvIGFsbG93IGZvciBudWxsXG4gICAgY29uc3QgbmFtZSA9IHF1ZXJ5Lm5hbWUgfHwgJyc7XG4gICAgaWYgKG5hbWUubGVuZ3RoID4gNjMpIHtcbiAgICAgICAgLyogZXNsaW50LWRpc2FibGUgbm8tY29uc29sZSAqL1xuICAgICAgICBjb25zb2xlLmVycm9yKCdXYXJuaW5nISBQb3N0Z3JlcyBvbmx5IHN1cHBvcnRzIDYzIGNoYXJhY3RlcnMgZm9yIHF1ZXJ5IG5hbWVzLicpO1xuICAgICAgICBjb25zb2xlLmVycm9yKCdZb3Ugc3VwcGxpZWQgJXMgKCVzKScsIG5hbWUsIG5hbWUubGVuZ3RoKTtcbiAgICAgICAgY29uc29sZS5lcnJvcignVGhpcyBjYW4gY2F1c2UgY29uZmxpY3RzIGFuZCBzaWxlbnQgZXJyb3JzIGV4ZWN1dGluZyBxdWVyaWVzJyk7XG4gICAgICAgIC8qIGVzbGludC1lbmFibGUgbm8tY29uc29sZSAqL1xuICAgIH1cbiAgICBjb25zdCB0eXBlcyA9IHF1ZXJ5LnR5cGVzIHx8IGVtcHR5QXJyYXk7XG4gICAgdmFyIGxlbiA9IHR5cGVzLmxlbmd0aDtcbiAgICB2YXIgYnVmZmVyID0gd3JpdGVyXG4gICAgICAgIC5hZGRDU3RyaW5nKG5hbWUpIC8vIG5hbWUgb2YgcXVlcnlcbiAgICAgICAgLmFkZENTdHJpbmcocXVlcnkudGV4dCkgLy8gYWN0dWFsIHF1ZXJ5IHRleHRcbiAgICAgICAgLmFkZEludDE2KGxlbik7XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW47IGkrKykge1xuICAgICAgICBidWZmZXIuYWRkSW50MzIodHlwZXNbaV0pO1xuICAgIH1cbiAgICByZXR1cm4gd3JpdGVyLmZsdXNoKDgwIC8qIHBhcnNlICovKTtcbn07XG5jb25zdCBwYXJhbVdyaXRlciA9IG5ldyBidWZmZXJfd3JpdGVyXzEuV3JpdGVyKCk7XG5jb25zdCB3cml0ZVZhbHVlcyA9IGZ1bmN0aW9uICh2YWx1ZXMsIHZhbHVlTWFwcGVyKSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB2YWx1ZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgY29uc3QgbWFwcGVkVmFsID0gdmFsdWVNYXBwZXIgPyB2YWx1ZU1hcHBlcih2YWx1ZXNbaV0sIGkpIDogdmFsdWVzW2ldO1xuICAgICAgICBpZiAobWFwcGVkVmFsID09IG51bGwpIHtcbiAgICAgICAgICAgIC8vIGFkZCB0aGUgcGFyYW0gdHlwZSAoc3RyaW5nKSB0byB0aGUgd3JpdGVyXG4gICAgICAgICAgICB3cml0ZXIuYWRkSW50MTYoMCAvKiBTVFJJTkcgKi8pO1xuICAgICAgICAgICAgLy8gd3JpdGUgLTEgdG8gdGhlIHBhcmFtIHdyaXRlciB0byBpbmRpY2F0ZSBudWxsXG4gICAgICAgICAgICBwYXJhbVdyaXRlci5hZGRJbnQzMigtMSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWFwcGVkVmFsIGluc3RhbmNlb2YgQnVmZmVyKSB7XG4gICAgICAgICAgICAvLyBhZGQgdGhlIHBhcmFtIHR5cGUgKGJpbmFyeSkgdG8gdGhlIHdyaXRlclxuICAgICAgICAgICAgd3JpdGVyLmFkZEludDE2KDEgLyogQklOQVJZICovKTtcbiAgICAgICAgICAgIC8vIGFkZCB0aGUgYnVmZmVyIHRvIHRoZSBwYXJhbSB3cml0ZXJcbiAgICAgICAgICAgIHBhcmFtV3JpdGVyLmFkZEludDMyKG1hcHBlZFZhbC5sZW5ndGgpO1xuICAgICAgICAgICAgcGFyYW1Xcml0ZXIuYWRkKG1hcHBlZFZhbCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAvLyBhZGQgdGhlIHBhcmFtIHR5cGUgKHN0cmluZykgdG8gdGhlIHdyaXRlclxuICAgICAgICAgICAgd3JpdGVyLmFkZEludDE2KDAgLyogU1RSSU5HICovKTtcbiAgICAgICAgICAgIHBhcmFtV3JpdGVyLmFkZEludDMyKEJ1ZmZlci5ieXRlTGVuZ3RoKG1hcHBlZFZhbCkpO1xuICAgICAgICAgICAgcGFyYW1Xcml0ZXIuYWRkU3RyaW5nKG1hcHBlZFZhbCk7XG4gICAgICAgIH1cbiAgICB9XG59O1xuY29uc3QgYmluZCA9IChjb25maWcgPSB7fSkgPT4ge1xuICAgIC8vIG5vcm1hbGl6ZSBjb25maWdcbiAgICBjb25zdCBwb3J0YWwgPSBjb25maWcucG9ydGFsIHx8ICcnO1xuICAgIGNvbnN0IHN0YXRlbWVudCA9IGNvbmZpZy5zdGF0ZW1lbnQgfHwgJyc7XG4gICAgY29uc3QgYmluYXJ5ID0gY29uZmlnLmJpbmFyeSB8fCBmYWxzZTtcbiAgICBjb25zdCB2YWx1ZXMgPSBjb25maWcudmFsdWVzIHx8IGVtcHR5QXJyYXk7XG4gICAgY29uc3QgbGVuID0gdmFsdWVzLmxlbmd0aDtcbiAgICB3cml0ZXIuYWRkQ1N0cmluZyhwb3J0YWwpLmFkZENTdHJpbmcoc3RhdGVtZW50KTtcbiAgICB3cml0ZXIuYWRkSW50MTYobGVuKTtcbiAgICB3cml0ZVZhbHVlcyh2YWx1ZXMsIGNvbmZpZy52YWx1ZU1hcHBlcik7XG4gICAgd3JpdGVyLmFkZEludDE2KGxlbik7XG4gICAgd3JpdGVyLmFkZChwYXJhbVdyaXRlci5mbHVzaCgpKTtcbiAgICAvLyBmb3JtYXQgY29kZVxuICAgIHdyaXRlci5hZGRJbnQxNihiaW5hcnkgPyAxIC8qIEJJTkFSWSAqLyA6IDAgLyogU1RSSU5HICovKTtcbiAgICByZXR1cm4gd3JpdGVyLmZsdXNoKDY2IC8qIGJpbmQgKi8pO1xufTtcbmNvbnN0IGVtcHR5RXhlY3V0ZSA9IEJ1ZmZlci5mcm9tKFs2OSAvKiBleGVjdXRlICovLCAweDAwLCAweDAwLCAweDAwLCAweDA5LCAweDAwLCAweDAwLCAweDAwLCAweDAwLCAweDAwXSk7XG5jb25zdCBleGVjdXRlID0gKGNvbmZpZykgPT4ge1xuICAgIC8vIHRoaXMgaXMgdGhlIGhhcHB5IHBhdGggZm9yIG1vc3QgcXVlcmllc1xuICAgIGlmICghY29uZmlnIHx8ICghY29uZmlnLnBvcnRhbCAmJiAhY29uZmlnLnJvd3MpKSB7XG4gICAgICAgIHJldHVybiBlbXB0eUV4ZWN1dGU7XG4gICAgfVxuICAgIGNvbnN0IHBvcnRhbCA9IGNvbmZpZy5wb3J0YWwgfHwgJyc7XG4gICAgY29uc3Qgcm93cyA9IGNvbmZpZy5yb3dzIHx8IDA7XG4gICAgY29uc3QgcG9ydGFsTGVuZ3RoID0gQnVmZmVyLmJ5dGVMZW5ndGgocG9ydGFsKTtcbiAgICBjb25zdCBsZW4gPSA0ICsgcG9ydGFsTGVuZ3RoICsgMSArIDQ7XG4gICAgLy8gb25lIGV4dHJhIGJpdCBmb3IgY29kZVxuICAgIGNvbnN0IGJ1ZmYgPSBCdWZmZXIuYWxsb2NVbnNhZmUoMSArIGxlbik7XG4gICAgYnVmZlswXSA9IDY5IC8qIGV4ZWN1dGUgKi87XG4gICAgYnVmZi53cml0ZUludDMyQkUobGVuLCAxKTtcbiAgICBidWZmLndyaXRlKHBvcnRhbCwgNSwgJ3V0Zi04Jyk7XG4gICAgYnVmZltwb3J0YWxMZW5ndGggKyA1XSA9IDA7IC8vIG51bGwgdGVybWluYXRlIHBvcnRhbCBjU3RyaW5nXG4gICAgYnVmZi53cml0ZVVJbnQzMkJFKHJvd3MsIGJ1ZmYubGVuZ3RoIC0gNCk7XG4gICAgcmV0dXJuIGJ1ZmY7XG59O1xuY29uc3QgY2FuY2VsID0gKHByb2Nlc3NJRCwgc2VjcmV0S2V5KSA9PiB7XG4gICAgY29uc3QgYnVmZmVyID0gQnVmZmVyLmFsbG9jVW5zYWZlKDE2KTtcbiAgICBidWZmZXIud3JpdGVJbnQzMkJFKDE2LCAwKTtcbiAgICBidWZmZXIud3JpdGVJbnQxNkJFKDEyMzQsIDQpO1xuICAgIGJ1ZmZlci53cml0ZUludDE2QkUoNTY3OCwgNik7XG4gICAgYnVmZmVyLndyaXRlSW50MzJCRShwcm9jZXNzSUQsIDgpO1xuICAgIGJ1ZmZlci53cml0ZUludDMyQkUoc2VjcmV0S2V5LCAxMik7XG4gICAgcmV0dXJuIGJ1ZmZlcjtcbn07XG5jb25zdCBjc3RyaW5nTWVzc2FnZSA9IChjb2RlLCBzdHJpbmcpID0+IHtcbiAgICBjb25zdCBzdHJpbmdMZW4gPSBCdWZmZXIuYnl0ZUxlbmd0aChzdHJpbmcpO1xuICAgIGNvbnN0IGxlbiA9IDQgKyBzdHJpbmdMZW4gKyAxO1xuICAgIC8vIG9uZSBleHRyYSBiaXQgZm9yIGNvZGVcbiAgICBjb25zdCBidWZmZXIgPSBCdWZmZXIuYWxsb2NVbnNhZmUoMSArIGxlbik7XG4gICAgYnVmZmVyWzBdID0gY29kZTtcbiAgICBidWZmZXIud3JpdGVJbnQzMkJFKGxlbiwgMSk7XG4gICAgYnVmZmVyLndyaXRlKHN0cmluZywgNSwgJ3V0Zi04Jyk7XG4gICAgYnVmZmVyW2xlbl0gPSAwOyAvLyBudWxsIHRlcm1pbmF0ZSBjU3RyaW5nXG4gICAgcmV0dXJuIGJ1ZmZlcjtcbn07XG5jb25zdCBlbXB0eURlc2NyaWJlUG9ydGFsID0gd3JpdGVyLmFkZENTdHJpbmcoJ1AnKS5mbHVzaCg2OCAvKiBkZXNjcmliZSAqLyk7XG5jb25zdCBlbXB0eURlc2NyaWJlU3RhdGVtZW50ID0gd3JpdGVyLmFkZENTdHJpbmcoJ1MnKS5mbHVzaCg2OCAvKiBkZXNjcmliZSAqLyk7XG5jb25zdCBkZXNjcmliZSA9IChtc2cpID0+IHtcbiAgICByZXR1cm4gbXNnLm5hbWVcbiAgICAgICAgPyBjc3RyaW5nTWVzc2FnZSg2OCAvKiBkZXNjcmliZSAqLywgYCR7bXNnLnR5cGV9JHttc2cubmFtZSB8fCAnJ31gKVxuICAgICAgICA6IG1zZy50eXBlID09PSAnUCdcbiAgICAgICAgICAgID8gZW1wdHlEZXNjcmliZVBvcnRhbFxuICAgICAgICAgICAgOiBlbXB0eURlc2NyaWJlU3RhdGVtZW50O1xufTtcbmNvbnN0IGNsb3NlID0gKG1zZykgPT4ge1xuICAgIGNvbnN0IHRleHQgPSBgJHttc2cudHlwZX0ke21zZy5uYW1lIHx8ICcnfWA7XG4gICAgcmV0dXJuIGNzdHJpbmdNZXNzYWdlKDY3IC8qIGNsb3NlICovLCB0ZXh0KTtcbn07XG5jb25zdCBjb3B5RGF0YSA9IChjaHVuaykgPT4ge1xuICAgIHJldHVybiB3cml0ZXIuYWRkKGNodW5rKS5mbHVzaCgxMDAgLyogY29weUZyb21DaHVuayAqLyk7XG59O1xuY29uc3QgY29weUZhaWwgPSAobWVzc2FnZSkgPT4ge1xuICAgIHJldHVybiBjc3RyaW5nTWVzc2FnZSgxMDIgLyogY29weUZhaWwgKi8sIG1lc3NhZ2UpO1xufTtcbmNvbnN0IGNvZGVPbmx5QnVmZmVyID0gKGNvZGUpID0+IEJ1ZmZlci5mcm9tKFtjb2RlLCAweDAwLCAweDAwLCAweDAwLCAweDA0XSk7XG5jb25zdCBmbHVzaEJ1ZmZlciA9IGNvZGVPbmx5QnVmZmVyKDcyIC8qIGZsdXNoICovKTtcbmNvbnN0IHN5bmNCdWZmZXIgPSBjb2RlT25seUJ1ZmZlcig4MyAvKiBzeW5jICovKTtcbmNvbnN0IGVuZEJ1ZmZlciA9IGNvZGVPbmx5QnVmZmVyKDg4IC8qIGVuZCAqLyk7XG5jb25zdCBjb3B5RG9uZUJ1ZmZlciA9IGNvZGVPbmx5QnVmZmVyKDk5IC8qIGNvcHlEb25lICovKTtcbmNvbnN0IHNlcmlhbGl6ZSA9IHtcbiAgICBzdGFydHVwLFxuICAgIHBhc3N3b3JkLFxuICAgIHJlcXVlc3RTc2wsXG4gICAgc2VuZFNBU0xJbml0aWFsUmVzcG9uc2VNZXNzYWdlLFxuICAgIHNlbmRTQ1JBTUNsaWVudEZpbmFsTWVzc2FnZSxcbiAgICBxdWVyeSxcbiAgICBwYXJzZSxcbiAgICBiaW5kLFxuICAgIGV4ZWN1dGUsXG4gICAgZGVzY3JpYmUsXG4gICAgY2xvc2UsXG4gICAgZmx1c2g6ICgpID0+IGZsdXNoQnVmZmVyLFxuICAgIHN5bmM6ICgpID0+IHN5bmNCdWZmZXIsXG4gICAgZW5kOiAoKSA9PiBlbmRCdWZmZXIsXG4gICAgY29weURhdGEsXG4gICAgY29weURvbmU6ICgpID0+IGNvcHlEb25lQnVmZmVyLFxuICAgIGNvcHlGYWlsLFxuICAgIGNhbmNlbCxcbn07XG5leHBvcnRzLnNlcmlhbGl6ZSA9IHNlcmlhbGl6ZTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXNlcmlhbGl6ZXIuanMubWFwIiwidmFyIHRleHRQYXJzZXJzID0gcmVxdWlyZSgnLi9saWIvdGV4dFBhcnNlcnMnKTtcbnZhciBiaW5hcnlQYXJzZXJzID0gcmVxdWlyZSgnLi9saWIvYmluYXJ5UGFyc2VycycpO1xudmFyIGFycmF5UGFyc2VyID0gcmVxdWlyZSgnLi9saWIvYXJyYXlQYXJzZXInKTtcbnZhciBidWlsdGluVHlwZXMgPSByZXF1aXJlKCcuL2xpYi9idWlsdGlucycpO1xuXG5leHBvcnRzLmdldFR5cGVQYXJzZXIgPSBnZXRUeXBlUGFyc2VyO1xuZXhwb3J0cy5zZXRUeXBlUGFyc2VyID0gc2V0VHlwZVBhcnNlcjtcbmV4cG9ydHMuYXJyYXlQYXJzZXIgPSBhcnJheVBhcnNlcjtcbmV4cG9ydHMuYnVpbHRpbnMgPSBidWlsdGluVHlwZXM7XG5cbnZhciB0eXBlUGFyc2VycyA9IHtcbiAgdGV4dDoge30sXG4gIGJpbmFyeToge31cbn07XG5cbi8vdGhlIGVtcHR5IHBhcnNlIGZ1bmN0aW9uXG5mdW5jdGlvbiBub1BhcnNlICh2YWwpIHtcbiAgcmV0dXJuIFN0cmluZyh2YWwpO1xufTtcblxuLy9yZXR1cm5zIGEgZnVuY3Rpb24gdXNlZCB0byBjb252ZXJ0IGEgc3BlY2lmaWMgdHlwZSAoc3BlY2lmaWVkIGJ5XG4vL29pZCkgaW50byBhIHJlc3VsdCBqYXZhc2NyaXB0IHR5cGVcbi8vbm90ZTogdGhlIG9pZCBjYW4gYmUgb2J0YWluZWQgdmlhIHRoZSBmb2xsb3dpbmcgc3FsIHF1ZXJ5OlxuLy9TRUxFQ1Qgb2lkIEZST00gcGdfdHlwZSBXSEVSRSB0eXBuYW1lID0gJ1RZUEVfTkFNRV9IRVJFJztcbmZ1bmN0aW9uIGdldFR5cGVQYXJzZXIgKG9pZCwgZm9ybWF0KSB7XG4gIGZvcm1hdCA9IGZvcm1hdCB8fCAndGV4dCc7XG4gIGlmICghdHlwZVBhcnNlcnNbZm9ybWF0XSkge1xuICAgIHJldHVybiBub1BhcnNlO1xuICB9XG4gIHJldHVybiB0eXBlUGFyc2Vyc1tmb3JtYXRdW29pZF0gfHwgbm9QYXJzZTtcbn07XG5cbmZ1bmN0aW9uIHNldFR5cGVQYXJzZXIgKG9pZCwgZm9ybWF0LCBwYXJzZUZuKSB7XG4gIGlmKHR5cGVvZiBmb3JtYXQgPT0gJ2Z1bmN0aW9uJykge1xuICAgIHBhcnNlRm4gPSBmb3JtYXQ7XG4gICAgZm9ybWF0ID0gJ3RleHQnO1xuICB9XG4gIHR5cGVQYXJzZXJzW2Zvcm1hdF1bb2lkXSA9IHBhcnNlRm47XG59O1xuXG50ZXh0UGFyc2Vycy5pbml0KGZ1bmN0aW9uKG9pZCwgY29udmVydGVyKSB7XG4gIHR5cGVQYXJzZXJzLnRleHRbb2lkXSA9IGNvbnZlcnRlcjtcbn0pO1xuXG5iaW5hcnlQYXJzZXJzLmluaXQoZnVuY3Rpb24ob2lkLCBjb252ZXJ0ZXIpIHtcbiAgdHlwZVBhcnNlcnMuYmluYXJ5W29pZF0gPSBjb252ZXJ0ZXI7XG59KTtcbiIsInZhciBhcnJheSA9IHJlcXVpcmUoJ3Bvc3RncmVzLWFycmF5Jyk7XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICBjcmVhdGU6IGZ1bmN0aW9uIChzb3VyY2UsIHRyYW5zZm9ybSkge1xuICAgIHJldHVybiB7XG4gICAgICBwYXJzZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiBhcnJheS5wYXJzZShzb3VyY2UsIHRyYW5zZm9ybSk7XG4gICAgICB9XG4gICAgfTtcbiAgfVxufTtcbiIsInZhciBwYXJzZUludDY0ID0gcmVxdWlyZSgncGctaW50OCcpO1xuXG52YXIgcGFyc2VCaXRzID0gZnVuY3Rpb24oZGF0YSwgYml0cywgb2Zmc2V0LCBpbnZlcnQsIGNhbGxiYWNrKSB7XG4gIG9mZnNldCA9IG9mZnNldCB8fCAwO1xuICBpbnZlcnQgPSBpbnZlcnQgfHwgZmFsc2U7XG4gIGNhbGxiYWNrID0gY2FsbGJhY2sgfHwgZnVuY3Rpb24obGFzdFZhbHVlLCBuZXdWYWx1ZSwgYml0cykgeyByZXR1cm4gKGxhc3RWYWx1ZSAqIE1hdGgucG93KDIsIGJpdHMpKSArIG5ld1ZhbHVlOyB9O1xuICB2YXIgb2Zmc2V0Qnl0ZXMgPSBvZmZzZXQgPj4gMztcblxuICB2YXIgaW52ID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgICBpZiAoaW52ZXJ0KSB7XG4gICAgICByZXR1cm4gfnZhbHVlICYgMHhmZjtcbiAgICB9XG5cbiAgICByZXR1cm4gdmFsdWU7XG4gIH07XG5cbiAgLy8gcmVhZCBmaXJzdCAobWF5YmUgcGFydGlhbCkgYnl0ZVxuICB2YXIgbWFzayA9IDB4ZmY7XG4gIHZhciBmaXJzdEJpdHMgPSA4IC0gKG9mZnNldCAlIDgpO1xuICBpZiAoYml0cyA8IGZpcnN0Qml0cykge1xuICAgIG1hc2sgPSAoMHhmZiA8PCAoOCAtIGJpdHMpKSAmIDB4ZmY7XG4gICAgZmlyc3RCaXRzID0gYml0cztcbiAgfVxuXG4gIGlmIChvZmZzZXQpIHtcbiAgICBtYXNrID0gbWFzayA+PiAob2Zmc2V0ICUgOCk7XG4gIH1cblxuICB2YXIgcmVzdWx0ID0gMDtcbiAgaWYgKChvZmZzZXQgJSA4KSArIGJpdHMgPj0gOCkge1xuICAgIHJlc3VsdCA9IGNhbGxiYWNrKDAsIGludihkYXRhW29mZnNldEJ5dGVzXSkgJiBtYXNrLCBmaXJzdEJpdHMpO1xuICB9XG5cbiAgLy8gcmVhZCBieXRlc1xuICB2YXIgYnl0ZXMgPSAoYml0cyArIG9mZnNldCkgPj4gMztcbiAgZm9yICh2YXIgaSA9IG9mZnNldEJ5dGVzICsgMTsgaSA8IGJ5dGVzOyBpKyspIHtcbiAgICByZXN1bHQgPSBjYWxsYmFjayhyZXN1bHQsIGludihkYXRhW2ldKSwgOCk7XG4gIH1cblxuICAvLyBiaXRzIHRvIHJlYWQsIHRoYXQgYXJlIG5vdCBhIGNvbXBsZXRlIGJ5dGVcbiAgdmFyIGxhc3RCaXRzID0gKGJpdHMgKyBvZmZzZXQpICUgODtcbiAgaWYgKGxhc3RCaXRzID4gMCkge1xuICAgIHJlc3VsdCA9IGNhbGxiYWNrKHJlc3VsdCwgaW52KGRhdGFbYnl0ZXNdKSA+PiAoOCAtIGxhc3RCaXRzKSwgbGFzdEJpdHMpO1xuICB9XG5cbiAgcmV0dXJuIHJlc3VsdDtcbn07XG5cbnZhciBwYXJzZUZsb2F0RnJvbUJpdHMgPSBmdW5jdGlvbihkYXRhLCBwcmVjaXNpb25CaXRzLCBleHBvbmVudEJpdHMpIHtcbiAgdmFyIGJpYXMgPSBNYXRoLnBvdygyLCBleHBvbmVudEJpdHMgLSAxKSAtIDE7XG4gIHZhciBzaWduID0gcGFyc2VCaXRzKGRhdGEsIDEpO1xuICB2YXIgZXhwb25lbnQgPSBwYXJzZUJpdHMoZGF0YSwgZXhwb25lbnRCaXRzLCAxKTtcblxuICBpZiAoZXhwb25lbnQgPT09IDApIHtcbiAgICByZXR1cm4gMDtcbiAgfVxuXG4gIC8vIHBhcnNlIG1hbnRpc3NhXG4gIHZhciBwcmVjaXNpb25CaXRzQ291bnRlciA9IDE7XG4gIHZhciBwYXJzZVByZWNpc2lvbkJpdHMgPSBmdW5jdGlvbihsYXN0VmFsdWUsIG5ld1ZhbHVlLCBiaXRzKSB7XG4gICAgaWYgKGxhc3RWYWx1ZSA9PT0gMCkge1xuICAgICAgbGFzdFZhbHVlID0gMTtcbiAgICB9XG5cbiAgICBmb3IgKHZhciBpID0gMTsgaSA8PSBiaXRzOyBpKyspIHtcbiAgICAgIHByZWNpc2lvbkJpdHNDb3VudGVyIC89IDI7XG4gICAgICBpZiAoKG5ld1ZhbHVlICYgKDB4MSA8PCAoYml0cyAtIGkpKSkgPiAwKSB7XG4gICAgICAgIGxhc3RWYWx1ZSArPSBwcmVjaXNpb25CaXRzQ291bnRlcjtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gbGFzdFZhbHVlO1xuICB9O1xuXG4gIHZhciBtYW50aXNzYSA9IHBhcnNlQml0cyhkYXRhLCBwcmVjaXNpb25CaXRzLCBleHBvbmVudEJpdHMgKyAxLCBmYWxzZSwgcGFyc2VQcmVjaXNpb25CaXRzKTtcblxuICAvLyBzcGVjaWFsIGNhc2VzXG4gIGlmIChleHBvbmVudCA9PSAoTWF0aC5wb3coMiwgZXhwb25lbnRCaXRzICsgMSkgLSAxKSkge1xuICAgIGlmIChtYW50aXNzYSA9PT0gMCkge1xuICAgICAgcmV0dXJuIChzaWduID09PSAwKSA/IEluZmluaXR5IDogLUluZmluaXR5O1xuICAgIH1cblxuICAgIHJldHVybiBOYU47XG4gIH1cblxuICAvLyBub3JtYWxlIG51bWJlclxuICByZXR1cm4gKChzaWduID09PSAwKSA/IDEgOiAtMSkgKiBNYXRoLnBvdygyLCBleHBvbmVudCAtIGJpYXMpICogbWFudGlzc2E7XG59O1xuXG52YXIgcGFyc2VJbnQxNiA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIGlmIChwYXJzZUJpdHModmFsdWUsIDEpID09IDEpIHtcbiAgICByZXR1cm4gLTEgKiAocGFyc2VCaXRzKHZhbHVlLCAxNSwgMSwgdHJ1ZSkgKyAxKTtcbiAgfVxuXG4gIHJldHVybiBwYXJzZUJpdHModmFsdWUsIDE1LCAxKTtcbn07XG5cbnZhciBwYXJzZUludDMyID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgaWYgKHBhcnNlQml0cyh2YWx1ZSwgMSkgPT0gMSkge1xuICAgIHJldHVybiAtMSAqIChwYXJzZUJpdHModmFsdWUsIDMxLCAxLCB0cnVlKSArIDEpO1xuICB9XG5cbiAgcmV0dXJuIHBhcnNlQml0cyh2YWx1ZSwgMzEsIDEpO1xufTtcblxudmFyIHBhcnNlRmxvYXQzMiA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIHJldHVybiBwYXJzZUZsb2F0RnJvbUJpdHModmFsdWUsIDIzLCA4KTtcbn07XG5cbnZhciBwYXJzZUZsb2F0NjQgPSBmdW5jdGlvbih2YWx1ZSkge1xuICByZXR1cm4gcGFyc2VGbG9hdEZyb21CaXRzKHZhbHVlLCA1MiwgMTEpO1xufTtcblxudmFyIHBhcnNlTnVtZXJpYyA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIHZhciBzaWduID0gcGFyc2VCaXRzKHZhbHVlLCAxNiwgMzIpO1xuICBpZiAoc2lnbiA9PSAweGMwMDApIHtcbiAgICByZXR1cm4gTmFOO1xuICB9XG5cbiAgdmFyIHdlaWdodCA9IE1hdGgucG93KDEwMDAwLCBwYXJzZUJpdHModmFsdWUsIDE2LCAxNikpO1xuICB2YXIgcmVzdWx0ID0gMDtcblxuICB2YXIgZGlnaXRzID0gW107XG4gIHZhciBuZGlnaXRzID0gcGFyc2VCaXRzKHZhbHVlLCAxNik7XG4gIGZvciAodmFyIGkgPSAwOyBpIDwgbmRpZ2l0czsgaSsrKSB7XG4gICAgcmVzdWx0ICs9IHBhcnNlQml0cyh2YWx1ZSwgMTYsIDY0ICsgKDE2ICogaSkpICogd2VpZ2h0O1xuICAgIHdlaWdodCAvPSAxMDAwMDtcbiAgfVxuXG4gIHZhciBzY2FsZSA9IE1hdGgucG93KDEwLCBwYXJzZUJpdHModmFsdWUsIDE2LCA0OCkpO1xuICByZXR1cm4gKChzaWduID09PSAwKSA/IDEgOiAtMSkgKiBNYXRoLnJvdW5kKHJlc3VsdCAqIHNjYWxlKSAvIHNjYWxlO1xufTtcblxudmFyIHBhcnNlRGF0ZSA9IGZ1bmN0aW9uKGlzVVRDLCB2YWx1ZSkge1xuICB2YXIgc2lnbiA9IHBhcnNlQml0cyh2YWx1ZSwgMSk7XG4gIHZhciByYXdWYWx1ZSA9IHBhcnNlQml0cyh2YWx1ZSwgNjMsIDEpO1xuXG4gIC8vIGRpc2NhcmQgdXNlY3MgYW5kIHNoaWZ0IGZyb20gMjAwMCB0byAxOTcwXG4gIHZhciByZXN1bHQgPSBuZXcgRGF0ZSgoKChzaWduID09PSAwKSA/IDEgOiAtMSkgKiByYXdWYWx1ZSAvIDEwMDApICsgOTQ2Njg0ODAwMDAwKTtcblxuICBpZiAoIWlzVVRDKSB7XG4gICAgcmVzdWx0LnNldFRpbWUocmVzdWx0LmdldFRpbWUoKSArIHJlc3VsdC5nZXRUaW1lem9uZU9mZnNldCgpICogNjAwMDApO1xuICB9XG5cbiAgLy8gYWRkIG1pY3Jvc2Vjb25kcyB0byB0aGUgZGF0ZVxuICByZXN1bHQudXNlYyA9IHJhd1ZhbHVlICUgMTAwMDtcbiAgcmVzdWx0LmdldE1pY3JvU2Vjb25kcyA9IGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLnVzZWM7XG4gIH07XG4gIHJlc3VsdC5zZXRNaWNyb1NlY29uZHMgPSBmdW5jdGlvbih2YWx1ZSkge1xuICAgIHRoaXMudXNlYyA9IHZhbHVlO1xuICB9O1xuICByZXN1bHQuZ2V0VVRDTWljcm9TZWNvbmRzID0gZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMudXNlYztcbiAgfTtcblxuICByZXR1cm4gcmVzdWx0O1xufTtcblxudmFyIHBhcnNlQXJyYXkgPSBmdW5jdGlvbih2YWx1ZSkge1xuICB2YXIgZGltID0gcGFyc2VCaXRzKHZhbHVlLCAzMik7XG5cbiAgdmFyIGZsYWdzID0gcGFyc2VCaXRzKHZhbHVlLCAzMiwgMzIpO1xuICB2YXIgZWxlbWVudFR5cGUgPSBwYXJzZUJpdHModmFsdWUsIDMyLCA2NCk7XG5cbiAgdmFyIG9mZnNldCA9IDk2O1xuICB2YXIgZGltcyA9IFtdO1xuICBmb3IgKHZhciBpID0gMDsgaSA8IGRpbTsgaSsrKSB7XG4gICAgLy8gcGFyc2UgZGltZW5zaW9uXG4gICAgZGltc1tpXSA9IHBhcnNlQml0cyh2YWx1ZSwgMzIsIG9mZnNldCk7XG4gICAgb2Zmc2V0ICs9IDMyO1xuXG4gICAgLy8gaWdub3JlIGxvd2VyIGJvdW5kc1xuICAgIG9mZnNldCArPSAzMjtcbiAgfVxuXG4gIHZhciBwYXJzZUVsZW1lbnQgPSBmdW5jdGlvbihlbGVtZW50VHlwZSkge1xuICAgIC8vIHBhcnNlIGNvbnRlbnQgbGVuZ3RoXG4gICAgdmFyIGxlbmd0aCA9IHBhcnNlQml0cyh2YWx1ZSwgMzIsIG9mZnNldCk7XG4gICAgb2Zmc2V0ICs9IDMyO1xuXG4gICAgLy8gcGFyc2UgbnVsbCB2YWx1ZXNcbiAgICBpZiAobGVuZ3RoID09IDB4ZmZmZmZmZmYpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIHZhciByZXN1bHQ7XG4gICAgaWYgKChlbGVtZW50VHlwZSA9PSAweDE3KSB8fCAoZWxlbWVudFR5cGUgPT0gMHgxNCkpIHtcbiAgICAgIC8vIGludC9iaWdpbnRcbiAgICAgIHJlc3VsdCA9IHBhcnNlQml0cyh2YWx1ZSwgbGVuZ3RoICogOCwgb2Zmc2V0KTtcbiAgICAgIG9mZnNldCArPSBsZW5ndGggKiA4O1xuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgZWxzZSBpZiAoZWxlbWVudFR5cGUgPT0gMHgxOSkge1xuICAgICAgLy8gc3RyaW5nXG4gICAgICByZXN1bHQgPSB2YWx1ZS50b1N0cmluZyh0aGlzLmVuY29kaW5nLCBvZmZzZXQgPj4gMywgKG9mZnNldCArPSAobGVuZ3RoIDw8IDMpKSA+PiAzKTtcbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgY29uc29sZS5sb2coXCJFUlJPUjogRWxlbWVudFR5cGUgbm90IGltcGxlbWVudGVkOiBcIiArIGVsZW1lbnRUeXBlKTtcbiAgICB9XG4gIH07XG5cbiAgdmFyIHBhcnNlID0gZnVuY3Rpb24oZGltZW5zaW9uLCBlbGVtZW50VHlwZSkge1xuICAgIHZhciBhcnJheSA9IFtdO1xuICAgIHZhciBpO1xuXG4gICAgaWYgKGRpbWVuc2lvbi5sZW5ndGggPiAxKSB7XG4gICAgICB2YXIgY291bnQgPSBkaW1lbnNpb24uc2hpZnQoKTtcbiAgICAgIGZvciAoaSA9IDA7IGkgPCBjb3VudDsgaSsrKSB7XG4gICAgICAgIGFycmF5W2ldID0gcGFyc2UoZGltZW5zaW9uLCBlbGVtZW50VHlwZSk7XG4gICAgICB9XG4gICAgICBkaW1lbnNpb24udW5zaGlmdChjb3VudCk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgZm9yIChpID0gMDsgaSA8IGRpbWVuc2lvblswXTsgaSsrKSB7XG4gICAgICAgIGFycmF5W2ldID0gcGFyc2VFbGVtZW50KGVsZW1lbnRUeXBlKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gYXJyYXk7XG4gIH07XG5cbiAgcmV0dXJuIHBhcnNlKGRpbXMsIGVsZW1lbnRUeXBlKTtcbn07XG5cbnZhciBwYXJzZVRleHQgPSBmdW5jdGlvbih2YWx1ZSkge1xuICByZXR1cm4gdmFsdWUudG9TdHJpbmcoJ3V0ZjgnKTtcbn07XG5cbnZhciBwYXJzZUJvb2wgPSBmdW5jdGlvbih2YWx1ZSkge1xuICBpZih2YWx1ZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gIHJldHVybiAocGFyc2VCaXRzKHZhbHVlLCA4KSA+IDApO1xufTtcblxudmFyIGluaXQgPSBmdW5jdGlvbihyZWdpc3Rlcikge1xuICByZWdpc3RlcigyMCwgcGFyc2VJbnQ2NCk7XG4gIHJlZ2lzdGVyKDIxLCBwYXJzZUludDE2KTtcbiAgcmVnaXN0ZXIoMjMsIHBhcnNlSW50MzIpO1xuICByZWdpc3RlcigyNiwgcGFyc2VJbnQzMik7XG4gIHJlZ2lzdGVyKDE3MDAsIHBhcnNlTnVtZXJpYyk7XG4gIHJlZ2lzdGVyKDcwMCwgcGFyc2VGbG9hdDMyKTtcbiAgcmVnaXN0ZXIoNzAxLCBwYXJzZUZsb2F0NjQpO1xuICByZWdpc3RlcigxNiwgcGFyc2VCb29sKTtcbiAgcmVnaXN0ZXIoMTExNCwgcGFyc2VEYXRlLmJpbmQobnVsbCwgZmFsc2UpKTtcbiAgcmVnaXN0ZXIoMTE4NCwgcGFyc2VEYXRlLmJpbmQobnVsbCwgdHJ1ZSkpO1xuICByZWdpc3RlcigxMDAwLCBwYXJzZUFycmF5KTtcbiAgcmVnaXN0ZXIoMTAwNywgcGFyc2VBcnJheSk7XG4gIHJlZ2lzdGVyKDEwMTYsIHBhcnNlQXJyYXkpO1xuICByZWdpc3RlcigxMDA4LCBwYXJzZUFycmF5KTtcbiAgcmVnaXN0ZXIoMTAwOSwgcGFyc2VBcnJheSk7XG4gIHJlZ2lzdGVyKDI1LCBwYXJzZVRleHQpO1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gIGluaXQ6IGluaXRcbn07XG4iLCIvKipcbiAqIEZvbGxvd2luZyBxdWVyeSB3YXMgdXNlZCB0byBnZW5lcmF0ZSB0aGlzIGZpbGU6XG5cbiBTRUxFQ1QganNvbl9vYmplY3RfYWdnKFVQUEVSKFBULnR5cG5hbWUpLCBQVC5vaWQ6OmludDQgT1JERVIgQlkgcHQub2lkKVxuIEZST00gcGdfdHlwZSBQVFxuIFdIRVJFIHR5cG5hbWVzcGFjZSA9IChTRUxFQ1QgcGduLm9pZCBGUk9NIHBnX25hbWVzcGFjZSBwZ24gV0hFUkUgbnNwbmFtZSA9ICdwZ19jYXRhbG9nJykgLS0gVGFrZSBvbmx5IGJ1aWx0aW5nIFBvc3RncmVzIHR5cGVzIHdpdGggc3RhYmxlIE9JRCAoZXh0ZW5zaW9uIHR5cGVzIGFyZSBub3QgZ3VhcmFudGVkIHRvIGJlIHN0YWJsZSlcbiBBTkQgdHlwdHlwZSA9ICdiJyAtLSBPbmx5IGJhc2ljIHR5cGVzXG4gQU5EIHR5cGVsZW0gPSAwIC0tIElnbm9yZSBhbGlhc2VzXG4gQU5EIHR5cGlzZGVmaW5lZCAtLSBJZ25vcmUgdW5kZWZpbmVkIHR5cGVzXG4gKi9cblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gICAgQk9PTDogMTYsXG4gICAgQllURUE6IDE3LFxuICAgIENIQVI6IDE4LFxuICAgIElOVDg6IDIwLFxuICAgIElOVDI6IDIxLFxuICAgIElOVDQ6IDIzLFxuICAgIFJFR1BST0M6IDI0LFxuICAgIFRFWFQ6IDI1LFxuICAgIE9JRDogMjYsXG4gICAgVElEOiAyNyxcbiAgICBYSUQ6IDI4LFxuICAgIENJRDogMjksXG4gICAgSlNPTjogMTE0LFxuICAgIFhNTDogMTQyLFxuICAgIFBHX05PREVfVFJFRTogMTk0LFxuICAgIFNNR1I6IDIxMCxcbiAgICBQQVRIOiA2MDIsXG4gICAgUE9MWUdPTjogNjA0LFxuICAgIENJRFI6IDY1MCxcbiAgICBGTE9BVDQ6IDcwMCxcbiAgICBGTE9BVDg6IDcwMSxcbiAgICBBQlNUSU1FOiA3MDIsXG4gICAgUkVMVElNRTogNzAzLFxuICAgIFRJTlRFUlZBTDogNzA0LFxuICAgIENJUkNMRTogNzE4LFxuICAgIE1BQ0FERFI4OiA3NzQsXG4gICAgTU9ORVk6IDc5MCxcbiAgICBNQUNBRERSOiA4MjksXG4gICAgSU5FVDogODY5LFxuICAgIEFDTElURU06IDEwMzMsXG4gICAgQlBDSEFSOiAxMDQyLFxuICAgIFZBUkNIQVI6IDEwNDMsXG4gICAgREFURTogMTA4MixcbiAgICBUSU1FOiAxMDgzLFxuICAgIFRJTUVTVEFNUDogMTExNCxcbiAgICBUSU1FU1RBTVBUWjogMTE4NCxcbiAgICBJTlRFUlZBTDogMTE4NixcbiAgICBUSU1FVFo6IDEyNjYsXG4gICAgQklUOiAxNTYwLFxuICAgIFZBUkJJVDogMTU2MixcbiAgICBOVU1FUklDOiAxNzAwLFxuICAgIFJFRkNVUlNPUjogMTc5MCxcbiAgICBSRUdQUk9DRURVUkU6IDIyMDIsXG4gICAgUkVHT1BFUjogMjIwMyxcbiAgICBSRUdPUEVSQVRPUjogMjIwNCxcbiAgICBSRUdDTEFTUzogMjIwNSxcbiAgICBSRUdUWVBFOiAyMjA2LFxuICAgIFVVSUQ6IDI5NTAsXG4gICAgVFhJRF9TTkFQU0hPVDogMjk3MCxcbiAgICBQR19MU046IDMyMjAsXG4gICAgUEdfTkRJU1RJTkNUOiAzMzYxLFxuICAgIFBHX0RFUEVOREVOQ0lFUzogMzQwMixcbiAgICBUU1ZFQ1RPUjogMzYxNCxcbiAgICBUU1FVRVJZOiAzNjE1LFxuICAgIEdUU1ZFQ1RPUjogMzY0MixcbiAgICBSRUdDT05GSUc6IDM3MzQsXG4gICAgUkVHRElDVElPTkFSWTogMzc2OSxcbiAgICBKU09OQjogMzgwMixcbiAgICBSRUdOQU1FU1BBQ0U6IDQwODksXG4gICAgUkVHUk9MRTogNDA5NlxufTtcbiIsInZhciBhcnJheSA9IHJlcXVpcmUoJ3Bvc3RncmVzLWFycmF5JylcbnZhciBhcnJheVBhcnNlciA9IHJlcXVpcmUoJy4vYXJyYXlQYXJzZXInKTtcbnZhciBwYXJzZURhdGUgPSByZXF1aXJlKCdwb3N0Z3Jlcy1kYXRlJyk7XG52YXIgcGFyc2VJbnRlcnZhbCA9IHJlcXVpcmUoJ3Bvc3RncmVzLWludGVydmFsJyk7XG52YXIgcGFyc2VCeXRlQSA9IHJlcXVpcmUoJ3Bvc3RncmVzLWJ5dGVhJyk7XG5cbmZ1bmN0aW9uIGFsbG93TnVsbCAoZm4pIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIG51bGxBbGxvd2VkICh2YWx1ZSkge1xuICAgIGlmICh2YWx1ZSA9PT0gbnVsbCkgcmV0dXJuIHZhbHVlXG4gICAgcmV0dXJuIGZuKHZhbHVlKVxuICB9XG59XG5cbmZ1bmN0aW9uIHBhcnNlQm9vbCAodmFsdWUpIHtcbiAgaWYgKHZhbHVlID09PSBudWxsKSByZXR1cm4gdmFsdWVcbiAgcmV0dXJuIHZhbHVlID09PSAnVFJVRScgfHxcbiAgICB2YWx1ZSA9PT0gJ3QnIHx8XG4gICAgdmFsdWUgPT09ICd0cnVlJyB8fFxuICAgIHZhbHVlID09PSAneScgfHxcbiAgICB2YWx1ZSA9PT0gJ3llcycgfHxcbiAgICB2YWx1ZSA9PT0gJ29uJyB8fFxuICAgIHZhbHVlID09PSAnMSc7XG59XG5cbmZ1bmN0aW9uIHBhcnNlQm9vbEFycmF5ICh2YWx1ZSkge1xuICBpZiAoIXZhbHVlKSByZXR1cm4gbnVsbFxuICByZXR1cm4gYXJyYXkucGFyc2UodmFsdWUsIHBhcnNlQm9vbClcbn1cblxuZnVuY3Rpb24gcGFyc2VCYXNlVGVuSW50IChzdHJpbmcpIHtcbiAgcmV0dXJuIHBhcnNlSW50KHN0cmluZywgMTApXG59XG5cbmZ1bmN0aW9uIHBhcnNlSW50ZWdlckFycmF5ICh2YWx1ZSkge1xuICBpZiAoIXZhbHVlKSByZXR1cm4gbnVsbFxuICByZXR1cm4gYXJyYXkucGFyc2UodmFsdWUsIGFsbG93TnVsbChwYXJzZUJhc2VUZW5JbnQpKVxufVxuXG5mdW5jdGlvbiBwYXJzZUJpZ0ludGVnZXJBcnJheSAodmFsdWUpIHtcbiAgaWYgKCF2YWx1ZSkgcmV0dXJuIG51bGxcbiAgcmV0dXJuIGFycmF5LnBhcnNlKHZhbHVlLCBhbGxvd051bGwoZnVuY3Rpb24gKGVudHJ5KSB7XG4gICAgcmV0dXJuIHBhcnNlQmlnSW50ZWdlcihlbnRyeSkudHJpbSgpXG4gIH0pKVxufVxuXG52YXIgcGFyc2VQb2ludEFycmF5ID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgaWYoIXZhbHVlKSB7IHJldHVybiBudWxsOyB9XG4gIHZhciBwID0gYXJyYXlQYXJzZXIuY3JlYXRlKHZhbHVlLCBmdW5jdGlvbihlbnRyeSkge1xuICAgIGlmKGVudHJ5ICE9PSBudWxsKSB7XG4gICAgICBlbnRyeSA9IHBhcnNlUG9pbnQoZW50cnkpO1xuICAgIH1cbiAgICByZXR1cm4gZW50cnk7XG4gIH0pO1xuXG4gIHJldHVybiBwLnBhcnNlKCk7XG59O1xuXG52YXIgcGFyc2VGbG9hdEFycmF5ID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgaWYoIXZhbHVlKSB7IHJldHVybiBudWxsOyB9XG4gIHZhciBwID0gYXJyYXlQYXJzZXIuY3JlYXRlKHZhbHVlLCBmdW5jdGlvbihlbnRyeSkge1xuICAgIGlmKGVudHJ5ICE9PSBudWxsKSB7XG4gICAgICBlbnRyeSA9IHBhcnNlRmxvYXQoZW50cnkpO1xuICAgIH1cbiAgICByZXR1cm4gZW50cnk7XG4gIH0pO1xuXG4gIHJldHVybiBwLnBhcnNlKCk7XG59O1xuXG52YXIgcGFyc2VTdHJpbmdBcnJheSA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIGlmKCF2YWx1ZSkgeyByZXR1cm4gbnVsbDsgfVxuXG4gIHZhciBwID0gYXJyYXlQYXJzZXIuY3JlYXRlKHZhbHVlKTtcbiAgcmV0dXJuIHAucGFyc2UoKTtcbn07XG5cbnZhciBwYXJzZURhdGVBcnJheSA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIGlmICghdmFsdWUpIHsgcmV0dXJuIG51bGw7IH1cblxuICB2YXIgcCA9IGFycmF5UGFyc2VyLmNyZWF0ZSh2YWx1ZSwgZnVuY3Rpb24oZW50cnkpIHtcbiAgICBpZiAoZW50cnkgIT09IG51bGwpIHtcbiAgICAgIGVudHJ5ID0gcGFyc2VEYXRlKGVudHJ5KTtcbiAgICB9XG4gICAgcmV0dXJuIGVudHJ5O1xuICB9KTtcblxuICByZXR1cm4gcC5wYXJzZSgpO1xufTtcblxudmFyIHBhcnNlSW50ZXJ2YWxBcnJheSA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIGlmICghdmFsdWUpIHsgcmV0dXJuIG51bGw7IH1cblxuICB2YXIgcCA9IGFycmF5UGFyc2VyLmNyZWF0ZSh2YWx1ZSwgZnVuY3Rpb24oZW50cnkpIHtcbiAgICBpZiAoZW50cnkgIT09IG51bGwpIHtcbiAgICAgIGVudHJ5ID0gcGFyc2VJbnRlcnZhbChlbnRyeSk7XG4gICAgfVxuICAgIHJldHVybiBlbnRyeTtcbiAgfSk7XG5cbiAgcmV0dXJuIHAucGFyc2UoKTtcbn07XG5cbnZhciBwYXJzZUJ5dGVBQXJyYXkgPSBmdW5jdGlvbih2YWx1ZSkge1xuICBpZiAoIXZhbHVlKSB7IHJldHVybiBudWxsOyB9XG5cbiAgcmV0dXJuIGFycmF5LnBhcnNlKHZhbHVlLCBhbGxvd051bGwocGFyc2VCeXRlQSkpO1xufTtcblxudmFyIHBhcnNlSW50ZWdlciA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIHJldHVybiBwYXJzZUludCh2YWx1ZSwgMTApO1xufTtcblxudmFyIHBhcnNlQmlnSW50ZWdlciA9IGZ1bmN0aW9uKHZhbHVlKSB7XG4gIHZhciB2YWxTdHIgPSBTdHJpbmcodmFsdWUpO1xuICBpZiAoL15cXGQrJC8udGVzdCh2YWxTdHIpKSB7IHJldHVybiB2YWxTdHI7IH1cbiAgcmV0dXJuIHZhbHVlO1xufTtcblxudmFyIHBhcnNlSnNvbkFycmF5ID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgaWYgKCF2YWx1ZSkgeyByZXR1cm4gbnVsbDsgfVxuXG4gIHJldHVybiBhcnJheS5wYXJzZSh2YWx1ZSwgYWxsb3dOdWxsKEpTT04ucGFyc2UpKTtcbn07XG5cbnZhciBwYXJzZVBvaW50ID0gZnVuY3Rpb24odmFsdWUpIHtcbiAgaWYgKHZhbHVlWzBdICE9PSAnKCcpIHsgcmV0dXJuIG51bGw7IH1cblxuICB2YWx1ZSA9IHZhbHVlLnN1YnN0cmluZyggMSwgdmFsdWUubGVuZ3RoIC0gMSApLnNwbGl0KCcsJyk7XG5cbiAgcmV0dXJuIHtcbiAgICB4OiBwYXJzZUZsb2F0KHZhbHVlWzBdKVxuICAsIHk6IHBhcnNlRmxvYXQodmFsdWVbMV0pXG4gIH07XG59O1xuXG52YXIgcGFyc2VDaXJjbGUgPSBmdW5jdGlvbih2YWx1ZSkge1xuICBpZiAodmFsdWVbMF0gIT09ICc8JyAmJiB2YWx1ZVsxXSAhPT0gJygnKSB7IHJldHVybiBudWxsOyB9XG5cbiAgdmFyIHBvaW50ID0gJygnO1xuICB2YXIgcmFkaXVzID0gJyc7XG4gIHZhciBwb2ludFBhcnNlZCA9IGZhbHNlO1xuICBmb3IgKHZhciBpID0gMjsgaSA8IHZhbHVlLmxlbmd0aCAtIDE7IGkrKyl7XG4gICAgaWYgKCFwb2ludFBhcnNlZCkge1xuICAgICAgcG9pbnQgKz0gdmFsdWVbaV07XG4gICAgfVxuXG4gICAgaWYgKHZhbHVlW2ldID09PSAnKScpIHtcbiAgICAgIHBvaW50UGFyc2VkID0gdHJ1ZTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH0gZWxzZSBpZiAoIXBvaW50UGFyc2VkKSB7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG5cbiAgICBpZiAodmFsdWVbaV0gPT09ICcsJyl7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG5cbiAgICByYWRpdXMgKz0gdmFsdWVbaV07XG4gIH1cbiAgdmFyIHJlc3VsdCA9IHBhcnNlUG9pbnQocG9pbnQpO1xuICByZXN1bHQucmFkaXVzID0gcGFyc2VGbG9hdChyYWRpdXMpO1xuXG4gIHJldHVybiByZXN1bHQ7XG59O1xuXG52YXIgaW5pdCA9IGZ1bmN0aW9uKHJlZ2lzdGVyKSB7XG4gIHJlZ2lzdGVyKDIwLCBwYXJzZUJpZ0ludGVnZXIpOyAvLyBpbnQ4XG4gIHJlZ2lzdGVyKDIxLCBwYXJzZUludGVnZXIpOyAvLyBpbnQyXG4gIHJlZ2lzdGVyKDIzLCBwYXJzZUludGVnZXIpOyAvLyBpbnQ0XG4gIHJlZ2lzdGVyKDI2LCBwYXJzZUludGVnZXIpOyAvLyBvaWRcbiAgcmVnaXN0ZXIoNzAwLCBwYXJzZUZsb2F0KTsgLy8gZmxvYXQ0L3JlYWxcbiAgcmVnaXN0ZXIoNzAxLCBwYXJzZUZsb2F0KTsgLy8gZmxvYXQ4L2RvdWJsZVxuICByZWdpc3RlcigxNiwgcGFyc2VCb29sKTtcbiAgcmVnaXN0ZXIoMTA4MiwgcGFyc2VEYXRlKTsgLy8gZGF0ZVxuICByZWdpc3RlcigxMTE0LCBwYXJzZURhdGUpOyAvLyB0aW1lc3RhbXAgd2l0aG91dCB0aW1lem9uZVxuICByZWdpc3RlcigxMTg0LCBwYXJzZURhdGUpOyAvLyB0aW1lc3RhbXBcbiAgcmVnaXN0ZXIoNjAwLCBwYXJzZVBvaW50KTsgLy8gcG9pbnRcbiAgcmVnaXN0ZXIoNjUxLCBwYXJzZVN0cmluZ0FycmF5KTsgLy8gY2lkcltdXG4gIHJlZ2lzdGVyKDcxOCwgcGFyc2VDaXJjbGUpOyAvLyBjaXJjbGVcbiAgcmVnaXN0ZXIoMTAwMCwgcGFyc2VCb29sQXJyYXkpO1xuICByZWdpc3RlcigxMDAxLCBwYXJzZUJ5dGVBQXJyYXkpO1xuICByZWdpc3RlcigxMDA1LCBwYXJzZUludGVnZXJBcnJheSk7IC8vIF9pbnQyXG4gIHJlZ2lzdGVyKDEwMDcsIHBhcnNlSW50ZWdlckFycmF5KTsgLy8gX2ludDRcbiAgcmVnaXN0ZXIoMTAyOCwgcGFyc2VJbnRlZ2VyQXJyYXkpOyAvLyBvaWRbXVxuICByZWdpc3RlcigxMDE2LCBwYXJzZUJpZ0ludGVnZXJBcnJheSk7IC8vIF9pbnQ4XG4gIHJlZ2lzdGVyKDEwMTcsIHBhcnNlUG9pbnRBcnJheSk7IC8vIHBvaW50W11cbiAgcmVnaXN0ZXIoMTAyMSwgcGFyc2VGbG9hdEFycmF5KTsgLy8gX2Zsb2F0NFxuICByZWdpc3RlcigxMDIyLCBwYXJzZUZsb2F0QXJyYXkpOyAvLyBfZmxvYXQ4XG4gIHJlZ2lzdGVyKDEyMzEsIHBhcnNlRmxvYXRBcnJheSk7IC8vIF9udW1lcmljXG4gIHJlZ2lzdGVyKDEwMTQsIHBhcnNlU3RyaW5nQXJyYXkpOyAvL2NoYXJcbiAgcmVnaXN0ZXIoMTAxNSwgcGFyc2VTdHJpbmdBcnJheSk7IC8vdmFyY2hhclxuICByZWdpc3RlcigxMDA4LCBwYXJzZVN0cmluZ0FycmF5KTtcbiAgcmVnaXN0ZXIoMTAwOSwgcGFyc2VTdHJpbmdBcnJheSk7XG4gIHJlZ2lzdGVyKDEwNDAsIHBhcnNlU3RyaW5nQXJyYXkpOyAvLyBtYWNhZGRyW11cbiAgcmVnaXN0ZXIoMTA0MSwgcGFyc2VTdHJpbmdBcnJheSk7IC8vIGluZXRbXVxuICByZWdpc3RlcigxMTE1LCBwYXJzZURhdGVBcnJheSk7IC8vIHRpbWVzdGFtcCB3aXRob3V0IHRpbWUgem9uZVtdXG4gIHJlZ2lzdGVyKDExODIsIHBhcnNlRGF0ZUFycmF5KTsgLy8gX2RhdGVcbiAgcmVnaXN0ZXIoMTE4NSwgcGFyc2VEYXRlQXJyYXkpOyAvLyB0aW1lc3RhbXAgd2l0aCB0aW1lIHpvbmVbXVxuICByZWdpc3RlcigxMTg2LCBwYXJzZUludGVydmFsKTtcbiAgcmVnaXN0ZXIoMTE4NywgcGFyc2VJbnRlcnZhbEFycmF5KTtcbiAgcmVnaXN0ZXIoMTcsIHBhcnNlQnl0ZUEpO1xuICByZWdpc3RlcigxMTQsIEpTT04ucGFyc2UuYmluZChKU09OKSk7IC8vIGpzb25cbiAgcmVnaXN0ZXIoMzgwMiwgSlNPTi5wYXJzZS5iaW5kKEpTT04pKTsgLy8ganNvbmJcbiAgcmVnaXN0ZXIoMTk5LCBwYXJzZUpzb25BcnJheSk7IC8vIGpzb25bXVxuICByZWdpc3RlcigzODA3LCBwYXJzZUpzb25BcnJheSk7IC8vIGpzb25iW11cbiAgcmVnaXN0ZXIoMzkwNywgcGFyc2VTdHJpbmdBcnJheSk7IC8vIG51bXJhbmdlW11cbiAgcmVnaXN0ZXIoMjk1MSwgcGFyc2VTdHJpbmdBcnJheSk7IC8vIHV1aWRbXVxuICByZWdpc3Rlcig3OTEsIHBhcnNlU3RyaW5nQXJyYXkpOyAvLyBtb25leVtdXG4gIHJlZ2lzdGVyKDExODMsIHBhcnNlU3RyaW5nQXJyYXkpOyAvLyB0aW1lW11cbiAgcmVnaXN0ZXIoMTI3MCwgcGFyc2VTdHJpbmdBcnJheSk7IC8vIHRpbWV0eltdXG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgaW5pdDogaW5pdFxufTtcbiIsIid1c2Ugc3RyaWN0J1xuXG52YXIgRXZlbnRFbWl0dGVyID0gcmVxdWlyZSgnZXZlbnRzJykuRXZlbnRFbWl0dGVyXG52YXIgdXRpbCA9IHJlcXVpcmUoJ3V0aWwnKVxudmFyIHV0aWxzID0gcmVxdWlyZSgnLi91dGlscycpXG52YXIgc2FzbCA9IHJlcXVpcmUoJy4vc2FzbCcpXG52YXIgcGdQYXNzID0gcmVxdWlyZSgncGdwYXNzJylcbnZhciBUeXBlT3ZlcnJpZGVzID0gcmVxdWlyZSgnLi90eXBlLW92ZXJyaWRlcycpXG5cbnZhciBDb25uZWN0aW9uUGFyYW1ldGVycyA9IHJlcXVpcmUoJy4vY29ubmVjdGlvbi1wYXJhbWV0ZXJzJylcbnZhciBRdWVyeSA9IHJlcXVpcmUoJy4vcXVlcnknKVxudmFyIGRlZmF1bHRzID0gcmVxdWlyZSgnLi9kZWZhdWx0cycpXG52YXIgQ29ubmVjdGlvbiA9IHJlcXVpcmUoJy4vY29ubmVjdGlvbicpXG5cbmNsYXNzIENsaWVudCBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIGNvbnN0cnVjdG9yKGNvbmZpZykge1xuICAgIHN1cGVyKClcblxuICAgIHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMgPSBuZXcgQ29ubmVjdGlvblBhcmFtZXRlcnMoY29uZmlnKVxuICAgIHRoaXMudXNlciA9IHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMudXNlclxuICAgIHRoaXMuZGF0YWJhc2UgPSB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLmRhdGFiYXNlXG4gICAgdGhpcy5wb3J0ID0gdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy5wb3J0XG4gICAgdGhpcy5ob3N0ID0gdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy5ob3N0XG5cbiAgICAvLyBcImhpZGluZ1wiIHRoZSBwYXNzd29yZCBzbyBpdCBkb2Vzbid0IHNob3cgdXAgaW4gc3RhY2sgdHJhY2VzXG4gICAgLy8gb3IgaWYgdGhlIGNsaWVudCBpcyBjb25zb2xlLmxvZ2dlZFxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCAncGFzc3dvcmQnLCB7XG4gICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgdmFsdWU6IHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMucGFzc3dvcmQsXG4gICAgfSlcblxuICAgIHRoaXMucmVwbGljYXRpb24gPSB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLnJlcGxpY2F0aW9uXG5cbiAgICB2YXIgYyA9IGNvbmZpZyB8fCB7fVxuXG4gICAgdGhpcy5fUHJvbWlzZSA9IGMuUHJvbWlzZSB8fCBnbG9iYWwuUHJvbWlzZVxuICAgIHRoaXMuX3R5cGVzID0gbmV3IFR5cGVPdmVycmlkZXMoYy50eXBlcylcbiAgICB0aGlzLl9lbmRpbmcgPSBmYWxzZVxuICAgIHRoaXMuX2Nvbm5lY3RpbmcgPSBmYWxzZVxuICAgIHRoaXMuX2Nvbm5lY3RlZCA9IGZhbHNlXG4gICAgdGhpcy5fY29ubmVjdGlvbkVycm9yID0gZmFsc2VcbiAgICB0aGlzLl9xdWVyeWFibGUgPSB0cnVlXG5cbiAgICB0aGlzLmNvbm5lY3Rpb24gPVxuICAgICAgYy5jb25uZWN0aW9uIHx8XG4gICAgICBuZXcgQ29ubmVjdGlvbih7XG4gICAgICAgIHN0cmVhbTogYy5zdHJlYW0sXG4gICAgICAgIHNzbDogdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy5zc2wsXG4gICAgICAgIGtlZXBBbGl2ZTogYy5rZWVwQWxpdmUgfHwgZmFsc2UsXG4gICAgICAgIGtlZXBBbGl2ZUluaXRpYWxEZWxheU1pbGxpczogYy5rZWVwQWxpdmVJbml0aWFsRGVsYXlNaWxsaXMgfHwgMCxcbiAgICAgICAgZW5jb2Rpbmc6IHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMuY2xpZW50X2VuY29kaW5nIHx8ICd1dGY4JyxcbiAgICAgIH0pXG4gICAgdGhpcy5xdWVyeVF1ZXVlID0gW11cbiAgICB0aGlzLmJpbmFyeSA9IGMuYmluYXJ5IHx8IGRlZmF1bHRzLmJpbmFyeVxuICAgIHRoaXMucHJvY2Vzc0lEID0gbnVsbFxuICAgIHRoaXMuc2VjcmV0S2V5ID0gbnVsbFxuICAgIHRoaXMuc3NsID0gdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy5zc2wgfHwgZmFsc2VcbiAgICAvLyBBcyB3aXRoIFBhc3N3b3JkLCBtYWtlIFNTTC0+S2V5ICh0aGUgcHJpdmF0ZSBrZXkpIG5vbi1lbnVtZXJhYmxlLlxuICAgIC8vIEl0IHdvbid0IHNob3cgdXAgaW4gc3RhY2sgdHJhY2VzXG4gICAgLy8gb3IgaWYgdGhlIGNsaWVudCBpcyBjb25zb2xlLmxvZ2dlZFxuICAgIGlmICh0aGlzLnNzbCAmJiB0aGlzLnNzbC5rZXkpIHtcbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLnNzbCwgJ2tleScsIHtcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICB9KVxuICAgIH1cblxuICAgIHRoaXMuX2Nvbm5lY3Rpb25UaW1lb3V0TWlsbGlzID0gYy5jb25uZWN0aW9uVGltZW91dE1pbGxpcyB8fCAwXG4gIH1cblxuICBfZXJyb3JBbGxRdWVyaWVzKGVycikge1xuICAgIGNvbnN0IGVucXVldWVFcnJvciA9IChxdWVyeSkgPT4ge1xuICAgICAgcHJvY2Vzcy5uZXh0VGljaygoKSA9PiB7XG4gICAgICAgIHF1ZXJ5LmhhbmRsZUVycm9yKGVyciwgdGhpcy5jb25uZWN0aW9uKVxuICAgICAgfSlcbiAgICB9XG5cbiAgICBpZiAodGhpcy5hY3RpdmVRdWVyeSkge1xuICAgICAgZW5xdWV1ZUVycm9yKHRoaXMuYWN0aXZlUXVlcnkpXG4gICAgICB0aGlzLmFjdGl2ZVF1ZXJ5ID0gbnVsbFxuICAgIH1cblxuICAgIHRoaXMucXVlcnlRdWV1ZS5mb3JFYWNoKGVucXVldWVFcnJvcilcbiAgICB0aGlzLnF1ZXJ5UXVldWUubGVuZ3RoID0gMFxuICB9XG5cbiAgX2Nvbm5lY3QoY2FsbGJhY2spIHtcbiAgICB2YXIgc2VsZiA9IHRoaXNcbiAgICB2YXIgY29uID0gdGhpcy5jb25uZWN0aW9uXG4gICAgdGhpcy5fY29ubmVjdGlvbkNhbGxiYWNrID0gY2FsbGJhY2tcblxuICAgIGlmICh0aGlzLl9jb25uZWN0aW5nIHx8IHRoaXMuX2Nvbm5lY3RlZCkge1xuICAgICAgY29uc3QgZXJyID0gbmV3IEVycm9yKCdDbGllbnQgaGFzIGFscmVhZHkgYmVlbiBjb25uZWN0ZWQuIFlvdSBjYW5ub3QgcmV1c2UgYSBjbGllbnQuJylcbiAgICAgIHByb2Nlc3MubmV4dFRpY2soKCkgPT4ge1xuICAgICAgICBjYWxsYmFjayhlcnIpXG4gICAgICB9KVxuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIHRoaXMuX2Nvbm5lY3RpbmcgPSB0cnVlXG5cbiAgICB0aGlzLmNvbm5lY3Rpb25UaW1lb3V0SGFuZGxlXG4gICAgaWYgKHRoaXMuX2Nvbm5lY3Rpb25UaW1lb3V0TWlsbGlzID4gMCkge1xuICAgICAgdGhpcy5jb25uZWN0aW9uVGltZW91dEhhbmRsZSA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBjb24uX2VuZGluZyA9IHRydWVcbiAgICAgICAgY29uLnN0cmVhbS5kZXN0cm95KG5ldyBFcnJvcigndGltZW91dCBleHBpcmVkJykpXG4gICAgICB9LCB0aGlzLl9jb25uZWN0aW9uVGltZW91dE1pbGxpcylcbiAgICB9XG5cbiAgICBpZiAodGhpcy5ob3N0ICYmIHRoaXMuaG9zdC5pbmRleE9mKCcvJykgPT09IDApIHtcbiAgICAgIGNvbi5jb25uZWN0KHRoaXMuaG9zdCArICcvLnMuUEdTUUwuJyArIHRoaXMucG9ydClcbiAgICB9IGVsc2Uge1xuICAgICAgY29uLmNvbm5lY3QodGhpcy5wb3J0LCB0aGlzLmhvc3QpXG4gICAgfVxuXG4gICAgLy8gb25jZSBjb25uZWN0aW9uIGlzIGVzdGFibGlzaGVkIHNlbmQgc3RhcnR1cCBtZXNzYWdlXG4gICAgY29uLm9uKCdjb25uZWN0JywgZnVuY3Rpb24gKCkge1xuICAgICAgaWYgKHNlbGYuc3NsKSB7XG4gICAgICAgIGNvbi5yZXF1ZXN0U3NsKClcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbi5zdGFydHVwKHNlbGYuZ2V0U3RhcnR1cENvbmYoKSlcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgY29uLm9uKCdzc2xjb25uZWN0JywgZnVuY3Rpb24gKCkge1xuICAgICAgY29uLnN0YXJ0dXAoc2VsZi5nZXRTdGFydHVwQ29uZigpKVxuICAgIH0pXG5cbiAgICB0aGlzLl9hdHRhY2hMaXN0ZW5lcnMoY29uKVxuXG4gICAgY29uLm9uY2UoJ2VuZCcsICgpID0+IHtcbiAgICAgIGNvbnN0IGVycm9yID0gdGhpcy5fZW5kaW5nID8gbmV3IEVycm9yKCdDb25uZWN0aW9uIHRlcm1pbmF0ZWQnKSA6IG5ldyBFcnJvcignQ29ubmVjdGlvbiB0ZXJtaW5hdGVkIHVuZXhwZWN0ZWRseScpXG5cbiAgICAgIGNsZWFyVGltZW91dCh0aGlzLmNvbm5lY3Rpb25UaW1lb3V0SGFuZGxlKVxuICAgICAgdGhpcy5fZXJyb3JBbGxRdWVyaWVzKGVycm9yKVxuXG4gICAgICBpZiAoIXRoaXMuX2VuZGluZykge1xuICAgICAgICAvLyBpZiB0aGUgY29ubmVjdGlvbiBpcyBlbmRlZCB3aXRob3V0IHVzIGNhbGxpbmcgLmVuZCgpXG4gICAgICAgIC8vIG9uIHRoaXMgY2xpZW50IHRoZW4gd2UgaGF2ZSBhbiB1bmV4cGVjdGVkIGRpc2Nvbm5lY3Rpb25cbiAgICAgICAgLy8gdHJlYXQgdGhpcyBhcyBhbiBlcnJvciB1bmxlc3Mgd2UndmUgYWxyZWFkeSBlbWl0dGVkIGFuIGVycm9yXG4gICAgICAgIC8vIGR1cmluZyBjb25uZWN0aW9uLlxuICAgICAgICBpZiAodGhpcy5fY29ubmVjdGluZyAmJiAhdGhpcy5fY29ubmVjdGlvbkVycm9yKSB7XG4gICAgICAgICAgaWYgKHRoaXMuX2Nvbm5lY3Rpb25DYWxsYmFjaykge1xuICAgICAgICAgICAgdGhpcy5fY29ubmVjdGlvbkNhbGxiYWNrKGVycm9yKVxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLl9oYW5kbGVFcnJvckV2ZW50KGVycm9yKVxuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmICghdGhpcy5fY29ubmVjdGlvbkVycm9yKSB7XG4gICAgICAgICAgdGhpcy5faGFuZGxlRXJyb3JFdmVudChlcnJvcilcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBwcm9jZXNzLm5leHRUaWNrKCgpID0+IHtcbiAgICAgICAgdGhpcy5lbWl0KCdlbmQnKVxuICAgICAgfSlcbiAgICB9KVxuICB9XG5cbiAgY29ubmVjdChjYWxsYmFjaykge1xuICAgIGlmIChjYWxsYmFjaykge1xuICAgICAgdGhpcy5fY29ubmVjdChjYWxsYmFjaylcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIHJldHVybiBuZXcgdGhpcy5fUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICB0aGlzLl9jb25uZWN0KChlcnJvcikgPT4ge1xuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICByZWplY3QoZXJyb3IpXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmVzb2x2ZSgpXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfSlcbiAgfVxuXG4gIF9hdHRhY2hMaXN0ZW5lcnMoY29uKSB7XG4gICAgLy8gcGFzc3dvcmQgcmVxdWVzdCBoYW5kbGluZ1xuICAgIGNvbi5vbignYXV0aGVudGljYXRpb25DbGVhcnRleHRQYXNzd29yZCcsIHRoaXMuX2hhbmRsZUF1dGhDbGVhcnRleHRQYXNzd29yZC5iaW5kKHRoaXMpKVxuICAgIC8vIHBhc3N3b3JkIHJlcXVlc3QgaGFuZGxpbmdcbiAgICBjb24ub24oJ2F1dGhlbnRpY2F0aW9uTUQ1UGFzc3dvcmQnLCB0aGlzLl9oYW5kbGVBdXRoTUQ1UGFzc3dvcmQuYmluZCh0aGlzKSlcbiAgICAvLyBwYXNzd29yZCByZXF1ZXN0IGhhbmRsaW5nIChTQVNMKVxuICAgIGNvbi5vbignYXV0aGVudGljYXRpb25TQVNMJywgdGhpcy5faGFuZGxlQXV0aFNBU0wuYmluZCh0aGlzKSlcbiAgICBjb24ub24oJ2F1dGhlbnRpY2F0aW9uU0FTTENvbnRpbnVlJywgdGhpcy5faGFuZGxlQXV0aFNBU0xDb250aW51ZS5iaW5kKHRoaXMpKVxuICAgIGNvbi5vbignYXV0aGVudGljYXRpb25TQVNMRmluYWwnLCB0aGlzLl9oYW5kbGVBdXRoU0FTTEZpbmFsLmJpbmQodGhpcykpXG4gICAgY29uLm9uKCdiYWNrZW5kS2V5RGF0YScsIHRoaXMuX2hhbmRsZUJhY2tlbmRLZXlEYXRhLmJpbmQodGhpcykpXG4gICAgY29uLm9uKCdlcnJvcicsIHRoaXMuX2hhbmRsZUVycm9yRXZlbnQuYmluZCh0aGlzKSlcbiAgICBjb24ub24oJ2Vycm9yTWVzc2FnZScsIHRoaXMuX2hhbmRsZUVycm9yTWVzc2FnZS5iaW5kKHRoaXMpKVxuICAgIGNvbi5vbigncmVhZHlGb3JRdWVyeScsIHRoaXMuX2hhbmRsZVJlYWR5Rm9yUXVlcnkuYmluZCh0aGlzKSlcbiAgICBjb24ub24oJ25vdGljZScsIHRoaXMuX2hhbmRsZU5vdGljZS5iaW5kKHRoaXMpKVxuICAgIGNvbi5vbigncm93RGVzY3JpcHRpb24nLCB0aGlzLl9oYW5kbGVSb3dEZXNjcmlwdGlvbi5iaW5kKHRoaXMpKVxuICAgIGNvbi5vbignZGF0YVJvdycsIHRoaXMuX2hhbmRsZURhdGFSb3cuYmluZCh0aGlzKSlcbiAgICBjb24ub24oJ3BvcnRhbFN1c3BlbmRlZCcsIHRoaXMuX2hhbmRsZVBvcnRhbFN1c3BlbmRlZC5iaW5kKHRoaXMpKVxuICAgIGNvbi5vbignZW1wdHlRdWVyeScsIHRoaXMuX2hhbmRsZUVtcHR5UXVlcnkuYmluZCh0aGlzKSlcbiAgICBjb24ub24oJ2NvbW1hbmRDb21wbGV0ZScsIHRoaXMuX2hhbmRsZUNvbW1hbmRDb21wbGV0ZS5iaW5kKHRoaXMpKVxuICAgIGNvbi5vbigncGFyc2VDb21wbGV0ZScsIHRoaXMuX2hhbmRsZVBhcnNlQ29tcGxldGUuYmluZCh0aGlzKSlcbiAgICBjb24ub24oJ2NvcHlJblJlc3BvbnNlJywgdGhpcy5faGFuZGxlQ29weUluUmVzcG9uc2UuYmluZCh0aGlzKSlcbiAgICBjb24ub24oJ2NvcHlEYXRhJywgdGhpcy5faGFuZGxlQ29weURhdGEuYmluZCh0aGlzKSlcbiAgICBjb24ub24oJ25vdGlmaWNhdGlvbicsIHRoaXMuX2hhbmRsZU5vdGlmaWNhdGlvbi5iaW5kKHRoaXMpKVxuICB9XG5cbiAgLy8gVE9ETyhibWMpOiBkZXByZWNhdGUgcGdwYXNzIFwiYnVpbHQgaW5cIiBpbnRlZ3JhdGlvbiBzaW5jZSB0aGlzLnBhc3N3b3JkIGNhbiBiZSBhIGZ1bmN0aW9uXG4gIC8vIGl0IGNhbiBiZSBzdXBwbGllZCBieSB0aGUgdXNlciBpZiByZXF1aXJlZCAtIHRoaXMgaXMgYSBicmVha2luZyBjaGFuZ2UhXG4gIF9jaGVja1BnUGFzcyhjYikge1xuICAgIGNvbnN0IGNvbiA9IHRoaXMuY29ubmVjdGlvblxuICAgIGlmICh0eXBlb2YgdGhpcy5wYXNzd29yZCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgdGhpcy5fUHJvbWlzZVxuICAgICAgICAucmVzb2x2ZSgpXG4gICAgICAgIC50aGVuKCgpID0+IHRoaXMucGFzc3dvcmQoKSlcbiAgICAgICAgLnRoZW4oKHBhc3MpID0+IHtcbiAgICAgICAgICBpZiAocGFzcyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIHBhc3MgIT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICAgIGNvbi5lbWl0KCdlcnJvcicsIG5ldyBUeXBlRXJyb3IoJ1Bhc3N3b3JkIG11c3QgYmUgYSBzdHJpbmcnKSlcbiAgICAgICAgICAgICAgcmV0dXJuXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLnBhc3N3b3JkID0gdGhpcy5wYXNzd29yZCA9IHBhc3NcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy5wYXNzd29yZCA9IHRoaXMucGFzc3dvcmQgPSBudWxsXG4gICAgICAgICAgfVxuICAgICAgICAgIGNiKClcbiAgICAgICAgfSlcbiAgICAgICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICBjb24uZW1pdCgnZXJyb3InLCBlcnIpXG4gICAgICAgIH0pXG4gICAgfSBlbHNlIGlmICh0aGlzLnBhc3N3b3JkICE9PSBudWxsKSB7XG4gICAgICBjYigpXG4gICAgfSBlbHNlIHtcbiAgICAgIHBnUGFzcyh0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLCAocGFzcykgPT4ge1xuICAgICAgICBpZiAodW5kZWZpbmVkICE9PSBwYXNzKSB7XG4gICAgICAgICAgdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy5wYXNzd29yZCA9IHRoaXMucGFzc3dvcmQgPSBwYXNzXG4gICAgICAgIH1cbiAgICAgICAgY2IoKVxuICAgICAgfSlcbiAgICB9XG4gIH1cblxuICBfaGFuZGxlQXV0aENsZWFydGV4dFBhc3N3b3JkKG1zZykge1xuICAgIHRoaXMuX2NoZWNrUGdQYXNzKCgpID0+IHtcbiAgICAgIHRoaXMuY29ubmVjdGlvbi5wYXNzd29yZCh0aGlzLnBhc3N3b3JkKVxuICAgIH0pXG4gIH1cblxuICBfaGFuZGxlQXV0aE1ENVBhc3N3b3JkKG1zZykge1xuICAgIHRoaXMuX2NoZWNrUGdQYXNzKCgpID0+IHtcbiAgICAgIGNvbnN0IGhhc2hlZFBhc3N3b3JkID0gdXRpbHMucG9zdGdyZXNNZDVQYXNzd29yZEhhc2godGhpcy51c2VyLCB0aGlzLnBhc3N3b3JkLCBtc2cuc2FsdClcbiAgICAgIHRoaXMuY29ubmVjdGlvbi5wYXNzd29yZChoYXNoZWRQYXNzd29yZClcbiAgICB9KVxuICB9XG5cbiAgX2hhbmRsZUF1dGhTQVNMKG1zZykge1xuICAgIHRoaXMuX2NoZWNrUGdQYXNzKCgpID0+IHtcbiAgICAgIHRoaXMuc2FzbFNlc3Npb24gPSBzYXNsLnN0YXJ0U2Vzc2lvbihtc2cubWVjaGFuaXNtcylcbiAgICAgIHRoaXMuY29ubmVjdGlvbi5zZW5kU0FTTEluaXRpYWxSZXNwb25zZU1lc3NhZ2UodGhpcy5zYXNsU2Vzc2lvbi5tZWNoYW5pc20sIHRoaXMuc2FzbFNlc3Npb24ucmVzcG9uc2UpXG4gICAgfSlcbiAgfVxuXG4gIF9oYW5kbGVBdXRoU0FTTENvbnRpbnVlKG1zZykge1xuICAgIHNhc2wuY29udGludWVTZXNzaW9uKHRoaXMuc2FzbFNlc3Npb24sIHRoaXMucGFzc3dvcmQsIG1zZy5kYXRhKVxuICAgIHRoaXMuY29ubmVjdGlvbi5zZW5kU0NSQU1DbGllbnRGaW5hbE1lc3NhZ2UodGhpcy5zYXNsU2Vzc2lvbi5yZXNwb25zZSlcbiAgfVxuXG4gIF9oYW5kbGVBdXRoU0FTTEZpbmFsKG1zZykge1xuICAgIHNhc2wuZmluYWxpemVTZXNzaW9uKHRoaXMuc2FzbFNlc3Npb24sIG1zZy5kYXRhKVxuICAgIHRoaXMuc2FzbFNlc3Npb24gPSBudWxsXG4gIH1cblxuICBfaGFuZGxlQmFja2VuZEtleURhdGEobXNnKSB7XG4gICAgdGhpcy5wcm9jZXNzSUQgPSBtc2cucHJvY2Vzc0lEXG4gICAgdGhpcy5zZWNyZXRLZXkgPSBtc2cuc2VjcmV0S2V5XG4gIH1cblxuICBfaGFuZGxlUmVhZHlGb3JRdWVyeShtc2cpIHtcbiAgICBpZiAodGhpcy5fY29ubmVjdGluZykge1xuICAgICAgdGhpcy5fY29ubmVjdGluZyA9IGZhbHNlXG4gICAgICB0aGlzLl9jb25uZWN0ZWQgPSB0cnVlXG4gICAgICBjbGVhclRpbWVvdXQodGhpcy5jb25uZWN0aW9uVGltZW91dEhhbmRsZSlcblxuICAgICAgLy8gcHJvY2VzcyBwb3NzaWJsZSBjYWxsYmFjayBhcmd1bWVudCB0byBDbGllbnQjY29ubmVjdFxuICAgICAgaWYgKHRoaXMuX2Nvbm5lY3Rpb25DYWxsYmFjaykge1xuICAgICAgICB0aGlzLl9jb25uZWN0aW9uQ2FsbGJhY2sobnVsbCwgdGhpcylcbiAgICAgICAgLy8gcmVtb3ZlIGNhbGxiYWNrIGZvciBwcm9wZXIgZXJyb3IgaGFuZGxpbmdcbiAgICAgICAgLy8gYWZ0ZXIgdGhlIGNvbm5lY3QgZXZlbnRcbiAgICAgICAgdGhpcy5fY29ubmVjdGlvbkNhbGxiYWNrID0gbnVsbFxuICAgICAgfVxuICAgICAgdGhpcy5lbWl0KCdjb25uZWN0JylcbiAgICB9XG4gICAgY29uc3QgeyBhY3RpdmVRdWVyeSB9ID0gdGhpc1xuICAgIHRoaXMuYWN0aXZlUXVlcnkgPSBudWxsXG4gICAgdGhpcy5yZWFkeUZvclF1ZXJ5ID0gdHJ1ZVxuICAgIGlmIChhY3RpdmVRdWVyeSkge1xuICAgICAgYWN0aXZlUXVlcnkuaGFuZGxlUmVhZHlGb3JRdWVyeSh0aGlzLmNvbm5lY3Rpb24pXG4gICAgfVxuICAgIHRoaXMuX3B1bHNlUXVlcnlRdWV1ZSgpXG4gIH1cblxuICAvLyBpZiB3ZSByZWNlaWV2ZSBhbiBlcnJvciBldmVudCBvciBlcnJvciBtZXNzYWdlXG4gIC8vIGR1cmluZyB0aGUgY29ubmVjdGlvbiBwcm9jZXNzIHdlIGhhbmRsZSBpdCBoZXJlXG4gIF9oYW5kbGVFcnJvcldoaWxlQ29ubmVjdGluZyhlcnIpIHtcbiAgICBpZiAodGhpcy5fY29ubmVjdGlvbkVycm9yKSB7XG4gICAgICAvLyBUT0RPKGJtYyk6IHRoaXMgaXMgc3dhbGxvd2luZyBlcnJvcnMgLSB3ZSBzaG91bGRuJ3QgZG8gdGhpc1xuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIHRoaXMuX2Nvbm5lY3Rpb25FcnJvciA9IHRydWVcbiAgICBjbGVhclRpbWVvdXQodGhpcy5jb25uZWN0aW9uVGltZW91dEhhbmRsZSlcbiAgICBpZiAodGhpcy5fY29ubmVjdGlvbkNhbGxiYWNrKSB7XG4gICAgICByZXR1cm4gdGhpcy5fY29ubmVjdGlvbkNhbGxiYWNrKGVycilcbiAgICB9XG4gICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycilcbiAgfVxuXG4gIC8vIGlmIHdlJ3JlIGNvbm5lY3RlZCBhbmQgd2UgcmVjZWl2ZSBhbiBlcnJvciBldmVudCBmcm9tIHRoZSBjb25uZWN0aW9uXG4gIC8vIHRoaXMgbWVhbnMgdGhlIHNvY2tldCBpcyBkZWFkIC0gZG8gYSBoYXJkIGFib3J0IG9mIGFsbCBxdWVyaWVzIGFuZCBlbWl0XG4gIC8vIHRoZSBzb2NrZXQgZXJyb3Igb24gdGhlIGNsaWVudCBhcyB3ZWxsXG4gIF9oYW5kbGVFcnJvckV2ZW50KGVycikge1xuICAgIGlmICh0aGlzLl9jb25uZWN0aW5nKSB7XG4gICAgICByZXR1cm4gdGhpcy5faGFuZGxlRXJyb3JXaGlsZUNvbm5lY3RpbmcoZXJyKVxuICAgIH1cbiAgICB0aGlzLl9xdWVyeWFibGUgPSBmYWxzZVxuICAgIHRoaXMuX2Vycm9yQWxsUXVlcmllcyhlcnIpXG4gICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycilcbiAgfVxuXG4gIC8vIGhhbmRsZSBlcnJvciBtZXNzYWdlcyBmcm9tIHRoZSBwb3N0Z3JlcyBiYWNrZW5kXG4gIF9oYW5kbGVFcnJvck1lc3NhZ2UobXNnKSB7XG4gICAgaWYgKHRoaXMuX2Nvbm5lY3RpbmcpIHtcbiAgICAgIHJldHVybiB0aGlzLl9oYW5kbGVFcnJvcldoaWxlQ29ubmVjdGluZyhtc2cpXG4gICAgfVxuICAgIGNvbnN0IGFjdGl2ZVF1ZXJ5ID0gdGhpcy5hY3RpdmVRdWVyeVxuXG4gICAgaWYgKCFhY3RpdmVRdWVyeSkge1xuICAgICAgdGhpcy5faGFuZGxlRXJyb3JFdmVudChtc2cpXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICB0aGlzLmFjdGl2ZVF1ZXJ5ID0gbnVsbFxuICAgIGFjdGl2ZVF1ZXJ5LmhhbmRsZUVycm9yKG1zZywgdGhpcy5jb25uZWN0aW9uKVxuICB9XG5cbiAgX2hhbmRsZVJvd0Rlc2NyaXB0aW9uKG1zZykge1xuICAgIC8vIGRlbGVnYXRlIHJvd0Rlc2NyaXB0aW9uIHRvIGFjdGl2ZSBxdWVyeVxuICAgIHRoaXMuYWN0aXZlUXVlcnkuaGFuZGxlUm93RGVzY3JpcHRpb24obXNnKVxuICB9XG5cbiAgX2hhbmRsZURhdGFSb3cobXNnKSB7XG4gICAgLy8gZGVsZWdhdGUgZGF0YVJvdyB0byBhY3RpdmUgcXVlcnlcbiAgICB0aGlzLmFjdGl2ZVF1ZXJ5LmhhbmRsZURhdGFSb3cobXNnKVxuICB9XG5cbiAgX2hhbmRsZVBvcnRhbFN1c3BlbmRlZChtc2cpIHtcbiAgICAvLyBkZWxlZ2F0ZSBwb3J0YWxTdXNwZW5kZWQgdG8gYWN0aXZlIHF1ZXJ5XG4gICAgdGhpcy5hY3RpdmVRdWVyeS5oYW5kbGVQb3J0YWxTdXNwZW5kZWQodGhpcy5jb25uZWN0aW9uKVxuICB9XG5cbiAgX2hhbmRsZUVtcHR5UXVlcnkobXNnKSB7XG4gICAgLy8gZGVsZWdhdGUgZW1wdHlRdWVyeSB0byBhY3RpdmUgcXVlcnlcbiAgICB0aGlzLmFjdGl2ZVF1ZXJ5LmhhbmRsZUVtcHR5UXVlcnkodGhpcy5jb25uZWN0aW9uKVxuICB9XG5cbiAgX2hhbmRsZUNvbW1hbmRDb21wbGV0ZShtc2cpIHtcbiAgICAvLyBkZWxlZ2F0ZSBjb21tYW5kQ29tcGxldGUgdG8gYWN0aXZlIHF1ZXJ5XG4gICAgdGhpcy5hY3RpdmVRdWVyeS5oYW5kbGVDb21tYW5kQ29tcGxldGUobXNnLCB0aGlzLmNvbm5lY3Rpb24pXG4gIH1cblxuICBfaGFuZGxlUGFyc2VDb21wbGV0ZShtc2cpIHtcbiAgICAvLyBpZiBhIHByZXBhcmVkIHN0YXRlbWVudCBoYXMgYSBuYW1lIGFuZCBwcm9wZXJseSBwYXJzZXNcbiAgICAvLyB3ZSB0cmFjayB0aGF0IGl0cyBhbHJlYWR5IGJlZW4gZXhlY3V0ZWQgc28gd2UgZG9uJ3QgcGFyc2VcbiAgICAvLyBpdCBhZ2FpbiBvbiB0aGUgc2FtZSBjbGllbnRcbiAgICBpZiAodGhpcy5hY3RpdmVRdWVyeS5uYW1lKSB7XG4gICAgICB0aGlzLmNvbm5lY3Rpb24ucGFyc2VkU3RhdGVtZW50c1t0aGlzLmFjdGl2ZVF1ZXJ5Lm5hbWVdID0gdGhpcy5hY3RpdmVRdWVyeS50ZXh0XG4gICAgfVxuICB9XG5cbiAgX2hhbmRsZUNvcHlJblJlc3BvbnNlKG1zZykge1xuICAgIHRoaXMuYWN0aXZlUXVlcnkuaGFuZGxlQ29weUluUmVzcG9uc2UodGhpcy5jb25uZWN0aW9uKVxuICB9XG5cbiAgX2hhbmRsZUNvcHlEYXRhKG1zZykge1xuICAgIHRoaXMuYWN0aXZlUXVlcnkuaGFuZGxlQ29weURhdGEobXNnLCB0aGlzLmNvbm5lY3Rpb24pXG4gIH1cblxuICBfaGFuZGxlTm90aWZpY2F0aW9uKG1zZykge1xuICAgIHRoaXMuZW1pdCgnbm90aWZpY2F0aW9uJywgbXNnKVxuICB9XG5cbiAgX2hhbmRsZU5vdGljZShtc2cpIHtcbiAgICB0aGlzLmVtaXQoJ25vdGljZScsIG1zZylcbiAgfVxuXG4gIGdldFN0YXJ0dXBDb25mKCkge1xuICAgIHZhciBwYXJhbXMgPSB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzXG5cbiAgICB2YXIgZGF0YSA9IHtcbiAgICAgIHVzZXI6IHBhcmFtcy51c2VyLFxuICAgICAgZGF0YWJhc2U6IHBhcmFtcy5kYXRhYmFzZSxcbiAgICB9XG5cbiAgICB2YXIgYXBwTmFtZSA9IHBhcmFtcy5hcHBsaWNhdGlvbl9uYW1lIHx8IHBhcmFtcy5mYWxsYmFja19hcHBsaWNhdGlvbl9uYW1lXG4gICAgaWYgKGFwcE5hbWUpIHtcbiAgICAgIGRhdGEuYXBwbGljYXRpb25fbmFtZSA9IGFwcE5hbWVcbiAgICB9XG4gICAgaWYgKHBhcmFtcy5yZXBsaWNhdGlvbikge1xuICAgICAgZGF0YS5yZXBsaWNhdGlvbiA9ICcnICsgcGFyYW1zLnJlcGxpY2F0aW9uXG4gICAgfVxuICAgIGlmIChwYXJhbXMuc3RhdGVtZW50X3RpbWVvdXQpIHtcbiAgICAgIGRhdGEuc3RhdGVtZW50X3RpbWVvdXQgPSBTdHJpbmcocGFyc2VJbnQocGFyYW1zLnN0YXRlbWVudF90aW1lb3V0LCAxMCkpXG4gICAgfVxuICAgIGlmIChwYXJhbXMuaWRsZV9pbl90cmFuc2FjdGlvbl9zZXNzaW9uX3RpbWVvdXQpIHtcbiAgICAgIGRhdGEuaWRsZV9pbl90cmFuc2FjdGlvbl9zZXNzaW9uX3RpbWVvdXQgPSBTdHJpbmcocGFyc2VJbnQocGFyYW1zLmlkbGVfaW5fdHJhbnNhY3Rpb25fc2Vzc2lvbl90aW1lb3V0LCAxMCkpXG4gICAgfVxuICAgIGlmIChwYXJhbXMub3B0aW9ucykge1xuICAgICAgZGF0YS5vcHRpb25zID0gcGFyYW1zLm9wdGlvbnNcbiAgICB9XG5cbiAgICByZXR1cm4gZGF0YVxuICB9XG5cbiAgY2FuY2VsKGNsaWVudCwgcXVlcnkpIHtcbiAgICBpZiAoY2xpZW50LmFjdGl2ZVF1ZXJ5ID09PSBxdWVyeSkge1xuICAgICAgdmFyIGNvbiA9IHRoaXMuY29ubmVjdGlvblxuXG4gICAgICBpZiAodGhpcy5ob3N0ICYmIHRoaXMuaG9zdC5pbmRleE9mKCcvJykgPT09IDApIHtcbiAgICAgICAgY29uLmNvbm5lY3QodGhpcy5ob3N0ICsgJy8ucy5QR1NRTC4nICsgdGhpcy5wb3J0KVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uLmNvbm5lY3QodGhpcy5wb3J0LCB0aGlzLmhvc3QpXG4gICAgICB9XG5cbiAgICAgIC8vIG9uY2UgY29ubmVjdGlvbiBpcyBlc3RhYmxpc2hlZCBzZW5kIGNhbmNlbCBtZXNzYWdlXG4gICAgICBjb24ub24oJ2Nvbm5lY3QnLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGNvbi5jYW5jZWwoY2xpZW50LnByb2Nlc3NJRCwgY2xpZW50LnNlY3JldEtleSlcbiAgICAgIH0pXG4gICAgfSBlbHNlIGlmIChjbGllbnQucXVlcnlRdWV1ZS5pbmRleE9mKHF1ZXJ5KSAhPT0gLTEpIHtcbiAgICAgIGNsaWVudC5xdWVyeVF1ZXVlLnNwbGljZShjbGllbnQucXVlcnlRdWV1ZS5pbmRleE9mKHF1ZXJ5KSwgMSlcbiAgICB9XG4gIH1cblxuICBzZXRUeXBlUGFyc2VyKG9pZCwgZm9ybWF0LCBwYXJzZUZuKSB7XG4gICAgcmV0dXJuIHRoaXMuX3R5cGVzLnNldFR5cGVQYXJzZXIob2lkLCBmb3JtYXQsIHBhcnNlRm4pXG4gIH1cblxuICBnZXRUeXBlUGFyc2VyKG9pZCwgZm9ybWF0KSB7XG4gICAgcmV0dXJuIHRoaXMuX3R5cGVzLmdldFR5cGVQYXJzZXIob2lkLCBmb3JtYXQpXG4gIH1cblxuICAvLyBQb3J0ZWQgZnJvbSBQb3N0Z3JlU1FMIDkuMi40IHNvdXJjZSBjb2RlIGluIHNyYy9pbnRlcmZhY2VzL2xpYnBxL2ZlLWV4ZWMuY1xuICBlc2NhcGVJZGVudGlmaWVyKHN0cikge1xuICAgIHJldHVybiAnXCInICsgc3RyLnJlcGxhY2UoL1wiL2csICdcIlwiJykgKyAnXCInXG4gIH1cblxuICAvLyBQb3J0ZWQgZnJvbSBQb3N0Z3JlU1FMIDkuMi40IHNvdXJjZSBjb2RlIGluIHNyYy9pbnRlcmZhY2VzL2xpYnBxL2ZlLWV4ZWMuY1xuICBlc2NhcGVMaXRlcmFsKHN0cikge1xuICAgIHZhciBoYXNCYWNrc2xhc2ggPSBmYWxzZVxuICAgIHZhciBlc2NhcGVkID0gXCInXCJcblxuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgc3RyLmxlbmd0aDsgaSsrKSB7XG4gICAgICB2YXIgYyA9IHN0cltpXVxuICAgICAgaWYgKGMgPT09IFwiJ1wiKSB7XG4gICAgICAgIGVzY2FwZWQgKz0gYyArIGNcbiAgICAgIH0gZWxzZSBpZiAoYyA9PT0gJ1xcXFwnKSB7XG4gICAgICAgIGVzY2FwZWQgKz0gYyArIGNcbiAgICAgICAgaGFzQmFja3NsYXNoID0gdHJ1ZVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZXNjYXBlZCArPSBjXG4gICAgICB9XG4gICAgfVxuXG4gICAgZXNjYXBlZCArPSBcIidcIlxuXG4gICAgaWYgKGhhc0JhY2tzbGFzaCA9PT0gdHJ1ZSkge1xuICAgICAgZXNjYXBlZCA9ICcgRScgKyBlc2NhcGVkXG4gICAgfVxuXG4gICAgcmV0dXJuIGVzY2FwZWRcbiAgfVxuXG4gIF9wdWxzZVF1ZXJ5UXVldWUoKSB7XG4gICAgaWYgKHRoaXMucmVhZHlGb3JRdWVyeSA9PT0gdHJ1ZSkge1xuICAgICAgdGhpcy5hY3RpdmVRdWVyeSA9IHRoaXMucXVlcnlRdWV1ZS5zaGlmdCgpXG4gICAgICBpZiAodGhpcy5hY3RpdmVRdWVyeSkge1xuICAgICAgICB0aGlzLnJlYWR5Rm9yUXVlcnkgPSBmYWxzZVxuICAgICAgICB0aGlzLmhhc0V4ZWN1dGVkID0gdHJ1ZVxuXG4gICAgICAgIGNvbnN0IHF1ZXJ5RXJyb3IgPSB0aGlzLmFjdGl2ZVF1ZXJ5LnN1Ym1pdCh0aGlzLmNvbm5lY3Rpb24pXG4gICAgICAgIGlmIChxdWVyeUVycm9yKSB7XG4gICAgICAgICAgcHJvY2Vzcy5uZXh0VGljaygoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmFjdGl2ZVF1ZXJ5LmhhbmRsZUVycm9yKHF1ZXJ5RXJyb3IsIHRoaXMuY29ubmVjdGlvbilcbiAgICAgICAgICAgIHRoaXMucmVhZHlGb3JRdWVyeSA9IHRydWVcbiAgICAgICAgICAgIHRoaXMuX3B1bHNlUXVlcnlRdWV1ZSgpXG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmICh0aGlzLmhhc0V4ZWN1dGVkKSB7XG4gICAgICAgIHRoaXMuYWN0aXZlUXVlcnkgPSBudWxsXG4gICAgICAgIHRoaXMuZW1pdCgnZHJhaW4nKVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHF1ZXJ5KGNvbmZpZywgdmFsdWVzLCBjYWxsYmFjaykge1xuICAgIC8vIGNhbiB0YWtlIGluIHN0cmluZ3MsIGNvbmZpZyBvYmplY3Qgb3IgcXVlcnkgb2JqZWN0XG4gICAgdmFyIHF1ZXJ5XG4gICAgdmFyIHJlc3VsdFxuICAgIHZhciByZWFkVGltZW91dFxuICAgIHZhciByZWFkVGltZW91dFRpbWVyXG4gICAgdmFyIHF1ZXJ5Q2FsbGJhY2tcblxuICAgIGlmIChjb25maWcgPT09IG51bGwgfHwgY29uZmlnID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ0NsaWVudCB3YXMgcGFzc2VkIGEgbnVsbCBvciB1bmRlZmluZWQgcXVlcnknKVxuICAgIH0gZWxzZSBpZiAodHlwZW9mIGNvbmZpZy5zdWJtaXQgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIHJlYWRUaW1lb3V0ID0gY29uZmlnLnF1ZXJ5X3RpbWVvdXQgfHwgdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy5xdWVyeV90aW1lb3V0XG4gICAgICByZXN1bHQgPSBxdWVyeSA9IGNvbmZpZ1xuICAgICAgaWYgKHR5cGVvZiB2YWx1ZXMgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgcXVlcnkuY2FsbGJhY2sgPSBxdWVyeS5jYWxsYmFjayB8fCB2YWx1ZXNcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgcmVhZFRpbWVvdXQgPSB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLnF1ZXJ5X3RpbWVvdXRcbiAgICAgIHF1ZXJ5ID0gbmV3IFF1ZXJ5KGNvbmZpZywgdmFsdWVzLCBjYWxsYmFjaylcbiAgICAgIGlmICghcXVlcnkuY2FsbGJhY2spIHtcbiAgICAgICAgcmVzdWx0ID0gbmV3IHRoaXMuX1Byb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICAgIHF1ZXJ5LmNhbGxiYWNrID0gKGVyciwgcmVzKSA9PiAoZXJyID8gcmVqZWN0KGVycikgOiByZXNvbHZlKHJlcykpXG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHJlYWRUaW1lb3V0KSB7XG4gICAgICBxdWVyeUNhbGxiYWNrID0gcXVlcnkuY2FsbGJhY2tcblxuICAgICAgcmVhZFRpbWVvdXRUaW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICB2YXIgZXJyb3IgPSBuZXcgRXJyb3IoJ1F1ZXJ5IHJlYWQgdGltZW91dCcpXG5cbiAgICAgICAgcHJvY2Vzcy5uZXh0VGljaygoKSA9PiB7XG4gICAgICAgICAgcXVlcnkuaGFuZGxlRXJyb3IoZXJyb3IsIHRoaXMuY29ubmVjdGlvbilcbiAgICAgICAgfSlcblxuICAgICAgICBxdWVyeUNhbGxiYWNrKGVycm9yKVxuXG4gICAgICAgIC8vIHdlIGFscmVhZHkgcmV0dXJuZWQgYW4gZXJyb3IsXG4gICAgICAgIC8vIGp1c3QgZG8gbm90aGluZyBpZiBxdWVyeSBjb21wbGV0ZXNcbiAgICAgICAgcXVlcnkuY2FsbGJhY2sgPSAoKSA9PiB7fVxuXG4gICAgICAgIC8vIFJlbW92ZSBmcm9tIHF1ZXVlXG4gICAgICAgIHZhciBpbmRleCA9IHRoaXMucXVlcnlRdWV1ZS5pbmRleE9mKHF1ZXJ5KVxuICAgICAgICBpZiAoaW5kZXggPiAtMSkge1xuICAgICAgICAgIHRoaXMucXVlcnlRdWV1ZS5zcGxpY2UoaW5kZXgsIDEpXG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLl9wdWxzZVF1ZXJ5UXVldWUoKVxuICAgICAgfSwgcmVhZFRpbWVvdXQpXG5cbiAgICAgIHF1ZXJ5LmNhbGxiYWNrID0gKGVyciwgcmVzKSA9PiB7XG4gICAgICAgIGNsZWFyVGltZW91dChyZWFkVGltZW91dFRpbWVyKVxuICAgICAgICBxdWVyeUNhbGxiYWNrKGVyciwgcmVzKVxuICAgICAgfVxuICAgIH1cblxuICAgIGlmICh0aGlzLmJpbmFyeSAmJiAhcXVlcnkuYmluYXJ5KSB7XG4gICAgICBxdWVyeS5iaW5hcnkgPSB0cnVlXG4gICAgfVxuXG4gICAgaWYgKHF1ZXJ5Ll9yZXN1bHQgJiYgIXF1ZXJ5Ll9yZXN1bHQuX3R5cGVzKSB7XG4gICAgICBxdWVyeS5fcmVzdWx0Ll90eXBlcyA9IHRoaXMuX3R5cGVzXG4gICAgfVxuXG4gICAgaWYgKCF0aGlzLl9xdWVyeWFibGUpIHtcbiAgICAgIHByb2Nlc3MubmV4dFRpY2soKCkgPT4ge1xuICAgICAgICBxdWVyeS5oYW5kbGVFcnJvcihuZXcgRXJyb3IoJ0NsaWVudCBoYXMgZW5jb3VudGVyZWQgYSBjb25uZWN0aW9uIGVycm9yIGFuZCBpcyBub3QgcXVlcnlhYmxlJyksIHRoaXMuY29ubmVjdGlvbilcbiAgICAgIH0pXG4gICAgICByZXR1cm4gcmVzdWx0XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuX2VuZGluZykge1xuICAgICAgcHJvY2Vzcy5uZXh0VGljaygoKSA9PiB7XG4gICAgICAgIHF1ZXJ5LmhhbmRsZUVycm9yKG5ldyBFcnJvcignQ2xpZW50IHdhcyBjbG9zZWQgYW5kIGlzIG5vdCBxdWVyeWFibGUnKSwgdGhpcy5jb25uZWN0aW9uKVxuICAgICAgfSlcbiAgICAgIHJldHVybiByZXN1bHRcbiAgICB9XG5cbiAgICB0aGlzLnF1ZXJ5UXVldWUucHVzaChxdWVyeSlcbiAgICB0aGlzLl9wdWxzZVF1ZXJ5UXVldWUoKVxuICAgIHJldHVybiByZXN1bHRcbiAgfVxuXG4gIHJlZigpIHtcbiAgICB0aGlzLmNvbm5lY3Rpb24ucmVmKClcbiAgfVxuXG4gIHVucmVmKCkge1xuICAgIHRoaXMuY29ubmVjdGlvbi51bnJlZigpXG4gIH1cblxuICBlbmQoY2IpIHtcbiAgICB0aGlzLl9lbmRpbmcgPSB0cnVlXG5cbiAgICAvLyBpZiB3ZSBoYXZlIG5ldmVyIGNvbm5lY3RlZCwgdGhlbiBlbmQgaXMgYSBub29wLCBjYWxsYmFjayBpbW1lZGlhdGVseVxuICAgIGlmICghdGhpcy5jb25uZWN0aW9uLl9jb25uZWN0aW5nKSB7XG4gICAgICBpZiAoY2IpIHtcbiAgICAgICAgY2IoKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX1Byb21pc2UucmVzb2x2ZSgpXG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuYWN0aXZlUXVlcnkgfHwgIXRoaXMuX3F1ZXJ5YWJsZSkge1xuICAgICAgLy8gaWYgd2UgaGF2ZSBhbiBhY3RpdmUgcXVlcnkgd2UgbmVlZCB0byBmb3JjZSBhIGRpc2Nvbm5lY3RcbiAgICAgIC8vIG9uIHRoZSBzb2NrZXQgLSBvdGhlcndpc2UgYSBodW5nIHF1ZXJ5IGNvdWxkIGJsb2NrIGVuZCBmb3JldmVyXG4gICAgICB0aGlzLmNvbm5lY3Rpb24uc3RyZWFtLmRlc3Ryb3koKVxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmNvbm5lY3Rpb24uZW5kKClcbiAgICB9XG5cbiAgICBpZiAoY2IpIHtcbiAgICAgIHRoaXMuY29ubmVjdGlvbi5vbmNlKCdlbmQnLCBjYilcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIG5ldyB0aGlzLl9Qcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICAgIHRoaXMuY29ubmVjdGlvbi5vbmNlKCdlbmQnLCByZXNvbHZlKVxuICAgICAgfSlcbiAgICB9XG4gIH1cbn1cblxuLy8gZXhwb3NlIGEgUXVlcnkgY29uc3RydWN0b3JcbkNsaWVudC5RdWVyeSA9IFF1ZXJ5XG5cbm1vZHVsZS5leHBvcnRzID0gQ2xpZW50XG4iLCIndXNlIHN0cmljdCdcblxudmFyIGRucyA9IHJlcXVpcmUoJ2RucycpXG5cbnZhciBkZWZhdWx0cyA9IHJlcXVpcmUoJy4vZGVmYXVsdHMnKVxuXG52YXIgcGFyc2UgPSByZXF1aXJlKCdwZy1jb25uZWN0aW9uLXN0cmluZycpLnBhcnNlIC8vIHBhcnNlcyBhIGNvbm5lY3Rpb24gc3RyaW5nXG5cbnZhciB2YWwgPSBmdW5jdGlvbiAoa2V5LCBjb25maWcsIGVudlZhcikge1xuICBpZiAoZW52VmFyID09PSB1bmRlZmluZWQpIHtcbiAgICBlbnZWYXIgPSBwcm9jZXNzLmVudlsnUEcnICsga2V5LnRvVXBwZXJDYXNlKCldXG4gIH0gZWxzZSBpZiAoZW52VmFyID09PSBmYWxzZSkge1xuICAgIC8vIGRvIG5vdGhpbmcgLi4uIHVzZSBmYWxzZVxuICB9IGVsc2Uge1xuICAgIGVudlZhciA9IHByb2Nlc3MuZW52W2VudlZhcl1cbiAgfVxuXG4gIHJldHVybiBjb25maWdba2V5XSB8fCBlbnZWYXIgfHwgZGVmYXVsdHNba2V5XVxufVxuXG52YXIgcmVhZFNTTENvbmZpZ0Zyb21FbnZpcm9ubWVudCA9IGZ1bmN0aW9uICgpIHtcbiAgc3dpdGNoIChwcm9jZXNzLmVudi5QR1NTTE1PREUpIHtcbiAgICBjYXNlICdkaXNhYmxlJzpcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIGNhc2UgJ3ByZWZlcic6XG4gICAgY2FzZSAncmVxdWlyZSc6XG4gICAgY2FzZSAndmVyaWZ5LWNhJzpcbiAgICBjYXNlICd2ZXJpZnktZnVsbCc6XG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIGNhc2UgJ25vLXZlcmlmeSc6XG4gICAgICByZXR1cm4geyByZWplY3RVbmF1dGhvcml6ZWQ6IGZhbHNlIH1cbiAgfVxuICByZXR1cm4gZGVmYXVsdHMuc3NsXG59XG5cbi8vIENvbnZlcnQgYXJnIHRvIGEgc3RyaW5nLCBzdXJyb3VuZCBpbiBzaW5nbGUgcXVvdGVzLCBhbmQgZXNjYXBlIHNpbmdsZSBxdW90ZXMgYW5kIGJhY2tzbGFzaGVzXG52YXIgcXVvdGVQYXJhbVZhbHVlID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gIHJldHVybiBcIidcIiArICgnJyArIHZhbHVlKS5yZXBsYWNlKC9cXFxcL2csICdcXFxcXFxcXCcpLnJlcGxhY2UoLycvZywgXCJcXFxcJ1wiKSArIFwiJ1wiXG59XG5cbnZhciBhZGQgPSBmdW5jdGlvbiAocGFyYW1zLCBjb25maWcsIHBhcmFtTmFtZSkge1xuICB2YXIgdmFsdWUgPSBjb25maWdbcGFyYW1OYW1lXVxuICBpZiAodmFsdWUgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZSAhPT0gbnVsbCkge1xuICAgIHBhcmFtcy5wdXNoKHBhcmFtTmFtZSArICc9JyArIHF1b3RlUGFyYW1WYWx1ZSh2YWx1ZSkpXG4gIH1cbn1cblxuY2xhc3MgQ29ubmVjdGlvblBhcmFtZXRlcnMge1xuICBjb25zdHJ1Y3Rvcihjb25maWcpIHtcbiAgICAvLyBpZiBhIHN0cmluZyBpcyBwYXNzZWQsIGl0IGlzIGEgcmF3IGNvbm5lY3Rpb24gc3RyaW5nIHNvIHdlIHBhcnNlIGl0IGludG8gYSBjb25maWdcbiAgICBjb25maWcgPSB0eXBlb2YgY29uZmlnID09PSAnc3RyaW5nJyA/IHBhcnNlKGNvbmZpZykgOiBjb25maWcgfHwge31cblxuICAgIC8vIGlmIHRoZSBjb25maWcgaGFzIGEgY29ubmVjdGlvblN0cmluZyBkZWZpbmVkLCBwYXJzZSBJVCBpbnRvIHRoZSBjb25maWcgd2UgdXNlXG4gICAgLy8gdGhpcyB3aWxsIG92ZXJyaWRlIG90aGVyIGRlZmF1bHQgdmFsdWVzIHdpdGggd2hhdCBpcyBzdG9yZWQgaW4gY29ubmVjdGlvblN0cmluZ1xuICAgIGlmIChjb25maWcuY29ubmVjdGlvblN0cmluZykge1xuICAgICAgY29uZmlnID0gT2JqZWN0LmFzc2lnbih7fSwgY29uZmlnLCBwYXJzZShjb25maWcuY29ubmVjdGlvblN0cmluZykpXG4gICAgfVxuXG4gICAgdGhpcy51c2VyID0gdmFsKCd1c2VyJywgY29uZmlnKVxuICAgIHRoaXMuZGF0YWJhc2UgPSB2YWwoJ2RhdGFiYXNlJywgY29uZmlnKVxuXG4gICAgaWYgKHRoaXMuZGF0YWJhc2UgPT09IHVuZGVmaW5lZCkge1xuICAgICAgdGhpcy5kYXRhYmFzZSA9IHRoaXMudXNlclxuICAgIH1cblxuICAgIHRoaXMucG9ydCA9IHBhcnNlSW50KHZhbCgncG9ydCcsIGNvbmZpZyksIDEwKVxuICAgIHRoaXMuaG9zdCA9IHZhbCgnaG9zdCcsIGNvbmZpZylcblxuICAgIC8vIFwiaGlkaW5nXCIgdGhlIHBhc3N3b3JkIHNvIGl0IGRvZXNuJ3Qgc2hvdyB1cCBpbiBzdGFjayB0cmFjZXNcbiAgICAvLyBvciBpZiB0aGUgY2xpZW50IGlzIGNvbnNvbGUubG9nZ2VkXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsICdwYXNzd29yZCcsIHtcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICB2YWx1ZTogdmFsKCdwYXNzd29yZCcsIGNvbmZpZyksXG4gICAgfSlcblxuICAgIHRoaXMuYmluYXJ5ID0gdmFsKCdiaW5hcnknLCBjb25maWcpXG4gICAgdGhpcy5vcHRpb25zID0gdmFsKCdvcHRpb25zJywgY29uZmlnKVxuXG4gICAgdGhpcy5zc2wgPSB0eXBlb2YgY29uZmlnLnNzbCA9PT0gJ3VuZGVmaW5lZCcgPyByZWFkU1NMQ29uZmlnRnJvbUVudmlyb25tZW50KCkgOiBjb25maWcuc3NsXG5cbiAgICBpZiAodHlwZW9mIHRoaXMuc3NsID09PSAnc3RyaW5nJykge1xuICAgICAgaWYgKHRoaXMuc3NsID09PSAndHJ1ZScpIHtcbiAgICAgICAgdGhpcy5zc2wgPSB0cnVlXG4gICAgICB9XG4gICAgfVxuICAgIC8vIHN1cHBvcnQgcGFzc2luZyBpbiBzc2w9bm8tdmVyaWZ5IHZpYSBjb25uZWN0aW9uIHN0cmluZ1xuICAgIGlmICh0aGlzLnNzbCA9PT0gJ25vLXZlcmlmeScpIHtcbiAgICAgIHRoaXMuc3NsID0geyByZWplY3RVbmF1dGhvcml6ZWQ6IGZhbHNlIH1cbiAgICB9XG4gICAgaWYgKHRoaXMuc3NsICYmIHRoaXMuc3NsLmtleSkge1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMuc3NsLCAna2V5Jywge1xuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgIH0pXG4gICAgfVxuXG4gICAgdGhpcy5jbGllbnRfZW5jb2RpbmcgPSB2YWwoJ2NsaWVudF9lbmNvZGluZycsIGNvbmZpZylcbiAgICB0aGlzLnJlcGxpY2F0aW9uID0gdmFsKCdyZXBsaWNhdGlvbicsIGNvbmZpZylcbiAgICAvLyBhIGRvbWFpbiBzb2NrZXQgYmVnaW5zIHdpdGggJy8nXG4gICAgdGhpcy5pc0RvbWFpblNvY2tldCA9ICEodGhpcy5ob3N0IHx8ICcnKS5pbmRleE9mKCcvJylcblxuICAgIHRoaXMuYXBwbGljYXRpb25fbmFtZSA9IHZhbCgnYXBwbGljYXRpb25fbmFtZScsIGNvbmZpZywgJ1BHQVBQTkFNRScpXG4gICAgdGhpcy5mYWxsYmFja19hcHBsaWNhdGlvbl9uYW1lID0gdmFsKCdmYWxsYmFja19hcHBsaWNhdGlvbl9uYW1lJywgY29uZmlnLCBmYWxzZSlcbiAgICB0aGlzLnN0YXRlbWVudF90aW1lb3V0ID0gdmFsKCdzdGF0ZW1lbnRfdGltZW91dCcsIGNvbmZpZywgZmFsc2UpXG4gICAgdGhpcy5pZGxlX2luX3RyYW5zYWN0aW9uX3Nlc3Npb25fdGltZW91dCA9IHZhbCgnaWRsZV9pbl90cmFuc2FjdGlvbl9zZXNzaW9uX3RpbWVvdXQnLCBjb25maWcsIGZhbHNlKVxuICAgIHRoaXMucXVlcnlfdGltZW91dCA9IHZhbCgncXVlcnlfdGltZW91dCcsIGNvbmZpZywgZmFsc2UpXG5cbiAgICBpZiAoY29uZmlnLmNvbm5lY3Rpb25UaW1lb3V0TWlsbGlzID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMuY29ubmVjdF90aW1lb3V0ID0gcHJvY2Vzcy5lbnYuUEdDT05ORUNUX1RJTUVPVVQgfHwgMFxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmNvbm5lY3RfdGltZW91dCA9IE1hdGguZmxvb3IoY29uZmlnLmNvbm5lY3Rpb25UaW1lb3V0TWlsbGlzIC8gMTAwMClcbiAgICB9XG5cbiAgICBpZiAoY29uZmlnLmtlZXBBbGl2ZSA9PT0gZmFsc2UpIHtcbiAgICAgIHRoaXMua2VlcGFsaXZlcyA9IDBcbiAgICB9IGVsc2UgaWYgKGNvbmZpZy5rZWVwQWxpdmUgPT09IHRydWUpIHtcbiAgICAgIHRoaXMua2VlcGFsaXZlcyA9IDFcbiAgICB9XG5cbiAgICBpZiAodHlwZW9mIGNvbmZpZy5rZWVwQWxpdmVJbml0aWFsRGVsYXlNaWxsaXMgPT09ICdudW1iZXInKSB7XG4gICAgICB0aGlzLmtlZXBhbGl2ZXNfaWRsZSA9IE1hdGguZmxvb3IoY29uZmlnLmtlZXBBbGl2ZUluaXRpYWxEZWxheU1pbGxpcyAvIDEwMDApXG4gICAgfVxuICB9XG5cbiAgZ2V0TGlicHFDb25uZWN0aW9uU3RyaW5nKGNiKSB7XG4gICAgdmFyIHBhcmFtcyA9IFtdXG4gICAgYWRkKHBhcmFtcywgdGhpcywgJ3VzZXInKVxuICAgIGFkZChwYXJhbXMsIHRoaXMsICdwYXNzd29yZCcpXG4gICAgYWRkKHBhcmFtcywgdGhpcywgJ3BvcnQnKVxuICAgIGFkZChwYXJhbXMsIHRoaXMsICdhcHBsaWNhdGlvbl9uYW1lJylcbiAgICBhZGQocGFyYW1zLCB0aGlzLCAnZmFsbGJhY2tfYXBwbGljYXRpb25fbmFtZScpXG4gICAgYWRkKHBhcmFtcywgdGhpcywgJ2Nvbm5lY3RfdGltZW91dCcpXG4gICAgYWRkKHBhcmFtcywgdGhpcywgJ29wdGlvbnMnKVxuXG4gICAgdmFyIHNzbCA9IHR5cGVvZiB0aGlzLnNzbCA9PT0gJ29iamVjdCcgPyB0aGlzLnNzbCA6IHRoaXMuc3NsID8geyBzc2xtb2RlOiB0aGlzLnNzbCB9IDoge31cbiAgICBhZGQocGFyYW1zLCBzc2wsICdzc2xtb2RlJylcbiAgICBhZGQocGFyYW1zLCBzc2wsICdzc2xjYScpXG4gICAgYWRkKHBhcmFtcywgc3NsLCAnc3Nsa2V5JylcbiAgICBhZGQocGFyYW1zLCBzc2wsICdzc2xjZXJ0JylcbiAgICBhZGQocGFyYW1zLCBzc2wsICdzc2xyb290Y2VydCcpXG5cbiAgICBpZiAodGhpcy5kYXRhYmFzZSkge1xuICAgICAgcGFyYW1zLnB1c2goJ2RibmFtZT0nICsgcXVvdGVQYXJhbVZhbHVlKHRoaXMuZGF0YWJhc2UpKVxuICAgIH1cbiAgICBpZiAodGhpcy5yZXBsaWNhdGlvbikge1xuICAgICAgcGFyYW1zLnB1c2goJ3JlcGxpY2F0aW9uPScgKyBxdW90ZVBhcmFtVmFsdWUodGhpcy5yZXBsaWNhdGlvbikpXG4gICAgfVxuICAgIGlmICh0aGlzLmhvc3QpIHtcbiAgICAgIHBhcmFtcy5wdXNoKCdob3N0PScgKyBxdW90ZVBhcmFtVmFsdWUodGhpcy5ob3N0KSlcbiAgICB9XG4gICAgaWYgKHRoaXMuaXNEb21haW5Tb2NrZXQpIHtcbiAgICAgIHJldHVybiBjYihudWxsLCBwYXJhbXMuam9pbignICcpKVxuICAgIH1cbiAgICBpZiAodGhpcy5jbGllbnRfZW5jb2RpbmcpIHtcbiAgICAgIHBhcmFtcy5wdXNoKCdjbGllbnRfZW5jb2Rpbmc9JyArIHF1b3RlUGFyYW1WYWx1ZSh0aGlzLmNsaWVudF9lbmNvZGluZykpXG4gICAgfVxuICAgIGRucy5sb29rdXAodGhpcy5ob3N0LCBmdW5jdGlvbiAoZXJyLCBhZGRyZXNzKSB7XG4gICAgICBpZiAoZXJyKSByZXR1cm4gY2IoZXJyLCBudWxsKVxuICAgICAgcGFyYW1zLnB1c2goJ2hvc3RhZGRyPScgKyBxdW90ZVBhcmFtVmFsdWUoYWRkcmVzcykpXG4gICAgICByZXR1cm4gY2IobnVsbCwgcGFyYW1zLmpvaW4oJyAnKSlcbiAgICB9KVxuICB9XG59XG5cbm1vZHVsZS5leHBvcnRzID0gQ29ubmVjdGlvblBhcmFtZXRlcnNcbiIsIid1c2Ugc3RyaWN0J1xuXG52YXIgbmV0ID0gcmVxdWlyZSgnbmV0JylcbnZhciBFdmVudEVtaXR0ZXIgPSByZXF1aXJlKCdldmVudHMnKS5FdmVudEVtaXR0ZXJcblxuY29uc3QgeyBwYXJzZSwgc2VyaWFsaXplIH0gPSByZXF1aXJlKCdwZy1wcm90b2NvbCcpXG5cbmNvbnN0IGZsdXNoQnVmZmVyID0gc2VyaWFsaXplLmZsdXNoKClcbmNvbnN0IHN5bmNCdWZmZXIgPSBzZXJpYWxpemUuc3luYygpXG5jb25zdCBlbmRCdWZmZXIgPSBzZXJpYWxpemUuZW5kKClcblxuLy8gVE9ETyhibWMpIHN1cHBvcnQgYmluYXJ5IG1vZGUgYXQgc29tZSBwb2ludFxuY2xhc3MgQ29ubmVjdGlvbiBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIGNvbnN0cnVjdG9yKGNvbmZpZykge1xuICAgIHN1cGVyKClcbiAgICBjb25maWcgPSBjb25maWcgfHwge31cbiAgICB0aGlzLnN0cmVhbSA9IGNvbmZpZy5zdHJlYW0gfHwgbmV3IG5ldC5Tb2NrZXQoKVxuICAgIHRoaXMuX2tlZXBBbGl2ZSA9IGNvbmZpZy5rZWVwQWxpdmVcbiAgICB0aGlzLl9rZWVwQWxpdmVJbml0aWFsRGVsYXlNaWxsaXMgPSBjb25maWcua2VlcEFsaXZlSW5pdGlhbERlbGF5TWlsbGlzXG4gICAgdGhpcy5sYXN0QnVmZmVyID0gZmFsc2VcbiAgICB0aGlzLnBhcnNlZFN0YXRlbWVudHMgPSB7fVxuICAgIHRoaXMuc3NsID0gY29uZmlnLnNzbCB8fCBmYWxzZVxuICAgIHRoaXMuX2VuZGluZyA9IGZhbHNlXG4gICAgdGhpcy5fZW1pdE1lc3NhZ2UgPSBmYWxzZVxuICAgIHZhciBzZWxmID0gdGhpc1xuICAgIHRoaXMub24oJ25ld0xpc3RlbmVyJywgZnVuY3Rpb24gKGV2ZW50TmFtZSkge1xuICAgICAgaWYgKGV2ZW50TmFtZSA9PT0gJ21lc3NhZ2UnKSB7XG4gICAgICAgIHNlbGYuX2VtaXRNZXNzYWdlID0gdHJ1ZVxuICAgICAgfVxuICAgIH0pXG4gIH1cblxuICBjb25uZWN0KHBvcnQsIGhvc3QpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXNcblxuICAgIHRoaXMuX2Nvbm5lY3RpbmcgPSB0cnVlXG4gICAgdGhpcy5zdHJlYW0uc2V0Tm9EZWxheSh0cnVlKVxuICAgIHRoaXMuc3RyZWFtLmNvbm5lY3QocG9ydCwgaG9zdClcblxuICAgIHRoaXMuc3RyZWFtLm9uY2UoJ2Nvbm5lY3QnLCBmdW5jdGlvbiAoKSB7XG4gICAgICBpZiAoc2VsZi5fa2VlcEFsaXZlKSB7XG4gICAgICAgIHNlbGYuc3RyZWFtLnNldEtlZXBBbGl2ZSh0cnVlLCBzZWxmLl9rZWVwQWxpdmVJbml0aWFsRGVsYXlNaWxsaXMpXG4gICAgICB9XG4gICAgICBzZWxmLmVtaXQoJ2Nvbm5lY3QnKVxuICAgIH0pXG5cbiAgICBjb25zdCByZXBvcnRTdHJlYW1FcnJvciA9IGZ1bmN0aW9uIChlcnJvcikge1xuICAgICAgLy8gZXJyb3JzIGFib3V0IGRpc2Nvbm5lY3Rpb25zIHNob3VsZCBiZSBpZ25vcmVkIGR1cmluZyBkaXNjb25uZWN0XG4gICAgICBpZiAoc2VsZi5fZW5kaW5nICYmIChlcnJvci5jb2RlID09PSAnRUNPTk5SRVNFVCcgfHwgZXJyb3IuY29kZSA9PT0gJ0VQSVBFJykpIHtcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG4gICAgICBzZWxmLmVtaXQoJ2Vycm9yJywgZXJyb3IpXG4gICAgfVxuICAgIHRoaXMuc3RyZWFtLm9uKCdlcnJvcicsIHJlcG9ydFN0cmVhbUVycm9yKVxuXG4gICAgdGhpcy5zdHJlYW0ub24oJ2Nsb3NlJywgZnVuY3Rpb24gKCkge1xuICAgICAgc2VsZi5lbWl0KCdlbmQnKVxuICAgIH0pXG5cbiAgICBpZiAoIXRoaXMuc3NsKSB7XG4gICAgICByZXR1cm4gdGhpcy5hdHRhY2hMaXN0ZW5lcnModGhpcy5zdHJlYW0pXG4gICAgfVxuXG4gICAgdGhpcy5zdHJlYW0ub25jZSgnZGF0YScsIGZ1bmN0aW9uIChidWZmZXIpIHtcbiAgICAgIHZhciByZXNwb25zZUNvZGUgPSBidWZmZXIudG9TdHJpbmcoJ3V0ZjgnKVxuICAgICAgc3dpdGNoIChyZXNwb25zZUNvZGUpIHtcbiAgICAgICAgY2FzZSAnUyc6IC8vIFNlcnZlciBzdXBwb3J0cyBTU0wgY29ubmVjdGlvbnMsIGNvbnRpbnVlIHdpdGggYSBzZWN1cmUgY29ubmVjdGlvblxuICAgICAgICAgIGJyZWFrXG4gICAgICAgIGNhc2UgJ04nOiAvLyBTZXJ2ZXIgZG9lcyBub3Qgc3VwcG9ydCBTU0wgY29ubmVjdGlvbnNcbiAgICAgICAgICBzZWxmLnN0cmVhbS5lbmQoKVxuICAgICAgICAgIHJldHVybiBzZWxmLmVtaXQoJ2Vycm9yJywgbmV3IEVycm9yKCdUaGUgc2VydmVyIGRvZXMgbm90IHN1cHBvcnQgU1NMIGNvbm5lY3Rpb25zJykpXG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgLy8gQW55IG90aGVyIHJlc3BvbnNlIGJ5dGUsIGluY2x1ZGluZyAnRScgKEVycm9yUmVzcG9uc2UpIGluZGljYXRpbmcgYSBzZXJ2ZXIgZXJyb3JcbiAgICAgICAgICBzZWxmLnN0cmVhbS5lbmQoKVxuICAgICAgICAgIHJldHVybiBzZWxmLmVtaXQoJ2Vycm9yJywgbmV3IEVycm9yKCdUaGVyZSB3YXMgYW4gZXJyb3IgZXN0YWJsaXNoaW5nIGFuIFNTTCBjb25uZWN0aW9uJykpXG4gICAgICB9XG4gICAgICB2YXIgdGxzID0gcmVxdWlyZSgndGxzJylcbiAgICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICAgIHNvY2tldDogc2VsZi5zdHJlYW0sXG4gICAgICB9XG5cbiAgICAgIGlmIChzZWxmLnNzbCAhPT0gdHJ1ZSkge1xuICAgICAgICBPYmplY3QuYXNzaWduKG9wdGlvbnMsIHNlbGYuc3NsKVxuXG4gICAgICAgIGlmICgna2V5JyBpbiBzZWxmLnNzbCkge1xuICAgICAgICAgIG9wdGlvbnMua2V5ID0gc2VsZi5zc2wua2V5XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKG5ldC5pc0lQKGhvc3QpID09PSAwKSB7XG4gICAgICAgIG9wdGlvbnMuc2VydmVybmFtZSA9IGhvc3RcbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIHNlbGYuc3RyZWFtID0gdGxzLmNvbm5lY3Qob3B0aW9ucylcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICByZXR1cm4gc2VsZi5lbWl0KCdlcnJvcicsIGVycilcbiAgICAgIH1cbiAgICAgIHNlbGYuYXR0YWNoTGlzdGVuZXJzKHNlbGYuc3RyZWFtKVxuICAgICAgc2VsZi5zdHJlYW0ub24oJ2Vycm9yJywgcmVwb3J0U3RyZWFtRXJyb3IpXG5cbiAgICAgIHNlbGYuZW1pdCgnc3NsY29ubmVjdCcpXG4gICAgfSlcbiAgfVxuXG4gIGF0dGFjaExpc3RlbmVycyhzdHJlYW0pIHtcbiAgICBzdHJlYW0ub24oJ2VuZCcsICgpID0+IHtcbiAgICAgIHRoaXMuZW1pdCgnZW5kJylcbiAgICB9KVxuICAgIHBhcnNlKHN0cmVhbSwgKG1zZykgPT4ge1xuICAgICAgdmFyIGV2ZW50TmFtZSA9IG1zZy5uYW1lID09PSAnZXJyb3InID8gJ2Vycm9yTWVzc2FnZScgOiBtc2cubmFtZVxuICAgICAgaWYgKHRoaXMuX2VtaXRNZXNzYWdlKSB7XG4gICAgICAgIHRoaXMuZW1pdCgnbWVzc2FnZScsIG1zZylcbiAgICAgIH1cbiAgICAgIHRoaXMuZW1pdChldmVudE5hbWUsIG1zZylcbiAgICB9KVxuICB9XG5cbiAgcmVxdWVzdFNzbCgpIHtcbiAgICB0aGlzLnN0cmVhbS53cml0ZShzZXJpYWxpemUucmVxdWVzdFNzbCgpKVxuICB9XG5cbiAgc3RhcnR1cChjb25maWcpIHtcbiAgICB0aGlzLnN0cmVhbS53cml0ZShzZXJpYWxpemUuc3RhcnR1cChjb25maWcpKVxuICB9XG5cbiAgY2FuY2VsKHByb2Nlc3NJRCwgc2VjcmV0S2V5KSB7XG4gICAgdGhpcy5fc2VuZChzZXJpYWxpemUuY2FuY2VsKHByb2Nlc3NJRCwgc2VjcmV0S2V5KSlcbiAgfVxuXG4gIHBhc3N3b3JkKHBhc3N3b3JkKSB7XG4gICAgdGhpcy5fc2VuZChzZXJpYWxpemUucGFzc3dvcmQocGFzc3dvcmQpKVxuICB9XG5cbiAgc2VuZFNBU0xJbml0aWFsUmVzcG9uc2VNZXNzYWdlKG1lY2hhbmlzbSwgaW5pdGlhbFJlc3BvbnNlKSB7XG4gICAgdGhpcy5fc2VuZChzZXJpYWxpemUuc2VuZFNBU0xJbml0aWFsUmVzcG9uc2VNZXNzYWdlKG1lY2hhbmlzbSwgaW5pdGlhbFJlc3BvbnNlKSlcbiAgfVxuXG4gIHNlbmRTQ1JBTUNsaWVudEZpbmFsTWVzc2FnZShhZGRpdGlvbmFsRGF0YSkge1xuICAgIHRoaXMuX3NlbmQoc2VyaWFsaXplLnNlbmRTQ1JBTUNsaWVudEZpbmFsTWVzc2FnZShhZGRpdGlvbmFsRGF0YSkpXG4gIH1cblxuICBfc2VuZChidWZmZXIpIHtcbiAgICBpZiAoIXRoaXMuc3RyZWFtLndyaXRhYmxlKSB7XG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuc3RyZWFtLndyaXRlKGJ1ZmZlcilcbiAgfVxuXG4gIHF1ZXJ5KHRleHQpIHtcbiAgICB0aGlzLl9zZW5kKHNlcmlhbGl6ZS5xdWVyeSh0ZXh0KSlcbiAgfVxuXG4gIC8vIHNlbmQgcGFyc2UgbWVzc2FnZVxuICBwYXJzZShxdWVyeSkge1xuICAgIHRoaXMuX3NlbmQoc2VyaWFsaXplLnBhcnNlKHF1ZXJ5KSlcbiAgfVxuXG4gIC8vIHNlbmQgYmluZCBtZXNzYWdlXG4gIGJpbmQoY29uZmlnKSB7XG4gICAgdGhpcy5fc2VuZChzZXJpYWxpemUuYmluZChjb25maWcpKVxuICB9XG5cbiAgLy8gc2VuZCBleGVjdXRlIG1lc3NhZ2VcbiAgZXhlY3V0ZShjb25maWcpIHtcbiAgICB0aGlzLl9zZW5kKHNlcmlhbGl6ZS5leGVjdXRlKGNvbmZpZykpXG4gIH1cblxuICBmbHVzaCgpIHtcbiAgICBpZiAodGhpcy5zdHJlYW0ud3JpdGFibGUpIHtcbiAgICAgIHRoaXMuc3RyZWFtLndyaXRlKGZsdXNoQnVmZmVyKVxuICAgIH1cbiAgfVxuXG4gIHN5bmMoKSB7XG4gICAgdGhpcy5fZW5kaW5nID0gdHJ1ZVxuICAgIHRoaXMuX3NlbmQoZmx1c2hCdWZmZXIpXG4gICAgdGhpcy5fc2VuZChzeW5jQnVmZmVyKVxuICB9XG5cbiAgcmVmKCkge1xuICAgIHRoaXMuc3RyZWFtLnJlZigpXG4gIH1cblxuICB1bnJlZigpIHtcbiAgICB0aGlzLnN0cmVhbS51bnJlZigpXG4gIH1cblxuICBlbmQoKSB7XG4gICAgLy8gMHg1OCA9ICdYJ1xuICAgIHRoaXMuX2VuZGluZyA9IHRydWVcbiAgICBpZiAoIXRoaXMuX2Nvbm5lY3RpbmcgfHwgIXRoaXMuc3RyZWFtLndyaXRhYmxlKSB7XG4gICAgICB0aGlzLnN0cmVhbS5lbmQoKVxuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIHJldHVybiB0aGlzLnN0cmVhbS53cml0ZShlbmRCdWZmZXIsICgpID0+IHtcbiAgICAgIHRoaXMuc3RyZWFtLmVuZCgpXG4gICAgfSlcbiAgfVxuXG4gIGNsb3NlKG1zZykge1xuICAgIHRoaXMuX3NlbmQoc2VyaWFsaXplLmNsb3NlKG1zZykpXG4gIH1cblxuICBkZXNjcmliZShtc2cpIHtcbiAgICB0aGlzLl9zZW5kKHNlcmlhbGl6ZS5kZXNjcmliZShtc2cpKVxuICB9XG5cbiAgc2VuZENvcHlGcm9tQ2h1bmsoY2h1bmspIHtcbiAgICB0aGlzLl9zZW5kKHNlcmlhbGl6ZS5jb3B5RGF0YShjaHVuaykpXG4gIH1cblxuICBlbmRDb3B5RnJvbSgpIHtcbiAgICB0aGlzLl9zZW5kKHNlcmlhbGl6ZS5jb3B5RG9uZSgpKVxuICB9XG5cbiAgc2VuZENvcHlGYWlsKG1zZykge1xuICAgIHRoaXMuX3NlbmQoc2VyaWFsaXplLmNvcHlGYWlsKG1zZykpXG4gIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSBDb25uZWN0aW9uXG4iLCIndXNlIHN0cmljdCdcblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gIC8vIGRhdGFiYXNlIGhvc3QuIGRlZmF1bHRzIHRvIGxvY2FsaG9zdFxuICBob3N0OiAnbG9jYWxob3N0JyxcblxuICAvLyBkYXRhYmFzZSB1c2VyJ3MgbmFtZVxuICB1c2VyOiBwcm9jZXNzLnBsYXRmb3JtID09PSAnd2luMzInID8gcHJvY2Vzcy5lbnYuVVNFUk5BTUUgOiBwcm9jZXNzLmVudi5VU0VSLFxuXG4gIC8vIG5hbWUgb2YgZGF0YWJhc2UgdG8gY29ubmVjdFxuICBkYXRhYmFzZTogdW5kZWZpbmVkLFxuXG4gIC8vIGRhdGFiYXNlIHVzZXIncyBwYXNzd29yZFxuICBwYXNzd29yZDogbnVsbCxcblxuICAvLyBhIFBvc3RncmVzIGNvbm5lY3Rpb24gc3RyaW5nIHRvIGJlIHVzZWQgaW5zdGVhZCBvZiBzZXR0aW5nIGluZGl2aWR1YWwgY29ubmVjdGlvbiBpdGVtc1xuICAvLyBOT1RFOiAgU2V0dGluZyB0aGlzIHZhbHVlIHdpbGwgY2F1c2UgaXQgdG8gb3ZlcnJpZGUgYW55IG90aGVyIHZhbHVlIChzdWNoIGFzIGRhdGFiYXNlIG9yIHVzZXIpIGRlZmluZWRcbiAgLy8gaW4gdGhlIGRlZmF1bHRzIG9iamVjdC5cbiAgY29ubmVjdGlvblN0cmluZzogdW5kZWZpbmVkLFxuXG4gIC8vIGRhdGFiYXNlIHBvcnRcbiAgcG9ydDogNTQzMixcblxuICAvLyBudW1iZXIgb2Ygcm93cyB0byByZXR1cm4gYXQgYSB0aW1lIGZyb20gYSBwcmVwYXJlZCBzdGF0ZW1lbnQnc1xuICAvLyBwb3J0YWwuIDAgd2lsbCByZXR1cm4gYWxsIHJvd3MgYXQgb25jZVxuICByb3dzOiAwLFxuXG4gIC8vIGJpbmFyeSByZXN1bHQgbW9kZVxuICBiaW5hcnk6IGZhbHNlLFxuXG4gIC8vIENvbm5lY3Rpb24gcG9vbCBvcHRpb25zIC0gc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9icmlhbmMvbm9kZS1wZy1wb29sXG5cbiAgLy8gbnVtYmVyIG9mIGNvbm5lY3Rpb25zIHRvIHVzZSBpbiBjb25uZWN0aW9uIHBvb2xcbiAgLy8gMCB3aWxsIGRpc2FibGUgY29ubmVjdGlvbiBwb29saW5nXG4gIG1heDogMTAsXG5cbiAgLy8gbWF4IG1pbGxpc2Vjb25kcyBhIGNsaWVudCBjYW4gZ28gdW51c2VkIGJlZm9yZSBpdCBpcyByZW1vdmVkXG4gIC8vIGZyb20gdGhlIHBvb2wgYW5kIGRlc3Ryb3llZFxuICBpZGxlVGltZW91dE1pbGxpczogMzAwMDAsXG5cbiAgY2xpZW50X2VuY29kaW5nOiAnJyxcblxuICBzc2w6IGZhbHNlLFxuXG4gIGFwcGxpY2F0aW9uX25hbWU6IHVuZGVmaW5lZCxcblxuICBmYWxsYmFja19hcHBsaWNhdGlvbl9uYW1lOiB1bmRlZmluZWQsXG5cbiAgb3B0aW9uczogdW5kZWZpbmVkLFxuXG4gIHBhcnNlSW5wdXREYXRlc0FzVVRDOiBmYWxzZSxcblxuICAvLyBtYXggbWlsbGlzZWNvbmRzIGFueSBxdWVyeSB1c2luZyB0aGlzIGNvbm5lY3Rpb24gd2lsbCBleGVjdXRlIGZvciBiZWZvcmUgdGltaW5nIG91dCBpbiBlcnJvci5cbiAgLy8gZmFsc2U9dW5saW1pdGVkXG4gIHN0YXRlbWVudF90aW1lb3V0OiBmYWxzZSxcblxuICAvLyBUZXJtaW5hdGUgYW55IHNlc3Npb24gd2l0aCBhbiBvcGVuIHRyYW5zYWN0aW9uIHRoYXQgaGFzIGJlZW4gaWRsZSBmb3IgbG9uZ2VyIHRoYW4gdGhlIHNwZWNpZmllZCBkdXJhdGlvbiBpbiBtaWxsaXNlY29uZHNcbiAgLy8gZmFsc2U9dW5saW1pdGVkXG4gIGlkbGVfaW5fdHJhbnNhY3Rpb25fc2Vzc2lvbl90aW1lb3V0OiBmYWxzZSxcblxuICAvLyBtYXggbWlsbGlzZWNvbmRzIHRvIHdhaXQgZm9yIHF1ZXJ5IHRvIGNvbXBsZXRlIChjbGllbnQgc2lkZSlcbiAgcXVlcnlfdGltZW91dDogZmFsc2UsXG5cbiAgY29ubmVjdF90aW1lb3V0OiAwLFxuXG4gIGtlZXBhbGl2ZXM6IDEsXG5cbiAga2VlcGFsaXZlc19pZGxlOiAwLFxufVxuXG52YXIgcGdUeXBlcyA9IHJlcXVpcmUoJ3BnLXR5cGVzJylcbi8vIHNhdmUgZGVmYXVsdCBwYXJzZXJzXG52YXIgcGFyc2VCaWdJbnRlZ2VyID0gcGdUeXBlcy5nZXRUeXBlUGFyc2VyKDIwLCAndGV4dCcpXG52YXIgcGFyc2VCaWdJbnRlZ2VyQXJyYXkgPSBwZ1R5cGVzLmdldFR5cGVQYXJzZXIoMTAxNiwgJ3RleHQnKVxuXG4vLyBwYXJzZSBpbnQ4IHNvIHlvdSBjYW4gZ2V0IHlvdXIgY291bnQgdmFsdWVzIGFzIGFjdHVhbCBudW1iZXJzXG5tb2R1bGUuZXhwb3J0cy5fX2RlZmluZVNldHRlcl9fKCdwYXJzZUludDgnLCBmdW5jdGlvbiAodmFsKSB7XG4gIHBnVHlwZXMuc2V0VHlwZVBhcnNlcigyMCwgJ3RleHQnLCB2YWwgPyBwZ1R5cGVzLmdldFR5cGVQYXJzZXIoMjMsICd0ZXh0JykgOiBwYXJzZUJpZ0ludGVnZXIpXG4gIHBnVHlwZXMuc2V0VHlwZVBhcnNlcigxMDE2LCAndGV4dCcsIHZhbCA/IHBnVHlwZXMuZ2V0VHlwZVBhcnNlcigxMDA3LCAndGV4dCcpIDogcGFyc2VCaWdJbnRlZ2VyQXJyYXkpXG59KVxuIiwiJ3VzZSBzdHJpY3QnXG5cbnZhciBDbGllbnQgPSByZXF1aXJlKCcuL2NsaWVudCcpXG52YXIgZGVmYXVsdHMgPSByZXF1aXJlKCcuL2RlZmF1bHRzJylcbnZhciBDb25uZWN0aW9uID0gcmVxdWlyZSgnLi9jb25uZWN0aW9uJylcbnZhciBQb29sID0gcmVxdWlyZSgncGctcG9vbCcpXG5jb25zdCB7IERhdGFiYXNlRXJyb3IgfSA9IHJlcXVpcmUoJ3BnLXByb3RvY29sJylcblxuY29uc3QgcG9vbEZhY3RvcnkgPSAoQ2xpZW50KSA9PiB7XG4gIHJldHVybiBjbGFzcyBCb3VuZFBvb2wgZXh0ZW5kcyBQb29sIHtcbiAgICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG4gICAgICBzdXBlcihvcHRpb25zLCBDbGllbnQpXG4gICAgfVxuICB9XG59XG5cbnZhciBQRyA9IGZ1bmN0aW9uIChjbGllbnRDb25zdHJ1Y3Rvcikge1xuICB0aGlzLmRlZmF1bHRzID0gZGVmYXVsdHNcbiAgdGhpcy5DbGllbnQgPSBjbGllbnRDb25zdHJ1Y3RvclxuICB0aGlzLlF1ZXJ5ID0gdGhpcy5DbGllbnQuUXVlcnlcbiAgdGhpcy5Qb29sID0gcG9vbEZhY3RvcnkodGhpcy5DbGllbnQpXG4gIHRoaXMuX3Bvb2xzID0gW11cbiAgdGhpcy5Db25uZWN0aW9uID0gQ29ubmVjdGlvblxuICB0aGlzLnR5cGVzID0gcmVxdWlyZSgncGctdHlwZXMnKVxuICB0aGlzLkRhdGFiYXNlRXJyb3IgPSBEYXRhYmFzZUVycm9yXG59XG5cbmlmICh0eXBlb2YgcHJvY2Vzcy5lbnYuTk9ERV9QR19GT1JDRV9OQVRJVkUgIT09ICd1bmRlZmluZWQnKSB7XG4gIG1vZHVsZS5leHBvcnRzID0gbmV3IFBHKHJlcXVpcmUoJy4vbmF0aXZlJykpXG59IGVsc2Uge1xuICBtb2R1bGUuZXhwb3J0cyA9IG5ldyBQRyhDbGllbnQpXG5cbiAgLy8gbGF6eSByZXF1aXJlIG5hdGl2ZSBtb2R1bGUuLi50aGUgbmF0aXZlIG1vZHVsZSBtYXkgbm90IGhhdmUgaW5zdGFsbGVkXG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShtb2R1bGUuZXhwb3J0cywgJ25hdGl2ZScsIHtcbiAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgZ2V0KCkge1xuICAgICAgdmFyIG5hdGl2ZSA9IG51bGxcbiAgICAgIHRyeSB7XG4gICAgICAgIG5hdGl2ZSA9IG5ldyBQRyhyZXF1aXJlKCcuL25hdGl2ZScpKVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGlmIChlcnIuY29kZSAhPT0gJ01PRFVMRV9OT1RfRk9VTkQnKSB7XG4gICAgICAgICAgdGhyb3cgZXJyXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gb3ZlcndyaXRlIG1vZHVsZS5leHBvcnRzLm5hdGl2ZSBzbyB0aGF0IGdldHRlciBpcyBuZXZlciBjYWxsZWQgYWdhaW5cbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShtb2R1bGUuZXhwb3J0cywgJ25hdGl2ZScsIHtcbiAgICAgICAgdmFsdWU6IG5hdGl2ZSxcbiAgICAgIH0pXG5cbiAgICAgIHJldHVybiBuYXRpdmVcbiAgICB9LFxuICB9KVxufVxuIiwiJ3VzZSBzdHJpY3QnXG5cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZVxudmFyIE5hdGl2ZSA9IHJlcXVpcmUoJ3BnLW5hdGl2ZScpXG52YXIgVHlwZU92ZXJyaWRlcyA9IHJlcXVpcmUoJy4uL3R5cGUtb3ZlcnJpZGVzJylcbnZhciBwa2cgPSByZXF1aXJlKCcuLi8uLi9wYWNrYWdlLmpzb24nKVxudmFyIEV2ZW50RW1pdHRlciA9IHJlcXVpcmUoJ2V2ZW50cycpLkV2ZW50RW1pdHRlclxudmFyIHV0aWwgPSByZXF1aXJlKCd1dGlsJylcbnZhciBDb25uZWN0aW9uUGFyYW1ldGVycyA9IHJlcXVpcmUoJy4uL2Nvbm5lY3Rpb24tcGFyYW1ldGVycycpXG5cbnZhciBOYXRpdmVRdWVyeSA9IHJlcXVpcmUoJy4vcXVlcnknKVxuXG52YXIgQ2xpZW50ID0gKG1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKGNvbmZpZykge1xuICBFdmVudEVtaXR0ZXIuY2FsbCh0aGlzKVxuICBjb25maWcgPSBjb25maWcgfHwge31cblxuICB0aGlzLl9Qcm9taXNlID0gY29uZmlnLlByb21pc2UgfHwgZ2xvYmFsLlByb21pc2VcbiAgdGhpcy5fdHlwZXMgPSBuZXcgVHlwZU92ZXJyaWRlcyhjb25maWcudHlwZXMpXG5cbiAgdGhpcy5uYXRpdmUgPSBuZXcgTmF0aXZlKHtcbiAgICB0eXBlczogdGhpcy5fdHlwZXMsXG4gIH0pXG5cbiAgdGhpcy5fcXVlcnlRdWV1ZSA9IFtdXG4gIHRoaXMuX2VuZGluZyA9IGZhbHNlXG4gIHRoaXMuX2Nvbm5lY3RpbmcgPSBmYWxzZVxuICB0aGlzLl9jb25uZWN0ZWQgPSBmYWxzZVxuICB0aGlzLl9xdWVyeWFibGUgPSB0cnVlXG5cbiAgLy8ga2VlcCB0aGVzZSBvbiB0aGUgb2JqZWN0IGZvciBsZWdhY3kgcmVhc29uc1xuICAvLyBmb3IgdGhlIHRpbWUgYmVpbmcuIFRPRE86IGRlcHJlY2F0ZSBhbGwgdGhpcyBqYXp6XG4gIHZhciBjcCA9ICh0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzID0gbmV3IENvbm5lY3Rpb25QYXJhbWV0ZXJzKGNvbmZpZykpXG4gIHRoaXMudXNlciA9IGNwLnVzZXJcblxuICAvLyBcImhpZGluZ1wiIHRoZSBwYXNzd29yZCBzbyBpdCBkb2Vzbid0IHNob3cgdXAgaW4gc3RhY2sgdHJhY2VzXG4gIC8vIG9yIGlmIHRoZSBjbGllbnQgaXMgY29uc29sZS5sb2dnZWRcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsICdwYXNzd29yZCcsIHtcbiAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgd3JpdGFibGU6IHRydWUsXG4gICAgdmFsdWU6IGNwLnBhc3N3b3JkLFxuICB9KVxuICB0aGlzLmRhdGFiYXNlID0gY3AuZGF0YWJhc2VcbiAgdGhpcy5ob3N0ID0gY3AuaG9zdFxuICB0aGlzLnBvcnQgPSBjcC5wb3J0XG5cbiAgLy8gYSBoYXNoIHRvIGhvbGQgbmFtZWQgcXVlcmllc1xuICB0aGlzLm5hbWVkUXVlcmllcyA9IHt9XG59KVxuXG5DbGllbnQuUXVlcnkgPSBOYXRpdmVRdWVyeVxuXG51dGlsLmluaGVyaXRzKENsaWVudCwgRXZlbnRFbWl0dGVyKVxuXG5DbGllbnQucHJvdG90eXBlLl9lcnJvckFsbFF1ZXJpZXMgPSBmdW5jdGlvbiAoZXJyKSB7XG4gIGNvbnN0IGVucXVldWVFcnJvciA9IChxdWVyeSkgPT4ge1xuICAgIHByb2Nlc3MubmV4dFRpY2soKCkgPT4ge1xuICAgICAgcXVlcnkubmF0aXZlID0gdGhpcy5uYXRpdmVcbiAgICAgIHF1ZXJ5LmhhbmRsZUVycm9yKGVycilcbiAgICB9KVxuICB9XG5cbiAgaWYgKHRoaXMuX2hhc0FjdGl2ZVF1ZXJ5KCkpIHtcbiAgICBlbnF1ZXVlRXJyb3IodGhpcy5fYWN0aXZlUXVlcnkpXG4gICAgdGhpcy5fYWN0aXZlUXVlcnkgPSBudWxsXG4gIH1cblxuICB0aGlzLl9xdWVyeVF1ZXVlLmZvckVhY2goZW5xdWV1ZUVycm9yKVxuICB0aGlzLl9xdWVyeVF1ZXVlLmxlbmd0aCA9IDBcbn1cblxuLy8gY29ubmVjdCB0byB0aGUgYmFja2VuZFxuLy8gcGFzcyBhbiBvcHRpb25hbCBjYWxsYmFjayB0byBiZSBjYWxsZWQgb25jZSBjb25uZWN0ZWRcbi8vIG9yIHdpdGggYW4gZXJyb3IgaWYgdGhlcmUgd2FzIGEgY29ubmVjdGlvbiBlcnJvclxuQ2xpZW50LnByb3RvdHlwZS5fY29ubmVjdCA9IGZ1bmN0aW9uIChjYikge1xuICB2YXIgc2VsZiA9IHRoaXNcblxuICBpZiAodGhpcy5fY29ubmVjdGluZykge1xuICAgIHByb2Nlc3MubmV4dFRpY2soKCkgPT4gY2IobmV3IEVycm9yKCdDbGllbnQgaGFzIGFscmVhZHkgYmVlbiBjb25uZWN0ZWQuIFlvdSBjYW5ub3QgcmV1c2UgYSBjbGllbnQuJykpKVxuICAgIHJldHVyblxuICB9XG5cbiAgdGhpcy5fY29ubmVjdGluZyA9IHRydWVcblxuICB0aGlzLmNvbm5lY3Rpb25QYXJhbWV0ZXJzLmdldExpYnBxQ29ubmVjdGlvblN0cmluZyhmdW5jdGlvbiAoZXJyLCBjb25TdHJpbmcpIHtcbiAgICBpZiAoZXJyKSByZXR1cm4gY2IoZXJyKVxuICAgIHNlbGYubmF0aXZlLmNvbm5lY3QoY29uU3RyaW5nLCBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICBpZiAoZXJyKSB7XG4gICAgICAgIHNlbGYubmF0aXZlLmVuZCgpXG4gICAgICAgIHJldHVybiBjYihlcnIpXG4gICAgICB9XG5cbiAgICAgIC8vIHNldCBpbnRlcm5hbCBzdGF0ZXMgdG8gY29ubmVjdGVkXG4gICAgICBzZWxmLl9jb25uZWN0ZWQgPSB0cnVlXG5cbiAgICAgIC8vIGhhbmRsZSBjb25uZWN0aW9uIGVycm9ycyBmcm9tIHRoZSBuYXRpdmUgbGF5ZXJcbiAgICAgIHNlbGYubmF0aXZlLm9uKCdlcnJvcicsIGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgc2VsZi5fcXVlcnlhYmxlID0gZmFsc2VcbiAgICAgICAgc2VsZi5fZXJyb3JBbGxRdWVyaWVzKGVycilcbiAgICAgICAgc2VsZi5lbWl0KCdlcnJvcicsIGVycilcbiAgICAgIH0pXG5cbiAgICAgIHNlbGYubmF0aXZlLm9uKCdub3RpZmljYXRpb24nLCBmdW5jdGlvbiAobXNnKSB7XG4gICAgICAgIHNlbGYuZW1pdCgnbm90aWZpY2F0aW9uJywge1xuICAgICAgICAgIGNoYW5uZWw6IG1zZy5yZWxuYW1lLFxuICAgICAgICAgIHBheWxvYWQ6IG1zZy5leHRyYSxcbiAgICAgICAgfSlcbiAgICAgIH0pXG5cbiAgICAgIC8vIHNpZ25hbCB3ZSBhcmUgY29ubmVjdGVkIG5vd1xuICAgICAgc2VsZi5lbWl0KCdjb25uZWN0JylcbiAgICAgIHNlbGYuX3B1bHNlUXVlcnlRdWV1ZSh0cnVlKVxuXG4gICAgICBjYigpXG4gICAgfSlcbiAgfSlcbn1cblxuQ2xpZW50LnByb3RvdHlwZS5jb25uZWN0ID0gZnVuY3Rpb24gKGNhbGxiYWNrKSB7XG4gIGlmIChjYWxsYmFjaykge1xuICAgIHRoaXMuX2Nvbm5lY3QoY2FsbGJhY2spXG4gICAgcmV0dXJuXG4gIH1cblxuICByZXR1cm4gbmV3IHRoaXMuX1Byb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIHRoaXMuX2Nvbm5lY3QoKGVycm9yKSA9PiB7XG4gICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgcmVqZWN0KGVycm9yKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmVzb2x2ZSgpXG4gICAgICB9XG4gICAgfSlcbiAgfSlcbn1cblxuLy8gc2VuZCBhIHF1ZXJ5IHRvIHRoZSBzZXJ2ZXJcbi8vIHRoaXMgbWV0aG9kIGlzIGhpZ2hseSBvdmVybG9hZGVkIHRvIHRha2Vcbi8vIDEpIHN0cmluZyBxdWVyeSwgb3B0aW9uYWwgYXJyYXkgb2YgcGFyYW1ldGVycywgb3B0aW9uYWwgZnVuY3Rpb24gY2FsbGJhY2tcbi8vIDIpIG9iamVjdCBxdWVyeSB3aXRoIHtcbi8vICAgIHN0cmluZyBxdWVyeVxuLy8gICAgb3B0aW9uYWwgYXJyYXkgdmFsdWVzLFxuLy8gICAgb3B0aW9uYWwgZnVuY3Rpb24gY2FsbGJhY2sgaW5zdGVhZCBvZiBhcyBhIHNlcGFyYXRlIHBhcmFtZXRlclxuLy8gICAgb3B0aW9uYWwgc3RyaW5nIG5hbWUgdG8gbmFtZSAmIGNhY2hlIHRoZSBxdWVyeSBwbGFuXG4vLyAgICBvcHRpb25hbCBzdHJpbmcgcm93TW9kZSA9ICdhcnJheScgZm9yIGFuIGFycmF5IG9mIHJlc3VsdHNcbi8vICB9XG5DbGllbnQucHJvdG90eXBlLnF1ZXJ5ID0gZnVuY3Rpb24gKGNvbmZpZywgdmFsdWVzLCBjYWxsYmFjaykge1xuICB2YXIgcXVlcnlcbiAgdmFyIHJlc3VsdFxuICB2YXIgcmVhZFRpbWVvdXRcbiAgdmFyIHJlYWRUaW1lb3V0VGltZXJcbiAgdmFyIHF1ZXJ5Q2FsbGJhY2tcblxuICBpZiAoY29uZmlnID09PSBudWxsIHx8IGNvbmZpZyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignQ2xpZW50IHdhcyBwYXNzZWQgYSBudWxsIG9yIHVuZGVmaW5lZCBxdWVyeScpXG4gIH0gZWxzZSBpZiAodHlwZW9mIGNvbmZpZy5zdWJtaXQgPT09ICdmdW5jdGlvbicpIHtcbiAgICByZWFkVGltZW91dCA9IGNvbmZpZy5xdWVyeV90aW1lb3V0IHx8IHRoaXMuY29ubmVjdGlvblBhcmFtZXRlcnMucXVlcnlfdGltZW91dFxuICAgIHJlc3VsdCA9IHF1ZXJ5ID0gY29uZmlnXG4gICAgLy8gYWNjZXB0IHF1ZXJ5KG5ldyBRdWVyeSguLi4pLCAoZXJyLCByZXMpID0+IHsgfSkgc3R5bGVcbiAgICBpZiAodHlwZW9mIHZhbHVlcyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgY29uZmlnLmNhbGxiYWNrID0gdmFsdWVzXG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHJlYWRUaW1lb3V0ID0gdGhpcy5jb25uZWN0aW9uUGFyYW1ldGVycy5xdWVyeV90aW1lb3V0XG4gICAgcXVlcnkgPSBuZXcgTmF0aXZlUXVlcnkoY29uZmlnLCB2YWx1ZXMsIGNhbGxiYWNrKVxuICAgIGlmICghcXVlcnkuY2FsbGJhY2spIHtcbiAgICAgIGxldCByZXNvbHZlT3V0LCByZWplY3RPdXRcbiAgICAgIHJlc3VsdCA9IG5ldyB0aGlzLl9Qcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgcmVzb2x2ZU91dCA9IHJlc29sdmVcbiAgICAgICAgcmVqZWN0T3V0ID0gcmVqZWN0XG4gICAgICB9KVxuICAgICAgcXVlcnkuY2FsbGJhY2sgPSAoZXJyLCByZXMpID0+IChlcnIgPyByZWplY3RPdXQoZXJyKSA6IHJlc29sdmVPdXQocmVzKSlcbiAgICB9XG4gIH1cblxuICBpZiAocmVhZFRpbWVvdXQpIHtcbiAgICBxdWVyeUNhbGxiYWNrID0gcXVlcnkuY2FsbGJhY2tcblxuICAgIHJlYWRUaW1lb3V0VGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHZhciBlcnJvciA9IG5ldyBFcnJvcignUXVlcnkgcmVhZCB0aW1lb3V0JylcblxuICAgICAgcHJvY2Vzcy5uZXh0VGljaygoKSA9PiB7XG4gICAgICAgIHF1ZXJ5LmhhbmRsZUVycm9yKGVycm9yLCB0aGlzLmNvbm5lY3Rpb24pXG4gICAgICB9KVxuXG4gICAgICBxdWVyeUNhbGxiYWNrKGVycm9yKVxuXG4gICAgICAvLyB3ZSBhbHJlYWR5IHJldHVybmVkIGFuIGVycm9yLFxuICAgICAgLy8ganVzdCBkbyBub3RoaW5nIGlmIHF1ZXJ5IGNvbXBsZXRlc1xuICAgICAgcXVlcnkuY2FsbGJhY2sgPSAoKSA9PiB7fVxuXG4gICAgICAvLyBSZW1vdmUgZnJvbSBxdWV1ZVxuICAgICAgdmFyIGluZGV4ID0gdGhpcy5fcXVlcnlRdWV1ZS5pbmRleE9mKHF1ZXJ5KVxuICAgICAgaWYgKGluZGV4ID4gLTEpIHtcbiAgICAgICAgdGhpcy5fcXVlcnlRdWV1ZS5zcGxpY2UoaW5kZXgsIDEpXG4gICAgICB9XG5cbiAgICAgIHRoaXMuX3B1bHNlUXVlcnlRdWV1ZSgpXG4gICAgfSwgcmVhZFRpbWVvdXQpXG5cbiAgICBxdWVyeS5jYWxsYmFjayA9IChlcnIsIHJlcykgPT4ge1xuICAgICAgY2xlYXJUaW1lb3V0KHJlYWRUaW1lb3V0VGltZXIpXG4gICAgICBxdWVyeUNhbGxiYWNrKGVyciwgcmVzKVxuICAgIH1cbiAgfVxuXG4gIGlmICghdGhpcy5fcXVlcnlhYmxlKSB7XG4gICAgcXVlcnkubmF0aXZlID0gdGhpcy5uYXRpdmVcbiAgICBwcm9jZXNzLm5leHRUaWNrKCgpID0+IHtcbiAgICAgIHF1ZXJ5LmhhbmRsZUVycm9yKG5ldyBFcnJvcignQ2xpZW50IGhhcyBlbmNvdW50ZXJlZCBhIGNvbm5lY3Rpb24gZXJyb3IgYW5kIGlzIG5vdCBxdWVyeWFibGUnKSlcbiAgICB9KVxuICAgIHJldHVybiByZXN1bHRcbiAgfVxuXG4gIGlmICh0aGlzLl9lbmRpbmcpIHtcbiAgICBxdWVyeS5uYXRpdmUgPSB0aGlzLm5hdGl2ZVxuICAgIHByb2Nlc3MubmV4dFRpY2soKCkgPT4ge1xuICAgICAgcXVlcnkuaGFuZGxlRXJyb3IobmV3IEVycm9yKCdDbGllbnQgd2FzIGNsb3NlZCBhbmQgaXMgbm90IHF1ZXJ5YWJsZScpKVxuICAgIH0pXG4gICAgcmV0dXJuIHJlc3VsdFxuICB9XG5cbiAgdGhpcy5fcXVlcnlRdWV1ZS5wdXNoKHF1ZXJ5KVxuICB0aGlzLl9wdWxzZVF1ZXJ5UXVldWUoKVxuICByZXR1cm4gcmVzdWx0XG59XG5cbi8vIGRpc2Nvbm5lY3QgZnJvbSB0aGUgYmFja2VuZCBzZXJ2ZXJcbkNsaWVudC5wcm90b3R5cGUuZW5kID0gZnVuY3Rpb24gKGNiKSB7XG4gIHZhciBzZWxmID0gdGhpc1xuXG4gIHRoaXMuX2VuZGluZyA9IHRydWVcblxuICBpZiAoIXRoaXMuX2Nvbm5lY3RlZCkge1xuICAgIHRoaXMub25jZSgnY29ubmVjdCcsIHRoaXMuZW5kLmJpbmQodGhpcywgY2IpKVxuICB9XG4gIHZhciByZXN1bHRcbiAgaWYgKCFjYikge1xuICAgIHJlc3VsdCA9IG5ldyB0aGlzLl9Qcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgIGNiID0gKGVycikgPT4gKGVyciA/IHJlamVjdChlcnIpIDogcmVzb2x2ZSgpKVxuICAgIH0pXG4gIH1cbiAgdGhpcy5uYXRpdmUuZW5kKGZ1bmN0aW9uICgpIHtcbiAgICBzZWxmLl9lcnJvckFsbFF1ZXJpZXMobmV3IEVycm9yKCdDb25uZWN0aW9uIHRlcm1pbmF0ZWQnKSlcblxuICAgIHByb2Nlc3MubmV4dFRpY2soKCkgPT4ge1xuICAgICAgc2VsZi5lbWl0KCdlbmQnKVxuICAgICAgaWYgKGNiKSBjYigpXG4gICAgfSlcbiAgfSlcbiAgcmV0dXJuIHJlc3VsdFxufVxuXG5DbGllbnQucHJvdG90eXBlLl9oYXNBY3RpdmVRdWVyeSA9IGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIHRoaXMuX2FjdGl2ZVF1ZXJ5ICYmIHRoaXMuX2FjdGl2ZVF1ZXJ5LnN0YXRlICE9PSAnZXJyb3InICYmIHRoaXMuX2FjdGl2ZVF1ZXJ5LnN0YXRlICE9PSAnZW5kJ1xufVxuXG5DbGllbnQucHJvdG90eXBlLl9wdWxzZVF1ZXJ5UXVldWUgPSBmdW5jdGlvbiAoaW5pdGlhbENvbm5lY3Rpb24pIHtcbiAgaWYgKCF0aGlzLl9jb25uZWN0ZWQpIHtcbiAgICByZXR1cm5cbiAgfVxuICBpZiAodGhpcy5faGFzQWN0aXZlUXVlcnkoKSkge1xuICAgIHJldHVyblxuICB9XG4gIHZhciBxdWVyeSA9IHRoaXMuX3F1ZXJ5UXVldWUuc2hpZnQoKVxuICBpZiAoIXF1ZXJ5KSB7XG4gICAgaWYgKCFpbml0aWFsQ29ubmVjdGlvbikge1xuICAgICAgdGhpcy5lbWl0KCdkcmFpbicpXG4gICAgfVxuICAgIHJldHVyblxuICB9XG4gIHRoaXMuX2FjdGl2ZVF1ZXJ5ID0gcXVlcnlcbiAgcXVlcnkuc3VibWl0KHRoaXMpXG4gIHZhciBzZWxmID0gdGhpc1xuICBxdWVyeS5vbmNlKCdfZG9uZScsIGZ1bmN0aW9uICgpIHtcbiAgICBzZWxmLl9wdWxzZVF1ZXJ5UXVldWUoKVxuICB9KVxufVxuXG4vLyBhdHRlbXB0IHRvIGNhbmNlbCBhbiBpbi1wcm9ncmVzcyBxdWVyeVxuQ2xpZW50LnByb3RvdHlwZS5jYW5jZWwgPSBmdW5jdGlvbiAocXVlcnkpIHtcbiAgaWYgKHRoaXMuX2FjdGl2ZVF1ZXJ5ID09PSBxdWVyeSkge1xuICAgIHRoaXMubmF0aXZlLmNhbmNlbChmdW5jdGlvbiAoKSB7fSlcbiAgfSBlbHNlIGlmICh0aGlzLl9xdWVyeVF1ZXVlLmluZGV4T2YocXVlcnkpICE9PSAtMSkge1xuICAgIHRoaXMuX3F1ZXJ5UXVldWUuc3BsaWNlKHRoaXMuX3F1ZXJ5UXVldWUuaW5kZXhPZihxdWVyeSksIDEpXG4gIH1cbn1cblxuQ2xpZW50LnByb3RvdHlwZS5yZWYgPSBmdW5jdGlvbiAoKSB7fVxuQ2xpZW50LnByb3RvdHlwZS51bnJlZiA9IGZ1bmN0aW9uICgpIHt9XG5cbkNsaWVudC5wcm90b3R5cGUuc2V0VHlwZVBhcnNlciA9IGZ1bmN0aW9uIChvaWQsIGZvcm1hdCwgcGFyc2VGbikge1xuICByZXR1cm4gdGhpcy5fdHlwZXMuc2V0VHlwZVBhcnNlcihvaWQsIGZvcm1hdCwgcGFyc2VGbilcbn1cblxuQ2xpZW50LnByb3RvdHlwZS5nZXRUeXBlUGFyc2VyID0gZnVuY3Rpb24gKG9pZCwgZm9ybWF0KSB7XG4gIHJldHVybiB0aGlzLl90eXBlcy5nZXRUeXBlUGFyc2VyKG9pZCwgZm9ybWF0KVxufVxuIiwiJ3VzZSBzdHJpY3QnXG5tb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vY2xpZW50JylcbiIsIid1c2Ugc3RyaWN0J1xuXG52YXIgRXZlbnRFbWl0dGVyID0gcmVxdWlyZSgnZXZlbnRzJykuRXZlbnRFbWl0dGVyXG52YXIgdXRpbCA9IHJlcXVpcmUoJ3V0aWwnKVxudmFyIHV0aWxzID0gcmVxdWlyZSgnLi4vdXRpbHMnKVxuXG52YXIgTmF0aXZlUXVlcnkgPSAobW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoY29uZmlnLCB2YWx1ZXMsIGNhbGxiYWNrKSB7XG4gIEV2ZW50RW1pdHRlci5jYWxsKHRoaXMpXG4gIGNvbmZpZyA9IHV0aWxzLm5vcm1hbGl6ZVF1ZXJ5Q29uZmlnKGNvbmZpZywgdmFsdWVzLCBjYWxsYmFjaylcbiAgdGhpcy50ZXh0ID0gY29uZmlnLnRleHRcbiAgdGhpcy52YWx1ZXMgPSBjb25maWcudmFsdWVzXG4gIHRoaXMubmFtZSA9IGNvbmZpZy5uYW1lXG4gIHRoaXMuY2FsbGJhY2sgPSBjb25maWcuY2FsbGJhY2tcbiAgdGhpcy5zdGF0ZSA9ICduZXcnXG4gIHRoaXMuX2FycmF5TW9kZSA9IGNvbmZpZy5yb3dNb2RlID09PSAnYXJyYXknXG5cbiAgLy8gaWYgdGhlICdyb3cnIGV2ZW50IGlzIGxpc3RlbmVkIGZvclxuICAvLyB0aGVuIGVtaXQgdGhlbSBhcyB0aGV5IGNvbWUgaW5cbiAgLy8gd2l0aG91dCBzZXR0aW5nIHNpbmdsZVJvd01vZGUgdG8gdHJ1ZVxuICAvLyB0aGlzIGhhcyBhbG1vc3Qgbm8gbWVhbmluZyBiZWNhdXNlIGxpYnBxXG4gIC8vIHJlYWRzIGFsbCByb3dzIGludG8gbWVtb3J5IGJlZm9yIHJldHVybmluZyBhbnlcbiAgdGhpcy5fZW1pdFJvd0V2ZW50cyA9IGZhbHNlXG4gIHRoaXMub24oXG4gICAgJ25ld0xpc3RlbmVyJyxcbiAgICBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgIGlmIChldmVudCA9PT0gJ3JvdycpIHRoaXMuX2VtaXRSb3dFdmVudHMgPSB0cnVlXG4gICAgfS5iaW5kKHRoaXMpXG4gIClcbn0pXG5cbnV0aWwuaW5oZXJpdHMoTmF0aXZlUXVlcnksIEV2ZW50RW1pdHRlcilcblxudmFyIGVycm9yRmllbGRNYXAgPSB7XG4gIC8qIGVzbGludC1kaXNhYmxlIHF1b3RlLXByb3BzICovXG4gIHNxbFN0YXRlOiAnY29kZScsXG4gIHN0YXRlbWVudFBvc2l0aW9uOiAncG9zaXRpb24nLFxuICBtZXNzYWdlUHJpbWFyeTogJ21lc3NhZ2UnLFxuICBjb250ZXh0OiAnd2hlcmUnLFxuICBzY2hlbWFOYW1lOiAnc2NoZW1hJyxcbiAgdGFibGVOYW1lOiAndGFibGUnLFxuICBjb2x1bW5OYW1lOiAnY29sdW1uJyxcbiAgZGF0YVR5cGVOYW1lOiAnZGF0YVR5cGUnLFxuICBjb25zdHJhaW50TmFtZTogJ2NvbnN0cmFpbnQnLFxuICBzb3VyY2VGaWxlOiAnZmlsZScsXG4gIHNvdXJjZUxpbmU6ICdsaW5lJyxcbiAgc291cmNlRnVuY3Rpb246ICdyb3V0aW5lJyxcbn1cblxuTmF0aXZlUXVlcnkucHJvdG90eXBlLmhhbmRsZUVycm9yID0gZnVuY3Rpb24gKGVycikge1xuICAvLyBjb3B5IHBxIGVycm9yIGZpZWxkcyBpbnRvIHRoZSBlcnJvciBvYmplY3RcbiAgdmFyIGZpZWxkcyA9IHRoaXMubmF0aXZlLnBxLnJlc3VsdEVycm9yRmllbGRzKClcbiAgaWYgKGZpZWxkcykge1xuICAgIGZvciAodmFyIGtleSBpbiBmaWVsZHMpIHtcbiAgICAgIHZhciBub3JtYWxpemVkRmllbGROYW1lID0gZXJyb3JGaWVsZE1hcFtrZXldIHx8IGtleVxuICAgICAgZXJyW25vcm1hbGl6ZWRGaWVsZE5hbWVdID0gZmllbGRzW2tleV1cbiAgICB9XG4gIH1cbiAgaWYgKHRoaXMuY2FsbGJhY2spIHtcbiAgICB0aGlzLmNhbGxiYWNrKGVycilcbiAgfSBlbHNlIHtcbiAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKVxuICB9XG4gIHRoaXMuc3RhdGUgPSAnZXJyb3InXG59XG5cbk5hdGl2ZVF1ZXJ5LnByb3RvdHlwZS50aGVuID0gZnVuY3Rpb24gKG9uU3VjY2Vzcywgb25GYWlsdXJlKSB7XG4gIHJldHVybiB0aGlzLl9nZXRQcm9taXNlKCkudGhlbihvblN1Y2Nlc3MsIG9uRmFpbHVyZSlcbn1cblxuTmF0aXZlUXVlcnkucHJvdG90eXBlLmNhdGNoID0gZnVuY3Rpb24gKGNhbGxiYWNrKSB7XG4gIHJldHVybiB0aGlzLl9nZXRQcm9taXNlKCkuY2F0Y2goY2FsbGJhY2spXG59XG5cbk5hdGl2ZVF1ZXJ5LnByb3RvdHlwZS5fZ2V0UHJvbWlzZSA9IGZ1bmN0aW9uICgpIHtcbiAgaWYgKHRoaXMuX3Byb21pc2UpIHJldHVybiB0aGlzLl9wcm9taXNlXG4gIHRoaXMuX3Byb21pc2UgPSBuZXcgUHJvbWlzZShcbiAgICBmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICB0aGlzLl9vbmNlKCdlbmQnLCByZXNvbHZlKVxuICAgICAgdGhpcy5fb25jZSgnZXJyb3InLCByZWplY3QpXG4gICAgfS5iaW5kKHRoaXMpXG4gIClcbiAgcmV0dXJuIHRoaXMuX3Byb21pc2Vcbn1cblxuTmF0aXZlUXVlcnkucHJvdG90eXBlLnN1Ym1pdCA9IGZ1bmN0aW9uIChjbGllbnQpIHtcbiAgdGhpcy5zdGF0ZSA9ICdydW5uaW5nJ1xuICB2YXIgc2VsZiA9IHRoaXNcbiAgdGhpcy5uYXRpdmUgPSBjbGllbnQubmF0aXZlXG4gIGNsaWVudC5uYXRpdmUuYXJyYXlNb2RlID0gdGhpcy5fYXJyYXlNb2RlXG5cbiAgdmFyIGFmdGVyID0gZnVuY3Rpb24gKGVyciwgcm93cywgcmVzdWx0cykge1xuICAgIGNsaWVudC5uYXRpdmUuYXJyYXlNb2RlID0gZmFsc2VcbiAgICBzZXRJbW1lZGlhdGUoZnVuY3Rpb24gKCkge1xuICAgICAgc2VsZi5lbWl0KCdfZG9uZScpXG4gICAgfSlcblxuICAgIC8vIGhhbmRsZSBwb3NzaWJsZSBxdWVyeSBlcnJvclxuICAgIGlmIChlcnIpIHtcbiAgICAgIHJldHVybiBzZWxmLmhhbmRsZUVycm9yKGVycilcbiAgICB9XG5cbiAgICAvLyBlbWl0IHJvdyBldmVudHMgZm9yIGVhY2ggcm93IGluIHRoZSByZXN1bHRcbiAgICBpZiAoc2VsZi5fZW1pdFJvd0V2ZW50cykge1xuICAgICAgaWYgKHJlc3VsdHMubGVuZ3RoID4gMSkge1xuICAgICAgICByb3dzLmZvckVhY2goKHJvd09mUm93cywgaSkgPT4ge1xuICAgICAgICAgIHJvd09mUm93cy5mb3JFYWNoKChyb3cpID0+IHtcbiAgICAgICAgICAgIHNlbGYuZW1pdCgncm93Jywgcm93LCByZXN1bHRzW2ldKVxuICAgICAgICAgIH0pXG4gICAgICAgIH0pXG4gICAgICB9IGVsc2Uge1xuICAgICAgICByb3dzLmZvckVhY2goZnVuY3Rpb24gKHJvdykge1xuICAgICAgICAgIHNlbGYuZW1pdCgncm93Jywgcm93LCByZXN1bHRzKVxuICAgICAgICB9KVxuICAgICAgfVxuICAgIH1cblxuICAgIC8vIGhhbmRsZSBzdWNjZXNzZnVsIHJlc3VsdFxuICAgIHNlbGYuc3RhdGUgPSAnZW5kJ1xuICAgIHNlbGYuZW1pdCgnZW5kJywgcmVzdWx0cylcbiAgICBpZiAoc2VsZi5jYWxsYmFjaykge1xuICAgICAgc2VsZi5jYWxsYmFjayhudWxsLCByZXN1bHRzKVxuICAgIH1cbiAgfVxuXG4gIGlmIChwcm9jZXNzLmRvbWFpbikge1xuICAgIGFmdGVyID0gcHJvY2Vzcy5kb21haW4uYmluZChhZnRlcilcbiAgfVxuXG4gIC8vIG5hbWVkIHF1ZXJ5XG4gIGlmICh0aGlzLm5hbWUpIHtcbiAgICBpZiAodGhpcy5uYW1lLmxlbmd0aCA+IDYzKSB7XG4gICAgICAvKiBlc2xpbnQtZGlzYWJsZSBuby1jb25zb2xlICovXG4gICAgICBjb25zb2xlLmVycm9yKCdXYXJuaW5nISBQb3N0Z3JlcyBvbmx5IHN1cHBvcnRzIDYzIGNoYXJhY3RlcnMgZm9yIHF1ZXJ5IG5hbWVzLicpXG4gICAgICBjb25zb2xlLmVycm9yKCdZb3Ugc3VwcGxpZWQgJXMgKCVzKScsIHRoaXMubmFtZSwgdGhpcy5uYW1lLmxlbmd0aClcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1RoaXMgY2FuIGNhdXNlIGNvbmZsaWN0cyBhbmQgc2lsZW50IGVycm9ycyBleGVjdXRpbmcgcXVlcmllcycpXG4gICAgICAvKiBlc2xpbnQtZW5hYmxlIG5vLWNvbnNvbGUgKi9cbiAgICB9XG4gICAgdmFyIHZhbHVlcyA9ICh0aGlzLnZhbHVlcyB8fCBbXSkubWFwKHV0aWxzLnByZXBhcmVWYWx1ZSlcblxuICAgIC8vIGNoZWNrIGlmIHRoZSBjbGllbnQgaGFzIGFscmVhZHkgZXhlY3V0ZWQgdGhpcyBuYW1lZCBxdWVyeVxuICAgIC8vIGlmIHNvLi4uanVzdCBleGVjdXRlIGl0IGFnYWluIC0gc2tpcCB0aGUgcGxhbm5pbmcgcGhhc2VcbiAgICBpZiAoY2xpZW50Lm5hbWVkUXVlcmllc1t0aGlzLm5hbWVdKSB7XG4gICAgICBpZiAodGhpcy50ZXh0ICYmIGNsaWVudC5uYW1lZFF1ZXJpZXNbdGhpcy5uYW1lXSAhPT0gdGhpcy50ZXh0KSB7XG4gICAgICAgIGNvbnN0IGVyciA9IG5ldyBFcnJvcihgUHJlcGFyZWQgc3RhdGVtZW50cyBtdXN0IGJlIHVuaXF1ZSAtICcke3RoaXMubmFtZX0nIHdhcyB1c2VkIGZvciBhIGRpZmZlcmVudCBzdGF0ZW1lbnRgKVxuICAgICAgICByZXR1cm4gYWZ0ZXIoZXJyKVxuICAgICAgfVxuICAgICAgcmV0dXJuIGNsaWVudC5uYXRpdmUuZXhlY3V0ZSh0aGlzLm5hbWUsIHZhbHVlcywgYWZ0ZXIpXG4gICAgfVxuICAgIC8vIHBsYW4gdGhlIG5hbWVkIHF1ZXJ5IHRoZSBmaXJzdCB0aW1lLCB0aGVuIGV4ZWN1dGUgaXRcbiAgICByZXR1cm4gY2xpZW50Lm5hdGl2ZS5wcmVwYXJlKHRoaXMubmFtZSwgdGhpcy50ZXh0LCB2YWx1ZXMubGVuZ3RoLCBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICBpZiAoZXJyKSByZXR1cm4gYWZ0ZXIoZXJyKVxuICAgICAgY2xpZW50Lm5hbWVkUXVlcmllc1tzZWxmLm5hbWVdID0gc2VsZi50ZXh0XG4gICAgICByZXR1cm4gc2VsZi5uYXRpdmUuZXhlY3V0ZShzZWxmLm5hbWUsIHZhbHVlcywgYWZ0ZXIpXG4gICAgfSlcbiAgfSBlbHNlIGlmICh0aGlzLnZhbHVlcykge1xuICAgIGlmICghQXJyYXkuaXNBcnJheSh0aGlzLnZhbHVlcykpIHtcbiAgICAgIGNvbnN0IGVyciA9IG5ldyBFcnJvcignUXVlcnkgdmFsdWVzIG11c3QgYmUgYW4gYXJyYXknKVxuICAgICAgcmV0dXJuIGFmdGVyKGVycilcbiAgICB9XG4gICAgdmFyIHZhbHMgPSB0aGlzLnZhbHVlcy5tYXAodXRpbHMucHJlcGFyZVZhbHVlKVxuICAgIGNsaWVudC5uYXRpdmUucXVlcnkodGhpcy50ZXh0LCB2YWxzLCBhZnRlcilcbiAgfSBlbHNlIHtcbiAgICBjbGllbnQubmF0aXZlLnF1ZXJ5KHRoaXMudGV4dCwgYWZ0ZXIpXG4gIH1cbn1cbiIsIid1c2Ugc3RyaWN0J1xuXG5jb25zdCB7IEV2ZW50RW1pdHRlciB9ID0gcmVxdWlyZSgnZXZlbnRzJylcblxuY29uc3QgUmVzdWx0ID0gcmVxdWlyZSgnLi9yZXN1bHQnKVxuY29uc3QgdXRpbHMgPSByZXF1aXJlKCcuL3V0aWxzJylcblxuY2xhc3MgUXVlcnkgZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBjb25zdHJ1Y3Rvcihjb25maWcsIHZhbHVlcywgY2FsbGJhY2spIHtcbiAgICBzdXBlcigpXG5cbiAgICBjb25maWcgPSB1dGlscy5ub3JtYWxpemVRdWVyeUNvbmZpZyhjb25maWcsIHZhbHVlcywgY2FsbGJhY2spXG5cbiAgICB0aGlzLnRleHQgPSBjb25maWcudGV4dFxuICAgIHRoaXMudmFsdWVzID0gY29uZmlnLnZhbHVlc1xuICAgIHRoaXMucm93cyA9IGNvbmZpZy5yb3dzXG4gICAgdGhpcy50eXBlcyA9IGNvbmZpZy50eXBlc1xuICAgIHRoaXMubmFtZSA9IGNvbmZpZy5uYW1lXG4gICAgdGhpcy5iaW5hcnkgPSBjb25maWcuYmluYXJ5XG4gICAgLy8gdXNlIHVuaXF1ZSBwb3J0YWwgbmFtZSBlYWNoIHRpbWVcbiAgICB0aGlzLnBvcnRhbCA9IGNvbmZpZy5wb3J0YWwgfHwgJydcbiAgICB0aGlzLmNhbGxiYWNrID0gY29uZmlnLmNhbGxiYWNrXG4gICAgdGhpcy5fcm93TW9kZSA9IGNvbmZpZy5yb3dNb2RlXG4gICAgaWYgKHByb2Nlc3MuZG9tYWluICYmIGNvbmZpZy5jYWxsYmFjaykge1xuICAgICAgdGhpcy5jYWxsYmFjayA9IHByb2Nlc3MuZG9tYWluLmJpbmQoY29uZmlnLmNhbGxiYWNrKVxuICAgIH1cbiAgICB0aGlzLl9yZXN1bHQgPSBuZXcgUmVzdWx0KHRoaXMuX3Jvd01vZGUsIHRoaXMudHlwZXMpXG5cbiAgICAvLyBwb3RlbnRpYWwgZm9yIG11bHRpcGxlIHJlc3VsdHNcbiAgICB0aGlzLl9yZXN1bHRzID0gdGhpcy5fcmVzdWx0XG4gICAgdGhpcy5pc1ByZXBhcmVkU3RhdGVtZW50ID0gZmFsc2VcbiAgICB0aGlzLl9jYW5jZWxlZER1ZVRvRXJyb3IgPSBmYWxzZVxuICAgIHRoaXMuX3Byb21pc2UgPSBudWxsXG4gIH1cblxuICByZXF1aXJlc1ByZXBhcmF0aW9uKCkge1xuICAgIC8vIG5hbWVkIHF1ZXJpZXMgbXVzdCBhbHdheXMgYmUgcHJlcGFyZWRcbiAgICBpZiAodGhpcy5uYW1lKSB7XG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH1cbiAgICAvLyBhbHdheXMgcHJlcGFyZSBpZiB0aGVyZSBhcmUgbWF4IG51bWJlciBvZiByb3dzIGV4cGVjdGVkIHBlclxuICAgIC8vIHBvcnRhbCBleGVjdXRpb25cbiAgICBpZiAodGhpcy5yb3dzKSB7XG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH1cbiAgICAvLyBkb24ndCBwcmVwYXJlIGVtcHR5IHRleHQgcXVlcmllc1xuICAgIGlmICghdGhpcy50ZXh0KSB7XG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG4gICAgLy8gcHJlcGFyZSBpZiB0aGVyZSBhcmUgdmFsdWVzXG4gICAgaWYgKCF0aGlzLnZhbHVlcykge1xuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuICAgIHJldHVybiB0aGlzLnZhbHVlcy5sZW5ndGggPiAwXG4gIH1cblxuICBfY2hlY2tGb3JNdWx0aXJvdygpIHtcbiAgICAvLyBpZiB3ZSBhbHJlYWR5IGhhdmUgYSByZXN1bHQgd2l0aCBhIGNvbW1hbmQgcHJvcGVydHlcbiAgICAvLyB0aGVuIHdlJ3ZlIGFscmVhZHkgZXhlY3V0ZWQgb25lIHF1ZXJ5IGluIGEgbXVsdGktc3RhdGVtZW50IHNpbXBsZSBxdWVyeVxuICAgIC8vIHR1cm4gb3VyIHJlc3VsdHMgaW50byBhbiBhcnJheSBvZiByZXN1bHRzXG4gICAgaWYgKHRoaXMuX3Jlc3VsdC5jb21tYW5kKSB7XG4gICAgICBpZiAoIUFycmF5LmlzQXJyYXkodGhpcy5fcmVzdWx0cykpIHtcbiAgICAgICAgdGhpcy5fcmVzdWx0cyA9IFt0aGlzLl9yZXN1bHRdXG4gICAgICB9XG4gICAgICB0aGlzLl9yZXN1bHQgPSBuZXcgUmVzdWx0KHRoaXMuX3Jvd01vZGUsIHRoaXMudHlwZXMpXG4gICAgICB0aGlzLl9yZXN1bHRzLnB1c2godGhpcy5fcmVzdWx0KVxuICAgIH1cbiAgfVxuXG4gIC8vIGFzc29jaWF0ZXMgcm93IG1ldGFkYXRhIGZyb20gdGhlIHN1cHBsaWVkXG4gIC8vIG1lc3NhZ2Ugd2l0aCB0aGlzIHF1ZXJ5IG9iamVjdFxuICAvLyBtZXRhZGF0YSB1c2VkIHdoZW4gcGFyc2luZyByb3cgcmVzdWx0c1xuICBoYW5kbGVSb3dEZXNjcmlwdGlvbihtc2cpIHtcbiAgICB0aGlzLl9jaGVja0Zvck11bHRpcm93KClcbiAgICB0aGlzLl9yZXN1bHQuYWRkRmllbGRzKG1zZy5maWVsZHMpXG4gICAgdGhpcy5fYWNjdW11bGF0ZVJvd3MgPSB0aGlzLmNhbGxiYWNrIHx8ICF0aGlzLmxpc3RlbmVycygncm93JykubGVuZ3RoXG4gIH1cblxuICBoYW5kbGVEYXRhUm93KG1zZykge1xuICAgIGxldCByb3dcblxuICAgIGlmICh0aGlzLl9jYW5jZWxlZER1ZVRvRXJyb3IpIHtcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICByb3cgPSB0aGlzLl9yZXN1bHQucGFyc2VSb3cobXNnLmZpZWxkcylcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHRoaXMuX2NhbmNlbGVkRHVlVG9FcnJvciA9IGVyclxuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgdGhpcy5lbWl0KCdyb3cnLCByb3csIHRoaXMuX3Jlc3VsdClcbiAgICBpZiAodGhpcy5fYWNjdW11bGF0ZVJvd3MpIHtcbiAgICAgIHRoaXMuX3Jlc3VsdC5hZGRSb3cocm93KVxuICAgIH1cbiAgfVxuXG4gIGhhbmRsZUNvbW1hbmRDb21wbGV0ZShtc2csIGNvbm5lY3Rpb24pIHtcbiAgICB0aGlzLl9jaGVja0Zvck11bHRpcm93KClcbiAgICB0aGlzLl9yZXN1bHQuYWRkQ29tbWFuZENvbXBsZXRlKG1zZylcbiAgICAvLyBuZWVkIHRvIHN5bmMgYWZ0ZXIgZWFjaCBjb21tYW5kIGNvbXBsZXRlIG9mIGEgcHJlcGFyZWQgc3RhdGVtZW50XG4gICAgLy8gaWYgd2Ugd2VyZSB1c2luZyBhIHJvdyBjb3VudCB3aGljaCByZXN1bHRzIGluIG11bHRpcGxlIGNhbGxzIHRvIF9nZXRSb3dzXG4gICAgaWYgKHRoaXMucm93cykge1xuICAgICAgY29ubmVjdGlvbi5zeW5jKClcbiAgICB9XG4gIH1cblxuICAvLyBpZiBhIG5hbWVkIHByZXBhcmVkIHN0YXRlbWVudCBpcyBjcmVhdGVkIHdpdGggZW1wdHkgcXVlcnkgdGV4dFxuICAvLyB0aGUgYmFja2VuZCB3aWxsIHNlbmQgYW4gZW1wdHlRdWVyeSBtZXNzYWdlIGJ1dCAqbm90KiBhIGNvbW1hbmQgY29tcGxldGUgbWVzc2FnZVxuICAvLyBzaW5jZSB3ZSBwaXBlbGluZSBzeW5jIGltbWVkaWF0ZWx5IGFmdGVyIGV4ZWN1dGUgd2UgZG9uJ3QgbmVlZCB0byBkbyBhbnl0aGluZyBoZXJlXG4gIC8vIHVubGVzcyB3ZSBoYXZlIHJvd3Mgc3BlY2lmaWVkLCBpbiB3aGljaCBjYXNlIHdlIGRpZCBub3QgcGlwZWxpbmUgdGhlIGludGlhbCBzeW5jIGNhbGxcbiAgaGFuZGxlRW1wdHlRdWVyeShjb25uZWN0aW9uKSB7XG4gICAgaWYgKHRoaXMucm93cykge1xuICAgICAgY29ubmVjdGlvbi5zeW5jKClcbiAgICB9XG4gIH1cblxuICBoYW5kbGVFcnJvcihlcnIsIGNvbm5lY3Rpb24pIHtcbiAgICAvLyBuZWVkIHRvIHN5bmMgYWZ0ZXIgZXJyb3IgZHVyaW5nIGEgcHJlcGFyZWQgc3RhdGVtZW50XG4gICAgaWYgKHRoaXMuX2NhbmNlbGVkRHVlVG9FcnJvcikge1xuICAgICAgZXJyID0gdGhpcy5fY2FuY2VsZWREdWVUb0Vycm9yXG4gICAgICB0aGlzLl9jYW5jZWxlZER1ZVRvRXJyb3IgPSBmYWxzZVxuICAgIH1cbiAgICAvLyBpZiBjYWxsYmFjayBzdXBwbGllZCBkbyBub3QgZW1pdCBlcnJvciBldmVudCBhcyB1bmNhdWdodCBlcnJvclxuICAgIC8vIGV2ZW50cyB3aWxsIGJ1YmJsZSB1cCB0byBub2RlIHByb2Nlc3NcbiAgICBpZiAodGhpcy5jYWxsYmFjaykge1xuICAgICAgcmV0dXJuIHRoaXMuY2FsbGJhY2soZXJyKVxuICAgIH1cbiAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKVxuICB9XG5cbiAgaGFuZGxlUmVhZHlGb3JRdWVyeShjb24pIHtcbiAgICBpZiAodGhpcy5fY2FuY2VsZWREdWVUb0Vycm9yKSB7XG4gICAgICByZXR1cm4gdGhpcy5oYW5kbGVFcnJvcih0aGlzLl9jYW5jZWxlZER1ZVRvRXJyb3IsIGNvbilcbiAgICB9XG4gICAgaWYgKHRoaXMuY2FsbGJhY2spIHtcbiAgICAgIHRoaXMuY2FsbGJhY2sobnVsbCwgdGhpcy5fcmVzdWx0cylcbiAgICB9XG4gICAgdGhpcy5lbWl0KCdlbmQnLCB0aGlzLl9yZXN1bHRzKVxuICB9XG5cbiAgc3VibWl0KGNvbm5lY3Rpb24pIHtcbiAgICBpZiAodHlwZW9mIHRoaXMudGV4dCAhPT0gJ3N0cmluZycgJiYgdHlwZW9mIHRoaXMubmFtZSAhPT0gJ3N0cmluZycpIHtcbiAgICAgIHJldHVybiBuZXcgRXJyb3IoJ0EgcXVlcnkgbXVzdCBoYXZlIGVpdGhlciB0ZXh0IG9yIGEgbmFtZS4gU3VwcGx5aW5nIG5laXRoZXIgaXMgdW5zdXBwb3J0ZWQuJylcbiAgICB9XG4gICAgY29uc3QgcHJldmlvdXMgPSBjb25uZWN0aW9uLnBhcnNlZFN0YXRlbWVudHNbdGhpcy5uYW1lXVxuICAgIGlmICh0aGlzLnRleHQgJiYgcHJldmlvdXMgJiYgdGhpcy50ZXh0ICE9PSBwcmV2aW91cykge1xuICAgICAgcmV0dXJuIG5ldyBFcnJvcihgUHJlcGFyZWQgc3RhdGVtZW50cyBtdXN0IGJlIHVuaXF1ZSAtICcke3RoaXMubmFtZX0nIHdhcyB1c2VkIGZvciBhIGRpZmZlcmVudCBzdGF0ZW1lbnRgKVxuICAgIH1cbiAgICBpZiAodGhpcy52YWx1ZXMgJiYgIUFycmF5LmlzQXJyYXkodGhpcy52YWx1ZXMpKSB7XG4gICAgICByZXR1cm4gbmV3IEVycm9yKCdRdWVyeSB2YWx1ZXMgbXVzdCBiZSBhbiBhcnJheScpXG4gICAgfVxuICAgIGlmICh0aGlzLnJlcXVpcmVzUHJlcGFyYXRpb24oKSkge1xuICAgICAgdGhpcy5wcmVwYXJlKGNvbm5lY3Rpb24pXG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbm5lY3Rpb24ucXVlcnkodGhpcy50ZXh0KVxuICAgIH1cbiAgICByZXR1cm4gbnVsbFxuICB9XG5cbiAgaGFzQmVlblBhcnNlZChjb25uZWN0aW9uKSB7XG4gICAgcmV0dXJuIHRoaXMubmFtZSAmJiBjb25uZWN0aW9uLnBhcnNlZFN0YXRlbWVudHNbdGhpcy5uYW1lXVxuICB9XG5cbiAgaGFuZGxlUG9ydGFsU3VzcGVuZGVkKGNvbm5lY3Rpb24pIHtcbiAgICB0aGlzLl9nZXRSb3dzKGNvbm5lY3Rpb24sIHRoaXMucm93cylcbiAgfVxuXG4gIF9nZXRSb3dzKGNvbm5lY3Rpb24sIHJvd3MpIHtcbiAgICBjb25uZWN0aW9uLmV4ZWN1dGUoe1xuICAgICAgcG9ydGFsOiB0aGlzLnBvcnRhbCxcbiAgICAgIHJvd3M6IHJvd3MsXG4gICAgfSlcbiAgICAvLyBpZiB3ZSdyZSBub3QgcmVhZGluZyBwYWdlcyBvZiByb3dzIHNlbmQgdGhlIHN5bmMgY29tbWFuZFxuICAgIC8vIHRvIGluZGljYXRlIHRoZSBwaXBlbGluZSBpcyBmaW5pc2hlZFxuICAgIGlmICghcm93cykge1xuICAgICAgY29ubmVjdGlvbi5zeW5jKClcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gb3RoZXJ3aXNlIGZsdXNoIHRoZSBjYWxsIG91dCB0byByZWFkIG1vcmUgcm93c1xuICAgICAgY29ubmVjdGlvbi5mbHVzaCgpXG4gICAgfVxuICB9XG5cbiAgLy8gaHR0cDovL2RldmVsb3Blci5wb3N0Z3Jlc3FsLm9yZy9wZ2RvY3MvcG9zdGdyZXMvcHJvdG9jb2wtZmxvdy5odG1sI1BST1RPQ09MLUZMT1ctRVhULVFVRVJZXG4gIHByZXBhcmUoY29ubmVjdGlvbikge1xuICAgIC8vIHByZXBhcmVkIHN0YXRlbWVudHMgbmVlZCBzeW5jIHRvIGJlIGNhbGxlZCBhZnRlciBlYWNoIGNvbW1hbmRcbiAgICAvLyBjb21wbGV0ZSBvciB3aGVuIGFuIGVycm9yIGlzIGVuY291bnRlcmVkXG4gICAgdGhpcy5pc1ByZXBhcmVkU3RhdGVtZW50ID0gdHJ1ZVxuXG4gICAgLy8gVE9ETyByZWZhY3RvciB0aGlzIHBvb3IgZW5jYXBzdWxhdGlvblxuICAgIGlmICghdGhpcy5oYXNCZWVuUGFyc2VkKGNvbm5lY3Rpb24pKSB7XG4gICAgICBjb25uZWN0aW9uLnBhcnNlKHtcbiAgICAgICAgdGV4dDogdGhpcy50ZXh0LFxuICAgICAgICBuYW1lOiB0aGlzLm5hbWUsXG4gICAgICAgIHR5cGVzOiB0aGlzLnR5cGVzLFxuICAgICAgfSlcbiAgICB9XG5cbiAgICAvLyBiZWNhdXNlIHdlJ3JlIG1hcHBpbmcgdXNlciBzdXBwbGllZCB2YWx1ZXMgdG9cbiAgICAvLyBwb3N0Z3JlcyB3aXJlIHByb3RvY29sIGNvbXBhdGlibGUgdmFsdWVzIGl0IGNvdWxkXG4gICAgLy8gdGhyb3cgYW4gZXhjZXB0aW9uLCBzbyB0cnkvY2F0Y2ggdGhpcyBzZWN0aW9uXG4gICAgdHJ5IHtcbiAgICAgIGNvbm5lY3Rpb24uYmluZCh7XG4gICAgICAgIHBvcnRhbDogdGhpcy5wb3J0YWwsXG4gICAgICAgIHN0YXRlbWVudDogdGhpcy5uYW1lLFxuICAgICAgICB2YWx1ZXM6IHRoaXMudmFsdWVzLFxuICAgICAgICBiaW5hcnk6IHRoaXMuYmluYXJ5LFxuICAgICAgICB2YWx1ZU1hcHBlcjogdXRpbHMucHJlcGFyZVZhbHVlLFxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHRoaXMuaGFuZGxlRXJyb3IoZXJyLCBjb25uZWN0aW9uKVxuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgY29ubmVjdGlvbi5kZXNjcmliZSh7XG4gICAgICB0eXBlOiAnUCcsXG4gICAgICBuYW1lOiB0aGlzLnBvcnRhbCB8fCAnJyxcbiAgICB9KVxuXG4gICAgdGhpcy5fZ2V0Um93cyhjb25uZWN0aW9uLCB0aGlzLnJvd3MpXG4gIH1cblxuICBoYW5kbGVDb3B5SW5SZXNwb25zZShjb25uZWN0aW9uKSB7XG4gICAgY29ubmVjdGlvbi5zZW5kQ29weUZhaWwoJ05vIHNvdXJjZSBzdHJlYW0gZGVmaW5lZCcpXG4gIH1cblxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdW51c2VkLXZhcnNcbiAgaGFuZGxlQ29weURhdGEobXNnLCBjb25uZWN0aW9uKSB7XG4gICAgLy8gbm9vcFxuICB9XG59XG5cbm1vZHVsZS5leHBvcnRzID0gUXVlcnlcbiIsIid1c2Ugc3RyaWN0J1xuXG52YXIgdHlwZXMgPSByZXF1aXJlKCdwZy10eXBlcycpXG5cbnZhciBtYXRjaFJlZ2V4cCA9IC9eKFtBLVphLXpdKykoPzogKFxcZCspKT8oPzogKFxcZCspKT8vXG5cbi8vIHJlc3VsdCBvYmplY3QgcmV0dXJuZWQgZnJvbSBxdWVyeVxuLy8gaW4gdGhlICdlbmQnIGV2ZW50IGFuZCBhbHNvXG4vLyBwYXNzZWQgYXMgc2Vjb25kIGFyZ3VtZW50IHRvIHByb3ZpZGVkIGNhbGxiYWNrXG5jbGFzcyBSZXN1bHQge1xuICBjb25zdHJ1Y3Rvcihyb3dNb2RlLCB0eXBlcykge1xuICAgIHRoaXMuY29tbWFuZCA9IG51bGxcbiAgICB0aGlzLnJvd0NvdW50ID0gbnVsbFxuICAgIHRoaXMub2lkID0gbnVsbFxuICAgIHRoaXMucm93cyA9IFtdXG4gICAgdGhpcy5maWVsZHMgPSBbXVxuICAgIHRoaXMuX3BhcnNlcnMgPSB1bmRlZmluZWRcbiAgICB0aGlzLl90eXBlcyA9IHR5cGVzXG4gICAgdGhpcy5Sb3dDdG9yID0gbnVsbFxuICAgIHRoaXMucm93QXNBcnJheSA9IHJvd01vZGUgPT09ICdhcnJheSdcbiAgICBpZiAodGhpcy5yb3dBc0FycmF5KSB7XG4gICAgICB0aGlzLnBhcnNlUm93ID0gdGhpcy5fcGFyc2VSb3dBc0FycmF5XG4gICAgfVxuICB9XG5cbiAgLy8gYWRkcyBhIGNvbW1hbmQgY29tcGxldGUgbWVzc2FnZVxuICBhZGRDb21tYW5kQ29tcGxldGUobXNnKSB7XG4gICAgdmFyIG1hdGNoXG4gICAgaWYgKG1zZy50ZXh0KSB7XG4gICAgICAvLyBwdXJlIGphdmFzY3JpcHRcbiAgICAgIG1hdGNoID0gbWF0Y2hSZWdleHAuZXhlYyhtc2cudGV4dClcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gbmF0aXZlIGJpbmRpbmdzXG4gICAgICBtYXRjaCA9IG1hdGNoUmVnZXhwLmV4ZWMobXNnLmNvbW1hbmQpXG4gICAgfVxuICAgIGlmIChtYXRjaCkge1xuICAgICAgdGhpcy5jb21tYW5kID0gbWF0Y2hbMV1cbiAgICAgIGlmIChtYXRjaFszXSkge1xuICAgICAgICAvLyBDT01NTUFORCBPSUQgUk9XU1xuICAgICAgICB0aGlzLm9pZCA9IHBhcnNlSW50KG1hdGNoWzJdLCAxMClcbiAgICAgICAgdGhpcy5yb3dDb3VudCA9IHBhcnNlSW50KG1hdGNoWzNdLCAxMClcbiAgICAgIH0gZWxzZSBpZiAobWF0Y2hbMl0pIHtcbiAgICAgICAgLy8gQ09NTUFORCBST1dTXG4gICAgICAgIHRoaXMucm93Q291bnQgPSBwYXJzZUludChtYXRjaFsyXSwgMTApXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgX3BhcnNlUm93QXNBcnJheShyb3dEYXRhKSB7XG4gICAgdmFyIHJvdyA9IG5ldyBBcnJheShyb3dEYXRhLmxlbmd0aClcbiAgICBmb3IgKHZhciBpID0gMCwgbGVuID0gcm93RGF0YS5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgICAgdmFyIHJhd1ZhbHVlID0gcm93RGF0YVtpXVxuICAgICAgaWYgKHJhd1ZhbHVlICE9PSBudWxsKSB7XG4gICAgICAgIHJvd1tpXSA9IHRoaXMuX3BhcnNlcnNbaV0ocmF3VmFsdWUpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICByb3dbaV0gPSBudWxsXG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiByb3dcbiAgfVxuXG4gIHBhcnNlUm93KHJvd0RhdGEpIHtcbiAgICB2YXIgcm93ID0ge31cbiAgICBmb3IgKHZhciBpID0gMCwgbGVuID0gcm93RGF0YS5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgICAgdmFyIHJhd1ZhbHVlID0gcm93RGF0YVtpXVxuICAgICAgdmFyIGZpZWxkID0gdGhpcy5maWVsZHNbaV0ubmFtZVxuICAgICAgaWYgKHJhd1ZhbHVlICE9PSBudWxsKSB7XG4gICAgICAgIHJvd1tmaWVsZF0gPSB0aGlzLl9wYXJzZXJzW2ldKHJhd1ZhbHVlKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcm93W2ZpZWxkXSA9IG51bGxcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHJvd1xuICB9XG5cbiAgYWRkUm93KHJvdykge1xuICAgIHRoaXMucm93cy5wdXNoKHJvdylcbiAgfVxuXG4gIGFkZEZpZWxkcyhmaWVsZERlc2NyaXB0aW9ucykge1xuICAgIC8vIGNsZWFycyBmaWVsZCBkZWZpbml0aW9uc1xuICAgIC8vIG11bHRpcGxlIHF1ZXJ5IHN0YXRlbWVudHMgaW4gMSBhY3Rpb24gY2FuIHJlc3VsdCBpbiBtdWx0aXBsZSBzZXRzXG4gICAgLy8gb2Ygcm93RGVzY3JpcHRpb25zLi4uZWc6ICdzZWxlY3QgTk9XKCk7IHNlbGVjdCAxOjppbnQ7J1xuICAgIC8vIHlvdSBuZWVkIHRvIHJlc2V0IHRoZSBmaWVsZHNcbiAgICB0aGlzLmZpZWxkcyA9IGZpZWxkRGVzY3JpcHRpb25zXG4gICAgaWYgKHRoaXMuZmllbGRzLmxlbmd0aCkge1xuICAgICAgdGhpcy5fcGFyc2VycyA9IG5ldyBBcnJheShmaWVsZERlc2NyaXB0aW9ucy5sZW5ndGgpXG4gICAgfVxuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgZmllbGREZXNjcmlwdGlvbnMubGVuZ3RoOyBpKyspIHtcbiAgICAgIHZhciBkZXNjID0gZmllbGREZXNjcmlwdGlvbnNbaV1cbiAgICAgIGlmICh0aGlzLl90eXBlcykge1xuICAgICAgICB0aGlzLl9wYXJzZXJzW2ldID0gdGhpcy5fdHlwZXMuZ2V0VHlwZVBhcnNlcihkZXNjLmRhdGFUeXBlSUQsIGRlc2MuZm9ybWF0IHx8ICd0ZXh0JylcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuX3BhcnNlcnNbaV0gPSB0eXBlcy5nZXRUeXBlUGFyc2VyKGRlc2MuZGF0YVR5cGVJRCwgZGVzYy5mb3JtYXQgfHwgJ3RleHQnKVxuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IFJlc3VsdFxuIiwiJ3VzZSBzdHJpY3QnXG5jb25zdCBjcnlwdG8gPSByZXF1aXJlKCdjcnlwdG8nKVxuXG5mdW5jdGlvbiBzdGFydFNlc3Npb24obWVjaGFuaXNtcykge1xuICBpZiAobWVjaGFuaXNtcy5pbmRleE9mKCdTQ1JBTS1TSEEtMjU2JykgPT09IC0xKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdTQVNMOiBPbmx5IG1lY2hhbmlzbSBTQ1JBTS1TSEEtMjU2IGlzIGN1cnJlbnRseSBzdXBwb3J0ZWQnKVxuICB9XG5cbiAgY29uc3QgY2xpZW50Tm9uY2UgPSBjcnlwdG8ucmFuZG9tQnl0ZXMoMTgpLnRvU3RyaW5nKCdiYXNlNjQnKVxuXG4gIHJldHVybiB7XG4gICAgbWVjaGFuaXNtOiAnU0NSQU0tU0hBLTI1NicsXG4gICAgY2xpZW50Tm9uY2UsXG4gICAgcmVzcG9uc2U6ICduLCxuPSoscj0nICsgY2xpZW50Tm9uY2UsXG4gICAgbWVzc2FnZTogJ1NBU0xJbml0aWFsUmVzcG9uc2UnLFxuICB9XG59XG5cbmZ1bmN0aW9uIGNvbnRpbnVlU2Vzc2lvbihzZXNzaW9uLCBwYXNzd29yZCwgc2VydmVyRGF0YSkge1xuICBpZiAoc2Vzc2lvbi5tZXNzYWdlICE9PSAnU0FTTEluaXRpYWxSZXNwb25zZScpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1NBU0w6IExhc3QgbWVzc2FnZSB3YXMgbm90IFNBU0xJbml0aWFsUmVzcG9uc2UnKVxuICB9XG4gIGlmICh0eXBlb2YgcGFzc3dvcmQgIT09ICdzdHJpbmcnKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdTQVNMOiBTQ1JBTS1TRVJWRVItRklSU1QtTUVTU0FHRTogY2xpZW50IHBhc3N3b3JkIG11c3QgYmUgYSBzdHJpbmcnKVxuICB9XG4gIGlmICh0eXBlb2Ygc2VydmVyRGF0YSAhPT0gJ3N0cmluZycpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1NBU0w6IFNDUkFNLVNFUlZFUi1GSVJTVC1NRVNTQUdFOiBzZXJ2ZXJEYXRhIG11c3QgYmUgYSBzdHJpbmcnKVxuICB9XG5cbiAgY29uc3Qgc3YgPSBwYXJzZVNlcnZlckZpcnN0TWVzc2FnZShzZXJ2ZXJEYXRhKVxuXG4gIGlmICghc3Yubm9uY2Uuc3RhcnRzV2l0aChzZXNzaW9uLmNsaWVudE5vbmNlKSkge1xuICAgIHRocm93IG5ldyBFcnJvcignU0FTTDogU0NSQU0tU0VSVkVSLUZJUlNULU1FU1NBR0U6IHNlcnZlciBub25jZSBkb2VzIG5vdCBzdGFydCB3aXRoIGNsaWVudCBub25jZScpXG4gIH0gZWxzZSBpZiAoc3Yubm9uY2UubGVuZ3RoID09PSBzZXNzaW9uLmNsaWVudE5vbmNlLmxlbmd0aCkge1xuICAgIHRocm93IG5ldyBFcnJvcignU0FTTDogU0NSQU0tU0VSVkVSLUZJUlNULU1FU1NBR0U6IHNlcnZlciBub25jZSBpcyB0b28gc2hvcnQnKVxuICB9XG5cbiAgdmFyIHNhbHRCeXRlcyA9IEJ1ZmZlci5mcm9tKHN2LnNhbHQsICdiYXNlNjQnKVxuXG4gIHZhciBzYWx0ZWRQYXNzd29yZCA9IEhpKHBhc3N3b3JkLCBzYWx0Qnl0ZXMsIHN2Lml0ZXJhdGlvbilcblxuICB2YXIgY2xpZW50S2V5ID0gaG1hY1NoYTI1NihzYWx0ZWRQYXNzd29yZCwgJ0NsaWVudCBLZXknKVxuICB2YXIgc3RvcmVkS2V5ID0gc2hhMjU2KGNsaWVudEtleSlcblxuICB2YXIgY2xpZW50Rmlyc3RNZXNzYWdlQmFyZSA9ICduPSoscj0nICsgc2Vzc2lvbi5jbGllbnROb25jZVxuICB2YXIgc2VydmVyRmlyc3RNZXNzYWdlID0gJ3I9JyArIHN2Lm5vbmNlICsgJyxzPScgKyBzdi5zYWx0ICsgJyxpPScgKyBzdi5pdGVyYXRpb25cblxuICB2YXIgY2xpZW50RmluYWxNZXNzYWdlV2l0aG91dFByb29mID0gJ2M9Yml3cyxyPScgKyBzdi5ub25jZVxuXG4gIHZhciBhdXRoTWVzc2FnZSA9IGNsaWVudEZpcnN0TWVzc2FnZUJhcmUgKyAnLCcgKyBzZXJ2ZXJGaXJzdE1lc3NhZ2UgKyAnLCcgKyBjbGllbnRGaW5hbE1lc3NhZ2VXaXRob3V0UHJvb2ZcblxuICB2YXIgY2xpZW50U2lnbmF0dXJlID0gaG1hY1NoYTI1NihzdG9yZWRLZXksIGF1dGhNZXNzYWdlKVxuICB2YXIgY2xpZW50UHJvb2ZCeXRlcyA9IHhvckJ1ZmZlcnMoY2xpZW50S2V5LCBjbGllbnRTaWduYXR1cmUpXG4gIHZhciBjbGllbnRQcm9vZiA9IGNsaWVudFByb29mQnl0ZXMudG9TdHJpbmcoJ2Jhc2U2NCcpXG5cbiAgdmFyIHNlcnZlcktleSA9IGhtYWNTaGEyNTYoc2FsdGVkUGFzc3dvcmQsICdTZXJ2ZXIgS2V5JylcbiAgdmFyIHNlcnZlclNpZ25hdHVyZUJ5dGVzID0gaG1hY1NoYTI1NihzZXJ2ZXJLZXksIGF1dGhNZXNzYWdlKVxuXG4gIHNlc3Npb24ubWVzc2FnZSA9ICdTQVNMUmVzcG9uc2UnXG4gIHNlc3Npb24uc2VydmVyU2lnbmF0dXJlID0gc2VydmVyU2lnbmF0dXJlQnl0ZXMudG9TdHJpbmcoJ2Jhc2U2NCcpXG4gIHNlc3Npb24ucmVzcG9uc2UgPSBjbGllbnRGaW5hbE1lc3NhZ2VXaXRob3V0UHJvb2YgKyAnLHA9JyArIGNsaWVudFByb29mXG59XG5cbmZ1bmN0aW9uIGZpbmFsaXplU2Vzc2lvbihzZXNzaW9uLCBzZXJ2ZXJEYXRhKSB7XG4gIGlmIChzZXNzaW9uLm1lc3NhZ2UgIT09ICdTQVNMUmVzcG9uc2UnKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdTQVNMOiBMYXN0IG1lc3NhZ2Ugd2FzIG5vdCBTQVNMUmVzcG9uc2UnKVxuICB9XG4gIGlmICh0eXBlb2Ygc2VydmVyRGF0YSAhPT0gJ3N0cmluZycpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1NBU0w6IFNDUkFNLVNFUlZFUi1GSU5BTC1NRVNTQUdFOiBzZXJ2ZXJEYXRhIG11c3QgYmUgYSBzdHJpbmcnKVxuICB9XG5cbiAgY29uc3QgeyBzZXJ2ZXJTaWduYXR1cmUgfSA9IHBhcnNlU2VydmVyRmluYWxNZXNzYWdlKHNlcnZlckRhdGEpXG5cbiAgaWYgKHNlcnZlclNpZ25hdHVyZSAhPT0gc2Vzc2lvbi5zZXJ2ZXJTaWduYXR1cmUpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1NBU0w6IFNDUkFNLVNFUlZFUi1GSU5BTC1NRVNTQUdFOiBzZXJ2ZXIgc2lnbmF0dXJlIGRvZXMgbm90IG1hdGNoJylcbiAgfVxufVxuXG4vKipcbiAqIHByaW50YWJsZSAgICAgICA9ICV4MjEtMkIgLyAleDJELTdFXG4gKiAgICAgICAgICAgICAgICAgICA7OyBQcmludGFibGUgQVNDSUkgZXhjZXB0IFwiLFwiLlxuICogICAgICAgICAgICAgICAgICAgOzsgTm90ZSB0aGF0IGFueSBcInByaW50YWJsZVwiIGlzIGFsc29cbiAqICAgICAgICAgICAgICAgICAgIDs7IGEgdmFsaWQgXCJ2YWx1ZVwiLlxuICovXG5mdW5jdGlvbiBpc1ByaW50YWJsZUNoYXJzKHRleHQpIHtcbiAgaWYgKHR5cGVvZiB0ZXh0ICE9PSAnc3RyaW5nJykge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1NBU0w6IHRleHQgbXVzdCBiZSBhIHN0cmluZycpXG4gIH1cbiAgcmV0dXJuIHRleHRcbiAgICAuc3BsaXQoJycpXG4gICAgLm1hcCgoXywgaSkgPT4gdGV4dC5jaGFyQ29kZUF0KGkpKVxuICAgIC5ldmVyeSgoYykgPT4gKGMgPj0gMHgyMSAmJiBjIDw9IDB4MmIpIHx8IChjID49IDB4MmQgJiYgYyA8PSAweDdlKSlcbn1cblxuLyoqXG4gKiBiYXNlNjQtY2hhciAgICAgPSBBTFBIQSAvIERJR0lUIC8gXCIvXCIgLyBcIitcIlxuICpcbiAqIGJhc2U2NC00ICAgICAgICA9IDRiYXNlNjQtY2hhclxuICpcbiAqIGJhc2U2NC0zICAgICAgICA9IDNiYXNlNjQtY2hhciBcIj1cIlxuICpcbiAqIGJhc2U2NC0yICAgICAgICA9IDJiYXNlNjQtY2hhciBcIj09XCJcbiAqXG4gKiBiYXNlNjQgICAgICAgICAgPSAqYmFzZTY0LTQgW2Jhc2U2NC0zIC8gYmFzZTY0LTJdXG4gKi9cbmZ1bmN0aW9uIGlzQmFzZTY0KHRleHQpIHtcbiAgcmV0dXJuIC9eKD86W2EtekEtWjAtOSsvXXs0fSkqKD86W2EtekEtWjAtOSsvXXsyfT09fFthLXpBLVowLTkrL117M309KT8kLy50ZXN0KHRleHQpXG59XG5cbmZ1bmN0aW9uIHBhcnNlQXR0cmlidXRlUGFpcnModGV4dCkge1xuICBpZiAodHlwZW9mIHRleHQgIT09ICdzdHJpbmcnKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignU0FTTDogYXR0cmlidXRlIHBhaXJzIHRleHQgbXVzdCBiZSBhIHN0cmluZycpXG4gIH1cblxuICByZXR1cm4gbmV3IE1hcChcbiAgICB0ZXh0LnNwbGl0KCcsJykubWFwKChhdHRyVmFsdWUpID0+IHtcbiAgICAgIGlmICghL14uPS8udGVzdChhdHRyVmFsdWUpKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignU0FTTDogSW52YWxpZCBhdHRyaWJ1dGUgcGFpciBlbnRyeScpXG4gICAgICB9XG4gICAgICBjb25zdCBuYW1lID0gYXR0clZhbHVlWzBdXG4gICAgICBjb25zdCB2YWx1ZSA9IGF0dHJWYWx1ZS5zdWJzdHJpbmcoMilcbiAgICAgIHJldHVybiBbbmFtZSwgdmFsdWVdXG4gICAgfSlcbiAgKVxufVxuXG5mdW5jdGlvbiBwYXJzZVNlcnZlckZpcnN0TWVzc2FnZShkYXRhKSB7XG4gIGNvbnN0IGF0dHJQYWlycyA9IHBhcnNlQXR0cmlidXRlUGFpcnMoZGF0YSlcblxuICBjb25zdCBub25jZSA9IGF0dHJQYWlycy5nZXQoJ3InKVxuICBpZiAoIW5vbmNlKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdTQVNMOiBTQ1JBTS1TRVJWRVItRklSU1QtTUVTU0FHRTogbm9uY2UgbWlzc2luZycpXG4gIH0gZWxzZSBpZiAoIWlzUHJpbnRhYmxlQ2hhcnMobm9uY2UpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdTQVNMOiBTQ1JBTS1TRVJWRVItRklSU1QtTUVTU0FHRTogbm9uY2UgbXVzdCBvbmx5IGNvbnRhaW4gcHJpbnRhYmxlIGNoYXJhY3RlcnMnKVxuICB9XG4gIGNvbnN0IHNhbHQgPSBhdHRyUGFpcnMuZ2V0KCdzJylcbiAgaWYgKCFzYWx0KSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdTQVNMOiBTQ1JBTS1TRVJWRVItRklSU1QtTUVTU0FHRTogc2FsdCBtaXNzaW5nJylcbiAgfSBlbHNlIGlmICghaXNCYXNlNjQoc2FsdCkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1NBU0w6IFNDUkFNLVNFUlZFUi1GSVJTVC1NRVNTQUdFOiBzYWx0IG11c3QgYmUgYmFzZTY0JylcbiAgfVxuICBjb25zdCBpdGVyYXRpb25UZXh0ID0gYXR0clBhaXJzLmdldCgnaScpXG4gIGlmICghaXRlcmF0aW9uVGV4dCkge1xuICAgIHRocm93IG5ldyBFcnJvcignU0FTTDogU0NSQU0tU0VSVkVSLUZJUlNULU1FU1NBR0U6IGl0ZXJhdGlvbiBtaXNzaW5nJylcbiAgfSBlbHNlIGlmICghL15bMS05XVswLTldKiQvLnRlc3QoaXRlcmF0aW9uVGV4dCkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1NBU0w6IFNDUkFNLVNFUlZFUi1GSVJTVC1NRVNTQUdFOiBpbnZhbGlkIGl0ZXJhdGlvbiBjb3VudCcpXG4gIH1cbiAgY29uc3QgaXRlcmF0aW9uID0gcGFyc2VJbnQoaXRlcmF0aW9uVGV4dCwgMTApXG5cbiAgcmV0dXJuIHtcbiAgICBub25jZSxcbiAgICBzYWx0LFxuICAgIGl0ZXJhdGlvbixcbiAgfVxufVxuXG5mdW5jdGlvbiBwYXJzZVNlcnZlckZpbmFsTWVzc2FnZShzZXJ2ZXJEYXRhKSB7XG4gIGNvbnN0IGF0dHJQYWlycyA9IHBhcnNlQXR0cmlidXRlUGFpcnMoc2VydmVyRGF0YSlcbiAgY29uc3Qgc2VydmVyU2lnbmF0dXJlID0gYXR0clBhaXJzLmdldCgndicpXG4gIGlmICghc2VydmVyU2lnbmF0dXJlKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdTQVNMOiBTQ1JBTS1TRVJWRVItRklOQUwtTUVTU0FHRTogc2VydmVyIHNpZ25hdHVyZSBpcyBtaXNzaW5nJylcbiAgfSBlbHNlIGlmICghaXNCYXNlNjQoc2VydmVyU2lnbmF0dXJlKSkge1xuICAgIHRocm93IG5ldyBFcnJvcignU0FTTDogU0NSQU0tU0VSVkVSLUZJTkFMLU1FU1NBR0U6IHNlcnZlciBzaWduYXR1cmUgbXVzdCBiZSBiYXNlNjQnKVxuICB9XG4gIHJldHVybiB7XG4gICAgc2VydmVyU2lnbmF0dXJlLFxuICB9XG59XG5cbmZ1bmN0aW9uIHhvckJ1ZmZlcnMoYSwgYikge1xuICBpZiAoIUJ1ZmZlci5pc0J1ZmZlcihhKSkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ2ZpcnN0IGFyZ3VtZW50IG11c3QgYmUgYSBCdWZmZXInKVxuICB9XG4gIGlmICghQnVmZmVyLmlzQnVmZmVyKGIpKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignc2Vjb25kIGFyZ3VtZW50IG11c3QgYmUgYSBCdWZmZXInKVxuICB9XG4gIGlmIChhLmxlbmd0aCAhPT0gYi5sZW5ndGgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ0J1ZmZlciBsZW5ndGhzIG11c3QgbWF0Y2gnKVxuICB9XG4gIGlmIChhLmxlbmd0aCA9PT0gMCkge1xuICAgIHRocm93IG5ldyBFcnJvcignQnVmZmVycyBjYW5ub3QgYmUgZW1wdHknKVxuICB9XG4gIHJldHVybiBCdWZmZXIuZnJvbShhLm1hcCgoXywgaSkgPT4gYVtpXSBeIGJbaV0pKVxufVxuXG5mdW5jdGlvbiBzaGEyNTYodGV4dCkge1xuICByZXR1cm4gY3J5cHRvLmNyZWF0ZUhhc2goJ3NoYTI1NicpLnVwZGF0ZSh0ZXh0KS5kaWdlc3QoKVxufVxuXG5mdW5jdGlvbiBobWFjU2hhMjU2KGtleSwgbXNnKSB7XG4gIHJldHVybiBjcnlwdG8uY3JlYXRlSG1hYygnc2hhMjU2Jywga2V5KS51cGRhdGUobXNnKS5kaWdlc3QoKVxufVxuXG5mdW5jdGlvbiBIaShwYXNzd29yZCwgc2FsdEJ5dGVzLCBpdGVyYXRpb25zKSB7XG4gIHZhciB1aTEgPSBobWFjU2hhMjU2KHBhc3N3b3JkLCBCdWZmZXIuY29uY2F0KFtzYWx0Qnl0ZXMsIEJ1ZmZlci5mcm9tKFswLCAwLCAwLCAxXSldKSlcbiAgdmFyIHVpID0gdWkxXG4gIGZvciAodmFyIGkgPSAwOyBpIDwgaXRlcmF0aW9ucyAtIDE7IGkrKykge1xuICAgIHVpMSA9IGhtYWNTaGEyNTYocGFzc3dvcmQsIHVpMSlcbiAgICB1aSA9IHhvckJ1ZmZlcnModWksIHVpMSlcbiAgfVxuXG4gIHJldHVybiB1aVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgc3RhcnRTZXNzaW9uLFxuICBjb250aW51ZVNlc3Npb24sXG4gIGZpbmFsaXplU2Vzc2lvbixcbn1cbiIsIid1c2Ugc3RyaWN0J1xuXG52YXIgdHlwZXMgPSByZXF1aXJlKCdwZy10eXBlcycpXG5cbmZ1bmN0aW9uIFR5cGVPdmVycmlkZXModXNlclR5cGVzKSB7XG4gIHRoaXMuX3R5cGVzID0gdXNlclR5cGVzIHx8IHR5cGVzXG4gIHRoaXMudGV4dCA9IHt9XG4gIHRoaXMuYmluYXJ5ID0ge31cbn1cblxuVHlwZU92ZXJyaWRlcy5wcm90b3R5cGUuZ2V0T3ZlcnJpZGVzID0gZnVuY3Rpb24gKGZvcm1hdCkge1xuICBzd2l0Y2ggKGZvcm1hdCkge1xuICAgIGNhc2UgJ3RleHQnOlxuICAgICAgcmV0dXJuIHRoaXMudGV4dFxuICAgIGNhc2UgJ2JpbmFyeSc6XG4gICAgICByZXR1cm4gdGhpcy5iaW5hcnlcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIHt9XG4gIH1cbn1cblxuVHlwZU92ZXJyaWRlcy5wcm90b3R5cGUuc2V0VHlwZVBhcnNlciA9IGZ1bmN0aW9uIChvaWQsIGZvcm1hdCwgcGFyc2VGbikge1xuICBpZiAodHlwZW9mIGZvcm1hdCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIHBhcnNlRm4gPSBmb3JtYXRcbiAgICBmb3JtYXQgPSAndGV4dCdcbiAgfVxuICB0aGlzLmdldE92ZXJyaWRlcyhmb3JtYXQpW29pZF0gPSBwYXJzZUZuXG59XG5cblR5cGVPdmVycmlkZXMucHJvdG90eXBlLmdldFR5cGVQYXJzZXIgPSBmdW5jdGlvbiAob2lkLCBmb3JtYXQpIHtcbiAgZm9ybWF0ID0gZm9ybWF0IHx8ICd0ZXh0J1xuICByZXR1cm4gdGhpcy5nZXRPdmVycmlkZXMoZm9ybWF0KVtvaWRdIHx8IHRoaXMuX3R5cGVzLmdldFR5cGVQYXJzZXIob2lkLCBmb3JtYXQpXG59XG5cbm1vZHVsZS5leHBvcnRzID0gVHlwZU92ZXJyaWRlc1xuIiwiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IGNyeXB0byA9IHJlcXVpcmUoJ2NyeXB0bycpXG5cbmNvbnN0IGRlZmF1bHRzID0gcmVxdWlyZSgnLi9kZWZhdWx0cycpXG5cbmZ1bmN0aW9uIGVzY2FwZUVsZW1lbnQoZWxlbWVudFJlcHJlc2VudGF0aW9uKSB7XG4gIHZhciBlc2NhcGVkID0gZWxlbWVudFJlcHJlc2VudGF0aW9uLnJlcGxhY2UoL1xcXFwvZywgJ1xcXFxcXFxcJykucmVwbGFjZSgvXCIvZywgJ1xcXFxcIicpXG5cbiAgcmV0dXJuICdcIicgKyBlc2NhcGVkICsgJ1wiJ1xufVxuXG4vLyBjb252ZXJ0IGEgSlMgYXJyYXkgdG8gYSBwb3N0Z3JlcyBhcnJheSBsaXRlcmFsXG4vLyB1c2VzIGNvbW1hIHNlcGFyYXRvciBzbyB3b24ndCB3b3JrIGZvciB0eXBlcyBsaWtlIGJveCB0aGF0IHVzZVxuLy8gYSBkaWZmZXJlbnQgYXJyYXkgc2VwYXJhdG9yLlxuZnVuY3Rpb24gYXJyYXlTdHJpbmcodmFsKSB7XG4gIHZhciByZXN1bHQgPSAneydcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCB2YWwubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAoaSA+IDApIHtcbiAgICAgIHJlc3VsdCA9IHJlc3VsdCArICcsJ1xuICAgIH1cbiAgICBpZiAodmFsW2ldID09PSBudWxsIHx8IHR5cGVvZiB2YWxbaV0gPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICByZXN1bHQgPSByZXN1bHQgKyAnTlVMTCdcbiAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkodmFsW2ldKSkge1xuICAgICAgcmVzdWx0ID0gcmVzdWx0ICsgYXJyYXlTdHJpbmcodmFsW2ldKVxuICAgIH0gZWxzZSBpZiAodmFsW2ldIGluc3RhbmNlb2YgQnVmZmVyKSB7XG4gICAgICByZXN1bHQgKz0gJ1xcXFxcXFxceCcgKyB2YWxbaV0udG9TdHJpbmcoJ2hleCcpXG4gICAgfSBlbHNlIHtcbiAgICAgIHJlc3VsdCArPSBlc2NhcGVFbGVtZW50KHByZXBhcmVWYWx1ZSh2YWxbaV0pKVxuICAgIH1cbiAgfVxuICByZXN1bHQgPSByZXN1bHQgKyAnfSdcbiAgcmV0dXJuIHJlc3VsdFxufVxuXG4vLyBjb252ZXJ0cyB2YWx1ZXMgZnJvbSBqYXZhc2NyaXB0IHR5cGVzXG4vLyB0byB0aGVpciAncmF3JyBjb3VudGVycGFydHMgZm9yIHVzZSBhcyBhIHBvc3RncmVzIHBhcmFtZXRlclxuLy8gbm90ZTogeW91IGNhbiBvdmVycmlkZSB0aGlzIGZ1bmN0aW9uIHRvIHByb3ZpZGUgeW91ciBvd24gY29udmVyc2lvbiBtZWNoYW5pc21cbi8vIGZvciBjb21wbGV4IHR5cGVzLCBldGMuLi5cbnZhciBwcmVwYXJlVmFsdWUgPSBmdW5jdGlvbiAodmFsLCBzZWVuKSB7XG4gIC8vIG51bGwgYW5kIHVuZGVmaW5lZCBhcmUgYm90aCBudWxsIGZvciBwb3N0Z3Jlc1xuICBpZiAodmFsID09IG51bGwpIHtcbiAgICByZXR1cm4gbnVsbFxuICB9XG4gIGlmICh2YWwgaW5zdGFuY2VvZiBCdWZmZXIpIHtcbiAgICByZXR1cm4gdmFsXG4gIH1cbiAgaWYgKEFycmF5QnVmZmVyLmlzVmlldyh2YWwpKSB7XG4gICAgdmFyIGJ1ZiA9IEJ1ZmZlci5mcm9tKHZhbC5idWZmZXIsIHZhbC5ieXRlT2Zmc2V0LCB2YWwuYnl0ZUxlbmd0aClcbiAgICBpZiAoYnVmLmxlbmd0aCA9PT0gdmFsLmJ5dGVMZW5ndGgpIHtcbiAgICAgIHJldHVybiBidWZcbiAgICB9XG4gICAgcmV0dXJuIGJ1Zi5zbGljZSh2YWwuYnl0ZU9mZnNldCwgdmFsLmJ5dGVPZmZzZXQgKyB2YWwuYnl0ZUxlbmd0aCkgLy8gTm9kZS5qcyB2NCBkb2VzIG5vdCBzdXBwb3J0IHRob3NlIEJ1ZmZlci5mcm9tIHBhcmFtc1xuICB9XG4gIGlmICh2YWwgaW5zdGFuY2VvZiBEYXRlKSB7XG4gICAgaWYgKGRlZmF1bHRzLnBhcnNlSW5wdXREYXRlc0FzVVRDKSB7XG4gICAgICByZXR1cm4gZGF0ZVRvU3RyaW5nVVRDKHZhbClcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIGRhdGVUb1N0cmluZyh2YWwpXG4gICAgfVxuICB9XG4gIGlmIChBcnJheS5pc0FycmF5KHZhbCkpIHtcbiAgICByZXR1cm4gYXJyYXlTdHJpbmcodmFsKVxuICB9XG4gIGlmICh0eXBlb2YgdmFsID09PSAnb2JqZWN0Jykge1xuICAgIHJldHVybiBwcmVwYXJlT2JqZWN0KHZhbCwgc2VlbilcbiAgfVxuICByZXR1cm4gdmFsLnRvU3RyaW5nKClcbn1cblxuZnVuY3Rpb24gcHJlcGFyZU9iamVjdCh2YWwsIHNlZW4pIHtcbiAgaWYgKHZhbCAmJiB0eXBlb2YgdmFsLnRvUG9zdGdyZXMgPT09ICdmdW5jdGlvbicpIHtcbiAgICBzZWVuID0gc2VlbiB8fCBbXVxuICAgIGlmIChzZWVuLmluZGV4T2YodmFsKSAhPT0gLTEpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignY2lyY3VsYXIgcmVmZXJlbmNlIGRldGVjdGVkIHdoaWxlIHByZXBhcmluZyBcIicgKyB2YWwgKyAnXCIgZm9yIHF1ZXJ5JylcbiAgICB9XG4gICAgc2Vlbi5wdXNoKHZhbClcblxuICAgIHJldHVybiBwcmVwYXJlVmFsdWUodmFsLnRvUG9zdGdyZXMocHJlcGFyZVZhbHVlKSwgc2VlbilcbiAgfVxuICByZXR1cm4gSlNPTi5zdHJpbmdpZnkodmFsKVxufVxuXG5mdW5jdGlvbiBwYWQobnVtYmVyLCBkaWdpdHMpIHtcbiAgbnVtYmVyID0gJycgKyBudW1iZXJcbiAgd2hpbGUgKG51bWJlci5sZW5ndGggPCBkaWdpdHMpIHtcbiAgICBudW1iZXIgPSAnMCcgKyBudW1iZXJcbiAgfVxuICByZXR1cm4gbnVtYmVyXG59XG5cbmZ1bmN0aW9uIGRhdGVUb1N0cmluZyhkYXRlKSB7XG4gIHZhciBvZmZzZXQgPSAtZGF0ZS5nZXRUaW1lem9uZU9mZnNldCgpXG5cbiAgdmFyIHllYXIgPSBkYXRlLmdldEZ1bGxZZWFyKClcbiAgdmFyIGlzQkNZZWFyID0geWVhciA8IDFcbiAgaWYgKGlzQkNZZWFyKSB5ZWFyID0gTWF0aC5hYnMoeWVhcikgKyAxIC8vIG5lZ2F0aXZlIHllYXJzIGFyZSAxIG9mZiB0aGVpciBCQyByZXByZXNlbnRhdGlvblxuXG4gIHZhciByZXQgPVxuICAgIHBhZCh5ZWFyLCA0KSArXG4gICAgJy0nICtcbiAgICBwYWQoZGF0ZS5nZXRNb250aCgpICsgMSwgMikgK1xuICAgICctJyArXG4gICAgcGFkKGRhdGUuZ2V0RGF0ZSgpLCAyKSArXG4gICAgJ1QnICtcbiAgICBwYWQoZGF0ZS5nZXRIb3VycygpLCAyKSArXG4gICAgJzonICtcbiAgICBwYWQoZGF0ZS5nZXRNaW51dGVzKCksIDIpICtcbiAgICAnOicgK1xuICAgIHBhZChkYXRlLmdldFNlY29uZHMoKSwgMikgK1xuICAgICcuJyArXG4gICAgcGFkKGRhdGUuZ2V0TWlsbGlzZWNvbmRzKCksIDMpXG5cbiAgaWYgKG9mZnNldCA8IDApIHtcbiAgICByZXQgKz0gJy0nXG4gICAgb2Zmc2V0ICo9IC0xXG4gIH0gZWxzZSB7XG4gICAgcmV0ICs9ICcrJ1xuICB9XG5cbiAgcmV0ICs9IHBhZChNYXRoLmZsb29yKG9mZnNldCAvIDYwKSwgMikgKyAnOicgKyBwYWQob2Zmc2V0ICUgNjAsIDIpXG4gIGlmIChpc0JDWWVhcikgcmV0ICs9ICcgQkMnXG4gIHJldHVybiByZXRcbn1cblxuZnVuY3Rpb24gZGF0ZVRvU3RyaW5nVVRDKGRhdGUpIHtcbiAgdmFyIHllYXIgPSBkYXRlLmdldFVUQ0Z1bGxZZWFyKClcbiAgdmFyIGlzQkNZZWFyID0geWVhciA8IDFcbiAgaWYgKGlzQkNZZWFyKSB5ZWFyID0gTWF0aC5hYnMoeWVhcikgKyAxIC8vIG5lZ2F0aXZlIHllYXJzIGFyZSAxIG9mZiB0aGVpciBCQyByZXByZXNlbnRhdGlvblxuXG4gIHZhciByZXQgPVxuICAgIHBhZCh5ZWFyLCA0KSArXG4gICAgJy0nICtcbiAgICBwYWQoZGF0ZS5nZXRVVENNb250aCgpICsgMSwgMikgK1xuICAgICctJyArXG4gICAgcGFkKGRhdGUuZ2V0VVRDRGF0ZSgpLCAyKSArXG4gICAgJ1QnICtcbiAgICBwYWQoZGF0ZS5nZXRVVENIb3VycygpLCAyKSArXG4gICAgJzonICtcbiAgICBwYWQoZGF0ZS5nZXRVVENNaW51dGVzKCksIDIpICtcbiAgICAnOicgK1xuICAgIHBhZChkYXRlLmdldFVUQ1NlY29uZHMoKSwgMikgK1xuICAgICcuJyArXG4gICAgcGFkKGRhdGUuZ2V0VVRDTWlsbGlzZWNvbmRzKCksIDMpXG5cbiAgcmV0ICs9ICcrMDA6MDAnXG4gIGlmIChpc0JDWWVhcikgcmV0ICs9ICcgQkMnXG4gIHJldHVybiByZXRcbn1cblxuZnVuY3Rpb24gbm9ybWFsaXplUXVlcnlDb25maWcoY29uZmlnLCB2YWx1ZXMsIGNhbGxiYWNrKSB7XG4gIC8vIGNhbiB0YWtlIGluIHN0cmluZ3Mgb3IgY29uZmlnIG9iamVjdHNcbiAgY29uZmlnID0gdHlwZW9mIGNvbmZpZyA9PT0gJ3N0cmluZycgPyB7IHRleHQ6IGNvbmZpZyB9IDogY29uZmlnXG4gIGlmICh2YWx1ZXMpIHtcbiAgICBpZiAodHlwZW9mIHZhbHVlcyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgY29uZmlnLmNhbGxiYWNrID0gdmFsdWVzXG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbmZpZy52YWx1ZXMgPSB2YWx1ZXNcbiAgICB9XG4gIH1cbiAgaWYgKGNhbGxiYWNrKSB7XG4gICAgY29uZmlnLmNhbGxiYWNrID0gY2FsbGJhY2tcbiAgfVxuICByZXR1cm4gY29uZmlnXG59XG5cbmNvbnN0IG1kNSA9IGZ1bmN0aW9uIChzdHJpbmcpIHtcbiAgcmV0dXJuIGNyeXB0by5jcmVhdGVIYXNoKCdtZDUnKS51cGRhdGUoc3RyaW5nLCAndXRmLTgnKS5kaWdlc3QoJ2hleCcpXG59XG5cbi8vIFNlZSBBdXRoZW50aWNhdGlvbk1ENVBhc3N3b3JkIGF0IGh0dHBzOi8vd3d3LnBvc3RncmVzcWwub3JnL2RvY3MvY3VycmVudC9zdGF0aWMvcHJvdG9jb2wtZmxvdy5odG1sXG5jb25zdCBwb3N0Z3Jlc01kNVBhc3N3b3JkSGFzaCA9IGZ1bmN0aW9uICh1c2VyLCBwYXNzd29yZCwgc2FsdCkge1xuICB2YXIgaW5uZXIgPSBtZDUocGFzc3dvcmQgKyB1c2VyKVxuICB2YXIgb3V0ZXIgPSBtZDUoQnVmZmVyLmNvbmNhdChbQnVmZmVyLmZyb20oaW5uZXIpLCBzYWx0XSkpXG4gIHJldHVybiAnbWQ1JyArIG91dGVyXG59XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICBwcmVwYXJlVmFsdWU6IGZ1bmN0aW9uIHByZXBhcmVWYWx1ZVdyYXBwZXIodmFsdWUpIHtcbiAgICAvLyB0aGlzIGVuc3VyZXMgdGhhdCBleHRyYSBhcmd1bWVudHMgZG8gbm90IGdldCBwYXNzZWQgaW50byBwcmVwYXJlVmFsdWVcbiAgICAvLyBieSBhY2NpZGVudCwgZWc6IGZyb20gY2FsbGluZyB2YWx1ZXMubWFwKHV0aWxzLnByZXBhcmVWYWx1ZSlcbiAgICByZXR1cm4gcHJlcGFyZVZhbHVlKHZhbHVlKVxuICB9LFxuICBub3JtYWxpemVRdWVyeUNvbmZpZyxcbiAgcG9zdGdyZXNNZDVQYXNzd29yZEhhc2gsXG4gIG1kNSxcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxudmFyIHBhdGggPSByZXF1aXJlKCdwYXRoJylcbiAgLCBTdHJlYW0gPSByZXF1aXJlKCdzdHJlYW0nKS5TdHJlYW1cbiAgLCBzcGxpdCA9IHJlcXVpcmUoJ3NwbGl0MicpXG4gICwgdXRpbCA9IHJlcXVpcmUoJ3V0aWwnKVxuICAsIGRlZmF1bHRQb3J0ID0gNTQzMlxuICAsIGlzV2luID0gKHByb2Nlc3MucGxhdGZvcm0gPT09ICd3aW4zMicpXG4gICwgd2FyblN0cmVhbSA9IHByb2Nlc3Muc3RkZXJyXG47XG5cblxudmFyIFNfSVJXWEcgPSA1NiAgICAgLy8gICAgMDAwNzAoOClcbiAgLCBTX0lSV1hPID0gNyAgICAgIC8vICAgIDAwMDA3KDgpXG4gICwgU19JRk1UICA9IDYxNDQwICAvLyAwMDE3MDAwMCg4KVxuICAsIFNfSUZSRUcgPSAzMjc2OCAgLy8gIDAxMDAwMDAoOClcbjtcbmZ1bmN0aW9uIGlzUmVnRmlsZShtb2RlKSB7XG4gICAgcmV0dXJuICgobW9kZSAmIFNfSUZNVCkgPT0gU19JRlJFRyk7XG59XG5cbnZhciBmaWVsZE5hbWVzID0gWyAnaG9zdCcsICdwb3J0JywgJ2RhdGFiYXNlJywgJ3VzZXInLCAncGFzc3dvcmQnIF07XG52YXIgbnJPZkZpZWxkcyA9IGZpZWxkTmFtZXMubGVuZ3RoO1xudmFyIHBhc3NLZXkgPSBmaWVsZE5hbWVzWyBuck9mRmllbGRzIC0xIF07XG5cblxuZnVuY3Rpb24gd2FybigpIHtcbiAgICB2YXIgaXNXcml0YWJsZSA9IChcbiAgICAgICAgd2FyblN0cmVhbSBpbnN0YW5jZW9mIFN0cmVhbSAmJlxuICAgICAgICAgIHRydWUgPT09IHdhcm5TdHJlYW0ud3JpdGFibGVcbiAgICApO1xuXG4gICAgaWYgKGlzV3JpdGFibGUpIHtcbiAgICAgICAgdmFyIGFyZ3MgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChhcmd1bWVudHMpLmNvbmNhdChcIlxcblwiKTtcbiAgICAgICAgd2FyblN0cmVhbS53cml0ZSggdXRpbC5mb3JtYXQuYXBwbHkodXRpbCwgYXJncykgKTtcbiAgICB9XG59XG5cblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KG1vZHVsZS5leHBvcnRzLCAnaXNXaW4nLCB7XG4gICAgZ2V0IDogZnVuY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiBpc1dpbjtcbiAgICB9ICxcbiAgICBzZXQgOiBmdW5jdGlvbih2YWwpIHtcbiAgICAgICAgaXNXaW4gPSB2YWw7XG4gICAgfVxufSk7XG5cblxubW9kdWxlLmV4cG9ydHMud2FyblRvID0gZnVuY3Rpb24oc3RyZWFtKSB7XG4gICAgdmFyIG9sZCA9IHdhcm5TdHJlYW07XG4gICAgd2FyblN0cmVhbSA9IHN0cmVhbTtcbiAgICByZXR1cm4gb2xkO1xufTtcblxubW9kdWxlLmV4cG9ydHMuZ2V0RmlsZU5hbWUgPSBmdW5jdGlvbihyYXdFbnYpe1xuICAgIHZhciBlbnYgPSByYXdFbnYgfHwgcHJvY2Vzcy5lbnY7XG4gICAgdmFyIGZpbGUgPSBlbnYuUEdQQVNTRklMRSB8fCAoXG4gICAgICAgIGlzV2luID9cbiAgICAgICAgICBwYXRoLmpvaW4oIGVudi5BUFBEQVRBIHx8ICcuLycgLCAncG9zdGdyZXNxbCcsICdwZ3Bhc3MuY29uZicgKSA6XG4gICAgICAgICAgcGF0aC5qb2luKCBlbnYuSE9NRSB8fCAnLi8nLCAnLnBncGFzcycgKVxuICAgICk7XG4gICAgcmV0dXJuIGZpbGU7XG59O1xuXG5tb2R1bGUuZXhwb3J0cy51c2VQZ1Bhc3MgPSBmdW5jdGlvbihzdGF0cywgZm5hbWUpIHtcbiAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHByb2Nlc3MuZW52LCAnUEdQQVNTV09SRCcpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICBpZiAoaXNXaW4pIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuXG4gICAgZm5hbWUgPSBmbmFtZSB8fCAnPHVua24+JztcblxuICAgIGlmICghIGlzUmVnRmlsZShzdGF0cy5tb2RlKSkge1xuICAgICAgICB3YXJuKCdXQVJOSU5HOiBwYXNzd29yZCBmaWxlIFwiJXNcIiBpcyBub3QgYSBwbGFpbiBmaWxlJywgZm5hbWUpO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgaWYgKHN0YXRzLm1vZGUgJiAoU19JUldYRyB8IFNfSVJXWE8pKSB7XG4gICAgICAgIC8qIElmIHBhc3N3b3JkIGZpbGUgaXMgaW5zZWN1cmUsIGFsZXJ0IHRoZSB1c2VyIGFuZCBpZ25vcmUgaXQuICovXG4gICAgICAgIHdhcm4oJ1dBUk5JTkc6IHBhc3N3b3JkIGZpbGUgXCIlc1wiIGhhcyBncm91cCBvciB3b3JsZCBhY2Nlc3M7IHBlcm1pc3Npb25zIHNob3VsZCBiZSB1PXJ3ICgwNjAwKSBvciBsZXNzJywgZm5hbWUpO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRydWU7XG59O1xuXG5cbnZhciBtYXRjaGVyID0gbW9kdWxlLmV4cG9ydHMubWF0Y2ggPSBmdW5jdGlvbihjb25uSW5mbywgZW50cnkpIHtcbiAgICByZXR1cm4gZmllbGROYW1lcy5zbGljZSgwLCAtMSkucmVkdWNlKGZ1bmN0aW9uKHByZXYsIGZpZWxkLCBpZHgpe1xuICAgICAgICBpZiAoaWR4ID09IDEpIHtcbiAgICAgICAgICAgIC8vIHRoZSBwb3J0XG4gICAgICAgICAgICBpZiAoIE51bWJlciggY29ubkluZm9bZmllbGRdIHx8IGRlZmF1bHRQb3J0ICkgPT09IE51bWJlciggZW50cnlbZmllbGRdICkgKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHByZXYgJiYgdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcHJldiAmJiAoXG4gICAgICAgICAgICBlbnRyeVtmaWVsZF0gPT09ICcqJyB8fFxuICAgICAgICAgICAgICBlbnRyeVtmaWVsZF0gPT09IGNvbm5JbmZvW2ZpZWxkXVxuICAgICAgICApO1xuICAgIH0sIHRydWUpO1xufTtcblxuXG5tb2R1bGUuZXhwb3J0cy5nZXRQYXNzd29yZCA9IGZ1bmN0aW9uKGNvbm5JbmZvLCBzdHJlYW0sIGNiKSB7XG4gICAgdmFyIHBhc3M7XG4gICAgdmFyIGxpbmVTdHJlYW0gPSBzdHJlYW0ucGlwZShzcGxpdCgpKTtcblxuICAgIGZ1bmN0aW9uIG9uTGluZShsaW5lKSB7XG4gICAgICAgIHZhciBlbnRyeSA9IHBhcnNlTGluZShsaW5lKTtcbiAgICAgICAgaWYgKGVudHJ5ICYmIGlzVmFsaWRFbnRyeShlbnRyeSkgJiYgbWF0Y2hlcihjb25uSW5mbywgZW50cnkpKSB7XG4gICAgICAgICAgICBwYXNzID0gZW50cnlbcGFzc0tleV07XG4gICAgICAgICAgICBsaW5lU3RyZWFtLmVuZCgpOyAvLyAtPiBjYWxscyBvbkVuZCgpLCBidXQgcGFzcyBpcyBzZXQgbm93XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICB2YXIgb25FbmQgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgc3RyZWFtLmRlc3Ryb3koKTtcbiAgICAgICAgY2IocGFzcyk7XG4gICAgfTtcblxuICAgIHZhciBvbkVyciA9IGZ1bmN0aW9uKGVycikge1xuICAgICAgICBzdHJlYW0uZGVzdHJveSgpO1xuICAgICAgICB3YXJuKCdXQVJOSU5HOiBlcnJvciBvbiByZWFkaW5nIGZpbGU6ICVzJywgZXJyKTtcbiAgICAgICAgY2IodW5kZWZpbmVkKTtcbiAgICB9O1xuXG4gICAgc3RyZWFtLm9uKCdlcnJvcicsIG9uRXJyKTtcbiAgICBsaW5lU3RyZWFtXG4gICAgICAgIC5vbignZGF0YScsIG9uTGluZSlcbiAgICAgICAgLm9uKCdlbmQnLCBvbkVuZClcbiAgICAgICAgLm9uKCdlcnJvcicsIG9uRXJyKVxuICAgIDtcblxufTtcblxuXG52YXIgcGFyc2VMaW5lID0gbW9kdWxlLmV4cG9ydHMucGFyc2VMaW5lID0gZnVuY3Rpb24obGluZSkge1xuICAgIGlmIChsaW5lLmxlbmd0aCA8IDExIHx8IGxpbmUubWF0Y2goL15cXHMrIy8pKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIHZhciBjdXJDaGFyID0gJyc7XG4gICAgdmFyIHByZXZDaGFyID0gJyc7XG4gICAgdmFyIGZpZWxkSWR4ID0gMDtcbiAgICB2YXIgc3RhcnRJZHggPSAwO1xuICAgIHZhciBlbmRJZHggPSAwO1xuICAgIHZhciBvYmogPSB7fTtcbiAgICB2YXIgaXNMYXN0RmllbGQgPSBmYWxzZTtcbiAgICB2YXIgYWRkVG9PYmogPSBmdW5jdGlvbihpZHgsIGkwLCBpMSkge1xuICAgICAgICB2YXIgZmllbGQgPSBsaW5lLnN1YnN0cmluZyhpMCwgaTEpO1xuXG4gICAgICAgIGlmICghIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKHByb2Nlc3MuZW52LCAnUEdQQVNTX05PX0RFRVNDQVBFJykpIHtcbiAgICAgICAgICAgIGZpZWxkID0gZmllbGQucmVwbGFjZSgvXFxcXChbOlxcXFxdKS9nLCAnJDEnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIG9ialsgZmllbGROYW1lc1tpZHhdIF0gPSBmaWVsZDtcbiAgICB9O1xuXG4gICAgZm9yICh2YXIgaSA9IDAgOyBpIDwgbGluZS5sZW5ndGgtMSA7IGkgKz0gMSkge1xuICAgICAgICBjdXJDaGFyID0gbGluZS5jaGFyQXQoaSsxKTtcbiAgICAgICAgcHJldkNoYXIgPSBsaW5lLmNoYXJBdChpKTtcblxuICAgICAgICBpc0xhc3RGaWVsZCA9IChmaWVsZElkeCA9PSBuck9mRmllbGRzLTEpO1xuXG4gICAgICAgIGlmIChpc0xhc3RGaWVsZCkge1xuICAgICAgICAgICAgYWRkVG9PYmooZmllbGRJZHgsIHN0YXJ0SWR4KTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGkgPj0gMCAmJiBjdXJDaGFyID09ICc6JyAmJiBwcmV2Q2hhciAhPT0gJ1xcXFwnKSB7XG4gICAgICAgICAgICBhZGRUb09iaihmaWVsZElkeCwgc3RhcnRJZHgsIGkrMSk7XG5cbiAgICAgICAgICAgIHN0YXJ0SWR4ID0gaSsyO1xuICAgICAgICAgICAgZmllbGRJZHggKz0gMTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIG9iaiA9ICggT2JqZWN0LmtleXMob2JqKS5sZW5ndGggPT09IG5yT2ZGaWVsZHMgKSA/IG9iaiA6IG51bGw7XG5cbiAgICByZXR1cm4gb2JqO1xufTtcblxuXG52YXIgaXNWYWxpZEVudHJ5ID0gbW9kdWxlLmV4cG9ydHMuaXNWYWxpZEVudHJ5ID0gZnVuY3Rpb24oZW50cnkpe1xuICAgIHZhciBydWxlcyA9IHtcbiAgICAgICAgLy8gaG9zdFxuICAgICAgICAwIDogZnVuY3Rpb24oeCl7XG4gICAgICAgICAgICByZXR1cm4geC5sZW5ndGggPiAwO1xuICAgICAgICB9ICxcbiAgICAgICAgLy8gcG9ydFxuICAgICAgICAxIDogZnVuY3Rpb24oeCl7XG4gICAgICAgICAgICBpZiAoeCA9PT0gJyonKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB4ID0gTnVtYmVyKHgpO1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICBpc0Zpbml0ZSh4KSAmJlxuICAgICAgICAgICAgICAgICAgeCA+IDAgJiZcbiAgICAgICAgICAgICAgICAgIHggPCA5MDA3MTk5MjU0NzQwOTkyICYmXG4gICAgICAgICAgICAgICAgICBNYXRoLmZsb29yKHgpID09PSB4XG4gICAgICAgICAgICApO1xuICAgICAgICB9ICxcbiAgICAgICAgLy8gZGF0YWJhc2VcbiAgICAgICAgMiA6IGZ1bmN0aW9uKHgpe1xuICAgICAgICAgICAgcmV0dXJuIHgubGVuZ3RoID4gMDtcbiAgICAgICAgfSAsXG4gICAgICAgIC8vIHVzZXJuYW1lXG4gICAgICAgIDMgOiBmdW5jdGlvbih4KXtcbiAgICAgICAgICAgIHJldHVybiB4Lmxlbmd0aCA+IDA7XG4gICAgICAgIH0gLFxuICAgICAgICAvLyBwYXNzd29yZFxuICAgICAgICA0IDogZnVuY3Rpb24oeCl7XG4gICAgICAgICAgICByZXR1cm4geC5sZW5ndGggPiAwO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGZvciAodmFyIGlkeCA9IDAgOyBpZHggPCBmaWVsZE5hbWVzLmxlbmd0aCA7IGlkeCArPSAxKSB7XG4gICAgICAgIHZhciBydWxlID0gcnVsZXNbaWR4XTtcbiAgICAgICAgdmFyIHZhbHVlID0gZW50cnlbIGZpZWxkTmFtZXNbaWR4XSBdIHx8ICcnO1xuXG4gICAgICAgIHZhciByZXMgPSBydWxlKHZhbHVlKTtcbiAgICAgICAgaWYgKCFyZXMpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiB0cnVlO1xufTtcblxuIiwiJ3VzZSBzdHJpY3QnO1xuXG52YXIgcGF0aCA9IHJlcXVpcmUoJ3BhdGgnKVxuICAsIGZzID0gcmVxdWlyZSgnZnMnKVxuICAsIGhlbHBlciA9IHJlcXVpcmUoJy4vaGVscGVyLmpzJylcbjtcblxuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uKGNvbm5JbmZvLCBjYikge1xuICAgIHZhciBmaWxlID0gaGVscGVyLmdldEZpbGVOYW1lKCk7XG4gICAgXG4gICAgZnMuc3RhdChmaWxlLCBmdW5jdGlvbihlcnIsIHN0YXQpe1xuICAgICAgICBpZiAoZXJyIHx8ICFoZWxwZXIudXNlUGdQYXNzKHN0YXQsIGZpbGUpKSB7XG4gICAgICAgICAgICByZXR1cm4gY2IodW5kZWZpbmVkKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHZhciBzdCA9IGZzLmNyZWF0ZVJlYWRTdHJlYW0oZmlsZSk7XG5cbiAgICAgICAgaGVscGVyLmdldFBhc3N3b3JkKGNvbm5JbmZvLCBzdCwgY2IpO1xuICAgIH0pO1xufTtcblxubW9kdWxlLmV4cG9ydHMud2FyblRvID0gaGVscGVyLndhcm5UbztcbiIsIid1c2Ugc3RyaWN0J1xuXG5leHBvcnRzLnBhcnNlID0gZnVuY3Rpb24gKHNvdXJjZSwgdHJhbnNmb3JtKSB7XG4gIHJldHVybiBuZXcgQXJyYXlQYXJzZXIoc291cmNlLCB0cmFuc2Zvcm0pLnBhcnNlKClcbn1cblxuY2xhc3MgQXJyYXlQYXJzZXIge1xuICBjb25zdHJ1Y3RvciAoc291cmNlLCB0cmFuc2Zvcm0pIHtcbiAgICB0aGlzLnNvdXJjZSA9IHNvdXJjZVxuICAgIHRoaXMudHJhbnNmb3JtID0gdHJhbnNmb3JtIHx8IGlkZW50aXR5XG4gICAgdGhpcy5wb3NpdGlvbiA9IDBcbiAgICB0aGlzLmVudHJpZXMgPSBbXVxuICAgIHRoaXMucmVjb3JkZWQgPSBbXVxuICAgIHRoaXMuZGltZW5zaW9uID0gMFxuICB9XG5cbiAgaXNFb2YgKCkge1xuICAgIHJldHVybiB0aGlzLnBvc2l0aW9uID49IHRoaXMuc291cmNlLmxlbmd0aFxuICB9XG5cbiAgbmV4dENoYXJhY3RlciAoKSB7XG4gICAgdmFyIGNoYXJhY3RlciA9IHRoaXMuc291cmNlW3RoaXMucG9zaXRpb24rK11cbiAgICBpZiAoY2hhcmFjdGVyID09PSAnXFxcXCcpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHZhbHVlOiB0aGlzLnNvdXJjZVt0aGlzLnBvc2l0aW9uKytdLFxuICAgICAgICBlc2NhcGVkOiB0cnVlXG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICB2YWx1ZTogY2hhcmFjdGVyLFxuICAgICAgZXNjYXBlZDogZmFsc2VcbiAgICB9XG4gIH1cblxuICByZWNvcmQgKGNoYXJhY3Rlcikge1xuICAgIHRoaXMucmVjb3JkZWQucHVzaChjaGFyYWN0ZXIpXG4gIH1cblxuICBuZXdFbnRyeSAoaW5jbHVkZUVtcHR5KSB7XG4gICAgdmFyIGVudHJ5XG4gICAgaWYgKHRoaXMucmVjb3JkZWQubGVuZ3RoID4gMCB8fCBpbmNsdWRlRW1wdHkpIHtcbiAgICAgIGVudHJ5ID0gdGhpcy5yZWNvcmRlZC5qb2luKCcnKVxuICAgICAgaWYgKGVudHJ5ID09PSAnTlVMTCcgJiYgIWluY2x1ZGVFbXB0eSkge1xuICAgICAgICBlbnRyeSA9IG51bGxcbiAgICAgIH1cbiAgICAgIGlmIChlbnRyeSAhPT0gbnVsbCkgZW50cnkgPSB0aGlzLnRyYW5zZm9ybShlbnRyeSlcbiAgICAgIHRoaXMuZW50cmllcy5wdXNoKGVudHJ5KVxuICAgICAgdGhpcy5yZWNvcmRlZCA9IFtdXG4gICAgfVxuICB9XG5cbiAgY29uc3VtZURpbWVuc2lvbnMgKCkge1xuICAgIGlmICh0aGlzLnNvdXJjZVswXSA9PT0gJ1snKSB7XG4gICAgICB3aGlsZSAoIXRoaXMuaXNFb2YoKSkge1xuICAgICAgICB2YXIgY2hhciA9IHRoaXMubmV4dENoYXJhY3RlcigpXG4gICAgICAgIGlmIChjaGFyLnZhbHVlID09PSAnPScpIGJyZWFrXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcGFyc2UgKG5lc3RlZCkge1xuICAgIHZhciBjaGFyYWN0ZXIsIHBhcnNlciwgcXVvdGVcbiAgICB0aGlzLmNvbnN1bWVEaW1lbnNpb25zKClcbiAgICB3aGlsZSAoIXRoaXMuaXNFb2YoKSkge1xuICAgICAgY2hhcmFjdGVyID0gdGhpcy5uZXh0Q2hhcmFjdGVyKClcbiAgICAgIGlmIChjaGFyYWN0ZXIudmFsdWUgPT09ICd7JyAmJiAhcXVvdGUpIHtcbiAgICAgICAgdGhpcy5kaW1lbnNpb24rK1xuICAgICAgICBpZiAodGhpcy5kaW1lbnNpb24gPiAxKSB7XG4gICAgICAgICAgcGFyc2VyID0gbmV3IEFycmF5UGFyc2VyKHRoaXMuc291cmNlLnN1YnN0cih0aGlzLnBvc2l0aW9uIC0gMSksIHRoaXMudHJhbnNmb3JtKVxuICAgICAgICAgIHRoaXMuZW50cmllcy5wdXNoKHBhcnNlci5wYXJzZSh0cnVlKSlcbiAgICAgICAgICB0aGlzLnBvc2l0aW9uICs9IHBhcnNlci5wb3NpdGlvbiAtIDJcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChjaGFyYWN0ZXIudmFsdWUgPT09ICd9JyAmJiAhcXVvdGUpIHtcbiAgICAgICAgdGhpcy5kaW1lbnNpb24tLVxuICAgICAgICBpZiAoIXRoaXMuZGltZW5zaW9uKSB7XG4gICAgICAgICAgdGhpcy5uZXdFbnRyeSgpXG4gICAgICAgICAgaWYgKG5lc3RlZCkgcmV0dXJuIHRoaXMuZW50cmllc1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKGNoYXJhY3Rlci52YWx1ZSA9PT0gJ1wiJyAmJiAhY2hhcmFjdGVyLmVzY2FwZWQpIHtcbiAgICAgICAgaWYgKHF1b3RlKSB0aGlzLm5ld0VudHJ5KHRydWUpXG4gICAgICAgIHF1b3RlID0gIXF1b3RlXG4gICAgICB9IGVsc2UgaWYgKGNoYXJhY3Rlci52YWx1ZSA9PT0gJywnICYmICFxdW90ZSkge1xuICAgICAgICB0aGlzLm5ld0VudHJ5KClcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMucmVjb3JkKGNoYXJhY3Rlci52YWx1ZSlcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHRoaXMuZGltZW5zaW9uICE9PSAwKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ2FycmF5IGRpbWVuc2lvbiBub3QgYmFsYW5jZWQnKVxuICAgIH1cbiAgICByZXR1cm4gdGhpcy5lbnRyaWVzXG4gIH1cbn1cblxuZnVuY3Rpb24gaWRlbnRpdHkgKHZhbHVlKSB7XG4gIHJldHVybiB2YWx1ZVxufVxuIiwiJ3VzZSBzdHJpY3QnXG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gcGFyc2VCeXRlYSAoaW5wdXQpIHtcbiAgaWYgKC9eXFxcXHgvLnRlc3QoaW5wdXQpKSB7XG4gICAgLy8gbmV3ICdoZXgnIHN0eWxlIHJlc3BvbnNlIChwZyA+OS4wKVxuICAgIHJldHVybiBuZXcgQnVmZmVyKGlucHV0LnN1YnN0cigyKSwgJ2hleCcpXG4gIH1cbiAgdmFyIG91dHB1dCA9ICcnXG4gIHZhciBpID0gMFxuICB3aGlsZSAoaSA8IGlucHV0Lmxlbmd0aCkge1xuICAgIGlmIChpbnB1dFtpXSAhPT0gJ1xcXFwnKSB7XG4gICAgICBvdXRwdXQgKz0gaW5wdXRbaV1cbiAgICAgICsraVxuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoL1swLTddezN9Ly50ZXN0KGlucHV0LnN1YnN0cihpICsgMSwgMykpKSB7XG4gICAgICAgIG91dHB1dCArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKHBhcnNlSW50KGlucHV0LnN1YnN0cihpICsgMSwgMyksIDgpKVxuICAgICAgICBpICs9IDRcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHZhciBiYWNrc2xhc2hlcyA9IDFcbiAgICAgICAgd2hpbGUgKGkgKyBiYWNrc2xhc2hlcyA8IGlucHV0Lmxlbmd0aCAmJiBpbnB1dFtpICsgYmFja3NsYXNoZXNdID09PSAnXFxcXCcpIHtcbiAgICAgICAgICBiYWNrc2xhc2hlcysrXG4gICAgICAgIH1cbiAgICAgICAgZm9yICh2YXIgayA9IDA7IGsgPCBNYXRoLmZsb29yKGJhY2tzbGFzaGVzIC8gMik7ICsraykge1xuICAgICAgICAgIG91dHB1dCArPSAnXFxcXCdcbiAgICAgICAgfVxuICAgICAgICBpICs9IE1hdGguZmxvb3IoYmFja3NsYXNoZXMgLyAyKSAqIDJcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIG5ldyBCdWZmZXIob3V0cHV0LCAnYmluYXJ5Jylcbn1cbiIsIid1c2Ugc3RyaWN0J1xuXG52YXIgREFURV9USU1FID0gLyhcXGR7MSx9KS0oXFxkezJ9KS0oXFxkezJ9KSAoXFxkezJ9KTooXFxkezJ9KTooXFxkezJ9KShcXC5cXGR7MSx9KT8uKj8oIEJDKT8kL1xudmFyIERBVEUgPSAvXihcXGR7MSx9KS0oXFxkezJ9KS0oXFxkezJ9KSggQkMpPyQvXG52YXIgVElNRV9aT05FID0gLyhbWistXSkoXFxkezJ9KT86PyhcXGR7Mn0pPzo/KFxcZHsyfSk/L1xudmFyIElORklOSVRZID0gL14tP2luZmluaXR5JC9cblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBwYXJzZURhdGUgKGlzb0RhdGUpIHtcbiAgaWYgKElORklOSVRZLnRlc3QoaXNvRGF0ZSkpIHtcbiAgICAvLyBDYXBpdGFsaXplIHRvIEluZmluaXR5IGJlZm9yZSBwYXNzaW5nIHRvIE51bWJlclxuICAgIHJldHVybiBOdW1iZXIoaXNvRGF0ZS5yZXBsYWNlKCdpJywgJ0knKSlcbiAgfVxuICB2YXIgbWF0Y2hlcyA9IERBVEVfVElNRS5leGVjKGlzb0RhdGUpXG5cbiAgaWYgKCFtYXRjaGVzKSB7XG4gICAgLy8gRm9yY2UgWVlZWS1NTS1ERCBkYXRlcyB0byBiZSBwYXJzZWQgYXMgbG9jYWwgdGltZVxuICAgIHJldHVybiBnZXREYXRlKGlzb0RhdGUpIHx8IG51bGxcbiAgfVxuXG4gIHZhciBpc0JDID0gISFtYXRjaGVzWzhdXG4gIHZhciB5ZWFyID0gcGFyc2VJbnQobWF0Y2hlc1sxXSwgMTApXG4gIGlmIChpc0JDKSB7XG4gICAgeWVhciA9IGJjWWVhclRvTmVnYXRpdmVZZWFyKHllYXIpXG4gIH1cblxuICB2YXIgbW9udGggPSBwYXJzZUludChtYXRjaGVzWzJdLCAxMCkgLSAxXG4gIHZhciBkYXkgPSBtYXRjaGVzWzNdXG4gIHZhciBob3VyID0gcGFyc2VJbnQobWF0Y2hlc1s0XSwgMTApXG4gIHZhciBtaW51dGUgPSBwYXJzZUludChtYXRjaGVzWzVdLCAxMClcbiAgdmFyIHNlY29uZCA9IHBhcnNlSW50KG1hdGNoZXNbNl0sIDEwKVxuXG4gIHZhciBtcyA9IG1hdGNoZXNbN11cbiAgbXMgPSBtcyA/IDEwMDAgKiBwYXJzZUZsb2F0KG1zKSA6IDBcblxuICB2YXIgZGF0ZVxuICB2YXIgb2Zmc2V0ID0gdGltZVpvbmVPZmZzZXQoaXNvRGF0ZSlcbiAgaWYgKG9mZnNldCAhPSBudWxsKSB7XG4gICAgZGF0ZSA9IG5ldyBEYXRlKERhdGUuVVRDKHllYXIsIG1vbnRoLCBkYXksIGhvdXIsIG1pbnV0ZSwgc2Vjb25kLCBtcykpXG5cbiAgICAvLyBBY2NvdW50IGZvciB5ZWFycyBmcm9tIDAgdG8gOTkgYmVpbmcgaW50ZXJwcmV0ZWQgYXMgMTkwMC0xOTk5XG4gICAgLy8gYnkgRGF0ZS5VVEMgLyB0aGUgbXVsdGktYXJndW1lbnQgZm9ybSBvZiB0aGUgRGF0ZSBjb25zdHJ1Y3RvclxuICAgIGlmIChpczBUbzk5KHllYXIpKSB7XG4gICAgICBkYXRlLnNldFVUQ0Z1bGxZZWFyKHllYXIpXG4gICAgfVxuXG4gICAgaWYgKG9mZnNldCAhPT0gMCkge1xuICAgICAgZGF0ZS5zZXRUaW1lKGRhdGUuZ2V0VGltZSgpIC0gb2Zmc2V0KVxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBkYXRlID0gbmV3IERhdGUoeWVhciwgbW9udGgsIGRheSwgaG91ciwgbWludXRlLCBzZWNvbmQsIG1zKVxuXG4gICAgaWYgKGlzMFRvOTkoeWVhcikpIHtcbiAgICAgIGRhdGUuc2V0RnVsbFllYXIoeWVhcilcbiAgICB9XG4gIH1cblxuICByZXR1cm4gZGF0ZVxufVxuXG5mdW5jdGlvbiBnZXREYXRlIChpc29EYXRlKSB7XG4gIHZhciBtYXRjaGVzID0gREFURS5leGVjKGlzb0RhdGUpXG4gIGlmICghbWF0Y2hlcykge1xuICAgIHJldHVyblxuICB9XG5cbiAgdmFyIHllYXIgPSBwYXJzZUludChtYXRjaGVzWzFdLCAxMClcbiAgdmFyIGlzQkMgPSAhIW1hdGNoZXNbNF1cbiAgaWYgKGlzQkMpIHtcbiAgICB5ZWFyID0gYmNZZWFyVG9OZWdhdGl2ZVllYXIoeWVhcilcbiAgfVxuXG4gIHZhciBtb250aCA9IHBhcnNlSW50KG1hdGNoZXNbMl0sIDEwKSAtIDFcbiAgdmFyIGRheSA9IG1hdGNoZXNbM11cbiAgLy8gWVlZWS1NTS1ERCB3aWxsIGJlIHBhcnNlZCBhcyBsb2NhbCB0aW1lXG4gIHZhciBkYXRlID0gbmV3IERhdGUoeWVhciwgbW9udGgsIGRheSlcblxuICBpZiAoaXMwVG85OSh5ZWFyKSkge1xuICAgIGRhdGUuc2V0RnVsbFllYXIoeWVhcilcbiAgfVxuXG4gIHJldHVybiBkYXRlXG59XG5cbi8vIG1hdGNoIHRpbWV6b25lczpcbi8vIFogKFVUQylcbi8vIC0wNVxuLy8gKzA2OjMwXG5mdW5jdGlvbiB0aW1lWm9uZU9mZnNldCAoaXNvRGF0ZSkge1xuICBpZiAoaXNvRGF0ZS5lbmRzV2l0aCgnKzAwJykpIHtcbiAgICByZXR1cm4gMFxuICB9XG5cbiAgdmFyIHpvbmUgPSBUSU1FX1pPTkUuZXhlYyhpc29EYXRlLnNwbGl0KCcgJylbMV0pXG4gIGlmICghem9uZSkgcmV0dXJuXG4gIHZhciB0eXBlID0gem9uZVsxXVxuXG4gIGlmICh0eXBlID09PSAnWicpIHtcbiAgICByZXR1cm4gMFxuICB9XG4gIHZhciBzaWduID0gdHlwZSA9PT0gJy0nID8gLTEgOiAxXG4gIHZhciBvZmZzZXQgPSBwYXJzZUludCh6b25lWzJdLCAxMCkgKiAzNjAwICtcbiAgICBwYXJzZUludCh6b25lWzNdIHx8IDAsIDEwKSAqIDYwICtcbiAgICBwYXJzZUludCh6b25lWzRdIHx8IDAsIDEwKVxuXG4gIHJldHVybiBvZmZzZXQgKiBzaWduICogMTAwMFxufVxuXG5mdW5jdGlvbiBiY1llYXJUb05lZ2F0aXZlWWVhciAoeWVhcikge1xuICAvLyBBY2NvdW50IGZvciBudW1lcmljYWwgZGlmZmVyZW5jZSBiZXR3ZWVuIHJlcHJlc2VudGF0aW9ucyBvZiBCQyB5ZWFyc1xuICAvLyBTZWU6IGh0dHBzOi8vZ2l0aHViLmNvbS9iZW5kcnVja2VyL3Bvc3RncmVzLWRhdGUvaXNzdWVzLzVcbiAgcmV0dXJuIC0oeWVhciAtIDEpXG59XG5cbmZ1bmN0aW9uIGlzMFRvOTkgKG51bSkge1xuICByZXR1cm4gbnVtID49IDAgJiYgbnVtIDwgMTAwXG59XG4iLCIndXNlIHN0cmljdCdcblxudmFyIGV4dGVuZCA9IHJlcXVpcmUoJ3h0ZW5kL211dGFibGUnKVxuXG5tb2R1bGUuZXhwb3J0cyA9IFBvc3RncmVzSW50ZXJ2YWxcblxuZnVuY3Rpb24gUG9zdGdyZXNJbnRlcnZhbCAocmF3KSB7XG4gIGlmICghKHRoaXMgaW5zdGFuY2VvZiBQb3N0Z3Jlc0ludGVydmFsKSkge1xuICAgIHJldHVybiBuZXcgUG9zdGdyZXNJbnRlcnZhbChyYXcpXG4gIH1cbiAgZXh0ZW5kKHRoaXMsIHBhcnNlKHJhdykpXG59XG52YXIgcHJvcGVydGllcyA9IFsnc2Vjb25kcycsICdtaW51dGVzJywgJ2hvdXJzJywgJ2RheXMnLCAnbW9udGhzJywgJ3llYXJzJ11cblBvc3RncmVzSW50ZXJ2YWwucHJvdG90eXBlLnRvUG9zdGdyZXMgPSBmdW5jdGlvbiAoKSB7XG4gIHZhciBmaWx0ZXJlZCA9IHByb3BlcnRpZXMuZmlsdGVyKHRoaXMuaGFzT3duUHJvcGVydHksIHRoaXMpXG5cbiAgLy8gSW4gYWRkaXRpb24gdG8gYHByb3BlcnRpZXNgLCB3ZSBuZWVkIHRvIGFjY291bnQgZm9yIGZyYWN0aW9ucyBvZiBzZWNvbmRzLlxuICBpZiAodGhpcy5taWxsaXNlY29uZHMgJiYgZmlsdGVyZWQuaW5kZXhPZignc2Vjb25kcycpIDwgMCkge1xuICAgIGZpbHRlcmVkLnB1c2goJ3NlY29uZHMnKVxuICB9XG5cbiAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgcmV0dXJuICcwJ1xuICByZXR1cm4gZmlsdGVyZWRcbiAgICAubWFwKGZ1bmN0aW9uIChwcm9wZXJ0eSkge1xuICAgICAgdmFyIHZhbHVlID0gdGhpc1twcm9wZXJ0eV0gfHwgMFxuXG4gICAgICAvLyBBY2NvdW50IGZvciBmcmFjdGlvbmFsIHBhcnQgb2Ygc2Vjb25kcyxcbiAgICAgIC8vIHJlbW92ZSB0cmFpbGluZyB6ZXJvZXMuXG4gICAgICBpZiAocHJvcGVydHkgPT09ICdzZWNvbmRzJyAmJiB0aGlzLm1pbGxpc2Vjb25kcykge1xuICAgICAgICB2YWx1ZSA9ICh2YWx1ZSArIHRoaXMubWlsbGlzZWNvbmRzIC8gMTAwMCkudG9GaXhlZCg2KS5yZXBsYWNlKC9cXC4/MCskLywgJycpXG4gICAgICB9XG5cbiAgICAgIHJldHVybiB2YWx1ZSArICcgJyArIHByb3BlcnR5XG4gICAgfSwgdGhpcylcbiAgICAuam9pbignICcpXG59XG5cbnZhciBwcm9wZXJ0aWVzSVNPRXF1aXZhbGVudCA9IHtcbiAgeWVhcnM6ICdZJyxcbiAgbW9udGhzOiAnTScsXG4gIGRheXM6ICdEJyxcbiAgaG91cnM6ICdIJyxcbiAgbWludXRlczogJ00nLFxuICBzZWNvbmRzOiAnUydcbn1cbnZhciBkYXRlUHJvcGVydGllcyA9IFsneWVhcnMnLCAnbW9udGhzJywgJ2RheXMnXVxudmFyIHRpbWVQcm9wZXJ0aWVzID0gWydob3VycycsICdtaW51dGVzJywgJ3NlY29uZHMnXVxuLy8gYWNjb3JkaW5nIHRvIElTTyA4NjAxXG5Qb3N0Z3Jlc0ludGVydmFsLnByb3RvdHlwZS50b0lTT1N0cmluZyA9IFBvc3RncmVzSW50ZXJ2YWwucHJvdG90eXBlLnRvSVNPID0gZnVuY3Rpb24gKCkge1xuICB2YXIgZGF0ZVBhcnQgPSBkYXRlUHJvcGVydGllc1xuICAgIC5tYXAoYnVpbGRQcm9wZXJ0eSwgdGhpcylcbiAgICAuam9pbignJylcblxuICB2YXIgdGltZVBhcnQgPSB0aW1lUHJvcGVydGllc1xuICAgIC5tYXAoYnVpbGRQcm9wZXJ0eSwgdGhpcylcbiAgICAuam9pbignJylcblxuICByZXR1cm4gJ1AnICsgZGF0ZVBhcnQgKyAnVCcgKyB0aW1lUGFydFxuXG4gIGZ1bmN0aW9uIGJ1aWxkUHJvcGVydHkgKHByb3BlcnR5KSB7XG4gICAgdmFyIHZhbHVlID0gdGhpc1twcm9wZXJ0eV0gfHwgMFxuXG4gICAgLy8gQWNjb3VudCBmb3IgZnJhY3Rpb25hbCBwYXJ0IG9mIHNlY29uZHMsXG4gICAgLy8gcmVtb3ZlIHRyYWlsaW5nIHplcm9lcy5cbiAgICBpZiAocHJvcGVydHkgPT09ICdzZWNvbmRzJyAmJiB0aGlzLm1pbGxpc2Vjb25kcykge1xuICAgICAgdmFsdWUgPSAodmFsdWUgKyB0aGlzLm1pbGxpc2Vjb25kcyAvIDEwMDApLnRvRml4ZWQoNikucmVwbGFjZSgvMCskLywgJycpXG4gICAgfVxuXG4gICAgcmV0dXJuIHZhbHVlICsgcHJvcGVydGllc0lTT0VxdWl2YWxlbnRbcHJvcGVydHldXG4gIH1cbn1cblxudmFyIE5VTUJFUiA9ICcoWystXT9cXFxcZCspJ1xudmFyIFlFQVIgPSBOVU1CRVIgKyAnXFxcXHMreWVhcnM/J1xudmFyIE1PTlRIID0gTlVNQkVSICsgJ1xcXFxzK21vbnM/J1xudmFyIERBWSA9IE5VTUJFUiArICdcXFxccytkYXlzPydcbnZhciBUSU1FID0gJyhbKy1dKT8oW1xcXFxkXSopOihcXFxcZFxcXFxkKTooXFxcXGRcXFxcZClcXFxcLj8oXFxcXGR7MSw2fSk/J1xudmFyIElOVEVSVkFMID0gbmV3IFJlZ0V4cChbWUVBUiwgTU9OVEgsIERBWSwgVElNRV0ubWFwKGZ1bmN0aW9uIChyZWdleFN0cmluZykge1xuICByZXR1cm4gJygnICsgcmVnZXhTdHJpbmcgKyAnKT8nXG59KVxuICAuam9pbignXFxcXHMqJykpXG5cbi8vIFBvc2l0aW9ucyBvZiB2YWx1ZXMgaW4gcmVnZXggbWF0Y2hcbnZhciBwb3NpdGlvbnMgPSB7XG4gIHllYXJzOiAyLFxuICBtb250aHM6IDQsXG4gIGRheXM6IDYsXG4gIGhvdXJzOiA5LFxuICBtaW51dGVzOiAxMCxcbiAgc2Vjb25kczogMTEsXG4gIG1pbGxpc2Vjb25kczogMTJcbn1cbi8vIFdlIGNhbiB1c2UgbmVnYXRpdmUgdGltZVxudmFyIG5lZ2F0aXZlcyA9IFsnaG91cnMnLCAnbWludXRlcycsICdzZWNvbmRzJywgJ21pbGxpc2Vjb25kcyddXG5cbmZ1bmN0aW9uIHBhcnNlTWlsbGlzZWNvbmRzIChmcmFjdGlvbikge1xuICAvLyBhZGQgb21pdHRlZCB6ZXJvZXNcbiAgdmFyIG1pY3Jvc2Vjb25kcyA9IGZyYWN0aW9uICsgJzAwMDAwMCcuc2xpY2UoZnJhY3Rpb24ubGVuZ3RoKVxuICByZXR1cm4gcGFyc2VJbnQobWljcm9zZWNvbmRzLCAxMCkgLyAxMDAwXG59XG5cbmZ1bmN0aW9uIHBhcnNlIChpbnRlcnZhbCkge1xuICBpZiAoIWludGVydmFsKSByZXR1cm4ge31cbiAgdmFyIG1hdGNoZXMgPSBJTlRFUlZBTC5leGVjKGludGVydmFsKVxuICB2YXIgaXNOZWdhdGl2ZSA9IG1hdGNoZXNbOF0gPT09ICctJ1xuICByZXR1cm4gT2JqZWN0LmtleXMocG9zaXRpb25zKVxuICAgIC5yZWR1Y2UoZnVuY3Rpb24gKHBhcnNlZCwgcHJvcGVydHkpIHtcbiAgICAgIHZhciBwb3NpdGlvbiA9IHBvc2l0aW9uc1twcm9wZXJ0eV1cbiAgICAgIHZhciB2YWx1ZSA9IG1hdGNoZXNbcG9zaXRpb25dXG4gICAgICAvLyBubyBlbXB0eSBzdHJpbmdcbiAgICAgIGlmICghdmFsdWUpIHJldHVybiBwYXJzZWRcbiAgICAgIC8vIG1pbGxpc2Vjb25kcyBhcmUgYWN0dWFsbHkgbWljcm9zZWNvbmRzICh1cCB0byA2IGRpZ2l0cylcbiAgICAgIC8vIHdpdGggb21pdHRlZCB0cmFpbGluZyB6ZXJvZXMuXG4gICAgICB2YWx1ZSA9IHByb3BlcnR5ID09PSAnbWlsbGlzZWNvbmRzJ1xuICAgICAgICA/IHBhcnNlTWlsbGlzZWNvbmRzKHZhbHVlKVxuICAgICAgICA6IHBhcnNlSW50KHZhbHVlLCAxMClcbiAgICAgIC8vIG5vIHplcm9zXG4gICAgICBpZiAoIXZhbHVlKSByZXR1cm4gcGFyc2VkXG4gICAgICBpZiAoaXNOZWdhdGl2ZSAmJiB+bmVnYXRpdmVzLmluZGV4T2YocHJvcGVydHkpKSB7XG4gICAgICAgIHZhbHVlICo9IC0xXG4gICAgICB9XG4gICAgICBwYXJzZWRbcHJvcGVydHldID0gdmFsdWVcbiAgICAgIHJldHVybiBwYXJzZWRcbiAgICB9LCB7fSlcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuY29uc3QgY29kZXMgPSB7fTtcblxuZnVuY3Rpb24gY3JlYXRlRXJyb3JUeXBlKGNvZGUsIG1lc3NhZ2UsIEJhc2UpIHtcbiAgaWYgKCFCYXNlKSB7XG4gICAgQmFzZSA9IEVycm9yXG4gIH1cblxuICBmdW5jdGlvbiBnZXRNZXNzYWdlIChhcmcxLCBhcmcyLCBhcmczKSB7XG4gICAgaWYgKHR5cGVvZiBtZXNzYWdlID09PSAnc3RyaW5nJykge1xuICAgICAgcmV0dXJuIG1lc3NhZ2VcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIG1lc3NhZ2UoYXJnMSwgYXJnMiwgYXJnMylcbiAgICB9XG4gIH1cblxuICBjbGFzcyBOb2RlRXJyb3IgZXh0ZW5kcyBCYXNlIHtcbiAgICBjb25zdHJ1Y3RvciAoYXJnMSwgYXJnMiwgYXJnMykge1xuICAgICAgc3VwZXIoZ2V0TWVzc2FnZShhcmcxLCBhcmcyLCBhcmczKSk7XG4gICAgfVxuICB9XG5cbiAgTm9kZUVycm9yLnByb3RvdHlwZS5uYW1lID0gQmFzZS5uYW1lO1xuICBOb2RlRXJyb3IucHJvdG90eXBlLmNvZGUgPSBjb2RlO1xuXG4gIGNvZGVzW2NvZGVdID0gTm9kZUVycm9yO1xufVxuXG4vLyBodHRwczovL2dpdGh1Yi5jb20vbm9kZWpzL25vZGUvYmxvYi92MTAuOC4wL2xpYi9pbnRlcm5hbC9lcnJvcnMuanNcbmZ1bmN0aW9uIG9uZU9mKGV4cGVjdGVkLCB0aGluZykge1xuICBpZiAoQXJyYXkuaXNBcnJheShleHBlY3RlZCkpIHtcbiAgICBjb25zdCBsZW4gPSBleHBlY3RlZC5sZW5ndGg7XG4gICAgZXhwZWN0ZWQgPSBleHBlY3RlZC5tYXAoKGkpID0+IFN0cmluZyhpKSk7XG4gICAgaWYgKGxlbiA+IDIpIHtcbiAgICAgIHJldHVybiBgb25lIG9mICR7dGhpbmd9ICR7ZXhwZWN0ZWQuc2xpY2UoMCwgbGVuIC0gMSkuam9pbignLCAnKX0sIG9yIGAgK1xuICAgICAgICAgICAgIGV4cGVjdGVkW2xlbiAtIDFdO1xuICAgIH0gZWxzZSBpZiAobGVuID09PSAyKSB7XG4gICAgICByZXR1cm4gYG9uZSBvZiAke3RoaW5nfSAke2V4cGVjdGVkWzBdfSBvciAke2V4cGVjdGVkWzFdfWA7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBgb2YgJHt0aGluZ30gJHtleHBlY3RlZFswXX1gO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gYG9mICR7dGhpbmd9ICR7U3RyaW5nKGV4cGVjdGVkKX1gO1xuICB9XG59XG5cbi8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0phdmFTY3JpcHQvUmVmZXJlbmNlL0dsb2JhbF9PYmplY3RzL1N0cmluZy9zdGFydHNXaXRoXG5mdW5jdGlvbiBzdGFydHNXaXRoKHN0ciwgc2VhcmNoLCBwb3MpIHtcblx0cmV0dXJuIHN0ci5zdWJzdHIoIXBvcyB8fCBwb3MgPCAwID8gMCA6ICtwb3MsIHNlYXJjaC5sZW5ndGgpID09PSBzZWFyY2g7XG59XG5cbi8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0phdmFTY3JpcHQvUmVmZXJlbmNlL0dsb2JhbF9PYmplY3RzL1N0cmluZy9lbmRzV2l0aFxuZnVuY3Rpb24gZW5kc1dpdGgoc3RyLCBzZWFyY2gsIHRoaXNfbGVuKSB7XG5cdGlmICh0aGlzX2xlbiA9PT0gdW5kZWZpbmVkIHx8IHRoaXNfbGVuID4gc3RyLmxlbmd0aCkge1xuXHRcdHRoaXNfbGVuID0gc3RyLmxlbmd0aDtcblx0fVxuXHRyZXR1cm4gc3RyLnN1YnN0cmluZyh0aGlzX2xlbiAtIHNlYXJjaC5sZW5ndGgsIHRoaXNfbGVuKSA9PT0gc2VhcmNoO1xufVxuXG4vLyBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9KYXZhU2NyaXB0L1JlZmVyZW5jZS9HbG9iYWxfT2JqZWN0cy9TdHJpbmcvaW5jbHVkZXNcbmZ1bmN0aW9uIGluY2x1ZGVzKHN0ciwgc2VhcmNoLCBzdGFydCkge1xuICBpZiAodHlwZW9mIHN0YXJ0ICE9PSAnbnVtYmVyJykge1xuICAgIHN0YXJ0ID0gMDtcbiAgfVxuXG4gIGlmIChzdGFydCArIHNlYXJjaC5sZW5ndGggPiBzdHIubGVuZ3RoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9IGVsc2Uge1xuICAgIHJldHVybiBzdHIuaW5kZXhPZihzZWFyY2gsIHN0YXJ0KSAhPT0gLTE7XG4gIH1cbn1cblxuY3JlYXRlRXJyb3JUeXBlKCdFUlJfSU5WQUxJRF9PUFRfVkFMVUUnLCBmdW5jdGlvbiAobmFtZSwgdmFsdWUpIHtcbiAgcmV0dXJuICdUaGUgdmFsdWUgXCInICsgdmFsdWUgKyAnXCIgaXMgaW52YWxpZCBmb3Igb3B0aW9uIFwiJyArIG5hbWUgKyAnXCInXG59LCBUeXBlRXJyb3IpO1xuY3JlYXRlRXJyb3JUeXBlKCdFUlJfSU5WQUxJRF9BUkdfVFlQRScsIGZ1bmN0aW9uIChuYW1lLCBleHBlY3RlZCwgYWN0dWFsKSB7XG4gIC8vIGRldGVybWluZXI6ICdtdXN0IGJlJyBvciAnbXVzdCBub3QgYmUnXG4gIGxldCBkZXRlcm1pbmVyO1xuICBpZiAodHlwZW9mIGV4cGVjdGVkID09PSAnc3RyaW5nJyAmJiBzdGFydHNXaXRoKGV4cGVjdGVkLCAnbm90ICcpKSB7XG4gICAgZGV0ZXJtaW5lciA9ICdtdXN0IG5vdCBiZSc7XG4gICAgZXhwZWN0ZWQgPSBleHBlY3RlZC5yZXBsYWNlKC9ebm90IC8sICcnKTtcbiAgfSBlbHNlIHtcbiAgICBkZXRlcm1pbmVyID0gJ211c3QgYmUnO1xuICB9XG5cbiAgbGV0IG1zZztcbiAgaWYgKGVuZHNXaXRoKG5hbWUsICcgYXJndW1lbnQnKSkge1xuICAgIC8vIEZvciBjYXNlcyBsaWtlICdmaXJzdCBhcmd1bWVudCdcbiAgICBtc2cgPSBgVGhlICR7bmFtZX0gJHtkZXRlcm1pbmVyfSAke29uZU9mKGV4cGVjdGVkLCAndHlwZScpfWA7XG4gIH0gZWxzZSB7XG4gICAgY29uc3QgdHlwZSA9IGluY2x1ZGVzKG5hbWUsICcuJykgPyAncHJvcGVydHknIDogJ2FyZ3VtZW50JztcbiAgICBtc2cgPSBgVGhlIFwiJHtuYW1lfVwiICR7dHlwZX0gJHtkZXRlcm1pbmVyfSAke29uZU9mKGV4cGVjdGVkLCAndHlwZScpfWA7XG4gIH1cblxuICBtc2cgKz0gYC4gUmVjZWl2ZWQgdHlwZSAke3R5cGVvZiBhY3R1YWx9YDtcbiAgcmV0dXJuIG1zZztcbn0sIFR5cGVFcnJvcik7XG5jcmVhdGVFcnJvclR5cGUoJ0VSUl9TVFJFQU1fUFVTSF9BRlRFUl9FT0YnLCAnc3RyZWFtLnB1c2goKSBhZnRlciBFT0YnKTtcbmNyZWF0ZUVycm9yVHlwZSgnRVJSX01FVEhPRF9OT1RfSU1QTEVNRU5URUQnLCBmdW5jdGlvbiAobmFtZSkge1xuICByZXR1cm4gJ1RoZSAnICsgbmFtZSArICcgbWV0aG9kIGlzIG5vdCBpbXBsZW1lbnRlZCdcbn0pO1xuY3JlYXRlRXJyb3JUeXBlKCdFUlJfU1RSRUFNX1BSRU1BVFVSRV9DTE9TRScsICdQcmVtYXR1cmUgY2xvc2UnKTtcbmNyZWF0ZUVycm9yVHlwZSgnRVJSX1NUUkVBTV9ERVNUUk9ZRUQnLCBmdW5jdGlvbiAobmFtZSkge1xuICByZXR1cm4gJ0Nhbm5vdCBjYWxsICcgKyBuYW1lICsgJyBhZnRlciBhIHN0cmVhbSB3YXMgZGVzdHJveWVkJztcbn0pO1xuY3JlYXRlRXJyb3JUeXBlKCdFUlJfTVVMVElQTEVfQ0FMTEJBQ0snLCAnQ2FsbGJhY2sgY2FsbGVkIG11bHRpcGxlIHRpbWVzJyk7XG5jcmVhdGVFcnJvclR5cGUoJ0VSUl9TVFJFQU1fQ0FOTk9UX1BJUEUnLCAnQ2Fubm90IHBpcGUsIG5vdCByZWFkYWJsZScpO1xuY3JlYXRlRXJyb3JUeXBlKCdFUlJfU1RSRUFNX1dSSVRFX0FGVEVSX0VORCcsICd3cml0ZSBhZnRlciBlbmQnKTtcbmNyZWF0ZUVycm9yVHlwZSgnRVJSX1NUUkVBTV9OVUxMX1ZBTFVFUycsICdNYXkgbm90IHdyaXRlIG51bGwgdmFsdWVzIHRvIHN0cmVhbScsIFR5cGVFcnJvcik7XG5jcmVhdGVFcnJvclR5cGUoJ0VSUl9VTktOT1dOX0VOQ09ESU5HJywgZnVuY3Rpb24gKGFyZykge1xuICByZXR1cm4gJ1Vua25vd24gZW5jb2Rpbmc6ICcgKyBhcmdcbn0sIFR5cGVFcnJvcik7XG5jcmVhdGVFcnJvclR5cGUoJ0VSUl9TVFJFQU1fVU5TSElGVF9BRlRFUl9FTkRfRVZFTlQnLCAnc3RyZWFtLnVuc2hpZnQoKSBhZnRlciBlbmQgZXZlbnQnKTtcblxubW9kdWxlLmV4cG9ydHMuY29kZXMgPSBjb2RlcztcbiIsIi8vIENvcHlyaWdodCBKb3llbnQsIEluYy4gYW5kIG90aGVyIE5vZGUgY29udHJpYnV0b3JzLlxuLy9cbi8vIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhXG4vLyBjb3B5IG9mIHRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlXG4vLyBcIlNvZnR3YXJlXCIpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZSB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmdcbi8vIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBtZXJnZSwgcHVibGlzaCxcbi8vIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0byBwZXJtaXRcbi8vIHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLCBzdWJqZWN0IHRvIHRoZVxuLy8gZm9sbG93aW5nIGNvbmRpdGlvbnM6XG4vL1xuLy8gVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWRcbi8vIGluIGFsbCBjb3BpZXMgb3Igc3Vic3RhbnRpYWwgcG9ydGlvbnMgb2YgdGhlIFNvZnR3YXJlLlxuLy9cbi8vIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIsIFdJVEhPVVQgV0FSUkFOVFkgT0YgQU5ZIEtJTkQsIEVYUFJFU1Ncbi8vIE9SIElNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0Zcbi8vIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EIE5PTklORlJJTkdFTUVOVC4gSU5cbi8vIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1JTIE9SIENPUFlSSUdIVCBIT0xERVJTIEJFIExJQUJMRSBGT1IgQU5ZIENMQUlNLFxuLy8gREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULCBUT1JUIE9SXG4vLyBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT04gV0lUSCBUSEUgU09GVFdBUkUgT1IgVEhFXG4vLyBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuLy8gYSBkdXBsZXggc3RyZWFtIGlzIGp1c3QgYSBzdHJlYW0gdGhhdCBpcyBib3RoIHJlYWRhYmxlIGFuZCB3cml0YWJsZS5cbi8vIFNpbmNlIEpTIGRvZXNuJ3QgaGF2ZSBtdWx0aXBsZSBwcm90b3R5cGFsIGluaGVyaXRhbmNlLCB0aGlzIGNsYXNzXG4vLyBwcm90b3R5cGFsbHkgaW5oZXJpdHMgZnJvbSBSZWFkYWJsZSwgYW5kIHRoZW4gcGFyYXNpdGljYWxseSBmcm9tXG4vLyBXcml0YWJsZS5cbid1c2Ugc3RyaWN0Jztcbi8qPHJlcGxhY2VtZW50PiovXG5cbnZhciBvYmplY3RLZXlzID0gT2JqZWN0LmtleXMgfHwgZnVuY3Rpb24gKG9iaikge1xuICB2YXIga2V5cyA9IFtdO1xuXG4gIGZvciAodmFyIGtleSBpbiBvYmopIHtcbiAgICBrZXlzLnB1c2goa2V5KTtcbiAgfVxuXG4gIHJldHVybiBrZXlzO1xufTtcbi8qPC9yZXBsYWNlbWVudD4qL1xuXG5cbm1vZHVsZS5leHBvcnRzID0gRHVwbGV4O1xuXG52YXIgUmVhZGFibGUgPSByZXF1aXJlKCcuL19zdHJlYW1fcmVhZGFibGUnKTtcblxudmFyIFdyaXRhYmxlID0gcmVxdWlyZSgnLi9fc3RyZWFtX3dyaXRhYmxlJyk7XG5cbnJlcXVpcmUoJ2luaGVyaXRzJykoRHVwbGV4LCBSZWFkYWJsZSk7XG5cbntcbiAgLy8gQWxsb3cgdGhlIGtleXMgYXJyYXkgdG8gYmUgR0MnZWQuXG4gIHZhciBrZXlzID0gb2JqZWN0S2V5cyhXcml0YWJsZS5wcm90b3R5cGUpO1xuXG4gIGZvciAodmFyIHYgPSAwOyB2IDwga2V5cy5sZW5ndGg7IHYrKykge1xuICAgIHZhciBtZXRob2QgPSBrZXlzW3ZdO1xuICAgIGlmICghRHVwbGV4LnByb3RvdHlwZVttZXRob2RdKSBEdXBsZXgucHJvdG90eXBlW21ldGhvZF0gPSBXcml0YWJsZS5wcm90b3R5cGVbbWV0aG9kXTtcbiAgfVxufVxuXG5mdW5jdGlvbiBEdXBsZXgob3B0aW9ucykge1xuICBpZiAoISh0aGlzIGluc3RhbmNlb2YgRHVwbGV4KSkgcmV0dXJuIG5ldyBEdXBsZXgob3B0aW9ucyk7XG4gIFJlYWRhYmxlLmNhbGwodGhpcywgb3B0aW9ucyk7XG4gIFdyaXRhYmxlLmNhbGwodGhpcywgb3B0aW9ucyk7XG4gIHRoaXMuYWxsb3dIYWxmT3BlbiA9IHRydWU7XG5cbiAgaWYgKG9wdGlvbnMpIHtcbiAgICBpZiAob3B0aW9ucy5yZWFkYWJsZSA9PT0gZmFsc2UpIHRoaXMucmVhZGFibGUgPSBmYWxzZTtcbiAgICBpZiAob3B0aW9ucy53cml0YWJsZSA9PT0gZmFsc2UpIHRoaXMud3JpdGFibGUgPSBmYWxzZTtcblxuICAgIGlmIChvcHRpb25zLmFsbG93SGFsZk9wZW4gPT09IGZhbHNlKSB7XG4gICAgICB0aGlzLmFsbG93SGFsZk9wZW4gPSBmYWxzZTtcbiAgICAgIHRoaXMub25jZSgnZW5kJywgb25lbmQpO1xuICAgIH1cbiAgfVxufVxuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoRHVwbGV4LnByb3RvdHlwZSwgJ3dyaXRhYmxlSGlnaFdhdGVyTWFyaycsIHtcbiAgLy8gbWFraW5nIGl0IGV4cGxpY2l0IHRoaXMgcHJvcGVydHkgaXMgbm90IGVudW1lcmFibGVcbiAgLy8gYmVjYXVzZSBvdGhlcndpc2Ugc29tZSBwcm90b3R5cGUgbWFuaXB1bGF0aW9uIGluXG4gIC8vIHVzZXJsYW5kIHdpbGwgZmFpbFxuICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgZ2V0OiBmdW5jdGlvbiBnZXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3dyaXRhYmxlU3RhdGUuaGlnaFdhdGVyTWFyaztcbiAgfVxufSk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoRHVwbGV4LnByb3RvdHlwZSwgJ3dyaXRhYmxlQnVmZmVyJywge1xuICAvLyBtYWtpbmcgaXQgZXhwbGljaXQgdGhpcyBwcm9wZXJ0eSBpcyBub3QgZW51bWVyYWJsZVxuICAvLyBiZWNhdXNlIG90aGVyd2lzZSBzb21lIHByb3RvdHlwZSBtYW5pcHVsYXRpb24gaW5cbiAgLy8gdXNlcmxhbmQgd2lsbCBmYWlsXG4gIGVudW1lcmFibGU6IGZhbHNlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICByZXR1cm4gdGhpcy5fd3JpdGFibGVTdGF0ZSAmJiB0aGlzLl93cml0YWJsZVN0YXRlLmdldEJ1ZmZlcigpO1xuICB9XG59KTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShEdXBsZXgucHJvdG90eXBlLCAnd3JpdGFibGVMZW5ndGgnLCB7XG4gIC8vIG1ha2luZyBpdCBleHBsaWNpdCB0aGlzIHByb3BlcnR5IGlzIG5vdCBlbnVtZXJhYmxlXG4gIC8vIGJlY2F1c2Ugb3RoZXJ3aXNlIHNvbWUgcHJvdG90eXBlIG1hbmlwdWxhdGlvbiBpblxuICAvLyB1c2VybGFuZCB3aWxsIGZhaWxcbiAgZW51bWVyYWJsZTogZmFsc2UsXG4gIGdldDogZnVuY3Rpb24gZ2V0KCkge1xuICAgIHJldHVybiB0aGlzLl93cml0YWJsZVN0YXRlLmxlbmd0aDtcbiAgfVxufSk7IC8vIHRoZSBuby1oYWxmLW9wZW4gZW5mb3JjZXJcblxuZnVuY3Rpb24gb25lbmQoKSB7XG4gIC8vIElmIHRoZSB3cml0YWJsZSBzaWRlIGVuZGVkLCB0aGVuIHdlJ3JlIG9rLlxuICBpZiAodGhpcy5fd3JpdGFibGVTdGF0ZS5lbmRlZCkgcmV0dXJuOyAvLyBubyBtb3JlIGRhdGEgY2FuIGJlIHdyaXR0ZW4uXG4gIC8vIEJ1dCBhbGxvdyBtb3JlIHdyaXRlcyB0byBoYXBwZW4gaW4gdGhpcyB0aWNrLlxuXG4gIHByb2Nlc3MubmV4dFRpY2sob25FbmROVCwgdGhpcyk7XG59XG5cbmZ1bmN0aW9uIG9uRW5kTlQoc2VsZikge1xuICBzZWxmLmVuZCgpO1xufVxuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoRHVwbGV4LnByb3RvdHlwZSwgJ2Rlc3Ryb3llZCcsIHtcbiAgLy8gbWFraW5nIGl0IGV4cGxpY2l0IHRoaXMgcHJvcGVydHkgaXMgbm90IGVudW1lcmFibGVcbiAgLy8gYmVjYXVzZSBvdGhlcndpc2Ugc29tZSBwcm90b3R5cGUgbWFuaXB1bGF0aW9uIGluXG4gIC8vIHVzZXJsYW5kIHdpbGwgZmFpbFxuICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgZ2V0OiBmdW5jdGlvbiBnZXQoKSB7XG4gICAgaWYgKHRoaXMuX3JlYWRhYmxlU3RhdGUgPT09IHVuZGVmaW5lZCB8fCB0aGlzLl93cml0YWJsZVN0YXRlID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcy5fcmVhZGFibGVTdGF0ZS5kZXN0cm95ZWQgJiYgdGhpcy5fd3JpdGFibGVTdGF0ZS5kZXN0cm95ZWQ7XG4gIH0sXG4gIHNldDogZnVuY3Rpb24gc2V0KHZhbHVlKSB7XG4gICAgLy8gd2UgaWdub3JlIHRoZSB2YWx1ZSBpZiB0aGUgc3RyZWFtXG4gICAgLy8gaGFzIG5vdCBiZWVuIGluaXRpYWxpemVkIHlldFxuICAgIGlmICh0aGlzLl9yZWFkYWJsZVN0YXRlID09PSB1bmRlZmluZWQgfHwgdGhpcy5fd3JpdGFibGVTdGF0ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfSAvLyBiYWNrd2FyZCBjb21wYXRpYmlsaXR5LCB0aGUgdXNlciBpcyBleHBsaWNpdGx5XG4gICAgLy8gbWFuYWdpbmcgZGVzdHJveWVkXG5cblxuICAgIHRoaXMuX3JlYWRhYmxlU3RhdGUuZGVzdHJveWVkID0gdmFsdWU7XG4gICAgdGhpcy5fd3JpdGFibGVTdGF0ZS5kZXN0cm95ZWQgPSB2YWx1ZTtcbiAgfVxufSk7IiwiLy8gQ29weXJpZ2h0IEpveWVudCwgSW5jLiBhbmQgb3RoZXIgTm9kZSBjb250cmlidXRvcnMuXG4vL1xuLy8gUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb24gb2J0YWluaW5nIGFcbi8vIGNvcHkgb2YgdGhpcyBzb2Z0d2FyZSBhbmQgYXNzb2NpYXRlZCBkb2N1bWVudGF0aW9uIGZpbGVzICh0aGVcbi8vIFwiU29mdHdhcmVcIiksIHRvIGRlYWwgaW4gdGhlIFNvZnR3YXJlIHdpdGhvdXQgcmVzdHJpY3Rpb24sIGluY2x1ZGluZ1xuLy8gd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMgdG8gdXNlLCBjb3B5LCBtb2RpZnksIG1lcmdlLCBwdWJsaXNoLFxuLy8gZGlzdHJpYnV0ZSwgc3VibGljZW5zZSwgYW5kL29yIHNlbGwgY29waWVzIG9mIHRoZSBTb2Z0d2FyZSwgYW5kIHRvIHBlcm1pdFxuLy8gcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpcyBmdXJuaXNoZWQgdG8gZG8gc28sIHN1YmplY3QgdG8gdGhlXG4vLyBmb2xsb3dpbmcgY29uZGl0aW9uczpcbi8vXG4vLyBUaGUgYWJvdmUgY29weXJpZ2h0IG5vdGljZSBhbmQgdGhpcyBwZXJtaXNzaW9uIG5vdGljZSBzaGFsbCBiZSBpbmNsdWRlZFxuLy8gaW4gYWxsIGNvcGllcyBvciBzdWJzdGFudGlhbCBwb3J0aW9ucyBvZiB0aGUgU29mdHdhcmUuXG4vL1xuLy8gVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiwgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCwgRVhQUkVTU1xuLy8gT1IgSU1QTElFRCwgSU5DTFVESU5HIEJVVCBOT1QgTElNSVRFRCBUTyBUSEUgV0FSUkFOVElFUyBPRlxuLy8gTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTlxuLy8gTk8gRVZFTlQgU0hBTEwgVEhFIEFVVEhPUlMgT1IgQ09QWVJJR0hUIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTlkgQ0xBSU0sXG4vLyBEQU1BR0VTIE9SIE9USEVSIExJQUJJTElUWSwgV0hFVEhFUiBJTiBBTiBBQ1RJT04gT0YgQ09OVFJBQ1QsIFRPUlQgT1Jcbi8vIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRSBTT0ZUV0FSRSBPUiBUSEVcbi8vIFVTRSBPUiBPVEhFUiBERUFMSU5HUyBJTiBUSEUgU09GVFdBUkUuXG4vLyBhIHBhc3N0aHJvdWdoIHN0cmVhbS5cbi8vIGJhc2ljYWxseSBqdXN0IHRoZSBtb3N0IG1pbmltYWwgc29ydCBvZiBUcmFuc2Zvcm0gc3RyZWFtLlxuLy8gRXZlcnkgd3JpdHRlbiBjaHVuayBnZXRzIG91dHB1dCBhcy1pcy5cbid1c2Ugc3RyaWN0JztcblxubW9kdWxlLmV4cG9ydHMgPSBQYXNzVGhyb3VnaDtcblxudmFyIFRyYW5zZm9ybSA9IHJlcXVpcmUoJy4vX3N0cmVhbV90cmFuc2Zvcm0nKTtcblxucmVxdWlyZSgnaW5oZXJpdHMnKShQYXNzVGhyb3VnaCwgVHJhbnNmb3JtKTtcblxuZnVuY3Rpb24gUGFzc1Rocm91Z2gob3B0aW9ucykge1xuICBpZiAoISh0aGlzIGluc3RhbmNlb2YgUGFzc1Rocm91Z2gpKSByZXR1cm4gbmV3IFBhc3NUaHJvdWdoKG9wdGlvbnMpO1xuICBUcmFuc2Zvcm0uY2FsbCh0aGlzLCBvcHRpb25zKTtcbn1cblxuUGFzc1Rocm91Z2gucHJvdG90eXBlLl90cmFuc2Zvcm0gPSBmdW5jdGlvbiAoY2h1bmssIGVuY29kaW5nLCBjYikge1xuICBjYihudWxsLCBjaHVuayk7XG59OyIsIi8vIENvcHlyaWdodCBKb3llbnQsIEluYy4gYW5kIG90aGVyIE5vZGUgY29udHJpYnV0b3JzLlxuLy9cbi8vIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhXG4vLyBjb3B5IG9mIHRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlXG4vLyBcIlNvZnR3YXJlXCIpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZSB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmdcbi8vIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBtZXJnZSwgcHVibGlzaCxcbi8vIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0byBwZXJtaXRcbi8vIHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLCBzdWJqZWN0IHRvIHRoZVxuLy8gZm9sbG93aW5nIGNvbmRpdGlvbnM6XG4vL1xuLy8gVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWRcbi8vIGluIGFsbCBjb3BpZXMgb3Igc3Vic3RhbnRpYWwgcG9ydGlvbnMgb2YgdGhlIFNvZnR3YXJlLlxuLy9cbi8vIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIsIFdJVEhPVVQgV0FSUkFOVFkgT0YgQU5ZIEtJTkQsIEVYUFJFU1Ncbi8vIE9SIElNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0Zcbi8vIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EIE5PTklORlJJTkdFTUVOVC4gSU5cbi8vIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1JTIE9SIENPUFlSSUdIVCBIT0xERVJTIEJFIExJQUJMRSBGT1IgQU5ZIENMQUlNLFxuLy8gREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULCBUT1JUIE9SXG4vLyBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT04gV0lUSCBUSEUgU09GVFdBUkUgT1IgVEhFXG4vLyBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuJ3VzZSBzdHJpY3QnO1xuXG5tb2R1bGUuZXhwb3J0cyA9IFJlYWRhYmxlO1xuLyo8cmVwbGFjZW1lbnQ+Ki9cblxudmFyIER1cGxleDtcbi8qPC9yZXBsYWNlbWVudD4qL1xuXG5SZWFkYWJsZS5SZWFkYWJsZVN0YXRlID0gUmVhZGFibGVTdGF0ZTtcbi8qPHJlcGxhY2VtZW50PiovXG5cbnZhciBFRSA9IHJlcXVpcmUoJ2V2ZW50cycpLkV2ZW50RW1pdHRlcjtcblxudmFyIEVFbGlzdGVuZXJDb3VudCA9IGZ1bmN0aW9uIEVFbGlzdGVuZXJDb3VudChlbWl0dGVyLCB0eXBlKSB7XG4gIHJldHVybiBlbWl0dGVyLmxpc3RlbmVycyh0eXBlKS5sZW5ndGg7XG59O1xuLyo8L3JlcGxhY2VtZW50PiovXG5cbi8qPHJlcGxhY2VtZW50PiovXG5cblxudmFyIFN0cmVhbSA9IHJlcXVpcmUoJy4vaW50ZXJuYWwvc3RyZWFtcy9zdHJlYW0nKTtcbi8qPC9yZXBsYWNlbWVudD4qL1xuXG5cbnZhciBCdWZmZXIgPSByZXF1aXJlKCdidWZmZXInKS5CdWZmZXI7XG5cbnZhciBPdXJVaW50OEFycmF5ID0gZ2xvYmFsLlVpbnQ4QXJyYXkgfHwgZnVuY3Rpb24gKCkge307XG5cbmZ1bmN0aW9uIF91aW50OEFycmF5VG9CdWZmZXIoY2h1bmspIHtcbiAgcmV0dXJuIEJ1ZmZlci5mcm9tKGNodW5rKTtcbn1cblxuZnVuY3Rpb24gX2lzVWludDhBcnJheShvYmopIHtcbiAgcmV0dXJuIEJ1ZmZlci5pc0J1ZmZlcihvYmopIHx8IG9iaiBpbnN0YW5jZW9mIE91clVpbnQ4QXJyYXk7XG59XG4vKjxyZXBsYWNlbWVudD4qL1xuXG5cbnZhciBkZWJ1Z1V0aWwgPSByZXF1aXJlKCd1dGlsJyk7XG5cbnZhciBkZWJ1ZztcblxuaWYgKGRlYnVnVXRpbCAmJiBkZWJ1Z1V0aWwuZGVidWdsb2cpIHtcbiAgZGVidWcgPSBkZWJ1Z1V0aWwuZGVidWdsb2coJ3N0cmVhbScpO1xufSBlbHNlIHtcbiAgZGVidWcgPSBmdW5jdGlvbiBkZWJ1ZygpIHt9O1xufVxuLyo8L3JlcGxhY2VtZW50PiovXG5cblxudmFyIEJ1ZmZlckxpc3QgPSByZXF1aXJlKCcuL2ludGVybmFsL3N0cmVhbXMvYnVmZmVyX2xpc3QnKTtcblxudmFyIGRlc3Ryb3lJbXBsID0gcmVxdWlyZSgnLi9pbnRlcm5hbC9zdHJlYW1zL2Rlc3Ryb3knKTtcblxudmFyIF9yZXF1aXJlID0gcmVxdWlyZSgnLi9pbnRlcm5hbC9zdHJlYW1zL3N0YXRlJyksXG4gICAgZ2V0SGlnaFdhdGVyTWFyayA9IF9yZXF1aXJlLmdldEhpZ2hXYXRlck1hcms7XG5cbnZhciBfcmVxdWlyZSRjb2RlcyA9IHJlcXVpcmUoJy4uL2Vycm9ycycpLmNvZGVzLFxuICAgIEVSUl9JTlZBTElEX0FSR19UWVBFID0gX3JlcXVpcmUkY29kZXMuRVJSX0lOVkFMSURfQVJHX1RZUEUsXG4gICAgRVJSX1NUUkVBTV9QVVNIX0FGVEVSX0VPRiA9IF9yZXF1aXJlJGNvZGVzLkVSUl9TVFJFQU1fUFVTSF9BRlRFUl9FT0YsXG4gICAgRVJSX01FVEhPRF9OT1RfSU1QTEVNRU5URUQgPSBfcmVxdWlyZSRjb2Rlcy5FUlJfTUVUSE9EX05PVF9JTVBMRU1FTlRFRCxcbiAgICBFUlJfU1RSRUFNX1VOU0hJRlRfQUZURVJfRU5EX0VWRU5UID0gX3JlcXVpcmUkY29kZXMuRVJSX1NUUkVBTV9VTlNISUZUX0FGVEVSX0VORF9FVkVOVDsgLy8gTGF6eSBsb2FkZWQgdG8gaW1wcm92ZSB0aGUgc3RhcnR1cCBwZXJmb3JtYW5jZS5cblxuXG52YXIgU3RyaW5nRGVjb2RlcjtcbnZhciBjcmVhdGVSZWFkYWJsZVN0cmVhbUFzeW5jSXRlcmF0b3I7XG52YXIgZnJvbTtcblxucmVxdWlyZSgnaW5oZXJpdHMnKShSZWFkYWJsZSwgU3RyZWFtKTtcblxudmFyIGVycm9yT3JEZXN0cm95ID0gZGVzdHJveUltcGwuZXJyb3JPckRlc3Ryb3k7XG52YXIga1Byb3h5RXZlbnRzID0gWydlcnJvcicsICdjbG9zZScsICdkZXN0cm95JywgJ3BhdXNlJywgJ3Jlc3VtZSddO1xuXG5mdW5jdGlvbiBwcmVwZW5kTGlzdGVuZXIoZW1pdHRlciwgZXZlbnQsIGZuKSB7XG4gIC8vIFNhZGx5IHRoaXMgaXMgbm90IGNhY2hlYWJsZSBhcyBzb21lIGxpYnJhcmllcyBidW5kbGUgdGhlaXIgb3duXG4gIC8vIGV2ZW50IGVtaXR0ZXIgaW1wbGVtZW50YXRpb24gd2l0aCB0aGVtLlxuICBpZiAodHlwZW9mIGVtaXR0ZXIucHJlcGVuZExpc3RlbmVyID09PSAnZnVuY3Rpb24nKSByZXR1cm4gZW1pdHRlci5wcmVwZW5kTGlzdGVuZXIoZXZlbnQsIGZuKTsgLy8gVGhpcyBpcyBhIGhhY2sgdG8gbWFrZSBzdXJlIHRoYXQgb3VyIGVycm9yIGhhbmRsZXIgaXMgYXR0YWNoZWQgYmVmb3JlIGFueVxuICAvLyB1c2VybGFuZCBvbmVzLiAgTkVWRVIgRE8gVEhJUy4gVGhpcyBpcyBoZXJlIG9ubHkgYmVjYXVzZSB0aGlzIGNvZGUgbmVlZHNcbiAgLy8gdG8gY29udGludWUgdG8gd29yayB3aXRoIG9sZGVyIHZlcnNpb25zIG9mIE5vZGUuanMgdGhhdCBkbyBub3QgaW5jbHVkZVxuICAvLyB0aGUgcHJlcGVuZExpc3RlbmVyKCkgbWV0aG9kLiBUaGUgZ29hbCBpcyB0byBldmVudHVhbGx5IHJlbW92ZSB0aGlzIGhhY2suXG5cbiAgaWYgKCFlbWl0dGVyLl9ldmVudHMgfHwgIWVtaXR0ZXIuX2V2ZW50c1tldmVudF0pIGVtaXR0ZXIub24oZXZlbnQsIGZuKTtlbHNlIGlmIChBcnJheS5pc0FycmF5KGVtaXR0ZXIuX2V2ZW50c1tldmVudF0pKSBlbWl0dGVyLl9ldmVudHNbZXZlbnRdLnVuc2hpZnQoZm4pO2Vsc2UgZW1pdHRlci5fZXZlbnRzW2V2ZW50XSA9IFtmbiwgZW1pdHRlci5fZXZlbnRzW2V2ZW50XV07XG59XG5cbmZ1bmN0aW9uIFJlYWRhYmxlU3RhdGUob3B0aW9ucywgc3RyZWFtLCBpc0R1cGxleCkge1xuICBEdXBsZXggPSBEdXBsZXggfHwgcmVxdWlyZSgnLi9fc3RyZWFtX2R1cGxleCcpO1xuICBvcHRpb25zID0gb3B0aW9ucyB8fCB7fTsgLy8gRHVwbGV4IHN0cmVhbXMgYXJlIGJvdGggcmVhZGFibGUgYW5kIHdyaXRhYmxlLCBidXQgc2hhcmVcbiAgLy8gdGhlIHNhbWUgb3B0aW9ucyBvYmplY3QuXG4gIC8vIEhvd2V2ZXIsIHNvbWUgY2FzZXMgcmVxdWlyZSBzZXR0aW5nIG9wdGlvbnMgdG8gZGlmZmVyZW50XG4gIC8vIHZhbHVlcyBmb3IgdGhlIHJlYWRhYmxlIGFuZCB0aGUgd3JpdGFibGUgc2lkZXMgb2YgdGhlIGR1cGxleCBzdHJlYW0uXG4gIC8vIFRoZXNlIG9wdGlvbnMgY2FuIGJlIHByb3ZpZGVkIHNlcGFyYXRlbHkgYXMgcmVhZGFibGVYWFggYW5kIHdyaXRhYmxlWFhYLlxuXG4gIGlmICh0eXBlb2YgaXNEdXBsZXggIT09ICdib29sZWFuJykgaXNEdXBsZXggPSBzdHJlYW0gaW5zdGFuY2VvZiBEdXBsZXg7IC8vIG9iamVjdCBzdHJlYW0gZmxhZy4gVXNlZCB0byBtYWtlIHJlYWQobikgaWdub3JlIG4gYW5kIHRvXG4gIC8vIG1ha2UgYWxsIHRoZSBidWZmZXIgbWVyZ2luZyBhbmQgbGVuZ3RoIGNoZWNrcyBnbyBhd2F5XG5cbiAgdGhpcy5vYmplY3RNb2RlID0gISFvcHRpb25zLm9iamVjdE1vZGU7XG4gIGlmIChpc0R1cGxleCkgdGhpcy5vYmplY3RNb2RlID0gdGhpcy5vYmplY3RNb2RlIHx8ICEhb3B0aW9ucy5yZWFkYWJsZU9iamVjdE1vZGU7IC8vIHRoZSBwb2ludCBhdCB3aGljaCBpdCBzdG9wcyBjYWxsaW5nIF9yZWFkKCkgdG8gZmlsbCB0aGUgYnVmZmVyXG4gIC8vIE5vdGU6IDAgaXMgYSB2YWxpZCB2YWx1ZSwgbWVhbnMgXCJkb24ndCBjYWxsIF9yZWFkIHByZWVtcHRpdmVseSBldmVyXCJcblxuICB0aGlzLmhpZ2hXYXRlck1hcmsgPSBnZXRIaWdoV2F0ZXJNYXJrKHRoaXMsIG9wdGlvbnMsICdyZWFkYWJsZUhpZ2hXYXRlck1hcmsnLCBpc0R1cGxleCk7IC8vIEEgbGlua2VkIGxpc3QgaXMgdXNlZCB0byBzdG9yZSBkYXRhIGNodW5rcyBpbnN0ZWFkIG9mIGFuIGFycmF5IGJlY2F1c2UgdGhlXG4gIC8vIGxpbmtlZCBsaXN0IGNhbiByZW1vdmUgZWxlbWVudHMgZnJvbSB0aGUgYmVnaW5uaW5nIGZhc3RlciB0aGFuXG4gIC8vIGFycmF5LnNoaWZ0KClcblxuICB0aGlzLmJ1ZmZlciA9IG5ldyBCdWZmZXJMaXN0KCk7XG4gIHRoaXMubGVuZ3RoID0gMDtcbiAgdGhpcy5waXBlcyA9IG51bGw7XG4gIHRoaXMucGlwZXNDb3VudCA9IDA7XG4gIHRoaXMuZmxvd2luZyA9IG51bGw7XG4gIHRoaXMuZW5kZWQgPSBmYWxzZTtcbiAgdGhpcy5lbmRFbWl0dGVkID0gZmFsc2U7XG4gIHRoaXMucmVhZGluZyA9IGZhbHNlOyAvLyBhIGZsYWcgdG8gYmUgYWJsZSB0byB0ZWxsIGlmIHRoZSBldmVudCAncmVhZGFibGUnLydkYXRhJyBpcyBlbWl0dGVkXG4gIC8vIGltbWVkaWF0ZWx5LCBvciBvbiBhIGxhdGVyIHRpY2suICBXZSBzZXQgdGhpcyB0byB0cnVlIGF0IGZpcnN0LCBiZWNhdXNlXG4gIC8vIGFueSBhY3Rpb25zIHRoYXQgc2hvdWxkbid0IGhhcHBlbiB1bnRpbCBcImxhdGVyXCIgc2hvdWxkIGdlbmVyYWxseSBhbHNvXG4gIC8vIG5vdCBoYXBwZW4gYmVmb3JlIHRoZSBmaXJzdCByZWFkIGNhbGwuXG5cbiAgdGhpcy5zeW5jID0gdHJ1ZTsgLy8gd2hlbmV2ZXIgd2UgcmV0dXJuIG51bGwsIHRoZW4gd2Ugc2V0IGEgZmxhZyB0byBzYXlcbiAgLy8gdGhhdCB3ZSdyZSBhd2FpdGluZyBhICdyZWFkYWJsZScgZXZlbnQgZW1pc3Npb24uXG5cbiAgdGhpcy5uZWVkUmVhZGFibGUgPSBmYWxzZTtcbiAgdGhpcy5lbWl0dGVkUmVhZGFibGUgPSBmYWxzZTtcbiAgdGhpcy5yZWFkYWJsZUxpc3RlbmluZyA9IGZhbHNlO1xuICB0aGlzLnJlc3VtZVNjaGVkdWxlZCA9IGZhbHNlO1xuICB0aGlzLnBhdXNlZCA9IHRydWU7IC8vIFNob3VsZCBjbG9zZSBiZSBlbWl0dGVkIG9uIGRlc3Ryb3kuIERlZmF1bHRzIHRvIHRydWUuXG5cbiAgdGhpcy5lbWl0Q2xvc2UgPSBvcHRpb25zLmVtaXRDbG9zZSAhPT0gZmFsc2U7IC8vIFNob3VsZCAuZGVzdHJveSgpIGJlIGNhbGxlZCBhZnRlciAnZW5kJyAoYW5kIHBvdGVudGlhbGx5ICdmaW5pc2gnKVxuXG4gIHRoaXMuYXV0b0Rlc3Ryb3kgPSAhIW9wdGlvbnMuYXV0b0Rlc3Ryb3k7IC8vIGhhcyBpdCBiZWVuIGRlc3Ryb3llZFxuXG4gIHRoaXMuZGVzdHJveWVkID0gZmFsc2U7IC8vIENyeXB0byBpcyBraW5kIG9mIG9sZCBhbmQgY3J1c3R5LiAgSGlzdG9yaWNhbGx5LCBpdHMgZGVmYXVsdCBzdHJpbmdcbiAgLy8gZW5jb2RpbmcgaXMgJ2JpbmFyeScgc28gd2UgaGF2ZSB0byBtYWtlIHRoaXMgY29uZmlndXJhYmxlLlxuICAvLyBFdmVyeXRoaW5nIGVsc2UgaW4gdGhlIHVuaXZlcnNlIHVzZXMgJ3V0ZjgnLCB0aG91Z2guXG5cbiAgdGhpcy5kZWZhdWx0RW5jb2RpbmcgPSBvcHRpb25zLmRlZmF1bHRFbmNvZGluZyB8fCAndXRmOCc7IC8vIHRoZSBudW1iZXIgb2Ygd3JpdGVycyB0aGF0IGFyZSBhd2FpdGluZyBhIGRyYWluIGV2ZW50IGluIC5waXBlKClzXG5cbiAgdGhpcy5hd2FpdERyYWluID0gMDsgLy8gaWYgdHJ1ZSwgYSBtYXliZVJlYWRNb3JlIGhhcyBiZWVuIHNjaGVkdWxlZFxuXG4gIHRoaXMucmVhZGluZ01vcmUgPSBmYWxzZTtcbiAgdGhpcy5kZWNvZGVyID0gbnVsbDtcbiAgdGhpcy5lbmNvZGluZyA9IG51bGw7XG5cbiAgaWYgKG9wdGlvbnMuZW5jb2RpbmcpIHtcbiAgICBpZiAoIVN0cmluZ0RlY29kZXIpIFN0cmluZ0RlY29kZXIgPSByZXF1aXJlKCdzdHJpbmdfZGVjb2Rlci8nKS5TdHJpbmdEZWNvZGVyO1xuICAgIHRoaXMuZGVjb2RlciA9IG5ldyBTdHJpbmdEZWNvZGVyKG9wdGlvbnMuZW5jb2RpbmcpO1xuICAgIHRoaXMuZW5jb2RpbmcgPSBvcHRpb25zLmVuY29kaW5nO1xuICB9XG59XG5cbmZ1bmN0aW9uIFJlYWRhYmxlKG9wdGlvbnMpIHtcbiAgRHVwbGV4ID0gRHVwbGV4IHx8IHJlcXVpcmUoJy4vX3N0cmVhbV9kdXBsZXgnKTtcbiAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIFJlYWRhYmxlKSkgcmV0dXJuIG5ldyBSZWFkYWJsZShvcHRpb25zKTsgLy8gQ2hlY2tpbmcgZm9yIGEgU3RyZWFtLkR1cGxleCBpbnN0YW5jZSBpcyBmYXN0ZXIgaGVyZSBpbnN0ZWFkIG9mIGluc2lkZVxuICAvLyB0aGUgUmVhZGFibGVTdGF0ZSBjb25zdHJ1Y3RvciwgYXQgbGVhc3Qgd2l0aCBWOCA2LjVcblxuICB2YXIgaXNEdXBsZXggPSB0aGlzIGluc3RhbmNlb2YgRHVwbGV4O1xuICB0aGlzLl9yZWFkYWJsZVN0YXRlID0gbmV3IFJlYWRhYmxlU3RhdGUob3B0aW9ucywgdGhpcywgaXNEdXBsZXgpOyAvLyBsZWdhY3lcblxuICB0aGlzLnJlYWRhYmxlID0gdHJ1ZTtcblxuICBpZiAob3B0aW9ucykge1xuICAgIGlmICh0eXBlb2Ygb3B0aW9ucy5yZWFkID09PSAnZnVuY3Rpb24nKSB0aGlzLl9yZWFkID0gb3B0aW9ucy5yZWFkO1xuICAgIGlmICh0eXBlb2Ygb3B0aW9ucy5kZXN0cm95ID09PSAnZnVuY3Rpb24nKSB0aGlzLl9kZXN0cm95ID0gb3B0aW9ucy5kZXN0cm95O1xuICB9XG5cbiAgU3RyZWFtLmNhbGwodGhpcyk7XG59XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShSZWFkYWJsZS5wcm90b3R5cGUsICdkZXN0cm95ZWQnLCB7XG4gIC8vIG1ha2luZyBpdCBleHBsaWNpdCB0aGlzIHByb3BlcnR5IGlzIG5vdCBlbnVtZXJhYmxlXG4gIC8vIGJlY2F1c2Ugb3RoZXJ3aXNlIHNvbWUgcHJvdG90eXBlIG1hbmlwdWxhdGlvbiBpblxuICAvLyB1c2VybGFuZCB3aWxsIGZhaWxcbiAgZW51bWVyYWJsZTogZmFsc2UsXG4gIGdldDogZnVuY3Rpb24gZ2V0KCkge1xuICAgIGlmICh0aGlzLl9yZWFkYWJsZVN0YXRlID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcy5fcmVhZGFibGVTdGF0ZS5kZXN0cm95ZWQ7XG4gIH0sXG4gIHNldDogZnVuY3Rpb24gc2V0KHZhbHVlKSB7XG4gICAgLy8gd2UgaWdub3JlIHRoZSB2YWx1ZSBpZiB0aGUgc3RyZWFtXG4gICAgLy8gaGFzIG5vdCBiZWVuIGluaXRpYWxpemVkIHlldFxuICAgIGlmICghdGhpcy5fcmVhZGFibGVTdGF0ZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH0gLy8gYmFja3dhcmQgY29tcGF0aWJpbGl0eSwgdGhlIHVzZXIgaXMgZXhwbGljaXRseVxuICAgIC8vIG1hbmFnaW5nIGRlc3Ryb3llZFxuXG5cbiAgICB0aGlzLl9yZWFkYWJsZVN0YXRlLmRlc3Ryb3llZCA9IHZhbHVlO1xuICB9XG59KTtcblJlYWRhYmxlLnByb3RvdHlwZS5kZXN0cm95ID0gZGVzdHJveUltcGwuZGVzdHJveTtcblJlYWRhYmxlLnByb3RvdHlwZS5fdW5kZXN0cm95ID0gZGVzdHJveUltcGwudW5kZXN0cm95O1xuXG5SZWFkYWJsZS5wcm90b3R5cGUuX2Rlc3Ryb3kgPSBmdW5jdGlvbiAoZXJyLCBjYikge1xuICBjYihlcnIpO1xufTsgLy8gTWFudWFsbHkgc2hvdmUgc29tZXRoaW5nIGludG8gdGhlIHJlYWQoKSBidWZmZXIuXG4vLyBUaGlzIHJldHVybnMgdHJ1ZSBpZiB0aGUgaGlnaFdhdGVyTWFyayBoYXMgbm90IGJlZW4gaGl0IHlldCxcbi8vIHNpbWlsYXIgdG8gaG93IFdyaXRhYmxlLndyaXRlKCkgcmV0dXJucyB0cnVlIGlmIHlvdSBzaG91bGRcbi8vIHdyaXRlKCkgc29tZSBtb3JlLlxuXG5cblJlYWRhYmxlLnByb3RvdHlwZS5wdXNoID0gZnVuY3Rpb24gKGNodW5rLCBlbmNvZGluZykge1xuICB2YXIgc3RhdGUgPSB0aGlzLl9yZWFkYWJsZVN0YXRlO1xuICB2YXIgc2tpcENodW5rQ2hlY2s7XG5cbiAgaWYgKCFzdGF0ZS5vYmplY3RNb2RlKSB7XG4gICAgaWYgKHR5cGVvZiBjaHVuayA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGVuY29kaW5nID0gZW5jb2RpbmcgfHwgc3RhdGUuZGVmYXVsdEVuY29kaW5nO1xuXG4gICAgICBpZiAoZW5jb2RpbmcgIT09IHN0YXRlLmVuY29kaW5nKSB7XG4gICAgICAgIGNodW5rID0gQnVmZmVyLmZyb20oY2h1bmssIGVuY29kaW5nKTtcbiAgICAgICAgZW5jb2RpbmcgPSAnJztcbiAgICAgIH1cblxuICAgICAgc2tpcENodW5rQ2hlY2sgPSB0cnVlO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBza2lwQ2h1bmtDaGVjayA9IHRydWU7XG4gIH1cblxuICByZXR1cm4gcmVhZGFibGVBZGRDaHVuayh0aGlzLCBjaHVuaywgZW5jb2RpbmcsIGZhbHNlLCBza2lwQ2h1bmtDaGVjayk7XG59OyAvLyBVbnNoaWZ0IHNob3VsZCAqYWx3YXlzKiBiZSBzb21ldGhpbmcgZGlyZWN0bHkgb3V0IG9mIHJlYWQoKVxuXG5cblJlYWRhYmxlLnByb3RvdHlwZS51bnNoaWZ0ID0gZnVuY3Rpb24gKGNodW5rKSB7XG4gIHJldHVybiByZWFkYWJsZUFkZENodW5rKHRoaXMsIGNodW5rLCBudWxsLCB0cnVlLCBmYWxzZSk7XG59O1xuXG5mdW5jdGlvbiByZWFkYWJsZUFkZENodW5rKHN0cmVhbSwgY2h1bmssIGVuY29kaW5nLCBhZGRUb0Zyb250LCBza2lwQ2h1bmtDaGVjaykge1xuICBkZWJ1ZygncmVhZGFibGVBZGRDaHVuaycsIGNodW5rKTtcbiAgdmFyIHN0YXRlID0gc3RyZWFtLl9yZWFkYWJsZVN0YXRlO1xuXG4gIGlmIChjaHVuayA9PT0gbnVsbCkge1xuICAgIHN0YXRlLnJlYWRpbmcgPSBmYWxzZTtcbiAgICBvbkVvZkNodW5rKHN0cmVhbSwgc3RhdGUpO1xuICB9IGVsc2Uge1xuICAgIHZhciBlcjtcbiAgICBpZiAoIXNraXBDaHVua0NoZWNrKSBlciA9IGNodW5rSW52YWxpZChzdGF0ZSwgY2h1bmspO1xuXG4gICAgaWYgKGVyKSB7XG4gICAgICBlcnJvck9yRGVzdHJveShzdHJlYW0sIGVyKTtcbiAgICB9IGVsc2UgaWYgKHN0YXRlLm9iamVjdE1vZGUgfHwgY2h1bmsgJiYgY2h1bmsubGVuZ3RoID4gMCkge1xuICAgICAgaWYgKHR5cGVvZiBjaHVuayAhPT0gJ3N0cmluZycgJiYgIXN0YXRlLm9iamVjdE1vZGUgJiYgT2JqZWN0LmdldFByb3RvdHlwZU9mKGNodW5rKSAhPT0gQnVmZmVyLnByb3RvdHlwZSkge1xuICAgICAgICBjaHVuayA9IF91aW50OEFycmF5VG9CdWZmZXIoY2h1bmspO1xuICAgICAgfVxuXG4gICAgICBpZiAoYWRkVG9Gcm9udCkge1xuICAgICAgICBpZiAoc3RhdGUuZW5kRW1pdHRlZCkgZXJyb3JPckRlc3Ryb3koc3RyZWFtLCBuZXcgRVJSX1NUUkVBTV9VTlNISUZUX0FGVEVSX0VORF9FVkVOVCgpKTtlbHNlIGFkZENodW5rKHN0cmVhbSwgc3RhdGUsIGNodW5rLCB0cnVlKTtcbiAgICAgIH0gZWxzZSBpZiAoc3RhdGUuZW5kZWQpIHtcbiAgICAgICAgZXJyb3JPckRlc3Ryb3koc3RyZWFtLCBuZXcgRVJSX1NUUkVBTV9QVVNIX0FGVEVSX0VPRigpKTtcbiAgICAgIH0gZWxzZSBpZiAoc3RhdGUuZGVzdHJveWVkKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHN0YXRlLnJlYWRpbmcgPSBmYWxzZTtcblxuICAgICAgICBpZiAoc3RhdGUuZGVjb2RlciAmJiAhZW5jb2RpbmcpIHtcbiAgICAgICAgICBjaHVuayA9IHN0YXRlLmRlY29kZXIud3JpdGUoY2h1bmspO1xuICAgICAgICAgIGlmIChzdGF0ZS5vYmplY3RNb2RlIHx8IGNodW5rLmxlbmd0aCAhPT0gMCkgYWRkQ2h1bmsoc3RyZWFtLCBzdGF0ZSwgY2h1bmssIGZhbHNlKTtlbHNlIG1heWJlUmVhZE1vcmUoc3RyZWFtLCBzdGF0ZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgYWRkQ2h1bmsoc3RyZWFtLCBzdGF0ZSwgY2h1bmssIGZhbHNlKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoIWFkZFRvRnJvbnQpIHtcbiAgICAgIHN0YXRlLnJlYWRpbmcgPSBmYWxzZTtcbiAgICAgIG1heWJlUmVhZE1vcmUoc3RyZWFtLCBzdGF0ZSk7XG4gICAgfVxuICB9IC8vIFdlIGNhbiBwdXNoIG1vcmUgZGF0YSBpZiB3ZSBhcmUgYmVsb3cgdGhlIGhpZ2hXYXRlck1hcmsuXG4gIC8vIEFsc28sIGlmIHdlIGhhdmUgbm8gZGF0YSB5ZXQsIHdlIGNhbiBzdGFuZCBzb21lIG1vcmUgYnl0ZXMuXG4gIC8vIFRoaXMgaXMgdG8gd29yayBhcm91bmQgY2FzZXMgd2hlcmUgaHdtPTAsIHN1Y2ggYXMgdGhlIHJlcGwuXG5cblxuICByZXR1cm4gIXN0YXRlLmVuZGVkICYmIChzdGF0ZS5sZW5ndGggPCBzdGF0ZS5oaWdoV2F0ZXJNYXJrIHx8IHN0YXRlLmxlbmd0aCA9PT0gMCk7XG59XG5cbmZ1bmN0aW9uIGFkZENodW5rKHN0cmVhbSwgc3RhdGUsIGNodW5rLCBhZGRUb0Zyb250KSB7XG4gIGlmIChzdGF0ZS5mbG93aW5nICYmIHN0YXRlLmxlbmd0aCA9PT0gMCAmJiAhc3RhdGUuc3luYykge1xuICAgIHN0YXRlLmF3YWl0RHJhaW4gPSAwO1xuICAgIHN0cmVhbS5lbWl0KCdkYXRhJywgY2h1bmspO1xuICB9IGVsc2Uge1xuICAgIC8vIHVwZGF0ZSB0aGUgYnVmZmVyIGluZm8uXG4gICAgc3RhdGUubGVuZ3RoICs9IHN0YXRlLm9iamVjdE1vZGUgPyAxIDogY2h1bmsubGVuZ3RoO1xuICAgIGlmIChhZGRUb0Zyb250KSBzdGF0ZS5idWZmZXIudW5zaGlmdChjaHVuayk7ZWxzZSBzdGF0ZS5idWZmZXIucHVzaChjaHVuayk7XG4gICAgaWYgKHN0YXRlLm5lZWRSZWFkYWJsZSkgZW1pdFJlYWRhYmxlKHN0cmVhbSk7XG4gIH1cblxuICBtYXliZVJlYWRNb3JlKHN0cmVhbSwgc3RhdGUpO1xufVxuXG5mdW5jdGlvbiBjaHVua0ludmFsaWQoc3RhdGUsIGNodW5rKSB7XG4gIHZhciBlcjtcblxuICBpZiAoIV9pc1VpbnQ4QXJyYXkoY2h1bmspICYmIHR5cGVvZiBjaHVuayAhPT0gJ3N0cmluZycgJiYgY2h1bmsgIT09IHVuZGVmaW5lZCAmJiAhc3RhdGUub2JqZWN0TW9kZSkge1xuICAgIGVyID0gbmV3IEVSUl9JTlZBTElEX0FSR19UWVBFKCdjaHVuaycsIFsnc3RyaW5nJywgJ0J1ZmZlcicsICdVaW50OEFycmF5J10sIGNodW5rKTtcbiAgfVxuXG4gIHJldHVybiBlcjtcbn1cblxuUmVhZGFibGUucHJvdG90eXBlLmlzUGF1c2VkID0gZnVuY3Rpb24gKCkge1xuICByZXR1cm4gdGhpcy5fcmVhZGFibGVTdGF0ZS5mbG93aW5nID09PSBmYWxzZTtcbn07IC8vIGJhY2t3YXJkcyBjb21wYXRpYmlsaXR5LlxuXG5cblJlYWRhYmxlLnByb3RvdHlwZS5zZXRFbmNvZGluZyA9IGZ1bmN0aW9uIChlbmMpIHtcbiAgaWYgKCFTdHJpbmdEZWNvZGVyKSBTdHJpbmdEZWNvZGVyID0gcmVxdWlyZSgnc3RyaW5nX2RlY29kZXIvJykuU3RyaW5nRGVjb2RlcjtcbiAgdmFyIGRlY29kZXIgPSBuZXcgU3RyaW5nRGVjb2RlcihlbmMpO1xuICB0aGlzLl9yZWFkYWJsZVN0YXRlLmRlY29kZXIgPSBkZWNvZGVyOyAvLyBJZiBzZXRFbmNvZGluZyhudWxsKSwgZGVjb2Rlci5lbmNvZGluZyBlcXVhbHMgdXRmOFxuXG4gIHRoaXMuX3JlYWRhYmxlU3RhdGUuZW5jb2RpbmcgPSB0aGlzLl9yZWFkYWJsZVN0YXRlLmRlY29kZXIuZW5jb2Rpbmc7IC8vIEl0ZXJhdGUgb3ZlciBjdXJyZW50IGJ1ZmZlciB0byBjb252ZXJ0IGFscmVhZHkgc3RvcmVkIEJ1ZmZlcnM6XG5cbiAgdmFyIHAgPSB0aGlzLl9yZWFkYWJsZVN0YXRlLmJ1ZmZlci5oZWFkO1xuICB2YXIgY29udGVudCA9ICcnO1xuXG4gIHdoaWxlIChwICE9PSBudWxsKSB7XG4gICAgY29udGVudCArPSBkZWNvZGVyLndyaXRlKHAuZGF0YSk7XG4gICAgcCA9IHAubmV4dDtcbiAgfVxuXG4gIHRoaXMuX3JlYWRhYmxlU3RhdGUuYnVmZmVyLmNsZWFyKCk7XG5cbiAgaWYgKGNvbnRlbnQgIT09ICcnKSB0aGlzLl9yZWFkYWJsZVN0YXRlLmJ1ZmZlci5wdXNoKGNvbnRlbnQpO1xuICB0aGlzLl9yZWFkYWJsZVN0YXRlLmxlbmd0aCA9IGNvbnRlbnQubGVuZ3RoO1xuICByZXR1cm4gdGhpcztcbn07IC8vIERvbid0IHJhaXNlIHRoZSBod20gPiAxR0JcblxuXG52YXIgTUFYX0hXTSA9IDB4NDAwMDAwMDA7XG5cbmZ1bmN0aW9uIGNvbXB1dGVOZXdIaWdoV2F0ZXJNYXJrKG4pIHtcbiAgaWYgKG4gPj0gTUFYX0hXTSkge1xuICAgIC8vIFRPRE8ocm9uYWcpOiBUaHJvdyBFUlJfVkFMVUVfT1VUX09GX1JBTkdFLlxuICAgIG4gPSBNQVhfSFdNO1xuICB9IGVsc2Uge1xuICAgIC8vIEdldCB0aGUgbmV4dCBoaWdoZXN0IHBvd2VyIG9mIDIgdG8gcHJldmVudCBpbmNyZWFzaW5nIGh3bSBleGNlc3NpdmVseSBpblxuICAgIC8vIHRpbnkgYW1vdW50c1xuICAgIG4tLTtcbiAgICBuIHw9IG4gPj4+IDE7XG4gICAgbiB8PSBuID4+PiAyO1xuICAgIG4gfD0gbiA+Pj4gNDtcbiAgICBuIHw9IG4gPj4+IDg7XG4gICAgbiB8PSBuID4+PiAxNjtcbiAgICBuKys7XG4gIH1cblxuICByZXR1cm4gbjtcbn0gLy8gVGhpcyBmdW5jdGlvbiBpcyBkZXNpZ25lZCB0byBiZSBpbmxpbmFibGUsIHNvIHBsZWFzZSB0YWtlIGNhcmUgd2hlbiBtYWtpbmdcbi8vIGNoYW5nZXMgdG8gdGhlIGZ1bmN0aW9uIGJvZHkuXG5cblxuZnVuY3Rpb24gaG93TXVjaFRvUmVhZChuLCBzdGF0ZSkge1xuICBpZiAobiA8PSAwIHx8IHN0YXRlLmxlbmd0aCA9PT0gMCAmJiBzdGF0ZS5lbmRlZCkgcmV0dXJuIDA7XG4gIGlmIChzdGF0ZS5vYmplY3RNb2RlKSByZXR1cm4gMTtcblxuICBpZiAobiAhPT0gbikge1xuICAgIC8vIE9ubHkgZmxvdyBvbmUgYnVmZmVyIGF0IGEgdGltZVxuICAgIGlmIChzdGF0ZS5mbG93aW5nICYmIHN0YXRlLmxlbmd0aCkgcmV0dXJuIHN0YXRlLmJ1ZmZlci5oZWFkLmRhdGEubGVuZ3RoO2Vsc2UgcmV0dXJuIHN0YXRlLmxlbmd0aDtcbiAgfSAvLyBJZiB3ZSdyZSBhc2tpbmcgZm9yIG1vcmUgdGhhbiB0aGUgY3VycmVudCBod20sIHRoZW4gcmFpc2UgdGhlIGh3bS5cblxuXG4gIGlmIChuID4gc3RhdGUuaGlnaFdhdGVyTWFyaykgc3RhdGUuaGlnaFdhdGVyTWFyayA9IGNvbXB1dGVOZXdIaWdoV2F0ZXJNYXJrKG4pO1xuICBpZiAobiA8PSBzdGF0ZS5sZW5ndGgpIHJldHVybiBuOyAvLyBEb24ndCBoYXZlIGVub3VnaFxuXG4gIGlmICghc3RhdGUuZW5kZWQpIHtcbiAgICBzdGF0ZS5uZWVkUmVhZGFibGUgPSB0cnVlO1xuICAgIHJldHVybiAwO1xuICB9XG5cbiAgcmV0dXJuIHN0YXRlLmxlbmd0aDtcbn0gLy8geW91IGNhbiBvdmVycmlkZSBlaXRoZXIgdGhpcyBtZXRob2QsIG9yIHRoZSBhc3luYyBfcmVhZChuKSBiZWxvdy5cblxuXG5SZWFkYWJsZS5wcm90b3R5cGUucmVhZCA9IGZ1bmN0aW9uIChuKSB7XG4gIGRlYnVnKCdyZWFkJywgbik7XG4gIG4gPSBwYXJzZUludChuLCAxMCk7XG4gIHZhciBzdGF0ZSA9IHRoaXMuX3JlYWRhYmxlU3RhdGU7XG4gIHZhciBuT3JpZyA9IG47XG4gIGlmIChuICE9PSAwKSBzdGF0ZS5lbWl0dGVkUmVhZGFibGUgPSBmYWxzZTsgLy8gaWYgd2UncmUgZG9pbmcgcmVhZCgwKSB0byB0cmlnZ2VyIGEgcmVhZGFibGUgZXZlbnQsIGJ1dCB3ZVxuICAvLyBhbHJlYWR5IGhhdmUgYSBidW5jaCBvZiBkYXRhIGluIHRoZSBidWZmZXIsIHRoZW4ganVzdCB0cmlnZ2VyXG4gIC8vIHRoZSAncmVhZGFibGUnIGV2ZW50IGFuZCBtb3ZlIG9uLlxuXG4gIGlmIChuID09PSAwICYmIHN0YXRlLm5lZWRSZWFkYWJsZSAmJiAoKHN0YXRlLmhpZ2hXYXRlck1hcmsgIT09IDAgPyBzdGF0ZS5sZW5ndGggPj0gc3RhdGUuaGlnaFdhdGVyTWFyayA6IHN0YXRlLmxlbmd0aCA+IDApIHx8IHN0YXRlLmVuZGVkKSkge1xuICAgIGRlYnVnKCdyZWFkOiBlbWl0UmVhZGFibGUnLCBzdGF0ZS5sZW5ndGgsIHN0YXRlLmVuZGVkKTtcbiAgICBpZiAoc3RhdGUubGVuZ3RoID09PSAwICYmIHN0YXRlLmVuZGVkKSBlbmRSZWFkYWJsZSh0aGlzKTtlbHNlIGVtaXRSZWFkYWJsZSh0aGlzKTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIG4gPSBob3dNdWNoVG9SZWFkKG4sIHN0YXRlKTsgLy8gaWYgd2UndmUgZW5kZWQsIGFuZCB3ZSdyZSBub3cgY2xlYXIsIHRoZW4gZmluaXNoIGl0IHVwLlxuXG4gIGlmIChuID09PSAwICYmIHN0YXRlLmVuZGVkKSB7XG4gICAgaWYgKHN0YXRlLmxlbmd0aCA9PT0gMCkgZW5kUmVhZGFibGUodGhpcyk7XG4gICAgcmV0dXJuIG51bGw7XG4gIH0gLy8gQWxsIHRoZSBhY3R1YWwgY2h1bmsgZ2VuZXJhdGlvbiBsb2dpYyBuZWVkcyB0byBiZVxuICAvLyAqYmVsb3cqIHRoZSBjYWxsIHRvIF9yZWFkLiAgVGhlIHJlYXNvbiBpcyB0aGF0IGluIGNlcnRhaW5cbiAgLy8gc3ludGhldGljIHN0cmVhbSBjYXNlcywgc3VjaCBhcyBwYXNzdGhyb3VnaCBzdHJlYW1zLCBfcmVhZFxuICAvLyBtYXkgYmUgYSBjb21wbGV0ZWx5IHN5bmNocm9ub3VzIG9wZXJhdGlvbiB3aGljaCBtYXkgY2hhbmdlXG4gIC8vIHRoZSBzdGF0ZSBvZiB0aGUgcmVhZCBidWZmZXIsIHByb3ZpZGluZyBlbm91Z2ggZGF0YSB3aGVuXG4gIC8vIGJlZm9yZSB0aGVyZSB3YXMgKm5vdCogZW5vdWdoLlxuICAvL1xuICAvLyBTbywgdGhlIHN0ZXBzIGFyZTpcbiAgLy8gMS4gRmlndXJlIG91dCB3aGF0IHRoZSBzdGF0ZSBvZiB0aGluZ3Mgd2lsbCBiZSBhZnRlciB3ZSBkb1xuICAvLyBhIHJlYWQgZnJvbSB0aGUgYnVmZmVyLlxuICAvL1xuICAvLyAyLiBJZiB0aGF0IHJlc3VsdGluZyBzdGF0ZSB3aWxsIHRyaWdnZXIgYSBfcmVhZCwgdGhlbiBjYWxsIF9yZWFkLlxuICAvLyBOb3RlIHRoYXQgdGhpcyBtYXkgYmUgYXN5bmNocm9ub3VzLCBvciBzeW5jaHJvbm91cy4gIFllcywgaXQgaXNcbiAgLy8gZGVlcGx5IHVnbHkgdG8gd3JpdGUgQVBJcyB0aGlzIHdheSwgYnV0IHRoYXQgc3RpbGwgZG9lc24ndCBtZWFuXG4gIC8vIHRoYXQgdGhlIFJlYWRhYmxlIGNsYXNzIHNob3VsZCBiZWhhdmUgaW1wcm9wZXJseSwgYXMgc3RyZWFtcyBhcmVcbiAgLy8gZGVzaWduZWQgdG8gYmUgc3luYy9hc3luYyBhZ25vc3RpYy5cbiAgLy8gVGFrZSBub3RlIGlmIHRoZSBfcmVhZCBjYWxsIGlzIHN5bmMgb3IgYXN5bmMgKGllLCBpZiB0aGUgcmVhZCBjYWxsXG4gIC8vIGhhcyByZXR1cm5lZCB5ZXQpLCBzbyB0aGF0IHdlIGtub3cgd2hldGhlciBvciBub3QgaXQncyBzYWZlIHRvIGVtaXRcbiAgLy8gJ3JlYWRhYmxlJyBldGMuXG4gIC8vXG4gIC8vIDMuIEFjdHVhbGx5IHB1bGwgdGhlIHJlcXVlc3RlZCBjaHVua3Mgb3V0IG9mIHRoZSBidWZmZXIgYW5kIHJldHVybi5cbiAgLy8gaWYgd2UgbmVlZCBhIHJlYWRhYmxlIGV2ZW50LCB0aGVuIHdlIG5lZWQgdG8gZG8gc29tZSByZWFkaW5nLlxuXG5cbiAgdmFyIGRvUmVhZCA9IHN0YXRlLm5lZWRSZWFkYWJsZTtcbiAgZGVidWcoJ25lZWQgcmVhZGFibGUnLCBkb1JlYWQpOyAvLyBpZiB3ZSBjdXJyZW50bHkgaGF2ZSBsZXNzIHRoYW4gdGhlIGhpZ2hXYXRlck1hcmssIHRoZW4gYWxzbyByZWFkIHNvbWVcblxuICBpZiAoc3RhdGUubGVuZ3RoID09PSAwIHx8IHN0YXRlLmxlbmd0aCAtIG4gPCBzdGF0ZS5oaWdoV2F0ZXJNYXJrKSB7XG4gICAgZG9SZWFkID0gdHJ1ZTtcbiAgICBkZWJ1ZygnbGVuZ3RoIGxlc3MgdGhhbiB3YXRlcm1hcmsnLCBkb1JlYWQpO1xuICB9IC8vIGhvd2V2ZXIsIGlmIHdlJ3ZlIGVuZGVkLCB0aGVuIHRoZXJlJ3Mgbm8gcG9pbnQsIGFuZCBpZiB3ZSdyZSBhbHJlYWR5XG4gIC8vIHJlYWRpbmcsIHRoZW4gaXQncyB1bm5lY2Vzc2FyeS5cblxuXG4gIGlmIChzdGF0ZS5lbmRlZCB8fCBzdGF0ZS5yZWFkaW5nKSB7XG4gICAgZG9SZWFkID0gZmFsc2U7XG4gICAgZGVidWcoJ3JlYWRpbmcgb3IgZW5kZWQnLCBkb1JlYWQpO1xuICB9IGVsc2UgaWYgKGRvUmVhZCkge1xuICAgIGRlYnVnKCdkbyByZWFkJyk7XG4gICAgc3RhdGUucmVhZGluZyA9IHRydWU7XG4gICAgc3RhdGUuc3luYyA9IHRydWU7IC8vIGlmIHRoZSBsZW5ndGggaXMgY3VycmVudGx5IHplcm8sIHRoZW4gd2UgKm5lZWQqIGEgcmVhZGFibGUgZXZlbnQuXG5cbiAgICBpZiAoc3RhdGUubGVuZ3RoID09PSAwKSBzdGF0ZS5uZWVkUmVhZGFibGUgPSB0cnVlOyAvLyBjYWxsIGludGVybmFsIHJlYWQgbWV0aG9kXG5cbiAgICB0aGlzLl9yZWFkKHN0YXRlLmhpZ2hXYXRlck1hcmspO1xuXG4gICAgc3RhdGUuc3luYyA9IGZhbHNlOyAvLyBJZiBfcmVhZCBwdXNoZWQgZGF0YSBzeW5jaHJvbm91c2x5LCB0aGVuIGByZWFkaW5nYCB3aWxsIGJlIGZhbHNlLFxuICAgIC8vIGFuZCB3ZSBuZWVkIHRvIHJlLWV2YWx1YXRlIGhvdyBtdWNoIGRhdGEgd2UgY2FuIHJldHVybiB0byB0aGUgdXNlci5cblxuICAgIGlmICghc3RhdGUucmVhZGluZykgbiA9IGhvd011Y2hUb1JlYWQobk9yaWcsIHN0YXRlKTtcbiAgfVxuXG4gIHZhciByZXQ7XG4gIGlmIChuID4gMCkgcmV0ID0gZnJvbUxpc3Qobiwgc3RhdGUpO2Vsc2UgcmV0ID0gbnVsbDtcblxuICBpZiAocmV0ID09PSBudWxsKSB7XG4gICAgc3RhdGUubmVlZFJlYWRhYmxlID0gc3RhdGUubGVuZ3RoIDw9IHN0YXRlLmhpZ2hXYXRlck1hcms7XG4gICAgbiA9IDA7XG4gIH0gZWxzZSB7XG4gICAgc3RhdGUubGVuZ3RoIC09IG47XG4gICAgc3RhdGUuYXdhaXREcmFpbiA9IDA7XG4gIH1cblxuICBpZiAoc3RhdGUubGVuZ3RoID09PSAwKSB7XG4gICAgLy8gSWYgd2UgaGF2ZSBub3RoaW5nIGluIHRoZSBidWZmZXIsIHRoZW4gd2Ugd2FudCB0byBrbm93XG4gICAgLy8gYXMgc29vbiBhcyB3ZSAqZG8qIGdldCBzb21ldGhpbmcgaW50byB0aGUgYnVmZmVyLlxuICAgIGlmICghc3RhdGUuZW5kZWQpIHN0YXRlLm5lZWRSZWFkYWJsZSA9IHRydWU7IC8vIElmIHdlIHRyaWVkIHRvIHJlYWQoKSBwYXN0IHRoZSBFT0YsIHRoZW4gZW1pdCBlbmQgb24gdGhlIG5leHQgdGljay5cblxuICAgIGlmIChuT3JpZyAhPT0gbiAmJiBzdGF0ZS5lbmRlZCkgZW5kUmVhZGFibGUodGhpcyk7XG4gIH1cblxuICBpZiAocmV0ICE9PSBudWxsKSB0aGlzLmVtaXQoJ2RhdGEnLCByZXQpO1xuICByZXR1cm4gcmV0O1xufTtcblxuZnVuY3Rpb24gb25Fb2ZDaHVuayhzdHJlYW0sIHN0YXRlKSB7XG4gIGRlYnVnKCdvbkVvZkNodW5rJyk7XG4gIGlmIChzdGF0ZS5lbmRlZCkgcmV0dXJuO1xuXG4gIGlmIChzdGF0ZS5kZWNvZGVyKSB7XG4gICAgdmFyIGNodW5rID0gc3RhdGUuZGVjb2Rlci5lbmQoKTtcblxuICAgIGlmIChjaHVuayAmJiBjaHVuay5sZW5ndGgpIHtcbiAgICAgIHN0YXRlLmJ1ZmZlci5wdXNoKGNodW5rKTtcbiAgICAgIHN0YXRlLmxlbmd0aCArPSBzdGF0ZS5vYmplY3RNb2RlID8gMSA6IGNodW5rLmxlbmd0aDtcbiAgICB9XG4gIH1cblxuICBzdGF0ZS5lbmRlZCA9IHRydWU7XG5cbiAgaWYgKHN0YXRlLnN5bmMpIHtcbiAgICAvLyBpZiB3ZSBhcmUgc3luYywgd2FpdCB1bnRpbCBuZXh0IHRpY2sgdG8gZW1pdCB0aGUgZGF0YS5cbiAgICAvLyBPdGhlcndpc2Ugd2UgcmlzayBlbWl0dGluZyBkYXRhIGluIHRoZSBmbG93KClcbiAgICAvLyB0aGUgcmVhZGFibGUgY29kZSB0cmlnZ2VycyBkdXJpbmcgYSByZWFkKCkgY2FsbFxuICAgIGVtaXRSZWFkYWJsZShzdHJlYW0pO1xuICB9IGVsc2Uge1xuICAgIC8vIGVtaXQgJ3JlYWRhYmxlJyBub3cgdG8gbWFrZSBzdXJlIGl0IGdldHMgcGlja2VkIHVwLlxuICAgIHN0YXRlLm5lZWRSZWFkYWJsZSA9IGZhbHNlO1xuXG4gICAgaWYgKCFzdGF0ZS5lbWl0dGVkUmVhZGFibGUpIHtcbiAgICAgIHN0YXRlLmVtaXR0ZWRSZWFkYWJsZSA9IHRydWU7XG4gICAgICBlbWl0UmVhZGFibGVfKHN0cmVhbSk7XG4gICAgfVxuICB9XG59IC8vIERvbid0IGVtaXQgcmVhZGFibGUgcmlnaHQgYXdheSBpbiBzeW5jIG1vZGUsIGJlY2F1c2UgdGhpcyBjYW4gdHJpZ2dlclxuLy8gYW5vdGhlciByZWFkKCkgY2FsbCA9PiBzdGFjayBvdmVyZmxvdy4gIFRoaXMgd2F5LCBpdCBtaWdodCB0cmlnZ2VyXG4vLyBhIG5leHRUaWNrIHJlY3Vyc2lvbiB3YXJuaW5nLCBidXQgdGhhdCdzIG5vdCBzbyBiYWQuXG5cblxuZnVuY3Rpb24gZW1pdFJlYWRhYmxlKHN0cmVhbSkge1xuICB2YXIgc3RhdGUgPSBzdHJlYW0uX3JlYWRhYmxlU3RhdGU7XG4gIGRlYnVnKCdlbWl0UmVhZGFibGUnLCBzdGF0ZS5uZWVkUmVhZGFibGUsIHN0YXRlLmVtaXR0ZWRSZWFkYWJsZSk7XG4gIHN0YXRlLm5lZWRSZWFkYWJsZSA9IGZhbHNlO1xuXG4gIGlmICghc3RhdGUuZW1pdHRlZFJlYWRhYmxlKSB7XG4gICAgZGVidWcoJ2VtaXRSZWFkYWJsZScsIHN0YXRlLmZsb3dpbmcpO1xuICAgIHN0YXRlLmVtaXR0ZWRSZWFkYWJsZSA9IHRydWU7XG4gICAgcHJvY2Vzcy5uZXh0VGljayhlbWl0UmVhZGFibGVfLCBzdHJlYW0pO1xuICB9XG59XG5cbmZ1bmN0aW9uIGVtaXRSZWFkYWJsZV8oc3RyZWFtKSB7XG4gIHZhciBzdGF0ZSA9IHN0cmVhbS5fcmVhZGFibGVTdGF0ZTtcbiAgZGVidWcoJ2VtaXRSZWFkYWJsZV8nLCBzdGF0ZS5kZXN0cm95ZWQsIHN0YXRlLmxlbmd0aCwgc3RhdGUuZW5kZWQpO1xuXG4gIGlmICghc3RhdGUuZGVzdHJveWVkICYmIChzdGF0ZS5sZW5ndGggfHwgc3RhdGUuZW5kZWQpKSB7XG4gICAgc3RyZWFtLmVtaXQoJ3JlYWRhYmxlJyk7XG4gICAgc3RhdGUuZW1pdHRlZFJlYWRhYmxlID0gZmFsc2U7XG4gIH0gLy8gVGhlIHN0cmVhbSBuZWVkcyBhbm90aGVyIHJlYWRhYmxlIGV2ZW50IGlmXG4gIC8vIDEuIEl0IGlzIG5vdCBmbG93aW5nLCBhcyB0aGUgZmxvdyBtZWNoYW5pc20gd2lsbCB0YWtlXG4gIC8vICAgIGNhcmUgb2YgaXQuXG4gIC8vIDIuIEl0IGlzIG5vdCBlbmRlZC5cbiAgLy8gMy4gSXQgaXMgYmVsb3cgdGhlIGhpZ2hXYXRlck1hcmssIHNvIHdlIGNhbiBzY2hlZHVsZVxuICAvLyAgICBhbm90aGVyIHJlYWRhYmxlIGxhdGVyLlxuXG5cbiAgc3RhdGUubmVlZFJlYWRhYmxlID0gIXN0YXRlLmZsb3dpbmcgJiYgIXN0YXRlLmVuZGVkICYmIHN0YXRlLmxlbmd0aCA8PSBzdGF0ZS5oaWdoV2F0ZXJNYXJrO1xuICBmbG93KHN0cmVhbSk7XG59IC8vIGF0IHRoaXMgcG9pbnQsIHRoZSB1c2VyIGhhcyBwcmVzdW1hYmx5IHNlZW4gdGhlICdyZWFkYWJsZScgZXZlbnQsXG4vLyBhbmQgY2FsbGVkIHJlYWQoKSB0byBjb25zdW1lIHNvbWUgZGF0YS4gIHRoYXQgbWF5IGhhdmUgdHJpZ2dlcmVkXG4vLyBpbiB0dXJuIGFub3RoZXIgX3JlYWQobikgY2FsbCwgaW4gd2hpY2ggY2FzZSByZWFkaW5nID0gdHJ1ZSBpZlxuLy8gaXQncyBpbiBwcm9ncmVzcy5cbi8vIEhvd2V2ZXIsIGlmIHdlJ3JlIG5vdCBlbmRlZCwgb3IgcmVhZGluZywgYW5kIHRoZSBsZW5ndGggPCBod20sXG4vLyB0aGVuIGdvIGFoZWFkIGFuZCB0cnkgdG8gcmVhZCBzb21lIG1vcmUgcHJlZW1wdGl2ZWx5LlxuXG5cbmZ1bmN0aW9uIG1heWJlUmVhZE1vcmUoc3RyZWFtLCBzdGF0ZSkge1xuICBpZiAoIXN0YXRlLnJlYWRpbmdNb3JlKSB7XG4gICAgc3RhdGUucmVhZGluZ01vcmUgPSB0cnVlO1xuICAgIHByb2Nlc3MubmV4dFRpY2sobWF5YmVSZWFkTW9yZV8sIHN0cmVhbSwgc3RhdGUpO1xuICB9XG59XG5cbmZ1bmN0aW9uIG1heWJlUmVhZE1vcmVfKHN0cmVhbSwgc3RhdGUpIHtcbiAgLy8gQXR0ZW1wdCB0byByZWFkIG1vcmUgZGF0YSBpZiB3ZSBzaG91bGQuXG4gIC8vXG4gIC8vIFRoZSBjb25kaXRpb25zIGZvciByZWFkaW5nIG1vcmUgZGF0YSBhcmUgKG9uZSBvZik6XG4gIC8vIC0gTm90IGVub3VnaCBkYXRhIGJ1ZmZlcmVkIChzdGF0ZS5sZW5ndGggPCBzdGF0ZS5oaWdoV2F0ZXJNYXJrKS4gVGhlIGxvb3BcbiAgLy8gICBpcyByZXNwb25zaWJsZSBmb3IgZmlsbGluZyB0aGUgYnVmZmVyIHdpdGggZW5vdWdoIGRhdGEgaWYgc3VjaCBkYXRhXG4gIC8vICAgaXMgYXZhaWxhYmxlLiBJZiBoaWdoV2F0ZXJNYXJrIGlzIDAgYW5kIHdlIGFyZSBub3QgaW4gdGhlIGZsb3dpbmcgbW9kZVxuICAvLyAgIHdlIHNob3VsZCBfbm90XyBhdHRlbXB0IHRvIGJ1ZmZlciBhbnkgZXh0cmEgZGF0YS4gV2UnbGwgZ2V0IG1vcmUgZGF0YVxuICAvLyAgIHdoZW4gdGhlIHN0cmVhbSBjb25zdW1lciBjYWxscyByZWFkKCkgaW5zdGVhZC5cbiAgLy8gLSBObyBkYXRhIGluIHRoZSBidWZmZXIsIGFuZCB0aGUgc3RyZWFtIGlzIGluIGZsb3dpbmcgbW9kZS4gSW4gdGhpcyBtb2RlXG4gIC8vICAgdGhlIGxvb3AgYmVsb3cgaXMgcmVzcG9uc2libGUgZm9yIGVuc3VyaW5nIHJlYWQoKSBpcyBjYWxsZWQuIEZhaWxpbmcgdG9cbiAgLy8gICBjYWxsIHJlYWQgaGVyZSB3b3VsZCBhYm9ydCB0aGUgZmxvdyBhbmQgdGhlcmUncyBubyBvdGhlciBtZWNoYW5pc20gZm9yXG4gIC8vICAgY29udGludWluZyB0aGUgZmxvdyBpZiB0aGUgc3RyZWFtIGNvbnN1bWVyIGhhcyBqdXN0IHN1YnNjcmliZWQgdG8gdGhlXG4gIC8vICAgJ2RhdGEnIGV2ZW50LlxuICAvL1xuICAvLyBJbiBhZGRpdGlvbiB0byB0aGUgYWJvdmUgY29uZGl0aW9ucyB0byBrZWVwIHJlYWRpbmcgZGF0YSwgdGhlIGZvbGxvd2luZ1xuICAvLyBjb25kaXRpb25zIHByZXZlbnQgdGhlIGRhdGEgZnJvbSBiZWluZyByZWFkOlxuICAvLyAtIFRoZSBzdHJlYW0gaGFzIGVuZGVkIChzdGF0ZS5lbmRlZCkuXG4gIC8vIC0gVGhlcmUgaXMgYWxyZWFkeSBhIHBlbmRpbmcgJ3JlYWQnIG9wZXJhdGlvbiAoc3RhdGUucmVhZGluZykuIFRoaXMgaXMgYVxuICAvLyAgIGNhc2Ugd2hlcmUgdGhlIHRoZSBzdHJlYW0gaGFzIGNhbGxlZCB0aGUgaW1wbGVtZW50YXRpb24gZGVmaW5lZCBfcmVhZCgpXG4gIC8vICAgbWV0aG9kLCBidXQgdGhleSBhcmUgcHJvY2Vzc2luZyB0aGUgY2FsbCBhc3luY2hyb25vdXNseSBhbmQgaGF2ZSBfbm90X1xuICAvLyAgIGNhbGxlZCBwdXNoKCkgd2l0aCBuZXcgZGF0YS4gSW4gdGhpcyBjYXNlIHdlIHNraXAgcGVyZm9ybWluZyBtb3JlXG4gIC8vICAgcmVhZCgpcy4gVGhlIGV4ZWN1dGlvbiBlbmRzIGluIHRoaXMgbWV0aG9kIGFnYWluIGFmdGVyIHRoZSBfcmVhZCgpIGVuZHNcbiAgLy8gICB1cCBjYWxsaW5nIHB1c2goKSB3aXRoIG1vcmUgZGF0YS5cbiAgd2hpbGUgKCFzdGF0ZS5yZWFkaW5nICYmICFzdGF0ZS5lbmRlZCAmJiAoc3RhdGUubGVuZ3RoIDwgc3RhdGUuaGlnaFdhdGVyTWFyayB8fCBzdGF0ZS5mbG93aW5nICYmIHN0YXRlLmxlbmd0aCA9PT0gMCkpIHtcbiAgICB2YXIgbGVuID0gc3RhdGUubGVuZ3RoO1xuICAgIGRlYnVnKCdtYXliZVJlYWRNb3JlIHJlYWQgMCcpO1xuICAgIHN0cmVhbS5yZWFkKDApO1xuICAgIGlmIChsZW4gPT09IHN0YXRlLmxlbmd0aCkgLy8gZGlkbid0IGdldCBhbnkgZGF0YSwgc3RvcCBzcGlubmluZy5cbiAgICAgIGJyZWFrO1xuICB9XG5cbiAgc3RhdGUucmVhZGluZ01vcmUgPSBmYWxzZTtcbn0gLy8gYWJzdHJhY3QgbWV0aG9kLiAgdG8gYmUgb3ZlcnJpZGRlbiBpbiBzcGVjaWZpYyBpbXBsZW1lbnRhdGlvbiBjbGFzc2VzLlxuLy8gY2FsbCBjYihlciwgZGF0YSkgd2hlcmUgZGF0YSBpcyA8PSBuIGluIGxlbmd0aC5cbi8vIGZvciB2aXJ0dWFsIChub24tc3RyaW5nLCBub24tYnVmZmVyKSBzdHJlYW1zLCBcImxlbmd0aFwiIGlzIHNvbWV3aGF0XG4vLyBhcmJpdHJhcnksIGFuZCBwZXJoYXBzIG5vdCB2ZXJ5IG1lYW5pbmdmdWwuXG5cblxuUmVhZGFibGUucHJvdG90eXBlLl9yZWFkID0gZnVuY3Rpb24gKG4pIHtcbiAgZXJyb3JPckRlc3Ryb3kodGhpcywgbmV3IEVSUl9NRVRIT0RfTk9UX0lNUExFTUVOVEVEKCdfcmVhZCgpJykpO1xufTtcblxuUmVhZGFibGUucHJvdG90eXBlLnBpcGUgPSBmdW5jdGlvbiAoZGVzdCwgcGlwZU9wdHMpIHtcbiAgdmFyIHNyYyA9IHRoaXM7XG4gIHZhciBzdGF0ZSA9IHRoaXMuX3JlYWRhYmxlU3RhdGU7XG5cbiAgc3dpdGNoIChzdGF0ZS5waXBlc0NvdW50KSB7XG4gICAgY2FzZSAwOlxuICAgICAgc3RhdGUucGlwZXMgPSBkZXN0O1xuICAgICAgYnJlYWs7XG5cbiAgICBjYXNlIDE6XG4gICAgICBzdGF0ZS5waXBlcyA9IFtzdGF0ZS5waXBlcywgZGVzdF07XG4gICAgICBicmVhaztcblxuICAgIGRlZmF1bHQ6XG4gICAgICBzdGF0ZS5waXBlcy5wdXNoKGRlc3QpO1xuICAgICAgYnJlYWs7XG4gIH1cblxuICBzdGF0ZS5waXBlc0NvdW50ICs9IDE7XG4gIGRlYnVnKCdwaXBlIGNvdW50PSVkIG9wdHM9JWonLCBzdGF0ZS5waXBlc0NvdW50LCBwaXBlT3B0cyk7XG4gIHZhciBkb0VuZCA9ICghcGlwZU9wdHMgfHwgcGlwZU9wdHMuZW5kICE9PSBmYWxzZSkgJiYgZGVzdCAhPT0gcHJvY2Vzcy5zdGRvdXQgJiYgZGVzdCAhPT0gcHJvY2Vzcy5zdGRlcnI7XG4gIHZhciBlbmRGbiA9IGRvRW5kID8gb25lbmQgOiB1bnBpcGU7XG4gIGlmIChzdGF0ZS5lbmRFbWl0dGVkKSBwcm9jZXNzLm5leHRUaWNrKGVuZEZuKTtlbHNlIHNyYy5vbmNlKCdlbmQnLCBlbmRGbik7XG4gIGRlc3Qub24oJ3VucGlwZScsIG9udW5waXBlKTtcblxuICBmdW5jdGlvbiBvbnVucGlwZShyZWFkYWJsZSwgdW5waXBlSW5mbykge1xuICAgIGRlYnVnKCdvbnVucGlwZScpO1xuXG4gICAgaWYgKHJlYWRhYmxlID09PSBzcmMpIHtcbiAgICAgIGlmICh1bnBpcGVJbmZvICYmIHVucGlwZUluZm8uaGFzVW5waXBlZCA9PT0gZmFsc2UpIHtcbiAgICAgICAgdW5waXBlSW5mby5oYXNVbnBpcGVkID0gdHJ1ZTtcbiAgICAgICAgY2xlYW51cCgpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIG9uZW5kKCkge1xuICAgIGRlYnVnKCdvbmVuZCcpO1xuICAgIGRlc3QuZW5kKCk7XG4gIH0gLy8gd2hlbiB0aGUgZGVzdCBkcmFpbnMsIGl0IHJlZHVjZXMgdGhlIGF3YWl0RHJhaW4gY291bnRlclxuICAvLyBvbiB0aGUgc291cmNlLiAgVGhpcyB3b3VsZCBiZSBtb3JlIGVsZWdhbnQgd2l0aCBhIC5vbmNlKClcbiAgLy8gaGFuZGxlciBpbiBmbG93KCksIGJ1dCBhZGRpbmcgYW5kIHJlbW92aW5nIHJlcGVhdGVkbHkgaXNcbiAgLy8gdG9vIHNsb3cuXG5cblxuICB2YXIgb25kcmFpbiA9IHBpcGVPbkRyYWluKHNyYyk7XG4gIGRlc3Qub24oJ2RyYWluJywgb25kcmFpbik7XG4gIHZhciBjbGVhbmVkVXAgPSBmYWxzZTtcblxuICBmdW5jdGlvbiBjbGVhbnVwKCkge1xuICAgIGRlYnVnKCdjbGVhbnVwJyk7IC8vIGNsZWFudXAgZXZlbnQgaGFuZGxlcnMgb25jZSB0aGUgcGlwZSBpcyBicm9rZW5cblxuICAgIGRlc3QucmVtb3ZlTGlzdGVuZXIoJ2Nsb3NlJywgb25jbG9zZSk7XG4gICAgZGVzdC5yZW1vdmVMaXN0ZW5lcignZmluaXNoJywgb25maW5pc2gpO1xuICAgIGRlc3QucmVtb3ZlTGlzdGVuZXIoJ2RyYWluJywgb25kcmFpbik7XG4gICAgZGVzdC5yZW1vdmVMaXN0ZW5lcignZXJyb3InLCBvbmVycm9yKTtcbiAgICBkZXN0LnJlbW92ZUxpc3RlbmVyKCd1bnBpcGUnLCBvbnVucGlwZSk7XG4gICAgc3JjLnJlbW92ZUxpc3RlbmVyKCdlbmQnLCBvbmVuZCk7XG4gICAgc3JjLnJlbW92ZUxpc3RlbmVyKCdlbmQnLCB1bnBpcGUpO1xuICAgIHNyYy5yZW1vdmVMaXN0ZW5lcignZGF0YScsIG9uZGF0YSk7XG4gICAgY2xlYW5lZFVwID0gdHJ1ZTsgLy8gaWYgdGhlIHJlYWRlciBpcyB3YWl0aW5nIGZvciBhIGRyYWluIGV2ZW50IGZyb20gdGhpc1xuICAgIC8vIHNwZWNpZmljIHdyaXRlciwgdGhlbiBpdCB3b3VsZCBjYXVzZSBpdCB0byBuZXZlciBzdGFydFxuICAgIC8vIGZsb3dpbmcgYWdhaW4uXG4gICAgLy8gU28sIGlmIHRoaXMgaXMgYXdhaXRpbmcgYSBkcmFpbiwgdGhlbiB3ZSBqdXN0IGNhbGwgaXQgbm93LlxuICAgIC8vIElmIHdlIGRvbid0IGtub3csIHRoZW4gYXNzdW1lIHRoYXQgd2UgYXJlIHdhaXRpbmcgZm9yIG9uZS5cblxuICAgIGlmIChzdGF0ZS5hd2FpdERyYWluICYmICghZGVzdC5fd3JpdGFibGVTdGF0ZSB8fCBkZXN0Ll93cml0YWJsZVN0YXRlLm5lZWREcmFpbikpIG9uZHJhaW4oKTtcbiAgfVxuXG4gIHNyYy5vbignZGF0YScsIG9uZGF0YSk7XG5cbiAgZnVuY3Rpb24gb25kYXRhKGNodW5rKSB7XG4gICAgZGVidWcoJ29uZGF0YScpO1xuICAgIHZhciByZXQgPSBkZXN0LndyaXRlKGNodW5rKTtcbiAgICBkZWJ1ZygnZGVzdC53cml0ZScsIHJldCk7XG5cbiAgICBpZiAocmV0ID09PSBmYWxzZSkge1xuICAgICAgLy8gSWYgdGhlIHVzZXIgdW5waXBlZCBkdXJpbmcgYGRlc3Qud3JpdGUoKWAsIGl0IGlzIHBvc3NpYmxlXG4gICAgICAvLyB0byBnZXQgc3R1Y2sgaW4gYSBwZXJtYW5lbnRseSBwYXVzZWQgc3RhdGUgaWYgdGhhdCB3cml0ZVxuICAgICAgLy8gYWxzbyByZXR1cm5lZCBmYWxzZS5cbiAgICAgIC8vID0+IENoZWNrIHdoZXRoZXIgYGRlc3RgIGlzIHN0aWxsIGEgcGlwaW5nIGRlc3RpbmF0aW9uLlxuICAgICAgaWYgKChzdGF0ZS5waXBlc0NvdW50ID09PSAxICYmIHN0YXRlLnBpcGVzID09PSBkZXN0IHx8IHN0YXRlLnBpcGVzQ291bnQgPiAxICYmIGluZGV4T2Yoc3RhdGUucGlwZXMsIGRlc3QpICE9PSAtMSkgJiYgIWNsZWFuZWRVcCkge1xuICAgICAgICBkZWJ1ZygnZmFsc2Ugd3JpdGUgcmVzcG9uc2UsIHBhdXNlJywgc3RhdGUuYXdhaXREcmFpbik7XG4gICAgICAgIHN0YXRlLmF3YWl0RHJhaW4rKztcbiAgICAgIH1cblxuICAgICAgc3JjLnBhdXNlKCk7XG4gICAgfVxuICB9IC8vIGlmIHRoZSBkZXN0IGhhcyBhbiBlcnJvciwgdGhlbiBzdG9wIHBpcGluZyBpbnRvIGl0LlxuICAvLyBob3dldmVyLCBkb24ndCBzdXBwcmVzcyB0aGUgdGhyb3dpbmcgYmVoYXZpb3IgZm9yIHRoaXMuXG5cblxuICBmdW5jdGlvbiBvbmVycm9yKGVyKSB7XG4gICAgZGVidWcoJ29uZXJyb3InLCBlcik7XG4gICAgdW5waXBlKCk7XG4gICAgZGVzdC5yZW1vdmVMaXN0ZW5lcignZXJyb3InLCBvbmVycm9yKTtcbiAgICBpZiAoRUVsaXN0ZW5lckNvdW50KGRlc3QsICdlcnJvcicpID09PSAwKSBlcnJvck9yRGVzdHJveShkZXN0LCBlcik7XG4gIH0gLy8gTWFrZSBzdXJlIG91ciBlcnJvciBoYW5kbGVyIGlzIGF0dGFjaGVkIGJlZm9yZSB1c2VybGFuZCBvbmVzLlxuXG5cbiAgcHJlcGVuZExpc3RlbmVyKGRlc3QsICdlcnJvcicsIG9uZXJyb3IpOyAvLyBCb3RoIGNsb3NlIGFuZCBmaW5pc2ggc2hvdWxkIHRyaWdnZXIgdW5waXBlLCBidXQgb25seSBvbmNlLlxuXG4gIGZ1bmN0aW9uIG9uY2xvc2UoKSB7XG4gICAgZGVzdC5yZW1vdmVMaXN0ZW5lcignZmluaXNoJywgb25maW5pc2gpO1xuICAgIHVucGlwZSgpO1xuICB9XG5cbiAgZGVzdC5vbmNlKCdjbG9zZScsIG9uY2xvc2UpO1xuXG4gIGZ1bmN0aW9uIG9uZmluaXNoKCkge1xuICAgIGRlYnVnKCdvbmZpbmlzaCcpO1xuICAgIGRlc3QucmVtb3ZlTGlzdGVuZXIoJ2Nsb3NlJywgb25jbG9zZSk7XG4gICAgdW5waXBlKCk7XG4gIH1cblxuICBkZXN0Lm9uY2UoJ2ZpbmlzaCcsIG9uZmluaXNoKTtcblxuICBmdW5jdGlvbiB1bnBpcGUoKSB7XG4gICAgZGVidWcoJ3VucGlwZScpO1xuICAgIHNyYy51bnBpcGUoZGVzdCk7XG4gIH0gLy8gdGVsbCB0aGUgZGVzdCB0aGF0IGl0J3MgYmVpbmcgcGlwZWQgdG9cblxuXG4gIGRlc3QuZW1pdCgncGlwZScsIHNyYyk7IC8vIHN0YXJ0IHRoZSBmbG93IGlmIGl0IGhhc24ndCBiZWVuIHN0YXJ0ZWQgYWxyZWFkeS5cblxuICBpZiAoIXN0YXRlLmZsb3dpbmcpIHtcbiAgICBkZWJ1ZygncGlwZSByZXN1bWUnKTtcbiAgICBzcmMucmVzdW1lKCk7XG4gIH1cblxuICByZXR1cm4gZGVzdDtcbn07XG5cbmZ1bmN0aW9uIHBpcGVPbkRyYWluKHNyYykge1xuICByZXR1cm4gZnVuY3Rpb24gcGlwZU9uRHJhaW5GdW5jdGlvblJlc3VsdCgpIHtcbiAgICB2YXIgc3RhdGUgPSBzcmMuX3JlYWRhYmxlU3RhdGU7XG4gICAgZGVidWcoJ3BpcGVPbkRyYWluJywgc3RhdGUuYXdhaXREcmFpbik7XG4gICAgaWYgKHN0YXRlLmF3YWl0RHJhaW4pIHN0YXRlLmF3YWl0RHJhaW4tLTtcblxuICAgIGlmIChzdGF0ZS5hd2FpdERyYWluID09PSAwICYmIEVFbGlzdGVuZXJDb3VudChzcmMsICdkYXRhJykpIHtcbiAgICAgIHN0YXRlLmZsb3dpbmcgPSB0cnVlO1xuICAgICAgZmxvdyhzcmMpO1xuICAgIH1cbiAgfTtcbn1cblxuUmVhZGFibGUucHJvdG90eXBlLnVucGlwZSA9IGZ1bmN0aW9uIChkZXN0KSB7XG4gIHZhciBzdGF0ZSA9IHRoaXMuX3JlYWRhYmxlU3RhdGU7XG4gIHZhciB1bnBpcGVJbmZvID0ge1xuICAgIGhhc1VucGlwZWQ6IGZhbHNlXG4gIH07IC8vIGlmIHdlJ3JlIG5vdCBwaXBpbmcgYW55d2hlcmUsIHRoZW4gZG8gbm90aGluZy5cblxuICBpZiAoc3RhdGUucGlwZXNDb3VudCA9PT0gMCkgcmV0dXJuIHRoaXM7IC8vIGp1c3Qgb25lIGRlc3RpbmF0aW9uLiAgbW9zdCBjb21tb24gY2FzZS5cblxuICBpZiAoc3RhdGUucGlwZXNDb3VudCA9PT0gMSkge1xuICAgIC8vIHBhc3NlZCBpbiBvbmUsIGJ1dCBpdCdzIG5vdCB0aGUgcmlnaHQgb25lLlxuICAgIGlmIChkZXN0ICYmIGRlc3QgIT09IHN0YXRlLnBpcGVzKSByZXR1cm4gdGhpcztcbiAgICBpZiAoIWRlc3QpIGRlc3QgPSBzdGF0ZS5waXBlczsgLy8gZ290IGEgbWF0Y2guXG5cbiAgICBzdGF0ZS5waXBlcyA9IG51bGw7XG4gICAgc3RhdGUucGlwZXNDb3VudCA9IDA7XG4gICAgc3RhdGUuZmxvd2luZyA9IGZhbHNlO1xuICAgIGlmIChkZXN0KSBkZXN0LmVtaXQoJ3VucGlwZScsIHRoaXMsIHVucGlwZUluZm8pO1xuICAgIHJldHVybiB0aGlzO1xuICB9IC8vIHNsb3cgY2FzZS4gbXVsdGlwbGUgcGlwZSBkZXN0aW5hdGlvbnMuXG5cblxuICBpZiAoIWRlc3QpIHtcbiAgICAvLyByZW1vdmUgYWxsLlxuICAgIHZhciBkZXN0cyA9IHN0YXRlLnBpcGVzO1xuICAgIHZhciBsZW4gPSBzdGF0ZS5waXBlc0NvdW50O1xuICAgIHN0YXRlLnBpcGVzID0gbnVsbDtcbiAgICBzdGF0ZS5waXBlc0NvdW50ID0gMDtcbiAgICBzdGF0ZS5mbG93aW5nID0gZmFsc2U7XG5cbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICBkZXN0c1tpXS5lbWl0KCd1bnBpcGUnLCB0aGlzLCB7XG4gICAgICAgIGhhc1VucGlwZWQ6IGZhbHNlXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcztcbiAgfSAvLyB0cnkgdG8gZmluZCB0aGUgcmlnaHQgb25lLlxuXG5cbiAgdmFyIGluZGV4ID0gaW5kZXhPZihzdGF0ZS5waXBlcywgZGVzdCk7XG4gIGlmIChpbmRleCA9PT0gLTEpIHJldHVybiB0aGlzO1xuICBzdGF0ZS5waXBlcy5zcGxpY2UoaW5kZXgsIDEpO1xuICBzdGF0ZS5waXBlc0NvdW50IC09IDE7XG4gIGlmIChzdGF0ZS5waXBlc0NvdW50ID09PSAxKSBzdGF0ZS5waXBlcyA9IHN0YXRlLnBpcGVzWzBdO1xuICBkZXN0LmVtaXQoJ3VucGlwZScsIHRoaXMsIHVucGlwZUluZm8pO1xuICByZXR1cm4gdGhpcztcbn07IC8vIHNldCB1cCBkYXRhIGV2ZW50cyBpZiB0aGV5IGFyZSBhc2tlZCBmb3Jcbi8vIEVuc3VyZSByZWFkYWJsZSBsaXN0ZW5lcnMgZXZlbnR1YWxseSBnZXQgc29tZXRoaW5nXG5cblxuUmVhZGFibGUucHJvdG90eXBlLm9uID0gZnVuY3Rpb24gKGV2LCBmbikge1xuICB2YXIgcmVzID0gU3RyZWFtLnByb3RvdHlwZS5vbi5jYWxsKHRoaXMsIGV2LCBmbik7XG4gIHZhciBzdGF0ZSA9IHRoaXMuX3JlYWRhYmxlU3RhdGU7XG5cbiAgaWYgKGV2ID09PSAnZGF0YScpIHtcbiAgICAvLyB1cGRhdGUgcmVhZGFibGVMaXN0ZW5pbmcgc28gdGhhdCByZXN1bWUoKSBtYXkgYmUgYSBuby1vcFxuICAgIC8vIGEgZmV3IGxpbmVzIGRvd24uIFRoaXMgaXMgbmVlZGVkIHRvIHN1cHBvcnQgb25jZSgncmVhZGFibGUnKS5cbiAgICBzdGF0ZS5yZWFkYWJsZUxpc3RlbmluZyA9IHRoaXMubGlzdGVuZXJDb3VudCgncmVhZGFibGUnKSA+IDA7IC8vIFRyeSBzdGFydCBmbG93aW5nIG9uIG5leHQgdGljayBpZiBzdHJlYW0gaXNuJ3QgZXhwbGljaXRseSBwYXVzZWRcblxuICAgIGlmIChzdGF0ZS5mbG93aW5nICE9PSBmYWxzZSkgdGhpcy5yZXN1bWUoKTtcbiAgfSBlbHNlIGlmIChldiA9PT0gJ3JlYWRhYmxlJykge1xuICAgIGlmICghc3RhdGUuZW5kRW1pdHRlZCAmJiAhc3RhdGUucmVhZGFibGVMaXN0ZW5pbmcpIHtcbiAgICAgIHN0YXRlLnJlYWRhYmxlTGlzdGVuaW5nID0gc3RhdGUubmVlZFJlYWRhYmxlID0gdHJ1ZTtcbiAgICAgIHN0YXRlLmZsb3dpbmcgPSBmYWxzZTtcbiAgICAgIHN0YXRlLmVtaXR0ZWRSZWFkYWJsZSA9IGZhbHNlO1xuICAgICAgZGVidWcoJ29uIHJlYWRhYmxlJywgc3RhdGUubGVuZ3RoLCBzdGF0ZS5yZWFkaW5nKTtcblxuICAgICAgaWYgKHN0YXRlLmxlbmd0aCkge1xuICAgICAgICBlbWl0UmVhZGFibGUodGhpcyk7XG4gICAgICB9IGVsc2UgaWYgKCFzdGF0ZS5yZWFkaW5nKSB7XG4gICAgICAgIHByb2Nlc3MubmV4dFRpY2soblJlYWRpbmdOZXh0VGljaywgdGhpcyk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHJlcztcbn07XG5cblJlYWRhYmxlLnByb3RvdHlwZS5hZGRMaXN0ZW5lciA9IFJlYWRhYmxlLnByb3RvdHlwZS5vbjtcblxuUmVhZGFibGUucHJvdG90eXBlLnJlbW92ZUxpc3RlbmVyID0gZnVuY3Rpb24gKGV2LCBmbikge1xuICB2YXIgcmVzID0gU3RyZWFtLnByb3RvdHlwZS5yZW1vdmVMaXN0ZW5lci5jYWxsKHRoaXMsIGV2LCBmbik7XG5cbiAgaWYgKGV2ID09PSAncmVhZGFibGUnKSB7XG4gICAgLy8gV2UgbmVlZCB0byBjaGVjayBpZiB0aGVyZSBpcyBzb21lb25lIHN0aWxsIGxpc3RlbmluZyB0b1xuICAgIC8vIHJlYWRhYmxlIGFuZCByZXNldCB0aGUgc3RhdGUuIEhvd2V2ZXIgdGhpcyBuZWVkcyB0byBoYXBwZW5cbiAgICAvLyBhZnRlciByZWFkYWJsZSBoYXMgYmVlbiBlbWl0dGVkIGJ1dCBiZWZvcmUgSS9PIChuZXh0VGljaykgdG9cbiAgICAvLyBzdXBwb3J0IG9uY2UoJ3JlYWRhYmxlJywgZm4pIGN5Y2xlcy4gVGhpcyBtZWFucyB0aGF0IGNhbGxpbmdcbiAgICAvLyByZXN1bWUgd2l0aGluIHRoZSBzYW1lIHRpY2sgd2lsbCBoYXZlIG5vXG4gICAgLy8gZWZmZWN0LlxuICAgIHByb2Nlc3MubmV4dFRpY2sodXBkYXRlUmVhZGFibGVMaXN0ZW5pbmcsIHRoaXMpO1xuICB9XG5cbiAgcmV0dXJuIHJlcztcbn07XG5cblJlYWRhYmxlLnByb3RvdHlwZS5yZW1vdmVBbGxMaXN0ZW5lcnMgPSBmdW5jdGlvbiAoZXYpIHtcbiAgdmFyIHJlcyA9IFN0cmVhbS5wcm90b3R5cGUucmVtb3ZlQWxsTGlzdGVuZXJzLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG5cbiAgaWYgKGV2ID09PSAncmVhZGFibGUnIHx8IGV2ID09PSB1bmRlZmluZWQpIHtcbiAgICAvLyBXZSBuZWVkIHRvIGNoZWNrIGlmIHRoZXJlIGlzIHNvbWVvbmUgc3RpbGwgbGlzdGVuaW5nIHRvXG4gICAgLy8gcmVhZGFibGUgYW5kIHJlc2V0IHRoZSBzdGF0ZS4gSG93ZXZlciB0aGlzIG5lZWRzIHRvIGhhcHBlblxuICAgIC8vIGFmdGVyIHJlYWRhYmxlIGhhcyBiZWVuIGVtaXR0ZWQgYnV0IGJlZm9yZSBJL08gKG5leHRUaWNrKSB0b1xuICAgIC8vIHN1cHBvcnQgb25jZSgncmVhZGFibGUnLCBmbikgY3ljbGVzLiBUaGlzIG1lYW5zIHRoYXQgY2FsbGluZ1xuICAgIC8vIHJlc3VtZSB3aXRoaW4gdGhlIHNhbWUgdGljayB3aWxsIGhhdmUgbm9cbiAgICAvLyBlZmZlY3QuXG4gICAgcHJvY2Vzcy5uZXh0VGljayh1cGRhdGVSZWFkYWJsZUxpc3RlbmluZywgdGhpcyk7XG4gIH1cblxuICByZXR1cm4gcmVzO1xufTtcblxuZnVuY3Rpb24gdXBkYXRlUmVhZGFibGVMaXN0ZW5pbmcoc2VsZikge1xuICB2YXIgc3RhdGUgPSBzZWxmLl9yZWFkYWJsZVN0YXRlO1xuICBzdGF0ZS5yZWFkYWJsZUxpc3RlbmluZyA9IHNlbGYubGlzdGVuZXJDb3VudCgncmVhZGFibGUnKSA+IDA7XG5cbiAgaWYgKHN0YXRlLnJlc3VtZVNjaGVkdWxlZCAmJiAhc3RhdGUucGF1c2VkKSB7XG4gICAgLy8gZmxvd2luZyBuZWVkcyB0byBiZSBzZXQgdG8gdHJ1ZSBub3csIG90aGVyd2lzZVxuICAgIC8vIHRoZSB1cGNvbWluZyByZXN1bWUgd2lsbCBub3QgZmxvdy5cbiAgICBzdGF0ZS5mbG93aW5nID0gdHJ1ZTsgLy8gY3J1ZGUgd2F5IHRvIGNoZWNrIGlmIHdlIHNob3VsZCByZXN1bWVcbiAgfSBlbHNlIGlmIChzZWxmLmxpc3RlbmVyQ291bnQoJ2RhdGEnKSA+IDApIHtcbiAgICBzZWxmLnJlc3VtZSgpO1xuICB9XG59XG5cbmZ1bmN0aW9uIG5SZWFkaW5nTmV4dFRpY2soc2VsZikge1xuICBkZWJ1ZygncmVhZGFibGUgbmV4dHRpY2sgcmVhZCAwJyk7XG4gIHNlbGYucmVhZCgwKTtcbn0gLy8gcGF1c2UoKSBhbmQgcmVzdW1lKCkgYXJlIHJlbW5hbnRzIG9mIHRoZSBsZWdhY3kgcmVhZGFibGUgc3RyZWFtIEFQSVxuLy8gSWYgdGhlIHVzZXIgdXNlcyB0aGVtLCB0aGVuIHN3aXRjaCBpbnRvIG9sZCBtb2RlLlxuXG5cblJlYWRhYmxlLnByb3RvdHlwZS5yZXN1bWUgPSBmdW5jdGlvbiAoKSB7XG4gIHZhciBzdGF0ZSA9IHRoaXMuX3JlYWRhYmxlU3RhdGU7XG5cbiAgaWYgKCFzdGF0ZS5mbG93aW5nKSB7XG4gICAgZGVidWcoJ3Jlc3VtZScpOyAvLyB3ZSBmbG93IG9ubHkgaWYgdGhlcmUgaXMgbm8gb25lIGxpc3RlbmluZ1xuICAgIC8vIGZvciByZWFkYWJsZSwgYnV0IHdlIHN0aWxsIGhhdmUgdG8gY2FsbFxuICAgIC8vIHJlc3VtZSgpXG5cbiAgICBzdGF0ZS5mbG93aW5nID0gIXN0YXRlLnJlYWRhYmxlTGlzdGVuaW5nO1xuICAgIHJlc3VtZSh0aGlzLCBzdGF0ZSk7XG4gIH1cblxuICBzdGF0ZS5wYXVzZWQgPSBmYWxzZTtcbiAgcmV0dXJuIHRoaXM7XG59O1xuXG5mdW5jdGlvbiByZXN1bWUoc3RyZWFtLCBzdGF0ZSkge1xuICBpZiAoIXN0YXRlLnJlc3VtZVNjaGVkdWxlZCkge1xuICAgIHN0YXRlLnJlc3VtZVNjaGVkdWxlZCA9IHRydWU7XG4gICAgcHJvY2Vzcy5uZXh0VGljayhyZXN1bWVfLCBzdHJlYW0sIHN0YXRlKTtcbiAgfVxufVxuXG5mdW5jdGlvbiByZXN1bWVfKHN0cmVhbSwgc3RhdGUpIHtcbiAgZGVidWcoJ3Jlc3VtZScsIHN0YXRlLnJlYWRpbmcpO1xuXG4gIGlmICghc3RhdGUucmVhZGluZykge1xuICAgIHN0cmVhbS5yZWFkKDApO1xuICB9XG5cbiAgc3RhdGUucmVzdW1lU2NoZWR1bGVkID0gZmFsc2U7XG4gIHN0cmVhbS5lbWl0KCdyZXN1bWUnKTtcbiAgZmxvdyhzdHJlYW0pO1xuICBpZiAoc3RhdGUuZmxvd2luZyAmJiAhc3RhdGUucmVhZGluZykgc3RyZWFtLnJlYWQoMCk7XG59XG5cblJlYWRhYmxlLnByb3RvdHlwZS5wYXVzZSA9IGZ1bmN0aW9uICgpIHtcbiAgZGVidWcoJ2NhbGwgcGF1c2UgZmxvd2luZz0laicsIHRoaXMuX3JlYWRhYmxlU3RhdGUuZmxvd2luZyk7XG5cbiAgaWYgKHRoaXMuX3JlYWRhYmxlU3RhdGUuZmxvd2luZyAhPT0gZmFsc2UpIHtcbiAgICBkZWJ1ZygncGF1c2UnKTtcbiAgICB0aGlzLl9yZWFkYWJsZVN0YXRlLmZsb3dpbmcgPSBmYWxzZTtcbiAgICB0aGlzLmVtaXQoJ3BhdXNlJyk7XG4gIH1cblxuICB0aGlzLl9yZWFkYWJsZVN0YXRlLnBhdXNlZCA9IHRydWU7XG4gIHJldHVybiB0aGlzO1xufTtcblxuZnVuY3Rpb24gZmxvdyhzdHJlYW0pIHtcbiAgdmFyIHN0YXRlID0gc3RyZWFtLl9yZWFkYWJsZVN0YXRlO1xuICBkZWJ1ZygnZmxvdycsIHN0YXRlLmZsb3dpbmcpO1xuXG4gIHdoaWxlIChzdGF0ZS5mbG93aW5nICYmIHN0cmVhbS5yZWFkKCkgIT09IG51bGwpIHtcbiAgICA7XG4gIH1cbn0gLy8gd3JhcCBhbiBvbGQtc3R5bGUgc3RyZWFtIGFzIHRoZSBhc3luYyBkYXRhIHNvdXJjZS5cbi8vIFRoaXMgaXMgKm5vdCogcGFydCBvZiB0aGUgcmVhZGFibGUgc3RyZWFtIGludGVyZmFjZS5cbi8vIEl0IGlzIGFuIHVnbHkgdW5mb3J0dW5hdGUgbWVzcyBvZiBoaXN0b3J5LlxuXG5cblJlYWRhYmxlLnByb3RvdHlwZS53cmFwID0gZnVuY3Rpb24gKHN0cmVhbSkge1xuICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gIHZhciBzdGF0ZSA9IHRoaXMuX3JlYWRhYmxlU3RhdGU7XG4gIHZhciBwYXVzZWQgPSBmYWxzZTtcbiAgc3RyZWFtLm9uKCdlbmQnLCBmdW5jdGlvbiAoKSB7XG4gICAgZGVidWcoJ3dyYXBwZWQgZW5kJyk7XG5cbiAgICBpZiAoc3RhdGUuZGVjb2RlciAmJiAhc3RhdGUuZW5kZWQpIHtcbiAgICAgIHZhciBjaHVuayA9IHN0YXRlLmRlY29kZXIuZW5kKCk7XG4gICAgICBpZiAoY2h1bmsgJiYgY2h1bmsubGVuZ3RoKSBfdGhpcy5wdXNoKGNodW5rKTtcbiAgICB9XG5cbiAgICBfdGhpcy5wdXNoKG51bGwpO1xuICB9KTtcbiAgc3RyZWFtLm9uKCdkYXRhJywgZnVuY3Rpb24gKGNodW5rKSB7XG4gICAgZGVidWcoJ3dyYXBwZWQgZGF0YScpO1xuICAgIGlmIChzdGF0ZS5kZWNvZGVyKSBjaHVuayA9IHN0YXRlLmRlY29kZXIud3JpdGUoY2h1bmspOyAvLyBkb24ndCBza2lwIG92ZXIgZmFsc3kgdmFsdWVzIGluIG9iamVjdE1vZGVcblxuICAgIGlmIChzdGF0ZS5vYmplY3RNb2RlICYmIChjaHVuayA9PT0gbnVsbCB8fCBjaHVuayA9PT0gdW5kZWZpbmVkKSkgcmV0dXJuO2Vsc2UgaWYgKCFzdGF0ZS5vYmplY3RNb2RlICYmICghY2h1bmsgfHwgIWNodW5rLmxlbmd0aCkpIHJldHVybjtcblxuICAgIHZhciByZXQgPSBfdGhpcy5wdXNoKGNodW5rKTtcblxuICAgIGlmICghcmV0KSB7XG4gICAgICBwYXVzZWQgPSB0cnVlO1xuICAgICAgc3RyZWFtLnBhdXNlKCk7XG4gICAgfVxuICB9KTsgLy8gcHJveHkgYWxsIHRoZSBvdGhlciBtZXRob2RzLlxuICAvLyBpbXBvcnRhbnQgd2hlbiB3cmFwcGluZyBmaWx0ZXJzIGFuZCBkdXBsZXhlcy5cblxuICBmb3IgKHZhciBpIGluIHN0cmVhbSkge1xuICAgIGlmICh0aGlzW2ldID09PSB1bmRlZmluZWQgJiYgdHlwZW9mIHN0cmVhbVtpXSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgdGhpc1tpXSA9IGZ1bmN0aW9uIG1ldGhvZFdyYXAobWV0aG9kKSB7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiBtZXRob2RXcmFwUmV0dXJuRnVuY3Rpb24oKSB7XG4gICAgICAgICAgcmV0dXJuIHN0cmVhbVttZXRob2RdLmFwcGx5KHN0cmVhbSwgYXJndW1lbnRzKTtcbiAgICAgICAgfTtcbiAgICAgIH0oaSk7XG4gICAgfVxuICB9IC8vIHByb3h5IGNlcnRhaW4gaW1wb3J0YW50IGV2ZW50cy5cblxuXG4gIGZvciAodmFyIG4gPSAwOyBuIDwga1Byb3h5RXZlbnRzLmxlbmd0aDsgbisrKSB7XG4gICAgc3RyZWFtLm9uKGtQcm94eUV2ZW50c1tuXSwgdGhpcy5lbWl0LmJpbmQodGhpcywga1Byb3h5RXZlbnRzW25dKSk7XG4gIH0gLy8gd2hlbiB3ZSB0cnkgdG8gY29uc3VtZSBzb21lIG1vcmUgYnl0ZXMsIHNpbXBseSB1bnBhdXNlIHRoZVxuICAvLyB1bmRlcmx5aW5nIHN0cmVhbS5cblxuXG4gIHRoaXMuX3JlYWQgPSBmdW5jdGlvbiAobikge1xuICAgIGRlYnVnKCd3cmFwcGVkIF9yZWFkJywgbik7XG5cbiAgICBpZiAocGF1c2VkKSB7XG4gICAgICBwYXVzZWQgPSBmYWxzZTtcbiAgICAgIHN0cmVhbS5yZXN1bWUoKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIHRoaXM7XG59O1xuXG5pZiAodHlwZW9mIFN5bWJvbCA9PT0gJ2Z1bmN0aW9uJykge1xuICBSZWFkYWJsZS5wcm90b3R5cGVbU3ltYm9sLmFzeW5jSXRlcmF0b3JdID0gZnVuY3Rpb24gKCkge1xuICAgIGlmIChjcmVhdGVSZWFkYWJsZVN0cmVhbUFzeW5jSXRlcmF0b3IgPT09IHVuZGVmaW5lZCkge1xuICAgICAgY3JlYXRlUmVhZGFibGVTdHJlYW1Bc3luY0l0ZXJhdG9yID0gcmVxdWlyZSgnLi9pbnRlcm5hbC9zdHJlYW1zL2FzeW5jX2l0ZXJhdG9yJyk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGNyZWF0ZVJlYWRhYmxlU3RyZWFtQXN5bmNJdGVyYXRvcih0aGlzKTtcbiAgfTtcbn1cblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KFJlYWRhYmxlLnByb3RvdHlwZSwgJ3JlYWRhYmxlSGlnaFdhdGVyTWFyaycsIHtcbiAgLy8gbWFraW5nIGl0IGV4cGxpY2l0IHRoaXMgcHJvcGVydHkgaXMgbm90IGVudW1lcmFibGVcbiAgLy8gYmVjYXVzZSBvdGhlcndpc2Ugc29tZSBwcm90b3R5cGUgbWFuaXB1bGF0aW9uIGluXG4gIC8vIHVzZXJsYW5kIHdpbGwgZmFpbFxuICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgZ2V0OiBmdW5jdGlvbiBnZXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3JlYWRhYmxlU3RhdGUuaGlnaFdhdGVyTWFyaztcbiAgfVxufSk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoUmVhZGFibGUucHJvdG90eXBlLCAncmVhZGFibGVCdWZmZXInLCB7XG4gIC8vIG1ha2luZyBpdCBleHBsaWNpdCB0aGlzIHByb3BlcnR5IGlzIG5vdCBlbnVtZXJhYmxlXG4gIC8vIGJlY2F1c2Ugb3RoZXJ3aXNlIHNvbWUgcHJvdG90eXBlIG1hbmlwdWxhdGlvbiBpblxuICAvLyB1c2VybGFuZCB3aWxsIGZhaWxcbiAgZW51bWVyYWJsZTogZmFsc2UsXG4gIGdldDogZnVuY3Rpb24gZ2V0KCkge1xuICAgIHJldHVybiB0aGlzLl9yZWFkYWJsZVN0YXRlICYmIHRoaXMuX3JlYWRhYmxlU3RhdGUuYnVmZmVyO1xuICB9XG59KTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShSZWFkYWJsZS5wcm90b3R5cGUsICdyZWFkYWJsZUZsb3dpbmcnLCB7XG4gIC8vIG1ha2luZyBpdCBleHBsaWNpdCB0aGlzIHByb3BlcnR5IGlzIG5vdCBlbnVtZXJhYmxlXG4gIC8vIGJlY2F1c2Ugb3RoZXJ3aXNlIHNvbWUgcHJvdG90eXBlIG1hbmlwdWxhdGlvbiBpblxuICAvLyB1c2VybGFuZCB3aWxsIGZhaWxcbiAgZW51bWVyYWJsZTogZmFsc2UsXG4gIGdldDogZnVuY3Rpb24gZ2V0KCkge1xuICAgIHJldHVybiB0aGlzLl9yZWFkYWJsZVN0YXRlLmZsb3dpbmc7XG4gIH0sXG4gIHNldDogZnVuY3Rpb24gc2V0KHN0YXRlKSB7XG4gICAgaWYgKHRoaXMuX3JlYWRhYmxlU3RhdGUpIHtcbiAgICAgIHRoaXMuX3JlYWRhYmxlU3RhdGUuZmxvd2luZyA9IHN0YXRlO1xuICAgIH1cbiAgfVxufSk7IC8vIGV4cG9zZWQgZm9yIHRlc3RpbmcgcHVycG9zZXMgb25seS5cblxuUmVhZGFibGUuX2Zyb21MaXN0ID0gZnJvbUxpc3Q7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoUmVhZGFibGUucHJvdG90eXBlLCAncmVhZGFibGVMZW5ndGgnLCB7XG4gIC8vIG1ha2luZyBpdCBleHBsaWNpdCB0aGlzIHByb3BlcnR5IGlzIG5vdCBlbnVtZXJhYmxlXG4gIC8vIGJlY2F1c2Ugb3RoZXJ3aXNlIHNvbWUgcHJvdG90eXBlIG1hbmlwdWxhdGlvbiBpblxuICAvLyB1c2VybGFuZCB3aWxsIGZhaWxcbiAgZW51bWVyYWJsZTogZmFsc2UsXG4gIGdldDogZnVuY3Rpb24gZ2V0KCkge1xuICAgIHJldHVybiB0aGlzLl9yZWFkYWJsZVN0YXRlLmxlbmd0aDtcbiAgfVxufSk7IC8vIFBsdWNrIG9mZiBuIGJ5dGVzIGZyb20gYW4gYXJyYXkgb2YgYnVmZmVycy5cbi8vIExlbmd0aCBpcyB0aGUgY29tYmluZWQgbGVuZ3RocyBvZiBhbGwgdGhlIGJ1ZmZlcnMgaW4gdGhlIGxpc3QuXG4vLyBUaGlzIGZ1bmN0aW9uIGlzIGRlc2lnbmVkIHRvIGJlIGlubGluYWJsZSwgc28gcGxlYXNlIHRha2UgY2FyZSB3aGVuIG1ha2luZ1xuLy8gY2hhbmdlcyB0byB0aGUgZnVuY3Rpb24gYm9keS5cblxuZnVuY3Rpb24gZnJvbUxpc3Qobiwgc3RhdGUpIHtcbiAgLy8gbm90aGluZyBidWZmZXJlZFxuICBpZiAoc3RhdGUubGVuZ3RoID09PSAwKSByZXR1cm4gbnVsbDtcbiAgdmFyIHJldDtcbiAgaWYgKHN0YXRlLm9iamVjdE1vZGUpIHJldCA9IHN0YXRlLmJ1ZmZlci5zaGlmdCgpO2Vsc2UgaWYgKCFuIHx8IG4gPj0gc3RhdGUubGVuZ3RoKSB7XG4gICAgLy8gcmVhZCBpdCBhbGwsIHRydW5jYXRlIHRoZSBsaXN0XG4gICAgaWYgKHN0YXRlLmRlY29kZXIpIHJldCA9IHN0YXRlLmJ1ZmZlci5qb2luKCcnKTtlbHNlIGlmIChzdGF0ZS5idWZmZXIubGVuZ3RoID09PSAxKSByZXQgPSBzdGF0ZS5idWZmZXIuZmlyc3QoKTtlbHNlIHJldCA9IHN0YXRlLmJ1ZmZlci5jb25jYXQoc3RhdGUubGVuZ3RoKTtcbiAgICBzdGF0ZS5idWZmZXIuY2xlYXIoKTtcbiAgfSBlbHNlIHtcbiAgICAvLyByZWFkIHBhcnQgb2YgbGlzdFxuICAgIHJldCA9IHN0YXRlLmJ1ZmZlci5jb25zdW1lKG4sIHN0YXRlLmRlY29kZXIpO1xuICB9XG4gIHJldHVybiByZXQ7XG59XG5cbmZ1bmN0aW9uIGVuZFJlYWRhYmxlKHN0cmVhbSkge1xuICB2YXIgc3RhdGUgPSBzdHJlYW0uX3JlYWRhYmxlU3RhdGU7XG4gIGRlYnVnKCdlbmRSZWFkYWJsZScsIHN0YXRlLmVuZEVtaXR0ZWQpO1xuXG4gIGlmICghc3RhdGUuZW5kRW1pdHRlZCkge1xuICAgIHN0YXRlLmVuZGVkID0gdHJ1ZTtcbiAgICBwcm9jZXNzLm5leHRUaWNrKGVuZFJlYWRhYmxlTlQsIHN0YXRlLCBzdHJlYW0pO1xuICB9XG59XG5cbmZ1bmN0aW9uIGVuZFJlYWRhYmxlTlQoc3RhdGUsIHN0cmVhbSkge1xuICBkZWJ1ZygnZW5kUmVhZGFibGVOVCcsIHN0YXRlLmVuZEVtaXR0ZWQsIHN0YXRlLmxlbmd0aCk7IC8vIENoZWNrIHRoYXQgd2UgZGlkbid0IGdldCBvbmUgbGFzdCB1bnNoaWZ0LlxuXG4gIGlmICghc3RhdGUuZW5kRW1pdHRlZCAmJiBzdGF0ZS5sZW5ndGggPT09IDApIHtcbiAgICBzdGF0ZS5lbmRFbWl0dGVkID0gdHJ1ZTtcbiAgICBzdHJlYW0ucmVhZGFibGUgPSBmYWxzZTtcbiAgICBzdHJlYW0uZW1pdCgnZW5kJyk7XG5cbiAgICBpZiAoc3RhdGUuYXV0b0Rlc3Ryb3kpIHtcbiAgICAgIC8vIEluIGNhc2Ugb2YgZHVwbGV4IHN0cmVhbXMgd2UgbmVlZCBhIHdheSB0byBkZXRlY3RcbiAgICAgIC8vIGlmIHRoZSB3cml0YWJsZSBzaWRlIGlzIHJlYWR5IGZvciBhdXRvRGVzdHJveSBhcyB3ZWxsXG4gICAgICB2YXIgd1N0YXRlID0gc3RyZWFtLl93cml0YWJsZVN0YXRlO1xuXG4gICAgICBpZiAoIXdTdGF0ZSB8fCB3U3RhdGUuYXV0b0Rlc3Ryb3kgJiYgd1N0YXRlLmZpbmlzaGVkKSB7XG4gICAgICAgIHN0cmVhbS5kZXN0cm95KCk7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbmlmICh0eXBlb2YgU3ltYm9sID09PSAnZnVuY3Rpb24nKSB7XG4gIFJlYWRhYmxlLmZyb20gPSBmdW5jdGlvbiAoaXRlcmFibGUsIG9wdHMpIHtcbiAgICBpZiAoZnJvbSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICBmcm9tID0gcmVxdWlyZSgnLi9pbnRlcm5hbC9zdHJlYW1zL2Zyb20nKTtcbiAgICB9XG5cbiAgICByZXR1cm4gZnJvbShSZWFkYWJsZSwgaXRlcmFibGUsIG9wdHMpO1xuICB9O1xufVxuXG5mdW5jdGlvbiBpbmRleE9mKHhzLCB4KSB7XG4gIGZvciAodmFyIGkgPSAwLCBsID0geHMubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG4gICAgaWYgKHhzW2ldID09PSB4KSByZXR1cm4gaTtcbiAgfVxuXG4gIHJldHVybiAtMTtcbn0iLCIvLyBDb3B5cmlnaHQgSm95ZW50LCBJbmMuIGFuZCBvdGhlciBOb2RlIGNvbnRyaWJ1dG9ycy5cbi8vXG4vLyBQZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYVxuLy8gY29weSBvZiB0aGlzIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZVxuLy8gXCJTb2Z0d2FyZVwiKSwgdG8gZGVhbCBpbiB0aGUgU29mdHdhcmUgd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nXG4vLyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsXG4vLyBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0XG4vLyBwZXJzb25zIHRvIHdob20gdGhlIFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0byB0aGVcbi8vIGZvbGxvd2luZyBjb25kaXRpb25zOlxuLy9cbi8vIFRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIHNoYWxsIGJlIGluY2x1ZGVkXG4vLyBpbiBhbGwgY29waWVzIG9yIHN1YnN0YW50aWFsIHBvcnRpb25zIG9mIHRoZSBTb2Z0d2FyZS5cbi8vXG4vLyBUSEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTXG4vLyBPUiBJTVBMSUVELCBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GXG4vLyBNRVJDSEFOVEFCSUxJVFksIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuIElOXG4vLyBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFQgSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSxcbi8vIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSIElOIEFOIEFDVElPTiBPRiBDT05UUkFDVCwgVE9SVCBPUlxuLy8gT1RIRVJXSVNFLCBBUklTSU5HIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFIFNPRlRXQVJFIE9SIFRIRVxuLy8gVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cbi8vIGEgdHJhbnNmb3JtIHN0cmVhbSBpcyBhIHJlYWRhYmxlL3dyaXRhYmxlIHN0cmVhbSB3aGVyZSB5b3UgZG9cbi8vIHNvbWV0aGluZyB3aXRoIHRoZSBkYXRhLiAgU29tZXRpbWVzIGl0J3MgY2FsbGVkIGEgXCJmaWx0ZXJcIixcbi8vIGJ1dCB0aGF0J3Mgbm90IGEgZ3JlYXQgbmFtZSBmb3IgaXQsIHNpbmNlIHRoYXQgaW1wbGllcyBhIHRoaW5nIHdoZXJlXG4vLyBzb21lIGJpdHMgcGFzcyB0aHJvdWdoLCBhbmQgb3RoZXJzIGFyZSBzaW1wbHkgaWdub3JlZC4gIChUaGF0IHdvdWxkXG4vLyBiZSBhIHZhbGlkIGV4YW1wbGUgb2YgYSB0cmFuc2Zvcm0sIG9mIGNvdXJzZS4pXG4vL1xuLy8gV2hpbGUgdGhlIG91dHB1dCBpcyBjYXVzYWxseSByZWxhdGVkIHRvIHRoZSBpbnB1dCwgaXQncyBub3QgYVxuLy8gbmVjZXNzYXJpbHkgc3ltbWV0cmljIG9yIHN5bmNocm9ub3VzIHRyYW5zZm9ybWF0aW9uLiAgRm9yIGV4YW1wbGUsXG4vLyBhIHpsaWIgc3RyZWFtIG1pZ2h0IHRha2UgbXVsdGlwbGUgcGxhaW4tdGV4dCB3cml0ZXMoKSwgYW5kIHRoZW5cbi8vIGVtaXQgYSBzaW5nbGUgY29tcHJlc3NlZCBjaHVuayBzb21lIHRpbWUgaW4gdGhlIGZ1dHVyZS5cbi8vXG4vLyBIZXJlJ3MgaG93IHRoaXMgd29ya3M6XG4vL1xuLy8gVGhlIFRyYW5zZm9ybSBzdHJlYW0gaGFzIGFsbCB0aGUgYXNwZWN0cyBvZiB0aGUgcmVhZGFibGUgYW5kIHdyaXRhYmxlXG4vLyBzdHJlYW0gY2xhc3Nlcy4gIFdoZW4geW91IHdyaXRlKGNodW5rKSwgdGhhdCBjYWxscyBfd3JpdGUoY2h1bmssY2IpXG4vLyBpbnRlcm5hbGx5LCBhbmQgcmV0dXJucyBmYWxzZSBpZiB0aGVyZSdzIGEgbG90IG9mIHBlbmRpbmcgd3JpdGVzXG4vLyBidWZmZXJlZCB1cC4gIFdoZW4geW91IGNhbGwgcmVhZCgpLCB0aGF0IGNhbGxzIF9yZWFkKG4pIHVudGlsXG4vLyB0aGVyZSdzIGVub3VnaCBwZW5kaW5nIHJlYWRhYmxlIGRhdGEgYnVmZmVyZWQgdXAuXG4vL1xuLy8gSW4gYSB0cmFuc2Zvcm0gc3RyZWFtLCB0aGUgd3JpdHRlbiBkYXRhIGlzIHBsYWNlZCBpbiBhIGJ1ZmZlci4gIFdoZW5cbi8vIF9yZWFkKG4pIGlzIGNhbGxlZCwgaXQgdHJhbnNmb3JtcyB0aGUgcXVldWVkIHVwIGRhdGEsIGNhbGxpbmcgdGhlXG4vLyBidWZmZXJlZCBfd3JpdGUgY2IncyBhcyBpdCBjb25zdW1lcyBjaHVua3MuICBJZiBjb25zdW1pbmcgYSBzaW5nbGVcbi8vIHdyaXR0ZW4gY2h1bmsgd291bGQgcmVzdWx0IGluIG11bHRpcGxlIG91dHB1dCBjaHVua3MsIHRoZW4gdGhlIGZpcnN0XG4vLyBvdXRwdXR0ZWQgYml0IGNhbGxzIHRoZSByZWFkY2IsIGFuZCBzdWJzZXF1ZW50IGNodW5rcyBqdXN0IGdvIGludG9cbi8vIHRoZSByZWFkIGJ1ZmZlciwgYW5kIHdpbGwgY2F1c2UgaXQgdG8gZW1pdCAncmVhZGFibGUnIGlmIG5lY2Vzc2FyeS5cbi8vXG4vLyBUaGlzIHdheSwgYmFjay1wcmVzc3VyZSBpcyBhY3R1YWxseSBkZXRlcm1pbmVkIGJ5IHRoZSByZWFkaW5nIHNpZGUsXG4vLyBzaW5jZSBfcmVhZCBoYXMgdG8gYmUgY2FsbGVkIHRvIHN0YXJ0IHByb2Nlc3NpbmcgYSBuZXcgY2h1bmsuICBIb3dldmVyLFxuLy8gYSBwYXRob2xvZ2ljYWwgaW5mbGF0ZSB0eXBlIG9mIHRyYW5zZm9ybSBjYW4gY2F1c2UgZXhjZXNzaXZlIGJ1ZmZlcmluZ1xuLy8gaGVyZS4gIEZvciBleGFtcGxlLCBpbWFnaW5lIGEgc3RyZWFtIHdoZXJlIGV2ZXJ5IGJ5dGUgb2YgaW5wdXQgaXNcbi8vIGludGVycHJldGVkIGFzIGFuIGludGVnZXIgZnJvbSAwLTI1NSwgYW5kIHRoZW4gcmVzdWx0cyBpbiB0aGF0IG1hbnlcbi8vIGJ5dGVzIG9mIG91dHB1dC4gIFdyaXRpbmcgdGhlIDQgYnl0ZXMge2ZmLGZmLGZmLGZmfSB3b3VsZCByZXN1bHQgaW5cbi8vIDFrYiBvZiBkYXRhIGJlaW5nIG91dHB1dC4gIEluIHRoaXMgY2FzZSwgeW91IGNvdWxkIHdyaXRlIGEgdmVyeSBzbWFsbFxuLy8gYW1vdW50IG9mIGlucHV0LCBhbmQgZW5kIHVwIHdpdGggYSB2ZXJ5IGxhcmdlIGFtb3VudCBvZiBvdXRwdXQuICBJblxuLy8gc3VjaCBhIHBhdGhvbG9naWNhbCBpbmZsYXRpbmcgbWVjaGFuaXNtLCB0aGVyZSdkIGJlIG5vIHdheSB0byB0ZWxsXG4vLyB0aGUgc3lzdGVtIHRvIHN0b3AgZG9pbmcgdGhlIHRyYW5zZm9ybS4gIEEgc2luZ2xlIDRNQiB3cml0ZSBjb3VsZFxuLy8gY2F1c2UgdGhlIHN5c3RlbSB0byBydW4gb3V0IG9mIG1lbW9yeS5cbi8vXG4vLyBIb3dldmVyLCBldmVuIGluIHN1Y2ggYSBwYXRob2xvZ2ljYWwgY2FzZSwgb25seSBhIHNpbmdsZSB3cml0dGVuIGNodW5rXG4vLyB3b3VsZCBiZSBjb25zdW1lZCwgYW5kIHRoZW4gdGhlIHJlc3Qgd291bGQgd2FpdCAodW4tdHJhbnNmb3JtZWQpIHVudGlsXG4vLyB0aGUgcmVzdWx0cyBvZiB0aGUgcHJldmlvdXMgdHJhbnNmb3JtZWQgY2h1bmsgd2VyZSBjb25zdW1lZC5cbid1c2Ugc3RyaWN0JztcblxubW9kdWxlLmV4cG9ydHMgPSBUcmFuc2Zvcm07XG5cbnZhciBfcmVxdWlyZSRjb2RlcyA9IHJlcXVpcmUoJy4uL2Vycm9ycycpLmNvZGVzLFxuICAgIEVSUl9NRVRIT0RfTk9UX0lNUExFTUVOVEVEID0gX3JlcXVpcmUkY29kZXMuRVJSX01FVEhPRF9OT1RfSU1QTEVNRU5URUQsXG4gICAgRVJSX01VTFRJUExFX0NBTExCQUNLID0gX3JlcXVpcmUkY29kZXMuRVJSX01VTFRJUExFX0NBTExCQUNLLFxuICAgIEVSUl9UUkFOU0ZPUk1fQUxSRUFEWV9UUkFOU0ZPUk1JTkcgPSBfcmVxdWlyZSRjb2Rlcy5FUlJfVFJBTlNGT1JNX0FMUkVBRFlfVFJBTlNGT1JNSU5HLFxuICAgIEVSUl9UUkFOU0ZPUk1fV0lUSF9MRU5HVEhfMCA9IF9yZXF1aXJlJGNvZGVzLkVSUl9UUkFOU0ZPUk1fV0lUSF9MRU5HVEhfMDtcblxudmFyIER1cGxleCA9IHJlcXVpcmUoJy4vX3N0cmVhbV9kdXBsZXgnKTtcblxucmVxdWlyZSgnaW5oZXJpdHMnKShUcmFuc2Zvcm0sIER1cGxleCk7XG5cbmZ1bmN0aW9uIGFmdGVyVHJhbnNmb3JtKGVyLCBkYXRhKSB7XG4gIHZhciB0cyA9IHRoaXMuX3RyYW5zZm9ybVN0YXRlO1xuICB0cy50cmFuc2Zvcm1pbmcgPSBmYWxzZTtcbiAgdmFyIGNiID0gdHMud3JpdGVjYjtcblxuICBpZiAoY2IgPT09IG51bGwpIHtcbiAgICByZXR1cm4gdGhpcy5lbWl0KCdlcnJvcicsIG5ldyBFUlJfTVVMVElQTEVfQ0FMTEJBQ0soKSk7XG4gIH1cblxuICB0cy53cml0ZWNodW5rID0gbnVsbDtcbiAgdHMud3JpdGVjYiA9IG51bGw7XG4gIGlmIChkYXRhICE9IG51bGwpIC8vIHNpbmdsZSBlcXVhbHMgY2hlY2sgZm9yIGJvdGggYG51bGxgIGFuZCBgdW5kZWZpbmVkYFxuICAgIHRoaXMucHVzaChkYXRhKTtcbiAgY2IoZXIpO1xuICB2YXIgcnMgPSB0aGlzLl9yZWFkYWJsZVN0YXRlO1xuICBycy5yZWFkaW5nID0gZmFsc2U7XG5cbiAgaWYgKHJzLm5lZWRSZWFkYWJsZSB8fCBycy5sZW5ndGggPCBycy5oaWdoV2F0ZXJNYXJrKSB7XG4gICAgdGhpcy5fcmVhZChycy5oaWdoV2F0ZXJNYXJrKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBUcmFuc2Zvcm0ob3B0aW9ucykge1xuICBpZiAoISh0aGlzIGluc3RhbmNlb2YgVHJhbnNmb3JtKSkgcmV0dXJuIG5ldyBUcmFuc2Zvcm0ob3B0aW9ucyk7XG4gIER1cGxleC5jYWxsKHRoaXMsIG9wdGlvbnMpO1xuICB0aGlzLl90cmFuc2Zvcm1TdGF0ZSA9IHtcbiAgICBhZnRlclRyYW5zZm9ybTogYWZ0ZXJUcmFuc2Zvcm0uYmluZCh0aGlzKSxcbiAgICBuZWVkVHJhbnNmb3JtOiBmYWxzZSxcbiAgICB0cmFuc2Zvcm1pbmc6IGZhbHNlLFxuICAgIHdyaXRlY2I6IG51bGwsXG4gICAgd3JpdGVjaHVuazogbnVsbCxcbiAgICB3cml0ZWVuY29kaW5nOiBudWxsXG4gIH07IC8vIHN0YXJ0IG91dCBhc2tpbmcgZm9yIGEgcmVhZGFibGUgZXZlbnQgb25jZSBkYXRhIGlzIHRyYW5zZm9ybWVkLlxuXG4gIHRoaXMuX3JlYWRhYmxlU3RhdGUubmVlZFJlYWRhYmxlID0gdHJ1ZTsgLy8gd2UgaGF2ZSBpbXBsZW1lbnRlZCB0aGUgX3JlYWQgbWV0aG9kLCBhbmQgZG9uZSB0aGUgb3RoZXIgdGhpbmdzXG4gIC8vIHRoYXQgUmVhZGFibGUgd2FudHMgYmVmb3JlIHRoZSBmaXJzdCBfcmVhZCBjYWxsLCBzbyB1bnNldCB0aGVcbiAgLy8gc3luYyBndWFyZCBmbGFnLlxuXG4gIHRoaXMuX3JlYWRhYmxlU3RhdGUuc3luYyA9IGZhbHNlO1xuXG4gIGlmIChvcHRpb25zKSB7XG4gICAgaWYgKHR5cGVvZiBvcHRpb25zLnRyYW5zZm9ybSA9PT0gJ2Z1bmN0aW9uJykgdGhpcy5fdHJhbnNmb3JtID0gb3B0aW9ucy50cmFuc2Zvcm07XG4gICAgaWYgKHR5cGVvZiBvcHRpb25zLmZsdXNoID09PSAnZnVuY3Rpb24nKSB0aGlzLl9mbHVzaCA9IG9wdGlvbnMuZmx1c2g7XG4gIH0gLy8gV2hlbiB0aGUgd3JpdGFibGUgc2lkZSBmaW5pc2hlcywgdGhlbiBmbHVzaCBvdXQgYW55dGhpbmcgcmVtYWluaW5nLlxuXG5cbiAgdGhpcy5vbigncHJlZmluaXNoJywgcHJlZmluaXNoKTtcbn1cblxuZnVuY3Rpb24gcHJlZmluaXNoKCkge1xuICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gIGlmICh0eXBlb2YgdGhpcy5fZmx1c2ggPT09ICdmdW5jdGlvbicgJiYgIXRoaXMuX3JlYWRhYmxlU3RhdGUuZGVzdHJveWVkKSB7XG4gICAgdGhpcy5fZmx1c2goZnVuY3Rpb24gKGVyLCBkYXRhKSB7XG4gICAgICBkb25lKF90aGlzLCBlciwgZGF0YSk7XG4gICAgfSk7XG4gIH0gZWxzZSB7XG4gICAgZG9uZSh0aGlzLCBudWxsLCBudWxsKTtcbiAgfVxufVxuXG5UcmFuc2Zvcm0ucHJvdG90eXBlLnB1c2ggPSBmdW5jdGlvbiAoY2h1bmssIGVuY29kaW5nKSB7XG4gIHRoaXMuX3RyYW5zZm9ybVN0YXRlLm5lZWRUcmFuc2Zvcm0gPSBmYWxzZTtcbiAgcmV0dXJuIER1cGxleC5wcm90b3R5cGUucHVzaC5jYWxsKHRoaXMsIGNodW5rLCBlbmNvZGluZyk7XG59OyAvLyBUaGlzIGlzIHRoZSBwYXJ0IHdoZXJlIHlvdSBkbyBzdHVmZiFcbi8vIG92ZXJyaWRlIHRoaXMgZnVuY3Rpb24gaW4gaW1wbGVtZW50YXRpb24gY2xhc3Nlcy5cbi8vICdjaHVuaycgaXMgYW4gaW5wdXQgY2h1bmsuXG4vL1xuLy8gQ2FsbCBgcHVzaChuZXdDaHVuaylgIHRvIHBhc3MgYWxvbmcgdHJhbnNmb3JtZWQgb3V0cHV0XG4vLyB0byB0aGUgcmVhZGFibGUgc2lkZS4gIFlvdSBtYXkgY2FsbCAncHVzaCcgemVybyBvciBtb3JlIHRpbWVzLlxuLy9cbi8vIENhbGwgYGNiKGVycilgIHdoZW4geW91IGFyZSBkb25lIHdpdGggdGhpcyBjaHVuay4gIElmIHlvdSBwYXNzXG4vLyBhbiBlcnJvciwgdGhlbiB0aGF0J2xsIHB1dCB0aGUgaHVydCBvbiB0aGUgd2hvbGUgb3BlcmF0aW9uLiAgSWYgeW91XG4vLyBuZXZlciBjYWxsIGNiKCksIHRoZW4geW91J2xsIG5ldmVyIGdldCBhbm90aGVyIGNodW5rLlxuXG5cblRyYW5zZm9ybS5wcm90b3R5cGUuX3RyYW5zZm9ybSA9IGZ1bmN0aW9uIChjaHVuaywgZW5jb2RpbmcsIGNiKSB7XG4gIGNiKG5ldyBFUlJfTUVUSE9EX05PVF9JTVBMRU1FTlRFRCgnX3RyYW5zZm9ybSgpJykpO1xufTtcblxuVHJhbnNmb3JtLnByb3RvdHlwZS5fd3JpdGUgPSBmdW5jdGlvbiAoY2h1bmssIGVuY29kaW5nLCBjYikge1xuICB2YXIgdHMgPSB0aGlzLl90cmFuc2Zvcm1TdGF0ZTtcbiAgdHMud3JpdGVjYiA9IGNiO1xuICB0cy53cml0ZWNodW5rID0gY2h1bms7XG4gIHRzLndyaXRlZW5jb2RpbmcgPSBlbmNvZGluZztcblxuICBpZiAoIXRzLnRyYW5zZm9ybWluZykge1xuICAgIHZhciBycyA9IHRoaXMuX3JlYWRhYmxlU3RhdGU7XG4gICAgaWYgKHRzLm5lZWRUcmFuc2Zvcm0gfHwgcnMubmVlZFJlYWRhYmxlIHx8IHJzLmxlbmd0aCA8IHJzLmhpZ2hXYXRlck1hcmspIHRoaXMuX3JlYWQocnMuaGlnaFdhdGVyTWFyayk7XG4gIH1cbn07IC8vIERvZXNuJ3QgbWF0dGVyIHdoYXQgdGhlIGFyZ3MgYXJlIGhlcmUuXG4vLyBfdHJhbnNmb3JtIGRvZXMgYWxsIHRoZSB3b3JrLlxuLy8gVGhhdCB3ZSBnb3QgaGVyZSBtZWFucyB0aGF0IHRoZSByZWFkYWJsZSBzaWRlIHdhbnRzIG1vcmUgZGF0YS5cblxuXG5UcmFuc2Zvcm0ucHJvdG90eXBlLl9yZWFkID0gZnVuY3Rpb24gKG4pIHtcbiAgdmFyIHRzID0gdGhpcy5fdHJhbnNmb3JtU3RhdGU7XG5cbiAgaWYgKHRzLndyaXRlY2h1bmsgIT09IG51bGwgJiYgIXRzLnRyYW5zZm9ybWluZykge1xuICAgIHRzLnRyYW5zZm9ybWluZyA9IHRydWU7XG5cbiAgICB0aGlzLl90cmFuc2Zvcm0odHMud3JpdGVjaHVuaywgdHMud3JpdGVlbmNvZGluZywgdHMuYWZ0ZXJUcmFuc2Zvcm0pO1xuICB9IGVsc2Uge1xuICAgIC8vIG1hcmsgdGhhdCB3ZSBuZWVkIGEgdHJhbnNmb3JtLCBzbyB0aGF0IGFueSBkYXRhIHRoYXQgY29tZXMgaW5cbiAgICAvLyB3aWxsIGdldCBwcm9jZXNzZWQsIG5vdyB0aGF0IHdlJ3ZlIGFza2VkIGZvciBpdC5cbiAgICB0cy5uZWVkVHJhbnNmb3JtID0gdHJ1ZTtcbiAgfVxufTtcblxuVHJhbnNmb3JtLnByb3RvdHlwZS5fZGVzdHJveSA9IGZ1bmN0aW9uIChlcnIsIGNiKSB7XG4gIER1cGxleC5wcm90b3R5cGUuX2Rlc3Ryb3kuY2FsbCh0aGlzLCBlcnIsIGZ1bmN0aW9uIChlcnIyKSB7XG4gICAgY2IoZXJyMik7XG4gIH0pO1xufTtcblxuZnVuY3Rpb24gZG9uZShzdHJlYW0sIGVyLCBkYXRhKSB7XG4gIGlmIChlcikgcmV0dXJuIHN0cmVhbS5lbWl0KCdlcnJvcicsIGVyKTtcbiAgaWYgKGRhdGEgIT0gbnVsbCkgLy8gc2luZ2xlIGVxdWFscyBjaGVjayBmb3IgYm90aCBgbnVsbGAgYW5kIGB1bmRlZmluZWRgXG4gICAgc3RyZWFtLnB1c2goZGF0YSk7IC8vIFRPRE8oQnJpZGdlQVIpOiBXcml0ZSBhIHRlc3QgZm9yIHRoZXNlIHR3byBlcnJvciBjYXNlc1xuICAvLyBpZiB0aGVyZSdzIG5vdGhpbmcgaW4gdGhlIHdyaXRlIGJ1ZmZlciwgdGhlbiB0aGF0IG1lYW5zXG4gIC8vIHRoYXQgbm90aGluZyBtb3JlIHdpbGwgZXZlciBiZSBwcm92aWRlZFxuXG4gIGlmIChzdHJlYW0uX3dyaXRhYmxlU3RhdGUubGVuZ3RoKSB0aHJvdyBuZXcgRVJSX1RSQU5TRk9STV9XSVRIX0xFTkdUSF8wKCk7XG4gIGlmIChzdHJlYW0uX3RyYW5zZm9ybVN0YXRlLnRyYW5zZm9ybWluZykgdGhyb3cgbmV3IEVSUl9UUkFOU0ZPUk1fQUxSRUFEWV9UUkFOU0ZPUk1JTkcoKTtcbiAgcmV0dXJuIHN0cmVhbS5wdXNoKG51bGwpO1xufSIsIi8vIENvcHlyaWdodCBKb3llbnQsIEluYy4gYW5kIG90aGVyIE5vZGUgY29udHJpYnV0b3JzLlxuLy9cbi8vIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhXG4vLyBjb3B5IG9mIHRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlXG4vLyBcIlNvZnR3YXJlXCIpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZSB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmdcbi8vIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBtZXJnZSwgcHVibGlzaCxcbi8vIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0byBwZXJtaXRcbi8vIHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLCBzdWJqZWN0IHRvIHRoZVxuLy8gZm9sbG93aW5nIGNvbmRpdGlvbnM6XG4vL1xuLy8gVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWRcbi8vIGluIGFsbCBjb3BpZXMgb3Igc3Vic3RhbnRpYWwgcG9ydGlvbnMgb2YgdGhlIFNvZnR3YXJlLlxuLy9cbi8vIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIsIFdJVEhPVVQgV0FSUkFOVFkgT0YgQU5ZIEtJTkQsIEVYUFJFU1Ncbi8vIE9SIElNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0Zcbi8vIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EIE5PTklORlJJTkdFTUVOVC4gSU5cbi8vIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1JTIE9SIENPUFlSSUdIVCBIT0xERVJTIEJFIExJQUJMRSBGT1IgQU5ZIENMQUlNLFxuLy8gREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULCBUT1JUIE9SXG4vLyBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT04gV0lUSCBUSEUgU09GVFdBUkUgT1IgVEhFXG4vLyBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuLy8gQSBiaXQgc2ltcGxlciB0aGFuIHJlYWRhYmxlIHN0cmVhbXMuXG4vLyBJbXBsZW1lbnQgYW4gYXN5bmMgLl93cml0ZShjaHVuaywgZW5jb2RpbmcsIGNiKSwgYW5kIGl0J2xsIGhhbmRsZSBhbGxcbi8vIHRoZSBkcmFpbiBldmVudCBlbWlzc2lvbiBhbmQgYnVmZmVyaW5nLlxuJ3VzZSBzdHJpY3QnO1xuXG5tb2R1bGUuZXhwb3J0cyA9IFdyaXRhYmxlO1xuLyogPHJlcGxhY2VtZW50PiAqL1xuXG5mdW5jdGlvbiBXcml0ZVJlcShjaHVuaywgZW5jb2RpbmcsIGNiKSB7XG4gIHRoaXMuY2h1bmsgPSBjaHVuaztcbiAgdGhpcy5lbmNvZGluZyA9IGVuY29kaW5nO1xuICB0aGlzLmNhbGxiYWNrID0gY2I7XG4gIHRoaXMubmV4dCA9IG51bGw7XG59IC8vIEl0IHNlZW1zIGEgbGlua2VkIGxpc3QgYnV0IGl0IGlzIG5vdFxuLy8gdGhlcmUgd2lsbCBiZSBvbmx5IDIgb2YgdGhlc2UgZm9yIGVhY2ggc3RyZWFtXG5cblxuZnVuY3Rpb24gQ29ya2VkUmVxdWVzdChzdGF0ZSkge1xuICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gIHRoaXMubmV4dCA9IG51bGw7XG4gIHRoaXMuZW50cnkgPSBudWxsO1xuXG4gIHRoaXMuZmluaXNoID0gZnVuY3Rpb24gKCkge1xuICAgIG9uQ29ya2VkRmluaXNoKF90aGlzLCBzdGF0ZSk7XG4gIH07XG59XG4vKiA8L3JlcGxhY2VtZW50PiAqL1xuXG4vKjxyZXBsYWNlbWVudD4qL1xuXG5cbnZhciBEdXBsZXg7XG4vKjwvcmVwbGFjZW1lbnQ+Ki9cblxuV3JpdGFibGUuV3JpdGFibGVTdGF0ZSA9IFdyaXRhYmxlU3RhdGU7XG4vKjxyZXBsYWNlbWVudD4qL1xuXG52YXIgaW50ZXJuYWxVdGlsID0ge1xuICBkZXByZWNhdGU6IHJlcXVpcmUoJ3V0aWwtZGVwcmVjYXRlJylcbn07XG4vKjwvcmVwbGFjZW1lbnQ+Ki9cblxuLyo8cmVwbGFjZW1lbnQ+Ki9cblxudmFyIFN0cmVhbSA9IHJlcXVpcmUoJy4vaW50ZXJuYWwvc3RyZWFtcy9zdHJlYW0nKTtcbi8qPC9yZXBsYWNlbWVudD4qL1xuXG5cbnZhciBCdWZmZXIgPSByZXF1aXJlKCdidWZmZXInKS5CdWZmZXI7XG5cbnZhciBPdXJVaW50OEFycmF5ID0gZ2xvYmFsLlVpbnQ4QXJyYXkgfHwgZnVuY3Rpb24gKCkge307XG5cbmZ1bmN0aW9uIF91aW50OEFycmF5VG9CdWZmZXIoY2h1bmspIHtcbiAgcmV0dXJuIEJ1ZmZlci5mcm9tKGNodW5rKTtcbn1cblxuZnVuY3Rpb24gX2lzVWludDhBcnJheShvYmopIHtcbiAgcmV0dXJuIEJ1ZmZlci5pc0J1ZmZlcihvYmopIHx8IG9iaiBpbnN0YW5jZW9mIE91clVpbnQ4QXJyYXk7XG59XG5cbnZhciBkZXN0cm95SW1wbCA9IHJlcXVpcmUoJy4vaW50ZXJuYWwvc3RyZWFtcy9kZXN0cm95Jyk7XG5cbnZhciBfcmVxdWlyZSA9IHJlcXVpcmUoJy4vaW50ZXJuYWwvc3RyZWFtcy9zdGF0ZScpLFxuICAgIGdldEhpZ2hXYXRlck1hcmsgPSBfcmVxdWlyZS5nZXRIaWdoV2F0ZXJNYXJrO1xuXG52YXIgX3JlcXVpcmUkY29kZXMgPSByZXF1aXJlKCcuLi9lcnJvcnMnKS5jb2RlcyxcbiAgICBFUlJfSU5WQUxJRF9BUkdfVFlQRSA9IF9yZXF1aXJlJGNvZGVzLkVSUl9JTlZBTElEX0FSR19UWVBFLFxuICAgIEVSUl9NRVRIT0RfTk9UX0lNUExFTUVOVEVEID0gX3JlcXVpcmUkY29kZXMuRVJSX01FVEhPRF9OT1RfSU1QTEVNRU5URUQsXG4gICAgRVJSX01VTFRJUExFX0NBTExCQUNLID0gX3JlcXVpcmUkY29kZXMuRVJSX01VTFRJUExFX0NBTExCQUNLLFxuICAgIEVSUl9TVFJFQU1fQ0FOTk9UX1BJUEUgPSBfcmVxdWlyZSRjb2Rlcy5FUlJfU1RSRUFNX0NBTk5PVF9QSVBFLFxuICAgIEVSUl9TVFJFQU1fREVTVFJPWUVEID0gX3JlcXVpcmUkY29kZXMuRVJSX1NUUkVBTV9ERVNUUk9ZRUQsXG4gICAgRVJSX1NUUkVBTV9OVUxMX1ZBTFVFUyA9IF9yZXF1aXJlJGNvZGVzLkVSUl9TVFJFQU1fTlVMTF9WQUxVRVMsXG4gICAgRVJSX1NUUkVBTV9XUklURV9BRlRFUl9FTkQgPSBfcmVxdWlyZSRjb2Rlcy5FUlJfU1RSRUFNX1dSSVRFX0FGVEVSX0VORCxcbiAgICBFUlJfVU5LTk9XTl9FTkNPRElORyA9IF9yZXF1aXJlJGNvZGVzLkVSUl9VTktOT1dOX0VOQ09ESU5HO1xuXG52YXIgZXJyb3JPckRlc3Ryb3kgPSBkZXN0cm95SW1wbC5lcnJvck9yRGVzdHJveTtcblxucmVxdWlyZSgnaW5oZXJpdHMnKShXcml0YWJsZSwgU3RyZWFtKTtcblxuZnVuY3Rpb24gbm9wKCkge31cblxuZnVuY3Rpb24gV3JpdGFibGVTdGF0ZShvcHRpb25zLCBzdHJlYW0sIGlzRHVwbGV4KSB7XG4gIER1cGxleCA9IER1cGxleCB8fCByZXF1aXJlKCcuL19zdHJlYW1fZHVwbGV4Jyk7XG4gIG9wdGlvbnMgPSBvcHRpb25zIHx8IHt9OyAvLyBEdXBsZXggc3RyZWFtcyBhcmUgYm90aCByZWFkYWJsZSBhbmQgd3JpdGFibGUsIGJ1dCBzaGFyZVxuICAvLyB0aGUgc2FtZSBvcHRpb25zIG9iamVjdC5cbiAgLy8gSG93ZXZlciwgc29tZSBjYXNlcyByZXF1aXJlIHNldHRpbmcgb3B0aW9ucyB0byBkaWZmZXJlbnRcbiAgLy8gdmFsdWVzIGZvciB0aGUgcmVhZGFibGUgYW5kIHRoZSB3cml0YWJsZSBzaWRlcyBvZiB0aGUgZHVwbGV4IHN0cmVhbSxcbiAgLy8gZS5nLiBvcHRpb25zLnJlYWRhYmxlT2JqZWN0TW9kZSB2cy4gb3B0aW9ucy53cml0YWJsZU9iamVjdE1vZGUsIGV0Yy5cblxuICBpZiAodHlwZW9mIGlzRHVwbGV4ICE9PSAnYm9vbGVhbicpIGlzRHVwbGV4ID0gc3RyZWFtIGluc3RhbmNlb2YgRHVwbGV4OyAvLyBvYmplY3Qgc3RyZWFtIGZsYWcgdG8gaW5kaWNhdGUgd2hldGhlciBvciBub3QgdGhpcyBzdHJlYW1cbiAgLy8gY29udGFpbnMgYnVmZmVycyBvciBvYmplY3RzLlxuXG4gIHRoaXMub2JqZWN0TW9kZSA9ICEhb3B0aW9ucy5vYmplY3RNb2RlO1xuICBpZiAoaXNEdXBsZXgpIHRoaXMub2JqZWN0TW9kZSA9IHRoaXMub2JqZWN0TW9kZSB8fCAhIW9wdGlvbnMud3JpdGFibGVPYmplY3RNb2RlOyAvLyB0aGUgcG9pbnQgYXQgd2hpY2ggd3JpdGUoKSBzdGFydHMgcmV0dXJuaW5nIGZhbHNlXG4gIC8vIE5vdGU6IDAgaXMgYSB2YWxpZCB2YWx1ZSwgbWVhbnMgdGhhdCB3ZSBhbHdheXMgcmV0dXJuIGZhbHNlIGlmXG4gIC8vIHRoZSBlbnRpcmUgYnVmZmVyIGlzIG5vdCBmbHVzaGVkIGltbWVkaWF0ZWx5IG9uIHdyaXRlKClcblxuICB0aGlzLmhpZ2hXYXRlck1hcmsgPSBnZXRIaWdoV2F0ZXJNYXJrKHRoaXMsIG9wdGlvbnMsICd3cml0YWJsZUhpZ2hXYXRlck1hcmsnLCBpc0R1cGxleCk7IC8vIGlmIF9maW5hbCBoYXMgYmVlbiBjYWxsZWRcblxuICB0aGlzLmZpbmFsQ2FsbGVkID0gZmFsc2U7IC8vIGRyYWluIGV2ZW50IGZsYWcuXG5cbiAgdGhpcy5uZWVkRHJhaW4gPSBmYWxzZTsgLy8gYXQgdGhlIHN0YXJ0IG9mIGNhbGxpbmcgZW5kKClcblxuICB0aGlzLmVuZGluZyA9IGZhbHNlOyAvLyB3aGVuIGVuZCgpIGhhcyBiZWVuIGNhbGxlZCwgYW5kIHJldHVybmVkXG5cbiAgdGhpcy5lbmRlZCA9IGZhbHNlOyAvLyB3aGVuICdmaW5pc2gnIGlzIGVtaXR0ZWRcblxuICB0aGlzLmZpbmlzaGVkID0gZmFsc2U7IC8vIGhhcyBpdCBiZWVuIGRlc3Ryb3llZFxuXG4gIHRoaXMuZGVzdHJveWVkID0gZmFsc2U7IC8vIHNob3VsZCB3ZSBkZWNvZGUgc3RyaW5ncyBpbnRvIGJ1ZmZlcnMgYmVmb3JlIHBhc3NpbmcgdG8gX3dyaXRlP1xuICAvLyB0aGlzIGlzIGhlcmUgc28gdGhhdCBzb21lIG5vZGUtY29yZSBzdHJlYW1zIGNhbiBvcHRpbWl6ZSBzdHJpbmdcbiAgLy8gaGFuZGxpbmcgYXQgYSBsb3dlciBsZXZlbC5cblxuICB2YXIgbm9EZWNvZGUgPSBvcHRpb25zLmRlY29kZVN0cmluZ3MgPT09IGZhbHNlO1xuICB0aGlzLmRlY29kZVN0cmluZ3MgPSAhbm9EZWNvZGU7IC8vIENyeXB0byBpcyBraW5kIG9mIG9sZCBhbmQgY3J1c3R5LiAgSGlzdG9yaWNhbGx5LCBpdHMgZGVmYXVsdCBzdHJpbmdcbiAgLy8gZW5jb2RpbmcgaXMgJ2JpbmFyeScgc28gd2UgaGF2ZSB0byBtYWtlIHRoaXMgY29uZmlndXJhYmxlLlxuICAvLyBFdmVyeXRoaW5nIGVsc2UgaW4gdGhlIHVuaXZlcnNlIHVzZXMgJ3V0ZjgnLCB0aG91Z2guXG5cbiAgdGhpcy5kZWZhdWx0RW5jb2RpbmcgPSBvcHRpb25zLmRlZmF1bHRFbmNvZGluZyB8fCAndXRmOCc7IC8vIG5vdCBhbiBhY3R1YWwgYnVmZmVyIHdlIGtlZXAgdHJhY2sgb2YsIGJ1dCBhIG1lYXN1cmVtZW50XG4gIC8vIG9mIGhvdyBtdWNoIHdlJ3JlIHdhaXRpbmcgdG8gZ2V0IHB1c2hlZCB0byBzb21lIHVuZGVybHlpbmdcbiAgLy8gc29ja2V0IG9yIGZpbGUuXG5cbiAgdGhpcy5sZW5ndGggPSAwOyAvLyBhIGZsYWcgdG8gc2VlIHdoZW4gd2UncmUgaW4gdGhlIG1pZGRsZSBvZiBhIHdyaXRlLlxuXG4gIHRoaXMud3JpdGluZyA9IGZhbHNlOyAvLyB3aGVuIHRydWUgYWxsIHdyaXRlcyB3aWxsIGJlIGJ1ZmZlcmVkIHVudGlsIC51bmNvcmsoKSBjYWxsXG5cbiAgdGhpcy5jb3JrZWQgPSAwOyAvLyBhIGZsYWcgdG8gYmUgYWJsZSB0byB0ZWxsIGlmIHRoZSBvbndyaXRlIGNiIGlzIGNhbGxlZCBpbW1lZGlhdGVseSxcbiAgLy8gb3Igb24gYSBsYXRlciB0aWNrLiAgV2Ugc2V0IHRoaXMgdG8gdHJ1ZSBhdCBmaXJzdCwgYmVjYXVzZSBhbnlcbiAgLy8gYWN0aW9ucyB0aGF0IHNob3VsZG4ndCBoYXBwZW4gdW50aWwgXCJsYXRlclwiIHNob3VsZCBnZW5lcmFsbHkgYWxzb1xuICAvLyBub3QgaGFwcGVuIGJlZm9yZSB0aGUgZmlyc3Qgd3JpdGUgY2FsbC5cblxuICB0aGlzLnN5bmMgPSB0cnVlOyAvLyBhIGZsYWcgdG8ga25vdyBpZiB3ZSdyZSBwcm9jZXNzaW5nIHByZXZpb3VzbHkgYnVmZmVyZWQgaXRlbXMsIHdoaWNoXG4gIC8vIG1heSBjYWxsIHRoZSBfd3JpdGUoKSBjYWxsYmFjayBpbiB0aGUgc2FtZSB0aWNrLCBzbyB0aGF0IHdlIGRvbid0XG4gIC8vIGVuZCB1cCBpbiBhbiBvdmVybGFwcGVkIG9ud3JpdGUgc2l0dWF0aW9uLlxuXG4gIHRoaXMuYnVmZmVyUHJvY2Vzc2luZyA9IGZhbHNlOyAvLyB0aGUgY2FsbGJhY2sgdGhhdCdzIHBhc3NlZCB0byBfd3JpdGUoY2h1bmssY2IpXG5cbiAgdGhpcy5vbndyaXRlID0gZnVuY3Rpb24gKGVyKSB7XG4gICAgb253cml0ZShzdHJlYW0sIGVyKTtcbiAgfTsgLy8gdGhlIGNhbGxiYWNrIHRoYXQgdGhlIHVzZXIgc3VwcGxpZXMgdG8gd3JpdGUoY2h1bmssZW5jb2RpbmcsY2IpXG5cblxuICB0aGlzLndyaXRlY2IgPSBudWxsOyAvLyB0aGUgYW1vdW50IHRoYXQgaXMgYmVpbmcgd3JpdHRlbiB3aGVuIF93cml0ZSBpcyBjYWxsZWQuXG5cbiAgdGhpcy53cml0ZWxlbiA9IDA7XG4gIHRoaXMuYnVmZmVyZWRSZXF1ZXN0ID0gbnVsbDtcbiAgdGhpcy5sYXN0QnVmZmVyZWRSZXF1ZXN0ID0gbnVsbDsgLy8gbnVtYmVyIG9mIHBlbmRpbmcgdXNlci1zdXBwbGllZCB3cml0ZSBjYWxsYmFja3NcbiAgLy8gdGhpcyBtdXN0IGJlIDAgYmVmb3JlICdmaW5pc2gnIGNhbiBiZSBlbWl0dGVkXG5cbiAgdGhpcy5wZW5kaW5nY2IgPSAwOyAvLyBlbWl0IHByZWZpbmlzaCBpZiB0aGUgb25seSB0aGluZyB3ZSdyZSB3YWl0aW5nIGZvciBpcyBfd3JpdGUgY2JzXG4gIC8vIFRoaXMgaXMgcmVsZXZhbnQgZm9yIHN5bmNocm9ub3VzIFRyYW5zZm9ybSBzdHJlYW1zXG5cbiAgdGhpcy5wcmVmaW5pc2hlZCA9IGZhbHNlOyAvLyBUcnVlIGlmIHRoZSBlcnJvciB3YXMgYWxyZWFkeSBlbWl0dGVkIGFuZCBzaG91bGQgbm90IGJlIHRocm93biBhZ2FpblxuXG4gIHRoaXMuZXJyb3JFbWl0dGVkID0gZmFsc2U7IC8vIFNob3VsZCBjbG9zZSBiZSBlbWl0dGVkIG9uIGRlc3Ryb3kuIERlZmF1bHRzIHRvIHRydWUuXG5cbiAgdGhpcy5lbWl0Q2xvc2UgPSBvcHRpb25zLmVtaXRDbG9zZSAhPT0gZmFsc2U7IC8vIFNob3VsZCAuZGVzdHJveSgpIGJlIGNhbGxlZCBhZnRlciAnZmluaXNoJyAoYW5kIHBvdGVudGlhbGx5ICdlbmQnKVxuXG4gIHRoaXMuYXV0b0Rlc3Ryb3kgPSAhIW9wdGlvbnMuYXV0b0Rlc3Ryb3k7IC8vIGNvdW50IGJ1ZmZlcmVkIHJlcXVlc3RzXG5cbiAgdGhpcy5idWZmZXJlZFJlcXVlc3RDb3VudCA9IDA7IC8vIGFsbG9jYXRlIHRoZSBmaXJzdCBDb3JrZWRSZXF1ZXN0LCB0aGVyZSBpcyBhbHdheXNcbiAgLy8gb25lIGFsbG9jYXRlZCBhbmQgZnJlZSB0byB1c2UsIGFuZCB3ZSBtYWludGFpbiBhdCBtb3N0IHR3b1xuXG4gIHRoaXMuY29ya2VkUmVxdWVzdHNGcmVlID0gbmV3IENvcmtlZFJlcXVlc3QodGhpcyk7XG59XG5cbldyaXRhYmxlU3RhdGUucHJvdG90eXBlLmdldEJ1ZmZlciA9IGZ1bmN0aW9uIGdldEJ1ZmZlcigpIHtcbiAgdmFyIGN1cnJlbnQgPSB0aGlzLmJ1ZmZlcmVkUmVxdWVzdDtcbiAgdmFyIG91dCA9IFtdO1xuXG4gIHdoaWxlIChjdXJyZW50KSB7XG4gICAgb3V0LnB1c2goY3VycmVudCk7XG4gICAgY3VycmVudCA9IGN1cnJlbnQubmV4dDtcbiAgfVxuXG4gIHJldHVybiBvdXQ7XG59O1xuXG4oZnVuY3Rpb24gKCkge1xuICB0cnkge1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShXcml0YWJsZVN0YXRlLnByb3RvdHlwZSwgJ2J1ZmZlcicsIHtcbiAgICAgIGdldDogaW50ZXJuYWxVdGlsLmRlcHJlY2F0ZShmdW5jdGlvbiB3cml0YWJsZVN0YXRlQnVmZmVyR2V0dGVyKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5nZXRCdWZmZXIoKTtcbiAgICAgIH0sICdfd3JpdGFibGVTdGF0ZS5idWZmZXIgaXMgZGVwcmVjYXRlZC4gVXNlIF93cml0YWJsZVN0YXRlLmdldEJ1ZmZlciAnICsgJ2luc3RlYWQuJywgJ0RFUDAwMDMnKVxuICAgIH0pO1xuICB9IGNhdGNoIChfKSB7fVxufSkoKTsgLy8gVGVzdCBfd3JpdGFibGVTdGF0ZSBmb3IgaW5oZXJpdGFuY2UgdG8gYWNjb3VudCBmb3IgRHVwbGV4IHN0cmVhbXMsXG4vLyB3aG9zZSBwcm90b3R5cGUgY2hhaW4gb25seSBwb2ludHMgdG8gUmVhZGFibGUuXG5cblxudmFyIHJlYWxIYXNJbnN0YW5jZTtcblxuaWYgKHR5cGVvZiBTeW1ib2wgPT09ICdmdW5jdGlvbicgJiYgU3ltYm9sLmhhc0luc3RhbmNlICYmIHR5cGVvZiBGdW5jdGlvbi5wcm90b3R5cGVbU3ltYm9sLmhhc0luc3RhbmNlXSA9PT0gJ2Z1bmN0aW9uJykge1xuICByZWFsSGFzSW5zdGFuY2UgPSBGdW5jdGlvbi5wcm90b3R5cGVbU3ltYm9sLmhhc0luc3RhbmNlXTtcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFdyaXRhYmxlLCBTeW1ib2wuaGFzSW5zdGFuY2UsIHtcbiAgICB2YWx1ZTogZnVuY3Rpb24gdmFsdWUob2JqZWN0KSB7XG4gICAgICBpZiAocmVhbEhhc0luc3RhbmNlLmNhbGwodGhpcywgb2JqZWN0KSkgcmV0dXJuIHRydWU7XG4gICAgICBpZiAodGhpcyAhPT0gV3JpdGFibGUpIHJldHVybiBmYWxzZTtcbiAgICAgIHJldHVybiBvYmplY3QgJiYgb2JqZWN0Ll93cml0YWJsZVN0YXRlIGluc3RhbmNlb2YgV3JpdGFibGVTdGF0ZTtcbiAgICB9XG4gIH0pO1xufSBlbHNlIHtcbiAgcmVhbEhhc0luc3RhbmNlID0gZnVuY3Rpb24gcmVhbEhhc0luc3RhbmNlKG9iamVjdCkge1xuICAgIHJldHVybiBvYmplY3QgaW5zdGFuY2VvZiB0aGlzO1xuICB9O1xufVxuXG5mdW5jdGlvbiBXcml0YWJsZShvcHRpb25zKSB7XG4gIER1cGxleCA9IER1cGxleCB8fCByZXF1aXJlKCcuL19zdHJlYW1fZHVwbGV4Jyk7IC8vIFdyaXRhYmxlIGN0b3IgaXMgYXBwbGllZCB0byBEdXBsZXhlcywgdG9vLlxuICAvLyBgcmVhbEhhc0luc3RhbmNlYCBpcyBuZWNlc3NhcnkgYmVjYXVzZSB1c2luZyBwbGFpbiBgaW5zdGFuY2VvZmBcbiAgLy8gd291bGQgcmV0dXJuIGZhbHNlLCBhcyBubyBgX3dyaXRhYmxlU3RhdGVgIHByb3BlcnR5IGlzIGF0dGFjaGVkLlxuICAvLyBUcnlpbmcgdG8gdXNlIHRoZSBjdXN0b20gYGluc3RhbmNlb2ZgIGZvciBXcml0YWJsZSBoZXJlIHdpbGwgYWxzbyBicmVhayB0aGVcbiAgLy8gTm9kZS5qcyBMYXp5VHJhbnNmb3JtIGltcGxlbWVudGF0aW9uLCB3aGljaCBoYXMgYSBub24tdHJpdmlhbCBnZXR0ZXIgZm9yXG4gIC8vIGBfd3JpdGFibGVTdGF0ZWAgdGhhdCB3b3VsZCBsZWFkIHRvIGluZmluaXRlIHJlY3Vyc2lvbi5cbiAgLy8gQ2hlY2tpbmcgZm9yIGEgU3RyZWFtLkR1cGxleCBpbnN0YW5jZSBpcyBmYXN0ZXIgaGVyZSBpbnN0ZWFkIG9mIGluc2lkZVxuICAvLyB0aGUgV3JpdGFibGVTdGF0ZSBjb25zdHJ1Y3RvciwgYXQgbGVhc3Qgd2l0aCBWOCA2LjVcblxuICB2YXIgaXNEdXBsZXggPSB0aGlzIGluc3RhbmNlb2YgRHVwbGV4O1xuICBpZiAoIWlzRHVwbGV4ICYmICFyZWFsSGFzSW5zdGFuY2UuY2FsbChXcml0YWJsZSwgdGhpcykpIHJldHVybiBuZXcgV3JpdGFibGUob3B0aW9ucyk7XG4gIHRoaXMuX3dyaXRhYmxlU3RhdGUgPSBuZXcgV3JpdGFibGVTdGF0ZShvcHRpb25zLCB0aGlzLCBpc0R1cGxleCk7IC8vIGxlZ2FjeS5cblxuICB0aGlzLndyaXRhYmxlID0gdHJ1ZTtcblxuICBpZiAob3B0aW9ucykge1xuICAgIGlmICh0eXBlb2Ygb3B0aW9ucy53cml0ZSA9PT0gJ2Z1bmN0aW9uJykgdGhpcy5fd3JpdGUgPSBvcHRpb25zLndyaXRlO1xuICAgIGlmICh0eXBlb2Ygb3B0aW9ucy53cml0ZXYgPT09ICdmdW5jdGlvbicpIHRoaXMuX3dyaXRldiA9IG9wdGlvbnMud3JpdGV2O1xuICAgIGlmICh0eXBlb2Ygb3B0aW9ucy5kZXN0cm95ID09PSAnZnVuY3Rpb24nKSB0aGlzLl9kZXN0cm95ID0gb3B0aW9ucy5kZXN0cm95O1xuICAgIGlmICh0eXBlb2Ygb3B0aW9ucy5maW5hbCA9PT0gJ2Z1bmN0aW9uJykgdGhpcy5fZmluYWwgPSBvcHRpb25zLmZpbmFsO1xuICB9XG5cbiAgU3RyZWFtLmNhbGwodGhpcyk7XG59IC8vIE90aGVyd2lzZSBwZW9wbGUgY2FuIHBpcGUgV3JpdGFibGUgc3RyZWFtcywgd2hpY2ggaXMganVzdCB3cm9uZy5cblxuXG5Xcml0YWJsZS5wcm90b3R5cGUucGlwZSA9IGZ1bmN0aW9uICgpIHtcbiAgZXJyb3JPckRlc3Ryb3kodGhpcywgbmV3IEVSUl9TVFJFQU1fQ0FOTk9UX1BJUEUoKSk7XG59O1xuXG5mdW5jdGlvbiB3cml0ZUFmdGVyRW5kKHN0cmVhbSwgY2IpIHtcbiAgdmFyIGVyID0gbmV3IEVSUl9TVFJFQU1fV1JJVEVfQUZURVJfRU5EKCk7IC8vIFRPRE86IGRlZmVyIGVycm9yIGV2ZW50cyBjb25zaXN0ZW50bHkgZXZlcnl3aGVyZSwgbm90IGp1c3QgdGhlIGNiXG5cbiAgZXJyb3JPckRlc3Ryb3koc3RyZWFtLCBlcik7XG4gIHByb2Nlc3MubmV4dFRpY2soY2IsIGVyKTtcbn0gLy8gQ2hlY2tzIHRoYXQgYSB1c2VyLXN1cHBsaWVkIGNodW5rIGlzIHZhbGlkLCBlc3BlY2lhbGx5IGZvciB0aGUgcGFydGljdWxhclxuLy8gbW9kZSB0aGUgc3RyZWFtIGlzIGluLiBDdXJyZW50bHkgdGhpcyBtZWFucyB0aGF0IGBudWxsYCBpcyBuZXZlciBhY2NlcHRlZFxuLy8gYW5kIHVuZGVmaW5lZC9ub24tc3RyaW5nIHZhbHVlcyBhcmUgb25seSBhbGxvd2VkIGluIG9iamVjdCBtb2RlLlxuXG5cbmZ1bmN0aW9uIHZhbGlkQ2h1bmsoc3RyZWFtLCBzdGF0ZSwgY2h1bmssIGNiKSB7XG4gIHZhciBlcjtcblxuICBpZiAoY2h1bmsgPT09IG51bGwpIHtcbiAgICBlciA9IG5ldyBFUlJfU1RSRUFNX05VTExfVkFMVUVTKCk7XG4gIH0gZWxzZSBpZiAodHlwZW9mIGNodW5rICE9PSAnc3RyaW5nJyAmJiAhc3RhdGUub2JqZWN0TW9kZSkge1xuICAgIGVyID0gbmV3IEVSUl9JTlZBTElEX0FSR19UWVBFKCdjaHVuaycsIFsnc3RyaW5nJywgJ0J1ZmZlciddLCBjaHVuayk7XG4gIH1cblxuICBpZiAoZXIpIHtcbiAgICBlcnJvck9yRGVzdHJveShzdHJlYW0sIGVyKTtcbiAgICBwcm9jZXNzLm5leHRUaWNrKGNiLCBlcik7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgcmV0dXJuIHRydWU7XG59XG5cbldyaXRhYmxlLnByb3RvdHlwZS53cml0ZSA9IGZ1bmN0aW9uIChjaHVuaywgZW5jb2RpbmcsIGNiKSB7XG4gIHZhciBzdGF0ZSA9IHRoaXMuX3dyaXRhYmxlU3RhdGU7XG4gIHZhciByZXQgPSBmYWxzZTtcblxuICB2YXIgaXNCdWYgPSAhc3RhdGUub2JqZWN0TW9kZSAmJiBfaXNVaW50OEFycmF5KGNodW5rKTtcblxuICBpZiAoaXNCdWYgJiYgIUJ1ZmZlci5pc0J1ZmZlcihjaHVuaykpIHtcbiAgICBjaHVuayA9IF91aW50OEFycmF5VG9CdWZmZXIoY2h1bmspO1xuICB9XG5cbiAgaWYgKHR5cGVvZiBlbmNvZGluZyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIGNiID0gZW5jb2Rpbmc7XG4gICAgZW5jb2RpbmcgPSBudWxsO1xuICB9XG5cbiAgaWYgKGlzQnVmKSBlbmNvZGluZyA9ICdidWZmZXInO2Vsc2UgaWYgKCFlbmNvZGluZykgZW5jb2RpbmcgPSBzdGF0ZS5kZWZhdWx0RW5jb2Rpbmc7XG4gIGlmICh0eXBlb2YgY2IgIT09ICdmdW5jdGlvbicpIGNiID0gbm9wO1xuICBpZiAoc3RhdGUuZW5kaW5nKSB3cml0ZUFmdGVyRW5kKHRoaXMsIGNiKTtlbHNlIGlmIChpc0J1ZiB8fCB2YWxpZENodW5rKHRoaXMsIHN0YXRlLCBjaHVuaywgY2IpKSB7XG4gICAgc3RhdGUucGVuZGluZ2NiKys7XG4gICAgcmV0ID0gd3JpdGVPckJ1ZmZlcih0aGlzLCBzdGF0ZSwgaXNCdWYsIGNodW5rLCBlbmNvZGluZywgY2IpO1xuICB9XG4gIHJldHVybiByZXQ7XG59O1xuXG5Xcml0YWJsZS5wcm90b3R5cGUuY29yayA9IGZ1bmN0aW9uICgpIHtcbiAgdGhpcy5fd3JpdGFibGVTdGF0ZS5jb3JrZWQrKztcbn07XG5cbldyaXRhYmxlLnByb3RvdHlwZS51bmNvcmsgPSBmdW5jdGlvbiAoKSB7XG4gIHZhciBzdGF0ZSA9IHRoaXMuX3dyaXRhYmxlU3RhdGU7XG5cbiAgaWYgKHN0YXRlLmNvcmtlZCkge1xuICAgIHN0YXRlLmNvcmtlZC0tO1xuICAgIGlmICghc3RhdGUud3JpdGluZyAmJiAhc3RhdGUuY29ya2VkICYmICFzdGF0ZS5idWZmZXJQcm9jZXNzaW5nICYmIHN0YXRlLmJ1ZmZlcmVkUmVxdWVzdCkgY2xlYXJCdWZmZXIodGhpcywgc3RhdGUpO1xuICB9XG59O1xuXG5Xcml0YWJsZS5wcm90b3R5cGUuc2V0RGVmYXVsdEVuY29kaW5nID0gZnVuY3Rpb24gc2V0RGVmYXVsdEVuY29kaW5nKGVuY29kaW5nKSB7XG4gIC8vIG5vZGU6OlBhcnNlRW5jb2RpbmcoKSByZXF1aXJlcyBsb3dlciBjYXNlLlxuICBpZiAodHlwZW9mIGVuY29kaW5nID09PSAnc3RyaW5nJykgZW5jb2RpbmcgPSBlbmNvZGluZy50b0xvd2VyQ2FzZSgpO1xuICBpZiAoIShbJ2hleCcsICd1dGY4JywgJ3V0Zi04JywgJ2FzY2lpJywgJ2JpbmFyeScsICdiYXNlNjQnLCAndWNzMicsICd1Y3MtMicsICd1dGYxNmxlJywgJ3V0Zi0xNmxlJywgJ3JhdyddLmluZGV4T2YoKGVuY29kaW5nICsgJycpLnRvTG93ZXJDYXNlKCkpID4gLTEpKSB0aHJvdyBuZXcgRVJSX1VOS05PV05fRU5DT0RJTkcoZW5jb2RpbmcpO1xuICB0aGlzLl93cml0YWJsZVN0YXRlLmRlZmF1bHRFbmNvZGluZyA9IGVuY29kaW5nO1xuICByZXR1cm4gdGhpcztcbn07XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShXcml0YWJsZS5wcm90b3R5cGUsICd3cml0YWJsZUJ1ZmZlcicsIHtcbiAgLy8gbWFraW5nIGl0IGV4cGxpY2l0IHRoaXMgcHJvcGVydHkgaXMgbm90IGVudW1lcmFibGVcbiAgLy8gYmVjYXVzZSBvdGhlcndpc2Ugc29tZSBwcm90b3R5cGUgbWFuaXB1bGF0aW9uIGluXG4gIC8vIHVzZXJsYW5kIHdpbGwgZmFpbFxuICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgZ2V0OiBmdW5jdGlvbiBnZXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3dyaXRhYmxlU3RhdGUgJiYgdGhpcy5fd3JpdGFibGVTdGF0ZS5nZXRCdWZmZXIoKTtcbiAgfVxufSk7XG5cbmZ1bmN0aW9uIGRlY29kZUNodW5rKHN0YXRlLCBjaHVuaywgZW5jb2RpbmcpIHtcbiAgaWYgKCFzdGF0ZS5vYmplY3RNb2RlICYmIHN0YXRlLmRlY29kZVN0cmluZ3MgIT09IGZhbHNlICYmIHR5cGVvZiBjaHVuayA9PT0gJ3N0cmluZycpIHtcbiAgICBjaHVuayA9IEJ1ZmZlci5mcm9tKGNodW5rLCBlbmNvZGluZyk7XG4gIH1cblxuICByZXR1cm4gY2h1bms7XG59XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShXcml0YWJsZS5wcm90b3R5cGUsICd3cml0YWJsZUhpZ2hXYXRlck1hcmsnLCB7XG4gIC8vIG1ha2luZyBpdCBleHBsaWNpdCB0aGlzIHByb3BlcnR5IGlzIG5vdCBlbnVtZXJhYmxlXG4gIC8vIGJlY2F1c2Ugb3RoZXJ3aXNlIHNvbWUgcHJvdG90eXBlIG1hbmlwdWxhdGlvbiBpblxuICAvLyB1c2VybGFuZCB3aWxsIGZhaWxcbiAgZW51bWVyYWJsZTogZmFsc2UsXG4gIGdldDogZnVuY3Rpb24gZ2V0KCkge1xuICAgIHJldHVybiB0aGlzLl93cml0YWJsZVN0YXRlLmhpZ2hXYXRlck1hcms7XG4gIH1cbn0pOyAvLyBpZiB3ZSdyZSBhbHJlYWR5IHdyaXRpbmcgc29tZXRoaW5nLCB0aGVuIGp1c3QgcHV0IHRoaXNcbi8vIGluIHRoZSBxdWV1ZSwgYW5kIHdhaXQgb3VyIHR1cm4uICBPdGhlcndpc2UsIGNhbGwgX3dyaXRlXG4vLyBJZiB3ZSByZXR1cm4gZmFsc2UsIHRoZW4gd2UgbmVlZCBhIGRyYWluIGV2ZW50LCBzbyBzZXQgdGhhdCBmbGFnLlxuXG5mdW5jdGlvbiB3cml0ZU9yQnVmZmVyKHN0cmVhbSwgc3RhdGUsIGlzQnVmLCBjaHVuaywgZW5jb2RpbmcsIGNiKSB7XG4gIGlmICghaXNCdWYpIHtcbiAgICB2YXIgbmV3Q2h1bmsgPSBkZWNvZGVDaHVuayhzdGF0ZSwgY2h1bmssIGVuY29kaW5nKTtcblxuICAgIGlmIChjaHVuayAhPT0gbmV3Q2h1bmspIHtcbiAgICAgIGlzQnVmID0gdHJ1ZTtcbiAgICAgIGVuY29kaW5nID0gJ2J1ZmZlcic7XG4gICAgICBjaHVuayA9IG5ld0NodW5rO1xuICAgIH1cbiAgfVxuXG4gIHZhciBsZW4gPSBzdGF0ZS5vYmplY3RNb2RlID8gMSA6IGNodW5rLmxlbmd0aDtcbiAgc3RhdGUubGVuZ3RoICs9IGxlbjtcbiAgdmFyIHJldCA9IHN0YXRlLmxlbmd0aCA8IHN0YXRlLmhpZ2hXYXRlck1hcms7IC8vIHdlIG11c3QgZW5zdXJlIHRoYXQgcHJldmlvdXMgbmVlZERyYWluIHdpbGwgbm90IGJlIHJlc2V0IHRvIGZhbHNlLlxuXG4gIGlmICghcmV0KSBzdGF0ZS5uZWVkRHJhaW4gPSB0cnVlO1xuXG4gIGlmIChzdGF0ZS53cml0aW5nIHx8IHN0YXRlLmNvcmtlZCkge1xuICAgIHZhciBsYXN0ID0gc3RhdGUubGFzdEJ1ZmZlcmVkUmVxdWVzdDtcbiAgICBzdGF0ZS5sYXN0QnVmZmVyZWRSZXF1ZXN0ID0ge1xuICAgICAgY2h1bms6IGNodW5rLFxuICAgICAgZW5jb2Rpbmc6IGVuY29kaW5nLFxuICAgICAgaXNCdWY6IGlzQnVmLFxuICAgICAgY2FsbGJhY2s6IGNiLFxuICAgICAgbmV4dDogbnVsbFxuICAgIH07XG5cbiAgICBpZiAobGFzdCkge1xuICAgICAgbGFzdC5uZXh0ID0gc3RhdGUubGFzdEJ1ZmZlcmVkUmVxdWVzdDtcbiAgICB9IGVsc2Uge1xuICAgICAgc3RhdGUuYnVmZmVyZWRSZXF1ZXN0ID0gc3RhdGUubGFzdEJ1ZmZlcmVkUmVxdWVzdDtcbiAgICB9XG5cbiAgICBzdGF0ZS5idWZmZXJlZFJlcXVlc3RDb3VudCArPSAxO1xuICB9IGVsc2Uge1xuICAgIGRvV3JpdGUoc3RyZWFtLCBzdGF0ZSwgZmFsc2UsIGxlbiwgY2h1bmssIGVuY29kaW5nLCBjYik7XG4gIH1cblxuICByZXR1cm4gcmV0O1xufVxuXG5mdW5jdGlvbiBkb1dyaXRlKHN0cmVhbSwgc3RhdGUsIHdyaXRldiwgbGVuLCBjaHVuaywgZW5jb2RpbmcsIGNiKSB7XG4gIHN0YXRlLndyaXRlbGVuID0gbGVuO1xuICBzdGF0ZS53cml0ZWNiID0gY2I7XG4gIHN0YXRlLndyaXRpbmcgPSB0cnVlO1xuICBzdGF0ZS5zeW5jID0gdHJ1ZTtcbiAgaWYgKHN0YXRlLmRlc3Ryb3llZCkgc3RhdGUub253cml0ZShuZXcgRVJSX1NUUkVBTV9ERVNUUk9ZRUQoJ3dyaXRlJykpO2Vsc2UgaWYgKHdyaXRldikgc3RyZWFtLl93cml0ZXYoY2h1bmssIHN0YXRlLm9ud3JpdGUpO2Vsc2Ugc3RyZWFtLl93cml0ZShjaHVuaywgZW5jb2RpbmcsIHN0YXRlLm9ud3JpdGUpO1xuICBzdGF0ZS5zeW5jID0gZmFsc2U7XG59XG5cbmZ1bmN0aW9uIG9ud3JpdGVFcnJvcihzdHJlYW0sIHN0YXRlLCBzeW5jLCBlciwgY2IpIHtcbiAgLS1zdGF0ZS5wZW5kaW5nY2I7XG5cbiAgaWYgKHN5bmMpIHtcbiAgICAvLyBkZWZlciB0aGUgY2FsbGJhY2sgaWYgd2UgYXJlIGJlaW5nIGNhbGxlZCBzeW5jaHJvbm91c2x5XG4gICAgLy8gdG8gYXZvaWQgcGlsaW5nIHVwIHRoaW5ncyBvbiB0aGUgc3RhY2tcbiAgICBwcm9jZXNzLm5leHRUaWNrKGNiLCBlcik7IC8vIHRoaXMgY2FuIGVtaXQgZmluaXNoLCBhbmQgaXQgd2lsbCBhbHdheXMgaGFwcGVuXG4gICAgLy8gYWZ0ZXIgZXJyb3JcblxuICAgIHByb2Nlc3MubmV4dFRpY2soZmluaXNoTWF5YmUsIHN0cmVhbSwgc3RhdGUpO1xuICAgIHN0cmVhbS5fd3JpdGFibGVTdGF0ZS5lcnJvckVtaXR0ZWQgPSB0cnVlO1xuICAgIGVycm9yT3JEZXN0cm95KHN0cmVhbSwgZXIpO1xuICB9IGVsc2Uge1xuICAgIC8vIHRoZSBjYWxsZXIgZXhwZWN0IHRoaXMgdG8gaGFwcGVuIGJlZm9yZSBpZlxuICAgIC8vIGl0IGlzIGFzeW5jXG4gICAgY2IoZXIpO1xuICAgIHN0cmVhbS5fd3JpdGFibGVTdGF0ZS5lcnJvckVtaXR0ZWQgPSB0cnVlO1xuICAgIGVycm9yT3JEZXN0cm95KHN0cmVhbSwgZXIpOyAvLyB0aGlzIGNhbiBlbWl0IGZpbmlzaCwgYnV0IGZpbmlzaCBtdXN0XG4gICAgLy8gYWx3YXlzIGZvbGxvdyBlcnJvclxuXG4gICAgZmluaXNoTWF5YmUoc3RyZWFtLCBzdGF0ZSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gb253cml0ZVN0YXRlVXBkYXRlKHN0YXRlKSB7XG4gIHN0YXRlLndyaXRpbmcgPSBmYWxzZTtcbiAgc3RhdGUud3JpdGVjYiA9IG51bGw7XG4gIHN0YXRlLmxlbmd0aCAtPSBzdGF0ZS53cml0ZWxlbjtcbiAgc3RhdGUud3JpdGVsZW4gPSAwO1xufVxuXG5mdW5jdGlvbiBvbndyaXRlKHN0cmVhbSwgZXIpIHtcbiAgdmFyIHN0YXRlID0gc3RyZWFtLl93cml0YWJsZVN0YXRlO1xuICB2YXIgc3luYyA9IHN0YXRlLnN5bmM7XG4gIHZhciBjYiA9IHN0YXRlLndyaXRlY2I7XG4gIGlmICh0eXBlb2YgY2IgIT09ICdmdW5jdGlvbicpIHRocm93IG5ldyBFUlJfTVVMVElQTEVfQ0FMTEJBQ0soKTtcbiAgb253cml0ZVN0YXRlVXBkYXRlKHN0YXRlKTtcbiAgaWYgKGVyKSBvbndyaXRlRXJyb3Ioc3RyZWFtLCBzdGF0ZSwgc3luYywgZXIsIGNiKTtlbHNlIHtcbiAgICAvLyBDaGVjayBpZiB3ZSdyZSBhY3R1YWxseSByZWFkeSB0byBmaW5pc2gsIGJ1dCBkb24ndCBlbWl0IHlldFxuICAgIHZhciBmaW5pc2hlZCA9IG5lZWRGaW5pc2goc3RhdGUpIHx8IHN0cmVhbS5kZXN0cm95ZWQ7XG5cbiAgICBpZiAoIWZpbmlzaGVkICYmICFzdGF0ZS5jb3JrZWQgJiYgIXN0YXRlLmJ1ZmZlclByb2Nlc3NpbmcgJiYgc3RhdGUuYnVmZmVyZWRSZXF1ZXN0KSB7XG4gICAgICBjbGVhckJ1ZmZlcihzdHJlYW0sIHN0YXRlKTtcbiAgICB9XG5cbiAgICBpZiAoc3luYykge1xuICAgICAgcHJvY2Vzcy5uZXh0VGljayhhZnRlcldyaXRlLCBzdHJlYW0sIHN0YXRlLCBmaW5pc2hlZCwgY2IpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhZnRlcldyaXRlKHN0cmVhbSwgc3RhdGUsIGZpbmlzaGVkLCBjYik7XG4gICAgfVxuICB9XG59XG5cbmZ1bmN0aW9uIGFmdGVyV3JpdGUoc3RyZWFtLCBzdGF0ZSwgZmluaXNoZWQsIGNiKSB7XG4gIGlmICghZmluaXNoZWQpIG9ud3JpdGVEcmFpbihzdHJlYW0sIHN0YXRlKTtcbiAgc3RhdGUucGVuZGluZ2NiLS07XG4gIGNiKCk7XG4gIGZpbmlzaE1heWJlKHN0cmVhbSwgc3RhdGUpO1xufSAvLyBNdXN0IGZvcmNlIGNhbGxiYWNrIHRvIGJlIGNhbGxlZCBvbiBuZXh0VGljaywgc28gdGhhdCB3ZSBkb24ndFxuLy8gZW1pdCAnZHJhaW4nIGJlZm9yZSB0aGUgd3JpdGUoKSBjb25zdW1lciBnZXRzIHRoZSAnZmFsc2UnIHJldHVyblxuLy8gdmFsdWUsIGFuZCBoYXMgYSBjaGFuY2UgdG8gYXR0YWNoIGEgJ2RyYWluJyBsaXN0ZW5lci5cblxuXG5mdW5jdGlvbiBvbndyaXRlRHJhaW4oc3RyZWFtLCBzdGF0ZSkge1xuICBpZiAoc3RhdGUubGVuZ3RoID09PSAwICYmIHN0YXRlLm5lZWREcmFpbikge1xuICAgIHN0YXRlLm5lZWREcmFpbiA9IGZhbHNlO1xuICAgIHN0cmVhbS5lbWl0KCdkcmFpbicpO1xuICB9XG59IC8vIGlmIHRoZXJlJ3Mgc29tZXRoaW5nIGluIHRoZSBidWZmZXIgd2FpdGluZywgdGhlbiBwcm9jZXNzIGl0XG5cblxuZnVuY3Rpb24gY2xlYXJCdWZmZXIoc3RyZWFtLCBzdGF0ZSkge1xuICBzdGF0ZS5idWZmZXJQcm9jZXNzaW5nID0gdHJ1ZTtcbiAgdmFyIGVudHJ5ID0gc3RhdGUuYnVmZmVyZWRSZXF1ZXN0O1xuXG4gIGlmIChzdHJlYW0uX3dyaXRldiAmJiBlbnRyeSAmJiBlbnRyeS5uZXh0KSB7XG4gICAgLy8gRmFzdCBjYXNlLCB3cml0ZSBldmVyeXRoaW5nIHVzaW5nIF93cml0ZXYoKVxuICAgIHZhciBsID0gc3RhdGUuYnVmZmVyZWRSZXF1ZXN0Q291bnQ7XG4gICAgdmFyIGJ1ZmZlciA9IG5ldyBBcnJheShsKTtcbiAgICB2YXIgaG9sZGVyID0gc3RhdGUuY29ya2VkUmVxdWVzdHNGcmVlO1xuICAgIGhvbGRlci5lbnRyeSA9IGVudHJ5O1xuICAgIHZhciBjb3VudCA9IDA7XG4gICAgdmFyIGFsbEJ1ZmZlcnMgPSB0cnVlO1xuXG4gICAgd2hpbGUgKGVudHJ5KSB7XG4gICAgICBidWZmZXJbY291bnRdID0gZW50cnk7XG4gICAgICBpZiAoIWVudHJ5LmlzQnVmKSBhbGxCdWZmZXJzID0gZmFsc2U7XG4gICAgICBlbnRyeSA9IGVudHJ5Lm5leHQ7XG4gICAgICBjb3VudCArPSAxO1xuICAgIH1cblxuICAgIGJ1ZmZlci5hbGxCdWZmZXJzID0gYWxsQnVmZmVycztcbiAgICBkb1dyaXRlKHN0cmVhbSwgc3RhdGUsIHRydWUsIHN0YXRlLmxlbmd0aCwgYnVmZmVyLCAnJywgaG9sZGVyLmZpbmlzaCk7IC8vIGRvV3JpdGUgaXMgYWxtb3N0IGFsd2F5cyBhc3luYywgZGVmZXIgdGhlc2UgdG8gc2F2ZSBhIGJpdCBvZiB0aW1lXG4gICAgLy8gYXMgdGhlIGhvdCBwYXRoIGVuZHMgd2l0aCBkb1dyaXRlXG5cbiAgICBzdGF0ZS5wZW5kaW5nY2IrKztcbiAgICBzdGF0ZS5sYXN0QnVmZmVyZWRSZXF1ZXN0ID0gbnVsbDtcblxuICAgIGlmIChob2xkZXIubmV4dCkge1xuICAgICAgc3RhdGUuY29ya2VkUmVxdWVzdHNGcmVlID0gaG9sZGVyLm5leHQ7XG4gICAgICBob2xkZXIubmV4dCA9IG51bGw7XG4gICAgfSBlbHNlIHtcbiAgICAgIHN0YXRlLmNvcmtlZFJlcXVlc3RzRnJlZSA9IG5ldyBDb3JrZWRSZXF1ZXN0KHN0YXRlKTtcbiAgICB9XG5cbiAgICBzdGF0ZS5idWZmZXJlZFJlcXVlc3RDb3VudCA9IDA7XG4gIH0gZWxzZSB7XG4gICAgLy8gU2xvdyBjYXNlLCB3cml0ZSBjaHVua3Mgb25lLWJ5LW9uZVxuICAgIHdoaWxlIChlbnRyeSkge1xuICAgICAgdmFyIGNodW5rID0gZW50cnkuY2h1bms7XG4gICAgICB2YXIgZW5jb2RpbmcgPSBlbnRyeS5lbmNvZGluZztcbiAgICAgIHZhciBjYiA9IGVudHJ5LmNhbGxiYWNrO1xuICAgICAgdmFyIGxlbiA9IHN0YXRlLm9iamVjdE1vZGUgPyAxIDogY2h1bmsubGVuZ3RoO1xuICAgICAgZG9Xcml0ZShzdHJlYW0sIHN0YXRlLCBmYWxzZSwgbGVuLCBjaHVuaywgZW5jb2RpbmcsIGNiKTtcbiAgICAgIGVudHJ5ID0gZW50cnkubmV4dDtcbiAgICAgIHN0YXRlLmJ1ZmZlcmVkUmVxdWVzdENvdW50LS07IC8vIGlmIHdlIGRpZG4ndCBjYWxsIHRoZSBvbndyaXRlIGltbWVkaWF0ZWx5LCB0aGVuXG4gICAgICAvLyBpdCBtZWFucyB0aGF0IHdlIG5lZWQgdG8gd2FpdCB1bnRpbCBpdCBkb2VzLlxuICAgICAgLy8gYWxzbywgdGhhdCBtZWFucyB0aGF0IHRoZSBjaHVuayBhbmQgY2IgYXJlIGN1cnJlbnRseVxuICAgICAgLy8gYmVpbmcgcHJvY2Vzc2VkLCBzbyBtb3ZlIHRoZSBidWZmZXIgY291bnRlciBwYXN0IHRoZW0uXG5cbiAgICAgIGlmIChzdGF0ZS53cml0aW5nKSB7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChlbnRyeSA9PT0gbnVsbCkgc3RhdGUubGFzdEJ1ZmZlcmVkUmVxdWVzdCA9IG51bGw7XG4gIH1cblxuICBzdGF0ZS5idWZmZXJlZFJlcXVlc3QgPSBlbnRyeTtcbiAgc3RhdGUuYnVmZmVyUHJvY2Vzc2luZyA9IGZhbHNlO1xufVxuXG5Xcml0YWJsZS5wcm90b3R5cGUuX3dyaXRlID0gZnVuY3Rpb24gKGNodW5rLCBlbmNvZGluZywgY2IpIHtcbiAgY2IobmV3IEVSUl9NRVRIT0RfTk9UX0lNUExFTUVOVEVEKCdfd3JpdGUoKScpKTtcbn07XG5cbldyaXRhYmxlLnByb3RvdHlwZS5fd3JpdGV2ID0gbnVsbDtcblxuV3JpdGFibGUucHJvdG90eXBlLmVuZCA9IGZ1bmN0aW9uIChjaHVuaywgZW5jb2RpbmcsIGNiKSB7XG4gIHZhciBzdGF0ZSA9IHRoaXMuX3dyaXRhYmxlU3RhdGU7XG5cbiAgaWYgKHR5cGVvZiBjaHVuayA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIGNiID0gY2h1bms7XG4gICAgY2h1bmsgPSBudWxsO1xuICAgIGVuY29kaW5nID0gbnVsbDtcbiAgfSBlbHNlIGlmICh0eXBlb2YgZW5jb2RpbmcgPT09ICdmdW5jdGlvbicpIHtcbiAgICBjYiA9IGVuY29kaW5nO1xuICAgIGVuY29kaW5nID0gbnVsbDtcbiAgfVxuXG4gIGlmIChjaHVuayAhPT0gbnVsbCAmJiBjaHVuayAhPT0gdW5kZWZpbmVkKSB0aGlzLndyaXRlKGNodW5rLCBlbmNvZGluZyk7IC8vIC5lbmQoKSBmdWxseSB1bmNvcmtzXG5cbiAgaWYgKHN0YXRlLmNvcmtlZCkge1xuICAgIHN0YXRlLmNvcmtlZCA9IDE7XG4gICAgdGhpcy51bmNvcmsoKTtcbiAgfSAvLyBpZ25vcmUgdW5uZWNlc3NhcnkgZW5kKCkgY2FsbHMuXG5cblxuICBpZiAoIXN0YXRlLmVuZGluZykgZW5kV3JpdGFibGUodGhpcywgc3RhdGUsIGNiKTtcbiAgcmV0dXJuIHRoaXM7XG59O1xuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoV3JpdGFibGUucHJvdG90eXBlLCAnd3JpdGFibGVMZW5ndGgnLCB7XG4gIC8vIG1ha2luZyBpdCBleHBsaWNpdCB0aGlzIHByb3BlcnR5IGlzIG5vdCBlbnVtZXJhYmxlXG4gIC8vIGJlY2F1c2Ugb3RoZXJ3aXNlIHNvbWUgcHJvdG90eXBlIG1hbmlwdWxhdGlvbiBpblxuICAvLyB1c2VybGFuZCB3aWxsIGZhaWxcbiAgZW51bWVyYWJsZTogZmFsc2UsXG4gIGdldDogZnVuY3Rpb24gZ2V0KCkge1xuICAgIHJldHVybiB0aGlzLl93cml0YWJsZVN0YXRlLmxlbmd0aDtcbiAgfVxufSk7XG5cbmZ1bmN0aW9uIG5lZWRGaW5pc2goc3RhdGUpIHtcbiAgcmV0dXJuIHN0YXRlLmVuZGluZyAmJiBzdGF0ZS5sZW5ndGggPT09IDAgJiYgc3RhdGUuYnVmZmVyZWRSZXF1ZXN0ID09PSBudWxsICYmICFzdGF0ZS5maW5pc2hlZCAmJiAhc3RhdGUud3JpdGluZztcbn1cblxuZnVuY3Rpb24gY2FsbEZpbmFsKHN0cmVhbSwgc3RhdGUpIHtcbiAgc3RyZWFtLl9maW5hbChmdW5jdGlvbiAoZXJyKSB7XG4gICAgc3RhdGUucGVuZGluZ2NiLS07XG5cbiAgICBpZiAoZXJyKSB7XG4gICAgICBlcnJvck9yRGVzdHJveShzdHJlYW0sIGVycik7XG4gICAgfVxuXG4gICAgc3RhdGUucHJlZmluaXNoZWQgPSB0cnVlO1xuICAgIHN0cmVhbS5lbWl0KCdwcmVmaW5pc2gnKTtcbiAgICBmaW5pc2hNYXliZShzdHJlYW0sIHN0YXRlKTtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHByZWZpbmlzaChzdHJlYW0sIHN0YXRlKSB7XG4gIGlmICghc3RhdGUucHJlZmluaXNoZWQgJiYgIXN0YXRlLmZpbmFsQ2FsbGVkKSB7XG4gICAgaWYgKHR5cGVvZiBzdHJlYW0uX2ZpbmFsID09PSAnZnVuY3Rpb24nICYmICFzdGF0ZS5kZXN0cm95ZWQpIHtcbiAgICAgIHN0YXRlLnBlbmRpbmdjYisrO1xuICAgICAgc3RhdGUuZmluYWxDYWxsZWQgPSB0cnVlO1xuICAgICAgcHJvY2Vzcy5uZXh0VGljayhjYWxsRmluYWwsIHN0cmVhbSwgc3RhdGUpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzdGF0ZS5wcmVmaW5pc2hlZCA9IHRydWU7XG4gICAgICBzdHJlYW0uZW1pdCgncHJlZmluaXNoJyk7XG4gICAgfVxuICB9XG59XG5cbmZ1bmN0aW9uIGZpbmlzaE1heWJlKHN0cmVhbSwgc3RhdGUpIHtcbiAgdmFyIG5lZWQgPSBuZWVkRmluaXNoKHN0YXRlKTtcblxuICBpZiAobmVlZCkge1xuICAgIHByZWZpbmlzaChzdHJlYW0sIHN0YXRlKTtcblxuICAgIGlmIChzdGF0ZS5wZW5kaW5nY2IgPT09IDApIHtcbiAgICAgIHN0YXRlLmZpbmlzaGVkID0gdHJ1ZTtcbiAgICAgIHN0cmVhbS5lbWl0KCdmaW5pc2gnKTtcblxuICAgICAgaWYgKHN0YXRlLmF1dG9EZXN0cm95KSB7XG4gICAgICAgIC8vIEluIGNhc2Ugb2YgZHVwbGV4IHN0cmVhbXMgd2UgbmVlZCBhIHdheSB0byBkZXRlY3RcbiAgICAgICAgLy8gaWYgdGhlIHJlYWRhYmxlIHNpZGUgaXMgcmVhZHkgZm9yIGF1dG9EZXN0cm95IGFzIHdlbGxcbiAgICAgICAgdmFyIHJTdGF0ZSA9IHN0cmVhbS5fcmVhZGFibGVTdGF0ZTtcblxuICAgICAgICBpZiAoIXJTdGF0ZSB8fCByU3RhdGUuYXV0b0Rlc3Ryb3kgJiYgclN0YXRlLmVuZEVtaXR0ZWQpIHtcbiAgICAgICAgICBzdHJlYW0uZGVzdHJveSgpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIG5lZWQ7XG59XG5cbmZ1bmN0aW9uIGVuZFdyaXRhYmxlKHN0cmVhbSwgc3RhdGUsIGNiKSB7XG4gIHN0YXRlLmVuZGluZyA9IHRydWU7XG4gIGZpbmlzaE1heWJlKHN0cmVhbSwgc3RhdGUpO1xuXG4gIGlmIChjYikge1xuICAgIGlmIChzdGF0ZS5maW5pc2hlZCkgcHJvY2Vzcy5uZXh0VGljayhjYik7ZWxzZSBzdHJlYW0ub25jZSgnZmluaXNoJywgY2IpO1xuICB9XG5cbiAgc3RhdGUuZW5kZWQgPSB0cnVlO1xuICBzdHJlYW0ud3JpdGFibGUgPSBmYWxzZTtcbn1cblxuZnVuY3Rpb24gb25Db3JrZWRGaW5pc2goY29ya1JlcSwgc3RhdGUsIGVycikge1xuICB2YXIgZW50cnkgPSBjb3JrUmVxLmVudHJ5O1xuICBjb3JrUmVxLmVudHJ5ID0gbnVsbDtcblxuICB3aGlsZSAoZW50cnkpIHtcbiAgICB2YXIgY2IgPSBlbnRyeS5jYWxsYmFjaztcbiAgICBzdGF0ZS5wZW5kaW5nY2ItLTtcbiAgICBjYihlcnIpO1xuICAgIGVudHJ5ID0gZW50cnkubmV4dDtcbiAgfSAvLyByZXVzZSB0aGUgZnJlZSBjb3JrUmVxLlxuXG5cbiAgc3RhdGUuY29ya2VkUmVxdWVzdHNGcmVlLm5leHQgPSBjb3JrUmVxO1xufVxuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoV3JpdGFibGUucHJvdG90eXBlLCAnZGVzdHJveWVkJywge1xuICAvLyBtYWtpbmcgaXQgZXhwbGljaXQgdGhpcyBwcm9wZXJ0eSBpcyBub3QgZW51bWVyYWJsZVxuICAvLyBiZWNhdXNlIG90aGVyd2lzZSBzb21lIHByb3RvdHlwZSBtYW5pcHVsYXRpb24gaW5cbiAgLy8gdXNlcmxhbmQgd2lsbCBmYWlsXG4gIGVudW1lcmFibGU6IGZhbHNlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICBpZiAodGhpcy5fd3JpdGFibGVTdGF0ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuX3dyaXRhYmxlU3RhdGUuZGVzdHJveWVkO1xuICB9LFxuICBzZXQ6IGZ1bmN0aW9uIHNldCh2YWx1ZSkge1xuICAgIC8vIHdlIGlnbm9yZSB0aGUgdmFsdWUgaWYgdGhlIHN0cmVhbVxuICAgIC8vIGhhcyBub3QgYmVlbiBpbml0aWFsaXplZCB5ZXRcbiAgICBpZiAoIXRoaXMuX3dyaXRhYmxlU3RhdGUpIHtcbiAgICAgIHJldHVybjtcbiAgICB9IC8vIGJhY2t3YXJkIGNvbXBhdGliaWxpdHksIHRoZSB1c2VyIGlzIGV4cGxpY2l0bHlcbiAgICAvLyBtYW5hZ2luZyBkZXN0cm95ZWRcblxuXG4gICAgdGhpcy5fd3JpdGFibGVTdGF0ZS5kZXN0cm95ZWQgPSB2YWx1ZTtcbiAgfVxufSk7XG5Xcml0YWJsZS5wcm90b3R5cGUuZGVzdHJveSA9IGRlc3Ryb3lJbXBsLmRlc3Ryb3k7XG5Xcml0YWJsZS5wcm90b3R5cGUuX3VuZGVzdHJveSA9IGRlc3Ryb3lJbXBsLnVuZGVzdHJveTtcblxuV3JpdGFibGUucHJvdG90eXBlLl9kZXN0cm95ID0gZnVuY3Rpb24gKGVyciwgY2IpIHtcbiAgY2IoZXJyKTtcbn07IiwiJ3VzZSBzdHJpY3QnO1xuXG52YXIgX09iamVjdCRzZXRQcm90b3R5cGVPO1xuXG5mdW5jdGlvbiBfZGVmaW5lUHJvcGVydHkob2JqLCBrZXksIHZhbHVlKSB7IGlmIChrZXkgaW4gb2JqKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmosIGtleSwgeyB2YWx1ZTogdmFsdWUsIGVudW1lcmFibGU6IHRydWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSwgd3JpdGFibGU6IHRydWUgfSk7IH0gZWxzZSB7IG9ialtrZXldID0gdmFsdWU7IH0gcmV0dXJuIG9iajsgfVxuXG52YXIgZmluaXNoZWQgPSByZXF1aXJlKCcuL2VuZC1vZi1zdHJlYW0nKTtcblxudmFyIGtMYXN0UmVzb2x2ZSA9IFN5bWJvbCgnbGFzdFJlc29sdmUnKTtcbnZhciBrTGFzdFJlamVjdCA9IFN5bWJvbCgnbGFzdFJlamVjdCcpO1xudmFyIGtFcnJvciA9IFN5bWJvbCgnZXJyb3InKTtcbnZhciBrRW5kZWQgPSBTeW1ib2woJ2VuZGVkJyk7XG52YXIga0xhc3RQcm9taXNlID0gU3ltYm9sKCdsYXN0UHJvbWlzZScpO1xudmFyIGtIYW5kbGVQcm9taXNlID0gU3ltYm9sKCdoYW5kbGVQcm9taXNlJyk7XG52YXIga1N0cmVhbSA9IFN5bWJvbCgnc3RyZWFtJyk7XG5cbmZ1bmN0aW9uIGNyZWF0ZUl0ZXJSZXN1bHQodmFsdWUsIGRvbmUpIHtcbiAgcmV0dXJuIHtcbiAgICB2YWx1ZTogdmFsdWUsXG4gICAgZG9uZTogZG9uZVxuICB9O1xufVxuXG5mdW5jdGlvbiByZWFkQW5kUmVzb2x2ZShpdGVyKSB7XG4gIHZhciByZXNvbHZlID0gaXRlcltrTGFzdFJlc29sdmVdO1xuXG4gIGlmIChyZXNvbHZlICE9PSBudWxsKSB7XG4gICAgdmFyIGRhdGEgPSBpdGVyW2tTdHJlYW1dLnJlYWQoKTsgLy8gd2UgZGVmZXIgaWYgZGF0YSBpcyBudWxsXG4gICAgLy8gd2UgY2FuIGJlIGV4cGVjdGluZyBlaXRoZXIgJ2VuZCcgb3JcbiAgICAvLyAnZXJyb3InXG5cbiAgICBpZiAoZGF0YSAhPT0gbnVsbCkge1xuICAgICAgaXRlcltrTGFzdFByb21pc2VdID0gbnVsbDtcbiAgICAgIGl0ZXJba0xhc3RSZXNvbHZlXSA9IG51bGw7XG4gICAgICBpdGVyW2tMYXN0UmVqZWN0XSA9IG51bGw7XG4gICAgICByZXNvbHZlKGNyZWF0ZUl0ZXJSZXN1bHQoZGF0YSwgZmFsc2UpKTtcbiAgICB9XG4gIH1cbn1cblxuZnVuY3Rpb24gb25SZWFkYWJsZShpdGVyKSB7XG4gIC8vIHdlIHdhaXQgZm9yIHRoZSBuZXh0IHRpY2ssIGJlY2F1c2UgaXQgbWlnaHRcbiAgLy8gZW1pdCBhbiBlcnJvciB3aXRoIHByb2Nlc3MubmV4dFRpY2tcbiAgcHJvY2Vzcy5uZXh0VGljayhyZWFkQW5kUmVzb2x2ZSwgaXRlcik7XG59XG5cbmZ1bmN0aW9uIHdyYXBGb3JOZXh0KGxhc3RQcm9taXNlLCBpdGVyKSB7XG4gIHJldHVybiBmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgbGFzdFByb21pc2UudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICBpZiAoaXRlcltrRW5kZWRdKSB7XG4gICAgICAgIHJlc29sdmUoY3JlYXRlSXRlclJlc3VsdCh1bmRlZmluZWQsIHRydWUpKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBpdGVyW2tIYW5kbGVQcm9taXNlXShyZXNvbHZlLCByZWplY3QpO1xuICAgIH0sIHJlamVjdCk7XG4gIH07XG59XG5cbnZhciBBc3luY0l0ZXJhdG9yUHJvdG90eXBlID0gT2JqZWN0LmdldFByb3RvdHlwZU9mKGZ1bmN0aW9uICgpIHt9KTtcbnZhciBSZWFkYWJsZVN0cmVhbUFzeW5jSXRlcmF0b3JQcm90b3R5cGUgPSBPYmplY3Quc2V0UHJvdG90eXBlT2YoKF9PYmplY3Qkc2V0UHJvdG90eXBlTyA9IHtcbiAgZ2V0IHN0cmVhbSgpIHtcbiAgICByZXR1cm4gdGhpc1trU3RyZWFtXTtcbiAgfSxcblxuICBuZXh0OiBmdW5jdGlvbiBuZXh0KCkge1xuICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICAvLyBpZiB3ZSBoYXZlIGRldGVjdGVkIGFuIGVycm9yIGluIHRoZSBtZWFud2hpbGVcbiAgICAvLyByZWplY3Qgc3RyYWlnaHQgYXdheVxuICAgIHZhciBlcnJvciA9IHRoaXNba0Vycm9yXTtcblxuICAgIGlmIChlcnJvciAhPT0gbnVsbCkge1xuICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcbiAgICB9XG5cbiAgICBpZiAodGhpc1trRW5kZWRdKSB7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGNyZWF0ZUl0ZXJSZXN1bHQodW5kZWZpbmVkLCB0cnVlKSk7XG4gICAgfVxuXG4gICAgaWYgKHRoaXNba1N0cmVhbV0uZGVzdHJveWVkKSB7XG4gICAgICAvLyBXZSBuZWVkIHRvIGRlZmVyIHZpYSBuZXh0VGljayBiZWNhdXNlIGlmIC5kZXN0cm95KGVycikgaXNcbiAgICAgIC8vIGNhbGxlZCwgdGhlIGVycm9yIHdpbGwgYmUgZW1pdHRlZCB2aWEgbmV4dFRpY2ssIGFuZFxuICAgICAgLy8gd2UgY2Fubm90IGd1YXJhbnRlZSB0aGF0IHRoZXJlIGlzIG5vIGVycm9yIGxpbmdlcmluZyBhcm91bmRcbiAgICAgIC8vIHdhaXRpbmcgdG8gYmUgZW1pdHRlZC5cbiAgICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgIHByb2Nlc3MubmV4dFRpY2soZnVuY3Rpb24gKCkge1xuICAgICAgICAgIGlmIChfdGhpc1trRXJyb3JdKSB7XG4gICAgICAgICAgICByZWplY3QoX3RoaXNba0Vycm9yXSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJlc29sdmUoY3JlYXRlSXRlclJlc3VsdCh1bmRlZmluZWQsIHRydWUpKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfSAvLyBpZiB3ZSBoYXZlIG11bHRpcGxlIG5leHQoKSBjYWxsc1xuICAgIC8vIHdlIHdpbGwgd2FpdCBmb3IgdGhlIHByZXZpb3VzIFByb21pc2UgdG8gZmluaXNoXG4gICAgLy8gdGhpcyBsb2dpYyBpcyBvcHRpbWl6ZWQgdG8gc3VwcG9ydCBmb3IgYXdhaXQgbG9vcHMsXG4gICAgLy8gd2hlcmUgbmV4dCgpIGlzIG9ubHkgY2FsbGVkIG9uY2UgYXQgYSB0aW1lXG5cblxuICAgIHZhciBsYXN0UHJvbWlzZSA9IHRoaXNba0xhc3RQcm9taXNlXTtcbiAgICB2YXIgcHJvbWlzZTtcblxuICAgIGlmIChsYXN0UHJvbWlzZSkge1xuICAgICAgcHJvbWlzZSA9IG5ldyBQcm9taXNlKHdyYXBGb3JOZXh0KGxhc3RQcm9taXNlLCB0aGlzKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIGZhc3QgcGF0aCBuZWVkZWQgdG8gc3VwcG9ydCBtdWx0aXBsZSB0aGlzLnB1c2goKVxuICAgICAgLy8gd2l0aG91dCB0cmlnZ2VyaW5nIHRoZSBuZXh0KCkgcXVldWVcbiAgICAgIHZhciBkYXRhID0gdGhpc1trU3RyZWFtXS5yZWFkKCk7XG5cbiAgICAgIGlmIChkYXRhICE9PSBudWxsKSB7XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoY3JlYXRlSXRlclJlc3VsdChkYXRhLCBmYWxzZSkpO1xuICAgICAgfVxuXG4gICAgICBwcm9taXNlID0gbmV3IFByb21pc2UodGhpc1trSGFuZGxlUHJvbWlzZV0pO1xuICAgIH1cblxuICAgIHRoaXNba0xhc3RQcm9taXNlXSA9IHByb21pc2U7XG4gICAgcmV0dXJuIHByb21pc2U7XG4gIH1cbn0sIF9kZWZpbmVQcm9wZXJ0eShfT2JqZWN0JHNldFByb3RvdHlwZU8sIFN5bWJvbC5hc3luY0l0ZXJhdG9yLCBmdW5jdGlvbiAoKSB7XG4gIHJldHVybiB0aGlzO1xufSksIF9kZWZpbmVQcm9wZXJ0eShfT2JqZWN0JHNldFByb3RvdHlwZU8sIFwicmV0dXJuXCIsIGZ1bmN0aW9uIF9yZXR1cm4oKSB7XG4gIHZhciBfdGhpczIgPSB0aGlzO1xuXG4gIC8vIGRlc3Ryb3koZXJyLCBjYikgaXMgYSBwcml2YXRlIEFQSVxuICAvLyB3ZSBjYW4gZ3VhcmFudGVlIHdlIGhhdmUgdGhhdCBoZXJlLCBiZWNhdXNlIHdlIGNvbnRyb2wgdGhlXG4gIC8vIFJlYWRhYmxlIGNsYXNzIHRoaXMgaXMgYXR0YWNoZWQgdG9cbiAgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICBfdGhpczJba1N0cmVhbV0uZGVzdHJveShudWxsLCBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICBpZiAoZXJyKSB7XG4gICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIHJlc29sdmUoY3JlYXRlSXRlclJlc3VsdCh1bmRlZmluZWQsIHRydWUpKTtcbiAgICB9KTtcbiAgfSk7XG59KSwgX09iamVjdCRzZXRQcm90b3R5cGVPKSwgQXN5bmNJdGVyYXRvclByb3RvdHlwZSk7XG5cbnZhciBjcmVhdGVSZWFkYWJsZVN0cmVhbUFzeW5jSXRlcmF0b3IgPSBmdW5jdGlvbiBjcmVhdGVSZWFkYWJsZVN0cmVhbUFzeW5jSXRlcmF0b3Ioc3RyZWFtKSB7XG4gIHZhciBfT2JqZWN0JGNyZWF0ZTtcblxuICB2YXIgaXRlcmF0b3IgPSBPYmplY3QuY3JlYXRlKFJlYWRhYmxlU3RyZWFtQXN5bmNJdGVyYXRvclByb3RvdHlwZSwgKF9PYmplY3QkY3JlYXRlID0ge30sIF9kZWZpbmVQcm9wZXJ0eShfT2JqZWN0JGNyZWF0ZSwga1N0cmVhbSwge1xuICAgIHZhbHVlOiBzdHJlYW0sXG4gICAgd3JpdGFibGU6IHRydWVcbiAgfSksIF9kZWZpbmVQcm9wZXJ0eShfT2JqZWN0JGNyZWF0ZSwga0xhc3RSZXNvbHZlLCB7XG4gICAgdmFsdWU6IG51bGwsXG4gICAgd3JpdGFibGU6IHRydWVcbiAgfSksIF9kZWZpbmVQcm9wZXJ0eShfT2JqZWN0JGNyZWF0ZSwga0xhc3RSZWplY3QsIHtcbiAgICB2YWx1ZTogbnVsbCxcbiAgICB3cml0YWJsZTogdHJ1ZVxuICB9KSwgX2RlZmluZVByb3BlcnR5KF9PYmplY3QkY3JlYXRlLCBrRXJyb3IsIHtcbiAgICB2YWx1ZTogbnVsbCxcbiAgICB3cml0YWJsZTogdHJ1ZVxuICB9KSwgX2RlZmluZVByb3BlcnR5KF9PYmplY3QkY3JlYXRlLCBrRW5kZWQsIHtcbiAgICB2YWx1ZTogc3RyZWFtLl9yZWFkYWJsZVN0YXRlLmVuZEVtaXR0ZWQsXG4gICAgd3JpdGFibGU6IHRydWVcbiAgfSksIF9kZWZpbmVQcm9wZXJ0eShfT2JqZWN0JGNyZWF0ZSwga0hhbmRsZVByb21pc2UsIHtcbiAgICB2YWx1ZTogZnVuY3Rpb24gdmFsdWUocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICB2YXIgZGF0YSA9IGl0ZXJhdG9yW2tTdHJlYW1dLnJlYWQoKTtcblxuICAgICAgaWYgKGRhdGEpIHtcbiAgICAgICAgaXRlcmF0b3Jba0xhc3RQcm9taXNlXSA9IG51bGw7XG4gICAgICAgIGl0ZXJhdG9yW2tMYXN0UmVzb2x2ZV0gPSBudWxsO1xuICAgICAgICBpdGVyYXRvcltrTGFzdFJlamVjdF0gPSBudWxsO1xuICAgICAgICByZXNvbHZlKGNyZWF0ZUl0ZXJSZXN1bHQoZGF0YSwgZmFsc2UpKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGl0ZXJhdG9yW2tMYXN0UmVzb2x2ZV0gPSByZXNvbHZlO1xuICAgICAgICBpdGVyYXRvcltrTGFzdFJlamVjdF0gPSByZWplY3Q7XG4gICAgICB9XG4gICAgfSxcbiAgICB3cml0YWJsZTogdHJ1ZVxuICB9KSwgX09iamVjdCRjcmVhdGUpKTtcbiAgaXRlcmF0b3Jba0xhc3RQcm9taXNlXSA9IG51bGw7XG4gIGZpbmlzaGVkKHN0cmVhbSwgZnVuY3Rpb24gKGVycikge1xuICAgIGlmIChlcnIgJiYgZXJyLmNvZGUgIT09ICdFUlJfU1RSRUFNX1BSRU1BVFVSRV9DTE9TRScpIHtcbiAgICAgIHZhciByZWplY3QgPSBpdGVyYXRvcltrTGFzdFJlamVjdF07IC8vIHJlamVjdCBpZiB3ZSBhcmUgd2FpdGluZyBmb3IgZGF0YSBpbiB0aGUgUHJvbWlzZVxuICAgICAgLy8gcmV0dXJuZWQgYnkgbmV4dCgpIGFuZCBzdG9yZSB0aGUgZXJyb3JcblxuICAgICAgaWYgKHJlamVjdCAhPT0gbnVsbCkge1xuICAgICAgICBpdGVyYXRvcltrTGFzdFByb21pc2VdID0gbnVsbDtcbiAgICAgICAgaXRlcmF0b3Jba0xhc3RSZXNvbHZlXSA9IG51bGw7XG4gICAgICAgIGl0ZXJhdG9yW2tMYXN0UmVqZWN0XSA9IG51bGw7XG4gICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgfVxuXG4gICAgICBpdGVyYXRvcltrRXJyb3JdID0gZXJyO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHZhciByZXNvbHZlID0gaXRlcmF0b3Jba0xhc3RSZXNvbHZlXTtcblxuICAgIGlmIChyZXNvbHZlICE9PSBudWxsKSB7XG4gICAgICBpdGVyYXRvcltrTGFzdFByb21pc2VdID0gbnVsbDtcbiAgICAgIGl0ZXJhdG9yW2tMYXN0UmVzb2x2ZV0gPSBudWxsO1xuICAgICAgaXRlcmF0b3Jba0xhc3RSZWplY3RdID0gbnVsbDtcbiAgICAgIHJlc29sdmUoY3JlYXRlSXRlclJlc3VsdCh1bmRlZmluZWQsIHRydWUpKTtcbiAgICB9XG5cbiAgICBpdGVyYXRvcltrRW5kZWRdID0gdHJ1ZTtcbiAgfSk7XG4gIHN0cmVhbS5vbigncmVhZGFibGUnLCBvblJlYWRhYmxlLmJpbmQobnVsbCwgaXRlcmF0b3IpKTtcbiAgcmV0dXJuIGl0ZXJhdG9yO1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSBjcmVhdGVSZWFkYWJsZVN0cmVhbUFzeW5jSXRlcmF0b3I7IiwiJ3VzZSBzdHJpY3QnO1xuXG5mdW5jdGlvbiBvd25LZXlzKG9iamVjdCwgZW51bWVyYWJsZU9ubHkpIHsgdmFyIGtleXMgPSBPYmplY3Qua2V5cyhvYmplY3QpOyBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykgeyB2YXIgc3ltYm9scyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMob2JqZWN0KTsgaWYgKGVudW1lcmFibGVPbmx5KSBzeW1ib2xzID0gc3ltYm9scy5maWx0ZXIoZnVuY3Rpb24gKHN5bSkgeyByZXR1cm4gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihvYmplY3QsIHN5bSkuZW51bWVyYWJsZTsgfSk7IGtleXMucHVzaC5hcHBseShrZXlzLCBzeW1ib2xzKTsgfSByZXR1cm4ga2V5czsgfVxuXG5mdW5jdGlvbiBfb2JqZWN0U3ByZWFkKHRhcmdldCkgeyBmb3IgKHZhciBpID0gMTsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7IGkrKykgeyB2YXIgc291cmNlID0gYXJndW1lbnRzW2ldICE9IG51bGwgPyBhcmd1bWVudHNbaV0gOiB7fTsgaWYgKGkgJSAyKSB7IG93bktleXMoT2JqZWN0KHNvdXJjZSksIHRydWUpLmZvckVhY2goZnVuY3Rpb24gKGtleSkgeyBfZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBrZXksIHNvdXJjZVtrZXldKTsgfSk7IH0gZWxzZSBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMpIHsgT2JqZWN0LmRlZmluZVByb3BlcnRpZXModGFyZ2V0LCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyhzb3VyY2UpKTsgfSBlbHNlIHsgb3duS2V5cyhPYmplY3Qoc291cmNlKSkuZm9yRWFjaChmdW5jdGlvbiAoa2V5KSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGtleSwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihzb3VyY2UsIGtleSkpOyB9KTsgfSB9IHJldHVybiB0YXJnZXQ7IH1cblxuZnVuY3Rpb24gX2RlZmluZVByb3BlcnR5KG9iaiwga2V5LCB2YWx1ZSkgeyBpZiAoa2V5IGluIG9iaikgeyBPYmplY3QuZGVmaW5lUHJvcGVydHkob2JqLCBrZXksIHsgdmFsdWU6IHZhbHVlLCBlbnVtZXJhYmxlOiB0cnVlLCBjb25maWd1cmFibGU6IHRydWUsIHdyaXRhYmxlOiB0cnVlIH0pOyB9IGVsc2UgeyBvYmpba2V5XSA9IHZhbHVlOyB9IHJldHVybiBvYmo7IH1cblxuZnVuY3Rpb24gX2NsYXNzQ2FsbENoZWNrKGluc3RhbmNlLCBDb25zdHJ1Y3RvcikgeyBpZiAoIShpbnN0YW5jZSBpbnN0YW5jZW9mIENvbnN0cnVjdG9yKSkgeyB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2Fubm90IGNhbGwgYSBjbGFzcyBhcyBhIGZ1bmN0aW9uXCIpOyB9IH1cblxuZnVuY3Rpb24gX2RlZmluZVByb3BlcnRpZXModGFyZ2V0LCBwcm9wcykgeyBmb3IgKHZhciBpID0gMDsgaSA8IHByb3BzLmxlbmd0aDsgaSsrKSB7IHZhciBkZXNjcmlwdG9yID0gcHJvcHNbaV07IGRlc2NyaXB0b3IuZW51bWVyYWJsZSA9IGRlc2NyaXB0b3IuZW51bWVyYWJsZSB8fCBmYWxzZTsgZGVzY3JpcHRvci5jb25maWd1cmFibGUgPSB0cnVlOyBpZiAoXCJ2YWx1ZVwiIGluIGRlc2NyaXB0b3IpIGRlc2NyaXB0b3Iud3JpdGFibGUgPSB0cnVlOyBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBkZXNjcmlwdG9yLmtleSwgZGVzY3JpcHRvcik7IH0gfVxuXG5mdW5jdGlvbiBfY3JlYXRlQ2xhc3MoQ29uc3RydWN0b3IsIHByb3RvUHJvcHMsIHN0YXRpY1Byb3BzKSB7IGlmIChwcm90b1Byb3BzKSBfZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvci5wcm90b3R5cGUsIHByb3RvUHJvcHMpOyBpZiAoc3RhdGljUHJvcHMpIF9kZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLCBzdGF0aWNQcm9wcyk7IHJldHVybiBDb25zdHJ1Y3RvcjsgfVxuXG52YXIgX3JlcXVpcmUgPSByZXF1aXJlKCdidWZmZXInKSxcbiAgICBCdWZmZXIgPSBfcmVxdWlyZS5CdWZmZXI7XG5cbnZhciBfcmVxdWlyZTIgPSByZXF1aXJlKCd1dGlsJyksXG4gICAgaW5zcGVjdCA9IF9yZXF1aXJlMi5pbnNwZWN0O1xuXG52YXIgY3VzdG9tID0gaW5zcGVjdCAmJiBpbnNwZWN0LmN1c3RvbSB8fCAnaW5zcGVjdCc7XG5cbmZ1bmN0aW9uIGNvcHlCdWZmZXIoc3JjLCB0YXJnZXQsIG9mZnNldCkge1xuICBCdWZmZXIucHJvdG90eXBlLmNvcHkuY2FsbChzcmMsIHRhcmdldCwgb2Zmc2V0KTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPVxuLyojX19QVVJFX18qL1xuZnVuY3Rpb24gKCkge1xuICBmdW5jdGlvbiBCdWZmZXJMaXN0KCkge1xuICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBCdWZmZXJMaXN0KTtcblxuICAgIHRoaXMuaGVhZCA9IG51bGw7XG4gICAgdGhpcy50YWlsID0gbnVsbDtcbiAgICB0aGlzLmxlbmd0aCA9IDA7XG4gIH1cblxuICBfY3JlYXRlQ2xhc3MoQnVmZmVyTGlzdCwgW3tcbiAgICBrZXk6IFwicHVzaFwiLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBwdXNoKHYpIHtcbiAgICAgIHZhciBlbnRyeSA9IHtcbiAgICAgICAgZGF0YTogdixcbiAgICAgICAgbmV4dDogbnVsbFxuICAgICAgfTtcbiAgICAgIGlmICh0aGlzLmxlbmd0aCA+IDApIHRoaXMudGFpbC5uZXh0ID0gZW50cnk7ZWxzZSB0aGlzLmhlYWQgPSBlbnRyeTtcbiAgICAgIHRoaXMudGFpbCA9IGVudHJ5O1xuICAgICAgKyt0aGlzLmxlbmd0aDtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6IFwidW5zaGlmdFwiLFxuICAgIHZhbHVlOiBmdW5jdGlvbiB1bnNoaWZ0KHYpIHtcbiAgICAgIHZhciBlbnRyeSA9IHtcbiAgICAgICAgZGF0YTogdixcbiAgICAgICAgbmV4dDogdGhpcy5oZWFkXG4gICAgICB9O1xuICAgICAgaWYgKHRoaXMubGVuZ3RoID09PSAwKSB0aGlzLnRhaWwgPSBlbnRyeTtcbiAgICAgIHRoaXMuaGVhZCA9IGVudHJ5O1xuICAgICAgKyt0aGlzLmxlbmd0aDtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6IFwic2hpZnRcIixcbiAgICB2YWx1ZTogZnVuY3Rpb24gc2hpZnQoKSB7XG4gICAgICBpZiAodGhpcy5sZW5ndGggPT09IDApIHJldHVybjtcbiAgICAgIHZhciByZXQgPSB0aGlzLmhlYWQuZGF0YTtcbiAgICAgIGlmICh0aGlzLmxlbmd0aCA9PT0gMSkgdGhpcy5oZWFkID0gdGhpcy50YWlsID0gbnVsbDtlbHNlIHRoaXMuaGVhZCA9IHRoaXMuaGVhZC5uZXh0O1xuICAgICAgLS10aGlzLmxlbmd0aDtcbiAgICAgIHJldHVybiByZXQ7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiBcImNsZWFyXCIsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGNsZWFyKCkge1xuICAgICAgdGhpcy5oZWFkID0gdGhpcy50YWlsID0gbnVsbDtcbiAgICAgIHRoaXMubGVuZ3RoID0gMDtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6IFwiam9pblwiLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBqb2luKHMpIHtcbiAgICAgIGlmICh0aGlzLmxlbmd0aCA9PT0gMCkgcmV0dXJuICcnO1xuICAgICAgdmFyIHAgPSB0aGlzLmhlYWQ7XG4gICAgICB2YXIgcmV0ID0gJycgKyBwLmRhdGE7XG5cbiAgICAgIHdoaWxlIChwID0gcC5uZXh0KSB7XG4gICAgICAgIHJldCArPSBzICsgcC5kYXRhO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gcmV0O1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogXCJjb25jYXRcIixcbiAgICB2YWx1ZTogZnVuY3Rpb24gY29uY2F0KG4pIHtcbiAgICAgIGlmICh0aGlzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIEJ1ZmZlci5hbGxvYygwKTtcbiAgICAgIHZhciByZXQgPSBCdWZmZXIuYWxsb2NVbnNhZmUobiA+Pj4gMCk7XG4gICAgICB2YXIgcCA9IHRoaXMuaGVhZDtcbiAgICAgIHZhciBpID0gMDtcblxuICAgICAgd2hpbGUgKHApIHtcbiAgICAgICAgY29weUJ1ZmZlcihwLmRhdGEsIHJldCwgaSk7XG4gICAgICAgIGkgKz0gcC5kYXRhLmxlbmd0aDtcbiAgICAgICAgcCA9IHAubmV4dDtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHJldDtcbiAgICB9IC8vIENvbnN1bWVzIGEgc3BlY2lmaWVkIGFtb3VudCBvZiBieXRlcyBvciBjaGFyYWN0ZXJzIGZyb20gdGhlIGJ1ZmZlcmVkIGRhdGEuXG5cbiAgfSwge1xuICAgIGtleTogXCJjb25zdW1lXCIsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGNvbnN1bWUobiwgaGFzU3RyaW5ncykge1xuICAgICAgdmFyIHJldDtcblxuICAgICAgaWYgKG4gPCB0aGlzLmhlYWQuZGF0YS5sZW5ndGgpIHtcbiAgICAgICAgLy8gYHNsaWNlYCBpcyB0aGUgc2FtZSBmb3IgYnVmZmVycyBhbmQgc3RyaW5ncy5cbiAgICAgICAgcmV0ID0gdGhpcy5oZWFkLmRhdGEuc2xpY2UoMCwgbik7XG4gICAgICAgIHRoaXMuaGVhZC5kYXRhID0gdGhpcy5oZWFkLmRhdGEuc2xpY2Uobik7XG4gICAgICB9IGVsc2UgaWYgKG4gPT09IHRoaXMuaGVhZC5kYXRhLmxlbmd0aCkge1xuICAgICAgICAvLyBGaXJzdCBjaHVuayBpcyBhIHBlcmZlY3QgbWF0Y2guXG4gICAgICAgIHJldCA9IHRoaXMuc2hpZnQoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIFJlc3VsdCBzcGFucyBtb3JlIHRoYW4gb25lIGJ1ZmZlci5cbiAgICAgICAgcmV0ID0gaGFzU3RyaW5ncyA/IHRoaXMuX2dldFN0cmluZyhuKSA6IHRoaXMuX2dldEJ1ZmZlcihuKTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHJldDtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6IFwiZmlyc3RcIixcbiAgICB2YWx1ZTogZnVuY3Rpb24gZmlyc3QoKSB7XG4gICAgICByZXR1cm4gdGhpcy5oZWFkLmRhdGE7XG4gICAgfSAvLyBDb25zdW1lcyBhIHNwZWNpZmllZCBhbW91bnQgb2YgY2hhcmFjdGVycyBmcm9tIHRoZSBidWZmZXJlZCBkYXRhLlxuXG4gIH0sIHtcbiAgICBrZXk6IFwiX2dldFN0cmluZ1wiLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBfZ2V0U3RyaW5nKG4pIHtcbiAgICAgIHZhciBwID0gdGhpcy5oZWFkO1xuICAgICAgdmFyIGMgPSAxO1xuICAgICAgdmFyIHJldCA9IHAuZGF0YTtcbiAgICAgIG4gLT0gcmV0Lmxlbmd0aDtcblxuICAgICAgd2hpbGUgKHAgPSBwLm5leHQpIHtcbiAgICAgICAgdmFyIHN0ciA9IHAuZGF0YTtcbiAgICAgICAgdmFyIG5iID0gbiA+IHN0ci5sZW5ndGggPyBzdHIubGVuZ3RoIDogbjtcbiAgICAgICAgaWYgKG5iID09PSBzdHIubGVuZ3RoKSByZXQgKz0gc3RyO2Vsc2UgcmV0ICs9IHN0ci5zbGljZSgwLCBuKTtcbiAgICAgICAgbiAtPSBuYjtcblxuICAgICAgICBpZiAobiA9PT0gMCkge1xuICAgICAgICAgIGlmIChuYiA9PT0gc3RyLmxlbmd0aCkge1xuICAgICAgICAgICAgKytjO1xuICAgICAgICAgICAgaWYgKHAubmV4dCkgdGhpcy5oZWFkID0gcC5uZXh0O2Vsc2UgdGhpcy5oZWFkID0gdGhpcy50YWlsID0gbnVsbDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5oZWFkID0gcDtcbiAgICAgICAgICAgIHAuZGF0YSA9IHN0ci5zbGljZShuYik7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cblxuICAgICAgICArK2M7XG4gICAgICB9XG5cbiAgICAgIHRoaXMubGVuZ3RoIC09IGM7XG4gICAgICByZXR1cm4gcmV0O1xuICAgIH0gLy8gQ29uc3VtZXMgYSBzcGVjaWZpZWQgYW1vdW50IG9mIGJ5dGVzIGZyb20gdGhlIGJ1ZmZlcmVkIGRhdGEuXG5cbiAgfSwge1xuICAgIGtleTogXCJfZ2V0QnVmZmVyXCIsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIF9nZXRCdWZmZXIobikge1xuICAgICAgdmFyIHJldCA9IEJ1ZmZlci5hbGxvY1Vuc2FmZShuKTtcbiAgICAgIHZhciBwID0gdGhpcy5oZWFkO1xuICAgICAgdmFyIGMgPSAxO1xuICAgICAgcC5kYXRhLmNvcHkocmV0KTtcbiAgICAgIG4gLT0gcC5kYXRhLmxlbmd0aDtcblxuICAgICAgd2hpbGUgKHAgPSBwLm5leHQpIHtcbiAgICAgICAgdmFyIGJ1ZiA9IHAuZGF0YTtcbiAgICAgICAgdmFyIG5iID0gbiA+IGJ1Zi5sZW5ndGggPyBidWYubGVuZ3RoIDogbjtcbiAgICAgICAgYnVmLmNvcHkocmV0LCByZXQubGVuZ3RoIC0gbiwgMCwgbmIpO1xuICAgICAgICBuIC09IG5iO1xuXG4gICAgICAgIGlmIChuID09PSAwKSB7XG4gICAgICAgICAgaWYgKG5iID09PSBidWYubGVuZ3RoKSB7XG4gICAgICAgICAgICArK2M7XG4gICAgICAgICAgICBpZiAocC5uZXh0KSB0aGlzLmhlYWQgPSBwLm5leHQ7ZWxzZSB0aGlzLmhlYWQgPSB0aGlzLnRhaWwgPSBudWxsO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmhlYWQgPSBwO1xuICAgICAgICAgICAgcC5kYXRhID0gYnVmLnNsaWNlKG5iKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuXG4gICAgICAgICsrYztcbiAgICAgIH1cblxuICAgICAgdGhpcy5sZW5ndGggLT0gYztcbiAgICAgIHJldHVybiByZXQ7XG4gICAgfSAvLyBNYWtlIHN1cmUgdGhlIGxpbmtlZCBsaXN0IG9ubHkgc2hvd3MgdGhlIG1pbmltYWwgbmVjZXNzYXJ5IGluZm9ybWF0aW9uLlxuXG4gIH0sIHtcbiAgICBrZXk6IGN1c3RvbSxcbiAgICB2YWx1ZTogZnVuY3Rpb24gdmFsdWUoXywgb3B0aW9ucykge1xuICAgICAgcmV0dXJuIGluc3BlY3QodGhpcywgX29iamVjdFNwcmVhZCh7fSwgb3B0aW9ucywge1xuICAgICAgICAvLyBPbmx5IGluc3BlY3Qgb25lIGxldmVsLlxuICAgICAgICBkZXB0aDogMCxcbiAgICAgICAgLy8gSXQgc2hvdWxkIG5vdCByZWN1cnNlLlxuICAgICAgICBjdXN0b21JbnNwZWN0OiBmYWxzZVxuICAgICAgfSkpO1xuICAgIH1cbiAgfV0pO1xuXG4gIHJldHVybiBCdWZmZXJMaXN0O1xufSgpOyIsIid1c2Ugc3RyaWN0JzsgLy8gdW5kb2N1bWVudGVkIGNiKCkgQVBJLCBuZWVkZWQgZm9yIGNvcmUsIG5vdCBmb3IgcHVibGljIEFQSVxuXG5mdW5jdGlvbiBkZXN0cm95KGVyciwgY2IpIHtcbiAgdmFyIF90aGlzID0gdGhpcztcblxuICB2YXIgcmVhZGFibGVEZXN0cm95ZWQgPSB0aGlzLl9yZWFkYWJsZVN0YXRlICYmIHRoaXMuX3JlYWRhYmxlU3RhdGUuZGVzdHJveWVkO1xuICB2YXIgd3JpdGFibGVEZXN0cm95ZWQgPSB0aGlzLl93cml0YWJsZVN0YXRlICYmIHRoaXMuX3dyaXRhYmxlU3RhdGUuZGVzdHJveWVkO1xuXG4gIGlmIChyZWFkYWJsZURlc3Ryb3llZCB8fCB3cml0YWJsZURlc3Ryb3llZCkge1xuICAgIGlmIChjYikge1xuICAgICAgY2IoZXJyKTtcbiAgICB9IGVsc2UgaWYgKGVycikge1xuICAgICAgaWYgKCF0aGlzLl93cml0YWJsZVN0YXRlKSB7XG4gICAgICAgIHByb2Nlc3MubmV4dFRpY2soZW1pdEVycm9yTlQsIHRoaXMsIGVycik7XG4gICAgICB9IGVsc2UgaWYgKCF0aGlzLl93cml0YWJsZVN0YXRlLmVycm9yRW1pdHRlZCkge1xuICAgICAgICB0aGlzLl93cml0YWJsZVN0YXRlLmVycm9yRW1pdHRlZCA9IHRydWU7XG4gICAgICAgIHByb2Nlc3MubmV4dFRpY2soZW1pdEVycm9yTlQsIHRoaXMsIGVycik7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXM7XG4gIH0gLy8gd2Ugc2V0IGRlc3Ryb3llZCB0byB0cnVlIGJlZm9yZSBmaXJpbmcgZXJyb3IgY2FsbGJhY2tzIGluIG9yZGVyXG4gIC8vIHRvIG1ha2UgaXQgcmUtZW50cmFuY2Ugc2FmZSBpbiBjYXNlIGRlc3Ryb3koKSBpcyBjYWxsZWQgd2l0aGluIGNhbGxiYWNrc1xuXG5cbiAgaWYgKHRoaXMuX3JlYWRhYmxlU3RhdGUpIHtcbiAgICB0aGlzLl9yZWFkYWJsZVN0YXRlLmRlc3Ryb3llZCA9IHRydWU7XG4gIH0gLy8gaWYgdGhpcyBpcyBhIGR1cGxleCBzdHJlYW0gbWFyayB0aGUgd3JpdGFibGUgcGFydCBhcyBkZXN0cm95ZWQgYXMgd2VsbFxuXG5cbiAgaWYgKHRoaXMuX3dyaXRhYmxlU3RhdGUpIHtcbiAgICB0aGlzLl93cml0YWJsZVN0YXRlLmRlc3Ryb3llZCA9IHRydWU7XG4gIH1cblxuICB0aGlzLl9kZXN0cm95KGVyciB8fCBudWxsLCBmdW5jdGlvbiAoZXJyKSB7XG4gICAgaWYgKCFjYiAmJiBlcnIpIHtcbiAgICAgIGlmICghX3RoaXMuX3dyaXRhYmxlU3RhdGUpIHtcbiAgICAgICAgcHJvY2Vzcy5uZXh0VGljayhlbWl0RXJyb3JBbmRDbG9zZU5ULCBfdGhpcywgZXJyKTtcbiAgICAgIH0gZWxzZSBpZiAoIV90aGlzLl93cml0YWJsZVN0YXRlLmVycm9yRW1pdHRlZCkge1xuICAgICAgICBfdGhpcy5fd3JpdGFibGVTdGF0ZS5lcnJvckVtaXR0ZWQgPSB0cnVlO1xuICAgICAgICBwcm9jZXNzLm5leHRUaWNrKGVtaXRFcnJvckFuZENsb3NlTlQsIF90aGlzLCBlcnIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcHJvY2Vzcy5uZXh0VGljayhlbWl0Q2xvc2VOVCwgX3RoaXMpO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoY2IpIHtcbiAgICAgIHByb2Nlc3MubmV4dFRpY2soZW1pdENsb3NlTlQsIF90aGlzKTtcbiAgICAgIGNiKGVycik7XG4gICAgfSBlbHNlIHtcbiAgICAgIHByb2Nlc3MubmV4dFRpY2soZW1pdENsb3NlTlQsIF90aGlzKTtcbiAgICB9XG4gIH0pO1xuXG4gIHJldHVybiB0aGlzO1xufVxuXG5mdW5jdGlvbiBlbWl0RXJyb3JBbmRDbG9zZU5UKHNlbGYsIGVycikge1xuICBlbWl0RXJyb3JOVChzZWxmLCBlcnIpO1xuICBlbWl0Q2xvc2VOVChzZWxmKTtcbn1cblxuZnVuY3Rpb24gZW1pdENsb3NlTlQoc2VsZikge1xuICBpZiAoc2VsZi5fd3JpdGFibGVTdGF0ZSAmJiAhc2VsZi5fd3JpdGFibGVTdGF0ZS5lbWl0Q2xvc2UpIHJldHVybjtcbiAgaWYgKHNlbGYuX3JlYWRhYmxlU3RhdGUgJiYgIXNlbGYuX3JlYWRhYmxlU3RhdGUuZW1pdENsb3NlKSByZXR1cm47XG4gIHNlbGYuZW1pdCgnY2xvc2UnKTtcbn1cblxuZnVuY3Rpb24gdW5kZXN0cm95KCkge1xuICBpZiAodGhpcy5fcmVhZGFibGVTdGF0ZSkge1xuICAgIHRoaXMuX3JlYWRhYmxlU3RhdGUuZGVzdHJveWVkID0gZmFsc2U7XG4gICAgdGhpcy5fcmVhZGFibGVTdGF0ZS5yZWFkaW5nID0gZmFsc2U7XG4gICAgdGhpcy5fcmVhZGFibGVTdGF0ZS5lbmRlZCA9IGZhbHNlO1xuICAgIHRoaXMuX3JlYWRhYmxlU3RhdGUuZW5kRW1pdHRlZCA9IGZhbHNlO1xuICB9XG5cbiAgaWYgKHRoaXMuX3dyaXRhYmxlU3RhdGUpIHtcbiAgICB0aGlzLl93cml0YWJsZVN0YXRlLmRlc3Ryb3llZCA9IGZhbHNlO1xuICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUuZW5kZWQgPSBmYWxzZTtcbiAgICB0aGlzLl93cml0YWJsZVN0YXRlLmVuZGluZyA9IGZhbHNlO1xuICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUuZmluYWxDYWxsZWQgPSBmYWxzZTtcbiAgICB0aGlzLl93cml0YWJsZVN0YXRlLnByZWZpbmlzaGVkID0gZmFsc2U7XG4gICAgdGhpcy5fd3JpdGFibGVTdGF0ZS5maW5pc2hlZCA9IGZhbHNlO1xuICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUuZXJyb3JFbWl0dGVkID0gZmFsc2U7XG4gIH1cbn1cblxuZnVuY3Rpb24gZW1pdEVycm9yTlQoc2VsZiwgZXJyKSB7XG4gIHNlbGYuZW1pdCgnZXJyb3InLCBlcnIpO1xufVxuXG5mdW5jdGlvbiBlcnJvck9yRGVzdHJveShzdHJlYW0sIGVycikge1xuICAvLyBXZSBoYXZlIHRlc3RzIHRoYXQgcmVseSBvbiBlcnJvcnMgYmVpbmcgZW1pdHRlZFxuICAvLyBpbiB0aGUgc2FtZSB0aWNrLCBzbyBjaGFuZ2luZyB0aGlzIGlzIHNlbXZlciBtYWpvci5cbiAgLy8gRm9yIG5vdyB3aGVuIHlvdSBvcHQtaW4gdG8gYXV0b0Rlc3Ryb3kgd2UgYWxsb3dcbiAgLy8gdGhlIGVycm9yIHRvIGJlIGVtaXR0ZWQgbmV4dFRpY2suIEluIGEgZnV0dXJlXG4gIC8vIHNlbXZlciBtYWpvciB1cGRhdGUgd2Ugc2hvdWxkIGNoYW5nZSB0aGUgZGVmYXVsdCB0byB0aGlzLlxuICB2YXIgclN0YXRlID0gc3RyZWFtLl9yZWFkYWJsZVN0YXRlO1xuICB2YXIgd1N0YXRlID0gc3RyZWFtLl93cml0YWJsZVN0YXRlO1xuICBpZiAoclN0YXRlICYmIHJTdGF0ZS5hdXRvRGVzdHJveSB8fCB3U3RhdGUgJiYgd1N0YXRlLmF1dG9EZXN0cm95KSBzdHJlYW0uZGVzdHJveShlcnIpO2Vsc2Ugc3RyZWFtLmVtaXQoJ2Vycm9yJywgZXJyKTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gIGRlc3Ryb3k6IGRlc3Ryb3ksXG4gIHVuZGVzdHJveTogdW5kZXN0cm95LFxuICBlcnJvck9yRGVzdHJveTogZXJyb3JPckRlc3Ryb3lcbn07IiwiLy8gUG9ydGVkIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL21hZmludG9zaC9lbmQtb2Ytc3RyZWFtIHdpdGhcbi8vIHBlcm1pc3Npb24gZnJvbSB0aGUgYXV0aG9yLCBNYXRoaWFzIEJ1dXMgKEBtYWZpbnRvc2gpLlxuJ3VzZSBzdHJpY3QnO1xuXG52YXIgRVJSX1NUUkVBTV9QUkVNQVRVUkVfQ0xPU0UgPSByZXF1aXJlKCcuLi8uLi8uLi9lcnJvcnMnKS5jb2Rlcy5FUlJfU1RSRUFNX1BSRU1BVFVSRV9DTE9TRTtcblxuZnVuY3Rpb24gb25jZShjYWxsYmFjaykge1xuICB2YXIgY2FsbGVkID0gZmFsc2U7XG4gIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgaWYgKGNhbGxlZCkgcmV0dXJuO1xuICAgIGNhbGxlZCA9IHRydWU7XG5cbiAgICBmb3IgKHZhciBfbGVuID0gYXJndW1lbnRzLmxlbmd0aCwgYXJncyA9IG5ldyBBcnJheShfbGVuKSwgX2tleSA9IDA7IF9rZXkgPCBfbGVuOyBfa2V5KyspIHtcbiAgICAgIGFyZ3NbX2tleV0gPSBhcmd1bWVudHNbX2tleV07XG4gICAgfVxuXG4gICAgY2FsbGJhY2suYXBwbHkodGhpcywgYXJncyk7XG4gIH07XG59XG5cbmZ1bmN0aW9uIG5vb3AoKSB7fVxuXG5mdW5jdGlvbiBpc1JlcXVlc3Qoc3RyZWFtKSB7XG4gIHJldHVybiBzdHJlYW0uc2V0SGVhZGVyICYmIHR5cGVvZiBzdHJlYW0uYWJvcnQgPT09ICdmdW5jdGlvbic7XG59XG5cbmZ1bmN0aW9uIGVvcyhzdHJlYW0sIG9wdHMsIGNhbGxiYWNrKSB7XG4gIGlmICh0eXBlb2Ygb3B0cyA9PT0gJ2Z1bmN0aW9uJykgcmV0dXJuIGVvcyhzdHJlYW0sIG51bGwsIG9wdHMpO1xuICBpZiAoIW9wdHMpIG9wdHMgPSB7fTtcbiAgY2FsbGJhY2sgPSBvbmNlKGNhbGxiYWNrIHx8IG5vb3ApO1xuICB2YXIgcmVhZGFibGUgPSBvcHRzLnJlYWRhYmxlIHx8IG9wdHMucmVhZGFibGUgIT09IGZhbHNlICYmIHN0cmVhbS5yZWFkYWJsZTtcbiAgdmFyIHdyaXRhYmxlID0gb3B0cy53cml0YWJsZSB8fCBvcHRzLndyaXRhYmxlICE9PSBmYWxzZSAmJiBzdHJlYW0ud3JpdGFibGU7XG5cbiAgdmFyIG9ubGVnYWN5ZmluaXNoID0gZnVuY3Rpb24gb25sZWdhY3lmaW5pc2goKSB7XG4gICAgaWYgKCFzdHJlYW0ud3JpdGFibGUpIG9uZmluaXNoKCk7XG4gIH07XG5cbiAgdmFyIHdyaXRhYmxlRW5kZWQgPSBzdHJlYW0uX3dyaXRhYmxlU3RhdGUgJiYgc3RyZWFtLl93cml0YWJsZVN0YXRlLmZpbmlzaGVkO1xuXG4gIHZhciBvbmZpbmlzaCA9IGZ1bmN0aW9uIG9uZmluaXNoKCkge1xuICAgIHdyaXRhYmxlID0gZmFsc2U7XG4gICAgd3JpdGFibGVFbmRlZCA9IHRydWU7XG4gICAgaWYgKCFyZWFkYWJsZSkgY2FsbGJhY2suY2FsbChzdHJlYW0pO1xuICB9O1xuXG4gIHZhciByZWFkYWJsZUVuZGVkID0gc3RyZWFtLl9yZWFkYWJsZVN0YXRlICYmIHN0cmVhbS5fcmVhZGFibGVTdGF0ZS5lbmRFbWl0dGVkO1xuXG4gIHZhciBvbmVuZCA9IGZ1bmN0aW9uIG9uZW5kKCkge1xuICAgIHJlYWRhYmxlID0gZmFsc2U7XG4gICAgcmVhZGFibGVFbmRlZCA9IHRydWU7XG4gICAgaWYgKCF3cml0YWJsZSkgY2FsbGJhY2suY2FsbChzdHJlYW0pO1xuICB9O1xuXG4gIHZhciBvbmVycm9yID0gZnVuY3Rpb24gb25lcnJvcihlcnIpIHtcbiAgICBjYWxsYmFjay5jYWxsKHN0cmVhbSwgZXJyKTtcbiAgfTtcblxuICB2YXIgb25jbG9zZSA9IGZ1bmN0aW9uIG9uY2xvc2UoKSB7XG4gICAgdmFyIGVycjtcblxuICAgIGlmIChyZWFkYWJsZSAmJiAhcmVhZGFibGVFbmRlZCkge1xuICAgICAgaWYgKCFzdHJlYW0uX3JlYWRhYmxlU3RhdGUgfHwgIXN0cmVhbS5fcmVhZGFibGVTdGF0ZS5lbmRlZCkgZXJyID0gbmV3IEVSUl9TVFJFQU1fUFJFTUFUVVJFX0NMT1NFKCk7XG4gICAgICByZXR1cm4gY2FsbGJhY2suY2FsbChzdHJlYW0sIGVycik7XG4gICAgfVxuXG4gICAgaWYgKHdyaXRhYmxlICYmICF3cml0YWJsZUVuZGVkKSB7XG4gICAgICBpZiAoIXN0cmVhbS5fd3JpdGFibGVTdGF0ZSB8fCAhc3RyZWFtLl93cml0YWJsZVN0YXRlLmVuZGVkKSBlcnIgPSBuZXcgRVJSX1NUUkVBTV9QUkVNQVRVUkVfQ0xPU0UoKTtcbiAgICAgIHJldHVybiBjYWxsYmFjay5jYWxsKHN0cmVhbSwgZXJyKTtcbiAgICB9XG4gIH07XG5cbiAgdmFyIG9ucmVxdWVzdCA9IGZ1bmN0aW9uIG9ucmVxdWVzdCgpIHtcbiAgICBzdHJlYW0ucmVxLm9uKCdmaW5pc2gnLCBvbmZpbmlzaCk7XG4gIH07XG5cbiAgaWYgKGlzUmVxdWVzdChzdHJlYW0pKSB7XG4gICAgc3RyZWFtLm9uKCdjb21wbGV0ZScsIG9uZmluaXNoKTtcbiAgICBzdHJlYW0ub24oJ2Fib3J0Jywgb25jbG9zZSk7XG4gICAgaWYgKHN0cmVhbS5yZXEpIG9ucmVxdWVzdCgpO2Vsc2Ugc3RyZWFtLm9uKCdyZXF1ZXN0Jywgb25yZXF1ZXN0KTtcbiAgfSBlbHNlIGlmICh3cml0YWJsZSAmJiAhc3RyZWFtLl93cml0YWJsZVN0YXRlKSB7XG4gICAgLy8gbGVnYWN5IHN0cmVhbXNcbiAgICBzdHJlYW0ub24oJ2VuZCcsIG9ubGVnYWN5ZmluaXNoKTtcbiAgICBzdHJlYW0ub24oJ2Nsb3NlJywgb25sZWdhY3lmaW5pc2gpO1xuICB9XG5cbiAgc3RyZWFtLm9uKCdlbmQnLCBvbmVuZCk7XG4gIHN0cmVhbS5vbignZmluaXNoJywgb25maW5pc2gpO1xuICBpZiAob3B0cy5lcnJvciAhPT0gZmFsc2UpIHN0cmVhbS5vbignZXJyb3InLCBvbmVycm9yKTtcbiAgc3RyZWFtLm9uKCdjbG9zZScsIG9uY2xvc2UpO1xuICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgIHN0cmVhbS5yZW1vdmVMaXN0ZW5lcignY29tcGxldGUnLCBvbmZpbmlzaCk7XG4gICAgc3RyZWFtLnJlbW92ZUxpc3RlbmVyKCdhYm9ydCcsIG9uY2xvc2UpO1xuICAgIHN0cmVhbS5yZW1vdmVMaXN0ZW5lcigncmVxdWVzdCcsIG9ucmVxdWVzdCk7XG4gICAgaWYgKHN0cmVhbS5yZXEpIHN0cmVhbS5yZXEucmVtb3ZlTGlzdGVuZXIoJ2ZpbmlzaCcsIG9uZmluaXNoKTtcbiAgICBzdHJlYW0ucmVtb3ZlTGlzdGVuZXIoJ2VuZCcsIG9ubGVnYWN5ZmluaXNoKTtcbiAgICBzdHJlYW0ucmVtb3ZlTGlzdGVuZXIoJ2Nsb3NlJywgb25sZWdhY3lmaW5pc2gpO1xuICAgIHN0cmVhbS5yZW1vdmVMaXN0ZW5lcignZmluaXNoJywgb25maW5pc2gpO1xuICAgIHN0cmVhbS5yZW1vdmVMaXN0ZW5lcignZW5kJywgb25lbmQpO1xuICAgIHN0cmVhbS5yZW1vdmVMaXN0ZW5lcignZXJyb3InLCBvbmVycm9yKTtcbiAgICBzdHJlYW0ucmVtb3ZlTGlzdGVuZXIoJ2Nsb3NlJywgb25jbG9zZSk7XG4gIH07XG59XG5cbm1vZHVsZS5leHBvcnRzID0gZW9zOyIsIid1c2Ugc3RyaWN0JztcblxuZnVuY3Rpb24gYXN5bmNHZW5lcmF0b3JTdGVwKGdlbiwgcmVzb2x2ZSwgcmVqZWN0LCBfbmV4dCwgX3Rocm93LCBrZXksIGFyZykgeyB0cnkgeyB2YXIgaW5mbyA9IGdlbltrZXldKGFyZyk7IHZhciB2YWx1ZSA9IGluZm8udmFsdWU7IH0gY2F0Y2ggKGVycm9yKSB7IHJlamVjdChlcnJvcik7IHJldHVybjsgfSBpZiAoaW5mby5kb25lKSB7IHJlc29sdmUodmFsdWUpOyB9IGVsc2UgeyBQcm9taXNlLnJlc29sdmUodmFsdWUpLnRoZW4oX25leHQsIF90aHJvdyk7IH0gfVxuXG5mdW5jdGlvbiBfYXN5bmNUb0dlbmVyYXRvcihmbikgeyByZXR1cm4gZnVuY3Rpb24gKCkgeyB2YXIgc2VsZiA9IHRoaXMsIGFyZ3MgPSBhcmd1bWVudHM7IHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7IHZhciBnZW4gPSBmbi5hcHBseShzZWxmLCBhcmdzKTsgZnVuY3Rpb24gX25leHQodmFsdWUpIHsgYXN5bmNHZW5lcmF0b3JTdGVwKGdlbiwgcmVzb2x2ZSwgcmVqZWN0LCBfbmV4dCwgX3Rocm93LCBcIm5leHRcIiwgdmFsdWUpOyB9IGZ1bmN0aW9uIF90aHJvdyhlcnIpIHsgYXN5bmNHZW5lcmF0b3JTdGVwKGdlbiwgcmVzb2x2ZSwgcmVqZWN0LCBfbmV4dCwgX3Rocm93LCBcInRocm93XCIsIGVycik7IH0gX25leHQodW5kZWZpbmVkKTsgfSk7IH07IH1cblxuZnVuY3Rpb24gb3duS2V5cyhvYmplY3QsIGVudW1lcmFibGVPbmx5KSB7IHZhciBrZXlzID0gT2JqZWN0LmtleXMob2JqZWN0KTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHsgdmFyIHN5bWJvbHMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKG9iamVjdCk7IGlmIChlbnVtZXJhYmxlT25seSkgc3ltYm9scyA9IHN5bWJvbHMuZmlsdGVyKGZ1bmN0aW9uIChzeW0pIHsgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3Iob2JqZWN0LCBzeW0pLmVudW1lcmFibGU7IH0pOyBrZXlzLnB1c2guYXBwbHkoa2V5cywgc3ltYm9scyk7IH0gcmV0dXJuIGtleXM7IH1cblxuZnVuY3Rpb24gX29iamVjdFNwcmVhZCh0YXJnZXQpIHsgZm9yICh2YXIgaSA9IDE7IGkgPCBhcmd1bWVudHMubGVuZ3RoOyBpKyspIHsgdmFyIHNvdXJjZSA9IGFyZ3VtZW50c1tpXSAhPSBudWxsID8gYXJndW1lbnRzW2ldIDoge307IGlmIChpICUgMikgeyBvd25LZXlzKE9iamVjdChzb3VyY2UpLCB0cnVlKS5mb3JFYWNoKGZ1bmN0aW9uIChrZXkpIHsgX2RlZmluZVByb3BlcnR5KHRhcmdldCwga2V5LCBzb3VyY2Vba2V5XSk7IH0pOyB9IGVsc2UgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKHRhcmdldCwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMoc291cmNlKSk7IH0gZWxzZSB7IG93bktleXMoT2JqZWN0KHNvdXJjZSkpLmZvckVhY2goZnVuY3Rpb24gKGtleSkgeyBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBrZXksIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3Ioc291cmNlLCBrZXkpKTsgfSk7IH0gfSByZXR1cm4gdGFyZ2V0OyB9XG5cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShvYmosIGtleSwgdmFsdWUpIHsgaWYgKGtleSBpbiBvYmopIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KG9iaiwga2V5LCB7IHZhbHVlOiB2YWx1ZSwgZW51bWVyYWJsZTogdHJ1ZSwgY29uZmlndXJhYmxlOiB0cnVlLCB3cml0YWJsZTogdHJ1ZSB9KTsgfSBlbHNlIHsgb2JqW2tleV0gPSB2YWx1ZTsgfSByZXR1cm4gb2JqOyB9XG5cbnZhciBFUlJfSU5WQUxJRF9BUkdfVFlQRSA9IHJlcXVpcmUoJy4uLy4uLy4uL2Vycm9ycycpLmNvZGVzLkVSUl9JTlZBTElEX0FSR19UWVBFO1xuXG5mdW5jdGlvbiBmcm9tKFJlYWRhYmxlLCBpdGVyYWJsZSwgb3B0cykge1xuICB2YXIgaXRlcmF0b3I7XG5cbiAgaWYgKGl0ZXJhYmxlICYmIHR5cGVvZiBpdGVyYWJsZS5uZXh0ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgaXRlcmF0b3IgPSBpdGVyYWJsZTtcbiAgfSBlbHNlIGlmIChpdGVyYWJsZSAmJiBpdGVyYWJsZVtTeW1ib2wuYXN5bmNJdGVyYXRvcl0pIGl0ZXJhdG9yID0gaXRlcmFibGVbU3ltYm9sLmFzeW5jSXRlcmF0b3JdKCk7ZWxzZSBpZiAoaXRlcmFibGUgJiYgaXRlcmFibGVbU3ltYm9sLml0ZXJhdG9yXSkgaXRlcmF0b3IgPSBpdGVyYWJsZVtTeW1ib2wuaXRlcmF0b3JdKCk7ZWxzZSB0aHJvdyBuZXcgRVJSX0lOVkFMSURfQVJHX1RZUEUoJ2l0ZXJhYmxlJywgWydJdGVyYWJsZSddLCBpdGVyYWJsZSk7XG5cbiAgdmFyIHJlYWRhYmxlID0gbmV3IFJlYWRhYmxlKF9vYmplY3RTcHJlYWQoe1xuICAgIG9iamVjdE1vZGU6IHRydWVcbiAgfSwgb3B0cykpOyAvLyBSZWFkaW5nIGJvb2xlYW4gdG8gcHJvdGVjdCBhZ2FpbnN0IF9yZWFkXG4gIC8vIGJlaW5nIGNhbGxlZCBiZWZvcmUgbGFzdCBpdGVyYXRpb24gY29tcGxldGlvbi5cblxuICB2YXIgcmVhZGluZyA9IGZhbHNlO1xuXG4gIHJlYWRhYmxlLl9yZWFkID0gZnVuY3Rpb24gKCkge1xuICAgIGlmICghcmVhZGluZykge1xuICAgICAgcmVhZGluZyA9IHRydWU7XG4gICAgICBuZXh0KCk7XG4gICAgfVxuICB9O1xuXG4gIGZ1bmN0aW9uIG5leHQoKSB7XG4gICAgcmV0dXJuIF9uZXh0Mi5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICB9XG5cbiAgZnVuY3Rpb24gX25leHQyKCkge1xuICAgIF9uZXh0MiA9IF9hc3luY1RvR2VuZXJhdG9yKGZ1bmN0aW9uKiAoKSB7XG4gICAgICB0cnkge1xuICAgICAgICB2YXIgX3JlZiA9IHlpZWxkIGl0ZXJhdG9yLm5leHQoKSxcbiAgICAgICAgICAgIHZhbHVlID0gX3JlZi52YWx1ZSxcbiAgICAgICAgICAgIGRvbmUgPSBfcmVmLmRvbmU7XG5cbiAgICAgICAgaWYgKGRvbmUpIHtcbiAgICAgICAgICByZWFkYWJsZS5wdXNoKG51bGwpO1xuICAgICAgICB9IGVsc2UgaWYgKHJlYWRhYmxlLnB1c2goKHlpZWxkIHZhbHVlKSkpIHtcbiAgICAgICAgICBuZXh0KCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmVhZGluZyA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgcmVhZGFibGUuZGVzdHJveShlcnIpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBfbmV4dDIuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgfVxuXG4gIHJldHVybiByZWFkYWJsZTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBmcm9tOyIsIi8vIFBvcnRlZCBmcm9tIGh0dHBzOi8vZ2l0aHViLmNvbS9tYWZpbnRvc2gvcHVtcCB3aXRoXG4vLyBwZXJtaXNzaW9uIGZyb20gdGhlIGF1dGhvciwgTWF0aGlhcyBCdXVzIChAbWFmaW50b3NoKS5cbid1c2Ugc3RyaWN0JztcblxudmFyIGVvcztcblxuZnVuY3Rpb24gb25jZShjYWxsYmFjaykge1xuICB2YXIgY2FsbGVkID0gZmFsc2U7XG4gIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgaWYgKGNhbGxlZCkgcmV0dXJuO1xuICAgIGNhbGxlZCA9IHRydWU7XG4gICAgY2FsbGJhY2suYXBwbHkodm9pZCAwLCBhcmd1bWVudHMpO1xuICB9O1xufVxuXG52YXIgX3JlcXVpcmUkY29kZXMgPSByZXF1aXJlKCcuLi8uLi8uLi9lcnJvcnMnKS5jb2RlcyxcbiAgICBFUlJfTUlTU0lOR19BUkdTID0gX3JlcXVpcmUkY29kZXMuRVJSX01JU1NJTkdfQVJHUyxcbiAgICBFUlJfU1RSRUFNX0RFU1RST1lFRCA9IF9yZXF1aXJlJGNvZGVzLkVSUl9TVFJFQU1fREVTVFJPWUVEO1xuXG5mdW5jdGlvbiBub29wKGVycikge1xuICAvLyBSZXRocm93IHRoZSBlcnJvciBpZiBpdCBleGlzdHMgdG8gYXZvaWQgc3dhbGxvd2luZyBpdFxuICBpZiAoZXJyKSB0aHJvdyBlcnI7XG59XG5cbmZ1bmN0aW9uIGlzUmVxdWVzdChzdHJlYW0pIHtcbiAgcmV0dXJuIHN0cmVhbS5zZXRIZWFkZXIgJiYgdHlwZW9mIHN0cmVhbS5hYm9ydCA9PT0gJ2Z1bmN0aW9uJztcbn1cblxuZnVuY3Rpb24gZGVzdHJveWVyKHN0cmVhbSwgcmVhZGluZywgd3JpdGluZywgY2FsbGJhY2spIHtcbiAgY2FsbGJhY2sgPSBvbmNlKGNhbGxiYWNrKTtcbiAgdmFyIGNsb3NlZCA9IGZhbHNlO1xuICBzdHJlYW0ub24oJ2Nsb3NlJywgZnVuY3Rpb24gKCkge1xuICAgIGNsb3NlZCA9IHRydWU7XG4gIH0pO1xuICBpZiAoZW9zID09PSB1bmRlZmluZWQpIGVvcyA9IHJlcXVpcmUoJy4vZW5kLW9mLXN0cmVhbScpO1xuICBlb3Moc3RyZWFtLCB7XG4gICAgcmVhZGFibGU6IHJlYWRpbmcsXG4gICAgd3JpdGFibGU6IHdyaXRpbmdcbiAgfSwgZnVuY3Rpb24gKGVycikge1xuICAgIGlmIChlcnIpIHJldHVybiBjYWxsYmFjayhlcnIpO1xuICAgIGNsb3NlZCA9IHRydWU7XG4gICAgY2FsbGJhY2soKTtcbiAgfSk7XG4gIHZhciBkZXN0cm95ZWQgPSBmYWxzZTtcbiAgcmV0dXJuIGZ1bmN0aW9uIChlcnIpIHtcbiAgICBpZiAoY2xvc2VkKSByZXR1cm47XG4gICAgaWYgKGRlc3Ryb3llZCkgcmV0dXJuO1xuICAgIGRlc3Ryb3llZCA9IHRydWU7IC8vIHJlcXVlc3QuZGVzdHJveSBqdXN0IGRvIC5lbmQgLSAuYWJvcnQgaXMgd2hhdCB3ZSB3YW50XG5cbiAgICBpZiAoaXNSZXF1ZXN0KHN0cmVhbSkpIHJldHVybiBzdHJlYW0uYWJvcnQoKTtcbiAgICBpZiAodHlwZW9mIHN0cmVhbS5kZXN0cm95ID09PSAnZnVuY3Rpb24nKSByZXR1cm4gc3RyZWFtLmRlc3Ryb3koKTtcbiAgICBjYWxsYmFjayhlcnIgfHwgbmV3IEVSUl9TVFJFQU1fREVTVFJPWUVEKCdwaXBlJykpO1xuICB9O1xufVxuXG5mdW5jdGlvbiBjYWxsKGZuKSB7XG4gIGZuKCk7XG59XG5cbmZ1bmN0aW9uIHBpcGUoZnJvbSwgdG8pIHtcbiAgcmV0dXJuIGZyb20ucGlwZSh0byk7XG59XG5cbmZ1bmN0aW9uIHBvcENhbGxiYWNrKHN0cmVhbXMpIHtcbiAgaWYgKCFzdHJlYW1zLmxlbmd0aCkgcmV0dXJuIG5vb3A7XG4gIGlmICh0eXBlb2Ygc3RyZWFtc1tzdHJlYW1zLmxlbmd0aCAtIDFdICE9PSAnZnVuY3Rpb24nKSByZXR1cm4gbm9vcDtcbiAgcmV0dXJuIHN0cmVhbXMucG9wKCk7XG59XG5cbmZ1bmN0aW9uIHBpcGVsaW5lKCkge1xuICBmb3IgKHZhciBfbGVuID0gYXJndW1lbnRzLmxlbmd0aCwgc3RyZWFtcyA9IG5ldyBBcnJheShfbGVuKSwgX2tleSA9IDA7IF9rZXkgPCBfbGVuOyBfa2V5KyspIHtcbiAgICBzdHJlYW1zW19rZXldID0gYXJndW1lbnRzW19rZXldO1xuICB9XG5cbiAgdmFyIGNhbGxiYWNrID0gcG9wQ2FsbGJhY2soc3RyZWFtcyk7XG4gIGlmIChBcnJheS5pc0FycmF5KHN0cmVhbXNbMF0pKSBzdHJlYW1zID0gc3RyZWFtc1swXTtcblxuICBpZiAoc3RyZWFtcy5sZW5ndGggPCAyKSB7XG4gICAgdGhyb3cgbmV3IEVSUl9NSVNTSU5HX0FSR1MoJ3N0cmVhbXMnKTtcbiAgfVxuXG4gIHZhciBlcnJvcjtcbiAgdmFyIGRlc3Ryb3lzID0gc3RyZWFtcy5tYXAoZnVuY3Rpb24gKHN0cmVhbSwgaSkge1xuICAgIHZhciByZWFkaW5nID0gaSA8IHN0cmVhbXMubGVuZ3RoIC0gMTtcbiAgICB2YXIgd3JpdGluZyA9IGkgPiAwO1xuICAgIHJldHVybiBkZXN0cm95ZXIoc3RyZWFtLCByZWFkaW5nLCB3cml0aW5nLCBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICBpZiAoIWVycm9yKSBlcnJvciA9IGVycjtcbiAgICAgIGlmIChlcnIpIGRlc3Ryb3lzLmZvckVhY2goY2FsbCk7XG4gICAgICBpZiAocmVhZGluZykgcmV0dXJuO1xuICAgICAgZGVzdHJveXMuZm9yRWFjaChjYWxsKTtcbiAgICAgIGNhbGxiYWNrKGVycm9yKTtcbiAgICB9KTtcbiAgfSk7XG4gIHJldHVybiBzdHJlYW1zLnJlZHVjZShwaXBlKTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBwaXBlbGluZTsiLCIndXNlIHN0cmljdCc7XG5cbnZhciBFUlJfSU5WQUxJRF9PUFRfVkFMVUUgPSByZXF1aXJlKCcuLi8uLi8uLi9lcnJvcnMnKS5jb2Rlcy5FUlJfSU5WQUxJRF9PUFRfVkFMVUU7XG5cbmZ1bmN0aW9uIGhpZ2hXYXRlck1hcmtGcm9tKG9wdGlvbnMsIGlzRHVwbGV4LCBkdXBsZXhLZXkpIHtcbiAgcmV0dXJuIG9wdGlvbnMuaGlnaFdhdGVyTWFyayAhPSBudWxsID8gb3B0aW9ucy5oaWdoV2F0ZXJNYXJrIDogaXNEdXBsZXggPyBvcHRpb25zW2R1cGxleEtleV0gOiBudWxsO1xufVxuXG5mdW5jdGlvbiBnZXRIaWdoV2F0ZXJNYXJrKHN0YXRlLCBvcHRpb25zLCBkdXBsZXhLZXksIGlzRHVwbGV4KSB7XG4gIHZhciBod20gPSBoaWdoV2F0ZXJNYXJrRnJvbShvcHRpb25zLCBpc0R1cGxleCwgZHVwbGV4S2V5KTtcblxuICBpZiAoaHdtICE9IG51bGwpIHtcbiAgICBpZiAoIShpc0Zpbml0ZShod20pICYmIE1hdGguZmxvb3IoaHdtKSA9PT0gaHdtKSB8fCBod20gPCAwKSB7XG4gICAgICB2YXIgbmFtZSA9IGlzRHVwbGV4ID8gZHVwbGV4S2V5IDogJ2hpZ2hXYXRlck1hcmsnO1xuICAgICAgdGhyb3cgbmV3IEVSUl9JTlZBTElEX09QVF9WQUxVRShuYW1lLCBod20pO1xuICAgIH1cblxuICAgIHJldHVybiBNYXRoLmZsb29yKGh3bSk7XG4gIH0gLy8gRGVmYXVsdCB2YWx1ZVxuXG5cbiAgcmV0dXJuIHN0YXRlLm9iamVjdE1vZGUgPyAxNiA6IDE2ICogMTAyNDtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gIGdldEhpZ2hXYXRlck1hcms6IGdldEhpZ2hXYXRlck1hcmtcbn07IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCdzdHJlYW0nKTtcbiIsInZhciBTdHJlYW0gPSByZXF1aXJlKCdzdHJlYW0nKTtcbmlmIChwcm9jZXNzLmVudi5SRUFEQUJMRV9TVFJFQU0gPT09ICdkaXNhYmxlJyAmJiBTdHJlYW0pIHtcbiAgbW9kdWxlLmV4cG9ydHMgPSBTdHJlYW0uUmVhZGFibGU7XG4gIE9iamVjdC5hc3NpZ24obW9kdWxlLmV4cG9ydHMsIFN0cmVhbSk7XG4gIG1vZHVsZS5leHBvcnRzLlN0cmVhbSA9IFN0cmVhbTtcbn0gZWxzZSB7XG4gIGV4cG9ydHMgPSBtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vbGliL19zdHJlYW1fcmVhZGFibGUuanMnKTtcbiAgZXhwb3J0cy5TdHJlYW0gPSBTdHJlYW0gfHwgZXhwb3J0cztcbiAgZXhwb3J0cy5SZWFkYWJsZSA9IGV4cG9ydHM7XG4gIGV4cG9ydHMuV3JpdGFibGUgPSByZXF1aXJlKCcuL2xpYi9fc3RyZWFtX3dyaXRhYmxlLmpzJyk7XG4gIGV4cG9ydHMuRHVwbGV4ID0gcmVxdWlyZSgnLi9saWIvX3N0cmVhbV9kdXBsZXguanMnKTtcbiAgZXhwb3J0cy5UcmFuc2Zvcm0gPSByZXF1aXJlKCcuL2xpYi9fc3RyZWFtX3RyYW5zZm9ybS5qcycpO1xuICBleHBvcnRzLlBhc3NUaHJvdWdoID0gcmVxdWlyZSgnLi9saWIvX3N0cmVhbV9wYXNzdGhyb3VnaC5qcycpO1xuICBleHBvcnRzLmZpbmlzaGVkID0gcmVxdWlyZSgnLi9saWIvaW50ZXJuYWwvc3RyZWFtcy9lbmQtb2Ytc3RyZWFtLmpzJyk7XG4gIGV4cG9ydHMucGlwZWxpbmUgPSByZXF1aXJlKCcuL2xpYi9pbnRlcm5hbC9zdHJlYW1zL3BpcGVsaW5lLmpzJyk7XG59XG4iLCIvKiEgc2FmZS1idWZmZXIuIE1JVCBMaWNlbnNlLiBGZXJvc3MgQWJvdWtoYWRpamVoIDxodHRwczovL2Zlcm9zcy5vcmcvb3BlbnNvdXJjZT4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG5vZGUvbm8tZGVwcmVjYXRlZC1hcGkgKi9cbnZhciBidWZmZXIgPSByZXF1aXJlKCdidWZmZXInKVxudmFyIEJ1ZmZlciA9IGJ1ZmZlci5CdWZmZXJcblxuLy8gYWx0ZXJuYXRpdmUgdG8gdXNpbmcgT2JqZWN0LmtleXMgZm9yIG9sZCBicm93c2Vyc1xuZnVuY3Rpb24gY29weVByb3BzIChzcmMsIGRzdCkge1xuICBmb3IgKHZhciBrZXkgaW4gc3JjKSB7XG4gICAgZHN0W2tleV0gPSBzcmNba2V5XVxuICB9XG59XG5pZiAoQnVmZmVyLmZyb20gJiYgQnVmZmVyLmFsbG9jICYmIEJ1ZmZlci5hbGxvY1Vuc2FmZSAmJiBCdWZmZXIuYWxsb2NVbnNhZmVTbG93KSB7XG4gIG1vZHVsZS5leHBvcnRzID0gYnVmZmVyXG59IGVsc2Uge1xuICAvLyBDb3B5IHByb3BlcnRpZXMgZnJvbSByZXF1aXJlKCdidWZmZXInKVxuICBjb3B5UHJvcHMoYnVmZmVyLCBleHBvcnRzKVxuICBleHBvcnRzLkJ1ZmZlciA9IFNhZmVCdWZmZXJcbn1cblxuZnVuY3Rpb24gU2FmZUJ1ZmZlciAoYXJnLCBlbmNvZGluZ09yT2Zmc2V0LCBsZW5ndGgpIHtcbiAgcmV0dXJuIEJ1ZmZlcihhcmcsIGVuY29kaW5nT3JPZmZzZXQsIGxlbmd0aClcbn1cblxuU2FmZUJ1ZmZlci5wcm90b3R5cGUgPSBPYmplY3QuY3JlYXRlKEJ1ZmZlci5wcm90b3R5cGUpXG5cbi8vIENvcHkgc3RhdGljIG1ldGhvZHMgZnJvbSBCdWZmZXJcbmNvcHlQcm9wcyhCdWZmZXIsIFNhZmVCdWZmZXIpXG5cblNhZmVCdWZmZXIuZnJvbSA9IGZ1bmN0aW9uIChhcmcsIGVuY29kaW5nT3JPZmZzZXQsIGxlbmd0aCkge1xuICBpZiAodHlwZW9mIGFyZyA9PT0gJ251bWJlcicpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdBcmd1bWVudCBtdXN0IG5vdCBiZSBhIG51bWJlcicpXG4gIH1cbiAgcmV0dXJuIEJ1ZmZlcihhcmcsIGVuY29kaW5nT3JPZmZzZXQsIGxlbmd0aClcbn1cblxuU2FmZUJ1ZmZlci5hbGxvYyA9IGZ1bmN0aW9uIChzaXplLCBmaWxsLCBlbmNvZGluZykge1xuICBpZiAodHlwZW9mIHNpemUgIT09ICdudW1iZXInKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignQXJndW1lbnQgbXVzdCBiZSBhIG51bWJlcicpXG4gIH1cbiAgdmFyIGJ1ZiA9IEJ1ZmZlcihzaXplKVxuICBpZiAoZmlsbCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgaWYgKHR5cGVvZiBlbmNvZGluZyA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGJ1Zi5maWxsKGZpbGwsIGVuY29kaW5nKVxuICAgIH0gZWxzZSB7XG4gICAgICBidWYuZmlsbChmaWxsKVxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBidWYuZmlsbCgwKVxuICB9XG4gIHJldHVybiBidWZcbn1cblxuU2FmZUJ1ZmZlci5hbGxvY1Vuc2FmZSA9IGZ1bmN0aW9uIChzaXplKSB7XG4gIGlmICh0eXBlb2Ygc2l6ZSAhPT0gJ251bWJlcicpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdBcmd1bWVudCBtdXN0IGJlIGEgbnVtYmVyJylcbiAgfVxuICByZXR1cm4gQnVmZmVyKHNpemUpXG59XG5cblNhZmVCdWZmZXIuYWxsb2NVbnNhZmVTbG93ID0gZnVuY3Rpb24gKHNpemUpIHtcbiAgaWYgKHR5cGVvZiBzaXplICE9PSAnbnVtYmVyJykge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ0FyZ3VtZW50IG11c3QgYmUgYSBudW1iZXInKVxuICB9XG4gIHJldHVybiBidWZmZXIuU2xvd0J1ZmZlcihzaXplKVxufVxuIiwiLypcbkNvcHlyaWdodCAoYykgMjAxNC0yMDE4LCBNYXR0ZW8gQ29sbGluYSA8aGVsbG9AbWF0dGVvY29sbGluYS5jb20+XG5cblBlcm1pc3Npb24gdG8gdXNlLCBjb3B5LCBtb2RpZnksIGFuZC9vciBkaXN0cmlidXRlIHRoaXMgc29mdHdhcmUgZm9yIGFueVxucHVycG9zZSB3aXRoIG9yIHdpdGhvdXQgZmVlIGlzIGhlcmVieSBncmFudGVkLCBwcm92aWRlZCB0aGF0IHRoZSBhYm92ZVxuY29weXJpZ2h0IG5vdGljZSBhbmQgdGhpcyBwZXJtaXNzaW9uIG5vdGljZSBhcHBlYXIgaW4gYWxsIGNvcGllcy5cblxuVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiBBTkQgVEhFIEFVVEhPUiBESVNDTEFJTVMgQUxMIFdBUlJBTlRJRVNcbldJVEggUkVHQVJEIFRPIFRISVMgU09GVFdBUkUgSU5DTFVESU5HIEFMTCBJTVBMSUVEIFdBUlJBTlRJRVMgT0Zcbk1FUkNIQU5UQUJJTElUWSBBTkQgRklUTkVTUy4gSU4gTk8gRVZFTlQgU0hBTEwgVEhFIEFVVEhPUiBCRSBMSUFCTEUgRk9SXG5BTlkgU1BFQ0lBTCwgRElSRUNULCBJTkRJUkVDVCwgT1IgQ09OU0VRVUVOVElBTCBEQU1BR0VTIE9SIEFOWSBEQU1BR0VTXG5XSEFUU09FVkVSIFJFU1VMVElORyBGUk9NIExPU1MgT0YgVVNFLCBEQVRBIE9SIFBST0ZJVFMsIFdIRVRIRVIgSU4gQU5cbkFDVElPTiBPRiBDT05UUkFDVCwgTkVHTElHRU5DRSBPUiBPVEhFUiBUT1JUSU9VUyBBQ1RJT04sIEFSSVNJTkcgT1VUIE9GIE9SXG5JTiBDT05ORUNUSU9OIFdJVEggVEhFIFVTRSBPUiBQRVJGT1JNQU5DRSBPRiBUSElTIFNPRlRXQVJFLlxuKi9cblxuJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IHsgVHJhbnNmb3JtIH0gPSByZXF1aXJlKCdyZWFkYWJsZS1zdHJlYW0nKVxuY29uc3QgeyBTdHJpbmdEZWNvZGVyIH0gPSByZXF1aXJlKCdzdHJpbmdfZGVjb2RlcicpXG5jb25zdCBrTGFzdCA9IFN5bWJvbCgnbGFzdCcpXG5jb25zdCBrRGVjb2RlciA9IFN5bWJvbCgnZGVjb2RlcicpXG5cbmZ1bmN0aW9uIHRyYW5zZm9ybSAoY2h1bmssIGVuYywgY2IpIHtcbiAgdmFyIGxpc3RcbiAgaWYgKHRoaXMub3ZlcmZsb3cpIHsgLy8gTGluZSBidWZmZXIgaXMgZnVsbC4gU2tpcCB0byBzdGFydCBvZiBuZXh0IGxpbmUuXG4gICAgdmFyIGJ1ZiA9IHRoaXNba0RlY29kZXJdLndyaXRlKGNodW5rKVxuICAgIGxpc3QgPSBidWYuc3BsaXQodGhpcy5tYXRjaGVyKVxuXG4gICAgaWYgKGxpc3QubGVuZ3RoID09PSAxKSByZXR1cm4gY2IoKSAvLyBMaW5lIGVuZGluZyBub3QgZm91bmQuIERpc2NhcmQgZW50aXJlIGNodW5rLlxuXG4gICAgLy8gTGluZSBlbmRpbmcgZm91bmQuIERpc2NhcmQgdHJhaWxpbmcgZnJhZ21lbnQgb2YgcHJldmlvdXMgbGluZSBhbmQgcmVzZXQgb3ZlcmZsb3cgc3RhdGUuXG4gICAgbGlzdC5zaGlmdCgpXG4gICAgdGhpcy5vdmVyZmxvdyA9IGZhbHNlXG4gIH0gZWxzZSB7XG4gICAgdGhpc1trTGFzdF0gKz0gdGhpc1trRGVjb2Rlcl0ud3JpdGUoY2h1bmspXG4gICAgbGlzdCA9IHRoaXNba0xhc3RdLnNwbGl0KHRoaXMubWF0Y2hlcilcbiAgfVxuXG4gIHRoaXNba0xhc3RdID0gbGlzdC5wb3AoKVxuXG4gIGZvciAodmFyIGkgPSAwOyBpIDwgbGlzdC5sZW5ndGg7IGkrKykge1xuICAgIHRyeSB7XG4gICAgICBwdXNoKHRoaXMsIHRoaXMubWFwcGVyKGxpc3RbaV0pKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICByZXR1cm4gY2IoZXJyb3IpXG4gICAgfVxuICB9XG5cbiAgdGhpcy5vdmVyZmxvdyA9IHRoaXNba0xhc3RdLmxlbmd0aCA+IHRoaXMubWF4TGVuZ3RoXG4gIGlmICh0aGlzLm92ZXJmbG93ICYmICF0aGlzLnNraXBPdmVyZmxvdykgcmV0dXJuIGNiKG5ldyBFcnJvcignbWF4aW11bSBidWZmZXIgcmVhY2hlZCcpKVxuXG4gIGNiKClcbn1cblxuZnVuY3Rpb24gZmx1c2ggKGNiKSB7XG4gIC8vIGZvcndhcmQgYW55IGdpYmJlcmlzaCBsZWZ0IGluIHRoZXJlXG4gIHRoaXNba0xhc3RdICs9IHRoaXNba0RlY29kZXJdLmVuZCgpXG5cbiAgaWYgKHRoaXNba0xhc3RdKSB7XG4gICAgdHJ5IHtcbiAgICAgIHB1c2godGhpcywgdGhpcy5tYXBwZXIodGhpc1trTGFzdF0pKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICByZXR1cm4gY2IoZXJyb3IpXG4gICAgfVxuICB9XG5cbiAgY2IoKVxufVxuXG5mdW5jdGlvbiBwdXNoIChzZWxmLCB2YWwpIHtcbiAgaWYgKHZhbCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgc2VsZi5wdXNoKHZhbClcbiAgfVxufVxuXG5mdW5jdGlvbiBub29wIChpbmNvbWluZykge1xuICByZXR1cm4gaW5jb21pbmdcbn1cblxuZnVuY3Rpb24gc3BsaXQgKG1hdGNoZXIsIG1hcHBlciwgb3B0aW9ucykge1xuICAvLyBTZXQgZGVmYXVsdHMgZm9yIGFueSBhcmd1bWVudHMgbm90IHN1cHBsaWVkLlxuICBtYXRjaGVyID0gbWF0Y2hlciB8fCAvXFxyP1xcbi9cbiAgbWFwcGVyID0gbWFwcGVyIHx8IG5vb3BcbiAgb3B0aW9ucyA9IG9wdGlvbnMgfHwge31cblxuICAvLyBUZXN0IGFyZ3VtZW50cyBleHBsaWNpdGx5LlxuICBzd2l0Y2ggKGFyZ3VtZW50cy5sZW5ndGgpIHtcbiAgICBjYXNlIDE6XG4gICAgICAvLyBJZiBtYXBwZXIgaXMgb25seSBhcmd1bWVudC5cbiAgICAgIGlmICh0eXBlb2YgbWF0Y2hlciA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBtYXBwZXIgPSBtYXRjaGVyXG4gICAgICAgIG1hdGNoZXIgPSAvXFxyP1xcbi9cbiAgICAgIC8vIElmIG9wdGlvbnMgaXMgb25seSBhcmd1bWVudC5cbiAgICAgIH0gZWxzZSBpZiAodHlwZW9mIG1hdGNoZXIgPT09ICdvYmplY3QnICYmICEobWF0Y2hlciBpbnN0YW5jZW9mIFJlZ0V4cCkpIHtcbiAgICAgICAgb3B0aW9ucyA9IG1hdGNoZXJcbiAgICAgICAgbWF0Y2hlciA9IC9cXHI/XFxuL1xuICAgICAgfVxuICAgICAgYnJlYWtcblxuICAgIGNhc2UgMjpcbiAgICAgIC8vIElmIG1hcHBlciBhbmQgb3B0aW9ucyBhcmUgYXJndW1lbnRzLlxuICAgICAgaWYgKHR5cGVvZiBtYXRjaGVyID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIG9wdGlvbnMgPSBtYXBwZXJcbiAgICAgICAgbWFwcGVyID0gbWF0Y2hlclxuICAgICAgICBtYXRjaGVyID0gL1xccj9cXG4vXG4gICAgICAvLyBJZiBtYXRjaGVyIGFuZCBvcHRpb25zIGFyZSBhcmd1bWVudHMuXG4gICAgICB9IGVsc2UgaWYgKHR5cGVvZiBtYXBwZXIgPT09ICdvYmplY3QnKSB7XG4gICAgICAgIG9wdGlvbnMgPSBtYXBwZXJcbiAgICAgICAgbWFwcGVyID0gbm9vcFxuICAgICAgfVxuICB9XG5cbiAgb3B0aW9ucyA9IE9iamVjdC5hc3NpZ24oe30sIG9wdGlvbnMpXG4gIG9wdGlvbnMudHJhbnNmb3JtID0gdHJhbnNmb3JtXG4gIG9wdGlvbnMuZmx1c2ggPSBmbHVzaFxuICBvcHRpb25zLnJlYWRhYmxlT2JqZWN0TW9kZSA9IHRydWVcblxuICBjb25zdCBzdHJlYW0gPSBuZXcgVHJhbnNmb3JtKG9wdGlvbnMpXG5cbiAgc3RyZWFtW2tMYXN0XSA9ICcnXG4gIHN0cmVhbVtrRGVjb2Rlcl0gPSBuZXcgU3RyaW5nRGVjb2RlcigndXRmOCcpXG4gIHN0cmVhbS5tYXRjaGVyID0gbWF0Y2hlclxuICBzdHJlYW0ubWFwcGVyID0gbWFwcGVyXG4gIHN0cmVhbS5tYXhMZW5ndGggPSBvcHRpb25zLm1heExlbmd0aFxuICBzdHJlYW0uc2tpcE92ZXJmbG93ID0gb3B0aW9ucy5za2lwT3ZlcmZsb3dcbiAgc3RyZWFtLm92ZXJmbG93ID0gZmFsc2VcblxuICByZXR1cm4gc3RyZWFtXG59XG5cbm1vZHVsZS5leHBvcnRzID0gc3BsaXRcbiIsIi8vIENvcHlyaWdodCBKb3llbnQsIEluYy4gYW5kIG90aGVyIE5vZGUgY29udHJpYnV0b3JzLlxuLy9cbi8vIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhXG4vLyBjb3B5IG9mIHRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlXG4vLyBcIlNvZnR3YXJlXCIpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZSB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmdcbi8vIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBtZXJnZSwgcHVibGlzaCxcbi8vIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0byBwZXJtaXRcbi8vIHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLCBzdWJqZWN0IHRvIHRoZVxuLy8gZm9sbG93aW5nIGNvbmRpdGlvbnM6XG4vL1xuLy8gVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWRcbi8vIGluIGFsbCBjb3BpZXMgb3Igc3Vic3RhbnRpYWwgcG9ydGlvbnMgb2YgdGhlIFNvZnR3YXJlLlxuLy9cbi8vIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIsIFdJVEhPVVQgV0FSUkFOVFkgT0YgQU5ZIEtJTkQsIEVYUFJFU1Ncbi8vIE9SIElNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0Zcbi8vIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EIE5PTklORlJJTkdFTUVOVC4gSU5cbi8vIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1JTIE9SIENPUFlSSUdIVCBIT0xERVJTIEJFIExJQUJMRSBGT1IgQU5ZIENMQUlNLFxuLy8gREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULCBUT1JUIE9SXG4vLyBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT04gV0lUSCBUSEUgU09GVFdBUkUgT1IgVEhFXG4vLyBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuXG4ndXNlIHN0cmljdCc7XG5cbi8qPHJlcGxhY2VtZW50PiovXG5cbnZhciBCdWZmZXIgPSByZXF1aXJlKCdzYWZlLWJ1ZmZlcicpLkJ1ZmZlcjtcbi8qPC9yZXBsYWNlbWVudD4qL1xuXG52YXIgaXNFbmNvZGluZyA9IEJ1ZmZlci5pc0VuY29kaW5nIHx8IGZ1bmN0aW9uIChlbmNvZGluZykge1xuICBlbmNvZGluZyA9ICcnICsgZW5jb2Rpbmc7XG4gIHN3aXRjaCAoZW5jb2RpbmcgJiYgZW5jb2RpbmcudG9Mb3dlckNhc2UoKSkge1xuICAgIGNhc2UgJ2hleCc6Y2FzZSAndXRmOCc6Y2FzZSAndXRmLTgnOmNhc2UgJ2FzY2lpJzpjYXNlICdiaW5hcnknOmNhc2UgJ2Jhc2U2NCc6Y2FzZSAndWNzMic6Y2FzZSAndWNzLTInOmNhc2UgJ3V0ZjE2bGUnOmNhc2UgJ3V0Zi0xNmxlJzpjYXNlICdyYXcnOlxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgfVxufTtcblxuZnVuY3Rpb24gX25vcm1hbGl6ZUVuY29kaW5nKGVuYykge1xuICBpZiAoIWVuYykgcmV0dXJuICd1dGY4JztcbiAgdmFyIHJldHJpZWQ7XG4gIHdoaWxlICh0cnVlKSB7XG4gICAgc3dpdGNoIChlbmMpIHtcbiAgICAgIGNhc2UgJ3V0ZjgnOlxuICAgICAgY2FzZSAndXRmLTgnOlxuICAgICAgICByZXR1cm4gJ3V0ZjgnO1xuICAgICAgY2FzZSAndWNzMic6XG4gICAgICBjYXNlICd1Y3MtMic6XG4gICAgICBjYXNlICd1dGYxNmxlJzpcbiAgICAgIGNhc2UgJ3V0Zi0xNmxlJzpcbiAgICAgICAgcmV0dXJuICd1dGYxNmxlJztcbiAgICAgIGNhc2UgJ2xhdGluMSc6XG4gICAgICBjYXNlICdiaW5hcnknOlxuICAgICAgICByZXR1cm4gJ2xhdGluMSc7XG4gICAgICBjYXNlICdiYXNlNjQnOlxuICAgICAgY2FzZSAnYXNjaWknOlxuICAgICAgY2FzZSAnaGV4JzpcbiAgICAgICAgcmV0dXJuIGVuYztcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIGlmIChyZXRyaWVkKSByZXR1cm47IC8vIHVuZGVmaW5lZFxuICAgICAgICBlbmMgPSAoJycgKyBlbmMpLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIHJldHJpZWQgPSB0cnVlO1xuICAgIH1cbiAgfVxufTtcblxuLy8gRG8gbm90IGNhY2hlIGBCdWZmZXIuaXNFbmNvZGluZ2Agd2hlbiBjaGVja2luZyBlbmNvZGluZyBuYW1lcyBhcyBzb21lXG4vLyBtb2R1bGVzIG1vbmtleS1wYXRjaCBpdCB0byBzdXBwb3J0IGFkZGl0aW9uYWwgZW5jb2RpbmdzXG5mdW5jdGlvbiBub3JtYWxpemVFbmNvZGluZyhlbmMpIHtcbiAgdmFyIG5lbmMgPSBfbm9ybWFsaXplRW5jb2RpbmcoZW5jKTtcbiAgaWYgKHR5cGVvZiBuZW5jICE9PSAnc3RyaW5nJyAmJiAoQnVmZmVyLmlzRW5jb2RpbmcgPT09IGlzRW5jb2RpbmcgfHwgIWlzRW5jb2RpbmcoZW5jKSkpIHRocm93IG5ldyBFcnJvcignVW5rbm93biBlbmNvZGluZzogJyArIGVuYyk7XG4gIHJldHVybiBuZW5jIHx8IGVuYztcbn1cblxuLy8gU3RyaW5nRGVjb2RlciBwcm92aWRlcyBhbiBpbnRlcmZhY2UgZm9yIGVmZmljaWVudGx5IHNwbGl0dGluZyBhIHNlcmllcyBvZlxuLy8gYnVmZmVycyBpbnRvIGEgc2VyaWVzIG9mIEpTIHN0cmluZ3Mgd2l0aG91dCBicmVha2luZyBhcGFydCBtdWx0aS1ieXRlXG4vLyBjaGFyYWN0ZXJzLlxuZXhwb3J0cy5TdHJpbmdEZWNvZGVyID0gU3RyaW5nRGVjb2RlcjtcbmZ1bmN0aW9uIFN0cmluZ0RlY29kZXIoZW5jb2RpbmcpIHtcbiAgdGhpcy5lbmNvZGluZyA9IG5vcm1hbGl6ZUVuY29kaW5nKGVuY29kaW5nKTtcbiAgdmFyIG5iO1xuICBzd2l0Y2ggKHRoaXMuZW5jb2RpbmcpIHtcbiAgICBjYXNlICd1dGYxNmxlJzpcbiAgICAgIHRoaXMudGV4dCA9IHV0ZjE2VGV4dDtcbiAgICAgIHRoaXMuZW5kID0gdXRmMTZFbmQ7XG4gICAgICBuYiA9IDQ7XG4gICAgICBicmVhaztcbiAgICBjYXNlICd1dGY4JzpcbiAgICAgIHRoaXMuZmlsbExhc3QgPSB1dGY4RmlsbExhc3Q7XG4gICAgICBuYiA9IDQ7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdiYXNlNjQnOlxuICAgICAgdGhpcy50ZXh0ID0gYmFzZTY0VGV4dDtcbiAgICAgIHRoaXMuZW5kID0gYmFzZTY0RW5kO1xuICAgICAgbmIgPSAzO1xuICAgICAgYnJlYWs7XG4gICAgZGVmYXVsdDpcbiAgICAgIHRoaXMud3JpdGUgPSBzaW1wbGVXcml0ZTtcbiAgICAgIHRoaXMuZW5kID0gc2ltcGxlRW5kO1xuICAgICAgcmV0dXJuO1xuICB9XG4gIHRoaXMubGFzdE5lZWQgPSAwO1xuICB0aGlzLmxhc3RUb3RhbCA9IDA7XG4gIHRoaXMubGFzdENoYXIgPSBCdWZmZXIuYWxsb2NVbnNhZmUobmIpO1xufVxuXG5TdHJpbmdEZWNvZGVyLnByb3RvdHlwZS53cml0ZSA9IGZ1bmN0aW9uIChidWYpIHtcbiAgaWYgKGJ1Zi5sZW5ndGggPT09IDApIHJldHVybiAnJztcbiAgdmFyIHI7XG4gIHZhciBpO1xuICBpZiAodGhpcy5sYXN0TmVlZCkge1xuICAgIHIgPSB0aGlzLmZpbGxMYXN0KGJ1Zik7XG4gICAgaWYgKHIgPT09IHVuZGVmaW5lZCkgcmV0dXJuICcnO1xuICAgIGkgPSB0aGlzLmxhc3ROZWVkO1xuICAgIHRoaXMubGFzdE5lZWQgPSAwO1xuICB9IGVsc2Uge1xuICAgIGkgPSAwO1xuICB9XG4gIGlmIChpIDwgYnVmLmxlbmd0aCkgcmV0dXJuIHIgPyByICsgdGhpcy50ZXh0KGJ1ZiwgaSkgOiB0aGlzLnRleHQoYnVmLCBpKTtcbiAgcmV0dXJuIHIgfHwgJyc7XG59O1xuXG5TdHJpbmdEZWNvZGVyLnByb3RvdHlwZS5lbmQgPSB1dGY4RW5kO1xuXG4vLyBSZXR1cm5zIG9ubHkgY29tcGxldGUgY2hhcmFjdGVycyBpbiBhIEJ1ZmZlclxuU3RyaW5nRGVjb2Rlci5wcm90b3R5cGUudGV4dCA9IHV0ZjhUZXh0O1xuXG4vLyBBdHRlbXB0cyB0byBjb21wbGV0ZSBhIHBhcnRpYWwgbm9uLVVURi04IGNoYXJhY3RlciB1c2luZyBieXRlcyBmcm9tIGEgQnVmZmVyXG5TdHJpbmdEZWNvZGVyLnByb3RvdHlwZS5maWxsTGFzdCA9IGZ1bmN0aW9uIChidWYpIHtcbiAgaWYgKHRoaXMubGFzdE5lZWQgPD0gYnVmLmxlbmd0aCkge1xuICAgIGJ1Zi5jb3B5KHRoaXMubGFzdENoYXIsIHRoaXMubGFzdFRvdGFsIC0gdGhpcy5sYXN0TmVlZCwgMCwgdGhpcy5sYXN0TmVlZCk7XG4gICAgcmV0dXJuIHRoaXMubGFzdENoYXIudG9TdHJpbmcodGhpcy5lbmNvZGluZywgMCwgdGhpcy5sYXN0VG90YWwpO1xuICB9XG4gIGJ1Zi5jb3B5KHRoaXMubGFzdENoYXIsIHRoaXMubGFzdFRvdGFsIC0gdGhpcy5sYXN0TmVlZCwgMCwgYnVmLmxlbmd0aCk7XG4gIHRoaXMubGFzdE5lZWQgLT0gYnVmLmxlbmd0aDtcbn07XG5cbi8vIENoZWNrcyB0aGUgdHlwZSBvZiBhIFVURi04IGJ5dGUsIHdoZXRoZXIgaXQncyBBU0NJSSwgYSBsZWFkaW5nIGJ5dGUsIG9yIGFcbi8vIGNvbnRpbnVhdGlvbiBieXRlLiBJZiBhbiBpbnZhbGlkIGJ5dGUgaXMgZGV0ZWN0ZWQsIC0yIGlzIHJldHVybmVkLlxuZnVuY3Rpb24gdXRmOENoZWNrQnl0ZShieXRlKSB7XG4gIGlmIChieXRlIDw9IDB4N0YpIHJldHVybiAwO2Vsc2UgaWYgKGJ5dGUgPj4gNSA9PT0gMHgwNikgcmV0dXJuIDI7ZWxzZSBpZiAoYnl0ZSA+PiA0ID09PSAweDBFKSByZXR1cm4gMztlbHNlIGlmIChieXRlID4+IDMgPT09IDB4MUUpIHJldHVybiA0O1xuICByZXR1cm4gYnl0ZSA+PiA2ID09PSAweDAyID8gLTEgOiAtMjtcbn1cblxuLy8gQ2hlY2tzIGF0IG1vc3QgMyBieXRlcyBhdCB0aGUgZW5kIG9mIGEgQnVmZmVyIGluIG9yZGVyIHRvIGRldGVjdCBhblxuLy8gaW5jb21wbGV0ZSBtdWx0aS1ieXRlIFVURi04IGNoYXJhY3Rlci4gVGhlIHRvdGFsIG51bWJlciBvZiBieXRlcyAoMiwgMywgb3IgNClcbi8vIG5lZWRlZCB0byBjb21wbGV0ZSB0aGUgVVRGLTggY2hhcmFjdGVyIChpZiBhcHBsaWNhYmxlKSBhcmUgcmV0dXJuZWQuXG5mdW5jdGlvbiB1dGY4Q2hlY2tJbmNvbXBsZXRlKHNlbGYsIGJ1ZiwgaSkge1xuICB2YXIgaiA9IGJ1Zi5sZW5ndGggLSAxO1xuICBpZiAoaiA8IGkpIHJldHVybiAwO1xuICB2YXIgbmIgPSB1dGY4Q2hlY2tCeXRlKGJ1ZltqXSk7XG4gIGlmIChuYiA+PSAwKSB7XG4gICAgaWYgKG5iID4gMCkgc2VsZi5sYXN0TmVlZCA9IG5iIC0gMTtcbiAgICByZXR1cm4gbmI7XG4gIH1cbiAgaWYgKC0taiA8IGkgfHwgbmIgPT09IC0yKSByZXR1cm4gMDtcbiAgbmIgPSB1dGY4Q2hlY2tCeXRlKGJ1ZltqXSk7XG4gIGlmIChuYiA+PSAwKSB7XG4gICAgaWYgKG5iID4gMCkgc2VsZi5sYXN0TmVlZCA9IG5iIC0gMjtcbiAgICByZXR1cm4gbmI7XG4gIH1cbiAgaWYgKC0taiA8IGkgfHwgbmIgPT09IC0yKSByZXR1cm4gMDtcbiAgbmIgPSB1dGY4Q2hlY2tCeXRlKGJ1ZltqXSk7XG4gIGlmIChuYiA+PSAwKSB7XG4gICAgaWYgKG5iID4gMCkge1xuICAgICAgaWYgKG5iID09PSAyKSBuYiA9IDA7ZWxzZSBzZWxmLmxhc3ROZWVkID0gbmIgLSAzO1xuICAgIH1cbiAgICByZXR1cm4gbmI7XG4gIH1cbiAgcmV0dXJuIDA7XG59XG5cbi8vIFZhbGlkYXRlcyBhcyBtYW55IGNvbnRpbnVhdGlvbiBieXRlcyBmb3IgYSBtdWx0aS1ieXRlIFVURi04IGNoYXJhY3RlciBhc1xuLy8gbmVlZGVkIG9yIGFyZSBhdmFpbGFibGUuIElmIHdlIHNlZSBhIG5vbi1jb250aW51YXRpb24gYnl0ZSB3aGVyZSB3ZSBleHBlY3Rcbi8vIG9uZSwgd2UgXCJyZXBsYWNlXCIgdGhlIHZhbGlkYXRlZCBjb250aW51YXRpb24gYnl0ZXMgd2UndmUgc2VlbiBzbyBmYXIgd2l0aFxuLy8gYSBzaW5nbGUgVVRGLTggcmVwbGFjZW1lbnQgY2hhcmFjdGVyICgnXFx1ZmZmZCcpLCB0byBtYXRjaCB2OCdzIFVURi04IGRlY29kaW5nXG4vLyBiZWhhdmlvci4gVGhlIGNvbnRpbnVhdGlvbiBieXRlIGNoZWNrIGlzIGluY2x1ZGVkIHRocmVlIHRpbWVzIGluIHRoZSBjYXNlXG4vLyB3aGVyZSBhbGwgb2YgdGhlIGNvbnRpbnVhdGlvbiBieXRlcyBmb3IgYSBjaGFyYWN0ZXIgZXhpc3QgaW4gdGhlIHNhbWUgYnVmZmVyLlxuLy8gSXQgaXMgYWxzbyBkb25lIHRoaXMgd2F5IGFzIGEgc2xpZ2h0IHBlcmZvcm1hbmNlIGluY3JlYXNlIGluc3RlYWQgb2YgdXNpbmcgYVxuLy8gbG9vcC5cbmZ1bmN0aW9uIHV0ZjhDaGVja0V4dHJhQnl0ZXMoc2VsZiwgYnVmLCBwKSB7XG4gIGlmICgoYnVmWzBdICYgMHhDMCkgIT09IDB4ODApIHtcbiAgICBzZWxmLmxhc3ROZWVkID0gMDtcbiAgICByZXR1cm4gJ1xcdWZmZmQnO1xuICB9XG4gIGlmIChzZWxmLmxhc3ROZWVkID4gMSAmJiBidWYubGVuZ3RoID4gMSkge1xuICAgIGlmICgoYnVmWzFdICYgMHhDMCkgIT09IDB4ODApIHtcbiAgICAgIHNlbGYubGFzdE5lZWQgPSAxO1xuICAgICAgcmV0dXJuICdcXHVmZmZkJztcbiAgICB9XG4gICAgaWYgKHNlbGYubGFzdE5lZWQgPiAyICYmIGJ1Zi5sZW5ndGggPiAyKSB7XG4gICAgICBpZiAoKGJ1ZlsyXSAmIDB4QzApICE9PSAweDgwKSB7XG4gICAgICAgIHNlbGYubGFzdE5lZWQgPSAyO1xuICAgICAgICByZXR1cm4gJ1xcdWZmZmQnO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG4vLyBBdHRlbXB0cyB0byBjb21wbGV0ZSBhIG11bHRpLWJ5dGUgVVRGLTggY2hhcmFjdGVyIHVzaW5nIGJ5dGVzIGZyb20gYSBCdWZmZXIuXG5mdW5jdGlvbiB1dGY4RmlsbExhc3QoYnVmKSB7XG4gIHZhciBwID0gdGhpcy5sYXN0VG90YWwgLSB0aGlzLmxhc3ROZWVkO1xuICB2YXIgciA9IHV0ZjhDaGVja0V4dHJhQnl0ZXModGhpcywgYnVmLCBwKTtcbiAgaWYgKHIgIT09IHVuZGVmaW5lZCkgcmV0dXJuIHI7XG4gIGlmICh0aGlzLmxhc3ROZWVkIDw9IGJ1Zi5sZW5ndGgpIHtcbiAgICBidWYuY29weSh0aGlzLmxhc3RDaGFyLCBwLCAwLCB0aGlzLmxhc3ROZWVkKTtcbiAgICByZXR1cm4gdGhpcy5sYXN0Q2hhci50b1N0cmluZyh0aGlzLmVuY29kaW5nLCAwLCB0aGlzLmxhc3RUb3RhbCk7XG4gIH1cbiAgYnVmLmNvcHkodGhpcy5sYXN0Q2hhciwgcCwgMCwgYnVmLmxlbmd0aCk7XG4gIHRoaXMubGFzdE5lZWQgLT0gYnVmLmxlbmd0aDtcbn1cblxuLy8gUmV0dXJucyBhbGwgY29tcGxldGUgVVRGLTggY2hhcmFjdGVycyBpbiBhIEJ1ZmZlci4gSWYgdGhlIEJ1ZmZlciBlbmRlZCBvbiBhXG4vLyBwYXJ0aWFsIGNoYXJhY3RlciwgdGhlIGNoYXJhY3RlcidzIGJ5dGVzIGFyZSBidWZmZXJlZCB1bnRpbCB0aGUgcmVxdWlyZWRcbi8vIG51bWJlciBvZiBieXRlcyBhcmUgYXZhaWxhYmxlLlxuZnVuY3Rpb24gdXRmOFRleHQoYnVmLCBpKSB7XG4gIHZhciB0b3RhbCA9IHV0ZjhDaGVja0luY29tcGxldGUodGhpcywgYnVmLCBpKTtcbiAgaWYgKCF0aGlzLmxhc3ROZWVkKSByZXR1cm4gYnVmLnRvU3RyaW5nKCd1dGY4JywgaSk7XG4gIHRoaXMubGFzdFRvdGFsID0gdG90YWw7XG4gIHZhciBlbmQgPSBidWYubGVuZ3RoIC0gKHRvdGFsIC0gdGhpcy5sYXN0TmVlZCk7XG4gIGJ1Zi5jb3B5KHRoaXMubGFzdENoYXIsIDAsIGVuZCk7XG4gIHJldHVybiBidWYudG9TdHJpbmcoJ3V0ZjgnLCBpLCBlbmQpO1xufVxuXG4vLyBGb3IgVVRGLTgsIGEgcmVwbGFjZW1lbnQgY2hhcmFjdGVyIGlzIGFkZGVkIHdoZW4gZW5kaW5nIG9uIGEgcGFydGlhbFxuLy8gY2hhcmFjdGVyLlxuZnVuY3Rpb24gdXRmOEVuZChidWYpIHtcbiAgdmFyIHIgPSBidWYgJiYgYnVmLmxlbmd0aCA/IHRoaXMud3JpdGUoYnVmKSA6ICcnO1xuICBpZiAodGhpcy5sYXN0TmVlZCkgcmV0dXJuIHIgKyAnXFx1ZmZmZCc7XG4gIHJldHVybiByO1xufVxuXG4vLyBVVEYtMTZMRSB0eXBpY2FsbHkgbmVlZHMgdHdvIGJ5dGVzIHBlciBjaGFyYWN0ZXIsIGJ1dCBldmVuIGlmIHdlIGhhdmUgYW4gZXZlblxuLy8gbnVtYmVyIG9mIGJ5dGVzIGF2YWlsYWJsZSwgd2UgbmVlZCB0byBjaGVjayBpZiB3ZSBlbmQgb24gYSBsZWFkaW5nL2hpZ2hcbi8vIHN1cnJvZ2F0ZS4gSW4gdGhhdCBjYXNlLCB3ZSBuZWVkIHRvIHdhaXQgZm9yIHRoZSBuZXh0IHR3byBieXRlcyBpbiBvcmRlciB0b1xuLy8gZGVjb2RlIHRoZSBsYXN0IGNoYXJhY3RlciBwcm9wZXJseS5cbmZ1bmN0aW9uIHV0ZjE2VGV4dChidWYsIGkpIHtcbiAgaWYgKChidWYubGVuZ3RoIC0gaSkgJSAyID09PSAwKSB7XG4gICAgdmFyIHIgPSBidWYudG9TdHJpbmcoJ3V0ZjE2bGUnLCBpKTtcbiAgICBpZiAocikge1xuICAgICAgdmFyIGMgPSByLmNoYXJDb2RlQXQoci5sZW5ndGggLSAxKTtcbiAgICAgIGlmIChjID49IDB4RDgwMCAmJiBjIDw9IDB4REJGRikge1xuICAgICAgICB0aGlzLmxhc3ROZWVkID0gMjtcbiAgICAgICAgdGhpcy5sYXN0VG90YWwgPSA0O1xuICAgICAgICB0aGlzLmxhc3RDaGFyWzBdID0gYnVmW2J1Zi5sZW5ndGggLSAyXTtcbiAgICAgICAgdGhpcy5sYXN0Q2hhclsxXSA9IGJ1ZltidWYubGVuZ3RoIC0gMV07XG4gICAgICAgIHJldHVybiByLnNsaWNlKDAsIC0xKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHI7XG4gIH1cbiAgdGhpcy5sYXN0TmVlZCA9IDE7XG4gIHRoaXMubGFzdFRvdGFsID0gMjtcbiAgdGhpcy5sYXN0Q2hhclswXSA9IGJ1ZltidWYubGVuZ3RoIC0gMV07XG4gIHJldHVybiBidWYudG9TdHJpbmcoJ3V0ZjE2bGUnLCBpLCBidWYubGVuZ3RoIC0gMSk7XG59XG5cbi8vIEZvciBVVEYtMTZMRSB3ZSBkbyBub3QgZXhwbGljaXRseSBhcHBlbmQgc3BlY2lhbCByZXBsYWNlbWVudCBjaGFyYWN0ZXJzIGlmIHdlXG4vLyBlbmQgb24gYSBwYXJ0aWFsIGNoYXJhY3Rlciwgd2Ugc2ltcGx5IGxldCB2OCBoYW5kbGUgdGhhdC5cbmZ1bmN0aW9uIHV0ZjE2RW5kKGJ1Zikge1xuICB2YXIgciA9IGJ1ZiAmJiBidWYubGVuZ3RoID8gdGhpcy53cml0ZShidWYpIDogJyc7XG4gIGlmICh0aGlzLmxhc3ROZWVkKSB7XG4gICAgdmFyIGVuZCA9IHRoaXMubGFzdFRvdGFsIC0gdGhpcy5sYXN0TmVlZDtcbiAgICByZXR1cm4gciArIHRoaXMubGFzdENoYXIudG9TdHJpbmcoJ3V0ZjE2bGUnLCAwLCBlbmQpO1xuICB9XG4gIHJldHVybiByO1xufVxuXG5mdW5jdGlvbiBiYXNlNjRUZXh0KGJ1ZiwgaSkge1xuICB2YXIgbiA9IChidWYubGVuZ3RoIC0gaSkgJSAzO1xuICBpZiAobiA9PT0gMCkgcmV0dXJuIGJ1Zi50b1N0cmluZygnYmFzZTY0JywgaSk7XG4gIHRoaXMubGFzdE5lZWQgPSAzIC0gbjtcbiAgdGhpcy5sYXN0VG90YWwgPSAzO1xuICBpZiAobiA9PT0gMSkge1xuICAgIHRoaXMubGFzdENoYXJbMF0gPSBidWZbYnVmLmxlbmd0aCAtIDFdO1xuICB9IGVsc2Uge1xuICAgIHRoaXMubGFzdENoYXJbMF0gPSBidWZbYnVmLmxlbmd0aCAtIDJdO1xuICAgIHRoaXMubGFzdENoYXJbMV0gPSBidWZbYnVmLmxlbmd0aCAtIDFdO1xuICB9XG4gIHJldHVybiBidWYudG9TdHJpbmcoJ2Jhc2U2NCcsIGksIGJ1Zi5sZW5ndGggLSBuKTtcbn1cblxuZnVuY3Rpb24gYmFzZTY0RW5kKGJ1Zikge1xuICB2YXIgciA9IGJ1ZiAmJiBidWYubGVuZ3RoID8gdGhpcy53cml0ZShidWYpIDogJyc7XG4gIGlmICh0aGlzLmxhc3ROZWVkKSByZXR1cm4gciArIHRoaXMubGFzdENoYXIudG9TdHJpbmcoJ2Jhc2U2NCcsIDAsIDMgLSB0aGlzLmxhc3ROZWVkKTtcbiAgcmV0dXJuIHI7XG59XG5cbi8vIFBhc3MgYnl0ZXMgb24gdGhyb3VnaCBmb3Igc2luZ2xlLWJ5dGUgZW5jb2RpbmdzIChlLmcuIGFzY2lpLCBsYXRpbjEsIGhleClcbmZ1bmN0aW9uIHNpbXBsZVdyaXRlKGJ1Zikge1xuICByZXR1cm4gYnVmLnRvU3RyaW5nKHRoaXMuZW5jb2RpbmcpO1xufVxuXG5mdW5jdGlvbiBzaW1wbGVFbmQoYnVmKSB7XG4gIHJldHVybiBidWYgJiYgYnVmLmxlbmd0aCA/IHRoaXMud3JpdGUoYnVmKSA6ICcnO1xufSIsIlxuLyoqXG4gKiBGb3IgTm9kZS5qcywgc2ltcGx5IHJlLWV4cG9ydCB0aGUgY29yZSBgdXRpbC5kZXByZWNhdGVgIGZ1bmN0aW9uLlxuICovXG5cbm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgndXRpbCcpLmRlcHJlY2F0ZTtcbiIsIm1vZHVsZS5leHBvcnRzID0gZXh0ZW5kXG5cbnZhciBoYXNPd25Qcm9wZXJ0eSA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG5cbmZ1bmN0aW9uIGV4dGVuZCh0YXJnZXQpIHtcbiAgICBmb3IgKHZhciBpID0gMTsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgICB2YXIgc291cmNlID0gYXJndW1lbnRzW2ldXG5cbiAgICAgICAgZm9yICh2YXIga2V5IGluIHNvdXJjZSkge1xuICAgICAgICAgICAgaWYgKGhhc093blByb3BlcnR5LmNhbGwoc291cmNlLCBrZXkpKSB7XG4gICAgICAgICAgICAgICAgdGFyZ2V0W2tleV0gPSBzb3VyY2Vba2V5XVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHRhcmdldFxufVxuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiYXNzZXJ0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImJ1ZmZlclwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJjcnlwdG9cIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiZG5zXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImV2ZW50c1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJmc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicGF0aFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJzdHJlYW1cIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwic3RyaW5nX2RlY29kZXJcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwidGxzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInVybFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJ1dGlsXCIpOyIsIi8vIFRoZSBtb2R1bGUgY2FjaGVcbnZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcblxuLy8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbmZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG5cdHZhciBjYWNoZWRNb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdO1xuXHRpZiAoY2FjaGVkTW9kdWxlICE9PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gY2FjaGVkTW9kdWxlLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0Ly8gbm8gbW9kdWxlLmlkIG5lZWRlZFxuXHRcdC8vIG5vIG1vZHVsZS5sb2FkZWQgbmVlZGVkXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4iLCIvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9ucyBmb3IgaGFybW9ueSBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSAoZXhwb3J0cywgZGVmaW5pdGlvbikgPT4ge1xuXHRmb3IodmFyIGtleSBpbiBkZWZpbml0aW9uKSB7XG5cdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKGRlZmluaXRpb24sIGtleSkgJiYgIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBrZXkpKSB7XG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywga2V5LCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZGVmaW5pdGlvbltrZXldIH0pO1xuXHRcdH1cblx0fVxufTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSAob2JqLCBwcm9wKSA9PiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwgcHJvcCkpIiwiLy8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5yID0gKGV4cG9ydHMpID0+IHtcblx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG5cdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG5cdH1cblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbn07IiwiIiwiLy8gc3RhcnR1cFxuLy8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4vLyBUaGlzIGVudHJ5IG1vZHVsZSBkb2Vzbid0IHRlbGwgYWJvdXQgaXQncyB0b3AtbGV2ZWwgZGVjbGFyYXRpb25zIHNvIGl0IGNhbid0IGJlIGlubGluZWRcbnZhciBfX3dlYnBhY2tfZXhwb3J0c19fID0gX193ZWJwYWNrX3JlcXVpcmVfXyg1MDM1KTtcbiIsIiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==